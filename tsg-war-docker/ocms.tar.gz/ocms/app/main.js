require([
	// Application.
	"app",
	"context",
	"header",
	"configuredrouters",
	"modules/common/alert/alert",
	"modules/common/popoverhandler",	
	"modules/common/modalactionhandler",
	"modules/tour/searchtour",
	"modules/tour/stagetour",
	"modules/formsupport",
	"modules/services/exitservice",
	"modules/services/googleanalyticsservice",
	"modules/common/useragent",
	"modules/services/localizationservice",
	"modules/common/handlebarsService",
	"modules/common/hpiconstants"
],


function(app, Context, Header, ConfiguredRouters, Alert, PopoverHandler, ModalActionHandler, SearchTour, StageTour, FormSupport, ExitService, GoogleAnalyticsService, UserAgent, LocalizationService, HandlebarsService, HPIConstants) {
		
	// Helper for using layouts.
	app.useLayout = function(name, options) { 
		var tour = null;

		if (this.layout && this.layout.options.template === name) {
			app.log.debug(window.localize("app.main.layoutAlready"));
			// remove any active tours and their view
			// get any existing tour views
			tour = this.layout.getView("#tour-outlet");
			if(tour) {
				tour.removeInstances();
				tour.remove();
			}
			return this.layout;
		}

		// If a layout already exists, remove it from the DOM.
		if (this.layout) {
			// remove any active tours and their view
			// get any existing tour views
			tour = this.layout.getView("#tour-outlet");
			if(tour) {
				tour.removeInstances();
				tour.remove();
			}

			this.layout.remove();

		}

		// Create a new Layout with options.
		var layout = new Backbone.Layout(_.extend({
			template: name,
			className: "layout " + name,
			id: "layout",
			views : {
				"#alert" : new Alert.Views.Layout(),
				"#modalActionHandler-outlet" : new ModalActionHandler.View(),
				"#popoverHandler-outlet" : new PopoverHandler.View(),
				"#formSupport-outlet" : new FormSupport.View(),
				"#tour-outlet" : new SearchTour.Views.Layout(),
				"#stage-tour-outlet" : new StageTour.Views.Layout()
			},
			serialize: function() {
				return {
					removeHeader: options ? options.removeHeader : false
				};
			}
		}, options));
		

		//we don't want the nav-bar if we are loading up the login screen, it makes an unnecessary fetch call for AppConfig
		// also if we have the removeHeader option then we dont want to show the header navigation bar
		if (name !== "layout-login" && name!== "layout-error" && (options ? !options.removeHeader : true) )	{
			layout.setViews({
                "#nav-outlet" : new Header.View()
            });
		}

		// Insert into the DOM.
		$("#main").empty().append(layout.el);

		// Cache the refererence.
		this.layout = layout;

		// Return the reference, for chainability.
		return layout;
	};

	// Define your master router on the application namespace and trigger all
	// navigation from this instance.
	app.routers = ConfiguredRouters;

	// Store the previous route
	app.prevRoute = "";

	/**
	* This function starts the router and if a
	* login isn't found, goes to the login page
	*/
	var startApp = function(errorMode){

		// adding debugging statement for a common configuration error
		app.log.debug(window.localize("app.main.appRootIs") + app.root);

		// Register all of the handlebar helper functions we have.
		HandlebarsService.registerHelpers();

		if(app.checkForSupportedBrowser){
			// Make sure the browser being used is an acceptable browser for this application.
			UserAgent.checkSupportedBrowserVersions();
		} else {
			// If this application is not configured to check if the current browser is supported or not, let's assume it is.
			app.isBrowserSupported = true;
		}

		if(!app.isBrowserSupported){
			// The user's browser is not supported, let's let them know that with a message displaying the issue.
            // does not use the setupLayout function on purpose - this is unique for login
            $("body").attr("class", "login");
            app.useLayout("layout-login").setViews({
                "#login-outlet" : new UserAgent.UnsupportedBrowserView({'browser': app.browser})
            }).render();
		} else {
			// if the users cookie is non-existent, save the current url and then redirect to login
			if(!$.cookie("ocUser")) {
				//Start the router, but don't run the inital route because we need a login
				Backbone.history.start({ pushState: true, root: app.root, silent: true });
				//if(!Backbone.History.started) Backbone.history.start({ pushState: true, root: app.root, silent: true });

				app.savedUrl = Backbone.history.fragment;
				Backbone.history.navigate("");
				app.routers.main.index(errorMode); //go to the index route
			}else{
				//if we have a ticket already, use main to set up this beforeunload. Otherwise, security will do it.
					ExitService.register('userpreferences.save', function(){
		                //save the user preferences if it exists - async code won't work here
		                if(app.context.currentUserPreferences()){
							app.context.currentUserPreferences().saveNow({version: false}, {global: false});
						}
	                });
				//proceed
				Backbone.history.start({ pushState: true, root: app.root });
				//if(!Backbone.History.started) Backbone.history.start({ pushState: true, root: app.root });
			}
		}
	};

	//Hit the resolveLang endpoint so we can determine which language to use.
	var url = app.serviceUrlRoot + "/localization/resolveLang";
	Backbone.ajax({
		url: url,
		global: false,
		success: function(ticket, status, headers) {
			var expSoon = headers.getResponseHeader("ExpiringSoon");
			if (expSoon) {
				app.licenseInfo = {};
				app.licenseInfo.showLicenseError = true;
				app.licenseInfo.remainingDaysOnLicense = expSoon;
			}
			//get our languages
			var languagesHeader = headers.getResponseHeader("content-language");
			//determine which language to set
			LocalizationService.loadTimezones();
			LocalizationService.resolveLang(languagesHeader);
			
			startApp();
		},
		error: function(xhr) {
			if (xhr.status === HPIConstants.HTTP.Status.PreconditionFailed) {
				// precondition failed - too many users in the repo
				startApp("licenseErrorTooManyUsers");
			} else if (xhr.status === HPIConstants.HTTP.Status.PaymentRequired) {
				//check to see if license is missing or expired
				 if (xhr.getResponseHeader("Expired")) {
					startApp("licenseErrorExpired");
				} else {
					startApp("licenseError");
				}
			} else {
				//otherwise, likely couldn't connect to OC, start app in error mode
				startApp("generalError");
			}
		}
	});

	// All navigation that is relative should be passed through the navigate
	// method, to be processed by the router. If the link has a `data-bypass`
	// attribute, bypass the delegation completely.
	$(document).on("click", "a:not([data-bypass])", function(evt) {
		// Get the absolute anchor href.
		var href = { prop: $(this).prop("href"), attr: $(this).attr("href") };
		// Get the absolute root.
		var root = location.protocol + "//" + location.host + app.root;

		// Ensure the root is part of the anchor href, meaning it's relative.
		if (href.prop && href.prop.slice(0, root.length) === root) {
			// Stop the default event to ensure the link will not cause a page
			// refresh.
			evt.preventDefault();

			// `Backbone.history.navigate` is sufficient for all Routers and will
			// trigger the correct events. The Router's internal `navigate` method
			// calls this anyways.  The fragment is sliced from the root.
			Backbone.history.navigate(href.attr, true);
		}
	});

});
