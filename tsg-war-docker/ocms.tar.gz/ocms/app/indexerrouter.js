define([
	// Application.
	"app",
	"oc",
	"abstractrouter",
	"modules/indexer/indexer",
	"modules/indexer/indexersuggestionenabled"
],

	function(app, OC, AbstractRouter, Indexer, IndexerSuggestionEnabled) {
		"use strict";

		// Defining the application router, you can attach sub routers here.
		var IndexRouter = AbstractRouter.extend({
			// Map of - URL Patter : 
			routes: {
				"indexer/index" : "indexer",
				"indexer(/:docId)/index" : "indexer",
				"indexer(/:docId)/postIndexing" : "postIndexing",
				"indexer(/:configName)(/:queueName)/queued(/:docId)/index" : "indexerQueued"
			},
			initialize: function(){
				AbstractRouter.__super__.initialize.apply(this, arguments);

			},
			beforeRoute: function() {
				//Layout
				$("body").removeClass(); // removes all classes (such as login)

				this.layout = app.useLayout("layout-1-col");
				return this.layout;
			},

			indexer: function(docId) {
				var self = this;
				var layout = this.beforeRoute();

				app.context.configService.getIndexerConfigNames(function(names) {
					app.context.configService.getIndexerConfigByName(names[0], function(indexerConfig){
						var indexerDocModel = new Indexer.DocumentModel({
							objectId: docId,
						});

						self.fetchDocOco(docId)
							.done(function() {

								//Determine which indexerView type should be used
								var indexerView = self.initializeIndexerView(self.docOco, indexerDocModel, indexerConfig);
								self.attachIndexerView(layout, indexerView);

							})
							.fail(function() {
								var indexerView = new Indexer.Views.Layout({
									model: indexerDocModel,
									config: indexerConfig
								});
								self.attachIndexerView(layout, indexerView);
							});
					});
				});
			},
			indexerQueued: function(configName, queueName, docId) {
				var self = this;
				var layout = this.beforeRoute();

				app.context.configService.getIndexerConfigByName(configName, function(indexerConfig){
					app.context.configService.getDashboardConfig(function(dashboardConfig){
						// Search dashboard config for our dashboard config.
						var dashletsCollection = dashboardConfig.get("dashlets");
						var queueDashletConfig = dashletsCollection.findWhere({dashletId: queueName});

						var indexerDocModel = new Indexer.DocumentModel({
							objectId: docId,
							dashletConfig: queueDashletConfig
						});

						self.fetchDocOco(docId)
							.done(function() {

								//Determine which indexerView type should be used
								var indexerView = self.initializeIndexerView(self.docOco, indexerDocModel, indexerConfig);
								self.attachIndexerView(layout, indexerView);

							})
							.fail(function() {
								var indexerView = new Indexer.Views.Layout({
									model: indexerDocModel,
									config: indexerConfig
								});
								self.attachIndexerView(layout, indexerView);
							});
					});
				});
			},
			postIndexing: function(docId) {
				var layout = this.beforeRoute();

				var indexerDocModel = new Indexer.DocumentModel({
					objectId: docId
				});

				layout.setViews({
					"#content-outlet" : new Indexer.Views.PostLayout({
						model: indexerDocModel
					})	
				});

				layout.render();
			},
			fetchDocOco: function(docId) {
				this.docOco = new OC.OpenContentObject({
                		objectId: docId
            		});
            	return this.docOco.fetch();
			},
			initializeIndexerView: function(docOco, indexerDocModel, indexerConfig) {

				//Find config for document's object type
				var matchingType = indexerConfig.get("types").findWhere({ocName: docOco.get("objectType")});
				var indexerView = null;

				//Check if config has suggestions enabled and set appropriate view type
				if(matchingType && matchingType.get('suggestionDataEnabled')) {
					indexerView = new IndexerSuggestionEnabled.Views.Layout({
						model: indexerDocModel,
						config: indexerConfig,
						oco: docOco,
						tableSelectMode: matchingType.get('tableExtractEnabled')
					});
				} else {
					indexerView = new Indexer.Views.Layout({
						model: indexerDocModel,
						config: indexerConfig,
						oco: docOco
					});
				}
				return indexerView;
			},
			attachIndexerView: function(layout, indexerView) {
				layout.setViews({
					"#content-outlet" : indexerView
				});

				layout.render();
			}
		});



		return IndexRouter;

	});