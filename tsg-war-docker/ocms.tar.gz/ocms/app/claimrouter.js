define([
    "app",
    "abstractrouter"
],
function(app, AbstractRouter) {

        // Defining the application router, you can attach sub routers here.
        var Router = AbstractRouter.extend({
            routes: {
                "claim?*urlParams": "getOrCreateClaimFolder",
            },
            getOrCreateClaimFolder: function(urlParams) {
                var self = this;

                var folderProperties = {};
                folderProperties = $.deparam(urlParams);
                _.each(Object.keys(folderProperties), function(key) {
                    if (key.toLowerCase().search("date") !== -1) {
                        // incoming property like {lossDate: '2020-05-19'} returns as {lossDate: 1589864400000}
                        folderProperties[key] = moment(folderProperties[key], 'YYYY-MM-DD').valueOf();
                    }
                });

                $.ajax({
                    type: "POST",
                    url: app.serviceUrlRoot + "/insurance/getOrCreateClaimFolder",
                    data: JSON.stringify(folderProperties),
                    contentType: "application/json",
                    success: function(folderObjectId) {
                        self.navigateToStage(folderObjectId);
                    },
                    error: function(response) { 
                        $("body").attr("class", "login");
                        app.useLayout("layout-login").render();

                        var responseTextJson = JSON.parse(response.responseText);
                        var errorMessage = window.localize("generic.status") + ": '" + responseTextJson.status + " " + response.statusText;
                        errorMessage += "'. " + window.localize("generic.message") + ": '" + responseTextJson.message + "'";

                        app.trigger("alert:error", {
                            header: window.localize("app.router.claim.getOrCreateClaimFolder.error.header"),
                            message: errorMessage
                        });
                    }
                });
            },
            /* this function is currently unused after reworking the getOrCreateClaimFolder code
            leaving this as a guide when this needs to be implemented for a client
            attemptToMigrateClaimDocuments: function(folder) {
                var self = this;

                $.ajax({
                    type: "POST",
                    url: app.serviceUrlRoot + "/insurance/updateRepository",
                    data: JSON.stringify(folder),
                    contentType: "application/json",
                    success: self.navigateToStage(folder.objectId),
                    error: function() { }
                });

            },
            */ 
            navigateToStage: function(folderId) {
                Backbone.history.navigate("StageSimple/" + folderId, { trigger: true }, { replace: true });
            }
        });
    
    return Router;
});