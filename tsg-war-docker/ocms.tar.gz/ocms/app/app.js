define([
	// special module for access to config
	"module",

	// libraries
	"jquery",
	"underscore",
	"backbone",
	"handlebars",
	"modules/hpiadmin/logger/logger",
	"backbonerelational",
	"knockout",
	"sanitizeHtml",
	"URIjs/URI",

	"templating",

	// plugins
	"backbonequeryparams",
	"plugins/json2",
	"backbonelayoutmanager",
	"marionette",
	"modules/common/hpiconstants",
	"bootstrap",
	"jqueryMigrationPlugin",
	"jqueryDraggablePlugin",
	"typeahead",
	"l10n",
	"plugins/jquery.cookie"

],
function(module, $, _, Backbone, Handlebars, Logger, backbonerelational, ko, sanitizeHtml, URI, templating) {

	// redefine l10n's localize function for easy global access as function "l"
	var l = window.l = window.localize =  function (string, fallback) {
		var localized = string.toLocaleString();
		if (localized !== string) {
			return localized;
		// if fallback wasn't specified, reutrn the string so that 'undefined' isn't returned
		} else if (fallback) {
			return fallback;
		} else {
			return string;
		}
	};

	// Localize function that allow allows for string replacement via an array of
	// replacement strings in an array
	// For example: "This is a ~0~ ~1~" with the replacements array ["replacement", "array"]
	// will print: "This is a replacement array"
	window.sL = window.sLocalize =  function (string, replacements, fallback) {
		var localized = window.localize(string, fallback);
		
		if (localized !== string) {
			if (replacements && Array.isArray(replacements)) {
				for (var i = 0; i < replacements.length; ++i) {
					localized = localized.replace('~' + i.toString() + '~', replacements[i]);
				}
			}
		}

		return localized;
	};
	
	Handlebars.registerHelper('localize', function(value) {
		return value ? new Handlebars.SafeString(l(value)) : new Handlebars.SafeString('');
	});

	// Provide a global location to place configuration settings and module creation.
	var app = {
		// The root path to run the application.
		root: module.config().root || "/",
		serviceUrlRoot: module.config().serviceUrlRoot,
		defaultAdminGroup: module.config().defaultAdminGroup,
		secureAdminUrl: module.config().secureAdminUrl,
		soapServiceUrlRoot: module.config().soapServiceUrlRoot,
		enableWizard: (module.config().enableWizard !== false ? true : false),
		minCharBeforeQuery: module.config().minCharBeforeQuery || 3,
		openAnnotateURL: module.config().openAnnotateURL || "/OpenAnnotate",
		openAnnotateVideoURL: module.config().openAnnotateVideoURL || "/OpenAnnotateVideo",
		DocViewerURL: module.config().openDocViewerURL || (module.config().root || "/") + "DocViewer",
		shareURL: module.config().shareURL || "/share",
		collectionRelation: module.config().collectionRelation,
		requiredDocs: module.config().requiredDocs,
		remainingRequiredDocs: module.config().remainingRequiredDocs,
		folderTags: module.config().folderTags,
		requiredDocsFolderType: module.config().requiredDocsFolderType,
		uniqueUserName: module.config().uniqueUserName || "displayName",
		objectDisplayName: module.config().objectDisplayName || "objectName",
		showGroupManager: module.config().showGroupManager || false,
		showUserManager: module.config().showUserManager || false,
		showAclManager: module.config().showAclManager || false,
		showTemplateManager: (module.config().showTemplateManager !== false ? true : false),
		openAnnotate: _.extend({}, Backbone.Events),
		checkForSupportedBrowser: module.config().checkForSupportedBrowser,
		supportedBrowsers: module.config().supportedBrowsers,
		developerZone : module.config().developerTab === undefined ? true : module.config().developerTab,
		enableContentlessMode: module.config().enableContentlessMode || false,
		enableSSO : $.cookie("enableSSO") ? ($.cookie("enableSSO") === "true" ? true: false) : false,
		replaceAnchorTags : false,
		secureBrowserCookies: module.config().secureBrowserCookies || false,
		enableDirectSQL: (module.config().enableDirectSQL !== false ? true: false)
	};

	if($.cookie("envSettings")){
		_.extend(app,JSON.parse($.cookie("envSettings"))); 
	}
	
	//checks whether or not to prepend http or https://localhost to the openAnnotateURL in the computer name.json
    if (app.openAnnotateURL.indexOf("http://") !== 0  && app.openAnnotateURL.indexOf("https://") !== 0 ) {
        app.openAnnotateURL = location.origin + app.openAnnotateURL;   
    }

	//checks whether or not to prepend http or https://localhost to the openAnnotateVideoURL in the computer name.json
    if (app.openAnnotateVideoURL.indexOf("http://") !== 0  && app.openAnnotateVideoURL.indexOf("https://") !== 0 ) {
        app.openAnnotateVideoURL = location.origin + app.openAnnotateVideoURL;   
	}
	
	// Localize or create a new JavaScript Template object.
	window.JST = window.JST || {};

	//There is an important memory cleanup modification to layoutManager,
	//check if the version has been upgraded and remind that the change be put back in
	if(Backbone.Layout.VERSION !== "0.9.5"){
		app.trigger("alert:info", {
			header: "Alert",
			message: "It looks like you've upgraded layout manager. " +
			"Congratulations! There is an important memory management tweak in the _removeView method " +
			"that will need to be put back. If you do a 'find' for TSG in the previous layoutmanager JS file " +
			"you will find it. Please make the necessary changes to put it back in the upgraded layoutmanager " +
			"then come here an update this check in app.js. Thanks!"
		});
	}

	//define knockout
	window.ko = ko;

	//this allow for event calls that are pushed on app to be called by action scripts
	window.app = app;

	// this logic grays out the screen and prevents the user from being able to click anything
	// while an ajax request is being made. We put the logic on app so that we can fake a global loading
	// scenario when an async ajax call is being made
	app.startGlobalLoading = function() {
		$("div.nav-logo").hide();
		$("#app-loading").show();
		$('#loading-backdrop').css('filter', 'alpha(opacity=60)');
		$("#loading-backdrop").fadeIn(200);
	};
	
	// this stops the gray out and disabling affect of global loading
	app.doneGlobalLoading = function() {
		$("#loading-backdrop").fadeOut(200, function() {
			$("#app-loading").hide();
			$("div.nav-logo").fadeIn(400);
		});
	};

	// handle auth errors
	$.ajaxSetup({
		statusCode: {
			401: function(){
				// save the url (if its not the login page (at root) calling throwing the 401)
				// and if its not the licenseError page either because otherwise when we login we will be sent back to /licenseError
				if(Backbone.history.fragment !== "" && Backbone.history.fragment !== "licenseError" 
          				&& Backbone.history.fragment !== "licenseErrorTooManyUsers" 
          				&& Backbone.history.fragment !== "licenseErrorExpired") {
					app.savedUrl = Backbone.history.fragment;
					if(app.enableSSO) {
						//Reload application and use the cached application file
						window.location.reload(false);
					} else {
						Backbone.history.navigate("/", {trigger : true});
					}
				}
				app.doneGlobalLoading();
			},
			404: app.doneGlobalLoading,
			500: app.doneGlobalLoading
		}
	});
	app.savedUrl = null;

	$(document).ajaxStart(app.startGlobalLoading);

	$(document).ajaxStop(app.doneGlobalLoading);

	// Add a class to the HTML tag if IE. Use this class as LITTLE as possible. Unfortunately we need it occasionally.
	// (This doesn't seem to work on IE11, but we don't need to target it, yet.
	if ($.browser.msie && $.browser.version) {
		$('html').addClass('ie ie' + parseInt($.browser.version, 10));
	}

	templating.init();

	ko.asyncComputed = function(evaluator, owner) {
		var result = ko.observable();

		ko.computed(function(){
			// Get the $.Deferred value, and then set up a callback so that when it's done,
			// the output is transferred onto our "result" observable
			evaluator.call(owner).done(result);
		});

		return result;
	};

	// patch Array so that IE8 has access to indexOf() - for future reference, its safer to use $.inArray
	Array.prototype.indexOf = function(obj, start) {
		for (var i = (start || 0), j = this.length; i < j; i++) {
			if (this[i] === obj) { return i; }
		}
		return -1;
	};

	//URI Patch
	//Returns value or undefined if key doesn't exist
	URI.prototype.getParameter = function(key) {
		var result = this.query(true)[key];
		if(!result){ result = null; }
		return result;
	};

	Handlebars.registerHelper('equal', function(lvalue, rvalue, options) {
		if (arguments.length < 3){
			throw new Error("Handlebars Helper equal needs 2 parameters");
		}
		if( lvalue!=rvalue ) {
			return options.inverse(this);
		} else {
			return options.fn(this);
		}
	});

	Handlebars.registerHelper('sanitize', function(html) {
		return sanitizeHtml(html);
	});
	
	// Mix Backbone.Events, modules, and layout management into the app object.
	return _.extend(app, {
		// Create a custom object with a nested Views object.
		module: function(additionalProps) {
			return _.extend({ Views: {} }, additionalProps);
		},

		log: Logger
	}, Backbone.Events);

});
