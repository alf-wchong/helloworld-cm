define([
        "jquery",
        "app",
        "knockout",
        "moment",
        "momentTimezone",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/otc/objecttypeconfig",
        "modules/hpiadmin/nmac/nonmandatoryaspectconfig",
        "modules/hpiadmin/otc/repotype",
        "modules/hpiadmin/picklistconfig/picklistconfig",
        "modules/common/action",
        "modules/hpiadmin/searchconfig/searchconfig",
        "modules/hpiadmin/stageconfig/stageconfig",
        "modules/hpiadmin/applicationconfig/applicationconfig",
        "modules/hpiadmin/collectionconfig/collectionconfig",
        "modules/hpiadmin/indexerconfig/indexerconfig",
        "modules/hpiadmin/dashboardconfig/dashboardconfig",
        "modules/hpiadmin/formconfig/formconfig",
        "modules/hpiadmin/templatemanagementconfig/templatemanagementconfig",
        "modules/hpiadmin/workflowformconfig/singleworkflowform",
        "modules/hpiadmin/workflowformconfig/workflowformconfig",
        "modules/hpiadmin/workflowconfig/workflowconfig",
        "modules/hpiadmin/preferences/userpreferences",
        "modules/hpiadmin/securityconfig/securityconfig",
        "modules/hpiadmin/wizardconfig/wizardconfig",
        "modules/hpiadmin/loggingconfig/loggingconfig",
        "modules/hpiadmin/preferences/publicpreferences",
        "oc",
        "plugins/jquery.cookie",
        "modules/hpiadmin/tracconfig/tracconfig",
        "modules/services/localizationservice",
        "sessiontimeout",
        "modules/common/themeService/themeService",
        "modules/common/hpiconstants",
        "datetimePicker"
    ],


    //This module is imported by main and serves to provide common services and stateful information to other parts of the application
    //by attaching them to app
    function($, app, ko, moment, momentTimezone, Hpiadmin, OTC, NMAC, Repotype, PicklistConfig, Action, SearchConfig,
        StageConfig, ApplicationConfig, CollectionConfig, IndexerConfig, DashboardConfig,
        FormConfig, TemplateManagementConfig, SingleAdHocForm, WorkflowFormConfig, WorkflowConfig, UserPreferences, SecurityConfig,
        WizardConfig, LoggingConfig, PublicPreferences, OC, cookie, TracConfig, LocalizationService, SessionTimeout, ThemeService, HPIConstants) {
        var Context = app.context = app.module();
        var plJqXhr;
        var adminOTCName = "default";

        Context.configName = ko.observable();
        Context.currentAdminOTC = ko.observable();
        Context.currentPicklistConfig = ko.observable();
        Context.currentAdminNMAC = ko.observable();
        Context.currentSearchConfig = ko.observable();
        Context.currentStageConfig = ko.observable();
        Context.currentCollectionConfig = ko.observable();
        Context.currentIndexerConfig = ko.observable();
        Context.currentDashboardConfig = ko.observable();
        Context.currentApplicationConfig = ko.observable();
        Context.currentSecurityConfig = ko.observable();
        Context.currentWizardConfig = ko.observable();
        Context.currentUserPreferences = ko.observable();
        Context.currentAdHocFormConfig = ko.observable();
        Context.currentWorkflowConfig = ko.observable();
        Context.currentPublicPreferences = ko.observable();
        Context.currentLoggingConfig = ko.observable();

        Context.container = new OC.OpenContentObject();
        Context.document = new OC.OpenContentObject();

        Context.setContainer = function(newId, successCallback) {
            Context.container.set("objectId", newId).fetch({
                success: successCallback
            });
        };

        Context.setDocument = function(newId, successCallback) {
            Context.document.set("objectId", newId).fetch({
                success: successCallback
            });
        };

        Context.setChildElementEventsObj = function(eventsObj) {
            Context.childElementEventsObj = eventsObj;
        };

        //help method to keep track of config models
        //since backbone doesn't like us to
        //fetch the same model twice.
        var _configHolder = {};
        // let's also create a cache for users

        //forceNewModel forces this method to create a new model to be fetched.
        //99% of the time this will not be necessary, only set this flag if you
        //know what you are doing and a new config is necessary, like in the case
        //of otc in admin
        var _findOrCreateConfig = Context.findOrCreateConfig = function(configModelDef, configName, forceNewModel) {
            //find this types cache or create
            var cache = _configHolder[configModelDef.prototype.type];
            if (!cache) {
                cache = _configHolder[configModelDef.prototype.type] = {};
            }
            var model = cache[configName];
            if (!model || forceNewModel) {
                model = cache[configName] = new configModelDef({
                    name: configName
                });
            }

            return model;
        };

        Context.registerConfig = function(configType, configName, configModel) {
            if (!_configHolder[configType]) {
                _configHolder[configType] = {};
                _configHolder[configType][configName] = configModel;
            } else if (!_configHolder[configType][configName]) {
                _configHolder[configType][configName] = configModel;
            } else {
                throw new Error("config already exists. Please use context.findOrCreateConfig");
            }
        };

        Context.configService = {
            initServicesThatRequireConfigs: function(deferred) {
                Context.configService.getApplicationConfig(function() {
                    Context.configService.getTracConfigs(function() {
                        Context.configService.getAdminOTC(function() {
                            Context.configService.getPicklistServices();

                            SessionTimeout.resetTimeout();
                            //TODO: make this listen to once? maybe move to main.js?
                            $(window).on("click", function() {
                                SessionTimeout.resetTimeout();
                            });

                            ThemeService.Model.prototype.headerCss();

                            deferred.resolve();
                        });
                    });
                });
            },
            /*factored out so that it can be called directly in picklistConfig (when picklist
            is from a webservice) to populate the necessary picklist config observables following
            a refresh in hpiadmin.
            See the webservice picklist section of picklistconfig.js for further explanation*/
            getPicklistServices: function() {
                Context.picklistConfig = _findOrCreateConfig(PicklistConfig.Model, adminOTCName);
                plJqXhr = Context.picklistConfig.fetch({
                    success: function(configModel) {
                        Context.currentPicklistConfig(configModel);

                        //cache the designated picklists
                        var callbackFunc = function(picklistArray, defaultItems, picklistName) {
                            _picklistCache[picklistName] = picklistArray;
                        };
                        for (var i = 0; i < configModel.get("picklists").models.length; i++) {
                            var indPicklistConfig = configModel.get("picklists").models[i];
                            if (indPicklistConfig.get("cache")) {
                                Context.picklistService.getPicklist(indPicklistConfig.get("label"), callbackFunc);
                            }
                        }
                    }
                });
                return plJqXhr;
            },
            //getTracConfigs has a new boolean called ignoreSecurity - this is ONLY to be used when getting trac configs within the admin
            //if you pass in this boolean during a call during non-admin code, it will break the security config functionality
            getTracConfigs: function(callback, errorCallback, ignoreSecurity) {
                if (app.user && app.user.get("groupNames")) {
                    Context.configService._getTracsAfterGroups(callback, errorCallback, ignoreSecurity);
                } else {
                    //this else should never actually be getting hit, since groups should be pulled in for every user by default
                    //this is here for proper error checking and if a client ever wants to not load a user's groups by default
                    var that = this;
                    that.callback = callback;
                    that.errorCallback = errorCallback;
                    that.ignoreSecurity = ignoreSecurity;
                    app.user.getGroups().done(function() {
                        Context.configService._getTracsAfterGroups(that.callback, that.errorCallback, that.ignoreSecurity);
                    });
                }
            },
            _getTracsAfterGroups: function(callback, errorCallback, ignoreSecurity) {
                var tracs = new TracConfig.Collection([], {
                    type: 'TracConfig'
                });
                if (ignoreSecurity) {
                    if (!app.context.tracConfigs) {
                        tracs.full = true;
                        return tracs.fetch({
                            success: callback
                        });
                    } else {
                        app.context.tracConfigs.models = app.context.tracConfigs.sortBy('ordinal');
                        callback(app.context.tracConfigs);
                        return $.Deferred().resolve(app.context.tracConfigs);
                    }
                } else {
                    if (!app.context.tracConfigs) {
                        tracs.full = true;
                        return tracs.fetch({
                            success: function(tracConfig) {
                                Context.configService.getSecurityConfig(function(securityConfig) {
                                        var disallowedTracs = [];
                                        securityConfig.get("securedTracs").each(function(securedTrac) {
                                            if (_.isEmpty(_.intersection(securedTrac.get("allowedGroups"), app.user.get("groupNames")))) {
                                                disallowedTracs.push(securedTrac.get("tracName"));
                                            }
                                        });
                                        var disallowedTracModels = tracConfig.filter(function(config) {
                                            return _.contains(disallowedTracs, config.get("name"));
                                        });
                                        tracConfig.remove(disallowedTracModels);
                                        app.context.tracConfigs = tracConfig;
                                        callback(tracConfig);
                                    },
                                    //Callback for error, directing user to the Security Config in the admin so
                                    //that HPI is still usable if the config doesn't exist.
                                    function() {
                                        app.log.warn(window.localize("app.context.errorRetrievingSecurity"));
                                        Backbone.history.navigate("/admin/SecurityConfig", {
                                            trigger: true
                                        });
                                    });
                            }
                        });
                    } else {
                        app.context.tracConfigs.models = app.context.tracConfigs.sortBy('ordinal');
                        callback(app.context.tracConfigs);
                        return $.Deferred().resolve(app.context.tracConfigs);
                    }
                }
            },
            getSecurityConfig: function(callback, errorCallback) {
                var securityConfig = _findOrCreateConfig(SecurityConfig.Model, adminOTCName);
                Context.currentSecurityConfig(securityConfig);
                if (securityConfig.isNew()) {
                    return securityConfig.fetch({
                        success: function(newConfig) {
                            Context.currentSecurityConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(securityConfig);
                    return $.Deferred().resolve(securityConfig);
                }
            },
            getWizardConfig: function(callback, errorCallback) {
                var wizardConfig = _findOrCreateConfig(WizardConfig.Model, adminOTCName);
                Context.currentWizardConfig(wizardConfig);
                if (wizardConfig.isNew()) {
                    return wizardConfig.fetch({
                        success: function(newConfig) {
                            Context.currentWizardConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(wizardConfig);
                    return $.Deferred().resolve(wizardConfig);
                }
            },
            getLoggingConfig: function(callback, errorCallback) {
                var loggingConfig = _findOrCreateConfig(LoggingConfig.Model, adminOTCName);
                Context.currentLoggingConfig(loggingConfig);
                if (loggingConfig.isNew()) {
                    return loggingConfig.fetch({
                        success: function(newConfig) {
                            Context.currentLoggingConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (_.isFunction(errorCallback)) {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(loggingConfig);
                    return $.Deferred().resolve(loggingConfig);
                }
            },
            getDashboardConfig: function(callback, errorCallback) {
                var dashboardConfig = _findOrCreateConfig(DashboardConfig.Model, adminOTCName);
                Context.currentDashboardConfig(dashboardConfig);
                if (dashboardConfig.isNew()) {
                    return dashboardConfig.fetch({
                        success: function(newConfig) {
                            Context.currentDashboardConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(dashboardConfig);
                    return $.Deferred().resolve(dashboardConfig);
                }
            },
            getApplicationConfig: function(callback) {
                var appConfig = _findOrCreateConfig(ApplicationConfig.Model, adminOTCName);
                Context.currentApplicationConfig(appConfig);
                if (appConfig.isNew()) {
                    return appConfig.fetch({
                        success: function(newConfig) {
                            Context.currentApplicationConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function() {
                            Backbone.history.navigate("/noConfigError", {
                                trigger: true
                            }, {
                                replace: true
                            });
                        }
                    });
                } else {
                    callback(appConfig);
                    return $.Deferred().resolve(appConfig);
                }
            },
            getAdHocFormConfigs: function(callback, errorCallback) {
                var adHocFormConfig = _findOrCreateConfig(SingleAdHocForm.Model, adminOTCName);
                Context.currentAdHocFormConfig(adHocFormConfig);
                if (adHocFormConfig.isNew()) {
                    return adHocFormConfig.fetch({
                        success: function(newConfig) {
                            Context.currentAdHocFormConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(adHocFormConfig);
                    return $.Deferred().resolve(adHocFormConfig);
                }
            },
            getWorkflowConfigs: function(callback, errorCallback) {
                var workflowConfig = _findOrCreateConfig(WorkflowConfig.Model, adminOTCName);
                Context.currentWorkflowConfig(workflowConfig);
                if (workflowConfig.isNew()) {
                    return workflowConfig.fetch({
                        success: function(newConfig) {
                            Context.currentWorkflowConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(workflowConfig);
                    return $.Deferred().resolve(workflowConfig);
                }
            },
            getUserPreferences: function(callback) {
                if (!app.context.currentUserPreferences()) {
                    //lets only fetch a new userPref if we don't have one
                    var userPreferences = UserPreferences.getUserPreferences({
                        name: app.user.get("loginName")
                    });
                    return userPreferences.fetch({
                        success: function(newUserPreferences) {
                            Context.currentUserPreferences(newUserPreferences);
                            if (callback) {
                                callback(newUserPreferences);
                            }
                        },
                        error: function() {
                            var newUserPreferences = UserPreferences.getUserPreferences();
                            newUserPreferences.set("name", app.user.get("loginName"));
                            Context.currentUserPreferences(newUserPreferences);
                            newUserPreferences.save();
                            if (callback) {
                                callback(newUserPreferences);
                            }
                        }
                    });
                } else {
                    callback(app.context.currentUserPreferences());
                    return $.Deferred().resolve(app.context.currentUserPreferences());
                }
            },
            getPublicPreferences: function(callback) {
                if (!app.context.currentPublicPreferences()) {
                    var publicPrefs = new PublicPreferences.Collection();
                    publicPrefs.fetch().done(function() {
                        Context.currentPublicPreferences(publicPrefs);
                        if (callback) {
                            callback(publicPrefs);
                        }
                    });
                } else {
                    if (callback) {
                        callback(app.context.currentPublicPreferences());
                    }
                    return $.Deferred().resolve(app.context.currentPublicPreferences());
                }
            },
            getCollectionConfig: function(callback, errorCallback) {
                var collectionConfig = _findOrCreateConfig(CollectionConfig.Model, adminOTCName);
                Context.currentCollectionConfig(collectionConfig);
                if (collectionConfig.isNew()) {
                    return collectionConfig.fetch({
                        success: function(newConfig) {
                            Context.currentCollectionConfig(newConfig);
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(collectionConfig);
                    return $.Deferred().resolve(collectionConfig);
                }
            },
            getIndexerConfigNames: function(callback) {
                var deferred = $.Deferred();
                new IndexerConfig.Collection().fetch({
                    success: function(models) {
                        //don't keep a record of this call in the store
                        models.each(function(model) {
                            Backbone.Relational.store.unregister(model);
                        });
                        var sortedNames = models.pluck("name");
                        sortedNames.sort();
                        callback(sortedNames);
                        deferred.resolve(sortedNames);
                    }
                });
                return deferred;
            },
            getIndexerConfigByName: function(configName, callback, errorCallback) {
                var indexerConfig = Context.findOrCreateConfig(IndexerConfig.Model, configName);
                Context.currentIndexerConfig(indexerConfig);
                if (indexerConfig.isNew()) {
                    return indexerConfig.fetch({
                        success: function(indexerConfigModel) {
                            Context.currentIndexerConfig(indexerConfigModel);
                            callback(indexerConfigModel);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(indexerConfig);
                    return $.Deferred().resolve(indexerConfig);
                }
            },
            getAdminNMAC: function(callback, errorCallback) {
                var nmaConfig = _findOrCreateConfig(NMAC.Model, adminOTCName);
                Context.currentAdminNMAC(nmaConfig);
                if (nmaConfig.isNew()) {
                    return nmaConfig.fetch({
                        success: function(nmacModel) {
                            Context.currentAdminNMAC(nmacModel);
                            callback(nmacModel);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(nmaConfig);
                    return $.Deferred().resolve(nmaConfig);
                }
            },
            getAdminNMACAspect: function(aspect, callback, errorCallback) {
                if (!aspect) {
                    callback(undefined);
                    return $.Deferred().resolve(undefined);
                }
                var nmaConfig = _findOrCreateConfig(NMAC.Model, adminOTCName);
                var aspectConfig = nmaConfig.get("configs").findWhere({
                    ocName: aspect
                });
                Context.currentAdminNMAC(nmaConfig);
                if (nmaConfig.isNew() || !aspectConfig) {
                    return nmaConfig.fetch({
                        success: function(nmacAspect) {
                            Context.currentAdminNMAC(nmacAspect);
                            callback(nmacAspect.get("configs").findWhere({
                                ocName: aspect
                            }));
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(aspectConfig);
                    return $.Deferred().resolve(aspectConfig);
                }
            },
            //this gets the OTC which controls the admin, right now called 'default'
            getAdminOTC: function(callback, errorCallback, context) {
                var otConfig = _findOrCreateConfig(OTC.Model, adminOTCName);
                Context.currentAdminOTC(otConfig);
                if (otConfig.isNew()) {
                    return otConfig.fetch({
                        success: function(otcModel) {
                            //We need the NMAC
                            Context.configService.getAdminNMAC(function() {
                                //We cycle through each model and add its aspect attributes to the otc attributes                        
                                _.each(otcModel.get("configs").models, function(type) {
                                    if (type.get('nonMandatoryAspects').length < 1) {
                                        //This is "continue" in _.each
                                        return;
                                    } else {
                                        _.each(type.get('nonMandatoryAspects'), function(configuredAspect) {
                                            Context.configService.getAdminNMACAspect(configuredAspect, function(aspectModel) {
                                                if (aspectModel) {
                                                    _.each(aspectModel.get("attrs").models, function(attribute) {
                                                        attribute.set("parentAspect", configuredAspect);
                                                        type.get("attrs").add(attribute);
                                                    });
                                                    type.get("attrs").models = _.uniq(type.get("attrs").models, false, function(aspectAttribute) {
                                                        return aspectAttribute.get("label");
                                                    });
                                                }
                                            });
                                        });
                                    }
                                });
                                Context.currentAdminOTC(otcModel);
                                callback.call(context, otcModel);
                            });
                        },
                        error: function() {
                            // if (typeof errorCallback === "function") {
                            //      errorCallback(textStatus);
                            // }
                            Backbone.history.navigate("/noConfigError", {
                                trigger: true
                            }, {
                                replace: true
                            });
                        }
                    });
                } else {
                    callback.call(context, otConfig);
                    return $.Deferred().resolve(otConfig);
                }
            },
            getAdminTypeConfig: function(objectType, callback, errorCallback, context) {
                //sometimes, this gets called with a blank objectType, which then forces a total refetch
                //which will never resolve correctly to a new currentTpyeConfig - we should short circuit
                //this use case
                if (!objectType) {
                    callback.call(context, undefined);
                    return $.Deferred().resolve(undefined);
                }

                var otConfig = _findOrCreateConfig(OTC.Model, adminOTCName);
                var typeConfig = otConfig.get("configs").findWhere({
                    ocName: objectType
                });
                Context.currentAdminOTC(otConfig);
                
                if (otConfig.isNew() && !typeConfig) {
                    return otConfig.fetch({
                        success: function(otcModel) {
                                //We need the NMAC
                                Context.configService.getAdminNMAC(function() {
                                    //We cycle through each model and add its aspect attributes to the otc attributes                        
                                    _.each(otcModel.get("configs").models, function(type) {
                                        if (type.get('nonMandatoryAspects').length < 1) {
                                            //This is "continue" in _.each
                                            return;
                                        } else {
                                            _.each(type.get('nonMandatoryAspects'), function(configuredAspect) {
                                                Context.configService.getAdminNMACAspect(configuredAspect, function(aspectModel) {
                                                    if (aspectModel) {
                                                        _.each(aspectModel.get("attrs").models, function(attribute) {
                                                            attribute.set("parentAspect", configuredAspect);
                                                            type.get("attrs").add(attribute);
                                                        });
                                                        type.get("attrs").models = _.uniq(type.get("attrs").models, false, function(aspectAttribute) {
                                                            return aspectAttribute.get("label");
                                                        });
                                                    }
                                                });
                                            });
                                        }
                                    });
                                    Context.currentAdminOTC(otcModel);
                                    var newTypeConfig = otcModel.get("configs").findWhere({
                                        ocName: objectType
                                    });
                                    if (!newTypeConfig) {
                                        app.log.warn(window.localize("app.context.noTypeConfigured") + objectType);
                                    }
                                    callback.call(context, newTypeConfig);
                                });
                            }
                            //don't use error callback - everyone expects this to fail silently
                    });
                } else {
                    callback.call(context, typeConfig);
                    return $.Deferred().resolve(typeConfig);
                }
            },
            getAdHocFormConfig: function(formName, callback, errorCallback) {
                var formConfig = _findOrCreateConfig(SingleAdHocForm.Model, formName);
                if (formConfig.isNew()) {
                    return formConfig.fetch({
                        success: function(newConfig) {
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(formConfig);
                    return $.Deferred().resolve(formConfig);
                }
            },
            //Return an array of saved formconfig names
            //Returns an array of configs if fullConfigs is true
            getAdHocFormConfigNames: function(callback) {
                var deferred = $.Deferred();
                new SingleAdHocForm.Collection().fetch({
                    success: function(models) {
                        //don't keep a record of this call in the store
                        models.each(function(model) {
                            Backbone.Relational.store.unregister(model);
                        });
                        var sortedNames = models.pluck("name");
                        sortedNames.sort();
                        callback(sortedNames);
                        deferred.resolve(sortedNames);
                    }
                });
                return deferred;
            },
            getCustomAttributes: function(callback, errorCallback) {
                var customAttrs = _findOrCreateConfig(SingleAdHocForm.CustomAttrsModel, adminOTCName);
                if (customAttrs.isNew()) {
                    return customAttrs.fetch({
                        success: function(newConfig) {
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                            customAttrs.save({}, {
                                success: function() {
                                    app.log.debug(window.localize("app.context.newCustomAttribute"));
                                    Backbone.history.loadUrl();
                                },
                                error: function(model, response) {
                                    app.trigger("alert:error", {
                                        message: window.localize("app.context.couldNotCreate") + response.responseText
                                    });
                                }
                            });
                        }
                    });
                } else {
                    callback(customAttrs);
                    return $.Deferred().resolve(customAttrs);
                }
            },
            //Return an array of saved workflowformconfig names
            //Returns an array of configs if fullConfigs is true
            getFormConfigNames: function(callback) {
                var deferred = $.Deferred();
                new FormConfig.Collection().fetch({
                    success: function(models) {
                        //don't keep a record of this call in the store
                        models.each(function(model) {
                            Backbone.Relational.store.unregister(model);
                        });
                        var sortedNames = models.pluck("name");
                        sortedNames.sort();
                        callback(sortedNames);
                        deferred.resolve(sortedNames);
                    }
                });
                return deferred;
            },
            getFormConfig: function(formName, callback, errorCallback) {
                var formConfig = _findOrCreateConfig(FormConfig.Model, formName);
                if (formConfig.isNew()) {
                    return formConfig.fetch({
                        success: function(newConfig) {
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(formConfig);
                    return $.Deferred().resolve(formConfig);
                }
            },
            getTemplateManagementConfigNames: function(callback) {
                var deferred = $.Deferred();
                new TemplateManagementConfig.Collection().fetch({
                    success: function(models) {
                        //don't keep a record of this call in the store
                        models.each(function(model) {
                            Backbone.Relational.store.unregister(model);
                        });
                        var sortedNames = models.pluck("name");
                        sortedNames.sort();
                        callback(sortedNames);
                        deferred.resolve(sortedNames);
                    }
                });
                return deferred;
            },
            getTemplateManagementConfig: function(templateName, callback, errorCallback) {
                var templateManagementConfig = _findOrCreateConfig(TemplateManagementConfig.Model, templateName);
                if (templateManagementConfig.isNew()) {
                    return templateManagementConfig.fetch({
                        success: function(newConfig) {
                            callback(newConfig);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(templateManagementConfig);
                    return $.Deferred().resolve(templateManagementConfig);
                }
            },
            getFormTypeConfig: function(formName, objectType, callback, errorCallback) {
                var formConfig = _findOrCreateConfig(FormConfig.Model, formName);
                var combineWithOverride = function(config, objectType) {
                    //Original Type
                    var originalTypeConfig = config.get("configuredTypes").findWhere({
                        ocName: objectType
                    });

                    if (config.get("configuredTypes").findWhere({
                            ocName: objectType
                        }) &&
                        config.get("configuredTypes").findWhere({
                            ocName: objectType
                        }).get('overrideType')) {
                        var origAttrsOcNames = _.union(originalTypeConfig.get('configuredAttrsPri').pluck('ocName'), originalTypeConfig.get('configuredAttrsSec').pluck("ocName"));

                        //Override Type
                        var overrideTypeConfig = config.get("configuredTypes").findWhere({
                            ocName: config.get("configuredTypes").findWhere({
                                ocName: objectType
                            }).get('overrideType')
                        });
                        var attrsToAddOcNames = _.union(overrideTypeConfig.get('configuredAttrsPri').pluck("ocName"), overrideTypeConfig.get('configuredAttrsSec').pluck("ocName"));

                        //These are the ocNames that are on the "override" but not the "original"..  We will need to add them to the original types collection.
                        var ocNameToAddToOrig = _.difference(_.union(origAttrsOcNames, attrsToAddOcNames), origAttrsOcNames);

                        app.log.debug("There is an override for this form and there are differences of: " + ocNameToAddToOrig);

                        //If it's in the primary attributes of the override, put it in the primary attributes for the  original type. Same for secondary attrs.
                        _.each(ocNameToAddToOrig, function(attrToAdd) {
                            if (overrideTypeConfig.get('configuredAttrsPri').findWhere({
                                    'ocName': attrToAdd
                                })) {
                                originalTypeConfig.get('configuredAttrsPri').add(overrideTypeConfig.get('configuredAttrsPri').findWhere({
                                    'ocName': attrToAdd
                                }), {
                                    at: 0
                                });
                            } else {
                                originalTypeConfig.get('configuredAttrsSec').add(overrideTypeConfig.get('configuredAttrsSec').findWhere({
                                    'ocName': attrToAdd
                                }), {
                                    at: 0
                                });
                            }
                        });
                    }

                    return originalTypeConfig;
                };
                if (formConfig.isNew()) {
                    return formConfig.fetch({
                        success: function(newConfig) {
                            var processedForm = combineWithOverride(newConfig, objectType);
                            callback(processedForm);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    var processedForm = combineWithOverride(formConfig, objectType);
                    callback(processedForm);
                    return $.Deferred().resolve(formConfig);
                }
            },
            getFormTypesAndAttrs: function(formName, callback) {
                var typesAndAttrs = [];
                Context.configService.getFormConfig(formName, function(formConfig) {
                    formConfig.get("configuredTypes").each(function(type) {
                        var typeAndAttrs = {
                            "type": type.get("ocName"),
                            "ordinal": type.get("ordinal")
                        };
                        var repoType = new Repotype.Model({
                            ocName: type.get("ocName")
                        });
                        repoType.fetch({
                            success: function(repoType) {
                                var allAttrs = _.pluck(repoType.get("allProperties"), "ocName");
                                typeAndAttrs.attrs = allAttrs;
                                typesAndAttrs.push(typeAndAttrs);
                                if (typesAndAttrs.length === formConfig.get("configuredTypes").length) {
                                    // sort by ordinal here
                                    typesAndAttrs = _.sortBy(typesAndAttrs, function(object) {
                                        return object.ordinal;
                                    });
                                    callback(typesAndAttrs);
                                }
                            }
                        });
                    });
                });
            },
            getTypeAttrs: function(typeName, callback) {
                var attrs = [];
                var repoType = new Repotype.Model({
                    ocName: typeName
                });
                repoType.fetch({
                    success: function(repoType) {
                        attrs = repoType.get("allProperties");
                        attrs.sort();
                        callback(attrs);
                    }
                });
            },
            getPrettyTypeAttrs: function(typeName, callback) {
                var attrs = [];
                var repoType = new Repotype.Model({
                    ocName: typeName
                });
                repoType.fetch({
                    success: function(repoType) {
                        app.attrMap = [];
                        _.each(repoType.attributes.allProperties, function(attr) {
                            app.attrMap.push({
                                "value": attr.ocName,
                                "text": attr.label
                            });
                        });
                        attrs = _.pluck(repoType.get("allProperties"), "label");
                        attrs.sort();
                        callback(attrs);
                    }
                });
            },
            //Return an array of saved SearchConfig names
            //Returns an array of configs if fullConfigs is true
            getSearchConfigNames: function(callback) {
                var deferred = $.Deferred();
                new SearchConfig.Collection().fetch({
                    success: function(models) {
                        //don't keep a record of this call in the store
                        models.each(function(model) {
                            Backbone.Relational.store.unregister(model);
                        });
                        var sortedNames = models.pluck("name");
                        sortedNames.sort();
                        callback(sortedNames);
                        deferred.resolve(sortedNames);
                    }
                });
                return deferred;
            },
            getSearchConfigForTrac: function(tracName, callback) {
                Context.searchConfig = _findOrCreateConfig(SearchConfig.Model, tracName);
                Context.searchConfig.fetch({
                    success: function(searchConfigModel) {
                        callback(searchConfigModel);
                    }
                });
            },
            getSearchConfigByName: function(configName, callback, errorCallback) {
                var searchConfig = _findOrCreateConfig(SearchConfig.Model, configName);
                Context.currentSearchConfig(searchConfig);
                if (searchConfig.isNew()) {
                    return searchConfig.fetch({
                        success: function(searchConfigModel) {
                            Context.currentSearchConfig(searchConfigModel);
                            callback(searchConfigModel);
                        },
                        error: function(jqXHR, textStatus) {
                            if (typeof errorCallback === "function") {
                                errorCallback(textStatus);
                            }
                        }
                    });
                } else {
                    callback(searchConfig);
                    return $.Deferred().resolve(searchConfig);
                }
            },
            getStageConfigByName: function(configName, callback, errorCallback, context) {
                var stageConfig = Context.findOrCreateConfig(StageConfig.Model, configName);
                Context.currentStageConfig(stageConfig);
                if (stageConfig.isNew()) {
                    return stageConfig.fetch({
                            global: false,
                            async: false,
                            success: callback,
                            error: errorCallback,
                            // if context is undefined, jquery will set it to window
                            // this assumes that the callback functions use a boosted scope variable (e.g. self, that)
                            context: context
                        }).promise();
                } else {
                    if (callback) {
                        if (context) {
                        callback.call(context, stageConfig);
                        } else {
                            callback(stageConfig);
                        }
                    }
                    // if context is null, jquery resolves with window
                    return $.Deferred().resolveWith(context, [stageConfig]);
                }
            },
            //new service that handles labels with a deffered, fetches a type label if ocNames is not provided
            //if an array of ocNames are provided, returns an array of ocName/label pairs
            //if unable to find a label, returns the ocName/type and logs error
            //OTC should have all types configured for no errors
            getLabels: function(type, ocNames) {
                var deferred = $.Deferred();
                var labels;

                Context.configService.getAdminTypeConfig(type, function(newTypeConfig) {
                    labels = Context.configService._findLabels(newTypeConfig, ocNames);
                    deferred.resolve(labels);
                });

                return deferred;
            },
            _findLabels: function(typeConfig, ocNames) {
                var results, attr;

                //bail out of no type config was defined
                if (!typeConfig && !ocNames) {
                    return;
                }

                if (!ocNames) {
                    //we just want the type label
                    if (!typeConfig.get("label") || typeConfig.get("label") === "") {
                        app.log.error(window.localize("app.context.configureLabel") + typeConfig.get("ocName") + window.localize("app.context.onTheOTC"));
                        results = typeConfig.get("ocaName");
                    } else {
                        results = typeConfig.get("label");
                    }
                } else {
                    if (_.isArray(ocNames)) {
                        results = [];
                        _.each(ocNames, function(ocName) {
                            attr = typeConfig.get("attrs").findWhere({
                                ocName: ocName
                            });
                            if (!attr || !attr.get("label") || attr.get("label") === "") {
                                app.log.error(window.localize("app.context.configureLabelForAttr") + ocName + window.localize("app.context.onType") + typeConfig.get("ocName"));
                                results.push({
                                    ocName: ocName,
                                    label: ocName
                                });
                            } else {
                                results.push({
                                    ocName: ocName,
                                    label: window.localize(attr.get("label"))
                                });
                            }
                        });
                    } else {
                        if (typeConfig) {
                            attr = typeConfig.get("attrs").findWhere({
                                ocName: ocNames
                            });
                        }
                        if (!attr || !attr.get("label") || attr.get("label") === "") {
                            app.log.debug(window.localize("app.context.configureLabelForAttr") + ocNames + window.localize("app.context.onType"));
                            results = ocNames;
                        } else {
                            results = window.localize(attr.get("label"));
                        }
                    }
                }

                return results;
            },
            isContainer: function(objectType, callback) {
                Context.configService.getAdminTypeConfig(objectType, function(objectTypeConfig) {
                    if (!objectTypeConfig) {
                        app.log.warn(window.localize("app.context.currentConfigDoesNot") + objectType);
                    } else {
                        callback(objectTypeConfig.get("isContainer"));
                    }
                });
            }
        };

        var _extraActionParameters = {};
        Context.actionParamService = {
            setExtraParameter: function(paramValue, paramKey) {
                _extraActionParameters[paramKey] = paramValue;
            },

            getExtraParameters: function() {
                return _extraActionParameters;
            }

        };

        Context._usernameCache = {};
        Context.filterService = {
            getUserDisplayName: function(loginName, callback) {
                if (Context._usernameCache[loginName]) {
                    Context._usernameCache[loginName].done(callback);
                    return Context._usernameCache[loginName];
                } else {
                    Context._usernameCache[loginName] = $.Deferred();
                    Context._usernameCache[loginName].done(callback);
                    // guess we'll have to call the user service for this thing
                   var user = new OC.User({
                        "loginName" : loginName,
                        "failQuietly": true,
                        "includeGroups": false
                    });
                   user.fetch().done(function() {
                            var realName;
                            //let's cache it
                            if (this.get("displayName") === undefined) {
                                realName = loginName;
                            } else {
                                realName = this.get("displayName");
                            }
                            Context._usernameCache[loginName].resolve(realName);
                        });
                }
                return Context._usernameCache[loginName];
            },
            filterValueThroughPicklist: function(valueToFilter, picklistName, callback) {
                //if valueToFilter is a key in the picklist, return the filtered value
                Context.picklistService.getPicklist(picklistName, function(picklist) {
                    var filteredPicklistItems = _.where(picklist, {"label":valueToFilter});

                    if(filteredPicklistItems && filteredPicklistItems.length > 0 && filteredPicklistItems[0].value) {
                        callback(filteredPicklistItems[0].value);
                    } else {
                        callback(valueToFilter);
                    }
                });
            }
        };

        //used to hold cached picklists
        //picklists keyed by picklist label
        var _picklistCache = {};

        //checks the config for the type of picklist and returns the options
        //if oc/webservice this will make the service call and return a map of key/values
        Context.picklistService = {
            getPicklistConfig: function(picklistName) {
                var plConfig = Context.currentPicklistConfig().get("picklists");
                if (!plConfig) {
                    throw window.localize("app.context.noPicklistConfigAvailable");
                }
                return plConfig.findWhere({
                    label: picklistName
                });

            },
            getPicklist: function(picklistName, callback, tokens) {
                var xhr;
                $.when(plJqXhr).done(function() {

                    var picklistConfig = Context.currentPicklistConfig().get("picklists").findWhere({
                        label: picklistName
                    });
                    if (!picklistConfig) {
                        app.log.error(window.localize("app.context.noPicklistConfigFor") + picklistName);
                        return [];
                    } else {
                        //before we make a call to OC, check if our picklist is in our cache
                        if (_picklistCache[picklistName]) {
                            //it does exist!
                            xhr = $.Deferred();
                            xhr.done(function() {
                                callback(_picklistCache[picklistName], picklistConfig.get("defaultItems"), picklistName);
                            });
                            xhr.resolve();
                        } else if (picklistConfig.get("type") === 'simple') {
                            xhr = $.Deferred();
                            xhr.done(function() {
                                callback(picklistConfig.get("options"), picklistConfig.get("defaultItems"), picklistName);
                            });
                            xhr.resolve();
                        } else if (picklistConfig.get("type") === 'opencontent') {
                            if (_.isEmpty(tokens)) {
                                xhr = $.ajax({
                                    url: app.serviceUrlRoot + "/picklists/" + picklistConfig.get("ocName"),
                                    success: function(data) {
                                        //add empty item
                                        data.splice(0, 0, {
                                            label: "",
                                            value: ""
                                        });
                                        callback(data, picklistConfig.get("defaultItems"), picklistName);
                                    },
                                    global: false
                                });
                            } else {
                                var tokenStringArray = [];
                                _.each(tokens, function(value, key){
                                    //url encode all values
                                    tokenStringArray.push(key + ":" + value);
                                });

                                xhr = $.ajax({
                                    type: "POST",
                                    contentType: "application/json",
                                    data: JSON.stringify(tokenStringArray),
                                    url: app.serviceUrlRoot + "/picklists/" + picklistConfig.get("ocName"),
                                    success: function(data){
                                        //add empty item
                                        data.splice(0, 0, {
                                            label: "",
                                            value: ""
                                        });
                                        callback(data, picklistConfig.get("defaultItems"), picklistName);
                                    },
                                    global: false
                                });
                            }
                        } else if (picklistConfig.get("type") === 'datadictionary') { //constraint-based picklist
                            xhr = $.get(app.serviceUrlRoot + "/dictionary/property?property=" + picklistConfig.get("label"), function(data) {
                                //we are assuming for now that the picklist will be labled with the property that the picklist is attached to
                                //there might be multiple contraints on this... for now, just get the one of type LIST
                                _.each(data.constraints, function(constraint) {
                                    if (constraint.type === 'LIST') {
                                        // got the one we want
                                        var pickList = [];
                                        pickList.push({
                                            label: "",
                                            value: ""
                                        }); // we want to leave them a blank value
                                        _.each(constraint.parameters.allowedValues, function(allowedValue) {
                                            pickList.push({
                                                label: allowedValue,
                                                value: allowedValue
                                            });
                                        });
                                        callback(pickList);
                                    }
                                });
                            });
                        } else if (picklistConfig.get("type") === 'webservice') {
                            xhr = $.get(app.serviceUrlRoot + picklistConfig.get("webserviceURL"), function(data) {
                                // as with datadictionary, would like to force in a blank value
                                var pickList = [];
                                pickList.push({
                                    label: "",
                                    value: ""
                                });
                                _.each(data, function(pickItem) {
                                    pickList.push({
                                        label: pickItem.label,
                                        value: pickItem.value
                                    });
                                });
                                callback(pickList);
                            });
                        }
                    }
                });
                return xhr;
            }
        };

        Context.dateService = {
            //For future, use HPI Constants so we know what string format correlates to which date format. getSimpleDateFormatterFormat for example

            getJQueryDateFormat: function(momentFormat) {
                var dateMap = {
                    "YYYY-DD-MM": "yy-dd-mm",
                    "MM-DD-YY": "mm-dd-y",
                    "MM-DD-YYYY": "mm-dd-yy",
                    "MM-DD-YY z": "mm-dd-y",
                    "MM-DD-YYYY z": "mm-dd-yy",
                    "DD-MMM-YYYY": "dd-M-yy",
                    "YYYY-MM-DD": "yy-mm-dd",
                    "dddd, MMMM DD, YYYY": "DD, MM dd, yy"
                };

                return dateMap[momentFormat] ? dateMap[momentFormat] : momentFormat;

            },
            getMomentDateFormat: function(jqueryFormat) {
                var dateMap = {};

                dateMap[HPIConstants.Date.jQuery.ISO] = HPIConstants.Date.moment.ISO;
                dateMap[HPIConstants.Date.jQuery.Short] = HPIConstants.Date.moment.Short;
                dateMap[HPIConstants.Date.jQuery.Long] = HPIConstants.Date.moment.Long;
                dateMap[HPIConstants.Date.jQuery.ShortTZ] = HPIConstants.Date.moment.ShortTZ;
                dateMap[HPIConstants.Date.jQuery.LongTZ] = HPIConstants.Date.moment.LongTZ;
                dateMap[HPIConstants.Date.jQuery.Euro] = HPIConstants.Date.moment.Euro;
                dateMap[HPIConstants.Date.jQuery.YearFirst] = HPIConstants.Date.moment.YearFirst;
                dateMap[HPIConstants.Date.jQuery.USA] = HPIConstants.Date.moment.USA;

                return dateMap[jqueryFormat] ? dateMap[jqueryFormat] : jqueryFormat;
            },
            getJQueryTimeFormat: function(momentFormat) {
                var timeMap = {
                    "h:mm a": "h:mm tt",
                    "h:mm A": "h:mm TT",
                    "hh:mm a": "hh:mm tt",
                    "hh:mm A": "hh:mm TT",
                    "hh:mm a z": "hh:mm tt",
                    "hh:mm A z": "hh:mm TT"
                };

                return timeMap[momentFormat];
            },
            getSimpleDateFormatterFormat: function(jqueryFormat) {
                var dateMap = {};

                dateMap[HPIConstants.Date.jQuery.ISO] = HPIConstants.Date.simpleDate.ISO;
                dateMap[HPIConstants.Date.jQuery.Short] = HPIConstants.Date.simpleDate.Short;
                dateMap[HPIConstants.Date.jQuery.Long] = HPIConstants.Date.simpleDate.Long;
                dateMap[HPIConstants.Date.jQuery.ShortTZ] = HPIConstants.Date.simpleDate.ShortTZ;
                dateMap[HPIConstants.Date.jQuery.LongTZ] = HPIConstants.Date.simpleDate.LongTZ;
                dateMap[HPIConstants.Date.jQuery.Euro] = HPIConstants.Date.simpleDate.Euro;
                dateMap[HPIConstants.Date.jQuery.YearFirst] = HPIConstants.Date.simpleDate.YearFirst;
                dateMap[HPIConstants.Date.jQuery.USA] = HPIConstants.Date.simpleDate.USA;

                return dateMap[jqueryFormat] ? dateMap[jqueryFormat] : jqueryFormat;

                //this format is used to pass to OpenContent so that the date prints in the correct format on wizard forms
            },
            //formats a date (or array of dates) using the format in the the application config
            getFormattedDate: function(dates) {
                var deferred = $.Deferred();
                if (null === dates || undefined === dates) {
                    deferred.resolve("");
                    return deferred;
                }
                var appConfig = Context.currentApplicationConfig();
                var formattedDates;

                if (!appConfig) {
                    Context.configService.getApplicationConfig(function(config) {
                        formattedDates = Context.dateService._formatDate(dates, config.get("dateFormat"), config.get("timezoneFormat"));
                        deferred.resolve(formattedDates);
                    });
                } else {
                    formattedDates = Context.dateService._formatDate(dates, appConfig.get("dateFormat"), appConfig.get("timezoneFormat"));
                    deferred.resolve(formattedDates);
                }

                return deferred;
            },
            _formatDate: function(dates, dateFormat, timezoneFormat) {
                var self = this;
                if (_.isArray(dates)) {
                    var returnArray = [];
                    _.each(dates, function(dateToFormat) {
                        if (null !== dateToFormat || undefined !== dateToFormat) {
                            // Hold a moment object of this date to check it's validity before returning anything.
                            var validDateCheck = self._momentizeDate(dateToFormat, dateFormat);

                            if (!timezoneFormat) {
                                returnArray.push(validDateCheck.isValid() ? validDateCheck.format(dateFormat) : '');
                            } else {
                                returnArray.push(validDateCheck.isValid() ? validDateCheck.tz(timezoneFormat).format(dateFormat) : '');
                            }
                        }
                    });
                    return returnArray;
                }
                // Hold a moment object of this date to check it's validity before returning anything.
                var validDateCheck = this._momentizeDate(dates, dateFormat);

                //dates is just a date
                if (!timezoneFormat) {
                    return validDateCheck.isValid() ? validDateCheck.format(dateFormat) : '';
                } else {
                    return validDateCheck.isValid() ? validDateCheck.tz(timezoneFormat).format(dateFormat) : '';
                }
            },
            _formatTime: function(dates, timeFormat, timezoneFormat) {
                if (_.isArray(dates)) {
                    var returnArray = [];
                    _.each(dates, function(dateToFormat) {
                        if (null !== dateToFormat || undefined !== timeFormat) {
                            if (!timezoneFormat) {
                                returnArray.push(moment(dateToFormat).format(timeFormat));
                            } else {
                                returnArray.push(moment(dateToFormat).tz(timezoneFormat).format(timeFormat));
                            }
                        }
                    });

                    return returnArray;
                } else {
                    if (!timezoneFormat) {
                        return moment(dates).format(timeFormat);
                    } else {
                        return moment(dates).tz(timezoneFormat).format(timeFormat);
                    }
                }
            },
            _formatDatetime: function(dates, dateFormat, timeFormat, timezoneFormat) {
                var self = this;
                //Makes sure that there aren't two time zones shown in a date/time formatting if it is already going to be shown by the 'time'.
                if (dateFormat.indexOf('z') > -1 && timeFormat.indexOf('z') > -1) {
                    dateFormat = dateFormat.replace(' z', '');
                }
                if (_.isArray(dates)) {
                    var returnArray = [];
                    _.each(dates, function(dateToFormat) {
                        if (null !== dateToFormat || undefined !== dateFormat) {
                            // Hold a moment object of this date to check it's validity before returning anything.
                            var validDateCheck = self._momentizeDate(dateToFormat, dateFormat + " " + timeFormat);

                            if (!timezoneFormat) {
                                returnArray.push(validDateCheck.isValid() ? validDateCheck.format(dateFormat + " " + timeFormat) : '');
                            } else {
                                returnArray.push(validDateCheck.isValid() ? validDateCheck.tz(timezoneFormat).format(dateFormat + " " + timeFormat) : '');
                            }
                        }
                    });

                    return returnArray;
                } else {
                    // Hold a moment object of this date to check it's validity before returning anything.
                    var validDateCheck = this._momentizeDate(dates, dateFormat + " " + timeFormat);

                    if (!timezoneFormat) {
                        return validDateCheck.isValid() ? validDateCheck.format(dateFormat + " " + timeFormat) : '';
                    } else {
                        return validDateCheck.isValid() ? validDateCheck.tz(timezoneFormat).format(dateFormat + " " + timeFormat) : '';
                    }
                }
            },
            // returns a moment date object
            // will frist try to create a moment object without using the dateFormat which will use the browser's native date object
            // if that fails, we will try to create a moment object with the dateFormat to handle cases when the browser can't handle the format such as Euro format
            _momentizeDate: function(dateToFormat, dateFormat) {
                var momentDate = moment(dateToFormat);
                if (!momentDate.isValid()) {
                    momentDate = moment(dateToFormat, dateFormat);
                }
                return momentDate;
            },
            getFormattedDatetime: function(dates) {

                var dateFormat, timeFormat, timezoneFormat;
                var deferred = $.Deferred();
                if (null === dates || undefined === dates) {
                    deferred.resolve("");
                } else {
                    //get the application config if we don't have it already
                    if (!Context.currentApplicationConfig()) {
                        Context.configService.getApplicationConfig(function(config) {
                            deferred.resolve(Context.dateService._formatDatetime(dates, config.get("dateFormat"), config.get("timeFormat"), config.get("timezoneFormat")));
                        });
                    } else {
                        dateFormat = Context.currentApplicationConfig().get("dateFormat");
                        timeFormat = Context.currentApplicationConfig().get("timeFormat");
                        timezoneFormat = Context.currentApplicationConfig().get("timezoneFormat");
                        deferred.resolve(Context.dateService._formatDatetime(dates, dateFormat, timeFormat, timezoneFormat));
                    }
                }

                return deferred;
            },
            getDateFormat: function() {
                var deferred = $.Deferred();
                if (Context.currentApplicationConfig()) {
                    deferred.resolve(Context.currentApplicationConfig().get("dateFormat"));
                } else {
                    Context.configService.getApplicationConfig(function() {
                        deferred.resolve(Context.currentApplicationConfig().get("dateFormat"));
                    });
                }
                return deferred;
            },
            getDatetimeTimezoneFormat: function() {
                var deferred = $.Deferred();
                if (Context.currentApplicationConfig()) {
                    var formats = {
                        dateFormat: Context.currentApplicationConfig().get("dateFormat"),
                        timeFormat: Context.currentApplicationConfig().get("timeFormat"),
                        timezoneFormat: Context.currentApplicationConfig().get("timezoneFormat")
                    };
                    deferred.resolve(formats);
                } else {
                    Context.configService.getApplicationConfig(function(config) {
                        var formats = {
                            dateFormat: config.get("dateFormat"),
                            timeFormat: config.get("timeFormat"),
                            timezoneFormat: config.get("timezoneFormat")
                        };
                        deferred.resolve(formats);
                    });
                }
                return deferred;
            },
            //formats a time (or array of dates) using the format in the the application config
            getFormattedTime: function(dates) {
                var deferred = $.Deferred();
                if (null === dates || undefined === dates) {
                    deferred.resolve("");
                    return deferred;
                }
                var appConfig = Context.currentApplicationConfig();
                var formattedDates;

                if (!appConfig) {
                    Context.configService.getApplicationConfig(function(config) {
                        formattedDates = Context.dateService._formatTime(dates, config.get("timeFormat"), config.get("timezoneFormat"));
                        deferred.resolve(formattedDates);
                    });
                } else {
                    formattedDates = Context.dateService._formatTime(dates, appConfig.get("timeFormat"), appConfig.get("timezoneFormat"));
                    deferred.resolve(formattedDates);
                }

                return deferred;
            },
            convertDateToIso: function(formattedDate, includeTimeFormat) {
                var isoDateVar, trueOffset;
                var dateFormat = Context.currentApplicationConfig().get("dateFormat");
                var timeFormat = Context.currentApplicationConfig().get("timeFormat");
                var timezoneFormat = Context.currentApplicationConfig().get("timezoneFormat");
                if (!includeTimeFormat) {
                    if (!timezoneFormat) {
                        isoDateVar = moment(formattedDate, dateFormat, true);
                        if (isoDateVar.isValid()) {
                            isoDateVar = moment(formattedDate, dateFormat, true).toDate().getTime();
                        } else {
                            isoDateVar = undefined;
                        }
                    } else {
                        trueOffset = moment(formattedDate, dateFormat, true).utcOffset() - moment(formattedDate, dateFormat).tz(timezoneFormat).utcOffset();
                        isoDateVar = moment(formattedDate, dateFormat, true);
                        if (isoDateVar.isValid()) {
                            isoDateVar = moment(formattedDate, dateFormat, true).utcOffset(trueOffset)._d.getTime();
                        } else {
                            isoDateVar = undefined;
                        }
                    }
                } else {
                    if (!timezoneFormat) {
                        isoDateVar = moment(formattedDate, dateFormat + " " + timeFormat, true);
                        if (isoDateVar.isValid()) {
                            isoDateVar = moment(formattedDate, dateFormat + " " + timeFormat, true).toDate().getTime();
                        } else {
                            isoDateVar = undefined;
                        }

                    } else {
                        trueOffset = moment(formattedDate, dateFormat + " " + timeFormat, true).utcOffset() - moment(formattedDate, dateFormat + " " + timeFormat, true).tz(timezoneFormat).utcOffset();
                        isoDateVar = moment(formattedDate, dateFormat + " " + timeFormat, true);
                        if (isoDateVar.isValid()) {
                            isoDateVar = moment(formattedDate, dateFormat + " " + timeFormat, true).utcOffset(trueOffset)._d.getTime();
                        } else {
                            isoDateVar = undefined;
                        }
                    }
                }
                return isoDateVar;
            }
        };

        Context.util = {
            /*
             * Typically in backbone you would re-render a view based on some event, say a model changing.
             * In our application the entire layout is rendered in the router, and which point all views
             * are typically in place. Sometimes a subview gets added later, In that case, we need to render it.
             * But only if it's not already rendered.
             */
            renderSubViews: function(view) {
                //if there are views and we ahve already rendered then render the subviews
                if (view.hasRendered) {
                    view.getViews().each(function(subView) {
                        if (!subView.hasRendered) {
                            subView.render();
                        }
                    });
                }
            },
            getParents: function(objectId, callback) {
                $.ajax({
                    type: 'GET',
                    url: app.serviceUrlRoot + '/content/getParents',
                    data: {
                        'objectId': objectId
                    },
                    context: this,
                    async: false,
                    success: function(data) {
                        callback(data);
                    }
                });
            },
            getAppliedAspects: function(objectId, callback) {
                $.ajax({
                    type: 'GET',
                    url: app.serviceUrlRoot + '/content/getAppliedAspects',
                    data: {
                        'objectId': objectId
                    },
                    context: this,
                    async: false,
                    success: function(data) {
                        callback(data);
                    }
                });
            },
            loadActionDefinitions: function() {
                var returnDeferred = $.Deferred();
                $.ajax({
                    url: app.serviceUrlRoot + "/action/available",
                    dataType: 'json',
                    success: function(data) {
                        var sortedActionData = [];
                        var sortedActionKeys = _.sortBy(_.keys(data));
                        _.each(sortedActionKeys, function(item) {
                            var actionData = _.extend(data[item], { name : item });
                            actionData.description = window.localize(actionData.description);
                            sortedActionData.push(_.extend(data[item], { name : item }));
                        });
                        returnDeferred.resolve(sortedActionData);
                    },
                    error: function() {
                        returnDeferred.reject(arguments);
                    }
                });
                return returnDeferred;
            },
            loadConditionDefinitions: function() {
                var returnDeferred = $.Deferred();
                $.ajax({
                    url: app.serviceUrlRoot + "/condition/available",
                    dataType: 'json',
                    success: function(data) {
                        var sortedConditionData = [];
                        var sortedConditionKeys = _.sortBy(_.keys(data));
                        _.each(sortedConditionKeys, function(item) {
                            sortedConditionData.push(_.extend({}, { name : item, description : data[item] }));
                        });
                        returnDeferred.resolve(sortedConditionData);
                    },
                    error: function() {
                        returnDeferred.reject(arguments);
                    }
                });
                return returnDeferred;
            },
            // this is a helper function to parse through a pattern and return
            // an array of the attributes that the pattern depends on
            parsePatternForAttributes: function(pattern) {
                var positionHolder = 0;
                var attributeArray = [];

                while (positionHolder < pattern.length) {
                    //starting where we left off (positionHolder), find
                    //the next '$' which denotes another attribute
                    var beginOfToken = pattern.indexOf('$', positionHolder);
                    //now, find the end of the attribute
                    var endOfToken = pattern.indexOf('$', beginOfToken + 1);

                    //if we found an attribute...
                    if (beginOfToken !== -1 && endOfToken !== -1) {
                        //get our attribute using substring method
                        var attribute = pattern.substring(beginOfToken + 1, endOfToken);
                        //add the attribute to the array we are going to return
                        attributeArray.push(attribute);
                        //move the positionHolder to the end of the token and repeat if necessary
                        positionHolder = endOfToken + 1;
                    } else {
                        //if we don't find a token, set positionHolder to the length so we can
                        //exit the while loop
                        positionHolder = pattern.length;
                    }

                }

                return attributeArray;
            },

            parseIEJSON: function(jqXHR) {
                // since we use jQuery 1.8, this function returns null for invalid JSON string instead of throwing an exception
                // this could be null if the jqXHR object is already JSON format or if we're in IE and the actual JSON we want
                // is in the body (only for successfully request, for an error the JSON is in the jqXHR object even in IE)
                //jQuery 1.9.1 throws an error
                var parsedResponse;
                try {
                    parsedResponse = $.parseJSON(jqXHR);
                } catch (e) {
                    parsedResponse = false;
                }
                if (!parsedResponse) {
                    // jqXHR[0] will not be defined if this was an error (even in IE)
                    if (!jqXHR[0]) {
                        // the jqXHR is already JSON
                        return jqXHR;
                    }

                    // IE8 hack. Data is not returned in jqXHR iteself but rather in jqXHR[0].body.innerHTML
                    // innerText is supported in all major browesers (yes, even IE >= 5.5) but NOT in Firefox
                    // Firefox uses textContent
                    var response = jqXHR[0].body.innerText || jqXHR[0].body.textContent;
                    parsedResponse = $.parseJSON(response);
                }

                return parsedResponse;
            },

            // helper function to prepare properties to be sent to OC with the "prop-" prefix that OC expects
            prefixProperties: function(properties) {
                // add prop- to each key as that's the way OC expects the properties
                var prefixedProps = {};
                _.each(properties, function(value, key) {
                    prefixedProps["prop-" + key] = value;
                });

                return prefixedProps;
            },

            //Adds an empty object to the front of the array
            //This object will have all the same keys as the first valid
            //object in the array, but all the values will be empty strings
            prependEmptyEntryToArray: function(array) {
                if(_.isArray(array)) {
                    var emptyEntry = {};

                    //initialize the empty entry with an empty string value
                    //for each key on the first real object in the array
                    _.each(_.keys(array[0]), function(key) {
                        emptyEntry[key] = '';
                    });
                    array.unshift(emptyEntry);
                }
                return array;
            },

            // helper function to construct the "ID part" of the wizard URL to the stage - this function
            // takes care of properly URI encoding the necessary symbols... I'm looking at you "+" and "|"
            getWizardStageUrlIdPart: function(psiId) {
                return psiId + encodeURIComponent("+current|") + psiId + encodeURIComponent("+current");
            }
        };

        Context.cookieService = {
            getUserPreferences: function(key) {
                if (app.user && app.user.get("loginName")) {
                    var userPrefCookieName = app.user.get("loginName") + "-" + key + "-userPreferences";
                    var unparsedCookie = $.cookie(userPrefCookieName);
                    if (!unparsedCookie) {
                        return {};
                    }
                    return JSON.parse(unparsedCookie);
                } else {
                    app.log.error(window.localize("app.context.errorRetrievingUser"));
                    return {};
                }

            },

            setUserPreferences: function(key, prefObject) {
                // make sure we have a valid logged in user to store preferences for..
                if (app.user && app.user.get("loginName")) {
                    var userPrefCookieName = app.user.get("loginName") + "-" + key + "-userPreferences";
                    var prefString = JSON.stringify(prefObject);
                    $.cookie(userPrefCookieName, prefString, {
                        path: app.root,
                        secure: app.secureBrowserCookies,
                        expires: 365 * 20
                    });
                } else {
                    app.log.error(window.localize("app.context.errorSettingUser"));
                }
            }
        };

        Context.getContentTypeConfigByMimiType = function(contentType) {
            return _.find(Context.contentTypeConfigsByMimeType, function(contentTypeConfigByMimeType) {
                return contentTypeConfigByMimeType.mimeType === contentType;
            });
        };

        Context.contentTypeConfigsByMimeType = [{
            mimeType: "application/msword",
            iconPath: "assets/css/styles/img/icons/doc.svg"
        }, {
            mimeType: "application/vnd.ms-word.document.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/doc.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            iconPath: "assets/css/styles/img/icons/doc.svg"
        }, {
            mimeType: "application/vnd.ms-powerpoint.template.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.template",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.ms-powerpoint.slideshow.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.ms-powerpoint",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.ms-powerpoint.presentation.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            iconPath: "assets/css/styles/img/icons/ppt.svg"
        }, {
            mimeType: "application/vnd.visio",
            iconPath: "assets/css/styles/img/icons/visio.svg"
        }, {
            mimeType: "application/vnd.ms-excel",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.ms-excel.sheet.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.ms-excel.template.macroEnabled.12",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.ms-works",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
            iconPath: "assets/css/styles/img/icons/xls.svg"
        }, {
            mimeType: "application/vnd.ms-outlook",
            iconPath: "assets/css/styles/img/icons/email.svg"
        }, {
            mimeType: "message/rfc822",
            iconPath: "assets/css/styles/img/icons/email.svg"
        }, {
            mimeType: "text/html",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "text/jhtml",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "text/phtml",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "text/shtml",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "multipart/related",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "text/plain",
            iconPath: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "text/json",
            iconPath: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "text/xml",
            iconPath: "assets/css/styles/img/icons/xml.svg"
        }, {
            mimeType: "text/x-vcard",
            iconPath: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "image/gif",
            iconPath: "assets/css/styles/img/icons/gif.svg"
        }, {
            mimeType: "image/jp2",
            iconPath: "assets/css/styles/img/icons/jpeg.svg"
        }, {
            mimeType: "image/jpeg",
            iconPath: "assets/css/styles/img/icons/jpeg.svg"
        }, {
            mimeType: "image/vnd.ms-modi",
            iconPath: "assets/css/styles/img/icons/tif.svg"
        }, {
            mimeType: "image/png",
            iconPath: "assets/css/styles/img/icons/gif.svg"
        }, {
            mimeType: "image/tiff",
            iconPath: "assets/css/styles/img/icons/tif.svg"
        }, {
            mimeType: "application/illustrator",
            iconPath: "assets/css/styles/img/icons/illlustrator.svg"
        }, {
            mimeType: "application/pdf_props",
            iconPath: "assets/css/styles/img/icons/pdf.svg"
        }, {
            mimeType: "application/pdf_combo",
            iconPath: "assets/css/styles/img/icons/pdf.svg"
        }, {
            mimeType: "application/pdf",
            iconPath: "assets/css/styles/img/icons/pdf.svg"
        }, {
            mimeType: "text/pdf",
            iconPath: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "application/photoshop",
            iconPath: "assets/css/styles/img/icons/ps.svg"
        }, {
            mimeType: "application/x-zip-compressed",
            iconPath: "assets/css/styles/img/icons/zip.svg"
        }, {
            mimeType: "application/octet-stream",
            iconPath: "assets/css/styles/img/icons/unknown.svg"
        }, {
            mimeType: "application/x-ms-wmz",
            iconPath: "assets/css/styles/img/icons/zip.svg"
        }, {
            mimeType: "application/rtf",
            iconPath: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "application/x-url",
            iconPath: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "image/x-dwg",
            iconPath: "assets/css/styles/img/icons/cad.svg"
        }, {
            mimeType: "video/mp4",
            iconPath: "assets/css/styles/img/icons/mp4.svg"
        }, {
            mimeType: "video/quicktime",
            iconPath: "assets/css/styles/img/icons/mp4.svg"
        }, {
            mimeType: "video/x-msvideo",
            iconPath: "assets/css/styles/img/icons/mp4.svg"
        }, {
            mimeType: "audio/x-wav",
            iconPath: "assets/css/styles/img/icons/audio.svg"
        }, {
            mimeType: "audio/x-ms-wma",
            iconPath: "assets/css/styles/img/icons/audio.svg"
        }, {
            mimeType: "audio/wav",
            iconPath: "assets/css/styles/img/icons/audio.svg"
        }, {
            mimeType: "audio/mpeg",
            iconPath: "assets/css/styles/img/icons/audio.svg"
        }];

        Context.getMimeTypePrettyType = function(mimeType) {
            return _.find(Context.mimeTypeToPrettyType, function(mimeTypeToPrettyType) {
                return mimeTypeToPrettyType.mimeType === mimeType;
            });
        };

        Context.mimeTypeToPrettyType = [{
            mimeType: "application/msword",
            prettyName: window.localize("app.context.microsoftWordDocument")
        }, {
            mimeType: "application/vnd.ms-word.document.macroEnabled.12",
            prettyName: window.localize("app.context.microsoftWordDocument")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            prettyName: window.localize("app.context.microsoftWordDocument")
        }, {
            mimeType: "application/vnd.ms-powerpoint.template.macroEnabled.12",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.template",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.ms-powerpoint.slideshow.macroEnabled.12",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.ms-powerpoint",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.ms-powerpoint.presentation.macroEnabled.12",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            prettyName: window.localize("app.context.mircrosoftPowerpointProject")
        }, {
            mimeType: "application/vnd.visio",
            prettyName: "assets/css/styles/img/icons/visio.svg"
        }, {
            mimeType: "application/vnd.ms-excel",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.ms-excel.sheet.macroEnabled.12",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.ms-excel.template.macroEnabled.12",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.ms-works",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
            prettyName: window.localize("app.context.microsoftExcelSpreedsheet")
        }, {
            mimeType: "application/vnd.ms-outlook",
            prettyName: window.localize("app.context.email")
        }, {
            mimeType: "text/html",
            prettyName: window.localize("generic.HTML")
        }, {
            mimeType: "text/jhtml",
            prettyName: window.localize("generic.HTML")
        }, {
            mimeType: "text/phtml",
            prettyName: window.localize("generic.HTML")
        }, {
            mimeType: "text/shtml",
            prettyName: window.localize("generic.HTML")
        }, {
            mimeType: "multipart/related",
            prettyName: window.localize("generic.HTML")
        }, {
            mimeType: "text/plain",
            prettyName: window.localize("app.context.textFile")
        }, {
            mimeType: "text/json",
            prettyName: window.localize("app.context.jsonObject")
        }, {
            mimeType: "application/json",
            prettyName: window.localize("app.context.jsonObject")
        }, {
            mimeType: "text/xml",
            prettyName: window.localize("app.context.xml")
        }, {
            mimeType: "text/x-vcard",
            prettyName: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "image/gif",
            iprettyName: window.localize("app.context.gif")
        }, {
            mimeType: "image/jpeg",
            prettyName: window.localize("app.context.jpeg")
        }, {
            mimeType: "image/vnd.ms-modi",
            prettyName: window.localize("app.context.tiff")
        }, {
            mimeType: "image/png",
            prettyName: window.localize("app.context.png")
        }, {
            mimeType: "image/tiff",
            prettyName: window.localize("app.context.tiff")
        }, {
            mimeType: "application/illustrator",
            prettyName: "assets/css/styles/img/icons/illlustrator.svg"
        }, {
            mimeType: "application/pdf_props",
            prettyName: window.localize("generic.PDF")
        }, {
            mimeType: "application/pdf_combo",
            prettyName: window.localize("generic.PDF")
        }, {
            mimeType: "application/pdf",
            prettyName: window.localize("generic.PDF")
        }, {
            mimeType: "text/pdf",
            prettyName: window.localize("generic.PDF")
        }, {
            mimeType: "application/photoshop",
            prettyName: window.localize("app.context.photoshop")
        }, {
            mimeType: "application/x-zip-compressed",
            prettyName: window.localize("app.context.zipFile")
        }, {
            mimeType: "application/octet-stream",
            prettyName: "assets/css/styles/img/icons/unknown.svg"
        }, {
            mimeType: "application/x-ms-wmz",
            prettyName: "assets/css/styles/img/icons/zip.svg"
        }, {
            mimeType: "application/rtf",
            prettyName: "assets/css/styles/img/icons/txt.svg"
        }, {
            mimeType: "application/x-url",
            prettyName: "assets/css/styles/img/icons/html.svg"
        }, {
            mimeType: "image/x-dwg",
            prettyName: "assets/css/styles/img/icons/cad.svg"
        }, {
            mimeType: "video/mp4",
            prettyName: window.localize("app.context.mp4")
        }, {
            mimeType: "video/quicktime",
            prettyName: window.localize("app.context.quicktime")
        }, {
            mimeType: "video/x-msvideo",
            prettyName: window.localize("app.context.msvideo")
        }, {
            mimeType: "audio/x-wav",
            prettyName: window.localize("app.context.wav")
        }, {
            mimeType: "audio/x-ms-wma",
            prettyName: window.localize("app.context.wma")
        }, {
            mimeType: "audio/wav",
            prettyName: window.localize("app.context.wav")
        }, {
            mimeType: "audio/mpeg",
            prettyName: window.localize("app.context.mpeg")
        }];

        return Context;
    });