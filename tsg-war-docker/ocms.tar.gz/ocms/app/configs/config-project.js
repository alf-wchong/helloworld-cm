var manageWFDocSearchConfig = {
	searchConfig: [
		{
			paramName: "documentNumber",
			paramValue: "none",
			paramType: "property"
		},
		{
			operator: "equals",
			paramName: "aw_status",
			paramType: "property",
			paramValue: "DRAFT"
		},
		{
			paramName: "Controlled Document",
			paramType: "type",
			paramValue: "Controlled Document"
		},
		{
			paramName: "limit_results",
			paramValue: 25,
			paramType: "options"
		},
		{
			paramName: "searchallversions",
			paramValue: "true",
			paramType: "searchallversions"
		}
	],
	//override attributes
	attributes: [
		{
			'displayName': 'Document Number',
			'ocoName': 'documentNumber',
			'createLink': true
		},
		{
			'displayName': 'Title',
			'ocoName': 'title'
		},
		{
			'displayName': 'Version',
			'ocoName': 'versionLabel'
		},
		{
			'displayName': 'Status',
			'ocoName': 'aw_status'
		}
	],
	localizations:{
		'existing-documents-instructions': 'Select controlled documents to remove from this form.',

	},
	conditions: ['condition-isqualitydraftlifecyclestate-conditionevaluator',
				'condition-isworkflowdocnotalreadyattached-conditionevaluator',
				'condition-isobjectlatest-conditionevaluator']
};

var manageRelationsConfig = {
	searchConfig: [
		{
			paramName: "objectName",
			paramValue: "none",
			paramType: "property"
		},
		{
			paramName: "Document",
			paramType: "type",
			paramValue: "Document"
		},
		{
			paramName: "limit_results",
			paramValue: 25,
			paramType: "options"
		}
	]
};

var adminSearchToolConfig = {
	passthroughQueryEnabled: false,
};

var metadataPositionAttr = "hpi_metadataPositions";

var manageAdHocDocumentsConfig = {	
	supportingDocumentRelationName: "aw:supportingDocument",
	attributes: [
		{
			'displayName': 'Document Title',
			'ocoName': 'title',
			'createLink': 'true'
		},
		{
			'displayName': 'Upload Date',
			'ocoName': 'creationDate'
		},
		{
			'displayName': 'Creator',
			'ocoName': 'creator'
		}
	],
	localizations: {
		tabs: {
			addAdHocDocuments : 'Add Ad Hoc Documents',
			existingAdHocDocuments : 'Existing Ad Hoc Documents'
		},
		add: {
			success: 'Ad Hoc Document(s) successfully added.',
			failure: 'Error adding ad hoc document(s). Please contact the administrator.'
		},
		remove: {
			success: 'Ad Hoc Document(s) successfully removed.',
			failure: 'Error removing ad hoc document(s). Please contact the administrator.'
		},
		noAdHocDocumentsSelected : 'No documents selected'
	}
};


var documentsPopulatorConfig = {
	searchConfig: [
		{
			paramName: "Parent",
			paramValue: "none",
			paramType: "property"
		},

		{
			paramName: "searchallversions",
			paramValue: "true",
			paramType: "searchallversions"
		},

		{
			paramName: "Document",
			paramType: "type",
			paramValue: "Document",
			relatedObjectOperator: null
		}

	],
	//override attributes
	attributes: [
		{
			'displayName': 'Name',
			'ocoName': 'objectName',
			'createLink': true
		},
		{
			'displayName': 'Title',
			'ocoName': 'title'
		},
		{
			'displayName': 'Version',
			'ocoName': 'versionLabel'
		}
	],
	localizations:{
		'existing-documents-instructions': 'Select controlled documents to remove from this form.'
	}
};

var config = {
	'app': {
		root: "/@@appRoot/",
		uniqueUserName: "loginName",
		collectionRelation: "hpi:collectionItem",
		defaultAdminGroup: "GROUP_hpi_administrators",
		secureAdminUrl: {
			viaUsernamePassword: false,
			viaAdminGroupMembership: true,
			allowedHpiAdminGroups: ['hpi_administrators', 'GROUP_hpi_administrators']
		},
		checkForSupportedBrowser: false,
        supportedBrowsers: {
	      'Chrome' : '50',
	      'MSIE' : '11',
          'Firefox' : '42'
		},
		// Enabling this flag will toggle the "secure" property on browser cookies created by this application
		secureBrowserCookies: true,
		enableWizard: false,
		showTemplateManager: true,
		enableDirectSQL: false,
		developerTab: false
	},
	'bulkupload': {
		// Example of a bulk upload extension whitelist configuration. Note: without any whitelist, all extensions are accepted.
		// With both this default list and a whitelist configured in admin, the admin configuration would override the list here.
		//defaultDocumentTypesWhiteListed : "doc,docx,gif,jpeg,jpg,pdf,png,ppt,pptx,xls,xlsx"
	},
	"sendsmartcomm": {
		thunderheadServer: "https://na10-sb.smartcommunications.cloud"
	},
	"modules/hpiadmin/hpiadmin": {
		// This syntax will allow us to provide an appId via the build command and replace this token with the provided id
		appId: "@@appId"
	},
	"modules/hpiadmin/adminsearchtool/adminsearchtool" : adminSearchToolConfig,
	"modules/stage/stageinfo": {
		linkText: "View Form"
	},
	//Override with specific file types to be displayed within the oaiframe on bulkupload
	//'bulkupload':{oaIframeExtenWhiteList:[]},
	'viewproperties': {
		objectTypesToNotAddExtentionTo : ["Page Set Instance"],
		positionalAttribute: metadataPositionAttr
	},
	'modules/wizard/views/pageview': {
		questionGroupLimitForShowingOnlyMobileView: 8
	},
	'modules/wizard/views/summaryview': {
		questionGroupLimitForShowingOnlyMobileView: 8
	},
	'modules/hpiadmin/preferences/preferencesconfig': {
		inboxProxyEnabled: true
	},
	'modules/hpiadmin/actionconfig/actions/reassignwizardworkflowtask/reassignwizardworkflowtaskconfig': {
		reassignFutureApprover: false
	},
	'modules/hpiadmin/picklistconfig/picklistconfig': {
		dataDictionaryEnabled: false
	},
	'modules/hpiadmin/indexerconfig/indexerconfig': {
		enableSplitPDFOptions: false
	},
	'modules/hpiadmin/otc/hpitypeconfigattrs': {
		enableIndexing: false
	},
    "tableview": {
    	specialIcon: {
	    	"documentNumber": {
				attrDependency: "lockOwner",
				regex: {
					pattern: "$user.displayName",
					value: "keys"
				},
				defaultValue :"lock",
				tooltip: true
			}
    	}
    },
	'modules/wizard/populators/documentspopulator' : documentsPopulatorConfig,
	"managerelations": manageRelationsConfig,
    "manageworkflowdocuments": manageWFDocSearchConfig,
    "modules/wizard/activeformrouter": {
    	folderPropertyToQuestionLabelMap: {
    		"Master Services Agreement": {
	            "tsg_contractVendorName": "Contractor",
	            "con_vendorStreet": "Street",
	            "con_vendorCity": "City",
	            "con_vendorState": "State",
	            "con_vendorZip": "Zip Code",
	            "con_vendorContactName": "What is the name of the Contractor Contact?",
	            "con_vendorContactPhoneNumber": "Phone Number",
	            "con_vendorContactEmail": "Email Address"
        	},
        	"Claimant Contact Letter": {
        		"insuranceDemo_claimantName": "Claimant Full Name",
        		"insuranceDemo_claimNumber": "Claim Number",
        		"insuranceDemo_lossDate": "Date of Injury"
        	}
    	}
    },
    'modules/hpiadmin/searchconfig/genericresultsconfig': {
            "totalTimeBad" : "10",
			"totalTimeMedium" : "5",

            "networkTimeBad" : "1",
			"networkTimeMedium" : ".5",

            "queryBuildTimeBad" : ".2",
			"queryBuildTimeMedium" : ".1",

            "queryExecuteTimeBad" : "2",
			"queryExecuteTimeMedium" : "1",

            "queryParseTimeBad" : ".5",
			"queryParseTimeMedium" : ".3",

            "tableViewRenderTimeBad" : ".5",
			"tableViewRenderTimeMedium" : ".3",

            "formatResultsTimeBad" : ".7",
            "formatResultsTimeMedium" : ".3"
	},
    'modules/hpiadmin/formconfig/formtype': {
	   availableConditions: [{
		   ruleLabel: "Attributes match existing content.",
		   ruleValue: 'condition-do-attributes-match-content-conditionevaluator'
	   }]
	},
	'modules/externalEventsModule' : {
		acceptedDateFormats: ['MMM DD, YYYY', 'MM/DD/YYYY','M/DD/YYYY','MM-DD-YYYY','DD-MMM-YYYY'],
		positionalAttribute: metadataPositionAttr
	},

    //below is a configuration for formattribute which allows
    //conditions defined and configured in OC to be applied to form attributes
    //on forms for validation.
    "modules/hpiadmin/formconfig/formattribute": {
        availableConditions: [{
            ruleLabel: "Read Access on Document using Selected User",
            ruleValue: "condition-readasotheruser-conditionevaluator"
        }, {
            ruleLabel: "Attribute is Unique",
            ruleValue: "condition-isattributeunique-conditionevaluator"
        }, {
            ruleLabel: "Attribute is Unique in folder",
            ruleValue: "condition-isattributeuniqueinfolder-conditionevaluator"
        }]
	},
	"getDocumentLink": {
		disableShortLink: true
	}
};
