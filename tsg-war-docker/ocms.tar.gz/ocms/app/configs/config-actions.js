//defaults to all, but you can override in your config-project.js
// eslint-disable-next-line no-unused-vars
var activeActionPackages = ['base', 'collections', 'indexer', 'oa', 'other', 'wizard', 'workflow', 'cloudservice'];

//map that will hold the different types of actions
var actions = {};

actions.base = {
    checkout : "modules/actions/checkout",
    checkin : "modules/actions/checkin",
    // uploadnewversion : "modules/actions/uploadnewversion",
    cancelcheckout : "modules/actions/cancelcheckout",
    viewproperties : "modules/actions/viewproperties/viewproperties",
    viewversions : "modules/actions/viewversions",
    //databasetableview : "modules/actions/databasetableview",
    deletedocument : "modules/actions/deletedocument",
    //softdeletedocument : "modules/actions/softdeletedocument",
    downloaddocument : "modules/actions/downloaddocument",
    downloadcollectionasdocument : "modules/actions/downloadcollectionasdocument",
    downloadaszip : "modules/actions/downloadaszip",
    exportfolder : "modules/actions/exportfolder",
    exportforms : "modules/actions/exportforms",
    exportsearchresults : "modules/actions/exportsearchresults",
    exportsearchresultstopdf: "modules/actions/exportsearchresultstopdf",
    createfolder: "modules/actions/createfolder",
    sendnotification : "modules/actions/sendnotification",
    sendemail : "modules/actions/sendemail/sendemail",
    sendsmartcomm : "modules/actions/sendsmartcomm/sendsmartcomm",
    sendcombinedcollectionemail: "modules/actions/sendcombinedcollectionemail",
    replyemail : "modules/actions/replyemail",
    foldernotes : "modules/actions/foldernotes",
    bulkupload : "modules/actions/bulkupload",
    createcontentlessobject : "modules/actions/createcontentlessobject",
    //makemajorversion: "modules/actions/makemajorversion",
    managelegalhold: "modules/actions/managelegalhold/managelegalhold",
    bulkproperties : "modules/actions/bulkproperties",
	setrendition : "modules/actions/setrendition",
    viewalldocuments : "modules/actions/viewalldocuments",
    advancedcombinetopdf : "modules/actions/advancedcombinetopdf/advancedcombinetopdf",
    advancedcombinetopdfsendemail : "modules/actions/advancedcombinetopdfsendemail",
    //controlledprint : "modules/actions/controlledprint/controlledprint",
	//mailmergefields: "modules/actions/mailmergefields",
	propertyintegritycheck: "modules/actions/propertyintegritycheck",
    sendtodocusign: "modules/actions/sendtodocusign",
    viewlocations: "modules/actions/viewlocations",
    // movedocument: "modules/actions/movedocuments/movedocuments",
    splitpdf: "modules/actions/splitpdf",
    prunepdf: "modules/actions/prunepdf/prunepdf",
    viewrenditions: "modules/actions/viewrenditions",
    generatecontract: "modules/actions/generatecontract",
    bulkdeleteattribute: "modules/actions/bulkdeleteattribute",
    requireddocuments: "modules/actions/requireddocuments",
    opennewtab: "modules/actions/opennewtab",
    revertversion: "modules/actions/revertversion",
    copytext: "modules/actions/copytext",
    viewfolderterms: "modules/actions/viewfolderterms",
    redacttext: "modules/actions/redacttext",
    //mergevideos: "modules/actions/mergevideos/mergevideos",
    comparedocuments: "modules/actions/comparedocuments/comparedocuments",
    downloadrelatedobjects: "modules/actions/downloadrelatedobjects/downloadrelatedobjects",
    sendtokira: "modules/actions/sendtokira/sendtokira",
    generatesmartcommletter : "modules/actions/generatesmartcommletter/generatesmartcommletter"
    //sendtojms: "modules/actions/sendtojms/sendtojms"
};

actions.collections = {
    addtocollection : "modules/actions/addtocollection",
    removefromcollection : "modules/actions/removefromcollection"
};
actions.indexer = {
    addindexerdocuments : "modules/actions/addindexerdocuments",
    createrelationships : "modules/actions/createrelationships"
};
actions.oa = {
    annotateobject : "modules/actions/annotateobject",
    permanentredact : "modules/actions/permanentredact",
    unredactedascopy: "modules/actions/unredactedascopy",
    redactedascopy: "modules/actions/redactedascopy",
    signature: "modules/actions/signature",
    viewannotations : "modules/actions/viewannotations",
    annotateVideo : "modules/actions/annotatevideo"
};
actions.other = {
    // opencontenturl : "modules/actions/opencontenturl",
    managerelations: "modules/actions/managerelations/managerelations",
    creategoogledoc: "modules/actions/creategoogledoc",
    whycanti : "modules/actions/whycanti"
};
actions.wizard = {
    viewwizardauditevents : "modules/actions/viewwizardauditevents",
    viewwizardworkflowstatus : "modules/actions/viewwizardworkflowstatus",
    createwizardform: "modules/actions/createwizardform",
    resumeform : "modules/actions/resumeform",
    startwizardreviewworkflow : "modules/actions/startwizardreviewworkflow",
    closeform : "modules/actions/closeform",
    cancelform : "modules/actions/cancelform",
    completewizardapprovalroute : "modules/actions/completewizardapprovalroute",
    completewizardreviewroute : "modules/actions/completewizardreviewroute",
    copywizardform: "modules/actions/copywizardform",
    delegatewizardworkflowtask : "modules/actions/delegatewizardworkflowtask",
    reassignwizardworkflowtask : "modules/actions/reassignwizardworkflowtask",
    startwizardapprovalworkflow: "modules/actions/startwizardapprovalworkflow",
    skipactivity: "modules/actions/skipactivity/skipactivity",
    impactassessment : "modules/actions/impactassessment",
    powerpromote : "modules/actions/powerpromote",
    promoteordemote : "modules/actions/promoteordemote",
    promoteordemoteworkflow: "modules/actions/promoteordemoteworkflow",
    seteffectivedate : "modules/actions/seteffectivedate",
    changewizardformowner : "modules/actions/changewizardformowner",
    obsoletedocument : "modules/actions/obsoletedocument",
    performPeriodicReview: "modules/actions/performperiodicreview",
    manageadhocdocuments: "modules/actions/manageadhocdocuments/manageadhocdocuments",
    manageworkflowdocuments: "modules/actions/manageworkflowdocuments",
    getDocumentLink: "modules/actions/getdocumentlink",
    //resettodraft: "modules/actions/resettodraft",
    formapprovalreport : "modules/actions/formapprovalreport/formapprovalreport",
    generateworkflowreport: "modules/actions/generateworkflowreport",
    openfinalattestationreport: "modules/actions/openfinalattestationreport"
};
actions.workflow = {
    cancelworkflow: "modules/actions/cancelworkflow",
    acquireworkflowtask : "modules/actions/acquireworkflowtask",
    startworkflow : "modules/actions/startworkflow",
    completetask :  "modules/actions/completetask",
    delegateworkflowtask : "modules/actions/delegateworkflowtask",
    viewauditevents : "modules/actions/viewauditevents",
    unacquireworkflowtask : "modules/actions/unacquireworkflowtask"
};
actions.cloudservice = {
    checkinfromcloudservice: "modules/actions/checkinfromcloudservice",
    checkouttocloudservice: "modules/actions/checkouttocloudservice"
};
