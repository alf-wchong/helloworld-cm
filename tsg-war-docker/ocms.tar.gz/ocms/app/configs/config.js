//IIF
(function(){
  //add active action packages to config
  for(var i=0;i< activeActionPackages.length; i++){
	var packageName = activeActionPackages[i];
	var actionPackage = actions[packageName];
	for(var key in actionPackage){
		conf.paths[key] = actionPackage[key];
		conf.deps.push(key);
	}
  }
  //set the config from config-project.js on the main conf module
  conf.config = config;
}());