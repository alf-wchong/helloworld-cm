var conf = {

	// Initialize the application with the main application file.
	deps: ["app", "main"],

	waitSeconds: 30,

	paths: {
		// JavaScript folders.
		libs: "../assets/js/libs",
		plugins: "../assets/js/plugins",
		vendor: "../assets/vendor",

		// Libraries.
		jquery: "../assets/js/libs/jquery-1.9.1",
        jqueryDownload: "../assets/js/libs/jquery-fileDownload-1.4.3",
		jqueryUI: "../assets/js/libs/jquery-ui-1.10.3.custom",
		jqueryDeparam: "../assets/js/libs/jquery-deparam",
		jqueryDrag: "../assets/js/libs/jquery.event.drag-2.2",
		jqueryDrop: "../assets/js/libs/jquery.event.drop-2.2",
		simpleXML: "../assets/js/libs/simpleXML",
		fileupload: "../assets/js/libs/jquery.fileupload",
		iframeTransport: "../assets/js/libs/jquery.iframe-transport",
		l10n: "../assets/js/libs/l10n",

		// bootstrap dependencies for older browsers (ie8 is our custom wrapper-loader)
		respond: "../assets/js/libs/respond",
		html5shiv: "../assets/js/libs/html5shiv",
		ie8: "modules/ie/ie8",

		bootstrap: "../assets/js/bootstrap/js/bootstrap",
		underscore: "../assets/js/libs/underscore",
		backbone: "../assets/js/libs/backbone-1.1.2",
		backbonerelational: "../assets/js/libs/backbone-relational",
		backbonequeryparams: "../assets/js/libs/backbone.queryparams",
		handlebars: "../assets/js/libs/handlebars-v4.7.3",
		knockout: "../assets/js/libs/knockout",
		knockoutsortable: "../assets/js/libs/knockout-sortable",
		knockback: "../assets/js/libs/knockback",
		moment: "../assets/js/libs/moment-v2.24",
		momentTimezone: "../assets/js/libs/moment-timezone-v0.5.28",
		numeral: "../assets/js/libs/numeral",
		log4javascript: "../assets/js/libs/log4javascript",
		slickcore: "../assets/js/slickgrid/slick.core",
		slickgrid: "../assets/js/slickgrid/slick.grid",
        slickcorebase: "../assets/js/slickgrid-base/slick.core",
        slickgridbase: "../assets/js/slickgrid-base/slick.grid",
		ckeditorcore: "../assets/ckeditor/ckeditor",
		ckeditorjquery: "../assets/ckeditor/adapters/jquery",
		typeahead: "../assets/js/libs/typeahead",
		wlapi: "../assets/js/libs/wl",
		URIjs: "../assets/js/libs/URIjs",
		sanitizeHtml: "../assets/js/libs/sanitize-html",
		tsgUtils: "../assets/js/libs/tsgUtils/src/tsgUtils",


		Dynamsoft: "../assets/vendor/dynamsoft/dynamsoft.webtwain.initiate",
		//modules
        header: "modules/header",
		stage: "modules/stage/stage",
        activeForm: "modules/wizard/activeform",
        security: "modules/common/security",
        dashboard: "modules/dashboard/dashboard",
		googledocs: "modules/common/googledocs",
		googledocsoauth: "modules/oauth/googledocsoauth",
        relatedObjects: "modules/stage/relatedobjects",
        foldertree: "modules/common/foldertree",
        oc: "modules/common/oc",
        cloudserviceauthentication: "modules/common/cloudservices/cloudserviceauthentication",
		thumbnailview: "modules/search/thumbnailview",
		listview: "modules/search/listview",

		externalEventsModule: "modules/externalEventsModule",
		
		templating: "modules/common/startup/templating",

		//search modules
        tableview: "modules/search/tableview",

		//dashboard modules
		workflowreportingdashlet: "modules/dashboard/workflowreportingdashlet",
		incompletetagdashlet: "modules/dashboard/incompletetagdashlet",
		inbox: "modules/dashboard/inbox",
		iframedashlet: "modules/dashboard/iframedashlet",

		// plugins
		tourist: "../assets/js/plugins/tourist",
		spin: "../assets/js/plugins/spin", // for loading indication spinner
		json2: "../assets/js/plugins/json2",
		backboneroutefilter: "../assets/js/plugins/backbone-route-filter",
		backbonelayoutmanager: "../assets/js/plugins/backbone.layoutmanager-0.9.5",
		marionette: "../assets/js/plugins/backbone.marionette-2.4.0",
		dateformat: "../assets/js/plugins/dateFormat.min",
		scrollable: "../assets/js/plugins/jquery.tools.min",
		jqplot: "../assets/js/plugins/jqplot/jquery.jqplot",
		jqplotCanvasOverlay: "../assets/js/plugins/jqplot/jqplot.barRenderer",
        jqplotBarRenderer: "../assets/js/plugins/jqplot/jqplot.canvasOverlay",
		jqplotCategoryAxisRenderer: "../assets/js/plugins/jqplot/jqplot.categoryAxisRenderer",
		jqplotCanvasTextRenderer: "../assets/js/plugins/jqplot/jqplot.canvasTextRenderer",
		jqplotCanvasAxisTickRenderer: "../assets/js/plugins/jqplot/jqplot.canvasAxisTickRenderer",
        jqplotDateAxisRenderer: "../assets/js/plugins/jqplot/jqplot.dateAxisRenderer",
        jqplotPieRenderer: "../assets/js/plugins/jqplot/jqplot.pieRenderer",
		jqplotPointLabels: "../assets/js/plugins/jqplot/jqplot.pointLabels",
        jqplotTrendline: "../assets/js/plugins/jqplot/jqplot.trendline",
		datetimePicker: "../assets/js/plugins/jquery-ui-timepicker-addon",
		jqueryMigrationPlugin: "../assets/js/plugins/jquery-migrate-1.2.1",
		jqueryDraggablePlugin: "../assets/js/plugins/jquery.ui.touch-punch",
		momentJDate: "../assets/js/plugins/moment-jdateformatparser.min",
		spectrum: "../assets/js/plugins/spectrum",
		videoJS: "../assets/videojs5/video.min",
		fabricJS: "../assets/fabricjs/fabric.min",
		boxIntegration: "../assets/js/libs/select"
	},

	shim: {
		fabricJS: {
			exports: "fabric"
		},

        underscore: {
            exports: "_"
		},

		// Backbone library depends on underscore and jQuery.
		backbone: {
			deps: ["underscore", "jquery"],
			exports: "Backbone"
		},

		backbonerelational: {
            deps: ["backbone"]
		},

		backbonequeryparams: {
            deps: ["backbone"]
		},

		//Knockout lib, has no dependencies
		knockout: {
			exports: "ko"
		},
		// Handlebars has no dependencies.
		handlebars: {
			exports: "Handlebars"
		},

		tourist: {
			deps: ["jquery", "backbone"],
			exports: "Tourist"
		},

		jqueryDeparam: {
			deps: ["jquery", "backbone"]
		},
		jqueryDownload : {
			deps: ["jquery"]
		},

		spin: {
			// jQuery is technically an optional dependency but since we use jQuery, let's make it a dependency
			deps: ["jquery"]
		},
		//bootstrap 3 decoupled typeahead from $ into typeahead.js
		typeahead: {
			deps: ["jquery"]
		},

		slickgrid: {
			deps: ["jqueryDrag", "jqueryDrop", "slickcore",
				"../assets/js/slickgrid/slick.editors", "../assets/js/slickgrid/slick.formatters", "../assets/js/slickgrid/tsg.dataview",
				"../assets/js/slickgrid/plugins/slick.rowselectionmodel", "../assets/js/slickgrid/plugins/slick.checkboxselectcolumn",
				"../assets/js/slickgrid/plugins/slick.autotooltips", "../assets/js/slickgrid/controls/slick.pager",
				"../assets/js/slickgrid/controls/slick.columnpicker", "../assets/js/slickgrid/plugins/slick.rowmovemanager",
				"../assets/js/slickgrid/plugins/slick.rowtogglecolumn","../assets/js/slickgrid/plugins/slick.orderinputcolumn",
				"../assets/js/slickgrid/plugins/slick.bookmarkcolumn","../assets/js/slickgrid/plugins/slick.oaselectedpagescolumn",
				"../assets/js/slickgrid/plugins/slick.selectversionscolumn", "../assets/js/slickgrid/plugins/slick.numcopiescolumn",
				"jquery"
			]
		},

        slickgridbase: {
            deps: ["jqueryDrag", "jqueryDrop", "slickcorebase",
                "../assets/js/slickgrid-base/slick.dataview", "jquery"
            ]
        },

		ckeditorjquery: {
            deps: ["jquery", "ckeditorcore"]
		},

		json2: {
			exports: "json2"
		},


		ie8: {
			deps: ['jquery']
		},

		bootstrap: {
            deps: ["jquery", "ie8"]
		},

        jqueryUI: {
            deps: ["jquery"]
        },

        jqueryDrag: {
            deps: ["jquery"]
		},

        jqueryDrop: {
            deps: ["jquery"]
		},

		simpleXML: {
            deps: ["jquery"]
		},


        "../assets/js/slickgrid/slick.editors": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid/slick.formatters": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid/tsg.dataview": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid-base/slick.dataview": {
            deps: ["jquery"]
        },

        "../assets/js/slickgrid/plugins/slick.rowselectionmodel": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid/plugins/slick.checkboxselectcolumn": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid/controls/slick.pager": {
            deps: ["jquery"]
		},

        "../assets/js/slickgrid/controls/slick.columnpicker": {
            deps: ["jquery"]
		},

		"../assets/js/slickgrid/plugins/slick.autotooltips": {
			deps : ["jquery"]
		},

		"../assets/js/slickgrid/plugins/slick.rowmovemanager": {
			deps: ["jquery"]
		},
		"../assets/js/slickgrid/plugins/slick.rowtogglecolumn": {
			deps: ["jquery"]
		},
		"../assets/js/slickgrid/plugins/slick.numcopiescolumn": {
			deps: ["jquery"]
		},
		
		"../assets/js/slickgrid/plugins/slick.orderinputcolumn" : {
			deps : ["jquery"]
		},

		"../assets/js/slickgrid/plugins/slick.bookmarkcolumn" : {
			deps : ["jquery"]
		},

		"../assets/js/slickgrid/plugins/slick.oaselectedpagescolumn" : {
			deps : ["jquery"]
		},

		"../assets/js/slickgrid/plugins/slick.selectversionscolumn": {
			deps : ["jquery"]
		},

        "slickcore": {
            deps: ["jquery"]
		},

        "slickcorebase": {
            deps: ["jquery"]
        },

        "jqplot": {
            deps: ["jquery"]
		},

		"jqplotBarRenderer": {
			deps: ["jquery", "jqplot"]
		},

        "jqplotCanvasOverlay": {
            deps: ["jquery", "jqplot"]
        },

		"jqplotCategoryAxisRenderer": {
			deps: ["jquery", "jqplot"]
		},

		"jqplotCanvasTextRenderer": {
			deps: ["jquery", "jqplot"]
		},

		"jqplotCanvasAxisTickRenderer": {
			deps: ["jquery", "jqplot"]
		},

        "jqplotDateAxisRenderer": {
            deps: ["jquery", "jqplot"]
        },

        "jqplotPieRenderer": {
            deps: ["jquery", "jqplot"]
        },

		"jqplotPointLabels": {
			deps: ["jquery", "jqplot"]
		},

        "jqplotTrendline": {
            deps: ["jquery", "jqplot"]
        },

        "uploadify": {
            deps: ["jquery"]
		},
        "backboneroutefilter": {
            deps: ["backbone"]
		},

        "scrollable": {
			deps: ["jquery"]
		},

        "datetimePicker": {
			deps: ["jquery", "jqueryUI"]
		},

        "jqueryMigrationPlugin": {
			deps: ["jquery"]
		},
        "jqueryDraggablePlugin": {
			deps: ["jquery", "jqueryUI"]
		},
        "spectrum": {
			deps: ["jquery", "jqueryUI"]
		},

		"backbonelayoutmanager": {
            deps: ["backbone"]
		},

		marionette: {
            deps: ["backbone"]
		}
	}
};