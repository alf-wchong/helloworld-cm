define([
        // Application.
        "app",
        "backboneroutefilter",
        "module",
        "modules/stage/searchresulttraversal",
        "modules/common/hpiconstants"
    ],

    function(app, filters, module, SearchResultTraversal, HPIConstants) {

        // these urls don't need a ticket
        var whiteList = ["",
            app.root,
            "applicationError",
            "noConfigError",
            "tracAuthorizationError",
            "logout",
            "licenseError",
            "licenseErrorTooManyUsers",
            "licenseErrorExpired",
            "connectError",
            "error/userDisabled",
            "error/userDoesNotExist",
            "error/fetchingUserData"
        ];

        // Defining the base router, app routers should extend this as it has the required filters
        var Router = Backbone.Router.extend({

            before: {
                "*any": "security"
            },

            removeSearchResults: function(fragment) {
                //Removing the data for search traversal of results on stage
                if (window.localStorage.getItem('latestResults') && fragment.indexOf('Stage') === -1) {
                    window.localStorage.removeItem('latestResults');
                    SearchResultTraversal.latestResults = [];
                }

                // Removing the openAnnotateSearchValue being used to display searched text on a document.
                if (window.localStorage.getItem('openAnnotateSearchValue') && (fragment.indexOf('Stage') === -1 && fragment.indexOf('search') === -1)) {
                    window.localStorage.removeItem('openAnnotateSearchValue');
                }
            },
            resetTabTitle: function(fragment) {
                if(fragment.indexOf('Stage') === -1){//Anything other than stage 
                    var title = Router.config.defaultTabTitle || HPIConstants.AppName;
                    $("title").text(title);
                }
            },

            security: function(fragment, args, next) {

                this.resetTabTitle(fragment);
                this.removeSearchResults(fragment);
                this.unlockIndexerDoc();
                if(fragment !== "error/userDoesNotExist" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.ExistenceError) {
                    Backbone.history.navigate("/error/userDoesNotExist", { trigger: true }, { replace: true });
                } else if(fragment !== "error/userDisabled" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.DisabledError) {
                    Backbone.history.navigate("/error/userDisabled", { trigger: true }, { replace: true });
                } else if(fragment !== "error/fetchingUserData" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.FetchingDataError) {
                    Backbone.history.navigate("/error/fetchingUserData", { trigger: true }, { replace: true });
                } else if (fragment.indexOf("admin") === -1 && !_.contains(whiteList, fragment)) {
                    // save annotations before navigating away
                    // this is the normal case when navigating to Dashboard, Collections, etc
                    this.autoSaveAnnotations();
                    //see if our trac configs are already loaded/we have any
                    if (!app.context.tracConfigs) {
                        var deferred = $.Deferred();
                        app.context.configService.initServicesThatRequireConfigs(deferred);
                        $.when(deferred).done(function() {
                            if (app.context.tracConfigs === undefined || app.context.tracConfigs.length === 0) {
                                //no tracs configured/allowed access to, and not trying to get to admin
                                Backbone.history.navigate("/tracAuthorizationError", { trigger: true }, { replace: true });
                            } else {
                                //Everything is fetched, so continue into the app
                                next();
                            }
                        });
                    } else {
                        app.trigger("closeTour");
                        next();
                    }
                } else {
                    //we're in the admin
                    next();
                }
            },

            tracAllowed: function(trac) {
                var tracAllowed;
                if (app.context.tracConfigs) {
                    tracAllowed = _.contains(app.context.tracConfigs.pluck("name"), trac);
                } else {
                    app.context.configService.getTracConfigs(function(tracConfigs) {
                        tracAllowed = _.contains(tracConfigs.pluck("name"), trac);
                    });
                }
                return tracAllowed;
            },

            autoSaveAnnotations: function() {
                Router.checkToSaveAnnotations();
            },

            unlockIndexerDoc: function() {
                if (app.idToUnlock) {
                    $.ajax({
                        url: app.serviceUrlRoot + '/content/unlockDocument?id=' + app.idToUnlock,
                        type: "GET",
                        success: function() {
                            app.log.debug("unlocked document");
                            app.idToUnlock = null;
                        }
                    });

                }
            }
        });

        Router.config = module.config();
        //save annotations when navigating away using a router that overrides AbstractRouter's before hook
        Router.checkToSaveAnnotations = function() {
            if (app.prevRoute && app.openAnnotate && app.prevRoute.indexOf("Stage") !== -1) {
                app.openAnnotate.trigger("cleanup");
            }
        };

        Router.onHistoryRoute = function() {
            Router.checkToSaveAnnotations();
            app.prevRoute = Backbone.history.fragment;
        };
        
        Backbone.history.on("route", Router.onHistoryRoute);

        return Router;
    });