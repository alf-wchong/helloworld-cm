define([
	// Application.
	"app",
	"abstractrouter",
	"dashboard"
],

	function(app, AbstractRouter, Dashboard) {
		"use strict";

		//All routes in this router are expected to use the one column layout setup.
		//This function ensures the correct layout and the correct subviews
		var setupLayout = function(config){

			$("body").removeClass(); // removes all classes (such as login)

			var layout = app.useLayout("layout-1-col");

			//Remove anything in the top outlet.
			var topOutlet = layout.getView("#top-content-outlet");
			if (topOutlet) {
				topOutlet.remove();
			}

			var contentOutlet = layout.getView("#content-outlet");
			if (contentOutlet) {
				// make sure the content outlet has the correct sub-view
				if (contentOutlet.name !== "dashboard") {
					contentOutlet.remove();
					layout.setViews({
						"#content-outlet" : new Dashboard.Views.Layout({config: config})
					});
				}
			}
			else {
				layout.setView("#content-outlet", new Dashboard.Views.Layout({config: config}));
			}

			return layout;
		};


		// Defining the application router, you can attach sub routers here.
		var Router = AbstractRouter.extend({

			routes: {
				"dashboard" : "dashboard"
			},

			dashboard: function() {

				app.context.configService.getDashboardConfig(function(config){
					app.context.configService.getUserPreferences(function(){
						var layout = setupLayout(config);
						layout.render();
					});
				});

			}
		});

		return Router;

	});