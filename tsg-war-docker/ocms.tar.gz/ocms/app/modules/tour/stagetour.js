// StageTour module
define([
  // Application
  "app",
  "tourist",
  "jquery",
  "underscore"
  ],
  
  // Map dependencies from above array
  function(app, Tourist, $, _)
  {
    "use strict";
    
    // Create a new module
    var StageTour = app.module();
    
    StageTour.Views.Layout = Backbone.Layout.extend({
      initialize: function() {
        StageTour.ActiveTours = [];
      },      
      afterRender: function() {    
        var self = this;
                
        self.listenTo(app, "stageRendered", function(data){  
          var newTour = new StageTour.Tour();
          
          app.context.configService.getUserPreferences(function(config){
            if(StageTour.ActiveTours.length === 0 || StageTour.ActiveTours === undefined){
              if (config.get("tours").stage){                
                if (data === "wizard"){
                  StageTour.IsWizard = true;
                }
                if (data === "noDocument"){
                  StageTour.NoDocument = true;
                }        
                StageTour.ActiveTours.push(newTour);
                newTour.start();
  
                app.trigger("preventScrolling");
              }
              else {
                app.log.debug("there is already an active stage tour");
              }
          }
          });
        });        
                
        app.log.debug("Stage Tour Layout Rendered");
      },
      
      removeInstances: function() {
        
        var self = this;
        self.activeTours = [];
        StageTour.ActiveTours = [];
      }
    });
    
    StageTour.ActiveTours = [];
    
    StageTour.IsWizard = false;
  
    StageTour.NoDocument = false;
      
    StageTour.Tour = function(options) {
      app.log.debug("Stage Tour Initializing");
      var self = this;
      
      _.extend(this, Backbone.Events);
      

      
      app.listenTo(app, "continueTour", function(){
        app.trigger("closeTour");
      });
      
      // prevents scrolling of the #leftBar while the tour is active
      self.preventScrolling = function(){
        $('#leftBar').on({ 'mousewheel': function(e) {
          
          if (e.target.id == 'el'){
              return;
          } 
          
          e.preventDefault();
          e.stopPropagation();
        }
        });      
      };     
       
      app.listenTo(app, "preventScrolling", function(){
        self.preventScrolling();
      });
      
      // reenables scrolling on #leftBar once the tour is over or exited
      self.enableScrolling = function(){
        $("#leftBar").unbind("mousewheel");
      };
      
      self.generateSearchResultTraversalContent = function(){
        var searchResultTraversalTitle = "<h3>" + window.localize("tour.stage.searchResultTraversal.title") + "</h3>";
        var searchResultTraversalContent = "<p>" + window.localize("tour.stage.searchResultTraversal.content") + "</p>";
        
        return searchResultTraversalTitle + searchResultTraversalContent;
      };  
      
      self.generateStageInfoContent = function(){
        var stageInfoTitle = "<h3>" + window.localize("tour.stage.stageInfo.title") + "</h3>";
        var stageInfoContent = "<p>" + window.localize("tour.stage.stageInfo.content") + "</p>";
        
        return stageInfoTitle + stageInfoContent;
      };

      self.generateFolderActionsContent = function(){
        var folderActionsTitle = "<h3>" + window.localize("tour.stage.folderActions.title") + "</h3>";
        var folderActionsContent = "<p>" + window.localize("tour.stage.folderActions.content") + "</p>";
        
        return folderActionsTitle + folderActionsContent;
      };
    
      self.generateRelatedObjectsContent = function(){
        var relatedObject = {};   
        var relatedObjectsTitle;
        var relatedObjectsContent;
        if (StageTour.NoDocument){
          relatedObjectsTitle = "<h3>" + window.localize("tour.stage.relatedObjects.title") + "</h3>";
          relatedObjectsContent = "<p>" + window.localize("tour.stage.relatedObjects.content.viewAllDocsNotVisible") + "</p>";
          relatedObject.content = relatedObjectsTitle + relatedObjectsContent;
          relatedObject.nextButton = true;
          
          return relatedObject;
        }
        else {
          relatedObjectsTitle = "<h3>" + window.localize("tour.stage.relatedObjects.title") + "</h3>";
          relatedObjectsContent = "<p>" + window.localize("tour.stage.relatedObjects.content.viewAllDocsVisible") + "</p>";        
          relatedObject.content = relatedObjectsTitle + relatedObjectsContent;
          relatedObject.nextButton = true; 
          
          return relatedObject;
        }
      };
  
      self.generateDocViewerContent = function(){
        var docViewerTitle = "<h3>" + window.localize("tour.stage.docViewer.title") + "</h3>";
        var docViewerContent = "<p>" + window.localize("tour.stage.docViewer.content") + "</p>";
        
        return docViewerTitle + docViewerContent;
      };
  
      self.generateClickDocumentContent = function(){
        var clickDocTitle = "<h3>" + window.localize("tour.stage.clickDoc.title") + "</h3>";
        var clickDocContent = "<p>" + window.localize("tour.stage.clickDoc.content") + "</p>";
        
        return clickDocTitle + clickDocContent;
      };

      self.generateDocActionsContent = function(){
        var docActionsTitle = "<h3>" + window.localize("tour.stage.docActions.title") + "</h3>";
        var docActionsContent = "<p>" + window.localize("tour.stage.docActions.content") + "</p>";
        
        return docActionsTitle + docActionsContent;
      };

      self.generateStageExitContent = function(){
        var stageExitExited = "<h3>" + window.localize("tour.stage.exit.exited") + "</h3>";
        var stageExitContent = "<p>" + window.localize("tour.stage.exit.content") + "</p>";
                
        return stageExitExited + stageExitContent;
      };

      self.generateStageCompleteContent = function(){          
        var stageExitComplete = "<h3>" + window.localize("tour.stage.exit.complete") + "</h3>"; 
        var stageExitContent = "<p>" + window.localize("tour.stage.exit.content") + "</p>";
                
        return stageExitComplete + stageExitContent;
      };
      
      if ($("#nextResult").is(":visible") && $("#nextResult").length){
        self.traversalTarget = "#nextResult";
      }
      
      if ($("#stageInfoLabel").is(":visible") && $("#stageInfoLabel").length){
        self.stageInfoTarget = "#stageInfoLabel";
      }
      
      if ($("#tourFolderActions").is(":visible") && $("#tourFolderActions").length){
        self.folderActionsTarget = "#tourFolderActions";
      }
      
      if ($("#tourRelatedObjects").is(":visible") && $("#tourRelatedObjects").length){
        // self.relatedObjectsTarget = "#leftBar";
        self.relatedObjectsTarget = "#tourRelatedObjects";
      }
      
      if ($("#docView-0").is(":visible") && $("#docView-0").length){
        self.docViewerTarget = "#docView-0";
      }
      
      if ($("#tourDocument").length){
        self.docActionsTarget = "#tracInfo";
      }
      if ($("#action-container-0").is(":visible")){
          self.docActionsTarget = "#action-container-0";
      }

      app.listenTo(app, "relatedObjectsClick", function(){
        // don't close tour for no document scenarios 
        if (!StageTour.NoDocument){
          app.trigger("closeTour");
        }
      });
      
      self.tourSteps = [
        {
          target: self.traversalTarget,
          content: self.generateSearchResultTraversalContent(),
          my: 'left center',
          at: 'right center',
          nextButton: true,
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {},
          teardown: function() {}
        },{
          target: self.stageInfoTarget,
          content: self.generateStageInfoContent(),
          my: 'left center',
          at: 'right center',
          nextButton: true,
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {},
          teardown: function() {}
        },{
          target: self.folderActionsTarget,
          content: self.generateFolderActionsContent(),
          my: 'left center',
          at: 'right center',
          nextButton: true,
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {
            $('#leftBar').animate({ scrollTop: $('#leftBar').offset().top - 60}, 'slow');
          },
          teardown: function() {}
        },{
          target: self.relatedObjectsTarget,
          my: 'left center',
          at: 'right top',
          nextButton: true,
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {
            $("#leftBar").animate({ scrollTop: $('#leftBar')[0].scrollHeight}, 1000);
            var data = self.generateRelatedObjectsContent();
            app.listenTo(app, "relatedObjectsClick", function(){
              if (!data.nextButton && tour !== undefined && tour.model.get("current_step") !== null && tour.model.get("current_step").target.selector === "#tourRelatedObjects"){
                tour.next();
              }
            });
            return {
              content: data.content,
              nextButton: data.nextButton
            };
          },
          teardown: function() {
            $('#leftBar').animate({ scrollTop: $('#leftBar').offset().top - 60}, 'slow');
          }
            },
              {
          target: self.docViewerTarget,
          content: self.generateDocViewerContent(),
          my: 'right center',
          at: 'left center',
          nextButton: true,
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {},
          teardown: function() {}
        },{
          target: self.docClickTarget,
          content: self.generateClickDocumentContent(),
          my: 'bottom center',
          at: 'bottom center',
          closeButton: true,
          highlightTarget: true,
          setup: function(tour, options) {
            app.listenTo(app, "continueTour", function(){ 
              if (tour !== undefined && tour.model.get("current_step") !== null && tour.model.get("current_step").target.selector === "#tourDocument"){  
               tour.next();
              }
            });
          },
          teardown: function() {
            self.enableScrolling();
          }
        },{
          target: self.docActionsTarget,
          content: self.generateDocActionsContent(),
          my: 'top center',
          at: 'bottom center',
          closeButton: true,
          highlightTarget: true,
          nextButton: true,
          setup: function(tour, options) {
          app.listenTo(app, "docActionClicked", function(){
          tour.next();
          });
          },
          teardown: function() {
            app.trigger("stageTourClosed");
          }
        }
      ].filter(function(obj) {
      return obj.target;
      });
      
      var cancelStep = {
        target: $("#userPreferencesBtn"),
        content: self.generateStageExitContent(),
        my: 'top center',
        at: 'bottom center',
        nextButton: true,
        closeButton: true,
        highlightTarget: true,
        setup: function(tour, options) {
          app.trigger("stageTourClosed");
          self.enableScrolling();
        },
        teardown: function() {}
      };
      
      var successStep = {
        content: self.generateStageCompleteContent(),
        target: $("#userPreferencesBtn"),
        my: 'top center',
        at: 'bottom center',
        closeButton: true,
        nextButton: true,
        highlightTarget: true,
        setup: function(tour, options) {
          app.trigger("stageTourClosed");
          self.enableScrolling();
        },
        teardown: function() {}
      };
      
      return new Tourist.Tour({
        steps: this.tourSteps,
        tipOptions: {
          showEffect: 'slidein'
        },
        stepOptions: {  
        },
        tipClass: 'Bootstrap',
        cancelStep: cancelStep,
        successStep: successStep
      });
    };
    
    return StageTour;
  });