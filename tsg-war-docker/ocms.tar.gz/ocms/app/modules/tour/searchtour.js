// SearchTour module
define([
        // Application.
        "app",
        "tourist",
        "jquery",
        "underscore"
    ],

    // Map dependencies from above array.
    function(app, Tourist, $, _) {

        "use strict";

        // Create a new module.
        var SearchTour = app.module();

        SearchTour.Views.Layout = Backbone.Layout.extend({
            initialize: function() {
                SearchTour.ActiveTours = [];
            },

            afterRender: function() {
                var self = this;

                self.listenTo(app, "searchTourStart", function(configName) {
                    app.context.configService.getSearchConfigByName(configName, function(searchConfig){       
                        var newTour = new SearchTour.Tour({config:searchConfig});

                        if(SearchTour.ActiveTours.length === 0 || SearchTour.ActiveTours === undefined){
                            app.context.configService.getUserPreferences(function(config){
                                if (config.get("tours").search){
                                    app.log.debug("search tour started");
                                    SearchTour.ActiveTours.push(newTour);
                                    newTour.start();
                                    app.trigger("disableSearchTabs");
                                }
                            });
                        } else {
                            app.log.debug("there is already an active search tour");
                        }
                    });
                });
            },
            removeInstances: function() {
              
                var self = this;
                self.activeTours = [];
                SearchTour.ActiveTours = [];
            }
        });
        
        SearchTour.ActiveTours = [];

        SearchTour.Tour = function(options) {
            app.log.debug("Search Tour Initializing");
            var self = this;
            var searchConfig = options.config;
            
            self.searchConfig = searchConfig;
            self.quickSearchEnabled = self.searchConfig.get("sidebarConfig").get("quickSearchEnabled");
            self.savedSearchEnabled = self.searchConfig.get("sidebarConfig").get("savedSearchEnabled");
            self.attributeSearchEnabled = self.searchConfig.get("sidebarConfig").get("attributeSearchConfig").get("enabled");
            self.advancedSearchEnabled = self.searchConfig.get("sidebarConfig").get("advancedSearchConfig").get("enabled");
            self.facetSearchEnabled = self.searchConfig.get("sidebarConfig").get("facetConfig").get("enabled");
                  
            if (self.savedSearchEnabled){
               self.savedSearchTarget = ".col-md-12";
            }
            if(self.quickSearchEnabled){
              self.quickSearchTarget = "#quick-search-form";
            }
            if (self.attributeSearchEnabled || self.advancedSearchEnabled){
              self.enabledSearchesTarget = $("#tourTabs");
              self.searchBtnTarget = "#searchtab-outlet";
            }
            
            if ($("#tracSwitcher").is(":visible")){
              self.tracSwitcherTarget = "#tracSwitcher";
            }
            
           if ($("#searchType").is(":visible")){
              self.searchTypeTarget = "#searchType";
            }

            $(".nav-tabs a[data-toggle=tab]").on("click", function(){
              app.trigger("checkTab");        
            });
                
            _.extend(self, Backbone.Events);
            
            
            // disables functionality of the search tabs while the tour is active
            self.disableSearchTabs = function(){
              $('#search-sidebar-tabs').on({ "click": function(e) {                
                if (e.target.id == 'el'){
                    return;
                } 
                
                e.preventDefault();
                e.stopPropagation();
              }
              });      
            };     
             
            app.listenTo(app, "disableSearchTabs", function(){
              // disables the search tabs if a tour is active
              if (SearchTour.ActiveTours.length){
                self.disableSearchTabs();
              }
            });
            
            // reeenables functionality of the search tabs
            self.enableSearchTabs = function(){
              $("#search-sidebar-tabs").unbind("click");
            };        
            
            // localization functions

            self.generateTracTypeContent = function(){
              var tracTypeTitle = "<h3>" + window.localize("tour.search.tracType.title") + "</h3>";
              var tracTypeContent = "<p>" + window.localize("tour.search.tracType.content") + "</p>";
              
              return tracTypeTitle + tracTypeContent;
            };

            self.generateSearchTypeContent = function(){
              var searchTypeTitle = "<h3>" + window.localize("tour.search.searchType.title") + "</h3>";
              var searchTypeContent = "<p>" + window.localize("tour.search.searchType.content") + "</p>";
              
              return searchTypeTitle + searchTypeContent;
            };

            self.generateSavedSearchContent = function(){
              var savedSearchTitle = "<h3>" + window.localize("tour.search.savedSearch.title") + "</h3>";
              var savedSearchContent = "<p>" + window.localize("tour.search.savedSearch.content") + "</p>";
              
              return savedSearchTitle + savedSearchContent;
            };
            
            self.generateQuickSearchContent = function(){
              var quickSearchTitle = "<h3>" + window.localize("tour.search.quickSearch.title") + "</h3>";
              var quickSearchContent = "<p>" + window.localize("tour.search.quickSearch.content") + "</p>";
              
              return quickSearchTitle + quickSearchContent;
            };

            self.generateEnabledSearchesContent = function(){
              var enabledSearchesTitle = "<h3>" + window.localize("tour.search.enabledSearches.title") + "</h3>";
              var enabledSearchesContentStart = "<p>" + window.localize("tour.search.enabledSearches.contentStart");
              var enabledSearchesAttribute = "<p>" + window.localize("tour.search.enabledSearches.attribute") + "</p> ";
              var enabledSearchesAdvanced = "<p>" + window.localize("tour.search.enabledSearches.advanced") + "</p> ";
              
              var enabledSearchesContent = enabledSearchesTitle + enabledSearchesContentStart;
              
              // if attribute search is configured, add info text to the step
              if (self.attributeSearchEnabled){
                enabledSearchesContent += enabledSearchesAttribute;
              }
              // if advanced search is configured, add info text to the step
              if (self.advancedSearchEnabled){
                enabledSearchesContent += enabledSearchesAdvanced;
              }
                        
              return enabledSearchesContent;
            };

            self.generateSearchButtonContent = function(){
              return "<p>" + window.localize("tour.search.searchButton.content") + "</p>"; 
            };

            self.generateSearchResultsContent = function(){
              var searchResultsTitle = "<h3>" + window.localize("tour.search.searchResults.title") + "</h3>";
              var searchResultsContent = "<p>" + window.localize("tour.search.searchResults.content") + "</p>";
              
              return searchResultsTitle + searchResultsContent;
            };

            self.generateSearchExitContent = function(){
              var searchExitTitle = "<h3>" + window.localize("tour.search.exit.title") + "</h3>";
              var searchExitContent = "<p>" + window.localize("tour.search.exit.content") + "</p>";
              
              return searchExitTitle + searchExitContent;
            };

            //define our tour's steps
            self.steps = [
            {
                target: self.tracSwitcherTarget,
                content: self.generateTracTypeContent(),
                my: 'left center',
                at: 'right center',
                nextButton: true,
                closeButton: true,
                highlightTarget: true,
                setup: function(tour, options) {},
                teardown: function() {}
            },{
                target: self.searchTypeTarget,
                content: self.generateSearchTypeContent(),
                my: 'left center',
                at: 'right center',
                nextButton: true,
                closeButton: true,
                highlightTarget: true,
                setup: function(tour, options) {},
                teardown: function() {}
            },{
                target: self.savedSearchTarget,
                content: self.generateSavedSearchContent(),
                my: 'left center',
                at: 'right center',
                highlightTarget: false,
                nextButton: true,
                closeButton: true,
                setup: function(tour, options) {},
                teardown: function() {}
            },{
                target: self.quickSearchTarget,
                content: self.generateQuickSearchContent(),
                my: 'left center',
                at: 'right center',
                nextButton: true,
                closeButton: true,
                highlightTarget: true,
                setup: function(tour, options) {},
                teardown: function() {}
            },{
                target: self.enabledSearchesTarget,
                content: self.generateEnabledSearchesContent(),
                my: 'left center',
                at: 'right top',
                closeButton: true,
                highlightTarget: true,
                nextButton: true,
                setup: function(tour, options) {
                    // $(".nav-tabs a[data-target=#attributeSearch]").on("dblclick", this.advanceStep);
                    // $(".nav-tabs a[data-target=#advancedSearch]").on("dblclick", this.advanceStep);
                },
                teardown: function() {
                    // $(".nav-tabs a[data-target=#attributeSearch]").off("dblclick", this.advanceStep);
                    // $(".nav-tabs a[data-target=#advancedSearch]").off("dblclick", this.advanceStep);
                },
                bind: ["advanceStep"],
                advanceStep: function(tour, options){
                    tour.next();
                }
            },{
                target: self.searchBtnTarget,
                content: self.generateSearchButtonContent(),
                my: 'left center',
                at: 'bottom center',
                nextButton: true,
                highlightTarget: true,
                setup: function(tour, options) {
                    $('html, body').animate({ scrollTop: $(document).height()-$(window).height() + 60}, 1400, "swing");
                },
                teardown: function() {
                    $('body').animate({ scrollTop: $('body').offset().top - 60}, 'swing');
                }
            },{
                target: ".table-view",
                content: self.generateSearchResultsContent(),
                my: 'top center',
                at: 'bottom center',
                nextButton: true,
                closeButton: true,
                highlightTarget: true,
                setup: function(tour, options) {},
                teardown: function() {
                    app.trigger("searchTourClosed");
                }
            }
        ].filter(function (obj) {
            return obj.target;
        });
            
            var cancelStep = {
              target: "#userPreferencesBtn",
              content: self.generateSearchExitContent(),
              my: 'top center',
              at: 'bottom center',
              closeButton: true,
              nextButton: true,
              highlightTarget: true,
              setup: function(tour, options) {
                app.trigger("searchTourClosed");
                self.enableSearchTabs();
              },
              teardown: function() {
              }
            };
            
            return new Tourist.Tour({
                steps: self.steps,
                tipOptions: {
                    showEffect: 'slidein'
                },
                stepOptions: {
                },
                tipClass: 'Bootstrap',
                cancelStep: cancelStep,
                successStep: cancelStep
            });
        };

        // Return the module for AMD compliance.
        return SearchTour;
    });
