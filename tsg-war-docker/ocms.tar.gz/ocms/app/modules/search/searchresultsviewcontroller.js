define([
        // Application.
        "app",
        "modules/common/hpiconstants"
    ],
    
    function(app, HPIConstants) {
        "use strict";

        var SearchResultsViewController = {};

        SearchResultsViewController.Model = Backbone.Model.extend({
            initialize: function(){
                this.tableEventsRef =  _.extend({}, Backbone.Events);
                this.searchStatisticsEnabled = true;
                this.useConfigs = true;
				this.enableColumnReorder = true;
                this.stageAttributeSearchEnabled = false;
            },
            determineResultsPerPage: function(){
                var self = this;
                var deferred = $.Deferred();
                    
                app.context.configService.getApplicationConfig(function(config) {                    
                    app.context.configService.getUserPreferences(function(currentUserPreferences) {                     
                        var defaultResultsPerPage = parseInt(config.get('searchResultsNumDefault'), 10);
                        // If we are going into standardized table view
                        if(app.searchView === HPIConstants.TableView.ViewType.StandardTableView){
                            // If in standard view we will want to set results per page to the default configured in the admin. 
                            self.resultsPerPage = defaultResultsPerPage;        
                        } else {
                            // If not in std view then we can apply the results per page from user preferences 
                            self.resultsPerPage = currentUserPreferences.get("resultsPerPage") ? currentUserPreferences.get("resultsPerPage") : defaultResultsPerPage;
                        }
                        deferred.resolve();
                    });
                });
                return deferred.promise();
            },
            resetGrid: function(){
                // This ensured that no rows are selected in the tableview and pagination is not remembered
                this.grid = null;
                // This is needed to make sure that the selected results badge is correctly updated and that the actions dropdown has the correct information about the number of documents selected. 
                this.tableEventsRef.trigger("search:selectedResults", []);
            }
        
        });
             
        return SearchResultsViewController;

    });
