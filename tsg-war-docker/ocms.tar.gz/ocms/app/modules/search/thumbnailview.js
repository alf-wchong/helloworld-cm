define("thumbnailview", [
        "app",
        "modules/common/spinner",
        "modules/common/action",
        "modules/common/booleanutils",
        "modules/actions/actionmodules",
        "module",
        "modules/common/hpiconstants",
        "jqueryDeparam"
    ],
    function(app, HPISpinner, Action, BooleanUtils, ActionModules, module, HPIConstants) {
        "use strict";

        var ThumbnailView = app.module();

        ThumbnailView.View = Backbone.Layout.extend({
            template: 'actions/viewalldocuments/thumbnailview',
            events: {
                "click .hpiThumbnail": "loadDocument",
                "click .selectThumbnail": "selectedThumbnailsChanged",
                "click .thumbnailDualPane": "launchDualPane"
            },
            initialize: function(options) {
                var self = this;
                this.searchResultsViewController = options.searchResultsViewController;
                this.collection = options.collection.fullCollection;
                this.options = options;
                this.paginationCollection = options.collection;
                // this is done for unit testing purposes since we can't access the module from the spec file
                var configuredMimetypeWhiteList = module.config().mimetypeWhiteList || this.options.mimetypeWhiteList;
                // whitelist that determines which ocos to fetch thumbnails for; uses project configured whitelist if it's defined
                this.mimetypeWhiteList = configuredMimetypeWhiteList || HPIConstants.ThumbnailView.MimetypeWhitelist;

                //The array of ocos
                this.ocos = this.collection.models;
                
                //All of the URLs for the ocos
                this.urls = [];

                //The URLs to actually display based on pageSize and currentPage
                this.urlsToShow = [];

                // all thumbnail images that will be lazy loaded
                this.lazyThumbnailImgs = [];

                //The deferreds that hold the thumbnail requests
                this.defs = [];

                //Getting the thumbnails the first time
                this.getThumbnails(this.ocos);

                // The thumbnails the user currently has selected
                this.selectedThumbnails = {};
            
                this.applyListeners();

                // Setting the correct page number for thumbnail view so that the correct results are retrieved
                this.searchResultsViewController.tableEventsRef.trigger("search:result:controls:setCurrentPage", this.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1);

                this.searchResultsViewController.determineResultsPerPage().done(function() {
                    self.searchResultsViewController.grid.getData().setPagingOptions({
                        pageSize: self.searchResultsViewController.resultsPerPage
                    });

                    if(self.searchResultsViewController.textFilter){
                        self.applyFilteredResults(self.searchResultsViewController.grid.getData().getFilteredItems());

                        // Applying the text filter only gives back all the results that pass through the filter
                        // It does not take into account the page number or the results per page
                        // so, we explicitly make sure that the correct results are displayed here. 
                        var pageNum = self.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1;

                        var startIdx = (pageNum-1)*self.searchResultsViewController.resultsPerPage;
                        var endIdx = (pageNum)*self.searchResultsViewController.resultsPerPage;
                        
                        self.urlsToShow = self.urlsToShow.slice(startIdx, endIdx);

                        self.searchResultsViewController.tableEventsRef.trigger("search:updateTextFilter", self.searchResultsViewController.textFilter);
                    }
                });

                //setting the paging info on initialize
                this.searchResultsViewController.grid.getData().onPagingInfoChanged.subscribe(function(e, pagingInfo) {
                    if (!app.searchView || app.searchView === "table") {
                        return;
                    }
                    app.context.configService.getApplicationConfig(function(config) {
                        // make sure window.resultsPerPage has a value
                        var defaultResults = parseInt(config.get('searchResultsNumDefault'), 10);

                        if (!self.searchResultsViewController.resultsPerPage) {
                            self.searchResultsViewController.resultsPerPage = defaultResults ? defaultResults : 10;
                        }

                        //The defaulting the page size/resultsPerPage to what is stored on window.  Subsequent renders
                        //will use the last size used.
                        pagingInfo.pageSize = pagingInfo.pageSize < 1  ? self.searchResultsViewController.resultsPerPage : pagingInfo.pageSize;

                        //We can't be at page 0
                        pagingInfo.pageNum = (_.isNaN(pagingInfo.pageNum) || pagingInfo.pageNum < 1) ? 1 : pagingInfo.pageNum;

                        //Ensuring the totalPages is correct
                        pagingInfo.totalPages = Math.ceil(pagingInfo.totalRows / pagingInfo.pageSize);

                        //Firing trigger to searchresultcontrols with new info.
                        self.searchResultsViewController.tableEventsRef.trigger("slickgrid:pagination:change", pagingInfo);
                    });
                });

                this.populateSelectedResultsFromTableView();
            },
            populateSelectedResultsFromTableView: function() {
                // grab all the selected ids and ocos from tableview - we'll update them in selectedThumbnailsChanged
                _.each(this.searchResultsViewController.grid.getSelectedIds(), function(id) {
                    // you can't assume all of these ocos are defined at this point if they have been
                    // filtered out of the grid with facets, so instead we use the value we have
                    var oco = this.searchResultsViewController.grid.getSelectedOCObyId(id);
                    this.selectedThumbnails[id] = oco;
                }, this);
            },
            applyFilteredResults: function(filteredResults) {
                var idsToKeep = _.pluck(filteredResults, HPIConstants.Properties.ObjectId);
                this.urlsToShow = this.urls.slice(0);

                this.urlsToShow = _.filter(this.urlsToShow, function(oco) {
                    return _.contains(idsToKeep, oco.id);
                });
            },
            getSelectedIndicesOnCurrentPage: function() {
                var self = this;
                // visible as in all names you could see currently flipping through pages
                var visibleObjNames = _.pluck(self.urlsToShow, HPIConstants.Properties.ObjectName);
                var selectedVisibleObjNames = _.intersection(visibleObjNames, self.searchResultsViewController.grid.getSelectedObjectNames());

                var selectedIndices = _.map(selectedVisibleObjNames, function(name) {
                    return _.indexOf(visibleObjNames, name);
                });

                return selectedIndices;
            },
            populateSelectedThumbnailsOnCurrentPage: function() {
                var self = this;

                var selectedIndices = this.getSelectedIndicesOnCurrentPage();
                //Transferring the information of selected documents from the searchResultsViewController to the selectedThumbnails object
                _.each(selectedIndices, function(selectedIdx) {

                    var id = self.urlsToShow[selectedIdx].id;
                    // You can assume that this object will be visible on the grid at this time
                    var oco = self.searchResultsViewController.grid.getData().getItemById(id);
                    self.selectedThumbnails[id] = oco;
                });
            },
            switchingToTableView: function() {
                // Ensuring that the information about selected rows is transferred back to
                // the tableviewController object just before switching back to tableview.
                var selectedRows = this.searchResultsViewController.grid.getSelectedRowsOnCurrentPage();
                this.searchResultsViewController.grid.setSelectedRows(selectedRows);
            },
            applyListeners: function(){
                var self = this;
                //Listening to when the number of results per page changes
                this.listenTo(this.searchResultsViewController.tableEventsRef, "change:resultsPerPage", function() {
                    //Resetting the 'urlsToShow' to be all of the URLs
                    //This is how you clone an array
                    self.urlsToShow = self.urls.slice(0);

                    //There are more total URLs than desired number of results
                    if (self.urlsToShow.length > self.searchResultsViewController.resultsPerPage) {
                        self.urlsToShow.length = self.searchResultsViewController.resultsPerPage;
                        self.render();
                    } else {
                        //There are less total URLs than desired number of results
                        self.urlsToShow = self.urls;
                        self.render();
                    }

                    //Setting the paging options in slickgrid so that the related events fire
                    self.searchResultsViewController.grid.getData().setPagingOptions({ pageSize: self.searchResultsViewController.resultsPerPage });
                });
                //Listener for when a specific page is selected
                this.listenTo(this.searchResultsViewController.tableEventsRef, "thumbnail:goToPage", this.goToPage);

                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:switching-to-table-view", this.switchingToTableView);

                //Listener for when filtered by input text
                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:text:filter:change", this._updateThumbnailDocView);

                //Listener for then the filtered results come back from the SlickGrid listener
                this.listenTo(this.searchResultsViewController.tableEventsRef, "rowCountChanged", function(filteredResults) {
                    self.applyFilteredResults(filteredResults);
                    self.render();
                });

                this.listenTo(this.searchResultsViewController.tableEventsRef, "resultsHaveMutated tableview:tableAfterGridSetupDone", function(evt) {
                    //the length and models on this collection need to be updated to get the correct values
                    self.paginationCollection.length = self.collection.length;
                    self.paginationCollection.models = self.collection.models;
                    self.searchResultsViewController.grid.getData().setItems(self.paginationCollection, "objectId");
                    
                    //making sure that the paging is correct
                    self.searchResultsViewController.grid.getData().setPagingOptions({
                        pageSize: self.searchResultsViewController.resultsPerPage
                    });
                }, this);

                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:facet", function(filteredResults){
                    //fullCollection contains the updated collection of results based on facet search
                    self.ocos = filteredResults.fullCollection.models;
                    self.urls = [];
                    self.urlsToShow =[];
                    self.searchResultsViewController.grid.getData().refresh();
                    self.getThumbnails(self.ocos);

                    var startIdx = self.searchResultsViewController.grid.getData().getPagingInfo().pageSize * self.searchResultsViewController.grid.getData().getPagingInfo().pageNum;
                    var endIdx = startIdx + self.searchResultsViewController.grid.getData().getPagingInfo().pageSize;

                    self.urlsToShow = self.urlsToShow.slice(startIdx, endIdx > self.urlsToShow.length ? self.urlsToShow.length : endIdx);

                    //Makes sure that text filter is applied if there is any 
                    if(this.searchResultsViewController.textFilter){
                        self.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
                        self.searchResultsViewController.tableEventsRef.trigger("rowCountChanged", self.searchResultsViewController.grid.getData().getFilteredItems());
                    }
                        
                    self.render();
                });

                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:removeAllChecked", this.deselectAllThumbnails);

                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:checkAllResults", this.selectAllThumbnails);
            },
            goToPage: function(options) {
                var pageToGoTo = options.pageToGoTo;
                var pageSize = options.pageSize;

                //Getting the first and last thumbnail to show based on pageSize and pageNumber
                var startIdx = pageSize * (pageToGoTo - 1);
                var endIdx = startIdx + pageSize;

                //Copying all URLs
                this.urlsToShow = this.urls.slice(0);

                // Update URLs to show to only include filtered items
                if (this.searchResultsViewController.textFilter) {
                    this.applyFilteredResults(this.searchResultsViewController.grid.getData().getFilteredItems());
                }

                //Getting the correct range of urls based on 'startIdx' and 'endIdx'
                this.urlsToShow = this.urlsToShow.slice(startIdx, endIdx > this.urlsToShow.length ? this.urlsToShow.length : endIdx);
                this.render();

                this.searchResultsViewController.grid.getData().setPagingOptions({ pageNum: options.pageToGoTo - 1, pageSize: options.pageSize });

                // Need to recalculate rows for new pages based on global object id list
                this.populateSelectedThumbnailsOnCurrentPage();
            },
            selectAllThumbnails: function() {
                var self = this;
                var visibleThumbnails = $('.thumbnails input:checkbox');

                // add just the thumbnails visible on this page
                _.each(visibleThumbnails, function(thumbnail) {
                    var id = thumbnail.getAttribute('objId');
                    // You may assume this item is available on the grid at this time
                    var oco = self.searchResultsViewController.grid.getData().getItemById(id);
                    self.selectedThumbnails[id] = oco;
                    $(thumbnail).parents('.hpiThumbnail').addClass('selectedThumbnail');
                });
                                
                // check all checkboxes
                visibleThumbnails.prop("checked", true);
            
                this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedThumbnails));
            },
            // resets the selected thumbnails
            resetSelectedThumbnails: function() {
                this.selectedThumbnails = {};
            },
            _updateNumberOfDocsPerPage: function(){
                if(this.urlsToShow.length > 0){
                    var pageNum = this.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1;
                    
                    var startIdx = (pageNum-1)*this.searchResultsViewController.resultsPerPage;
                    var endIdx = (pageNum)*this.searchResultsViewController.resultsPerPage;

                    this.urlsToShow = this.urlsToShow.slice(startIdx, endIdx > this.urlsToShow.length ? this.urlsToShow.length : endIdx);
                }
            },

            _updateThumbnailDocView: function(textFilter){
                //Copying all URLs
                this.urlsToShow = this.urls.slice(0);

                //The text argument passed to the filter.
                this.searchResultsViewController.grid.getData().setFilterArgs({ text: textFilter.trim() });

                //Refreshing the data based on the filter.
                this.searchResultsViewController.grid.getData().refresh();

                if(textFilter){
                    this.applyFilteredResults(this.searchResultsViewController.grid.getData().getFilteredItems());
                }

                this._updateNumberOfDocsPerPage();

                this.searchResultsViewController.tableEventsRef.trigger('filter:collection', this.paginationCollection);
                
                // When you perform a text search which returns no results and then add facets, the items are removed from grid object.
                // So to reset items we must update results from the facets. 
                if(!this.searchResultsViewController.grid.getData().getItems().length){

                    this.searchResultsViewController.tableEventsRef.trigger("search:updateFacetResults");

                }
                this.render();
            },
            // resets selected thumbnails and deselects all thumbnail checkboxes
            deselectAllThumbnails: function() {
                var visibleThumbnails = $('.thumbnails input:checkbox');
                this.resetSelectedThumbnails();
                                
                // uncheck all checkboxes
                visibleThumbnails.prop("checked", false);
                _.each(visibleThumbnails, function(thumbnail) {
                    $(thumbnail).parents('.hpiThumbnail').removeClass('selectedThumbnail');
                });

                this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedThumbnails));
            },
            // handles a thumbnail's selection toggling
            selectedThumbnailsChanged: function(evt) {
                evt.stopPropagation();                
                var thumbnail = evt.currentTarget; 
                var objId = thumbnail.getAttribute("objId");
                // invariant that this object is available on the grid at this time
                var oco = this.searchResultsViewController.grid.getData().getItemById(objId);

                // determine if adding or removing the thumbnail
                if(thumbnail.checked) {
                    this.selectedThumbnails[objId] = oco;
                    $(thumbnail).parents('.hpiThumbnail').addClass('selectedThumbnail');
                } else {
                    delete this.selectedThumbnails[objId];
                    $(thumbnail).parents('.hpiThumbnail').removeClass('selectedThumbnail');
                }

                this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedThumbnails));
            },
            setupLazyLoad: function() {
                this.lazyThumbnailImgs = $('.thumbnailImg');

                // TODO: We should move other thumbnails related code to here as well,
                // e.g. loading spinner gif, animation-before-image-arrive, etc.
            },
            lazyLoad: function() {
                this.tempImagesToLoad = [];
                _.each(this.lazyThumbnailImgs, this.updateThumbnailImgsSrc, this);
                // set lazyThumbnailImgs with the unloaded images that haven't been in the viewport yet
                this.lazyThumbnailImgs = this.tempImagesToLoad;
                delete this.tempImagesToLoad;
            },
            updateThumbnailImgsSrc: function(img) {
                if( this.isInViewport(img) ) {
                    if (img.getAttribute('data-src')) {
                        img.src = img.getAttribute('data-src');
                        img.removeAttribute('data-src');
                    } 
                } else {
                    this.tempImagesToLoad.push(img);
                }
            },
            isInViewport: function(thumbnailElement) {
                // wrapping this in a jquery object for unit testing..
                var windowObj = $(window);
                // get the top coordinate of the element relative to the document
                var thumbnailTop = $(thumbnailElement).offset().top;
                // the viewport bottom is equal to the scrollbar position plus the window height
                var viewportBottom = windowObj.scrollTop() + windowObj.height();
                return thumbnailTop < viewportBottom;
            },
            getThumbnails: function(ocos) {
                var self = this;
                _.each(ocos, this.getThumbnailUrlObj, this);
                //When all of the thumbnails have been fetched...
                $.when.apply(null, this.defs).done(function() {
                    self.urlsToShow = self.urls;
                    self.render();
                });
            },
            // method used to build up url objects and determine thumbnail urls
            getThumbnailUrlObj: function(oco) {
                var ocoProps = oco.get('properties');
                var mimeType = ocoProps.mimeType || ocoProps.nativeMimetype;
                var isWhitelisted = _.contains(this.mimetypeWhiteList, mimeType);
                if(isWhitelisted) {
                    var self = this;
                    var def = $.Deferred();
                    oco.getThumbnail("medium", function(thumbnailURL) {
                        self.urls.push({
                            "thumbnailURL": thumbnailURL,
                            "objectName": ocoProps.objectName,
                            "id": ocoProps.objectId
                        });

                        def.resolve();
                    });

                    // Pushing on the deferred for the thumbnail call
                    this.defs.push(def);
                } else {
                    this.urls.push({
                        "thumbnailURL": "assets/css/styles/img/noThumbnailAvailable.png",
                        "objectName": ocoProps.objectName,
                        "id": ocoProps.objectId
                    });
                }
            },
            //function that launches the document
            loadDocument: function(evt) {
                // if the user is holding down the ctrl key, select the thumbnail instead of opening it
                if(evt.ctrlKey || evt.metaKey) {
                    evt.stopPropagation();
                    evt.currentTarget = $(evt.currentTarget).find('.selectThumbnail')[0];

                    // toggle the selection checkbox
                    $(evt.currentTarget).prop("checked", !$(evt.currentTarget).prop('checked'));                    
                    this.selectedThumbnailsChanged(evt);
                } else {
                    var objectId = evt.currentTarget.getAttribute("objId");
                    if (objectId) {
                        if(app.prevRoute.indexOf("search") === -1){
                            app.trigger("stage.refresh.documentId", objectId);
                            app.trigger("stage.refresh.showPane3", true);
                            //don't hide the left bar unless in a large view
                            //the left bar will go to the top for small views
                            if (window.innerWidth > 991) {
                                app.trigger("toggleLeftBar", false);
                            }
                        } else {
                            //open document in the context of search
                            app.routers.main.stageSimple(objectId);
                        }
                    }
                }
            },
            launchDualPane: function(evt) {
                evt.stopPropagation();
                app.trigger("stage.refresh.documentId2", {
                    objectId: evt.currentTarget.getAttribute("objId"),
                    context: "viewAllDocuments"
                });  
            },
            // Create our spinner until the element loads
            afterRender: function() {
                var self = this;
                //displays the no results box when the search returns no results 
                if (this.urlsToShow.length < 1) {
                    $("#thumbnailNoResults").show();
                } else {
                    $("#thumbnailNoResults").hide();

                    self.setupLazyLoad();
                    self.lazyLoad();
                    // populate action dropdown placeholder divs
                    _.each(this.urlsToShow, function (thumbnail) {
                        this.setView('.thumbnailActionDropdown[objId="' + thumbnail.id + '"]', new ThumbnailView.ActionDropdown({
                            objectId: thumbnail.id,
                            objectName: thumbnail.objectName,
                            thumbnailView: this,
                            thumbnailViewOptions: this.options,
                            searchResultsViewController: this.searchResultsViewController
                        })).render();
                    }, this);
                }

                var spinElems = this.$el.find(".hpiThumbnail");
                _.each(spinElems, function(spinElem){
                    if(spinElem) {
                        // animate our loading indicator with spin.js (lighter weight than animated gif)
                        spinElem.spinner = HPISpinner.createSpinner({
                            color: '#fff',
                            length: 16, 
                            width: 6, 
                            radius: 30, 
                            shadow: true,
                            zIndex: 2
                        }, spinElem);

                        // Once the img loads, we can destroy the spinner
                        $(spinElem).find("img").on("load", function(){
                            HPISpinner.destroySpinner(spinElem.spinner);
                        });
                    }
                }, this);
            
                // Making sure that the documents that are in the selectedThumbnails object are selected and have 
                // the check mark in the checkbox. 
                var hpiThumbnails = $('.thumbnails input:checkbox');
                _.each(hpiThumbnails, function(thumbnail){
                    if(_.contains(_.keys(self.selectedThumbnails), thumbnail.getAttribute('objId'))) {
                        $(thumbnail).parents('.hpiThumbnail').addClass('selectedThumbnail');
                        $(thumbnail).parents('.hpiThumbnail').context.checked = true;
                    }
                });

                // Setting the selected results for the actions dropdown and to update the number of selected docs badge
                this.searchResultsViewController.tableEventsRef.trigger("search:selectedResults", _.values(this.selectedThumbnails));

                // registerListener - lazyLoad
                var scrollElement = this.getScrollElement();
                $(scrollElement).off("scroll.thumbnail");
                $(scrollElement).on("scroll.thumbnail", _.bind(this.lazyLoad, this));
            },
            getScrollElement: function() {
                // if we're in VAD via the RSAH, scroll events happen on the rightSideActionHandler div not window
                var isRightSideVAD = (this.context === HPIConstants.TableView.Context.VAD && this.options.handler === HPIConstants.Handlers.RightSideActionHandler);
                return isRightSideVAD ? "#rightSideActionHandler" : window;
            },
            serialize: function() { 
                return {
                    urls: this.urlsToShow,
                    showDualPaneBtn: this.options.context === HPIConstants.TableView.Context.VAD
                };
            },
            cleanup: function() {
                this.stopListening();
                $(this.getScrollElement()).off("scroll.thumbnail");
            }
        });

        ThumbnailView.ActionDropdown = Backbone.Layout.extend({
            template: "search/actioncontrols",
            events:function(){
                var events = {};
                events['click .hpi-action-' + this.cid] = 'launchAction';
                events['click #hpi-actions-' + this.cid] = 'clickedActionDropdown';
                return events;
            },
            initialize: function (options) {
                this.options = options.thumbnailView.options;
                this.objectId = options.objectId;
                this.searchResultsViewController = options.searchResultsViewController;
            },
            clickedActionDropdown: function (evt) {
                evt.stopPropagation();
                if(!this.resolvedActions) {
                    this.resolveActions();
                }
            },
            toggleActionDropdown: function() {
                $('#hpi-actions-' + this.cid).dropdown('toggle');
            },
            resolveActions: function() {
                var options = _.extend(this.options, {
                    objectId: this.objectId,
                    objectName: this.objectName
                });

                this.resolvedActions = Action.resolveActions(options, this.collectionId);
                this.options.actionConfigs = Action.getActionConfigs(this.options);

                $.when(this.resolvedActions.deferred).done(_.bind(function () {
                    options.optionsConfigured = this.resolvedActions.optionsConfigured;
                    this.options.actionCollection = this.resolvedActions.actions;
                    _.each(options.optionsConfigured, function (actionOption) {
                        // default to being unable to launch action
                        actionOption.dontLaunchAction = 'false';
                        var aConfig = this.options.actionConfigs[actionOption.id];
                        // check if we want to run some condition validation on the action and determine if we want to be able to launch the action
                        if (aConfig && aConfig.get('hasClientCondition') && BooleanUtils.isTruthy(aConfig.get('hasClientCondition'))) {
                            var action = this.options.actionCollection.findWhere({ "actionId": actionOption.id });
                            var actionModule = ActionModules.getAction(actionOption.id);
                            // the client condition evaluator failed, get the message from the action and display it as well as grey out the action label
                            if (!actionModule.evaluateClientCondition(action)) {
                                actionOption.dontLaunchAction = 'true';
                                actionOption.failedConditionMessage = actionModule.failedConditionMessage;
                            }
                        }
                    }, this);
                    this.render();
                }, this));
            },
            launchAction: function (evt) {
                this.clickedActionDropdown(evt);

                if (BooleanUtils.isTruthy(this.$(evt.currentTarget).data('dontlaunch'))) {
                    evt.preventDefault();
                } else {
                    this.executeAction(this.$(evt.currentTarget).data('actionname'));                    
                }
            },
            fireAction: function(useModalActionHandler, type, options) {
                if(useModalActionHandler) {
                    app.modalActionHandler.trigger(type, options);   
                } else {
                    app[options.config.get("handler")].trigger(type, options);                         
                }
            },
            executeAction: function (actionId) {
                var config = this.options.actionConfigs[actionId];
                var action = this.options.actionCollection.findWhere({ 'actionId': actionId });
                var options = { action: action, config: config };
                var type = 'show';
                var useModalActionHandler = false;

                action.get("parameters").objectIds = [this.options.objectId];
                action.get("parameters").objectNames = [this.options.objectName];

                if (config.actionId.indexOf("openNewTab") !== -1) {
                    var docVals = [];
                    var oco;
                    //TODO build up docvals array in opennewtab to avoid code duplication with searchresultscontrols and tableview
                    if (module.config() && module.config().useFirstThree) {
                        var field1, field2, field3;
                        field1 = action.get("parameters").sortFields[0];
                        field2 = action.get("parameters").sortFields[1];
                        field3 = action.get("parameters").sortFields[2];

                        oco = this.searchResultsViewController.grid.getData().getItemById(this.options.objectId);
                        docVals.push([oco[field1], oco[field2], oco[field3]]);
                    }

                    type = 'launch';
                    options = { action: action, config: config, docVals: docVals };
                    useModalActionHandler = true;
                } 

                this.fireAction(useModalActionHandler, type, options);
            },
            afterRender: function() {
                // if we have resolvedActions we just grabbed 'em, so open that Bootstrap dropdown
                if(this.resolvedActions) {
                    this.toggleActionDropdown();
                }
            },
            serialize: function () {
                //The showIcon and pullDropdownRight values need to be hardcoded for the reusable template.
                return {
                    availableActions: this.options.optionsConfigured,
                    showIcon: true,
                    pullDropdownRight: true,
                    cid : this.cid
                };
            }
        });

        return ThumbnailView;
    });