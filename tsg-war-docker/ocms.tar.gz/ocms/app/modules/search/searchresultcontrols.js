// Searchresultcontrols module
define([
    // Application.
    "app",
    "modules/common/action",
    "modules/common/booleanutils",
    "modules/actions/actionmodules",
    "modules/search/facetsearch",
    "handlebars",
    "module",
    "modules/common/hpiconstants",
    "modules/services/logstashservice",
    "modules/search/searchstatisticsview"
],
// Map dependencies from above array.
function(app, Action, BooleanUtils, ActionModules, FacetSearch, Handlebars, module, HPIConstants, LogstashService, SearchStatisticsView) {

    var SearchResultControls = app.module();
    SearchResultControls.Views.ResultsMessage = Backbone.Layout.extend({
        template: 'search/resultsmessage',
        events: {
            'click .fn-resetStageSearch': 'resetStageSearch'
        },
        initialize: function(options, config) {
            this.collection = config.collection;
            this.searchResultsViewController = options.searchResultsViewController;
            // create a template for your message above the table based on whether we are doing actpdf or search 
            if (window.localStorage.getItem("viewFolderTerms:lastFolderTermClicked")) {
                var vftTerm = window.localStorage.getItem("viewFolderTerms:lastFolderTermClicked");
                this.totalResultsMessageTemplate = "Filtered search using " + '"' + vftTerm + '"' + " returned " + "{{totalResults}} " +
                    window.localize("search.results") + ". ";
                window.localStorage.removeItem("viewFolderTerms:lastFolderTermClicked");
            } else {
                this.totalResultsMessageTemplate = options.context === HPIConstants.TableView.Context.ACTPDF ?
                    window.localize("search.combining") + " {{totalResults}} " + window.localize("search.documents") + ". " :
                    window.localize("search.searchReturned") + " {{totalResults}} " + window.localize("search.results") + ". ";
                    
            }
            if(this.searchResultsViewController.useConfigs && options.searchResults) {
                this.resultsTableConfig = options.searchResults.get("resultsConfig").get("resultsTableConfig");
                
                // if we are using configs show the icon otherwise skip
                // do not show search statistics glyphicon if in context of actpdf
                if(this.searchResultsViewController.searchStatisticsEnabled) {
                    this.searchStatisticsEnabled = this.resultsTableConfig.get("searchStatisticsEnabled") === "true";
                } else {
                    this.searchStatisticsEnabled = false;
                }
            } else {
                // if we are not using configs hide the icon
                this.searchStatisticsEnabled = false;
            }
            this.startListening();
            this.getNumResults(this.collection);
            this.updateMessage(this.collection);

            // initializing this view (even if we aren't using it) because this view gets re-rendered
            // in some instances when a new search isn't actually performed. we need to make sure 
            // the search statistics view is re-rendered so the popover works. the afterrender
            // of the view we are in only re-renders the SearchStatisticsView if it's defined - hence the following lines
            // only show search statistics if enabled in configs
            if(this.searchStatisticsEnabled && this.numResults > 0){
                this.searchStatisticsView = new SearchStatisticsView.Views.Layout({ 
                    collection: this.options.collection,
                    config: this.options.searchResults.get("resultsConfig").get("resultsTableConfig")
                });
            }
        },
        startListening: function() {
            this.listenTo(this.collection, 'query:complete', this.updateMessage, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'filter:collection', this.updateMessage, this);
    
            this.listenTo(this.searchResultsViewController.tableEventsRef, "rolebased:results:message:update", function(roleBasedViewName) {
                this.roleBasedViewName = roleBasedViewName;
            });

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:docSelected', function() {
                this.updateTotalResultsNumberOnMessage(1);
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:docRemoved', function() {
                this.updateTotalResultsNumberOnMessage(-1);
            }, this);

            // only show search statistics if enabled in configs
            if(this.searchStatisticsEnabled){
                // re-render the searchStatistics once TableView renders so we have the timing for that
                this.listenTo(app, 'tableViewLoaded', function() {
                    // don't need to load statistics on an empty table
                    if (this.numResults){
                        this.loadSearchStatistics();
                    }
                }, this);
            }
        },
        loadSearchStatistics: function(){
            // calculate the timings to display in SearchStatistics
            this.searchStatisticsView = new SearchStatisticsView.Views.Layout({ 
                collection: this.options.collection,
                config: this.options.searchResults.get("resultsConfig").get("resultsTableConfig")
            });

            // needed to have pop-over content set
            this.render();      
        },
        updateTotalResultsNumberOnMessage: function(changeBy) {
            // update the number on the message above the table in actpdf if docs are included or excluded
            this.totalResults += changeBy;
            this.totalResultsMessage = this.totalResultsMessageTemplate.replace('{{totalResults}}', this.totalResults);
            this.render();
        },
        getNumResults: function(collection) {
            //get current collection state
            var numResults = 0;
            if (collection.length) {
                //result of 1 might just be the search parameters - check for an objectId
                numResults = collection.at(0).get('objectId') ? collection.state.totalRecords : 0;
            }
            this.numResults = numResults;
        },
        updateMessage: function(collection) {
            if (collection.snapshot) {
                this.totalResults = collection.snapshot.fullCollection.length;
            } else {
                // The first time that the user enters tableview, there will be snapshot available
                this.totalResults = collection.fullCollection.length;
            }
            this.totalResultsMessage = this.totalResultsMessageTemplate.replace('{{totalResults}}', this.totalResults);
            
            this.getNumResults(collection);

            this.textFilterMessage = "";
            var ifFacets = (this.options.collection.state.facets && this.options.collection.state.facets.length > 0);
            var ifTextFilter = (this.searchResultsViewController.textFilter);

            // Checking if not in standardized table view and if facets or text is active
            if (!this.options.standardizedTableView && (ifFacets || ifTextFilter)) {
                this.totalResultsMessage += window.localize("search.showing") + this.numResults + window.localize("search.resultsUsing");

                if (ifTextFilter) {
                    if(ifFacets){
                        this.textFilterMessage += " " + window.localize("generic.and") + " " + window.localize("search.textFilter");    
                    }else{
                        this.textFilterMessage += " " + window.localize("search.textFilter");   
                    }
                } 
            } 
            this.render();
        },
        resetStageSearch: function() {
            this.searchResultsViewController.showingSearchResultsInStage = false;
            // run the default VAD query
            this.searchResultsViewController.tableEventsRef.trigger('VAD:resetQuery');
            // Resetting the grid so that the selected documents are page numbers do not persist when generatind std view
            this.searchResultsViewController.resetGrid();
        },
        serialize: function() {
            // Check if predefined filters are applied
            if(this.roleBasedViewName === window.localize("search.facets.predefinedFilter.noFilter")){
                this.roleBasedViewName = window.localize("search.customFilter");
            } 

            return {
                'usingTextFilter': this.searchResultsViewController.textFilter ? true : false,
                'usingFacets': (this.options.collection.state.facets && this.options.collection.state.facets.length > 0),
                'totalResultsMessage': this.totalResultsMessage,
                'textFilterMessage': this.textFilterMessage,
                'filter': this.searchResultsViewController.textFilter || "",
                'roleBasedViewName': this.roleBasedViewName,
                'searchStatisticsEnabled': this.searchStatisticsEnabled,
                'searchLoadTime': this.options.collection.totalTime,
                'searchLoadTimeMedium' : this.resultsTableConfig ? parseFloat(this.resultsTableConfig.get("totalTimeMedium"), 10) : 3,
                'searchLoadTimeBad' : this.resultsTableConfig ? parseFloat(this.resultsTableConfig.get("totalTimeBad"), 10) : 10,
                'showingSearchResultsInStage': this.searchResultsViewController.showingSearchResultsInStage && !this.options.standardizedTableView
            };
        },
        cleanup: function() {
            this.stopListening();
        },
        afterRender: function() {
            if (this.searchStatisticsView){
                this.searchStatisticsView.render();
            }
        }
    });

    SearchResultControls.Views.RoleBasedDropdown = Backbone.Layout.extend({
        template: 'search/rolebasedfilter',
        events: function() {
            var events = {};
            events['click #roleBasedViews-' + this.cid] = 'roleBasedViews';
            return events;
        },
        initialize: function(options) {
            var self = this;
            this.roleView = options.roleView;
            this.facetEnabled = options.facetEnabled;
            this.vadContext = options.vadContext;
            this.parentView = options.parentView;
            this.initialType = options.initialType;
            this.searchResults = options.searchResults;
            this.searchResultsViewController = options.searchResultsViewController;

            if (!this.options.roleBasedViewName) {
                this.roleBasedViewName = window.localize("search.facets.predefinedFilter.noFilter");
            } else {
                this.roleBasedViewName = this.options.roleBasedViewName;
            }

            if (this.facetEnabled) {
                this.roleBasedConfig = [];
                // if this is in the context of VAD then we need to get the role based views configured for all the types 
                // If we are in the context of search then we only need to get the role based views for that specific type
                if (this.vadContext) {
                    _.each(this.searchResults.get("sidebarConfig").get('facetConfig').get("types").models, function(types) {
                        var objectType = types.get("filters").objectType;
                        self.addFiltersToRoleBasedConfig(types, objectType);
                    });
                    this.addingAllResultsFilter();
                } else {
                    // sanity check to make sure that a type is selected in the search page  
                    if (this.initialType) {
                        this.typeUpdatedInSearch(this.initialType);
                    }
                }

            }
            this.startListening();
        },
        roleBasedViews: function(evt) {
            // clearing out the text filter if it exists 
            if (this.parentView.searchResultsViewController.textFilter) {
                this.parentView.clearFilter();
            }

            // setting the role based view dropdown to the value selected
            var roleView = this.$(evt.target).data('value');

            // triggering function that actually make the filtering happen
            _.each(this.roleBasedConfig, function(roleBasedView) {
                if (roleBasedView.name === roleView) {
                    // setting the role based view on user preferences 
                    app.context.configService.getUserPreferences(function(currentUserPreferences) {
                        currentUserPreferences.set("roleBasedView", roleBasedView);
                        currentUserPreferences.save();
                    });
                    // triggers the listener that actually does the filtering
                    this.searchResultsViewController.tableEventsRef.trigger("roleBasedView:applyFilters", roleBasedView.filters);
                }
            }, this);

        },
        addingAllResultsFilter: function() {
            this.displayRoleBasedDropdown = false;

            // if no role based views are configured then we do not want to display the dropdown
            if (this.roleBasedConfig.length > 0) {
                this.displayRoleBasedDropdown = true;
            }
            // Adding an option for the user to unselect all facets from role based view dropdown
            var allResults = [];
            allResults.name = window.localize("search.facets.predefinedFilter.allresults");
            allResults.filters = new Backbone.Collection();
            // All results should always be the first option available to the user
            this.roleBasedConfig.unshift(allResults);
        },
        resetRoleBasedDropdownName: function() {
            this.roleBasedViewName = window.localize("search.facets.predefinedFilter.noFilter");
            this.render();
            // changing the results message based on the new role based view name 
            this.searchResultsViewController.tableEventsRef.trigger("rolebased:results:message:update", this.roleBasedViewName);
        },
        typeUpdatedInSearch: function(type) {
            this.roleBasedConfig = [];
            // getting the correct type from all types configured
            var typeConfig = _.find(this.searchResults.get("sidebarConfig").get("facetConfig").get("types").models, function(model) {
                return model.get("objectType") === type;
            });

            // if there are no role based views configured for a specific type then we don't want to add filters
            if (typeConfig) {
                this.addFiltersToRoleBasedConfig(typeConfig, type);
                this.addingAllResultsFilter();
            } else {
                // If there are no role based views then we can hide the dropdwon
                this.displayRoleBasedDropdown = false;
            }
        },
        addFiltersToRoleBasedConfig: function(typeConfig, objectType) {
            var self = this;
            _.each(typeConfig.get("filters").filters, function(filter) {
                self.roleBasedConfig.push({
                    name: filter.label,
                    filters: filter.values,
                    type: objectType
                });
            });
        },
        setRoleBasedDropdownName: function(text) {
            var self = this;
            // If the 'all results' option is selected then we want to display the default text in the dropdown 
            if (text === window.localize("search.facets.predefinedFilter.allresults")) {
                self.roleBasedViewName = window.localize("search.facets.predefinedFilter.noFilter");
            } else {
                self.roleBasedViewName = text;
            }

            this.render();
            // changing the results message based on the new role based view name 
            this.searchResultsViewController.tableEventsRef.trigger("rolebased:results:message:update", this.roleBasedViewName);
        },
        startListening: function() {
            this.listenTo(this.searchResultsViewController.tableEventsRef, "roleBasedView:reset:dropdown:text", this.resetRoleBasedDropdownName);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "set:rolebased:name", this.setRoleBasedDropdownName);
            this.listenTo(app, "searchsidebar:typeChanged", this.typeUpdatedInSearch);
        },
        afterRender: function() {
            var self = this;
            $("#roleBasedViews-" + this.cid + " li a").click(function(evt) {
                var text = evt.currentTarget.attributes[0].value;
                self.setRoleBasedDropdownName(text);
            });
        },
        cleanup: function() {
            this.stopListening();
        },
        serialize: function() {
            return {
                'roleView': this.roleBasedConfig,
                'displayRoleBasedDropdown': this.displayRoleBasedDropdown,
                'roleBasedViewName': this.roleBasedViewName,
                'cid': this.cid
            };
        }
    });

    SearchResultControls.Views.FilterControl = Backbone.Layout.extend({
        template: 'search/filtercontrol',
        events: function() {
            var events = {};
            events['keydown #filterInput-' + this.cid] = 'sanitizeKey';
            events['keyup #filterInput-' + this.cid] = 'updateTextFilter';
            events['click #clear-filter-' + this.cid] = 'clearFilter';
            return events;
        },
        initialize: function(options, config) {
            this.collection = config.collection;
            this.options = options;
            this.searchResults = options.searchResults;
            this.searchResultsViewController = options.searchResultsViewController;
            this.context = options.context;

            // we don't need to check if facets are enabled for collections 
            if (this.searchResultsViewController.useConfigs && this.context !== HPIConstants.TableView.Context.Collections && this.searchResults.get("sidebarConfig").get("facetConfig").get("enabled")) {
                this.facetEnabled = true;
            } else {
                this.facetEnabled = false;
            }

            // Checking if the user is on the view all documents page
            this.vadContext = this.context === HPIConstants.TableView.Context.VAD;

            this.roleBasedDropView = new SearchResultControls.Views.RoleBasedDropdown({
                parentView: this,
                roleView: this.roleBasedConfig,
                facetEnabled: this.facetEnabled,
                vadContext: this.vadContext,
                searchResults: this.searchResults,
                roleBasedViewName: this.options.roleBasedViewName,
                initialType: this.options.initialType,
                searchResultsViewController: this.searchResultsViewController
            });

            this.setView('.rolebased-dropdown-holder', this.roleBasedDropView).render();

            var currentSearchConfig = app.context.currentSearchConfig();
            if (currentSearchConfig && this.searchResultsViewController.useConfigs) {
                this.filterByFacetHolder = new SearchResultControls.Views.FilterByFacetHolder({
                    collection: this.collection,
                    searchResults: this.searchResults,
                    resultsConfig: currentSearchConfig.get("resultsConfig").attributes,
                    searchResultsViewController: this.searchResultsViewController,
                    context: this.context
                });
                this.setView('.facet-filter-holder-outlet', this.filterByFacetHolder).render();
            }
            this.stopListening();
            this.startListening();
        },
        startListening: function() {
            //stop listening first -- don't want multiple listeners registered
            this.stopListening();
            //listen for search to update/change
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:result:controls:reset filter:reset', function() {
                this.clearFilter();
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:updateTextFilter', function(filterText) {
                this.ui.filter.val(filterText);
            }, this);
        },
        //must intercept enter key on down press not keyup
        sanitizeKey: function(evt) {
            var code = evt.keyCode || evt.which;
            if (code == 13) {
                //prevent default for enter key only
                evt.preventDefault();
            }
        },
        updateTextFilter: _.throttle(function() {
            this.searchResultsViewController.textFilter = this.ui.filter.val().toLowerCase();
            if (_.isEmpty(this.searchResultsViewController.textFilter)) {
                this.ui.clear.hide();
            } else {
                this.ui.clear.show();
            }
            
            this.searchResultsViewController.tableEventsRef.trigger("search:results:text:filter:change", this.searchResultsViewController.textFilter);
        }, 20),
        clearFilter: function(evt) {
            if (evt) {
                evt.preventDefault();
            }
            if (this.rendered) {
                this.ui.filter.val(''); //reset filter if search changed
                this.ui.clear.hide();
                this.updateTextFilter();
            }
        },
        afterRender: function() {
            this.rendered = true;
            this.ui = {
                filter: $('#filterInput-' + this.cid),
                clear: $('#clear-filter-' + this.cid)
            };
            if (_.isEmpty(this.searchResultsViewController.textFilter)) {
                this.ui.clear.hide();
            } else {
                this.ui.clear.show();
                //Setting the text filter in the HTML element. 
                this.ui.filter.val(this.searchResultsViewController.textFilter);
            }
        },
        cleanup: function() {
            this.stopListening();
        },
        reapplyViews: function() {
            if (this.roleBasedDropView) {
                this.roleBasedDropView.startListening();
                this.setView('.rolebased-dropdown-holder', this.roleBasedDropView).render();
            }
            if (this.filterByFacetHolder) {
                this.filterByFacetHolder.initializeFacets();
                this.setView('.facet-filter-holder-outlet', this.filterByFacetHolder).render();
            }
        },
        serialize: function() {
            return {
                'facetEnabled': this.facetEnabled,
                'VADContext': this.vadContext,
                'cid': this.cid
            };
        }
    });

    SearchResultControls.Views.FilterByFacetHolder = Backbone.Layout.extend({
        template: "search/filterbyfacetholder",
        initialize: function(options) {
            this.collection = options.collection;
            this.searchResults = options.searchResults;
            this.searchResultsViewController = options.searchResultsViewController;
            this.context = options.context;
            this.initializeFacets();
        },
        initializeFacets: function() {
            //This ensures that the filter by facets button does not get displayed in the search page since facets are already available in the sidebar 
            if (this.context === HPIConstants.TableView.Context.VAD) {
                // Argument for selected types has been left blank. This means that all types will be selected by default.
                this.facetView = new FacetSearch.Views.Layout({
                    searchConfig: this.searchResults,
                    collection: this.collection,
                    selectedType: null,
                    searchResultsViewController: this.searchResultsViewController
                });

            }
        },
        afterRender: function(){
            if(this.facetView){
                this.facetView.render();
            }
        }
    });

    SearchResultControls.Actions = Backbone.Model.extend({
        initialize: function(options, config) {
            if (options) {
                this.options = _.defaults(options, this.defaults);
            }
            this.availableActions = [];
            this.collection = config.collection;
            if (config.collection.collectionId) {
                this.collectionId = config.collection.collectionId;
            }
            this.searchResultsViewController = this.options.searchResultsViewController;
            if (this.searchResultsViewController.useConfigs) {
                this.actionConfigs = Action.getActionConfigs(this.options);
            }
            this.startListening();
        },
        startListening: function() {
            this.stopListening();
            //listen for search to update/change
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:result:controls:reset', function(collection) {
                this.collection = collection;
                this.updateSelectedResults([]); //reset options if search changed
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:results:selected:results', function(ocos) {
                this.updateSelectedResults(ocos);
            }, this);

            // listen to get available and visible attributes that actions might need to use
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:currentlyDisplayedFields", function(attrs, attrLabels) {
                this.visibleAttrs = attrs;
                this.visibleAttrLabels = attrLabels;
            }, this);
        },
        resolveActions: function() {
            var collectionId = this.collectionId ? this.collectionId : null;
            var resolvedActions = Action.resolveActions(this.options, collectionId);
            this.set('actions', resolvedActions.actions);

            //wait for actions to resolve
            $.when(resolvedActions.deferred).done(_.bind(function() {
                _.each(resolvedActions.optionsConfigured, function(actionOption) {
                    // default to being able to launch action
                    actionOption.dontLaunchAction = 'false';
                    var aConfig = this.actionConfigs[actionOption.id];
                    // check if we want to run some condition validation on the action and determine if we want to be able to launch the action
                    if (aConfig && aConfig.get('hasClientCondition') && BooleanUtils.isTruthy(aConfig.get('hasClientCondition'))) {
                        var action = resolvedActions.actions.findWhere({
                            "actionId": actionOption.id
                        });
                        var actionModule = ActionModules.getAction(actionOption.id);
                        // the client condition evaluator failed, get the message from the action and display it as well as grey out the action label
                        if (!actionModule.evaluateClientCondition(action)) {
                            actionOption.dontLaunchAction = 'true';
                            actionOption.failedConditionMessage = actionModule.failedConditionMessage;
                        }
                    }
                }, this);

                this.set('availableActions', resolvedActions.optionsConfigured);
            }, this));
        },
        // just pass ocos now that we have them
        updateSelectedResults: function(ocos) {
            var objectIds = _.pluck(ocos, HPIConstants.Properties.ObjectId);
            var objectNames = _.pluck(ocos, HPIConstants.Properties.ObjectName);

            this.set('hasSelectedResults', objectIds && objectIds.length > 0);

            //single vs multiple selected results
            if (objectIds.length === 1) {
                this.options.objectId = _.first(objectIds);
                this.options.objectIds = undefined;
                this.options.objectName = _.first(objectNames);
            } else if (objectIds.length > 1) {
                this.options.objectIds = objectIds;
                this.options.objectNames = objectNames;
                this.options.objectId = undefined;
            }
            //update the action's list of objectIds to evaluate against
            this.set('selectedResults', objectIds);
            this.set('objNames', objectNames);

            // add this to the controller's grid's global list of ids and names
            if (this.searchResultsViewController.grid) {
                this.searchResultsViewController.grid.setSelectedObjects(ocos);
            }

            // only resolve actions if we have selected ids
            if (objectIds.length > 0) {
                this.resolveActions();
            }
        },
        getDocValsFromFields: function(fields) {
            var self = this;
            var docVals = [];
            _.each(this.get('selectedResults'), function(id) {  
                var oco = self.searchResultsViewController.grid.getSelectedOCObyId(id);
                var ocoFields = _.map(fields, function(field) { return oco[field]; });
                docVals = docVals.concat(ocoFields);
            });
            return docVals;
        },
        executeAction: function(actionId) {
            var self = this;
            var config = this.actionConfigs[actionId];
            var action = this.get('actions').findWhere({
                'actionId': actionId
            });
            action.get("parameters").objectIds = this.get('selectedResults');
            action.get("parameters").objectNames = this.get('objNames');
            action.get("parameters").sortFields = this.visibleAttrs;
            action.get("parameters").fieldLabels = this.visibleAttrLabels;
            action.get("parameters").context = "searchResultControls";
            //this is ok not to null check, even if the collection is empty (no results), we still searched on a type
            action.get("parameters").objectTypes = this.get("collection").queryParams.oc_type;
            if (this.collectionId) {
                action.get("parameters").collectionId = this.collectionId;
            }

            if (config.actionId.indexOf("openNewTab") !== -1) {
                var fields = [];
                //TODO build up docvals array in opennewtab to avoid code duplication with thumbnail and tableview
                if (module.config() && module.config().useFirstThree) {
                    fields.push(action.get("parameters").sortFields[0]);
                    fields.push(action.get("parameters").sortFields[1]);
                    fields.push(action.get("parameters").sortFields[2]);
                }
                var docVals = this.getDocValsFromFields(fields);
                app.modalActionHandler.trigger("launch", {
                    action: action,
                    config: config,
                    docVals: docVals
                });
            } else {
                //fire action
                app[config.get("handler")].trigger("show", {
                    action: action,
                    config: config,
                    searchResultsViewController: self.searchResultsViewController
                });
            }
        },
        cleanup: function() {
            this.stopListening();
        }
    });

    SearchResultControls.Views.ActionsControl = Backbone.Layout.extend({
        template: 'search/actioncontrols',
        events: function() {
            var events = {};
            events['click .hpi-action-' + this.cid] = 'launchAction';
            return events;
        },
        initialize: function(options, config) {
            this.actions = new SearchResultControls.Actions(options, config);
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.startListening();
        },
        startListening: function() {
            this.stopListening();
            this.listenTo(this.actions, 'change:availableActions change:hasSelectedResults', function() {
                if (this.rendered) {
                    this.render();
                }
            }, this);

            this.listenTo(this.actions, 'change:selectedResults', this.updateSelectedResultsBadge);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:selected:results paginationControls:rendered", this.updateSelectedResultsBadge);
        },
        launchAction: function(evt) {
            if (BooleanUtils.isTruthy(this.$(evt.currentTarget).data('dontlaunch'))) {
                evt.preventDefault();
                return;
            }
            var actionId = this.$(evt.currentTarget).data('actionname');
            this.actions.executeAction(actionId);
        },
        updateSelectedResultsBadge: function() {
            if (this.actions.get('hasSelectedResults')) {
                this.$('#hpi-actions-' + this.cid).show();
            } else {
                this.$('#hpi-actions-' + this.cid).hide();
            }
        },
        afterRender: function() {
            this.rendered = true;
            this.updateSelectedResultsBadge();
        },
        serialize: function() {
            return {
                'availableActions': this.actions.get('availableActions'),
                'showText': true,
                'showIcon': false,
                'cid': this.cid
            };
        },
        cleanup: function() {
            this.actions.stopListening();
            this.stopListening();
        }
    });

    SearchResultControls.Pagination = Backbone.Model.extend({
        defaults: {
            'sortIcon': 'glyphicon glyphicon-sort-by-attributes-alt' //sort results icon (asc / desc)
        },
        initialize: function(options, config) {
            this.options = {};
            if (options) {
                this.options = _.defaults(options, this.defaults);
            }
            this.collection = config.collection;
            this.searchResultsViewController = options.searchResultsViewController;
            this.sortAttr = this.options.sortAttr;
            this.sortLabel = this.options.sortLabel;
            this.sortOrder = this.options.sortOrder;
            this.pageSize = this.options.pageSize || config.collection.state.pageSize;

            this.context = this.options.context;
            //if context is 'viewalldocuments' - use JS in-memory to store pagination state rather than the URL bar
            this.onStage = this.options.context === HPIConstants.TableView.Context.VAD;
            if (this.onStage) {
                this.paginationParams = _.defaults({}, this.defaults);
            }
            this.updateUrl = !this.options.silent;

            this.fetchedLabels = false;

            this.activeViewName = this.options.activeViewName || '';

            if (this.hasResults()) {
                //already preformed a fetch before loading search
                //get the latest params from the url bar - don't proc event during initialization
                this.updatePaginationParams();
            }

            this.startListening();
        },
        getState: function() {
            //return OCQuery's internal record keeper as the source of truth
            return this.collection.records;
        },
        startListening: function() {
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:changeView', function(activeViewName) {
                //set up a context based on the current search view
                this.activeViewName = activeViewName;
            }, this);
            

            //listen for facets
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:results:facet', this.processQueryResults, this);

            //Listener that accepts infomation from our SlickGrid pager/paginator.
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'slickgrid:pagination:change', function(pagingInfo) {
                //update from the totalRecords object
                this.collection.state.totalPages = pagingInfo.totalPages;
                //update the page size
                this.collection.state.pageSize = pagingInfo.pageSize;
                this.pageSize = pagingInfo.pageSize;
                //update total records
                this.collection.state.totalRecords = pagingInfo.totalRows;
                //DO NOT update current page based on the pagingInfo, This breaks Backbone Pagination becuase
                // tsg.dataview.js is not 1 indexed
                //Cant have the currentPage be greater then the totalPages
                if (this.collection.state.currentPage > this.collection.state.totalPages) {
                    //Cant set currentPage to 0 because it will break Backbone Pagination,
                    // which is not zero indexed.TotalPages can come through as zero because
                    //our tsg.dataview file is zero indexed.
                    if (this.collection.state.totalPages <= 0) {
                        this.collection.state.currentPage = 1;
                    } else {
                        this.collection.state.currentPage = this.collection.state.totalPages;
                    }
                }
                this.collection.state.text = this.collection.state.currentPage + " of " + this.collection.state.totalPages;
            });
        },
        processQueryResults: function(updatedCollection) {
            // reset models and update the recordkeeper -
            // don't re-assign as that will break the collection listener bindings
            this.collection.reset(updatedCollection.models);
            this.collection.records.set(_.extend({}, updatedCollection.records.attributes));
            //update state from the recordkeeper
            this.collection.state = _.extend({}, this.collection.records.attributes, this.collection.state);
            //reset unfiltered results
            this.unfilteredResults = undefined;

            //update pagination params before re-fetching labels
            this.updatePaginationParams();

            //update UI
            this.trigger('change:controls');
        },
        updatePaginationParams: function() {
            //IMPORTANT: make sure all search attributes changed or otherwise make it onto the paginationParams map
            //add on the total number of pages - doesn't live in the url query
            //update from the totalRecords object
            this.collection.state.totalPages = this.collection.records.totalPages();
            //update the page size
            this.collection.state.pageSize = this.collection.records.pageSize();
            this.pageSize = this.collection.records.pageSize();
            //update total records
            this.collection.state.totalRecords = this.collection.records.totalRecords();
        },
        hasResults: function() {
            return this.collection.records.totalRecords() > 0;
        },
        updateSearchUrl: function() {
            // only set these if the query is valid
            if (this.hasResults()) {
                this.url = Backbone.history.fragment;
                if (this.updateUrl) {
                    Backbone.history.navigate(this.url);
                }
                //update actual query to send to the server
                if (this.pageSize !== this.collection.state.pageSize) {
                    this.collection.records.changePageSize(this.collection.records.pageSize());
                    this.pageSize = this.collection.records.pageSize();
                    //changing pageSize resets results to the first page
                    this.collection.setPageSize(this.pageSize, {
                        first: true
                    });
                    //reset to the first page
                    this.collection.getPage(1);
                } else {
                    //only check these if page size hasn't changed
                    if (this.collection.records.currentPage() !== this.collection.state.currentPage) {
                        //setting page number triggers a web call in server-side
                        this.collection.getPage(this.collection.records.currentPage());
                    }
                }
            }
            return this.url;
        },
        fetchSortableFields: function() {
            var deferred = $.Deferred();
            var fields = [];
            var deferreds = [];
            _.each(app.context.currentSearchConfig().get("resultsConfig").attributes, function(resultConfig) {
                if (resultConfig instanceof Backbone.Model) {
                    //get the config that defines this search view
                    if (resultConfig.get("label") === this.activeViewName) {
                        _.each(resultConfig.get("types").models, function(type) {
                            //get labels
                            var typeLebelDeferred = app.context.configService.getLabels(type.get("objectType"), type.get("title"), function() {});
                            deferreds.push(typeLebelDeferred);
                            typeLebelDeferred.done(function(labelAttrs) {
                                fields.push({
                                    'fieldName': labelAttrs.ocName,
                                    'label': labelAttrs.label
                                });
                            });
                            //get otc types and their labels
                            _.each(type.get("fields"), function(field) {
                                // if its unique, push
                                var otcLabelsDeferred = app.context.configService.getLabels(type.get("objectType"), field, function() {});
                                deferreds.push(otcLabelsDeferred);
                                otcLabelsDeferred.done(function(labelAttrs) {
                                    fields.push({
                                        'fieldName': labelAttrs.ocName,
                                        'label': labelAttrs.label
                                    });
                                });
                            });
                        });
                    }
                }
            }, this);

            $.when.apply(null, deferreds).done($.proxy(function() {
                //ready to handle duplicates now
                var uniqueFields = [];
                _.each(fields, function(fieldAttr) {
                    var newFieldAttr = _.findWhere(uniqueFields, {
                        'fieldName': fieldAttr.fieldName
                    });
                    //set the sortLabel here
                    if (this.get('sortAttr') === fieldAttr.fieldName) {
                        this.sortLabel = fieldAttr.label;
                    }
                    if (!newFieldAttr) {
                        uniqueFields.push(fieldAttr);
                    }
                }, this);
                this.set({
                    'sortLabel': this.sortLabel,
                    'sortableFields': uniqueFields,
                    'hasSortableFields': uniqueFields.length > 0 //flag for easy rendering
                });
                deferred.resolve(fields);
            }, this));
            return deferred.promise();
        },
        updateResultsPerPage: function(resultsPerPage, silent) {
            this.set({
                'pageNumber': 1, //set page number
                'pageSize': resultsPerPage
            });

            this.collection.setPageSize(resultsPerPage);

            if (!silent) {
                this.trigger('change:controls');
            }
        },
        gotoPage: function(page, silent) {
            if (!page || page <= 0) {
                page = 1;
            }

            //clear cached unfiltered results
            this.unfilteredResults = undefined;

            //notify total records if page has changed
            if (this.collection.records.currentPage() != page) {
                //this  will trigger a formatting of the OCOs
                this.collection.getPage(page);
            }

            if (!silent) {
                this.trigger('change:controls');
            }
        },
        toggleSort: function(sortOrder, silent) {
            var sortAttrs = {
                'sortOrder': sortOrder,
                'sortIcon': sortOrder > 0 ? 'glyphicon glyphicon-sort-by-attributes-alt' : 'glyphicon glyphicon-sort-by-attributes'
            };
            this.set(sortAttrs);

            if (!silent) {
                this.trigger('change:controls');
            }

            return sortAttrs;
        },
        updateSortAttr: function(ocName, silent) {
            //update the selected sortAttr and corrsponding sortLabel
            var otcField = _.findWhere(this.get('sortableFields'), {
                'fieldName': ocName
            });
            var sortLabel = otcField ? otcField.label : undefined;
            var sortAttrs = {
                'sortAttr': ocName,
                'sortLabel': sortLabel
            };
            this.set(sortAttrs);

            if (!silent) {
                this.trigger('change:controls');
            }

            return sortAttrs;
        },
        cleanup: function() {
            this.stopListening();
        }
    });

    SearchResultControls.Views.PaginationControls = Backbone.Layout.extend({
        template: "search/paginationcontrols",
        events: function() {
            //scope all event bindings to this view
            var events = {};
            //check all/ uncheck all search results
            events['click .search-controls-checkAllResults-' + this.cid] = 'checkAll';
            events['click .search-controls-uncheckAllResults-' + this.cid] = 'uncheckAll';
            //sort by attribute
            events['click  a.search-sortBy-' + this.cid] = 'sortByAttr';
            //pagination controls
            events['click  button.prevPage-' + this.cid] = 'prevPage';
            events['click .gotoPage-' + this.cid + ' > li'] = 'gotoPage';
            events['click  button.nextPage-' + this.cid] = 'nextPage';
            //results per page
            events['click .resultsPerPage-' + this.cid + ' > li'] = 'updateResultsPerPage';
            events['click button.sortIcon-' + this.cid] = 'toggleSort';
            return events;
        },
        initialize: function(options, config) {
            this.options = options;
            this.stopListening();
            this.paginationControls = new SearchResultControls.Pagination(options, config);
            this.searchResultsViewController = this.options.searchResultsViewController;
            this._startListening();

            //reset unfiltered results
            this.unfilteredResults = undefined;

            //register a handlebars helper for the pagination dropdown rather then creating a possibly huge array
            //credit to http://stackoverflow.com/a/11924998/1377866
            Handlebars.registerHelper('search-results-pages', function(n, block) {
                var accum = '';
                for (var i = 0; i < n; ++i) {
                    accum += block.fn(i);
                }
                return accum;
            });

            Handlebars.registerHelper("offset", function(value) {
                return parseInt(value, 10) + 1;
            });
        },
        _startListening: function() {
            //listen for changes from the model and render acocrdingly
            this.listenTo(this.paginationControls, 'change:controls', function() {
                //update url if its changed
                this.paginationControls.updateSearchUrl();
                if (this.rendered) {
                    this.render();
                }
            }, this);

            //listen for changes from slick.pager and render buttons and text acocrdingly
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'updateButtons', function(state) {
                this.paginationControls.getState().attributes.prev = !state.prev;
                this.paginationControls.getState().attributes.next = !state.next;
                this.paginationControls.getState().attributes.text = state.text;
                this.render();
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:selectedResults", function(selectedResults) {
                this.selectedResultsLength = selectedResults.length;
                if (selectedResults.length === 0) {
                    $("#numSelectedResults-" + this.cid).text('');
                } else {
                    $("#numSelectedResults-" + this.cid).text(selectedResults.length);
                }
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:result:controls:setCurrentPage", function(pageNumber) {
                this.setCurrentPage(pageNumber);
            });
        },
        checkAll: function(evt) {
            evt.preventDefault();
            this.searchResultsViewController.tableEventsRef.trigger("search:checkAllResults");
        },
        uncheckAll: function(evt) {
            evt.preventDefault();
            this.searchResultsViewController.tableEventsRef.trigger("search:removeAllChecked");
        },
        prevPage: function(evt) {
            evt.preventDefault();
            //This is simulating a click on slick.pager
            if (app.searchView !== HPIConstants.TableView.SearchView.THUMBNAIL && app.searchView !== HPIConstants.TableView.SearchView.LIST) {
                this.searchResultsViewController.tableEventsRef.trigger("search:paginationControl:prev");
                var currentPage = this.paginationControls.collection.state.currentPage;
                this.setCurrentPage(currentPage);
            } else {
                if (this.paginationControls.collection.state.currentPage > 1) {
                    this.paginationControls.collection.state.currentPage = this.paginationControls.collection.state.currentPage - 1;
                    this.setCurrentPage(this.searchResultsViewController.grid.getData().getPagingInfo().pageNum);
                }
            }
        },
        gotoPage: function(evt) {
            evt.preventDefault();
            var gotoPage = this.$(evt.target).data('value');

            if (app.searchView === HPIConstants.TableView.SearchView.THUMBNAIL || app.searchView === HPIConstants.TableView.SearchView.LIST) {
                this.paginationControls.collection.state.currentPage = gotoPage;
            }
            this.setCurrentPage(gotoPage);
            //Telling slick.pager which page to go to.
            this.searchResultsViewController.grid.getData().setPagingOptions({
                pageNum: parseInt(gotoPage, 10) - 1
            });
        },
        nextPage: function(evt) {
            evt.preventDefault();
            //This is simulating a click on slick.pager
            if (app.searchView !== HPIConstants.TableView.SearchView.THUMBNAIL && app.searchView !== HPIConstants.TableView.SearchView.LIST) {
                this.searchResultsViewController.tableEventsRef.trigger("search:paginationControl:next");
                var currentPage = this.paginationControls.collection.state.currentPage;
                this.setCurrentPage(currentPage + 1);
            } else {
                this.paginationControls.collection.state.currentPage = this.paginationControls.collection.state.currentPage + 1;
                this.setCurrentPage(this.paginationControls.collection.state.currentPage);
            }
        },
        updateResultsPerPage: function(evt) {
            var self = this;

            this.searchResultsViewController.resultsPerPage = parseInt(this.$(evt.target).data('value'), 10);

            // Setting the results per page on the userPreferences
            app.context.configService.getUserPreferences(function(currentUserPreferences) {
                currentUserPreferences.set("resultsPerPage", self.searchResultsViewController.resultsPerPage);
                currentUserPreferences.save();
            });

            this.searchResultsViewController.tableEventsRef.trigger("change:resultsPerPage");
            if (this.searchResultsViewController.grid) {
                this.searchResultsViewController.grid.getData().setPagingOptions({
                    pageSize: this.searchResultsViewController.resultsPerPage
                });
            }
            this.paginationControls.getState().attributes.pageSize = this.searchResultsViewController.resultsPerPage;
            this.paginationControls.getState().attributes.totalPages = this.searchResultsViewController.grid.getData().getPagingInfo().totalPages;
            this.render();
        },
        setCurrentPage: function(pageNumber) {
            // Setting the current page
            this.paginationControls.collection.state.currentPage = pageNumber;
            var gotoPage = $('.dropdown-toggle.gotoPage-' + this.cid + ' > span.text');
            gotoPage.text(pageNumber + " of " + this.paginationControls.getState().totalPages());
            this.searchResultsViewController.tableEventsRef.trigger(app.searchView +":goToPage", {
                "pageToGoTo": pageNumber,
                "pageSize": this.searchResultsViewController.grid.getData().getPagingInfo().pageSize
            });
        },
        toggleSort: function() {
            //don't set the sort order directly as we need to update the icon as well
            this.paginationControls.toggleSort(this.paginationControls.get('sortOrder') * -1);
        },
        sortByAttr: function(evt) {
            this.paginationControls.updateSortAttr(this.$(evt.currentTarget).data('fieldname'));
        },
        beforeRender: function() {
            var paginationControls = this.paginationControls.getState().attributes;
            // If results per page has already been set then we should update it on the paginationControls object too
            if (!this.searchResultsViewController.resultsPerPage) {
                this.searchResultsViewController.resultsPerPage = paginationControls.pageSize;
            } else {
                // This decides what value is displayed in the results per page selection dropdown. 
                paginationControls.pageSize = this.searchResultsViewController.resultsPerPage;
            }

            // Since the page size has just been reset, the total pages will need to be recalculated
            paginationControls.totalPages = Math.ceil(this.paginationControls.collection.state.totalRecords / paginationControls.pageSize);
            paginationControls.lastPage = paginationControls.totalPages;
        },
        afterRender: function() {
            this.rendered = true;

            //results per page
            $('.dropdown-toggle.resultsPerPage-' + this.cid + ' > span.text').text(this.paginationControls.getState().pageSize() + "/Page");

            this.searchResultsViewController.tableEventsRef.trigger("paginationControls:rendered");

            //Setting the "<currentPage> of <totalPages>" text
            this.$('.slick-pager-status').text(this.paginationControls.getState().attributes.text);

            // Setting the number of selected documents on selected badge.
            if (this.selectedResultsLength) {
                $("#numSelectedResults-" + this.cid).text(this.selectedResultsLength);
            }

            if (window.innerWidth <=HPIConstants.WindowSize.Small && this.context === HPIConstants.TableView.Context.VAD){
                $('#bottom-paginator-form').hide();
            }else{
                $('#bottom-paginator-form').show();
            }

        },
        serialize: function() {
            var keyValues = _.extend(this.options, this.paginationControls.getState().attributes, {
                'cid': this.cid, //uniquely bind all events
                'showButtonPaginator' : window.innerWidth <=HPIConstants.WindowSize.Small
            });

            keyValues["standardizedTableView"] = this.options.standardizedTableView;
            
            return keyValues;
        },
        cleanup: function() {
            this.paginationControls.cleanup();
            this.stopListening();
        }
    });

    SearchResultControls.Views.Layout = Backbone.Layout.extend({
        template: "search/searchresultcontrols",
        events: function() {
            var events = {};
            events['click #showThumbnails-' + this.cid] = 'showThumbnails';
            events['click #showTable-' + this.cid] = 'showTable';
            events['click #resetPreferences-' + this.cid] = 'showResetTableView';
            events['click #standardizedTableView-' + this.cid] = 'standardizedTableView';
            events['click .top-button'] = 'topOfPage';
            events['change #include-index-page-' + this.cid] = 'toggleIncludeIndexPage';
            events['click .fn-toggleAttributeSearch'] = 'toggleAttributeSearch';
            return events;
        },
        initialize: function(options) {
            app.log.debug('initializing SearchResultControls');
            this.THUMBNAIL = "thumbnail";
            this.THUMBNAIL_VIEW = "Thumbnail View";
            this.THUMBNAIL_VIEW_MODE = "Thumbnail View Mode";
            this.LIST = "list";
            this.LIST_VIEW = "List View";
            this.LIST_VIEW_MODE = "List View Mode";
            this.TABLE = "table";
            this.TABLE_VIEW = "Table View";
            this.TABLE_VIEW_MODE = "Table View Mode";
            this.STANDARDIZED_TABLE_VIEW = "Standardized Table View";
            this.RESET_TABLE_VIEW = "Reset Table View";
            this.viewBtnMap = {
                "Thumbnail View": "#showThumbnails-" + this.cid,
                "Table View": "#showTable-" + this.cid,
                //same as table view button in list view
                "List View": "#showTable-" + this.cid,
                "Standardized Table View": "#standardizedTableView-" + this.cid
            };
            this.options = options;
            this.collection = options.collection;
            this.options.tableViewMode = this.TABLE_VIEW_MODE;
            this.options.viewType = !this.options.viewType ? this.TABLE_VIEW : this.options.viewType;
            this.highlightedBtn = this.viewBtnMap[this.options.viewType];
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.context = options.context;
            this.options.filter = "";
            this.setType();
            //listen for results set to change
            this.startListening();

            $(window).resize(_.bind(_.debounce(function(){
                if(this.options.viewType ===  this.THUMBNAIL_VIEW){
                    return;
                }

                if(window.innerWidth <=HPIConstants.WindowSize.Small && (this.options.viewType != this.LIST_VIEW || this.context === HPIConstants.TableView.Context.VAD)){
                    this.showLists();
                }else if (window.innerWidth >HPIConstants.WindowSize.Small){
                    this.options.viewType = this.TABLE_VIEW;
                    app.searchView = this.TABLE;
                    this.searchResultsViewController.tableEventsRef.trigger("search:changeView", this.TABLE_VIEW);
                    this.searchResultsViewController.tableEventsRef.trigger('VAD:showTable');
                }
            },200),this));

            // if user is at top of page make the top of page buttom disappear and vice versa
            $(window).scroll(_.bind(_.debounce(this.atTop, 200),this));

            this.renderChildViews();
        },
        startListening: function() {
            this.stopListening();

            //listen to the full backing collection from search
            this.listenTo(this.collection, 'query:complete', this.updateSearchResults);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:selectedResults", function(ocos) {
                //pass this event along to the search control submodules
                this.searchResultsViewController.tableEventsRef.trigger("search:results:selected:results", ocos);
            });

            this.listenTo(this.searchResultsViewController.tableEventsRef, 'search:showLists', function(){
                // preventing the switch to table view or list view on resize
                if(this.options.viewType === this.THUMBNAIL_VIEW){
                    return;
                }
                if (window.innerWidth <=HPIConstants.WindowSize.Small){
                    this.showLists();
                }else{
                    this.showTable();
                    this.options.viewType = this.TABLE_VIEW;
                    app.searchView = this.TABLE;
                    this.searchResultsViewController.tableEventsRef.trigger("search:changeView", this.TABLE_VIEW);
                    this.searchResultsViewController.tableEventsRef.trigger('VAD:showTable');
                }
            });
        },
        atTop: function() {
            $( document ).ready(function() {
                if ($(window).scrollTop() > 0 && window.innerWidth <=HPIConstants.WindowSize.Small) {
                    $('.top-button').css('visibility','visible').show().fadeIn(100);
                }else{
                    $('.top-button').css('visibility','hidden').hide().fadeOut(100);
                }
            });
        },
        setType: function() {
            this.type = this.collection.queryParams.oc_type ? this.collection.queryParams.oc_type[0] : null;
        },
        updateSearchResults: function(updatedCollection) {
            this.collection = updatedCollection;
            if (this.rendered) {
                //pass this event along to the search control submodules
                app.trigger("search:result:controls:numResults", this.collection.state.totalRecords);
                this.toggleControls();
            }
            if (this.options.viewType ===  HPIConstants.TableView.ViewType.ThumbnailView){
                // reassigning viewtype to table view on search
                this.options.viewType = this.TABLE_VIEW;
                this.searchResultsViewController.tableEventsRef.trigger("search:showLists");
            }
            this.render();

            //log search completion
            var searchCompletionTime = Date.now();
            LogstashService.sendMetrics(
                new LogstashService.PerformanceLog({
                    'eventTitle': HPIConstants.Logging.Events.Search,
                    'events': {
                        'eventDuration': searchCompletionTime - this.collection.searchStartTime
                    },
                    'docCount': this.collection.length
                })
            );
        },
        toggleControls: function() {
            var visibility = 'hidden';
            if (this.collection.state.totalRecords <= 0 && this.searchResultsViewController.textFilter || this.collection.state.totalRecords > 0 || this.collection.records.get('facets')) {
                visibility = 'visible';
            }
            this.$el.css('visibility', visibility);
        },
        setViewTypeUserPref: function() {
            // saving the current view type to user preferences
            var self = this;
            app.context.configService.getUserPreferences(function(currentUserPreferences) {
                var viewToSave = self.options.viewType;
                if (viewToSave === self.STANDARDIZED_TABLE_VIEW) {
                    viewToSave = self.TABLE_VIEW;
                }
                currentUserPreferences.set("lastSearchResultView", viewToSave);
                currentUserPreferences.save();
            });
        },
        showTable: function() {
            // This trigger ensures that selected documents and page number information is correctly preserved when switching views   
            this.searchResultsViewController.tableEventsRef.trigger("search:switching-to-table-view");
            // prevent weird re-sorting behavior
            if (this.highlightedBtn !== this.viewBtnMap[this.TABLE_VIEW]) {
                this.updateBtnStyling(this.viewBtnMap[this.TABLE_VIEW]);
                var searchResult = this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                });

                // Re-render of child views will be required whenever user enters std table view or leaves std table view
                // This is because filter controls will be hidden in std view
                this.renderChildViewsRequired = searchResult.get("standardizedTableView");

                // Setting stdTableView to false since we are now in table view
                searchResult.set("standardizedTableView", false);
                this.options.tableViewMode = this.TABLE_VIEW_MODE;
                this.options.viewType = this.TABLE_VIEW;
                this.setViewTypeUserPref();

                this.searchResultsViewController.tableEventsRef.trigger("toggleFacetTab", true);
                app.searchView = this.TABLE;
                this.searchResultsViewController.tableEventsRef.trigger('search:changeView', this.TABLE_VIEW);
                // only need to render child views in VAD (reset our facets)
                if (this.context === HPIConstants.TableView.Context.VAD) {
                    this.searchResultsViewController.tableEventsRef.trigger('VAD:showTable');
                    // render after the table view is set up (avoid calling reload results before an after render)
                    this.listenToOnce(this.searchResultsViewController.tableEventsRef, "tableview:tableAfterRenderDone", function() {
                        if (this.renderChildViewsRequired) {
                            //Need to update the collections state to the values in the paginationControls
                            //This is to prevent using the pagination setting of the Standardized table. This only occurs
                            //when leaving Standardized table. The renderChildViewsRequired variable indicates if
                            //we are leaving Standardized table.
                            if (this.origPagingInfo) {
                                this.collection.records.attributes.currentPage = this.origPagingInfo.currentPage;
                                this.collection.records.attributes.firstPage = this.origPagingInfo.firstPage;
                                this.collection.records.attributes.lastPage = this.origPagingInfo.lastPage;
                                this.collection.records.attributes.next = this.origPagingInfo.next;
                                this.collection.records.attributes.pageSize = this.origPagingInfo.pageSize;
                                this.collection.records.attributes.prev = this.origPagingInfo.prev;
                                this.collection.records.attributes.text = this.origPagingInfo.text;
                                this.collection.records.attributes.totalRecords = this.origPagingInfo.totalRecords;
                                this.collection.records.attributes.totalPages = this.origPagingInfo.totalPages;
                                this.searchResultsViewController.grid.getData().setPagingOptions(this.origPagingInfo);
                                delete this.origPagingInfo;
                            }
                            this.renderChildViews();
                        }
                    });
                }
            }
        },
        toggleAttributeSearch: function() {
            this.searchResultsViewController.tableEventsRef.trigger("stageAttributeSearch:toggleView");
        },
        showThumbnails: function() {
            // This trigger ensures that selected documents and page number information is correctly preserved when switching views
            this.searchResultsViewController.tableEventsRef.trigger("search:switching-to-thumbnail-view");
            this.updateBtnStyling(this.viewBtnMap[this.THUMBNAIL_VIEW]);
            var searchResult = this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                "objectType": this.type
            });

            // Re-render of child views will be required whenever user enters std table view or leaves std table view
            // This is because filter controls will be hidden in std view
            this.renderChildViewsRequired = searchResult.get("standardizedTableView");

            // Setting stdTableView to false since we are now in thumbnail view
            searchResult.set("standardizedTableView", false);
            this.options.tableViewMode = this.THUMBNAIL_VIEW_MODE;
            this.options.viewType = this.THUMBNAIL_VIEW;
            this.setViewTypeUserPref();
            //Updating the results per page variable, in case we are coming from standardized table
            this.searchResultsViewController.tableEventsRef.trigger("toggleFacetTab", true);

            app.searchView = this.THUMBNAIL;
            this.searchResultsViewController.tableEventsRef.trigger('search:changeView', this.THUMBNAIL_VIEW);
            // only need to render child views in VAD (reset our facets)
            if (this.context === HPIConstants.TableView.Context.VAD && this.renderChildViewsRequired) {
                this.renderChildViews();
            }
            this.searchResultsViewController.tableEventsRef.trigger('VAD:showThumbnails');
        },
        showLists: function() {
            // if thumbnail button is there it updates to listview
            this.updateBtnStyling(this.viewBtnMap[this.LIST_VIEW]);
            // This trigger ensures that selected documents and page number information is correctly preserved when switching views
            this.searchResultsViewController.tableEventsRef.trigger("search:switching-to-list-view");

            this.options.tableViewMode = this.LIST_VIEW_MODE;
            this.options.viewType = this.LIST_VIEW;

            //Updating the results per page variable, in case we are coming from standardized table
            this.searchResultsViewController.tableEventsRef.trigger("toggleFacetTab", true);

            app.searchView = this.LIST;
            this.searchResultsViewController.tableEventsRef.trigger('search:changeView', this.LIST_VIEW);
            // only need to render child views in VAD (reset our facets)
            if (this.context === HPIConstants.TableView.Context.VAD && this.renderChildViewsRequired) {
                this.renderChildViews();
            }
            this.searchResultsViewController.tableEventsRef.trigger('VAD:showLists');
        
        },
        showResetTableView: function() {
            // resetting facets before we destroy the grid.
            this.resetFacets();
            // Resetting the grid so that the selected documents are page numbers do not persist
            this.searchResultsViewController.resetGrid();
            // Unsetting the results per page from the user preferences 
            // Results per page will fall back to the default option configured in admin
            app.context.configService.getUserPreferences(function(currentUserPreferences) {
                currentUserPreferences.unset("resultsPerPage");
                currentUserPreferences.save();
            });

            this.updateBtnStyling(this.viewBtnMap[this.RESET_TABLE_VIEW]);
            // make sure Standardized Table View is off
            this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                "objectType": this.type
            }).set("standardizedTableView", false);

            this.options.tableViewMode = this.TABLE_VIEW_MODE;
            this.options.viewType = this.TABLE_VIEW;

            // reset text filters
            this.resetFilter();
            // Resetting role based dropdown name, resetting facets and unsetting role based views on the user preference               
            this.searchResultsViewController.tableEventsRef.trigger("roleBasedView:reset:dropdown:text");
            this.searchResultsViewController.tableEventsRef.trigger("roleBasedView:reset:userPreferences");
            this.searchResultsViewController.tableEventsRef.trigger("toggleFacetTab", true);

            app.searchView = HPIConstants.TableView.ViewType.ResetTableView;
            this.searchResultsViewController.tableEventsRef.trigger('search:changeView', this.RESET_TABLE_VIEW);

            // only need to render child views in VAD (reset our facets)
            if (this.context === HPIConstants.TableView.Context.VAD) {
                this.searchResultsViewController.tableEventsRef.trigger('VAD:showResetTableView');
                this.renderChildViews();
            }
        },
        standardizedTableView: function() {
            if (this.highlightedBtn !== this.viewBtnMap[this.STANDARDIZED_TABLE_VIEW]) {
                // resetting facets before we destroy the grid.
                this.resetFacets();
                // Resetting the grid so that the selected documents are page numbers do not persist when generatind std view
                this.searchResultsViewController.resetGrid();
                // resetting role based views if they exist 
                this.searchResultsViewController.tableEventsRef.trigger("roleBasedView:reset:dropdown:text");
                // prevent weird re-sorting behavior
                this.updateBtnStyling(this.viewBtnMap[this.STANDARDIZED_TABLE_VIEW]);
                // change config to enable the Standardized Table View
                this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                }).set("standardizedTableView", true);
                this.options.tableViewMode = this.TABLE_VIEW_MODE;
                this.options.viewType = this.STANDARDIZED_TABLE_VIEW;
                this.setViewTypeUserPref();
                // reset text filters
                this.resetFilter();

                this.searchResultsViewController.tableEventsRef.trigger("toggleFacetTab", false);

                app.searchView = this.TABLE;
                this.searchResultsViewController.tableEventsRef.trigger('search:changeView', this.STANDARDIZED_TABLE_VIEW);
                // we want to reset the child views in case we switch back to a different search view (VAD ONLY)
                if (this.context === HPIConstants.TableView.Context.VAD) {
                    //Store the paging info before going into the Standardized Table view
                    //This will allow us to reset the pagination info when leavining Standardized Table
                    this.origPagingInfo = _.clone(this.collection.records.attributes);
                    this.renderChildViews();
                    this.searchResultsViewController.tableEventsRef.trigger('VAD:showStandardizedTableView');
                }
            }
        },
        resetFacets: function() {
            if (this.options.facets) {
                this.searchResultsViewController.tableEventsRef.trigger("facets:reset");
            }
        },
        resetFilter: function() {
            if (!(_.isEmpty(this.filterControl.filter))) {
                this.searchResultsViewController.tableEventsRef.trigger("filter:reset");
            }
        },
        topOfPage: function() {
            $("html, body").animate({ scrollTop: 0 }, 300);
        },
        toggleIncludeIndexPage: function(e){
            this.searchResultsViewController.includeIndexPage = e.target.checked;
        },
        // updates button styling as the user clicks view mode buttons
        updateBtnStyling: function(selectedBtnId) {
            $(this.highlightedBtn).removeClass("btn-hpi");
            $(selectedBtnId).addClass("btn-hpi");
            this.highlightedBtn = selectedBtnId;
        },
        renderChildViews: function() {
            var config = {
                collection: this.collection
            };

            this.removeView('#search-result-pagination-controls-' + this.cid);
            this.removeView('#search-result-action-controls' + this.cid);
            this.removeView('#search-result-results-control' + this.cid);
            this.removeView('#search-result-filter-control-' + this.cid);

            if (_.isNull(this.type)) {
                this.setType();
            }

            // Adding info about if user is in standardized table view to the options so that it can be accessed by the paginationControls object 
            if (this.options.searchResults && this.type) {
                var searchResult = this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                });
                var standardizedTableView = searchResult.get("standardizedTableView");
                var standardizedTableViewEnabled = searchResult.get("standardizedTableViewEnabled");
                this.options.standardizedTableView = (standardizedTableViewEnabled && standardizedTableView);
            }

            this.paginationControls = new SearchResultControls.Views.PaginationControls(this.options, config);
            this.actionControls = new SearchResultControls.Views.ActionsControl(this.options, config);
            this.numResultsControl = new SearchResultControls.Views.ResultsMessage(this.options, config);

            var views = {};
            views['#search-result-pagination-controls-' + this.cid] = this.paginationControls;
            views['#search-result-action-controls-' + this.cid] = this.actionControls;
            views['#search-result-results-control-' + this.cid] = this.numResultsControl;
            this.setViews(views);

            var isStandardViewOn = false;

            if (this.context === HPIConstants.TableView.Context.VAD) {
                isStandardViewOn = this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                }).get("standardizedTableView");
            }
            if (!isStandardViewOn && this.context !== HPIConstants.TableView.Context.ACTPDF) {
                if (!this.filterControl) {
                    this.filterControl = new SearchResultControls.Views.FilterControl(this.options, config);
                } else {
                    this.filterControl.reapplyViews();
                    this.filterControl.startListening();
                }
                this.setView('#search-result-filter-control-' + this.cid, this.filterControl);
            }
        
        },
        afterRender: function() {
            this.rendered = true;
            this.toggleControls();

            var viewType = this.options.viewType && this.options.viewType.activeViewName ? this.options.viewType.activeViewName : this.options.viewType;
            if (viewType) {
                this.updateBtnStyling(this.viewBtnMap[viewType]);
            }
            this.atTop();
        },
        serialize: function() {
            var enableThumbnailGridView = false;
            var standardizedTableView = false;
            var resetTableViewEnabled = false;
            var standardizedTableViewEnabled = false;

            if (_.isNull(this.type)) {
                this.setType();
            }

            if (this.options.searchResults && this.type && this.context !== HPIConstants.TableView.Context.ACTPDF) {
                var searchResult = this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                });
                enableThumbnailGridView = searchResult.get("enableThumbnailGridView");
                standardizedTableView = searchResult.get("standardizedTableView");
                resetTableViewEnabled = searchResult.get("resetTableViewEnabled");
                standardizedTableViewEnabled = searchResult.get("standardizedTableViewEnabled");
            }

            return {
                'cid': this.cid,
                'thumbnailViewBtnEnabled': enableThumbnailGridView,
                'tableViewBtnEnabled': enableThumbnailGridView || standardizedTableViewEnabled,
                'standardizedTableViewEnabled': standardizedTableViewEnabled,
                'resetTableViewEnabled': resetTableViewEnabled,
                'showFilterControls': !(standardizedTableViewEnabled && standardizedTableView),
                'showIndexPageCheckbox': this.searchResultsViewController.showIndexPageCheckbox,
                'includeIndexPage' : this.searchResultsViewController.includeIndexPage,
                'stageAttributeSearchEnabled': !(standardizedTableViewEnabled && standardizedTableView) && this.searchResultsViewController.stageAttributeSearchEnabled,
                'showingSearchResultsInStage': this.searchResultsViewController.showingSearchResultsInStage
            };
        },
        cleanup: function() {
            this.stopListening();
            if (this.paginationControls) {
                this.paginationControls.cleanup();
            }
            if (this.actionControls) {
                this.actionControls.cleanup();
            }
            if (this.filterControl) {
                this.filterControl.cleanup();
            }

            // ensure standardized view is off
            if (this.options.searchResults && this.type) {
                this.options.searchResults.get("resultsConfig").get("resultsTableConfig").get("types").findWhere({
                    "objectType": this.type
                }).set("standardizedTableView", false);
            }
        }
    });

    // Return the module for AMD compliance.
    return SearchResultControls;
    });