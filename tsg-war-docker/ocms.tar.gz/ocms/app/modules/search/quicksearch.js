// Advancedsearch module
define([
	// Application.
	"app",
	"modules/services/exitservice"
],

// Map dependencies from above array.
function(app, ExitService) {

	// Create a new module.
	var QuickSearch = app.module();

	QuickSearch.ViewModel = function(query, selectedType, openAnnotateSearchEnabled) {
		
		var self = this;
		self.searchCriteria = ko.observable();
		self.selectedType = selectedType;
		self.openAnnotateSearchEnabled = openAnnotateSearchEnabled;

		self.results = kb.collectionObservable(query || new Backbone.Collection());

		self.search = function() {
			app.trigger('facets:clearSnapshot', true);
			app.trigger("search:execute");
			app.trigger('searchExecuted:renderSavedSearch');

			// Check to see if openAnnotateSearch is enabled.  If so, then we want to add that value to local storage.
			if (self.openAnnotateSearchEnabled) {
				window.localStorage.setItem("openAnnotateSearchValue", this.searchCriteria());
			}
		};

		self.updateSearchParams = function() {
			//iterate through all search params. if the 'allproperties' param exists already, update it. if not, add it
			var foundAllProperties = false;
			_.map(query.searchParameters, function(sParam){
				if(sParam.paramType === 'allproperties'){
					//TODO is this appropriate to do here, or should facets clean them selves based on some event?
					sParam.paramValue = self.searchCriteria();
					foundAllProperties = true;
				}
			});
			if (!foundAllProperties && self.searchCriteria() !== '') {
				var sp = {
					paramName: "allproperties",
					paramValue: self.searchCriteria(),
					paramType : "allproperties"
				};
				query.searchParameters.push(sp);
			}
			
		};

		self.clearAllValues = function() {
			self.searchCriteria("");
			self.updateSearchParams();
		};

	};

	// Default View.
	QuickSearch.Views.Layout = Backbone.Layout.extend({
		template: "search/quicksearch",

		initialize: function() { 
			this.searchConfig = this.options.model;
			this.selectedType = this.options.selectedType;
			this.queryObject = this.options.query;

			// Register an ExitService event so that when we leave/close the page, we clear the fullTextSearch localStorage value.
			ExitService.register('openannotatesearch.clear', function() {
				window.localStorage.removeItem("openAnnotateSearchValue");
			});
		},

		afterRender: function() {
			var self = this;
			var openAnnotateSearchEnabled = self.searchConfig.get("sidebarConfig").get("openAnnotateSearchEnabled");
			var viewModel = new QuickSearch.ViewModel(this.options.query, this.options.selectedType, openAnnotateSearchEnabled);

			// lets parse some search parameters
			_.each(this.queryObject.searchParameters, function(sp){
				if(sp.paramType === "allproperties")
				{
					viewModel.searchCriteria(sp.paramValue);
				}
			});
			if(self.selectedType() === null || self.selectedType() === undefined) { 
				app.log.error(window.localize("modules.search.quicksearch.error"));
			}

			// attempt to focus() the text box for usability
			$(this.el).find("input[type='text']").focus();

			kb.applyBindings(viewModel, this.$el[0]);

			if (!self.searchConfig.get("sidebarConfig").get("quickSearchEnabled")) {
				$("#quick-search-form").hide();
			}

			// If we dont have openAnnotateSearch enabled, then let's ensure that we dont have that variable is blank in local storage
			if (!openAnnotateSearchEnabled) {
				window.localStorage.removeItem("openAnnotateSearchValue");
			}

			this.listenTo(app, "search:clearQuickSearchValue search:runningSavedSearch", viewModel.clearAllValues);

			this.listenTo(this.options.query, 'sync', function(){
				_.map(this.options.query.searchParameters, function(sParam){
					if(sParam.paramType === 'allproperties'){
						//TODO is this appropriate to do here, or should facets clean them selves based on some event?
						viewModel.searchCriteria(sParam.paramValue);
					}
				});
			});

			this.listenTo(app, "updateQuickSearchValue" , function(value){
				viewModel.searchCriteria(value);
				viewModel.updateSearchParams();
			});

		}
	});

	// Return the module for AMD compliance.
	return QuickSearch;

});
