// Facetsearch module
define([
    "app"
],
function(app) {

    // Create a new module.
    var Facetsearch = app.module();

    Facetsearch.Events = _.extend({}, Backbone.Events);

    // this updates the URL with the checked or unchecked facet and triggers the router
    Facetsearch.facetURLNav = function(facetAttr, facetValue) {
        var curUrl = Backbone.history.fragment.split("search/")[1];
        if(curUrl){
        var urlParts = curUrl.split("/");
        var newUrl = urlParts[0] + "/" + urlParts[1];
        var remainingUrlParts = [];
        for (var i = 2; i < urlParts.length; i++) {
            remainingUrlParts[i - 2] = urlParts[i];
        }

        // get all of the non-facet urlParts - we will add these wholesale to the url later
        var nonCurrentFacetParts = _.reject(remainingUrlParts, function(urlPart) {
            return urlPart.indexOf("paramType=facet") !== -1 && urlPart.indexOf("paramName=" + facetAttr) !== -1;
        });

        // we only add facets to the url if they actually have a value
        if (!_.isEmpty(facetValue)) {
            var currentFacetPart = "paramName=" + facetAttr + "&paramType=facet&";
            _.each(facetValue, function(value) {
                currentFacetPart += "paramValue[]=" + value + "&";
            });
            //take off trailing &
            currentFacetPart = currentFacetPart.slice(0, -1);
            newUrl += "/" + currentFacetPart;
        }

        // add back in all of the non-facet url parts
        _.each(nonCurrentFacetParts, function(part) {
            newUrl += "/" + part;
        });

        Backbone.history.navigate("search/" + newUrl);
            }
    };


    Facetsearch.Facet = function(facetAttr, facetLabel, facetFields, selectedFacets, searchResultsViewController) {
        var self = this;

        // this is the label of the facet field to display
        self.facetLabel = facetLabel;
        self.facetAttr = facetAttr;
        self.selectedFacets = selectedFacets;
        self.searchResultsViewController = searchResultsViewController;

        // figure out if this current facet has been selected by being included in the selectedFacets
        // collection. if it is, save the checked values to instantiate the observableArray that controls
        // the checkboxes. this codeblock only matters when the url hit has facets included.
        if (self.selectedFacets.get(self.facetAttr) &&
            self.selectedFacets.get(self.facetAttr).get("checked")) {
            self.checkedItems = self.selectedFacets.get(self.facetAttr).get("checked");
        } else {
            self.checkedItems = [];
        }

        // this is the list of entries for the facet field that have a count greater than 0
        self.entries = ko.observableArray([]);

        // sanity check, make sure that the facet we are instantiating was included in the facetFields object we created earlier
        var facetEntries = facetFields[self.facetAttr];
        if (facetEntries) {
            // this array controls the checkboxes on the DOM for its facet
            self.chosenEntries = ko.observableArray(self.checkedItems).extend({ deferred: true });
            self.chosenEntries.subscribe(function(allEntries) {
                // Resetting the text in the dropdown whenever user manually selects a facet 
                self.searchResultsViewController.tableEventsRef.trigger("roleBasedView:reset:dropdown:text");
                var start = new Date().getTime();
                // everytime a checkbox is clicked, look at the "allEntries" array that the subscribe passes in, this array contains
                // the values on the checkboxes from the DOM. have the logic react accordingly based on the values.
                if (_.isEmpty(allEntries)) {
                    self.selectedFacets.remove(self.facetAttr);
                } else if (self.selectedFacets.get(self.facetAttr)) {
                    // Setting the selected facets based on the attribute that is just selected. This used to happen automatically until role based views 
                    var currentSelectedFacet = _.findWhere(self.selectedFacets.models, {id : self.facetAttr});
                    currentSelectedFacet.attributes.checked = allEntries;
                    // we already have this facet added and the observable is keeping the "checked" attr
                    // up-to-date, so just trigger an add
                    self.selectedFacets.trigger("add");
                } else {
                    self.selectedFacets.add({
                        id: self.facetAttr,
                        checked: allEntries
                    });
                }
                // update the URL
                Facetsearch.facetURLNav(self.facetAttr, allEntries);
                var done = new Date().getTime() - start;
                app.log.debug(done / 1000);
            });

            // loop over all the facet entries that have a count greater than 0 and create a facet entry view model for them
            _.each(facetEntries, function(facetCount, facetEntry) {
                if (facetCount > 0) {
                    var facetEntryVM = {
                        // the text to display for this facet entry
                        text: facetEntry,
                        // the count of this facet entry surround by parentheses
                        count: "(" + facetCount + ")"
                    };
                    self.entries.push(facetEntryVM);
                }
            });
        }

        return self;
    };

    Facetsearch.ViewModel = function(options) {
        var self = this;
        self.facetConfig = options.facetConfig;
        self.query = options.query;
        self.selectedFacets = options.selectedFacets;
        self.searchResultsViewController = options.searchResultsViewController;

        // used to display a helper message if a search hasn't occurred yet
        self.hasSearched = ko.observable(false);
        self.facets = ko.observableArray([]);

        // options.objectType is an observable!
        self.objectType = options.objectType;

        // update the facets on the view
        self.updateFacets = function(newQuery) {
            // let's start fresh by getting rid of the old facets
            self.facets.removeAll();
            self.facetFields = {};

            // If no specific object type is selected then all object types are chosen for faceted search
            // When coming from the context of VAD, we want to assume that the objectType is null
            if(!self.objectType || (Backbone.history.fragment.indexOf("Stage") !== -1) ){
                var facetObjectTypes = self.facetConfig.get("types").models;
                var displayedAttrs = [];
                _.each(facetObjectTypes, function(facetObjectType){
                        self.objectType = facetObjectType;
                       _.each(facetObjectType.get("facetableAttributes"), function(facetAttr) {
                        // making sure that there is only one facet per attribute name even if different types have the same attribute name 
                        if(displayedAttrs.indexOf(facetAttr.attrLabel) === -1){
                            // get the label for our facet attribute
                            app.context.configService.getLabels(self.objectType.get("objectType"), facetAttr.attrName).done(function(label) {
                                self.populateAndSortFacets(newQuery, facetAttr, label);
                                displayedAttrs.push(facetAttr.attrLabel);
                            });
                        }
                    }); 
                });
            }else{
                // account for differences between stage and view all documents
                var objType = _.isFunction(self.objectType) ? self.objectType().type : self.objectType.get("objectType");
            // find the selected object type's facet configuration
            var facetObjectType = self.facetConfig.get("types").findWhere({
                    objectType: objType
            });

            // if there is a configuration for this object type in the facet configuration
            if (facetObjectType) {
                    // loop over all the configured facet fields for this object type
                _.each(facetObjectType.get("facetableAttributes"), function(facetAttr) {
                    // get the label for our facet attribute
                        app.context.configService.getLabels(objType, facetAttr.attrName).done(function(label) {
                            self.populateAndSortFacets(newQuery, facetAttr, label);
                        });
                    });
                }
            }
           
        };

        self.populateAndSortFacets = function(newQuery, facetAttr, label){
            // loop through every result and see how many values show up for a particular attribute, this
            // let us show the count per facet in the facet view
            newQuery.fullCollection.each(function(queryResult){
                self.pushFacetValuesFromQueryResult(queryResult,facetAttr);
            });

            //sorting the results of each facet so that they appear in alphabetical order 
            var sortingField = facetAttr.attrName;
            if(self.facetFields[sortingField]){
                var input = Object.keys(self.facetFields[sortingField]).sort();
                var output = {};
                _.each(input, function(key){
                    // alfresco returns null strings and dctm returns blank string so both have to be addressed
                    if(key !== "null" && key !== ""){
                        output[key] = self.facetFields[sortingField][key];
                    }
                });
                self.facetFields[sortingField] = output;
                self.facets.push(new Facetsearch.Facet(facetAttr.attrName, label, self.facetFields, self.selectedFacets, self.searchResultsViewController));
            }
        };

        self.pushFacetValuesFromQueryResult = function(queryResult,facetAttr) {
            var self = this;
            var facetValues = [];
            if (_.isArray(queryResult.get("properties")[facetAttr.attrName])) {
                facetValues = queryResult.get("properties")[facetAttr.attrName];
            } else {
                if(queryResult.get("properties")[facetAttr.attrName]!== undefined){
                    facetValues.push(queryResult.get("properties")[facetAttr.attrName]);
                }
                
            }

            _.each(facetValues, function(facetValue) {
                if (!self.facetFields[facetAttr.attrName]) {
                    self.facetFields[facetAttr.attrName] = {};
                }

                if (!self.facetFields[facetAttr.attrName][facetValue]) {
                    self.facetFields[facetAttr.attrName][facetValue] = 1;
                } else {
                    self.facetFields[facetAttr.attrName][facetValue] += 1;
                }
            });
        };

        return self;
    };

    Facetsearch.Views.Layout = Backbone.Layout.extend({
        template: "search/facetsearch",
        events: {
            'click #facet-reset': 'resetFacetsAndUnsetRoleBasedView'
        },
        initialize: function(options) {
            this.searchResultsViewController = options.searchResultsViewController;

            // grab the facet configuration and the collection containing the query
            this.facetConfig = options.searchConfig.get("sidebarConfig").get("facetConfig");
            // this collection lets us keep track of what facets have been selected and update
            // the result set accordingly
            this.selectedFacets = new Backbone.Collection();

            this.query = this.collection;
            this.urlFacets = false;

            // instantiate the facet search view model providing the facet configuration, the query, the currently selected object type,
            // and the selectedFacets
            this.viewModel = new Facetsearch.ViewModel({
                facetConfig: this.facetConfig,
                query: this.query,
                objectType: this.options.selectedType,
                selectedFacets: this.selectedFacets,
                searchResultsViewController: this.searchResultsViewController
            });

            this.parseURL();            

            //facets are only supported for client-side implementations right now
            if (this.query.mode === 'client') {
                //see if any results have already come back
                this.viewModel.hasSearched(this.query.records.get('totalRecords'));
                //setup facets  if the query has already tun
                if (this.viewModel.hasSearched()) {
                    this.setupFacets(this.query);
                }
            }
            
            this.stopListening();
            this.startListening();
        },
        parseURL: function() {
			var self = this;
            // we want to be able to save URLs with facets in them and have them work
            // get everything in the URL after the "search" word
            var loadedUrl = Backbone.history.fragment.split("search");
            // split up the rest of the URL
            var urlParts = [];
            if(loadedUrl.length > 1){
                urlParts = loadedUrl[1].split("/");
            }
            self.urlFacets = [];
            // if there are parts to this URL then there should be some search parameters
            if (urlParts.length > 1) {
                // get our facets from the URL
                self.urlFacets = _.filter(urlParts, function(urlPart) {
                    return urlPart.indexOf("paramType=facet") !== -1;
                });

                if (self.urlFacets.length > 0) {
                    // for each urlPart which is a facet, parse it and create new models in our selectedFacet collection
                    _.each(self.urlFacets, function(urlFacet) {
                        var facetParts = urlFacet.split("paramType=facet"),
                            facetAttr, facetValues;
                        _.each(facetParts, function(facetPart) {
                            // strip out the "&" character so we don't have to care if this was the first urlPart or
                            // subsequent ones and also decode the part
                            facetPart = decodeURIComponent(facetPart.replace(/&/g, ""));
                            if (facetPart.indexOf("paramName") !== -1) {
                                facetAttr = facetPart.replace(/paramName=/g, "");
                            } else if (facetPart.indexOf("paramValue") !== -1) {
                                facetValues = facetPart.split("paramValue[]=");
                                // remove any blank values from the array
                                facetValues = _.without(facetValues, "");
                            }
                        });
                        // this is a bit confusing, but this will not set off the listener to update results
                        // since it happens before the listener is setup. this is actually good, since we need
                        // to wait for the query's fetch to return, so we let the sync below handle updating results
                        self.selectedFacets.add({
                            id: facetAttr,
                            checked: facetValues
                        });
                    });

                }
            }
        },
        startListening: function() {
            // subscribe to the query and update the facets in the viewmodel
            // temporary fix to avoid going into the if statement on line 435 that didn't allow a search after selecting facets
            this.listenTo(app, "facets:clearSnapshot", function(clearSnapshot){
                if(clearSnapshot) {
                    this.query.snapshot = undefined;
                }

                this.setupFacets(this.query);
            }, this);

            // listener that triggers whenever a facet checkbox is selected
            this.listenTo(this.selectedFacets, "add remove", this.updateResults, this);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:updateFacetResults", this.updateResults);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "roleBasedView:applyFilters", this.roleBasedViews);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "facets:reset", this.resetFacets);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "facets:setupFacets", function(){
                this.setupFacets(this.query);
            }, this);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "roleBasedView:reset:userPreferences", this.resetRoleBasedViewUserPreference);
        },
        resetFacetsAndUnsetRoleBasedView: function(evt) {
            if(evt) {
                evt.preventDefault();
            }
           
            // reset the role based view dropdown text but only when the reset facets button is actually clicked 
            this.searchResultsViewController.tableEventsRef.trigger("roleBasedView:reset:dropdown:text");
            this.resetRoleBasedViewUserPreference();
            this.resetFacets();
        },
        resetRoleBasedViewUserPreference: function() {              
            // setting no rolebased views as the default on the user preferences 
            app.context.configService.getUserPreferences(function(currentUserPreferences){
                currentUserPreferences.unset("roleBasedView");
                currentUserPreferences.save ();
            });
        },
        resetFacets: function() {
            if(this.selectedFacets.length > 0){
                var query = this.query.snapshot;
                if(query){
                    this.fullResults = query.fullCollection.clone();
                    this.selectedFacets.reset([]);           
                    this.viewModel.updateFacets(query);  
                    this.urlFacets = []; 
                    // This ensures that we only reload results when reset facets is triggered and not when reset tableview is called
                    // Resetting tableview will automatically trigger a reload results when the tableview is done rendering           
                    this.updateResults(true);
                }
            }  
        },
        facetContainsValue: function(facet, value){
            // checking if the value already exists in the list of facet attributes 
            var exists = _.find(facet.entries(), function(existingFacets){
                return existingFacets.text.indexOf(value) !== -1;
            });

            return exists;
        },
        roleBasedViews: function(roleBasedFilters){
            // resetting facets to get rid of any facets that might already have been selected
            this.resetFacets();
            var self = this;
            
            _.each(roleBasedFilters, function(model){
                self.applyRoleBasedFilters(model);
            });  

            // re-rendering the view makes sure that the checkboxes are checked when the user opens the popover
            this.render();  
        },
        applyRoleBasedFilters: function(model){

            var self = this; 

            // this ensures that the actual filtering takes place. Makes sure to only filter for those attributes that have predefined filters configured
            if(model.values.length > 0){ 

                // adding the facet to the list of facets for which atleast one value is seleceted
                var newFacet = this.selectedFacets.add({
                    id: model.ocName,
                    checked: []
                });

                // adding the preselected values to the filter
                newFacet.attributes.checked = model.values;
                this.selectedFacets.trigger("add");

                // checking the checkboxes in the popover view
                var facet = _.findWhere(this.viewModel.facets(),{facetAttr: model.ocName});
                _.each(model.values, function(preSelectedValue){
                    
                    // checking if facets used in predefined views contains the value it is configured to filter on
                    var exists = self.facetContainsValue(facet, preSelectedValue);

                    // If they don't exist then we add them to the list with count set to zero
                    if(!exists){
                        facet.entries().push({ text: preSelectedValue, count: "(0)"});
                    }
                    
                    facet.chosenEntries().push(preSelectedValue);
                });
            }   
        },
        setupFacets: function(newQuery) {
            app.log.debug('setting up facets...');
            // clone the full results so we can always have them when we are updating results based on facets
            this.fullResults = newQuery.fullCollection.clone();
            // we now know a search has taken place so we can hide the helper message
            this.viewModel.hasSearched(true);
            // if there were urlFacets, we cannot clear out the already setup self.selectedFacets collection, but
            // any other time we hit this sync, a new query has run and we need to reset the facet collection
            if (this.urlFacets.length === 0) {
                this.selectedFacets.reset([]);
            }
            this.viewModel.updateFacets(newQuery);
            //clear urlFacets so the above check passes next time
            this.urlFacets = [];
        },
        // this function handles the magic of updating the tableview with the correct result set when facets are used
        updateResults: function(isReloadResultsRequired) {
            var self =this;
            this.facetResults = [];

            if(this.selectedFacets.size() === 0 ){
                // stop listening to updates while applying facets - otherwise we get a heaplosion  of updates
                this.stopListening();
                //no facets selected, rollback to the internal snapshot
                this.query.setFacets(false);
                
                //Resetting to the original search results.
                if(this.query.snapshot) {
                    this.collection.reset(this.query.snapshot.fullCollection.models);
                    this.query.fullCollection.reset(this.query.snapshot.fullCollection.models);
                    if(isReloadResultsRequired) {
                        this.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
                    }
                }
                
                // notify search result controls
                this.searchResultsViewController.tableEventsRef.trigger('search:results:facet', this.query);
                this.searchResultsViewController.tableEventsRef.trigger("filter:collection", this.collection);

                // ready for updates
                this.startListening();
                return;
            }
            // loop through all of the search results - we want this logic to immediately fall out of looping
            // if the result we are on DOES NOT match the facet criteria
            this.fullResults.each(function(currentResultItem) {
                // this logic has the potential to do lots of looping, so let's optimize it. it is much faster to STOP
                // looping the second that a facet value does NOT match the current result's value. we want to use a
                // .find since .find stops looping through values on the first truthy return, we then modify the .find
                // logic to return TRUE only when a result does not match.
                var resultNotInSet = this.selectedFacets.find(function(currentFacet){
                    return self.checkIfResultsNotInSet(currentFacet,currentResultItem);
                });

                // if the above logic returns "undefined", it means each facet value checked matched for this currentResultItem,
                // so add it to an array
                if (!resultNotInSet) {
                    this.facetResults.push(currentResultItem);
                }
            }, this);
            // stop listening to updates while applying facets - otherwise we get a heaplosion  of updates
            this.stopListening();
            //snapshot the query as if we're filtering it
            this.query.setFacets(this.selectedFacets);
            //attach the modified collection to the query - deep-copy it
            this.query.fullCollection.reset(_.extend([], this.facetResults));
            //snapshot the facets state
            this.query.snapshotFacets();
            
            this.collection.reset(this.query.fullCollection.models);
            // do a wholesale reset of the query's fullCollection and tell tableview that it has changed by triggering "resultsHaveMutated"
            this.searchResultsViewController.tableEventsRef.trigger('search:results:facet', this.query);
            this.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
            this.searchResultsViewController.tableEventsRef.trigger("filter:collection", this.collection);
            // ready for updates
            this.startListening();
        },
        // role based views cookies are applied here because the facets are only rendered once.
        beforeRender: function(){
            var self = this;

            // Only check for user preferences when user is in stage 
            if(Backbone.history.fragment.indexOf("Stage") !== -1){

                // checking user preferences to see if role based views need to be applied
                app.context.configService.getUserPreferences(function(currentUserPreferences) {

                    // Checking if a role based view has been set on the user preferences
                    if(currentUserPreferences.get("roleBasedView")){
                        // getting the type of the predefined view and ensuring that it has not been deleted in the config 
                        var filterType = currentUserPreferences.get("roleBasedView").type;
                        var typeConfig = _.find(self.options.searchConfig.get("sidebarConfig").get("facetConfig").get("types").models, function(model) {
                                    return model.get("objectType") === filterType;
                        });
                        if(typeConfig){
                             self.preDefinedFilterExists = _.find(typeConfig.get("filters").filters, function(filter){
                                return filter.label === currentUserPreferences.get("roleBasedView").name;
                            });
                        }

                        if(self.preDefinedFilterExists){
                            var text = currentUserPreferences.get("roleBasedView").name;

                            // setting dropdown name and results message
                            self.searchResultsViewController.tableEventsRef.trigger("set:rolebased:name", text);
                       
                            var roleBasedFilters = currentUserPreferences.get("roleBasedView").filters;
                            // if results are returned for the search and the role based type in the user preferences is configured for the correct type then we apply it 
                            if (roleBasedFilters && self.fullResults) {
                                // resetting facets to get rid of any facets that might already have been selected
                            	self.resetFacets();
                                
                                // Adding the role based filters to the selected facets
                                _.each(roleBasedFilters, function(model){
                                    self.applyRoleBasedFilters(model);
                                });  
                            }
                        }    
                    }
                    
                });
            }
        },
        afterRender: function() {
            ko.applyBindings(this.viewModel, this.$el[0]);

            //the following popover logic needs to be in after render
            //because this.el will only contain the template html after render is called
            if(Backbone.history.fragment.indexOf("Stage") !== -1){
                // this will destroy the popover if it is already active
                // reinitializing the popover while already active will cause problems
                $("#facetSearch-popup-outlet").popover("destroy");

                $("#facetSearch-popup-outlet").popover({
                    html: true,
                    content: this.el,
                    title: "Select Facets to filter on",
                    placement: 'bottom'
                });
    
                // listener for clicking on all popovers
                // we do this with the generic popover class because there will always only be one 
                // popover open at a time
                $('body').on('click', function(e) {
                    // if we click anywhere outside of the popover, close it.
                    //  !$("#facetSearch-popup-outlet").is(e.target) : if target isn't the popover div
                    //  $("#facetSearch-popup-outlet").has(e.target).length : if the target doesn't have the popover div as a parent
                    //  $('.popover').has(e.target).length : if the target doesn't have the bootstrap popover class as a parent
                    if (!$("#facetSearch-popup-outlet").is(e.target) && $("#facetSearch-popup-outlet").has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                        $("#facetSearch-popup-outlet").popover('hide');
                    }
                });
            }
        },

        cleanup: function() {
            app.log.debug('cleaning up facets');
            this.stopListening();
            $('body').off('click');
        },

        checkIfResultsNotInSet: function(currentFacet,currentResultItem) {
            var arrayOfValues = [];
            // repeating attr support, if the result is an array, just copy it to our "arrayOfValues", else
            // if it is a single value, push it onto the array
            if (_.isArray(currentResultItem.get("properties")[currentFacet.get("id")])) {
                arrayOfValues = _.map(currentResultItem.get("properties")[currentFacet.get("id")], function(item) {
                    return item.toString();
                });
            } else {
                if(currentResultItem.get("properties")[currentFacet.get("id")]){
                    arrayOfValues.push(currentResultItem.get("properties")[currentFacet.get("id")].toString());
                }
                
            }

            // if our current arrayOfValues has an intersection with the checked values of the facet,
            // it means this result does match and self.foundValue will NOT be empty. we need to return
            // FALSE below so the .find continues to look for something that does not match.
            this.foundValue = _.intersection(currentFacet.get("checked"), arrayOfValues);
            return _.isEmpty(this.foundValue);
        }
    });

    return Facetsearch;
});