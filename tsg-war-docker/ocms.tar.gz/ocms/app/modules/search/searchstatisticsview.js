// SearchStatisticsView module
define([
  "app",
  "modules/common/hpiconstants"
],

// Map dependencies from above array.
function(app, HPIConstants) {

  // Create a new module.
  var SearchStatisticsView = app.module();

  SearchStatisticsView.Views.Layout = Backbone.Layout.extend({
	template: "search/loadtime",

	initialize: function(options) {

        var collection = options.collection;

        this.networkTime = collection.networkTime;
        this.queryBuildTime = collection.queryBuildTime;
        this.queryExecuteTime = collection.queryExecuteTime;
        this.queryParseTime = collection.queryParseTime;
        this.formatResultsTime = collection.formatResultsTime;
        this.tableViewRenderTime = collection.tableViewRenderTime;
        this.totalTime = collection.totalTime;
        this.OCCallTime = collection.ocCallTime;
        this.OCMSTotalTime = collection.OCMSTotalTime;

        var config = options.config;

        this.numberOfDecimalPlaces = HPIConstants.TableView.SearchStatistics.NUMBEROFDECIMALS;
        
        // timing thresholds from configs
        this.networkTimeBad = config.get("networkTimeBad") || 2;
        this.networkTimeMedium = config.get("networkTimeMedium") || 1;

        this.queryBuildTimeBad = config.get("queryBuildTimeBad") || 2;
        this.queryBuildTimeMedium = config.get("queryBuildTimeMedium") || 1;

        this.queryExecuteTimeBad = config.get("queryExecuteTimeBad") || 2;
        this.queryExecuteTimeMedium = config.get("queryExecuteTimeMedium") || 1;

        this.queryParseTimeBad = config.get("queryParseTimeBad") || 2;
        this.queryParseTimeMedium = config.get("queryParseTimeMedium") || 1;

        this.tableViewRenderTimeBad = config.get("tableViewRenderTimeBad") || 2;
        this.tableViewRenderTimeMedium = config.get("tableViewRenderTimeMedium") || 1;

        this.formatResultsTimeBad = config.get("formatResultsTimeBad") || 2;
        this.formatResultsTimeMedium = config.get("formatResultsTimeMedium") || 1;

        // Other functionality of OC/OCMS that we didn't explicitly time
        this.OCMSOtherTime = this.OCMSTotalTime - this.tableViewRenderTime - this.formatResultsTime;
        this.OCOtherTime = this.OCCallTime - this.queryBuildTime - this.queryExecuteTime - this.queryParseTime;

    },

	afterRender: function() {
	      // Set the content of the popover
        $("#search-statistics-popover-outlet").popover({
            html: true,
            content: this.el,
            title: "Total Search Time: " + this.totalTime.toFixed(this.numberOfDecimalPlaces) + " " + window.localize("search.loadtime.seconds"),
            placement: "bottom"
        });

        // listener for clicking on all popovers
        // we do this with the generic popover class because there will always only be one 
        // popover open at a time
        $("body").on('click', function(e) {
          // if we click anywhere outside of the popover, close it.
          // !$("#search-statistics-popover-outlet").is(e.target) : if target isn't the popover div
          //  $("#search-statistics-popover-outlet").has(e.target).length : if the target doesn't have the popover div as a parent
          //  $('.popover').has(e.target).length : if the target doesn't have the bootstrap popover class as a parent
          if (!$("#search-statistics-popover-outlet").is(e.target) && $("#search-statistics-popover-outlet").has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
              $("#search-statistics-popover-outlet").popover('hide');
          }
        });
    },

    cleanup : function() {
      $('body').off('click');
    },

    serialize: function() {
        return {
            networkTime: this.networkTime.toFixed(this.numberOfDecimalPlaces),
            queryBuildTime: this.queryBuildTime.toFixed(this.numberOfDecimalPlaces),
            queryExecuteTime: this.queryExecuteTime.toFixed(this.numberOfDecimalPlaces),
            queryParseTime: this.queryParseTime.toFixed(this.numberOfDecimalPlaces),
            tableViewRenderTime: this.tableViewRenderTime.toFixed(this.numberOfDecimalPlaces),
            formatResultsTime: this.formatResultsTime.toFixed(this.numberOfDecimalPlaces),
            totalTime: this.totalTime.toFixed(this.numberOfDecimalPlaces),
            OCCallTime: this.OCCallTime.toFixed(this.numberOfDecimalPlaces),
            OCMSTotalTime: parseFloat(this.OCMSTotalTime, 10).toFixed(this.numberOfDecimalPlaces),
            OCMSOtherTime: parseFloat(this.OCMSOtherTime, 10).toFixed(this.numberOfDecimalPlaces),
            OCOtherTime: parseFloat(this.OCOtherTime, 10).toFixed(this.numberOfDecimalPlaces),
            // need to parseFloat otherwise timeColor will compare two string values
            networkTimeBad: parseFloat(this.networkTimeBad, 10),
            networkTimeMedium: parseFloat(this.networkTimeMedium, 10),
            queryBuildTimeBad: parseFloat(this.queryBuildTimeBad, 10),
            queryBuildTimeMedium: parseFloat(this.queryBuildTimeMedium, 10),
            queryExecuteTimeBad: parseFloat(this.queryExecuteTimeBad, 10),
            queryExecuteTimeMedium: parseFloat(this.queryExecuteTimeMedium, 10),
            queryParseTimeBad: parseFloat(this.queryParseTimeBad, 10),
            queryParseTimeMedium: parseFloat(this.queryParseTimeMedium, 10),
            tableViewRenderTimeBad: parseFloat(this.tableViewRenderTimeBad, 10),
            tableViewRenderTimeMedium: parseFloat(this.tableViewRenderTimeMedium, 10),
            formatResultsTimeBad: parseFloat(this.formatResultsTimeBad, 10),
            formatResultsTimeMedium: parseFloat(this.formatResultsTimeMedium, 10),
        };
    },
  });

  return SearchStatisticsView;

});
