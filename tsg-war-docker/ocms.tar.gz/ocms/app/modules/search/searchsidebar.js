// Searchsidebar module
define([
	// Application.
	"app",
	"modules/search/quicksearch",
	"modules/search/savedsearch",
	"modules/search/attributesearch",
	"modules/search/facetsearch",
	"modules/search/advancedsearch/advancedsearch",
	"modules/common/hpiconstants"
	],
// Map dependencies from above array.
function(app, QuickSearch, SavedSearch, AttributeSearch, FacetSearch, AdvancedSearch, HPIConstants) {
	// Create a new module.
	var SearchSidebar = app.module();

	SearchSidebar.ObjectType = function(type, label, composite)  { 
		if(composite) {
			return {
				type: type,
				label: label,
				composite: true
			};
		} else {
			return {
				type: type,
				label: label
			};
		}
	};

	SearchSidebar.Views.Tabs = Backbone.Layout.extend({
		template: "search/sidebar-tabs",
		
		initialize: function() {
			var asConfig = this.model.get("sidebarConfig").get("attributeSearchConfig");
			var csConfig = this.model.get("sidebarConfig").get("advancedSearchConfig");
			var fConfig = this.model.get("sidebarConfig").get("facetConfig");

			this.attributeSearchEnabled = asConfig.get("enabled");
			this.advancedSearchEnabled = csConfig.get("enabled");
			this.facetSearchEnabled = fConfig.get("enabled");

			this.searchResultsViewController = this.options.searchResultsViewController;
			this.numTabsEnabled = 0;
			this.query = this.options.query;
			this.selectedType = this.options.selectedType;
			this.subviewDeferreds = this.options.subviewDeferreds;

			this.sidebarTabsViewInitializationDeferred = $.Deferred();

			this.subviewDeferreds.push(this.sidebarTabsViewInitializationDeferred);

			// SearchSidebar.Views.Tabs needs to have the currentUserPreferences before it can be rendered
			// so check if the currentUserPreferences exists and if it doesn't fetch them before we create SearchSidebar.Views.Tabs
			if (!app.context.currentUserPreferences()) {
				app.context.configService.getUserPreferences(_.bind(function() {
					this.determineActiveSearch();
					this.initializeViews();
					this.startListening();
					this.sidebarTabsViewInitializationDeferred.resolve();
				}, this));
			} else {
				this.determineActiveSearch();
				this.initializeViews();
				this.startListening();
				this.sidebarTabsViewInitializationDeferred.resolve();
			}
		},

		determineActiveSearch: function() {
			if(app.context.currentUserPreferences().get('lastSearchType') && 
			app.context.currentUserPreferences().get('lastSearchType') === 'advanced' && this.advancedSearchEnabled === true) {
				this.searchActive = "advancedActive";
			} else if(app.context.currentUserPreferences().get('lastSearchType') && 
			app.context.currentUserPreferences().get('lastSearchType') === 'attribute' && this.attributeSearchEnabled === true) {
				this.searchActive = "attributeActive";
			} else {
				if(this.attributeSearchEnabled) {
					this.searchActive = "attributeActive";
				} else if (this.advancedSearchEnabled) {
					this.searchActive = "advancedActive";
				} else {
					this.searchActive = "facetActive";
				}
			}
		},
		initializeViews: function() {
			if(this.attributeSearchEnabled) {
				this.setView("#attributeSearch-tabDiv", new AttributeSearch.Views.Layout({
					searchConfig : this.model,
					collection : this.query,
					selectedType: this.selectedType,
					searchResultsViewController: this.searchResultsViewController
				}));

				this.numTabsEnabled += 1;
			}

			if(this.advancedSearchEnabled) {
				this.setView("#advancedSearch-tabDiv", new AdvancedSearch.LayoutView({
					searchConfig : this.model,
					collection : this.query,
					selectedType: this.selectedType,
					searchResultsViewController: this.searchResultsViewController
				}));
				this.numTabsEnabled += 1;
			}

			if(this.facetSearchEnabled) {
				this.setView("#facetSearch-tabDiv", new FacetSearch.Views.Layout({
					searchConfig : this.model,
					collection : this.query,
					selectedType: this.selectedType,
					searchResultsViewController: this.searchResultsViewController
				}));
				this.numTabsEnabled += 1;
			}
		},
		startListening: function(){
			this.listenTo(this.searchResultsViewController.tableEventsRef, "toggleFacetTab", this.toggleFacetTab, this);
		},
		serialize: function() {
			return {
				attributeSearchEnabled: this.attributeSearchEnabled,
				advancedSearchEnabled: this.advancedSearchEnabled,
				facetSearchEnabled: this.facetSearchEnabled,
				searchActive: this.searchActive
			};
		},
		afterRender: function() {
			if (!this.model.get("sidebarConfig").get("quickSearchEnabled") && this.numTabsEnabled <= 1) {
				$("#quicksearch-outlet").hide();
				$("#search-sidebar-tabs").hide();
			} 
			app.log.debug("Search Tabs Rendered.");
			app.trigger("advancedsearch:clearform");
			app.trigger("renderAdvancedSearch");

			if(this.model.get("sidebarConfig").get("folderViewTypeSelection")) {
				var tempSelectedLabel = this.selectedType().label;
				var tempAllTypes = $('span.typeChange');
				_.each(tempAllTypes, function(type) {
					if(type.innerText === tempSelectedLabel) {
						$(type).addClass('highlightThis');
					}
				});
				app.trigger('folderViewTypeSelection-loadColumnHeaders', this);
			}
		},
		toggleFacetTab: function(showFacetTab) {
			if(showFacetTab) {
				$('#facet-tabLink').show();
				$("#facetSearch-tabDiv").removeAttr( 'style' );
				this.numTabsEnabled++;
			} else {
				$('#facet-tabLink').hide();
				$('#facet-tabLink').removeClass("active");
				
				$("#facetSearch-tabDiv").hide();
				$("#facetSearch-tabDiv").removeClass("active");

				$('#attributeSearch-tabDiv').addClass("active");
				$('#attributeSearch-tabLink').addClass("active");
				this.numTabsEnabled--;
			}
		},
		cleanup: function() {
			this.stopListening();
		}
	});
	
	SearchSidebar.ViewModel = function(model, selectedType) {
		var self = this;
		var result = {
			attrs : ko.observableArray([])
		};
		var formName = model.get("form");

		self.availableObjectTypes = ko.observableArray();
		self.showAvailableObjectTypes = ko.observable();

		self.selectedType = selectedType;

		var formConfigTypes = [];
		var compositeMap = {};

		app.context.configService.getFormConfig(formName, function(formConfig) {
			formConfig.get("configuredTypes").each(function(type) {
				formConfigTypes.push(type.get("ocName"));
				if(type.get('composite')) {
					compositeMap[type.get('ocName')] = true;
				}
			});

			var pertainableTypes = formConfigTypes; 

			//Since we need to splice in the attributes when they come back from the
			//label service, which may not be in order, we have to have a attrs array
			//with the correct number of attrs already existing
			_.each(formConfigTypes, function(item) {
				result.attrs.push(item);
			});

			_.each(pertainableTypes, function(item) {
				app.context.configService.getLabels(item).done(function(label) {
					var newType;
					if(compositeMap[item]) {
						newType = new SearchSidebar.ObjectType(item, label, true);
					} else {
						newType = new SearchSidebar.ObjectType(item, label);
					}
					// splice the new object into the result attribute array in the correct order, 
					// regardless of when "done" finishes
					result.attrs.splice(pertainableTypes.indexOf(item),1,newType);
					if(newType.type === selectedType().type) { 
						// update the selected type observable directly
						selectedType(newType);
					}
				}); 
			});
			// set our available object types to the correct-ordered result attribute array
			self.availableObjectTypes = result.attrs;

			var totalPaths = 0;
			var resolvedPaths = 0;
			var customTypePaths = app.context.currentSearchConfig().get('customTypePaths');
			if(customTypePaths) {
				totalPaths = _.size(customTypePaths[formName]) - 1;
			}
			//lets filter out our types based on path security.
			if(app.context.currentSearchConfig().get("sidebarConfig").get("enableTypeToPathSecurity") && totalPaths > 0) {

				self.typesToRemove = [];
				self.getTypesWithPermission = function(typesToRemove) {
					var tempTypesHolder = _.filter(self.availableObjectTypes(),function(type) {
						return typesToRemove.indexOf(type.type) === -1;
					});
					self.availableObjectTypes(tempTypesHolder);
					// set the selected type to the first item
					if(self.selectedType()) {
						var foundType = _.find(tempTypesHolder, function(typeObj) {
							return typeObj.type === self.selectedType().type;
						});
						if(!foundType) {
							if(self.selectedType().type !== tempTypesHolder[0].type) {
								self.selectedType(tempTypesHolder[0]);
							}
						}
					} else {
						self.selectedType(tempTypesHolder[0]);
					}
					self.showAvailableObjectTypes(true);
				};

				_.each(_.keys(customTypePaths[formName]),function(typeKey) {
					var containerPathHolder = "";
					if('_id' != typeKey) {
						containerPathHolder = customTypePaths[formName][typeKey];
					}

					if(containerPathHolder !== "") { // if the path is not empty
						// check to see if the user has write permission on the specified path
						$.ajax({
							type : "GET",
							contentType: "application/json",
							url: app.serviceUrlRoot + "/permission/read?id=" + containerPathHolder,
							success: function() {
								resolvedPaths++;
								// data will come back if we have read permission

								// if all the object types have been resolved, show the list of available object types to choose from
								if(resolvedPaths === totalPaths) {
									// if were finished, show the filtered types
									self.getTypesWithPermission(self.typesToRemove);
									var tempTypesHolder = _.filter(self.availableObjectTypes(), function(type) {
										return self.typesToRemove.indexOf(type.type) === -1;
									});
									self.availableObjectTypes(tempTypesHolder);
									self.showAvailableObjectTypes(true);
								}
							},
							error: function(jqXHR) {
								//if it throws an error, it means we didnt have permission to check the node, aka we cant read, mark this typeKey
								self.typesToRemove.push(typeKey);
								resolvedPaths++;
								// most commonly will happen if the specified path doesn't exist
								if(jqXHR.status === 403) {
									app.log.debug(typeKey + " type is not searchable by this user.");
								}
								if(resolvedPaths === totalPaths) {
									self.getTypesWithPermission(self.typesToRemove);
									var tempTypesHolder = _.filter(self.availableObjectTypes(), function(type) {
										return self.typesToRemove.indexOf(type.type) === -1;
									});
									self.availableObjectTypes(tempTypesHolder);
									self.showAvailableObjectTypes(true);
								}
							}
						});	
					}
				});
			} else {
				self.showAvailableObjectTypes(true);
			}
		});

		this.updateType = function(selected) {
			app.log.debug("clearing search parameters");
			app.trigger("search:clearQuickSearchValue");
			app.trigger("rerenderAdvancedSearch");
			app.trigger("searchsidebar:typeChanged", selected.type);
			self.selectedType(selected);
		};
		return this;
	};

	// TypeSelect View
	SearchSidebar.Views.TypeSelect = Backbone.Layout.extend({
		template: "search/sidebar-typeselect",
		events: {
			"click .typeChange" : "typeHasChanged"
		},
		typeHasChanged: function(event) {			
			app.trigger("tracOrTypeChange", this.selectedType());
			if(this.model.get("sidebarConfig").get("folderViewTypeSelection")) {
				$('span.highlightThis').removeClass('highlightThis');
				$(event.currentTarget).addClass('highlightThis');
			}
		},
		afterRender: function(){
			var typeViewModel = new SearchSidebar.ViewModel(this.model, this.options.selectedType);
			kb.applyBindings(typeViewModel, this.$el[0]);
		},
		serialize: function(){
			return {
				folderViewTypeSelection : this.model.get("sidebarConfig").get("folderViewTypeSelection")
			};
		}
	});

	// ConfigSwitcher View
	SearchSidebar.Views.ConfigSwitcher = Backbone.Layout.extend({
		template: "search/sidebar-configswitcher",
		events: {
			"click .availableTrac" : "tracHasChanged"
		},
		tracHasChanged: function() {
			app.trigger("tracOrTypeChange", app.context.configName());
			app.trigger("closeTour");
		},
		afterRender: function() {
			var self = this;
			app.context.configService.getTracConfigs(function(tracConfigs) {
				var currentTracLabelChild = tracConfigs.findWhere({name: app.context.configName()});
				var currentTracLabel = "";
				if(currentTracLabelChild) {
					currentTracLabel = currentTracLabelChild.get("displayName");
				}
				if (currentTracLabel === "") {
					currentTracLabel = app.context.configName();
				}
				self.configViewModel = {
					currentTracLabel: currentTracLabel,
					availableTrac: ko.observableArray(tracConfigs.models),
					updateSearchConfig : function(selected) {
						var selectedResultName = selected.get("name");
						app.context.configName(selectedResultName);

						//now we want to navigate to reload the searchpage
						//using backbone navigate alone doesn't work because if the route is already search
						//the router doesn't run again. so:
						app.routers.search.search(selectedResultName);
						Backbone.history.navigate("search/" + app.context.configName(), {replace : true});
					}
				};
				kb.applyBindings(self.configViewModel, self.$el[0]);
			});
		}
	});

	/*
	*   Event Hook: beforeExecuteSearch
	*	This is an example of an event hook - a common place/event where clients may want to add functionality.
	*   It is intentionally blank and meant to be overridden in your own client module or action.
	*
	*	beforeExecuteSearch allows us to add any additional search parameters to the query before the query is actually executed.
	*/
	SearchSidebar._beforeExecuteSearch = function(typeConfig, query, searchType, formType) {
		//in the query cycle through each of the search parameters
		_.each(query.searchParameters, function(item) {
			//all variables are declared here for global usage
			var itemName = item.paramName;
			var itemValue = item.paramValue;
			var itemType = item.paramType;
			var currentAttr;
			//cookieValue and arrayVals, placeholder for cookie value to be used in setting up cookie
			var cookieValue = {};
			var arrayVals = {};
			//if their property type is "property", get the attributes from the current search parameter
			if(itemType === "property") {
				if (formType.get("configuredAttrsPri").findWhere({"ocName": itemName})) {
					currentAttr = formType.get("configuredAttrsPri").findWhere({"ocName": itemName});
				} else if(formType.get("configuredAttrsSec").findWhere({"ocName": itemName})) {
					currentAttr = formType.get("configuredAttrsSec").findWhere({"ocName": itemName});
				}
				//if there is a cookie at savedTerms bring it down and save it
				if($.cookie("savedTerms")) {
					cookieValue = JSON.parse($.cookie("savedTerms"));
				}
				//The following if statements take care of the different variations
				//of cookie to be passed in
				if(currentAttr && currentAttr.get("rememberLastSearchTerm")) {
					if(!cookieValue) {
						cookieValue[searchType] = {};
						arrayVals[itemName] = itemValue;
						cookieValue[searchType] = arrayVals;
					} else if(cookieValue && !cookieValue[searchType]) {
						arrayVals[itemName] = itemValue;
						cookieValue[searchType] = arrayVals;
					} else if(cookieValue[searchType]) {
						cookieValue[searchType][itemName] = itemValue;
					}
					//if the cookie is not empty, save the cookie at the universal cookie path so that it can be 
					//accessed anywhere in the search sidebar page
					if(!_.isEmpty(cookieValue)) {
						$.cookie("savedTerms",JSON.stringify(cookieValue),{
							path: "/",
							secure: app.secureBrowserCookies
						});
					}
				}
			}
		});
	};
	// Default View.
	SearchSidebar.Views.Layout = Backbone.Layout.extend({

		template: "search/searchsidebar",

		events: {
			"click #main-header span.glyphicon" : "slideOutTab",
			"click #expander" : "expanderClick"
		},
 
		initialize: function() {
			var self = this;

			this.sidebarInitializationDeferred = $.Deferred();
		
			// Set our variables that we will be using throught the life of the module.
			this.name = "search-sidebar";
			this.subviewDeferreds = this.options.subviewDeferreds;
			this.searchConfig = this.options.config;
			this.selectedType = ko.observable();
			this.searchResultsViewController = this.options.searchResultsViewController;

			this.subviewDeferreds.push(this.sidebarInitializationDeferred);

			var _selectedTypeLabel;
			_.each(this.searchConfig.get("availableObjectTypes"), function(item) {
				if (item === self.options.selectedType) {
					app.context.configService.getLabels(item).done(function(label) {
						_selectedTypeLabel = label;
					});
				}
			});
			this.selectedType(new SearchSidebar.ObjectType(this.options.selectedType, _selectedTypeLabel));
			$(window).resize(_.bind(this.switchSearchGlyphicon,this));
				
			this.showSlideOutEnabled = false;
			this.createSidebarSubViews();
			this.sidebarInitializationDeferred.resolve();
		},

		// mobile view that pulls sidebar in and out of view
		slideOutTab: function() {

			// when search bar is clicked
			this.sidebar = $('#main-header');
			if (window.innerWidth <= HPIConstants.WindowSize.Small) {

				// Appropriately change the glyphicon being used depending on the sidebar being expanded
				// or collapsed.

				if ($('#main-header span.glyphicon').attr("class").indexOf("glyphicon-search") > 0) {
					$("#main-header span.glyphicon").css("float", "right");
					$('#main-header span.glyphicon').switchClass("glyphicon-search", "glyphicon-chevron-left");
				}
				
				$("#sidebar").toggleClass('showSlideOut');
				this.showSlideOutEnabled = !this.showSlideOutEnabled;

				//when slid out, position should be absolute. if not, position should be fixed so you can pull out the tab on any position of the page
				if(this.showSlideOutEnabled) {
					$( document ).ready(function() {
						$("#sidebar").removeClass('hideSlideOut');
						document.getElementById("sidebar-outlet").style.top = "0.5%";
						document.getElementById("sidebar-outlet").style.position = null;	
						document.getElementById("sidebar").style.position = "absolute";
						$("html, body").animate({ scrollTop: 0 }, "slow");
						$('#sidebar').animate({left: "0px"}, 500);
					});
				} else {
					$( document ).ready(function() {
						$('#sidebar').animate({left: "-96%"}, 500, function() {
							document.getElementById("sidebar-outlet").style.top = "50px";	
							document.getElementById("sidebar-outlet").style.position = "absolute";	
							document.getElementById("sidebar").style.position = "fixed";	
							$("#sidebar").addClass('hideSlideOut');
							$("#main-header span.glyphicon").css("float", "unset");
							$('#main-header span.glyphicon').switchClass("glyphicon-chevron-left", "glyphicon-search");	
						});
					});
				}
			}	
		},

		switchSearchGlyphicon:  _.debounce(function() {
			// in VAD mode when main-header is undefined
			if ($('#main-header span.glyphicon').attr("class")) {
				if (window.innerWidth > HPIConstants.WindowSize.Small ) {
					$("#sidebar").removeClass();
					// option should always be search in large view mode
					if ($('#main-header span.glyphicon').attr("class").indexOf("glyphicon-search") <= 0) {
						$("#main-header span.glyphicon").css("float", "unset");
						$('#main-header span.glyphicon').switchClass("glyphicon-chevron-left", "glyphicon-search");
					}

					document.getElementById("sidebar").style.position = null;
					document.getElementById("sidebar-outlet").style.position = "initial";
				} else {
					if (this.showSlideOutEnabled === true) {
						if ($('#main-header span.glyphicon').attr("class").indexOf("glyphicon-chevron-left") <= 0) {
							$("#main-header span.glyphicon").css("float", "right");
							$('#main-header span.glyphicon').switchClass("glyphicon-search", "glyphicon-chevron-left");
							$("#sidebar").removeClass();
							$('#sidebar').addClass('showSlideOut');
						}
					} else {
						document.getElementById("sidebar-outlet").style.position = "absolute";
						document.getElementById("sidebar").style.position = "fixed";
						$("#sidebar").removeClass();
						$('#sidebar').addClass('hideSlideOut');
					}
				}
			}
		}),

		executeSearch: function(cs){
			var that = this;
			var query = this.collection;

			//store start time for search duration log
			query.searchStartTime = Date.now();

			//Resets the selected documents on the grid between searches
			if (that.searchResultsViewController.grid) {
				that.searchResultsViewController.grid.setSelectedObjects([]);
			}
			
			//Populate Search Parameters
			that.populateSearchParameters(cs);
			
			//URL population stuff.
			app.context.configService.getAdminTypeConfig(that.selectedType().type, function(typeConfig) {
				//updates or sets a cookie to hold the last searched trac
				var lastTracObject = app.context.cookieService.getUserPreferences('searchTrac');
				lastTracObject.searchTrac = app.context.configName();
				app.context.cookieService.setUserPreferences('searchTrac', lastTracObject);

				// always go to the first page of results on a new search
				query.state.currentPage = 1;
				query.mode = "client";

				//we need the form to see what attrs are configured in the attribute search for
				//this type
				app.context.configService.getFormTypeConfig(that.options.config.get("form"), that.selectedType().type, function(formType) {
					// Weed out any bad params.
					that.filterSearchParams(formType);
					
					if(that.disableSearchOnWildcardChar || !that.searchParamsNotBlank) {
						// Validate that the user didn't search for *
						if (that.disableSearchOnWildcardChar) {
							app.trigger("alert:changeNotification", "alert-danger", window.localize('modules.search.searchSidebar.wildcardSearchWarning'), "#search-alert");
							return;
						}

						// Validate whether the search value was empty
						if (!that.searchParamsNotBlank) {
							app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.search.searchSidebar.pleaseEnter"), "#search-alert");
							window.scrollTo({ top: 0, behavior: 'smooth' });
							return;
						}
					} else {
						//slide tab in if alert not triggered
						that.slideOutTab();
					}
					// Reset the variable in case this code is triggered again
					that.searchParamsNotBlank = false;

					// and one to specify which type
					var sp = {
						paramName: that.selectedType().type,
						paramValue: that.selectedType().type,
						paramType : "type"
					};
					query.searchParameters.push(sp);

					var limitSearchResults = that.searchConfig.get("limitSearchResults");
					//limit the search results if the config says to
					if (limitSearchResults && limitSearchResults !== "") {
						var lsrsp = {
							paramName: "limit_results",
							paramValue: limitSearchResults,
							paramType: "options"
						};
						query.searchParameters.push(lsrsp);
					}

					// Calling this method allows for any additional logic to a search query.
					SearchSidebar._beforeExecuteSearch(typeConfig, query, that.selectedType().type, formType);

					// Build search string URL
					var searchString = that.buildSearchString(formType);

					var searchUrl;
					//Only search with a logic parameter if we are doing an advanced search
					if(that.advancedSearch && that.advancedSearch.logic) {
						searchUrl = "search/" + app.context.configName() + "/" + that.selectedType().type + "?" + searchString + "&logic="+ that.advancedSearch.logic[0]+" ";
					} else {
						searchUrl = "search/" + app.context.configName() + "/" + that.selectedType().type + "?" + searchString;
					}
					
					//This will minimize the sidebar on search
					if(app.context.currentUserPreferences() && app.context.currentUserPreferences().get("autoMinimize")) {
						that.expanderClick();
					}

					// navigate to the URL and load the results
					if(that.selectedType().composite) {
						query.composite = true;
						query.fetch({ 
							selectedType: that.selectedType().type,
							searchResultsViewController : that.searchResultsViewController
						});
					} else {
						query.composite = false;
						query.fetch({
							searchResultsViewController : that.searchResultsViewController
						});
					}
	
					Backbone.history.navigate( searchUrl, {"trigger": false } );
				});//end of formtype callback
			});//end of typeConfig callback
		},

		populateSearchParameters: function(cs) {
			var query = this.collection;

			this.advancedSearch = cs;
			query.logic = [];
			//Populate Search Parameters
			if (this.advancedSearch || $("#advancedSearch").is(":visible")) {
				if(!this.advancedSearch) {
					this.advancedSearch = AdvancedSearch.prepareSearch();
				}
				app.context.currentUserPreferences().set('lastSearchType', 'advanced');
				var allPropertySearch = _.find(query.searchParameters, function(param) {
					return param.paramName === "allproperties" && param.paramValue;
				});
				query.searchParameters = [];
				
				query.logic.push(this.advancedSearch.logic[0]);
				if(this.selectedType().composite) {
					query.searchParameters = AdvancedSearch.SetQueryParams(true);
				} else {
					query.searchParameters = AdvancedSearch.SetQueryParams(false);
				}
				if(allPropertySearch) {
					//if we had a value put in to the Full-Text Search, re-add it here.
					query.searchParameters.push(allPropertySearch);
				}
			} else {
				app.context.currentUserPreferences().set('lastSearchType', 'attribute');
				//pushing and on in case were switching from advanced search
				query.logic.push(" and ");
			} //end of if(AdvancedSearch)
		},
		filterSearchParams: function(formType) {
			var self = this;
			var query = this.collection;
			// Need to keep both these here because each iteration of a search needs to revalidate these two
			this.searchParamsNotBlank = false;
			this.disableSearchOnWildcardChar = false;

			// remove any old type/property params
			// property should remain so long as it is not blank (or length of 0 for repeating criteria) since it is updated on keyup now
			// allproperties should remain so long as it is not blank since it is updated on keyup now
			query.searchParameters = _.filter(query.searchParameters, function(sParam) {
				if(sParam.paramType === 'allproperties' || sParam.paramType === 'property' || sParam.paramType === 'searchallversions' || sParam.paramType === 'operator' || sParam.paramType === 'compositeProperty') {
					//added logic for reset button, since that clears out the paramValue
					if(sParam.paramValue) {
						if (sParam.paramValue !== "" && sParam.paramValue.length !== 0) {
							if(self.searchConfig.get('sidebarConfig').get('disableSearchOnWildcardChar')) {
								var wildcardChar = self.searchConfig.get('sidebarConfig').get('wildcardCharacter');
								if(sParam.paramValue ===  wildcardChar || sParam.paramValue[0] === wildcardChar) {
									self.disableSearchOnWildcardChar = true;
									return true;
								}
							}

							if(self.validateParamAgainstForm(sParam, formType)) {
								// searchAllVersions slider is a special case that does not necessarily indicate that 
								// params are not blank. if searchAllVersions is  the only query param, do not run the query
								if(sParam.paramType !== 'searchallversions') {
									self.searchParamsNotBlank = true;
								}
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						// Checking if our savedTerms cookie has value / exists
						if ($.cookie("savedTerms")) {
							// Grab the cookie and JSON parse it
							var cookieValue = JSON.parse($.cookie("savedTerms"));
							// Grab the currently selected object type
							var objectType = self.selectedType().type;

							// Check if our cookie has the current search objectType as a key
							// and check (if the key exists) if it contains our current parameter name
							if (cookieValue && cookieValue[objectType] && cookieValue[objectType][sParam.paramName]) {
								// If so, we know the value of the form control is now blank / null and needs to be 
								// removed from our savedTerms cookie
								delete cookieValue[objectType][sParam.paramName];

								// Checking if the parameter removed from the savedTerms cookied for the given objectType
								// was the last parameter present. If so - remove the whole cookieValue[objectType] key
								if (_.isEmpty(cookieValue[objectType])) {
									// Removing the whole objectType key
									delete cookieValue[objectType];

									// Since we removed an entire key from the savedTerms cookie, verify that there are 
									// other keys present. If not, remove the whole cookie
									if (_.isEmpty(cookieValue)) {
										// Remove the whole cookie
										$.removeCookie("savedTerms", { path: "/"});

										return false;
									}
								}

								// Saving any modifications made to the savedTerms cookie
								$.cookie("savedTerms", JSON.stringify(cookieValue), {
									path: "/",
									secure: app.secureBrowserCookies
								});
							}
						}

						return false;
					}
				} else if(sParam.paramType !== 'type' && sParam.paramType !== 'property' && sParam.paramType !== 'allproperties' && sParam.paramType !== 'searchallversions' && sParam.paramType !== 'operator') {
					//TODO is this appropriate to do here, or should facets clean them selves based on some event?
					if(_.isArray(sParam.paramValue)) { 
						sParam.paramValue = [""];
					} else {
						sParam.paramValue = "";
					}
					return true;
				}
				return false;
			});
		},
		buildSearchString: function(formType) {
			var query = this.collection;

			var searchString = "";
			_.each(query.searchParameters, function(searchParameter) {
				//if the param is a picklist control (autocomplete, radio button, dropdown)
				//send OPERATOR_EQUALS as the third attribute on the search parameter
				//to speed up searches on the backend
				if(searchParameter.paramType === 'property') {
					var attr = formType.get("configuredAttrsPri").findWhere({ocName: searchParameter.paramName});
					if(!attr) {
						//okay, if we don't find it on primary, try to find it on secondary
						attr = formType.get("configuredAttrsSec").findWhere({ocName: searchParameter.paramName});
					}
					// it's possible that attr could be undefined if a search parameter was added 
					// as a property that's not in the form
					if(attr) {
						var controlType = attr.get("controlType");
						if(controlType === "DropDown" || controlType === "AutoComplete" || 
							controlType === "RadioButton" || controlType === "Cascading") {

							searchParameter.operator = "OPERATOR_EQUALS";
						} else if(controlType === "TextBox" && attr.get('makeSearchExact')) {
							searchParameter.operator = "OPERATOR_EQUALS";
						}
						if(controlType === "TextBox" && attr.get('caseSensitive')) {
							searchParameter.searchMod = "CASE_SENSITIVE";
						}
						if(controlType === "AutoComplete" || controlType === "DropDown") {
							searchParameter.searchMod = "CASE_SENSITIVE";
						}
						// Check to see if this attr is repeating
						var isRepeating = attr.get("repeating");
						if (isRepeating) {
							// If it is repeating, get andRepeatingTerms
							// to determine how repeating values should
							// be handled
							var andRepeatingTerms = attr.get("andRepeatingTerms");
							
							// If andRepeatingTerms is true, add and set termLogic
							// to 'AND', otherwise default to 'OR'
							if (andRepeatingTerms) {
								searchParameter.termLogic = "AND";
							} else {
								searchParameter.termLogic = "OR";
							}
						}
					}
				}

				searchString += "/" + $.param(searchParameter);
			});
			// Remove the initial "/" that was added to the search string as per the code above.
			searchString = searchString.substring(1);

			// Add additional parameters to the search string to comply to the search configs.
			searchString += "&pageNumber=1";
			if (query.state.sortKey !== null) {
				searchString += "&sortAttr=" + query.state.sortKey + "&sortOrder=" + query.state.order;
			}
			if(this.selectedType().composite) {
				searchString += "&composite=true";
			}

			return searchString;
		},
		afterRender : function() {
			app.log.debug("Search Sidebar Rendered.");
			
			this.$('#searchsidebar-numResults').empty();

			// In case the listener is set up, clean it beforehand. No harm in cleaning up a non-existent listener.
			this.stopListening(app, 'search:execute');
			this.listenTo(app, "search:execute", this.executeSearch);

			// launches tour for search
			if($("#sidebar-outlet").is(":visible") && $("#sidebar-outlet").length) {
				app.trigger("searchTourStart", this.config.get("name"));
			}

			if (!this.showSlideOutEnabled && window.innerWidth <= HPIConstants.WindowSize.Small) {
				this.switchSearchGlyphicon();
			}

			// set true to begin with so search can pop out on first transition to small mode from refresh
			this.showSlideOutEnabled = true;
		},

		expanderClick : function() {
			// Reverse the current state of the sidebar
			$("#sidebar").toggle();

			// Appropriately change the glyicon being used depending on the sidebar being expanded
			// or collapsed.
			if ($('#expander span').attr("class").indexOf("glyphicon-chevron-right") > 0) {
				$("#content-outlet").css("margin-left", "395px");
				$('#expander span').switchClass("glyphicon-chevron-right", "glyphicon-chevron-left");
			} else {
				$("#content-outlet").css("margin-left", "15px");
				$('#expander span').switchClass("glyphicon-chevron-left", "glyphicon-chevron-right");
			}

			this.searchResultsViewController.tableEventsRef.trigger("tableview:columnHeaderResize");
		},

		createSidebarSubViews : function() {

			if(this.searchConfig.get("sidebarConfig").get("savedSearchEnabled")) {
				this.setView("#savedsearch-outlet", new SavedSearch.View({
					collection : this.collection,
					selectedType: this.selectedType,
					enabledPublicSavedSearch: this.searchConfig.get("sidebarConfig").get("enabledPublicSavedSearch")
				}));
			}

			// Only need to create and render the type selector if there is more than one type in the form of the currently selected trac
			if(this.searchConfig.get('formTypes').length > 1) {
				this.setView("#searchtypeselect-outlet", new SearchSidebar.Views.TypeSelect({
					model: this.searchConfig,
					selectedType : this.selectedType,
					query: this.collection
				}));
			}

			//if there are more than one trac config, display the dropdown.
			if(this.options.allConfigs.length > 1 ) {
				this.setView("#searchconfigswitcher-outlet", new SearchSidebar.Views.ConfigSwitcher({
					config: this.searchConfig,
					collection: this.options.allConfigs
				}));
			}

			this.setView("#quicksearch-outlet", new QuickSearch.Views.Layout({
					model: this.searchConfig,
					query: this.collection,
					selectedType: this.selectedType
			}));

			this.createSearchTabsView();
		},
		createSearchTabsView: function() {
			var searchTabs =  new SearchSidebar.Views.Tabs({
				model : this.searchConfig,
				query: this.collection,
				selectedType: this.selectedType,
				searchResultsViewController: this.searchResultsViewController,
				subviewDeferreds: this.subviewDeferreds
			});
			this.setView("#searchtab-outlet", searchTabs);
			// return the view so that it can be re-rendered if needed
			return searchTabs;
		},
		//this function just confirms that the parameter exists on the form
		//otherwise it shouldn't be included in any query.
		validateParamAgainstForm : function(sParam, formType) {
			//always return full-text search
			if(sParam.paramType === 'allproperties' || sParam.paramType === 'searchallversions') {
				return true;
			}
			var priAttrs = formType.get("configuredAttrsPri").models;
			var secAttrs = formType.get("configuredAttrsSec").models;
			return _.find(_.union(priAttrs, secAttrs), function(attr) {
				return attr.get("ocName") === sParam.paramName;
			});
		},
		serialize: function(){
			return {
				folderViewTypeSelection : this.config.get("sidebarConfig").get("folderViewTypeSelection")
			};
		}
		
	});

	// Return the module for AMD compliance.
	return SearchSidebar;
});