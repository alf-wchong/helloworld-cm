define("listview", [
"app",
    "modules/common/spinner",
    "modules/common/action",
    "modules/common/booleanutils",
    "modules/actions/actionmodules",
    "module",
    "modules/common/hpiconstants",
    "jqueryDeparam"
],
function(app, HPISpinner, Action, BooleanUtils, ActionModules, module, HPIConstants) {
    "use strict";

    var ListView = app.module();

    ListView.View = Backbone.Layout.extend({
        template: '/search/listview',
        events: {
            "click .hpiList": "loadDocument",
            "click .selectList": "selectedListsChanged",
            "click .listDualPane": "launchDualPane"
        },
        initialize: function(options) {
            var self = this;
            this.searchResultsViewController = options.searchResultsViewController;
            this.collection = options.collection.fullCollection;
            this.options = options;
            this.paginationCollection = options.collection;
            // this is done for unit testing purposes since we can't access the module from the spec file
            var configuredMimetypeWhiteList = module.config().mimetypeWhiteList || this.options.mimetypeWhiteList;
            // whitelist that determines which ocos to fetch lists for; uses project configured whitelist if it's defined
            this.mimetypeWhiteList = configuredMimetypeWhiteList || HPIConstants.ListView.MimetypeWhitelist;
            // if checkbox is clicked on the label div so the link will not be pressed
            this.clickedCheckBox = false;
            //The array of ocos
            this.ocos = this.collection.models;
            
            //All of the URLs for the ocos
            this.urls = [];

            //The URLs to actually display based on pageSize and currentPage
            this.urlsToShow = [];
            
            //The deferreds that hold the list requests
            this.defs = [];
         
            this.prefs = [];
         
            var deferred = $.Deferred();

            // retrieve order of columns from userpreferences
            deferred = this.getGridColumn();
      
            deferred.done(function(){

                //Getting the lists the first time
                self.getLists(self.ocos);

                // The lists the user currently has selected
                self.selectedLists = {};
            
                self.applyListeners();
                // Setting the correct page number for list view so that the correct results are retrieved
                self.searchResultsViewController.tableEventsRef.trigger("search:result:controls:setCurrentPage", self.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1);

                self.searchResultsViewController.determineResultsPerPage().done(function() {
                    self.searchResultsViewController.grid.getData().setPagingOptions({
                        pageSize: self.searchResultsViewController.resultsPerPage
                    });

                    if(self.searchResultsViewController.textFilter){
                        self.applyFilteredResults(self.searchResultsViewController.grid.getData().getFilteredItems());

                        // Applying the text filter only gives back all the results that pass through the filter
                        // It does not take into account the page number or the results per page
                        // so, we explicitly make sure that the correct results are displayed here. 
                        var pageNum = self.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1;

                        var startIdx = (pageNum-1)*self.searchResultsViewController.resultsPerPage;
                        var endIdx = (pageNum)*self.searchResultsViewController.resultsPerPage;
                        
                        self.urlsToShow = self.urlsToShow.slice(startIdx, endIdx);

                        self.searchResultsViewController.tableEventsRef.trigger("search:updateTextFilter", self.searchResultsViewController.textFilter);
                    }

                    var resultsPerPage = self.searchResultsViewController.resultsPerPage;
                    // check if we have a previous filter
                    if (self.keepFilter && self.searchResultsViewController.textFilter) {
                        self.searchResultsViewController.tableEventsRef.trigger("search:results:text:filter:change", self.searchResultsViewController.textFilter);
                        self.searchResultsViewController.tableEventsRef.trigger("search:updateTextFilter", self.searchResultsViewController.textFilter);
                    }
                    var pagingInfo = self.searchResultsViewController.grid.getData().getPagingInfo();
                    //The defaulting the page size/resultsPerPage to what is stored on window.  Subsequent renders
                    //will use the last size used.
                    pagingInfo.pageSize = pagingInfo.pageSize < 1 ? resultsPerPage : pagingInfo.pageSize;

                    //We can't be at page 0
                    pagingInfo.pageNum = pagingInfo.pageNum < 1 ? 1 : pagingInfo.pageNum;

                    //Ensuring the totalPages is correct
                    pagingInfo.totalPages = Math.ceil(pagingInfo.totalRows / pagingInfo.pageSize);

                    //Ensuring that the records state that ocquery uses is up to date
                    self.collection.pageableCollection.records.set('totalPages', pagingInfo.totalPages);

                    //Firing trigger to searchresultcontrols with new info.
                    self.searchResultsViewController.tableEventsRef.trigger("slickgrid:pagination:change", pagingInfo);
                });

                //setting the paging info on initialize
                self.searchResultsViewController.grid.getData().onPagingInfoChanged.subscribe(function(e, pagingInfo) {
                    if (!app.searchView || app.searchView === "table") {
                        return;
                    }
                    app.context.configService.getApplicationConfig(function(config) {
                        // make sure window.resultsPerPage has a value
                        var defaultResults = parseInt(config.get('searchResultsNumDefault'), 10);

                        if (!self.searchResultsViewController.resultsPerPage) {
                            self.searchResultsViewController.resultsPerPage = defaultResults ? defaultResults : 10;
                        }

                        //The defaulting the page size/resultsPerPage to what is stored on window.  Subsequent renders
                        //will use the last size used.
                        pagingInfo.pageSize = pagingInfo.pageSize < 1  ? self.searchResultsViewController.resultsPerPage : pagingInfo.pageSize;

                        //We can't be at page 0
                        pagingInfo.pageNum = (_.isNaN(pagingInfo.pageNum) || pagingInfo.pageNum < 1) ? 1 : pagingInfo.pageNum;

                        //Ensuring the totalPages is correct
                        pagingInfo.totalPages = Math.ceil(pagingInfo.totalRows / pagingInfo.pageSize);

                        //Firing trigger to searchresultcontrols with new info.
                        self.searchResultsViewController.tableEventsRef.trigger("slickgrid:pagination:change", pagingInfo);
                    });
                });
                self.populateSelectedResultsFromTableView();
            });
        },
        populateSelectedResultsFromTableView: function() {
            // grab all the selected ids and ocos from tableview - we'll update them in selectedListsChanged
            _.each(this.searchResultsViewController.grid.getSelectedIds(), function(id) {
                // you can't assume all of these ocos are defined at this point if they have been
                // filtered out of the grid with facets, so instead we use the value we have
                var oco = this.searchResultsViewController.grid.getSelectedOCObyId(id);
                this.selectedLists[id] = oco;
            }, this);
        },
        applyFilteredResults: function(filteredResults) {
            var idsToKeep = _.pluck(filteredResults, HPIConstants.Properties.ObjectId);
            this.urlsToShow = this.urls.slice(0);

            this.urlsToShow = _.filter(this.urlsToShow, function(oco) {
                return _.contains(idsToKeep, oco.id);
            });
        },
        getColumnPreferences: function(columns, type){

            var self = this;
        
            return app.context.configService.getUserPreferences(function(currentUserPreferences) {
                self.prefs = [];
                if (self.paginationCollection.queryParams.oc_type){
                    var queryType = self.paginationCollection.queryParams.oc_type[0];
                    var trac = queryType + '_' + app.context.configName() + "_" + app.context.currentSearchConfig().get("name"); 
                    var info = currentUserPreferences.attributes.searchResultsTableview[trac];
                    if (!info){
                        return;
                    }
                    var preferences = info.columnWidths;

                    for (var i = 0; i < preferences.length; ++i) {
                        if (preferences[i].id !== "_checkbox_selector"){    // does not add the button
                            self.prefs.push(preferences[i].id);
                            if (self.prefs.length == 3){
                                break;
                            }
                        }
                    }
                }

                var userPrefs = currentUserPreferences.get("searchResultsTableview");
                //Returns user prefered columns
                var visibleColumns = [];
                var searchConfigName = app.context.currentSearchConfig() ? "_" + app.context.currentSearchConfig().get("name") : "";
                if (userPrefs && userPrefs[queryType + '_' + app.context.configName() + searchConfigName] && userPrefs[queryType + '_' + app.context.configName() + searchConfigName].selectedColumns.length > 0) {
                    var uservisibleColumns = userPrefs[queryType + '_' + app.context.configName() + searchConfigName].selectedColumns;
                    _.each(uservisibleColumns, function(visibleColumn) {
                        _.each(columns, function(column) {
                            if (visibleColumn === column.field) {
                                visibleColumns.push(column);
                            }
                        });
                    });
                    self.searchResultsViewController.grid.setColumns(visibleColumns);

                    //If no preference, show only visible fields (hidden fields configured)
                } else if (type.get("fields").length > type.get("visibleFields").length) {
                    var tempVisibleFields = _.pluck(type.get("visibleFields"), 'ocName');
                    visibleColumns = _.filter(columns, function(column) {
                        if (_.indexOf(tempVisibleFields, column.field) !== -1) {
                            return true;
                        } else {
                            return false;
                        }
                    });
                    visibleColumns.unshift(columns[0]);
                    self.searchResultsViewController.grid.setColumns(visibleColumns);

                //If no hidden fields, show all fields
                } else {
                    self.searchResultsViewController.grid.setColumns(columns);
                }
            
            }, self);
        },
        getSelectedIndicesOnCurrentPage: function() {
            var self = this;
            // visible as in all names you could see currently flipping through pages
            var visibleObjNames = _.pluck(self.urlsToShow, HPIConstants.Properties.ObjectName);
            var selectedVisibleObjNames = _.intersection(visibleObjNames, self.searchResultsViewController.grid.getSelectedObjectNames());

            var selectedIndices = _.map(selectedVisibleObjNames, function(name) {
                return _.indexOf(visibleObjNames, name);
            });

            return selectedIndices;
        },
        populateSelectedListsOnCurrentPage: function() {
            var self = this;

            var selectedIndices = this.getSelectedIndicesOnCurrentPage();
            //Transferring the information of selected documents from the searchResultsViewController to the selectedLists object
            _.each(selectedIndices, function(selectedIdx) {

                var id = self.urlsToShow[selectedIdx].id;
                // You can assume that this object will be visible on the grid at this time
                var oco = self.searchResultsViewController.grid.getData().getItemById(id);
                self.selectedLists[id] = oco;
            });
        },
        switchingToTableView: function() {
            // Ensuring that the information about selected rows is transferred back to
            // the tableviewController object just before switching back to tableview.
            var selectedRows = this.searchResultsViewController.grid.getSelectedRowsOnCurrentPage();
            this.searchResultsViewController.grid.setSelectedRows(selectedRows);
        },
        applyListeners: function(){
            var self = this;
            //Listening to when the number of results per page changes
            this.listenTo(this.searchResultsViewController.tableEventsRef, "change:resultsPerPage", function() {
                //Resetting the 'urlsToShow' to be all of the URLs
                //This is how you clone an array
                self.urlsToShow = self.urls.slice(0);

                //There are more total URLs than desired number of results
                if (self.urlsToShow.length > self.searchResultsViewController.resultsPerPage) {
                    self.urlsToShow.length = self.searchResultsViewController.resultsPerPage;
                    self.render();
                } else {
                    //There are less total URLs than desired number of results
                    self.urlsToShow = self.urls;
                    self.render();
                }

                //Setting the paging options in slickgrid so that the related events fire
                self.searchResultsViewController.grid.getData().setPagingOptions({ pageSize: self.searchResultsViewController.resultsPerPage });
            });

            this.listenTo(this.options.collection, 'query:complete', function(collection){

                this.paginationCollection = collection;
                this.collection = collection.fullCollection;

                //pulling object type and putting on view controller for mimetype and octype purposes
                self.searchResultsViewController.queryType = collection.queryParams.oc_type[0];

                //TO DO HERE THE LOGIC IN UPDATING URLS TO SHOW W NEW COLLECTION

                var models = this.collection.models;

                var deferred = $.Deferred();

                // retrieve order of columns from userpreferences
                deferred = this.getGridColumn();
          
                deferred.done(function(){
                
                    self.getLists(models);

                    if(self.collection.pageableCollection.records.totalRecords() > 0){
                        self.searchResultsViewController.grid.getData().setPagingOptions({
                            pageSize: self.collection.pageableCollection.state.pageSize,
                            pageNum: self.collection.pageableCollection.state.currentPage - 1
                        });
                        self.urlsToShow = self.urlsToShow.slice(0, self.collection.pageableCollection.state.pageSize);
                    }
                });
             });
    
            //Listener for when a specific page is selected
            this.listenTo(this.searchResultsViewController.tableEventsRef, "list:goToPage", this.goToPage);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:switching-to-table-view", this.switchingToTableView);

            //Listener for when filtered by input text
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:text:filter:change", this._updateListDocView);

            //Listener for then the filtered results come back from the SlickGrid listener
            this.listenTo(this.searchResultsViewController.tableEventsRef, "rowCountChanged", function(filteredResults) {
                self.applyFilteredResults(filteredResults);
                self.render();
            });
            this.listenTo(this.searchResultsViewController.tableEventsRef, "resultsHaveMutated tableview:tableAfterGridSetupDone", function() {
                //the length and models on this collection need to be updated to get the correct values
                self.paginationCollection.length = self.collection.length;
                self.paginationCollection.models = self.collection.models;
                self.searchResultsViewController.grid.getData().setItems(self.paginationCollection, "objectId");
                
                //making sure that the paging is correct
                self.searchResultsViewController.grid.getData().setPagingOptions({
                    pageSize: self.searchResultsViewController.resultsPerPage
                });

            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:facet", function(filteredResults){
                //fullCollection contains the updated collection of results based on facet search
                self.ocos = filteredResults.fullCollection.models;
                self.urls = [];
                self.urlsToShow =[];
                self.searchResultsViewController.grid.getData().refresh();
                self.getLists(self.ocos);

                var startIdx = self.searchResultsViewController.grid.getData().getPagingInfo().pageSize * self.searchResultsViewController.grid.getData().getPagingInfo().pageNum;
                var endIdx = startIdx + self.searchResultsViewController.grid.getData().getPagingInfo().pageSize;

                self.urlsToShow = self.urlsToShow.slice(startIdx, endIdx > self.urlsToShow.length ? self.urlsToShow.length : endIdx);

                //Makes sure that text filter is applied if there is any 
                if(this.searchResultsViewController.textFilter){
                    self.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
                    self.searchResultsViewController.tableEventsRef.trigger("rowCountChanged", self.searchResultsViewController.grid.getData().getFilteredItems());
                }
                    
                self.render();
            });

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:removeAllChecked", this.deselectAllLists);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:checkAllResults", this.selectAllLists);
        },
        
        goToPage: function(options) {
            var pageToGoTo = options.pageToGoTo;
            var pageSize = options.pageSize;

            //Getting the first and last list to show based on pageSize and pageNumber
            var startIdx = pageSize * (pageToGoTo - 1);
            var endIdx = startIdx + pageSize;

            //Copying all URLs
            this.urlsToShow = this.urls.slice(0);

            // Update URLs to show to only include filtered items
            if (this.searchResultsViewController.textFilter) {
                this.applyFilteredResults(this.searchResultsViewController.grid.getData().getFilteredItems());
            }

            //Getting the correct range of urls based on 'startIdx' and 'endIdx'
            this.urlsToShow = this.urlsToShow.slice(startIdx, endIdx > this.urlsToShow.length ? this.urlsToShow.length : endIdx);
            this.render();

            this.searchResultsViewController.grid.getData().setPagingOptions({ pageNum: options.pageToGoTo - 1, pageSize: options.pageSize });

            // Need to recalculate rows for new pages based on global object id list
            this.populateSelectedListsOnCurrentPage();
        },
        getGridColumn: function(){
            var config = this.getSearchConfig();

            //pull type off the query params
            //? do we want to support queries against multple types?
            var type;
            var queryType;
            if ( this.paginationCollection.queryParams.oc_type !== undefined) {
                queryType = this.paginationCollection.queryParams.oc_type[0];
                type = config.get("types").findWhere({
                    objectType: queryType
                });
            } else {
                //IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
                // for now we are assuming it's just one parent type for collections
                queryType = config.get("types").models[0].attributes.objectType + "-collection";
                type = config.get("types").models[0];
            }
        
            if (!type) {
                return;
            }
            
            var deferred = $.Deferred();

            //set the columns up with labels TODO more features available here
            app.context.configService.getAdminTypeConfig(type.get("objectType"), function(objectTypeConfig) {
                var self = this;
                var columns = [];

                if(_.contains(self.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.CheckboxColumn)){
                    var checkboxSelector = new Slick.CheckboxSelectColumn({
                        cssClass: "slick-cell-checkboxsel"
                    });
                    columns = [checkboxSelector.getColumnDefinition()]; //start with blank table with checkbox column
                }

                _.each(type.get("fields"), function(fieldName) {
                    if (objectTypeConfig && fieldName.ocName === type.get("title").ocName) {
                        self.searchResultsViewController.linkColumnName = fieldName.ocName;
                    }
                    if (objectTypeConfig) {
                        var attrConfig = objectTypeConfig.get("attrs").findWhere({
                            ocName: fieldName.ocName
                        });
                        columns.push({
                            id: fieldName.ocName,
                            name: window.localize(attrConfig.get("label")),
                            field: fieldName.ocName,
                        });
                    } 
                }, self);

                self.getColumnPreferences(columns,type).done(function(){
                    deferred.resolve();
                });
            
            }, undefined, this);

            return deferred.promise();
        
        },
        showNoResults: function(){
            //displays the no results box when the search returns no results 
            if (this.searchResultsViewController.handler !== HPIConstants.Handlers.ModalActionHandler && (this.urlsToShow.length < 1 || !this.urlsToShow[0].objectOne)) {
                $("#listNoResults").show();
            }
            else {
            $("#listNoResults").hide();
            }
        },
        selectAllLists: function() {
            var self = this;
            var visibleLists = $('.lists input:checkbox');

            // add just the lists visible on this page
            _.each(visibleLists, function(list) {
                var id = list.getAttribute('objId');
                // You may assume this item is available on the grid at this time
                var oco = self.searchResultsViewController.grid.getData().getItemById(id);
                self.selectedLists[id] = oco;
                $(list).parents('.hpiList').addClass('selectedList');
            });
                            
            // check all checkboxes
            visibleLists.prop("checked", true);
        
            this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedLists));
        },
        // resets the selected lists
        resetSelectedLists: function() {
            this.selectedLists = {};
        },
        _updateNumberOfDocsPerPage: function(){
            if(this.urlsToShow.length > 0){
                var pageNum = this.searchResultsViewController.grid.getData().getPagingInfo().pageNum + 1;
                
                var startIdx = (pageNum-1)*this.searchResultsViewController.resultsPerPage;
                var endIdx = (pageNum)*this.searchResultsViewController.resultsPerPage;

                this.urlsToShow = this.urlsToShow.slice(startIdx, endIdx > this.urlsToShow.length ? this.urlsToShow.length : endIdx);
            }
        },

        _updateListDocView: function(textFilter){
            //Copying all URLs
            this.urlsToShow = this.urls.slice(0);

            //The text argument passed to the filter.
            this.searchResultsViewController.grid.getData().setFilterArgs({ text: textFilter.trim() });

            //Refreshing the data based on the filter.
            this.searchResultsViewController.grid.getData().refresh();

            if(textFilter){
                this.applyFilteredResults(this.searchResultsViewController.grid.getData().getFilteredItems());
            }

            this._updateNumberOfDocsPerPage();

            this.searchResultsViewController.tableEventsRef.trigger('filter:collection', this.paginationCollection);
            
            // When you perform a text search which returns no results and then add facets, the items are removed from grid object.
            // So to reset items we must update results from the facets. 
            if(!this.searchResultsViewController.grid.getData().getItems().length){

                this.searchResultsViewController.tableEventsRef.trigger("search:updateFacetResults");

            }
            this.render();
        },
        // resets selected lists and deselects all list checkboxes
        deselectAllLists: function() {
            var visibleLists = $('.lists input:checkbox');
            this.resetSelectedLists();
                            
            // uncheck all checkboxes
            visibleLists.prop("checked", false);
            _.each(visibleLists, function(list) {
                $(list).parents('.hpiList').removeClass('selectedList');
            });

            this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedLists));
        },
        // handles a list's selection toggling
        selectedListsChanged: function(evt) {
            evt.stopPropagation();                
            var list = evt.currentTarget; 
            var objId = list.getAttribute("objId");
            // invariant that this object is available on the grid at this time
            var oco = this.searchResultsViewController.grid.getData().getItemById(objId);

            // determine if adding or removing the list
            if(list.checked) {
                this.selectedLists[objId] = oco;
                $(list).parents('.hpiList').addClass('selectedList');
            } else {
                delete this.selectedLists[objId];
                $(list).parents('.hpiList').removeClass('selectedList');
            }

            this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', _.values(this.selectedLists));
            this.clickedCheckBox = true;
        },
        
        updateListImgsSrc: function(img) {
            if( this.isInViewport(img) ) {
                if (img.getAttribute('data-src')) {
                    img.src = img.getAttribute('data-src');
                    img.removeAttribute('data-src');
                } 
            } else {
                this.tempImagesToLoad.push(img);
            }
        },
        isInViewport: function(listElement) {
            // wrapping this in a jquery object for unit testing..
            var windowObj = $(window);
            // get the top coordinate of the element relative to the document
            var listTop = $(listElement).offset().top;
            // the viewport bottom is equal to the scrollbar position plus the window height
            var viewportBottom = windowObj.scrollTop() + windowObj.height();
            return listTop < viewportBottom;
        },
        getSearchConfig: function() {
            if (this.context === HPIConstants.TableView.Context.Search || this.context === HPIConstants.TableView.Context.Collections) {
                return this.options.searchConfig;
            } else {
                return app.context.currentSearchConfig().get("resultsConfig").get("resultsTableConfig");
            }
        },  

        getLists: function(ocos) {
            var self = this;

            // grab the link specified for the trac --> not fully implemented for preferences
            self.linkColumnName = this.searchResultsViewController.linkColumnName;

            self.urls = [];
            if ( this.options.collection.length >= 1 && this.options.collection.records.get('totalRecords')) {
                _.each(ocos, this.getListUrlObj, this);
                // When all of the lists have been fetched...
                $.when.apply(null, this.defs).done(function() {
                    self.urlsToShow = self.urls;
                    self.render();
                });
                }
            },

        // method used to build up url objects and determine list urls
        getListUrlObj: function(oco) {

            var ocoProps = oco.get('properties');

            var self = this;
            var queryType = self.searchResultsViewController.queryType;

            app.context.configService.getAdminTypeConfig(queryType, function(objectTypeConfig) {

                var isContainer = objectTypeConfig.get("isContainer");

                // retrieves the svg image related to the folder/file type
                var listURL = self.getMimeType(ocoProps,  isContainer);
                    
                var objects = [];
                
                for (var i = 0; i < self.prefs.length; ++i) {
                    if (self.prefs[i] != self.linkColumnName){
                        objects.push(self.prefs[i]);
                    } 
                    if (i == 2) break;
                }
    
                self.urls.push({
                    "listURL": listURL,
                    "objectOne": ocoProps[self.linkColumnName],
                    "objectTwo": ocoProps[objects.length >= 1 ? objects[0] : ""],
                    "objectThree": ocoProps[objects.length >= 2 ? objects[1] : ""],
                    "id": ocoProps.objectId
                });

            }, self);  
        },
        getMimeType: function(model, isContainer){

            var iconImageLocation = "assets/css/styles/img/icons/unknown.svg";

            //sometimes, we lose the mimeType when we refesh by clicking another document on the
            //stage. if this is the case, regrab it from the properties if it is a document
            if (!model.mimeType && model.Document) {
                if (model.Document instanceof Object) {
                    model.mimeType = model.Document.mimetype;
                } else {
                    model.mimeType = model.Document;
                }
            }
            var contentType = model.mimeType;

            // if mimetype is null it's a folder, if it matches get the image. If neither set to unknown
            if (isContainer === "true") {
                // if mimetype is null it's a folder
                iconImageLocation = "assets/css/styles/img/folder.svg";
            } else {
                var contentTypeConfig = app.context.getContentTypeConfigByMimiType(contentType);

                // if we've got a configuration set up for this mimeType, set the icon, otherwise we'll use the default
                if (contentTypeConfig) {
                    iconImageLocation = contentTypeConfig.iconPath;
                }
            }
            return iconImageLocation;
        },
        //function that launches the document
        loadDocument: function(evt) {
            // label for checkbox was pressed
            if (evt.srcElement.id === "click-checkbox"){
                return;
            }
            // if the user is holding down the ctrl key, select the list instead of opening it 
            if(evt.ctrlKey || evt.metaKey) {
                evt.stopPropagation();
                evt.currentTarget = $(evt.currentTarget).find('.selectList')[0];

                // toggle the selection checkbox
                $(evt.currentTarget).prop("checked", !$(evt.currentTarget).prop('checked'));                    
                this.selectedListsChanged(evt);
            } else {
                var objectId = evt.currentTarget.getAttribute("objId");
                if (objectId) {
                    if(app.prevRoute.indexOf("search") === -1){
                        app.trigger("stage.refresh.documentId", objectId);
                        app.trigger("stage.refresh.showPane3", true);
                    } else {
                        //open document in the context of search
                        app.routers.main.stageSimple(objectId);
                    }
                }
            }
        },
        launchDualPane: function(evt) {
            evt.stopPropagation();
            app.trigger("stage.refresh.documentId2", {
                objectId: evt.currentTarget.getAttribute("objId"),
                context: "viewAllDocuments"
            });  
        },

        afterRender: function() {
            var self = this;
            // Making sure that the documents that are in the selectedLists object are selected and have 
            // the check mark in the checkbox. 
            var hpiLists = $('.lists input:checkbox');
            _.each(hpiLists, function(list){
                if(_.contains(_.keys(self.selectedLists), list.getAttribute('objId'))) {
                    $(list).parents('.hpiList').addClass('selectedList');
                    $(list).parents('.hpiList').context.checked = true;
                }
            });
            
            // Setting the selected results for the actions dropdown and to update the number of selected docs badge
            this.searchResultsViewController.tableEventsRef.trigger("search:selectedResults", _.values(this.selectedLists));

            if (window.innerWidth <= HPIConstants.WindowSize.Small && this.context == HPIConstants.TableView.Context.VAD){
                $('.listWrapper').css('padding-bottom','0px');
            }else{
                $('.listWrapper').css('padding-bottom','90px');
            }
            this.showNoResults();
        },
        getScrollElement: function() {
            // if we're in VAD via the RSAH, scroll events happen on the rightSideActionHandler div not window
            var isRightSideVAD = (this.context === HPIConstants.TableView.Context.VAD && this.options.handler === HPIConstants.Handlers.RightSideActionHandler);
            return isRightSideVAD ? "#rightSideActionHandler" : window;
        },
        serialize: function() { 
            return {
                urls: this.urlsToShow,
                showDualPaneBtn: this.options.context === HPIConstants.TableView.Context.VAD,
                urlCount: this.urlsToShow.length !== 0
            };
        },
        cleanup: function() {
            this.stopListening();
            $(this.getScrollElement()).off("scroll.list");
        }
    });

    return ListView;
});
