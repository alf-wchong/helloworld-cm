// Searchresults module
define([
    // Application.
    "app", 
    "knockout",
    "knockback",
    "jquery",
    "modules/common/action"
],

// Map dependencies from above array.
function(app, ko, kb, jquery, Action) {

    // Create a new module.
    var ListView = app.module();

    // Default View.
    ListView.Views.Layout = Backbone.Layout.extend({
        template: "search/listview",

        initialize: function() { 
            var that = this;
            var config = this.options.searchConfig;
            this.name = "list-view";

            // This object is in charge of holding ALL observable subscriptions or computed values. These cannot be left hanging about since their callback functions will affect other code. By gathering them in this array we ensure that we are able to clean up all items in the array and not have stray KO code acting upon other modules.
            this.disposableKOs = [];

            //get the action configs and store them in an easy to access map for later use in the viewmodel
            var _actions = [];
            var _actionConfigMap = {};
            config.get("actions").each(function(actionConfig){
                _actions.push( new Action.Model({actionId : actionConfig.actionId, ocActionId : actionConfig.get("ocActionId") || actionConfig.actionId}));
                _actionConfigMap[actionConfig.actionId] = actionConfig;
            });

            this.SimpleLittleActionViewModel = kb.ViewModel.extend({
                constructor: function(model){
                    kb.ViewModel.prototype.constructor.call(this, model, {keys: ["actionId"]});
                    this.label = _actionConfigMap[model.get("actionId")].get("label");
                  }
            });

            this.SearchResultVm = function(model) { 
                var self = this;
                self.model = model;
                var thisModel = model.clone();
                var objectId = thisModel.get("objectId");
                self.objectId = kb.observable(thisModel, "objectId");


                self.fakeObservable = ko.observable();
                thisModel.formatPropertiesReadOnly().done(function(){
                    self.fakeObservable.valueHasMutated();
                });

                // object type of the result
                self.objectType = thisModel.get("objectType");

                // get the resolverOptions (resolver, resolverTrac, useResolverTrac) configured for this type
                self.resolver = (function() { 
                    var type = config.get("types").find(function(thisModel) {
                        if(thisModel.get("objectType") === self.objectType) {
                            return true;
                        }
                    });
                    if(type) {     
                        return type.get("resolver");
                    }
                })();

                self.onResultClick = function(){
                    var url = "";
                    if(self.resolver.match("stage")) {
                        if(self.resolver.match("wizard")){
                            url = "Stage/" + app.context.configName() + "/" + app.context.util.getWizardStageUrlIdPart(thisModel.get("objectId"));
                        }else{
                            url = "StageSimple/" + thisModel.get("objectId");
                        }
                        
                    } else if(self.resolver === "detailview") { 
                        // encode the uri for url safety and add the "true" flag that tells the detail view we need a "back" button
                        url = "details/" + app.context.configName() + "/" + encodeURIComponent(thisModel.get("objectId")) + "/true";
                    }
                    else if(self.resolver === "stream") {
                            var iframe;
                                iframe = document.getElementById("hiddenDownloader");
                                if (iframe === null) {
                                    iframe = document.createElement('iframe');
                                    iframe.id = "hiddenDownloader";
                                    iframe.style.visibility = 'hidden';
                                    document.body.appendChild(iframe);
                                }
                                iframe.src = app.serviceUrlRoot + "/content/content?id=" + encodeURIComponent(thisModel.get("objectId")) +"&download=true";
                            }
                    Backbone.history.navigate(url, {trigger: true});
                };

                // retrieve the attrs that should be shown via the config
                self.metadata = ko.computed(function() {
                    self.fakeObservable();
                    
                    var result = {
                        title : "",
                        attrs : ko.observableArray([])
                    };

                    // get a list of desired fields from the config
                    var pertainableFields = null;
                    // get the desired title field from the config
                    var desiredTitle;

                    _.each(config.get("types").models, function(type) {
                    
                        // find the relevant list of attributes for the type of result we have
                        if(type.get("objectType") === self.objectType) {
                            pertainableFields = type.get("fields");

                            //Since we need to splice in the attributes when they come back from the
                            //label service, which may not be in order, we have to have a attrs array
                            //with the correct number of attrs already existing
                            _.each(type.get("fields"), function(item){
                                result.attrs.push({"name": "Fetching...", "value": "Fetching..."});
                            });
                        }

                        // set the field in which the title should be retrived
                        desiredTitle = type.get("title").ocName;
                    });

                    if(pertainableFields === null) { 
                        app.log.error(window.localize("modules.search.listView.noSuitable")+self.objectType+window.localize("modules.search.listView.foundConfigure"));
                    } else { 
                        _.each(pertainableFields, function(attribute) {
                            app.context.configService.getLabels(self.objectType, attribute.ocName).done(function(tempLabel) {
                              var value = thisModel.get("properties")[attribute.ocName];
                                //for each field from the configuration
                                //get the "user friendly" label for the attribute
                                //pertainable fields should always be in the order specified in the config
                                var counter;
                                _.each(pertainableFields, function(field, index) {
                                    if(attribute.ocName === field.ocName) {
                                        counter = index;
                                    }
                                });
                                if(counter !== undefined) {
                                    if(attribute.ocName === "objectType" || attribute.ocName === "objectTypeReadOnly") {
                                        result.attrs.splice(counter,1,{ "name" : "Object Type", "value" : value });
                                    } else {
                                        result.attrs.splice(counter,1,{ "name" : tempLabel, "value" : value });
                                    }
                                    
                                }  
                           });   
                        });
                        result.title = thisModel.get("properties")[desiredTitle];
                        if(!result.title){
                            result.title = "(no value)";
                        }
                    }

                    return result;
                });
                // Add the computed variable that we have just instantiated above to the list of KO items we need to dispose during this view's cleanup.
                that.disposableKOs.push(self.metadata);

                self.thumbnailUrl = ko.observable();
                thisModel.getThumbnail("medium", function(thumbUrl) {
                    self.thumbnailUrl(thumbUrl);
                });

                //using the config, build out stub actions

                var  actionCollection = new Action.Collection(_actions, {objectId : objectId});

                self.actions = kb.collectionObservable(actionCollection, { view_model : that.SimpleLittleActionViewModel});
                self.actionTime = function(){
                    _.each(app.context.actionParamService.getExtraParameters(), function(key, value) {
                        actionCollection[key] = value;
                    });
                    actionCollection.fetch(
                        {
                            success: Action.filterActions,
                            error: function(){
                                app.log.error("Failed to get Actions");
                                actionCollection.reset();
                            }
                        });
                };
                self.executeAction = function(actionViewModel){
                    var action = actionViewModel.model();
                    var config = _actionConfigMap[action.get("actionId")];
                    app[config.get("handler")].trigger("show", {action: action, config: config }); 
                };



                return this;
            };
            
        },

        afterRender: function() {
            var self = this; 
            
            var resultsVm = window.rvm =  {
                results: kb.collectionObservable(this.collection, {view_model : this.SearchResultVm}),
                selectedItems: ko.observableArray([])
            };

            var selectedItemsSubscription = resultsVm.selectedItems.subscribe(function(items){
                app.trigger("search:selectedResults", items);
            });
            // Add the computed variable that we have just instantiated above to the list of KO items we need to dispose during this view's cleanup.
            this.disposableKOs.push(selectedItemsSubscription);

            this.listenTo(app, "search:removeAllChecked", function() {
                resultsVm.selectedItems.removeAll();
            });

            this.listenTo(app, "search:checkAllResults", function() {
                _.each(resultsVm.results(), function(r) {
                    if (jquery.inArray(r.objectId(), resultsVm.selectedItems()) === -1) {
                        resultsVm.selectedItems.push(r.objectId());
                    }
                });
            }); 

            // When triggered, reloads the collection back into the 
            // collection observable
            this.listenTo(app, "resultsHaveMutated", function() {
                resultsVm.results.collection(new Backbone.Collection());
                resultsVm.results.collection(this.collection);
            });

            this.listenTo(app, "search:objectDelete", function(oid) {
                _.each(self.collection.models, function(model) {
                    if (model.get("objectId") === oid) {
                        self.collection.remove(model);
                    }
                });
                app.trigger("resultsHaveMutated");
                this.collection.fetch();
            });            

            kb.applyBindings(resultsVm, this.$el[0]);

            
            this.collection.fetch();
            
        },

        cleanup: function(){
            // Dispose of every KO item we have gathered
            _.each(this.disposableKOs, function(koItem){
                koItem.dispose();
            });
        }
    });

    // Return the module for AMD compliance.
    return ListView;

});
