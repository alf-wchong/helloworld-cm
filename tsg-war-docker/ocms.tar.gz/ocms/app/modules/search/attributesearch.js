// AttributeSearch module
define([
	// Application.
	"app",
	"modules/formsupport",
	"modules/common/spinner"
],
// Map dependencies from above array.
function(app, formSupport, OCMSSpinner) {

	// Create a new module.
	var AttributeSearch = app.module();
  	AttributeSearch.Stage = {};

	// Default Model.
	AttributeSearch.Model = Backbone.Model.extend({
	});

	AttributeSearch.ViewModel = function(query, inStage) {
		var self = this;

		self.inStage = _.isUndefined(inStage) ? false : inStage;
		self.availableObjectTypes = ko.observableArray();
		self.selectedObjectType = ko.observable();
		self.search = function() {
			app.trigger('facets:clearSnapshot', true);

			// If we are in stage then we want to run the query and populate VAD again. This trigger will do that for us. 
			if(self.inStage) {
				// remove the object type parameter if it has been populated 
				var searchParameters = _.filter(query.searchParameters, function(param) {
					return param.paramName !== self.objectType();
				});
				app.trigger('stageAttributeSearch:execute', { 
					objectType: self.objectType(),
					searchParameters: searchParameters
				});
				return;
			}

			app.trigger("search:execute");
			app.trigger('searchExecuted:renderSavedSearch');

			// If we perform an attribute search, we want to remove the openAnnotateSearchValue from local storage so that
			// we dont accidentally have that value stored if/when we navigate to stage view.
			window.localStorage.removeItem("openAnnotateSearchValue");
		};

		self.isShowingSecondary = ko.observable(false);
		self.expandText = ko.observable(window.localize("search.moreFields"));
		self.toggleShowSecondary = function() {
			self.isShowingSecondary(!self.isShowingSecondary());
			if (self.isShowingSecondary()) {
				self.expandText(window.localize("search.lessFields"));
			} else {
				self.expandText(window.localize("search.moreFields"));
			}
		};

		self.populateDefaults = function() {
			_.each(self.controls(), function(control){
				// Make sure the value isn't pre-populated; if it is, no action needs taken.
				if(!control.value() && control.defaultValues && control.defaultValues()) {
				// Populate the control with the last item, as this is a non-repeating attribute that takes only one value.
					control.value(control.defaultValues()[control.defaultValues().length - 1]);
				} else if(_.isArray(control.value()) && control.value().length === 0 && control.defaultValues && control.defaultValues()) {
					// Populate the control with each selected defaultItem, since this is a repeating attribute.
					_.each(control.defaultValues(), function(value) {
						var controlValues = control.value();
						controlValues.push(value);
						control.value(controlValues);
					});
				}
			});
		};

		self.reset = function() {
			self.clearValues();
			//needs to be a string if using the slider/> IE 9 or a boolean if IE 9 or lower
			//use drag and drop hack for checking if in IE 9 as IE 9 doesn't support drag and drop
			var inIE9 = !('draggable' in document.createElement('span'));
			if(inIE9){
				self.searchAllVersions(false);
			}else{
				self.searchAllVersions("false");
			}
			self.populateDefaults();
			self.updateAdvSearchParams();
			app.trigger("search:clearQuickSearchValue");
		};

		self.updateAdvSearchParams = function() {
			//iterate through all values. if the param exists already, update it. if not, add it
			var isComposite;
			if(this.options) {
				isComposite = this.options.selectedType();
			}
			$.each(self.getValues(), function(key, value){
				var foundProperty = false;
				_.map(query.searchParameters, function(sParam){
					if((sParam.paramType === 'property' || sParam.paramType === 'compositeProperty') && sParam.paramName === key){
						//TODO is this appropriate to do here, or should facets clean them selves based on some event?
						sParam.paramValue = value;
						foundProperty = true;
					}
				});
				if(!foundProperty && value && !_.isEmpty(value)){
					var sp;
					if(isComposite && isComposite.composite) {
						sp = {
							paramName: key,
							paramValue: value,
							paramType : "compositeProperty"
						};
					} else {
						sp = {
							paramName: key,
							paramValue: value,
							paramType : "property"
					};
					}
					query.searchParameters.push(sp);
				}
			});
			
		};

		self.setAdvSearchParams = function(query){
			var paramMapping = {};
			var savedTermsMap = {};
			if(query) {

				// Setting defaults on the paramObject so that we dont lose them in case there are no searchParameters 
				// If we do have searchParameters then these defaults will get overrriden
				_.each(self.controls(), function(searchAttr){
					if(searchAttr.value()){
						paramMapping[searchAttr.id] = searchAttr.value();
					}				
				});
			
				var searchAllVersions = false;
				_.each(query.searchParameters, function(sp){
					if (sp.paramType === "property" || sp.paramType === "compositeProperty" || sp.paramType === "allproperties") {
						paramMapping[sp.paramName] = sp.paramValue; //set name:value for property params
						query.paramsPopulated = true;
					}
					if(sp.paramType === 'searchallversions' && (sp.paramValue === true || sp.paramValue === 'true')){
						searchAllVersions = true;
					}
				});

				//needs to be a string if using the slider/> IE 9 or a boolean if IE 9 or lower
				//use drag and drop hack for checking if in IE 9 as IE 9 doesn't support drag and drop
				var inIE9 = !('draggable' in document.createElement('span'));
				if(inIE9) {
					self.searchAllVersions(searchAllVersions);
				} else {
					self.searchAllVersions(searchAllVersions ? "true" : "false");
				}
				self.updateAdvSearchParams();
			}
			//if there is a cookie and that cookie has a type step in
			if ($.cookie("savedTerms") && Object.keys(JSON.parse($.cookie("savedTerms")))) {
				//the next variable pulls down the cookie and parses through it
				var savedCookie = JSON.parse($.cookie("savedTerms"));
				//separate the parameter name and value from the type name in the cookie
				savedTermsMap = savedCookie[self.objectType()];
				//as long as there is an savedTermsMap(object)
				if(savedTermsMap) {
					self.updateAdvSearchParams();
				}	
			}
			self.setValues(_.extend(paramMapping, savedTermsMap));
		};
		self.allowSearchAllVersions = ko.observable(false);
		self.searchAllVersions = ko.observable(false);	
	};

	// Default View.
	AttributeSearch.Views.Layout = Backbone.Layout.extend({
		template: "search/attributesearch",

		initialize: function() {
			this.searchConfig = this.options.searchConfig;
			this.selectedType = this.options.selectedType;
			this.queryObject = this.options.collection;
			this.inStage = _.isUndefined(this.options.inStage) ? false : this.options.inStage;
			
			// since the view model is not built up until the after render, views using
			// this view should wait until the afterRender has finished
			this.afterRenderDeferred = $.Deferred();
			
			// Setup our listeners
			this._startListening();
		},
		_startListening: function() {
			this.listenTo(app, "tracOrTypeChange", function(type) {
				if(type) {
					// call without query just need to check the cookie values in case remember last search is enabled.
					this.viewModel.setAdvSearchParams();
				}
			});
			// Whenever we reset search values we want to clear the current ones off the form, or we might not display the true set of reset values
			this.listenTo(app, 'search:runningSavedSearch', function(){
				this.viewModel.clearValues();
			});
		},
		serialize: function() {
			return {
				hideFormButtons: this.inStage
			};
		},
		setDefaultSearchAllVersions: function(allowSearchAllVersions, defaultSearchAllVersions) {
			var containsSearchAllVersionParam = _.find(this.options.collection.searchParameters, function(searchParameter){
				return (searchParameter.paramName === "searchallversions");
			});

			if(containsSearchAllVersionParam){
				this.viewModel.searchAllVersions(containsSearchAllVersionParam.paramValue);
			} else {
				if(allowSearchAllVersions[this.selectedType().type] === "true" && defaultSearchAllVersions[this.selectedType().type] === "true"){
					this.viewModel.searchAllVersions("true");
					//If searchallversions isn't a search param (b/c we're loading the page for the first time), add it
					this.options.collection.searchParameters.push({
						paramName: "searchallversions",
						paramValue: "true",
						paramType : "searchallversions"
					});
				}
			}
		},
		afterRender: function() {
			var self = this;
			var attributeGroupsByType = {};
			var defaultSortAttrByObjectType = {};
			var defaultSortOrderByObjectType = {};
			var allowSearchAllVersions = {};
			var defaultSearchAllVersions = {};
			var formName = this.options.searchConfig.get("form");
			var formTypes = this.options.searchConfig.get("sidebarConfig").get("attributeSearchConfig").get("formTypes");

			app.context.configService.getFormConfig(formName, function(formConfig) {
				formConfig.get("configuredTypes").each(function(type) {
					var attrGroups = [];

					var currentFormType = _.find(formTypes, function(formType) {
						return formType.type === type.get("ocName");
					});
					var primaryAttrOcNames = _.map(type.get("configuredAttrsPri").models, function(attr) {
						return attr.get("ocName");
					});
					var secondaryAttrOcNames = _.map(type.get("configuredAttrsSec").models, function(attr) {
						return attr.get("ocName");
					});

					attrGroups.push({
						attributes: primaryAttrOcNames,
						isDefault: true
					});
					attrGroups.push({
						attributes: secondaryAttrOcNames,
						isDefault: false
					});

					//If the type is configured in attributeSearchConfig, great, lets use those configs.
					//Otherwise, lets use defaults
					if(currentFormType) {
						defaultSortAttrByObjectType[currentFormType.type] = currentFormType.defaultSortAttr;
						defaultSortOrderByObjectType[currentFormType.type] = currentFormType.defaultSortOrder;
						attributeGroupsByType[currentFormType.type] = attrGroups;
						allowSearchAllVersions[currentFormType.type] = currentFormType.allowSearchAllVersions;
						defaultSearchAllVersions[currentFormType.type] = currentFormType.defaultSearchAllVersions;
					} else {
						defaultSortAttrByObjectType[type.get("ocName")] = "objectName";
						defaultSortOrderByObjectType[type.get("ocName")] = "-1";
						attributeGroupsByType[type.get("ocName")] = attrGroups;
						allowSearchAllVersions[type.get("ocName")] = "true";
						defaultSearchAllVersions[type.get("ocName")] = "false";
					}
				});

				//this accounts for overriding the formType - after everything is set the first time, see
				//if anything should be overwritten with something else
				//this is crappy double looping and attribute groups should be re-written in the future
				formConfig.get("configuredTypes").each(function(type) {
					if (type.get("overrideType")) {
						attributeGroupsByType[type.get("ocName")] = attributeGroupsByType[type.get("overrideType")];
					}
				});

				var viewModel = self.viewModel = new AttributeSearch.ViewModel(self.collection, self.inStage);

				var options = {
					"enableRequired" : false,
					"searchMode" : true,
					"attributeGroups" : attributeGroupsByType,
					"formName": formName
				};
				
				formSupport.tsgFormSupport(viewModel, options);
				viewModel.attributeGroups(attributeGroupsByType);
				viewModel.objectType.valueHasMutated();

				// cleanup listener to prevent having multiple set up
				self.stopListening(viewModel.eventManager, "fs:change");
				//this listens for a change in any of the attribute search criteria
				self.listenTo(viewModel.eventManager, "fs:change", viewModel.updateAdvSearchParams);


				viewModel.objectType(self.selectedType().type);
				
				viewModel.setAdvSearchParams(self.queryObject);

				// after controls subscription has been hit once, dispose so it doesn't get called when switching object types
				var disposeSubscription = function(subscription) {
					subscription.dispose();
				};

				var controlsSubscription = viewModel.controls.subscribe(function() {
					self.queryObject.defaultsOnly = false;
					viewModel.setAdvSearchParams(self.queryObject);

					disposeSubscription(controlsSubscription);
				});

				//create observable to show secondAttrs
				viewModel.numSecondary = ko.observable(0);

				if(defaultSortAttrByObjectType[self.selectedType().type] !== "")
				{
					self.queryObject.state.sortKey = defaultSortAttrByObjectType[self.selectedType().type];
					self.queryObject.state.order = defaultSortOrderByObjectType[self.selectedType().type];
				}

				if(allowSearchAllVersions[self.selectedType().type] && allowSearchAllVersions[self.selectedType().type] === "true") {
					viewModel.allowSearchAllVersions(true);
				} else {
					viewModel.allowSearchAllVersions(false);
				}

				//Checking if any of the attributes in the secondary form have been searched on.
				//If so, want to show the secondary form when the page re render
				var queryParamNames = _.pluck(self.queryObject.searchParameters, "paramName");

				//checks if the selected objectType has secondAttrs
				//Sets numSecondary to 0 if no, 1 if yes
				var checkSecondAttrs = function(vm){
					vm.numSecondary(0);
					_.each(attributeGroupsByType[vm.objectType()], function(group)
					{
						if (group.isDefault === false &&  group.attributes.length !== 0)
						{
							var secondaryAttrSearch = _.intersection(queryParamNames, group.attributes);
							if(secondaryAttrSearch && secondaryAttrSearch.length > 0) {
								viewModel.isShowingSecondary(true);
								viewModel.expandText(window.localize("search.lessFields"));
							}
							vm.numSecondary(1);
						}
					});
					return vm.numSecondary();
				};

				viewModel.numSecondary(checkSecondAttrs(viewModel));
				
				self.selectedType.subscribe(function(){
					//if the objecttype changes empty the query and wipe old searchParams
					self.queryObject.searchParameters.length = 0;
					viewModel.objectType(self.selectedType().type);
					if(defaultSortAttrByObjectType[self.selectedType().type] !== "")
					{
						self.queryObject.state.orderKey = defaultSortAttrByObjectType[self.selectedType().type];
						self.queryObject.state.sortKey = defaultSortAttrByObjectType[self.selectedType().type];
						self.queryObject.state.order = defaultSortOrderByObjectType[self.selectedType().type];
					}

					if(allowSearchAllVersions[self.selectedType().type] && allowSearchAllVersions[self.selectedType().type] === "true") {
						viewModel.allowSearchAllVersions(true);
					} else {
						viewModel.allowSearchAllVersions(false);
					}
					viewModel.numSecondary(checkSecondAttrs(viewModel));
				});
				
				// cleanup listener to prevent having multiple set up
				self.stopListening(self.options.collection, 'sync');

				self.listenTo(self.options.collection, 'sync', function(){
					viewModel.setAdvSearchParams(self.options.collection);
				});
						
				self.setDefaultSearchAllVersions(allowSearchAllVersions, defaultSearchAllVersions);
				
				viewModel.searchAllVersions.subscribe(function(newVal) {
					var foundProperty = false;
					_.map(self.options.collection.searchParameters, function(sParam){
						if(sParam.paramType === 'searchallversions'){
							sParam.paramValue = newVal;
							foundProperty = true;
						}
					});
					if(!foundProperty){
						self.options.collection.searchParameters.push(
							{
								paramName: "searchallversions",
								paramValue: newVal,
								paramType : "searchallversions"
							}
						);
					}
				});

				if(!self.queryObject.paramsPopulated) {
					//if no parameters existed on our query before, go ahead and populate any default values
					self.viewModel.populateDefaults();
					self.queryObject.defaultsOnly = true;
				}

				kb.applyBindings(viewModel, self.$el[0]);

				app.log.debug(window.localize("modules.search.attributeSearch.attributeSearch"));
				self.afterRenderDeferred.resolve();
			});
		}
	});

	// Attribute Search in Stage
	AttributeSearch.Stage.Model = Backbone.Model.extend({
		initialize: function(options) {
			this.set('searchConfig', options.searchConfig);
			this.set('selectedType', ko.observable());
			this.set('collection', options.collection);
		
			// flags used for animation and visibility
			this.set('isViewVisible', false);
			this.set('isLoading', false);

			// Setting up the deferred that tracks when this model has been fully initialized
			this.set('initializeDeferred', $.Deferred());

			$.when(this.getDocumentTypesFromTrac()).done(_.bind(function() {
				// when all deferreds are sucessful resolve
				this.get('initializeDeferred').resolve();
			}, this));
		},
		getDocumentTypesFromTrac: function() {
			var deferred = $.Deferred();

			var self = this;
			var searchObjectTypes = this.get('searchConfig').get('sidebarConfig').get('attributeSearchConfig').get('formTypes');
			var searchOTCs = [];

			// get otcs matching oc names on the search config
			app.context.configService.getAdminOTC(function(adminOTC) {
				var allOTCs = adminOTC.get('configs').models;

				searchOTCs = _.filter(allOTCs, function(otc) {
					var matchingOTC = _.find(searchObjectTypes, function(searchObjectType) {
						// return otc that matches the searchOTC
						return otc.get('ocName') === searchObjectType.type;
					});
					// matching otc exsits and it is not a container
					return matchingOTC && otc.get('isContainer') === 'false';
				});

				self.set('searchOTCs', searchOTCs);
				if (!_.isUndefined(self.get('searchOTCs')[0])) {
					// set the first selected type if it exists
					self.get('selectedType')({ 
						type: self.get('searchOTCs')[0].get('ocName'), 
						label: self.get('searchOTCs')[0].get('label') 
					}); // ko.observable
				}

				deferred.resolve();
			});

			return deferred;
		}
	});

	AttributeSearch.Stage.View = Backbone.Layout.extend({
		className: 'attribute-search-stage',
		template: 'search/attributesearchstage',
		events: { 
			'click .fn-typeChanged': 'typeChanged',
			'click .fn-toggleView': 'toggleView',
			'click .fn-resetForm': 'resetForm',
			'click .fn-submitForm': 'submitForm'
		},
		initialize: function(options) {
			this.model = new AttributeSearch.Stage.Model(options);
			this.searchResultsViewController = options.searchResultsViewController;
			this.startListening();
			
			$.when(this.model.get('initializeDeferred')).done(_.bind(function(){
				this.setAttributeSearchView();
				
				// the after render needs to finish, that is where the viewmodel is built
				// before this deferred finishes the access to the viewmodel is undefined
				$.when(this.attributesearchview.afterRenderDeferred).done(_.bind(function() {
					// update repeating this section to update the query on the view model
					if (!_.isUndefined(this.model.get('searchOTCs')[0])) {
						// set the first selected type if it exists
						this.model.get('selectedType')({ 
							type: this.model.get('searchOTCs')[0].get('ocName'), 
							label: this.model.get('searchOTCs')[0].get('label') 
						}); // ko.observable
					}
				}, this));
			}, this));
		},
		typeChanged: function (event) {
			var label = this.$(event.target).text();
			var value = event.currentTarget.id.replace('search-stage-for-', '');
			var selectedOTC = _.find(this.model.get('searchOTCs'), function(searchOTC) {
				return searchOTC.get('ocName') === value;
			});
			
			// update the attributeseach view through ko obverable
			this.model.get('selectedType')({ type: selectedOTC.get('ocName'), label: label }); // update the selected type
			app.trigger('searchsidebar:typeChanged', this.model.get('selectedType')().type); // send it along for searchresultcontrols
			this.render();
		},
		setAttributeSearchView: function() {
			this.attributesearchview = new AttributeSearch.Views.Layout({
				searchConfig: this.model.get('searchConfig'),
				selectedType: this.model.get('selectedType'),
				collection: this.model.get('collection'),
				inStage: true
			});

			this.setView('#attribute-search-outlet-' + this.cid, this.attributesearchview);
		},
		toggleView: function() {
			var self = this;
			var wasVisible = this.model.get('isViewVisible');

			this.$('.attribute-search-stage-background, .attribute-search-stage-content').toggleClass('active');
			if (wasVisible) {
				// it was visible so prep for closing
				this.$('.attribute-search-stage-content').addClass('closing');
			} else {
				// it was invisible so prep for opening
				this.$('.attribute-search-stage-content').addClass('opening');
			}

			// when the animation has finished remove the class to prevent the animation from firing again on redraw
			this.$('.attribute-search-stage-content').one('animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd', function() {
				self.$('.attribute-search-stage-content').removeClass('opening closing');
			});

			this.model.set('isViewVisible', !wasVisible);
		},
		resetForm: function() {
			this.attributesearchview.viewModel.reset();
		},
		submitForm: function() {
			// add the spinner to the view
			this.model.set('isLoading', true);

			this.$('#stageAttributeSearch-spinner').addClass('active');
			// prevent clicks from closing the view
			this.$('#attribute-search-stage-close, .attribute-search-stage-background').removeClass('fn-toggleView');
			var spinnerOpts = {
				lines: 12, // The number of lines to draw
				length: 12, // The length of each line
				width: 5, // The line thickness
				radius: 20, // The radius of the inner circle
			};
			this.spinner = OCMSSpinner.createSpinner(spinnerOpts, this.$('#stageAttributeSearch-spinner')[0]);

			// execute the search function through the view model
			this.attributesearchview.viewModel.search();
			this.searchResultsViewController.showingSearchResultsInStage = true;
		},
		searchFinished: function() {
			// Resetting the grid so that the selected documents are page numbers do not persist when generatind std view
			this.searchResultsViewController.resetGrid();

			// remove the spinner
			this.model.set('isLoading', false);
			this.$('#stageAttributeSearch-spinner').removeClass('active');
			// add back the click to toggle functionality
			this.$('#attribute-search-stage-close, .attribute-search-stage-background').addClass('fn-toggleView');
			OCMSSpinner.destroySpinner(this.spinner);

			// close the view
			this.toggleView();
		},
		startListening: function() {
			// triggered by view all documents view when query finishes executing
			this.listenTo(this.searchResultsViewController.tableEventsRef, 'attributeSearchStage:searchFinished', this.searchFinished);
			// This will get triggered when the search button is clicked to show the user the form and search options. 
			this.listenTo(this.searchResultsViewController.tableEventsRef, 'stageAttributeSearch:toggleView', this.toggleView);
		},
		serialize: function() {
			return {
				cid: this.cid,
				visible: this.model.get('isViewVisible'),
				multipleOTCs: this.model.get('searchOTCs').length > 1,
				otcsToSearchOn: this.model.get('searchOTCs'),
				selectedType: this.model.get('selectedType')() // ko.observable
			};
		}
	});

	// Return the module for AMD compliance.
	return AttributeSearch;

});