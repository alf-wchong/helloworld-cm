// Searchresults module
define([
	// Application.
	"app",
	"knockout",
	"knockback",
	"jquery",
	"modules/common/action",
	"modules/common/spinner"
],

// Map dependencies from above array.
function(app, ko, kb, jquery, Action, HPISpinner) {

	// Create a new module.
	var GridView = app.module();

	//Default view 
	GridView.Views.Layout = Backbone.Layout.extend({
		template: "search/gridview",
		className: "grid-view",

		initialize: function(options) {
			var self = this;

			this.name = "grid-view";
			this.maxProps = 0;
			//toggle to server-side
			this.options.collection.switchMode("server");
			this.results = this.options.collection;
	 		this.config = this.options.searchConfig;
	 		this.selections = [];
	 		//Setup various listeners
	 		this.listenTo(this.results, "query:complete", function(collection) {
	 			self.renderResults(collection);
	 		});

	 		this.listenTo(app, "search:gridviewItemSelected", function(item) {
	 			self.childSelected(item);
	 		});
	 		this.listenTo(app, "search:gridviewItemDeselected", function(item) {
	 			self.childDeselected(item);
	 		});

	 		this.listenTo(app, "search:removeAllChecked", function(){
	 			self.deselectAllChildren();
	 		});
	 		this.listenTo(app, "search:checkAllResults", function(){
	 			self.selectAllChildren();
	 		});
	 		this.listenTo(app, "search:objectDelete", function(item){
	 			self.childDeselected(item);
	 		});
	 		this.listenTo(app, "resultsHaveMutated", function() {
                self.renderResults();
            });
		},
		events: {
			"click #quickSearch": "openQuickSearch"
		},
		renderResults: function(){
			var self = this;

			//figure out max number of props to show
			_.each(this.results.models, function(model){
				var type = self.config.get("types").findWhere({objectType: model.get("objectType")});
				if(type && type.get("visibleFields").length > self.maxProps){
					self.maxProps = type.get("visibleFields").length;
				}
			});
			_.each(this.results.models, $.proxy(self.renderResult, self));

			self.render();		
		},
		renderResult: function(model) { 
			var self = this;

			var checked = _.contains(this.selections, model.id);
			var resultView = new GridView.Views.Result({
				model: model,
				config: self.config,
				checked: checked,
				maxProps: self.maxProps
			});

			this.insertView(".search-results-outlet", resultView);

		},
		childSelected: function(item){
			this.selections.push(item);
			app.trigger("search:selectedResults", this.selections);
		},
		childDeselected: function(item){
			var idx = this.selections.indexOf(item);
			if(idx !== -1){
				this.selections.splice(idx);
				app.trigger("search:selectedResults", this.selections);
			}
		},
		selectAllChildren: function(){
			var self = this;
			this.selections = [];

			_.each(this.results.models, function(model){
				self.selections.push(model.id);
			});
			app.trigger("search:changeAllCheckboxes", true);
			app.trigger("search:selectedResults", this.selections);
		},
		deselectAllChildren: function(){
			this.selections = [];

			app.trigger("search:changeAllCheckboxes", false);
			app.trigger("search:selectedResults", this.selections);
		},
		serialize: function() {
			// todo: return object for handlebars w/ necessary model data
			return {
				hasNoResults : (this.collection.models.length === 0)
			};
		}
	});
	//The view for each individual result
	GridView.Views.Result = Backbone.Layout.extend({
		template: "search/gridview-result",
		className: "grid-view-result",

		events: {
			"click .result" : "resultClicked",
			"change .checkBoxGrid" : "checkBoxChanged"
		},
		initialize: function(options) {
			var self = this;
			this.model = this.options.model;
			this.config = this.options.config;

			self.objectType = this.model.get("objectType");
			this.isImageLoaded = false;
			this.isChecked = this.options.checked;

			self.resolver = (function() {
				var type = self.config.get("types").find(function(thisModel) {
				if(thisModel.get("objectType") === self.objectType) {
					return true;
				}
				});
				if(type) {     
					return type.get("resolver");
				}
			})();

			// Create actions-dropdown subview
			var actionDropView = new Action.Views.Dropdown({
				model: self.model,
				config: self.config
			});
			this.insertView(".grid-view-actions-dropdown", actionDropView);
			// Create the properties subview
			var propertyView = new GridView.Views.Properties({
				model: self.model,
				config: self.config,
				maxProps: self.options.maxProps
			});
			this.insertView(".search-result-props", propertyView);
			

			this.listenTo(app, "search:changeAllCheckboxes", function(checked){
				this.changeCheckBox(checked);
			});
		
		},
		changeCheckBox: function(checked){
			this.$(".checkBoxGrid")[0].checked = checked;
		},
		//Bring up the selection form where the user can decide which stage configureation
		// to view this search result with
		getHandler: function() { 
				var url = "";
				if(this.resolver.match("stage")) {
					app.routers.main.stageSimple(this.model.get("objectId") );
					return;
				} else if(this.resolver === "detailview") { 
					// encode the uri for url safety and add the "true" flag that tells the detail view we need a "back" button
					url = "details/" + app.context.configName() + "/" + encodeURIComponent(this.model.get("objectId")) + "/true";
				}
				else if(this.resolver === "stream") {
						var iframe;
							iframe = document.getElementById("hiddenDownloader");
							if (iframe === null) {
								iframe = document.createElement('iframe');
								iframe.id = "hiddenDownloader";
								iframe.style.visibility = 'hidden';
								document.body.appendChild(iframe);
							}
							iframe.src = app.serviceUrlRoot + "/content/content?id=" + encodeURIComponent(this.model.get("objectId")) +"&download=true";
						}
				//add another else if self.resolver === "stream"
				//"details/" + app.context.configName() + "/" + encodeURIComponent(thisModel.get("objectId")) + encodeURIComponent(thisModel.get("docBaseName"))
				Backbone.history.navigate(url, {trigger: true});
		},
		resultClicked: function() {
			this.getHandler();
		},
		checkBoxChanged: function() {
			if(this.$(".checkBoxGrid")[0].checked){
				//this.isChecked = false;
				app.trigger("search:gridviewItemSelected", this.model.id);
			}
			else{
				//this.isChecked = true;
				app.trigger("search:gridviewItemDeselected", this.model.id);
			}
		},
		afterRender: function() { 
			this.loadThumbnail();
			this.changeCheckBox(this.isChecked);
		},
		loadThumbnail: function(){
			// if we already have a spinner we want to get rid of it before we re-add it (which removes it from the DOM and allows the spin
			// library to do cleanup). If you get rid of the below line you'll run into an IE9 issue (try switching tracs from the search page).
			HPISpinner.destroySpinner(this.spinner);
			if(this.isImageLoaded === false){
				var self = this;
				//Create loading spinner if the image is not loaded
				var spinElem = this.$el.find("div.app-loading")[0];
				this.spinner = HPISpinner.createSpinner({
					length:8,
					width:5,
					radius: 12,
					color: '#ccc',
					shadow: true 
				}, spinElem);
				// Call get thumbnail for this view's thumbnail img element
				this.model.getThumbnail("medium", function(thumbUrl){
	            	self.$("img.grid-item-thumb").attr('src', thumbUrl);
					HPISpinner.destroySpinner(self.spinner);
	            	self.isImageLoaded = true;
	            });
			}
		},
		serialize: function(){
			return {
				maxProps: GridView.HeightMap(this.options.maxProps)
			};
		}
	});

	GridView.Views.Properties = Backbone.Layout.extend({
		template: "search/gridview-properties",
		className: "grid-view-properties",
		events: {
			"click .result" : "resultClicked"
		},
		initialize: function(options) {
			var self = this;
			this.model = this.options.model;
			this.config = this.options.config;

			this.displayAttrs = []; 
			this.objectType = this.model.get("objectType");
			this.formattingComplete = false;

			self.resolver = (function() {
				var type = self.config.get("types").find(function(thisModel) {
				if(thisModel.get("objectType") === self.objectType) {
					return true;
				}
				});
				if(type) {     
					return type.get("resolver");
				}
			})();
			//Determines what properites need to shown and gets them from the label service.
			this.fieldLabels = this.getDisplayFields();
			
			//Save the deffered from the formatter
			var formatDef = this.model.formatPropertiesReadOnly();
			//Once the formatter has updated the model, reset displayFields and render the newly formatted data.
			formatDef.done(function(){
				self.formattingComplete = true;
				self.fieldLabels = self.getDisplayFields();
				self.render();
			});
		},
		//Bring up the selection form where the user can decide which stage configureation
		// to view this search result with
		getHandler: function() { 
				var url = "";
				if(this.resolver.match("stage")) {
					app.routers.main.stageSimple(this.model.get("objectId") );
					return;
				} else if(this.resolver === "detailview") { 
					// encode the uri for url safety and add the "true" flag that tells the detail view we need a "back" button
					url = "details/" + app.context.configName() + "/" + encodeURIComponent(this.model.get("objectId")) + "/true";
				}
				else if(this.resolver === "stream") {
						var iframe;
							iframe = document.getElementById("hiddenDownloader");
							if (iframe === null) {
								iframe = document.createElement('iframe');
								iframe.id = "hiddenDownloader";
								iframe.style.visibility = 'hidden';
								document.body.appendChild(iframe);
							}
							iframe.src = app.serviceUrlRoot + "/content/content?id=" + encodeURIComponent(this.model.get("objectId")) +"&download=true";
						}
				Backbone.history.navigate(url, {trigger: true});
		},
		getDisplayFields:function(){
			var self = this;
			var searchedTypeFields = null;
			var result = [];
			result.displayFields = [];
			var desiredTitle = "";


			_.each(this.config.get("types").models, function(type) {
				// find the relevant list of attributes for the type of result we have
				if(type.get("objectType") === self.objectType || self.model.collection.collectionId !== undefined) {
					searchedTypeFields = type.get("fields");

					//Since we need to splice in the attributes when they come back from the
                    //label service, which may not be in order, we have to have a attrs array
                    //with the correct number of attrs already existing
                    _.each(type.get("fields"), function(item){
                        result.displayFields.push({"name": "Fetching...", "value": "Fetching..."});
                    });
				}

				// set the field in which the title should be retrived
				desiredTitle = type.get("title").ocName;
			});

			if(searchedTypeFields === null) { 
				app.log.error(window.localize("modules.search.gridView.noSuitable")+self.objectType+window.localize("modules.search.gridView.foundConfigure") + self.model.get("properties").objectName);
			}
			else { 
				_.each(searchedTypeFields, function(attribute) {
                    app.context.configService.getLabels(self.objectType, attribute.ocName).done(function(tempLabel) {
		                var value = self.model.get("properties")[attribute.ocName];
		                //for each field from the configuration
		                //get the "user friendly" label for the attribute
	                    //pertainable fields should always be in the order specified in the config
	                    var counter;
	                    _.each(searchedTypeFields, function(field, index) {
	                        if(attribute.ocName === field.ocName) {
	                            counter = index;
	                        }
	                    });
	                    if(counter !== undefined) {
	                    	if(attribute.ocName === "objectType" || attribute.ocName === "objectTypeReadOnly") {
	                    		result.displayFields.splice(counter,1,{ "name" : "Object Type", "value" : value });
	                    	} else {
								result.displayFields.splice(counter,1,{ "name" : tempLabel, "value" : value });
	                    	}
	                        
	                    } 
                    });       
	            });
				result.title = this.model.get("properties")[desiredTitle];
				if(!result.title){
                            result.title = "(no value)";
                }
			}
			return result;
		},
		resultClicked: function() {
			this.getHandler();
		},
		serialize: function() {
			if(!this.fieldLabels.title){
				this.fieldLabels.title = "(no value)";
			}
			return {
				title : this.fieldLabels.title,
				propertyLabels : this.fieldLabels.displayFields,
				formatLoaded : this.formattingComplete
			};
		}
	});

	GridView.HeightMap = function(num){
		var className = "";
		if(num < 7){
			className = "grid-view-" + num + "-prop-height";
		}
		else {
			className = "grid-view-" + 6 + "-prop-height";
		}
		return className;
	};

	return GridView;

});

