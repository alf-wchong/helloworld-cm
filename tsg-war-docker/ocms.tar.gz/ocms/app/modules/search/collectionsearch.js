// Advancedsearch module
define([
    // Application.
    "app",
    "knockback",
    "knockout",
    "jquery",
    "underscore"
    ],

// Map dependencies from above array.
function(app, kb, ko, $, _) {

    "use strict";

    // Create a new module.
    var CollectionSearch = app.module(),
        _selectedViewModel = null;

    function getResultViewModel(queryObject, loadedCollection) {
        return kb.ViewModel.extend({
            constructor: function(model, options) { 
                var self = this;
                self.model = model;
                kb.ViewModel.prototype.constructor.call(this, model, options);
                
                self.query = queryObject;

                self.getCollectionItems = function() {
                    app.context.actionParamService.setExtraParameter("collectionId", self.model().id);
                    app.trigger("collection:collectionChange");

                    if(!app.collectionRelation) {
                        app.log.error(window.localize("modules.search.collectionSearch.theRelationObject"));
                    }
                    _selectedViewModel = self; // making this vm as the selected one
                    self.isSelected(true);

                    // Form the URL to store current state
                    var sortUrl = "";
                    var curUrl = Backbone.history.fragment.split("collections")[1];
                    var searchParam = "";
                    if ((new RegExp("&paramValue")).test(curUrl)) {
                        searchParam += "&paramValue=" + curUrl.split("&paramValue=")[1];
                    }
                    if (self.query.state.sortKey !== null) {
                        sortUrl += "&sortAttr=" + self.query.state.sortKey + "&sortOrder=" + self.query.state.order;
                    } else {
                        sortUrl += "&sortAttr=_&sortOrder=_";
                    }
                    var collectionUrl = "collections/" + self.model().id + "&pageNumber=" + self.query.state.currentPage + sortUrl + searchParam;
                    app.log.debug('collection search: fetching collection items: ' + collectionUrl);
                    // navigate to the URL and load the results
                    Backbone.history.navigate( collectionUrl );
                    // loadUrl works if we want to re-load the same query twice
                    Backbone.history.loadUrl( collectionUrl );
                };

                self.isSelected = ko.observable(false);
                var localPreferences = app.context.cookieService.getUserPreferences('collectionTab');
                if (undefined !== localPreferences) {
                    if (loadedCollection === self.model().id && localPreferences.collectionTab === "myCollections") {
                        _selectedViewModel = self;
                        self.getCollectionItems();
                        self.isSelected(true);
                    }
                }

                return self;
            }
        });
    }

    CollectionSearch.ViewModel = function(query, options) {
        var self = this;
        self.searchCriteria = ko.observable();
        // If a search criteria was passed in, set the observable to it
        if (query.searchParameters.length > 0) {
            self.searchCriteria(query.searchParameters[0].paramValue);
        }

        self.results = kb.collectionObservable(query, {
            view_model : getResultViewModel(options.collectionItems, options.loadedCollection)/*(model, {collection : options.collection})*/
        }); 

        self.search = function() {

            // always go to the first page of results on a new search
            query.state.currentPage = 0;
            
            var sp;

            // remove any old type/property/allproperties params
            query.searchParameters = _.filter(query.searchParameters, function(sParam){
                if(sParam.paramType !== 'property' && sParam.paramType !== 'type' && sParam.paramType !== 'allproperties'){
                    //*** is this appropriate to do here, or should facets clean them selves based on some event?
                    sParam.paramValue = "";
                    return true;
                }
                return false;
            }); 

            // Validate whether the search value was empty
            if (!self.searchCriteria()) {
                app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.search.collectionSearch.pleaseEnter"), "#collections-search-alert");
                window.scrollTo({ top: 0, behavior: 'smooth' });
                return;
            }
            
            // right now, let's have the input search on allproperties
            // might want to go for owner or objectName or something in the future
            sp = {
                paramName: "allproperties",
                paramValue: self.searchCriteria(),
                paramType : "allproperties"
                };
            query.searchParameters.push(sp);
            // and one to specify that we're searching on hpi_collection
            sp = {
                paramName: "Collection",
                paramValue: "Collection",
                paramType : "type"
            };
            query.searchParameters.push(sp);
            var curUrl = Backbone.history.fragment.split("collections")[1];
            var newUrl;
            if (curUrl === "") {
                newUrl = "/__&paramValue=" + self.searchCriteria();
            } else {
                if ((new RegExp("&paramValue")).test(curUrl)) {
                    curUrl = curUrl.split("&paramValue=")[0];
                }
                newUrl = curUrl + "&paramValue=" + self.searchCriteria();
            }
            query.fetch();
        };
    };

    // Default View.
    CollectionSearch.Views.Layout = Backbone.Layout.extend({
        template: "search/collectionsearch",

        afterRender: function() {
            var self = this;

            self.vm = window.colVm = new CollectionSearch.ViewModel(self.options.collections, {collectionItems : self.options.collectionItems, loadedCollection : self.options.loadedCollection});
            
            self.listenTo(app, "collection:collectionChange", function() {
                _.each(self.vm.results(), function(result) {
                    result.isSelected(false);
                });
            });

            this.listenTo(app, "action:itemModified",  function(){
                if (_selectedViewModel){
                    _selectedViewModel.getCollectionItems();
                }
            });

            // attempt to focus() the text box for usability
            $(this.el).find("input[type='text']").focus();

            kb.applyBindings(self.vm, this.$el[0]);

        }
    });

    // Return the module for AMD compliance.
    return CollectionSearch;

});
