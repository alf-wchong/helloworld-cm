// Searchresults module
define([
        "app",
        "modules/search/searchresultcontrols",
        "tableview",
        "thumbnailview",
        "listview",
        "modules/common/hpiconstants"
    ],

    function(app, SearchResultControls, TableView, ThumbnailView, ListView, HPIConstants) {

        // Create a new module.
        var SearchResults = app.module();

        // Default View.
        SearchResults.Views.Layout = Backbone.Layout.extend({
            template: "search/searchresults",
            initialize: function() {
                this.name = "search-results";
                this.searchQuery = this.options.collection;
                this.searchResults = this.options.configuration;
                this.context = this.options.context;
                this.searchResultsViewController = this.options.searchResultsViewController;
                this.applyListeners();
                this.createAndSetSearchResultControls();
                this.createTableView();
                // Set but not render.. search router will render this view
                var view = {};
                view["#results-outlet-" + this.cid] = this.tableView; 
                this.setViews(view);
            },
            applyListeners: function() {
                this.stopListening();
                //did contain an error check but can not be used due to the trac configs
                this.listenTo(this.searchResultsViewController.tableEventsRef, "search:changeView", this.switchView, this);
                this.listenTo(this.searchResultsViewController.tableEventsRef , "rolebased:results:message:update", function(roleBasedViewName){
                    this.roleBasedViewName = roleBasedViewName;
                });
            },
            createAndSetSearchResultControls: function() {
                this.setView("#control-outlet-" + this.cid, new SearchResultControls.Views.Layout({
                    'collection': this.searchQuery,
                    'searchConfig': this.searchConfig,
                    'searchResults': this.searchResults,
                    'hideSortControls': true,
                    'viewType': this.viewType || HPIConstants.TableView.ViewType.TableView,
                    'roleBasedViewName': this.roleBasedViewName,
                    'initialType': this.options.initialType,
                    'searchResultsViewController': this.searchResultsViewController,
                    'context': this.context,
                    'hideCheckAll': this.context === HPIConstants.TableView.Context.ACTPDF || this.context === HPIConstants.TableView.Context.DatabaseTableView
                }));
            },
            createTableView: function() {
                this.tableView = new TableView.Views.Layout({
                    context: this.context,
                    route: this.route,
                    collection: this.searchQuery,
                    searchConfig: this.searchResultsViewController.useConfigs ? this.searchResults.get("resultsConfig").get("resultsTableConfig") : {},
                    searchResults: this.searchResults,
                    viewType: this.viewType,
                    groupActions: this.searchResultsViewController.useConfigs ? this.searchResults.get("resultsConfig").get("groupActionsConfig").get("actions") : {},
                    searchResultsViewController: this.searchResultsViewController
                });
            },
            createThumbnailView: function(){
                return new ThumbnailView.View({ 
                    collection: this.searchQuery,
                    searchResultsViewController: this.searchResultsViewController
                });
            },
            createListView: function(){
                return new ListView.View({ 
                    collection: this.searchQuery,
                    searchResultsViewController: this.searchResultsViewController
                });
            },
            switchView: function(viewType) {
                app.log.debug(window.localize("modules.search.searchResults.eventFiring"));
                //default to TableView
                this.viewType = !viewType ? HPIConstants.TableView.ViewType.TableView : viewType;

                //this sets up cour pageable collection for correct sorting
                //the collection needs to be in client mode for the collection route,
                //or if we are in the Table view, the else catches when we are on the 
                //search page and using the Grid or List view
                if(this.context === HPIConstants.TableView.Context.Collections || 
                   this.viewType === HPIConstants.TableView.ViewType.TableView || 
                   this.viewType === HPIConstants.TableView.ViewType.ResetTableView || 
                   this.viewType === HPIConstants.TableView.ViewType.StandardTableView) {
                       this.searchQuery.mode = "client";
                }else {
                    this.searchQuery.mode = "server";
                }
                // switch to grid view if specified
                var view = {};
                if (this.viewType === HPIConstants.TableView.ViewType.ThumbnailView) {
                    view["#results-outlet-" + this.cid] = this.createThumbnailView();
                    this.setViews(view).render();
                } else if (this.viewType === HPIConstants.TableView.ViewType.ListView) {
                    view["#results-outlet-" + this.cid] = this.createListView();
                    this.setViews(view).render();
                } else {
                    this.createTableView();
                    view["#results-outlet-" + this.cid] = this.tableView;
                    this.setViews(view).render();
                }
            },
            cleanup: function(){
                this.stopListening();
            },
            serialize: function(){
                return {
                    'cid': this.cid
                };
            }
        });

        // Return the module for AMD compliance.
        return SearchResults;
    });