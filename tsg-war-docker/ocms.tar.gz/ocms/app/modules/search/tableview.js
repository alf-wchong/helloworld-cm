define([
    "app",
    "modules/common/action",
    "modules/common/linkformatterutil",
    "modules/common/booleanutils",
    "module",
    "modules/stage/searchresulttraversal",
    "modules/actions/actionmodules",
    "modules/common/hpiconstants",
    "modules/openannotate/oacontainer",
    "modules/common/spinner",
    "modules/actions/selectversionview",
    "modules/services/logstashservice",
    "tsgUtils"
],
function(app, Action, LinkFormatter, BooleanUtils, module, SearchResultTraversal, ActionModules, HPIConstants, OAContainer, HPISpinner, SelectVersion, LogstashService, tsgUtils) {

    // Create a new module.
    var TableView = app.module();

    //module context
    TableView.config = module.config();
    // implementing any row formatting here
    // exposed on the module for easy extension
    // column def has a property hpiConfig that provides access the attr config (datatype/label etc)
    // NOTE: if this is slow talk to mstein about how to make it better
    TableView.hpiFormatter = function(row, cell, value, columnDef, dataContext) {
        if (_.isUndefined(value)) return "";
        var formattedColVal = value; //placeholder so we don't return before considering all possibilities
        //assumes dates will never be the link
        var type = columnDef.type;
        var iconConfig = TableView.getIconConfig(type);
        var specialIcon = '';

        if(columnDef.hpiConfig.get("dataType") === "string" && value && !_.isArray(value)){
            //lets cancel any html-looking tags to be normal text
            formattedColVal = _.escape(value);
        } else if(columnDef.hpiConfig.get("dataType") === "string" && value && _.isArray(value)) {
            _.each(value, function(val, index){
               formattedColVal[index] = _.escape(val);
            });
        }

        if (columnDef.isLink) {
            // default the mimetype and notesNotifier icons to not show (empty strings), if they are set to show in the config then show them (put icon tags in the strings)
            var mimetypeIcon = "";
            var notesNotifierIcon = "";

            //if we've got the specialIcon configured, grab it here so it can be to the right of the mimeType.
            var specialIconLink = TableView.getPotentialIcon(iconConfig, dataContext, columnDef.id);
            var defaultIcons = TableView.getDefaultIcons(dataContext);
            
            //the LinkFormatter gets an OCO passed in because it needs the objectId, ocjectType and properties - create a fake OCO to pass in
            var fakeOco = new Backbone.Model({
                "objectType": type,
                "objectId": dataContext.objectId,
                "objectName": dataContext.objectName,
                "properties": dataContext
            });

            if (TableView.searchConfig.get("showMimeIcon") && TableView.searchConfig.get("showMimeIcon").indexOf("true") != -1) {
                mimetypeIcon = "<img src='" + TableView.getMimeTypeIcon(dataContext, columnDef.isContainer) + "' " + "class='mimetype-icon'" + " />";
            }

            // Get the value that we will make visible
            var visibleValue = value;

            var linkElement = LinkFormatter.getLinkElement(fakeOco, visibleValue, columnDef.resolver, columnDef.externalLink, value);

            if (columnDef.hasDocNotesIndicatorAttr && TableView.searchConfig.get("docIndicatorAttribute").attr !== "") {
                // default the icon to the dull icon meaning there are no notes
                notesNotifierIcon = "<span class='glyphicon glyphicon glyphicon-list-alt doesntHaveNotes'></span>";
                if (dataContext[TableView.searchConfig.get("docIndicatorAttribute").attr] && dataContext[TableView.searchConfig.get("docIndicatorAttribute").attr] === 'true') {
                    notesNotifierIcon = "<span class='glyphicon glyphicon glyphicon-list-alt hasNotes'></span>";
                }
            }
            if ((mimetypeIcon && mimetypeIcon !== "") || (defaultIcons.hasIcon) || (specialIconLink.hasIcon) || (notesNotifierIcon && notesNotifierIcon !== "")) {
                formattedColVal = "<span class='margin-right'>" + mimetypeIcon + notesNotifierIcon + "</span>" + "<span class='link '>" + linkElement + "</span>" + defaultIcons.html + specialIconLink.html;
            } else {
                formattedColVal = "<span class='link '>" + linkElement + "</span>";
            }

            var url = _.findWhere(TableView.urls, { "id": dataContext.objectId });

            if (url && iconConfig.get("showLists")) {
                // if our thumbnail has not been creqted yet, OC will make a request to create it. We need to add the timestamp to the end of our onerror method to prevent the browser from retrieving the non-existant image from the cache
                formattedColVal = formattedColVal + "<img class='tv-tn pull-left tableViewList' src='" + url.thumbnailURL + "'" + "onerror=\"this.onerror=null;setTimeout(this.src=this.src+ '&timeStamp=' + Date.now(), 5000)\" " + "type='image/png'/>";
            }
            //If we are in VAD we want to add a open in dual pane icon.
            if(columnDef.context === HPIConstants.TableView.Context.VAD){
                formattedColVal = formattedColVal + " <span title='" + window.localize("stage.relatedObjects.openInDualPaneView") + "' class='dualpaneIcon glyphicon glyphicon-share' dualPaneObjectId='" + dataContext.objectId + "' ></span>";
            }
        } else if (!columnDef.isLink && iconConfig.get("configuredIcons")) {
            specialIcon = TableView.getPotentialIcon(iconConfig, dataContext, columnDef.id);
            if (specialIcon.hasIcon) {
                //don't show the link if this is a boolean
                var configuredIcon = TableView.configuredIcon(iconConfig, dataContext, columnDef.id);
                _.each(configuredIcon, function(config) {
                    if (_.isBoolean(dataContext[config.checkAttribute])) {
                        formattedColVal = "<span class='margin-right'>" + specialIcon.html + "</span>";
                    } else {
                        formattedColVal = "<span class='margin-right'>" + specialIcon.html + formattedColVal + "</span>";
                    }
                }, this);
            }
        }
        // if this is a repeating version Label, order the results, number first
        if (columnDef.id === 'versionLabel' && _.isArray(value)) {
            value = _.sortBy(value, function(vLabel) {
                // show number values first
                if (_.contains(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], vLabel[0])) {
                    // We return Aaaaa to guarantee that the actual number value comes before any other Version Label
                    return 'Aaaaa';
                }

                // otherwise sort alphabetically
                return vLabel[0];
            });
            //if this is a repeating versionLabel value, we can assume this special case handling is the actual value
            formattedColVal = value;
        }
        //is this a contentSize? have to filter it to the right value here
        if (columnDef.hpiConfig.get("filter") === "contentSize") {
            //changing to the size of this content
            if (dataContext.Document) {
                value = TableView.formatContentSize(dataContext.Document.size);
            } else {
                value = TableView.formatContentSize(value);
            }
            formattedColVal = value;
        }

        if (iconConfig.get("sortRepeatingAttrs") && _.isArray(value) && value.length > 0) {
            value = value.sort();
        }

        return formattedColVal;
    };

    TableView.formatContentSize = function(size) {

        var kb = size / 1024.0;
        var mb = ((size / 1024.0) / 1024.0);
        var gb = (((size / 1024.0) / 1024.0) / 1024.0);
        var tb = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);

        if (tb > 1) {
            tb = tb.toFixed(2);
            tb += " TB";
            return tb;
        } else if (gb > 1) {
            gb = gb.toFixed(2);
            gb += " GB";
            return gb;
        } else if (mb > 1) {
            mb = mb.toFixed(2);
            mb += " MB";
            return mb;
        } else if (kb > 1) {
            kb = kb.toFixed(2);
            kb += " KB";
            return kb;
        } else {
            size += " Bytes";
        }

        return size;
    };

    TableView.getIconConfig = function(typeLink) {
        if (!this.retVal) {
            this.retVal = TableView.searchConfig.get('types').findWhere({ 'objectType': typeLink });
            return this.retVal;
        } else {
            return this.retVal;
        }

    };

    TableView.configuredIcon = function(iconConfig, dataContext, id) {
        return _.filter(iconConfig.get("configuredIcons"), function(config) {
            return config.attributeWithIcon === id;
        });
    };

    TableView.getPotentialIcon = function(iconConfig, dataContext, id) {
        var iconMarkup = '';
        var iconMetadata = {
            'html': '',
            'hasIcon': false,
            'iconCount': 0
        };
        var iconCount = 0;
        //something may have an icon configured but fail the truth test - booleans are a good example
        var configuredIcon = TableView.configuredIcon(iconConfig, dataContext, id);
        //only move on if the configuredIcon is not an empty array
        if (configuredIcon && !_.isEmpty(configuredIcon)) {
            iconMetadata.hasIcon = true;
            _.each(configuredIcon, function(config) {

                if (!_.has(dataContext, config.checkAttribute) || _.isNull(dataContext[config.checkAttribute])) {
                    return;
                }

                //We want to make a temporary value for each incase they have different metadata
                var configValueToCheck = config.valueToCheck;
                var tempHoverText = config.hoverText;

                //We are going to tokenize the value to check
                if (configValueToCheck && configValueToCheck.indexOf("$") > -1) {
                    configValueToCheck = TableView._tokenResolve(configValueToCheck, dataContext);
                }

                //Now we are going to similarly replace all the tokens in the hover text
                if (tempHoverText && tempHoverText.indexOf("$") > -1) {
                    var parts = tempHoverText.split(/(\$\S+?\S+)/g).map(function(value) {
                        return TableView._tokenResolve(value, dataContext);
                    });
                    tempHoverText = parts.join("");
                }

                //Handle different data types (boolean, string, number)
                //Expect numbers for less/greater than comparisons, strings for match, and strings/booleans for every other type
                var dataTypeValid = true;

                var dataValueToCheck = dataContext[config.checkAttribute];
                if (_.contains(['lessThan', 'lessThanOrEqual', 'greaterThan', 'greaterThanOrEqual'], config.typeOfComparison)) {
                    if (isNaN(dataValueToCheck) || isNaN(configValueToCheck)) {
                        dataTypeValid = false;
                    }
                    dataValueToCheck = parseInt(dataValueToCheck);
                    configValueToCheck = parseInt(configValueToCheck);
                } else if (config.typeOfComparison !== 'match' && _.isBoolean(dataValueToCheck)) {
                    if (BooleanUtils.isTruthy(configValueToCheck)) {
                        configValueToCheck = true;
                    } else if (BooleanUtils.isFalsey(configValueToCheck)) {
                        configValueToCheck = false;
                    } else {
                        dataTypeValid = false;
                    }
                } else {
                    dataValueToCheck = dataValueToCheck.toString();
                    configValueToCheck = configValueToCheck.toString();
                }

                if (!dataTypeValid) {
                    return;
                } 
                if ( 
                    (config.typeOfComparison === 'equal' && configValueToCheck === dataValueToCheck) ||
                    (config.typeOfComparison === 'match' && dataValueToCheck.match(configValueToCheck)) ||
                    (config.typeOfComparison === 'exist' && dataValueToCheck.length > 0) ||
                    (config.typeOfComparison === 'lessThan' && dataValueToCheck < configValueToCheck) ||
                    (config.typeOfComparison === 'greaterThan' && dataValueToCheck > configValueToCheck) ||
                    (config.typeOfComparison === 'lessThanOrEqual' && dataValueToCheck <= configValueToCheck) ||
                    (config.typeOfComparison === 'greaterThanOrEqual' && dataValueToCheck >= configValueToCheck)
                    ) {
                    var icon = config.customIcon ? config.customIcon : config.defaultIcon;
                    iconCount ++;
                    if (iconMarkup.length > 0) {
                        var iconClassHtml = '<span class="specialIcon glyphicons glyphicons-';
                        iconClassHtml += icon;
                        if (config.hoverText) {
                            iconClassHtml += '" title="' + tempHoverText + '"';
                        } else {
                            iconClassHtml += '"';
                        }
                        iconClassHtml += "></span>";

                        iconMarkup = iconMarkup.concat(iconClassHtml);
                    } else {
                        iconMarkup = '<span class="specialIcon glyphicons glyphicons-';
                        iconMarkup += icon;
                        if (tempHoverText) {
                            iconMarkup += '" title="' + tempHoverText + '"';
                        } else {
                            iconMarkup += '"';
                        }
                        iconMarkup += "></span>";
                    }

                }
            });
        }
        iconMetadata.html = iconMarkup;
        iconMetadata.iconCount = iconCount;
        return iconMetadata;
    };

    TableView.getDefaultIcons = function(dataContext){
        var iconMarkup = '';
        var iconMetadata = {
            'html': '',
            'hasIcon': false,
            'iconCount': 0
        };
        var PROP_HPI_REDACTED = "hpiIsRedacted";
        var PROP_HPI_DOC_NOTE = "hpiHasDocNote";
        var PROP_HPI_ANNOTATED = "hpiIsAnnotated";
        var PROP_HPI_ISINWORKFLOW = "hpiIsInWorkflow";
        var iconCount = 0;
        

        if(dataContext[PROP_HPI_ANNOTATED] || dataContext[PROP_HPI_DOC_NOTE] || dataContext[PROP_HPI_ISINWORKFLOW] || dataContext[PROP_HPI_REDACTED]){
            iconMetadata.hasIcon = true;

            if(dataContext[PROP_HPI_ANNOTATED]){
                iconMarkup = TableView.processDefaultIconsHtml(iconMarkup,'comments',window.localize("customConfig.viewAllDocumentsConfig.showIfDocumentIsAnnotated.hovertext"));
                iconCount ++;
            }
            if(dataContext[PROP_HPI_DOC_NOTE]){
                iconMarkup = TableView.processDefaultIconsHtml(iconMarkup,'pencil',window.localize("customConfig.viewAllDocumentsConfig.showIfDocumentHasNotes.hovertext"));
                iconCount ++;
            }
            if(dataContext[PROP_HPI_REDACTED]){
                iconMarkup = TableView.processDefaultIconsHtml(iconMarkup,'exclamation-sign',window.localize("customConfig.viewAllDocumentsConfig.showIfDocumentIsRedacted.hovertext"));
                iconCount ++;              
            }
            if(dataContext[PROP_HPI_ISINWORKFLOW]){
                iconMarkup = TableView.processDefaultIconsHtml(iconMarkup,'refresh',window.localize("customConfig.viewAllDocumentsConfig.showIfDocumentInWorkflow.hovertext"));
                iconCount ++;
            }
            iconMetadata.html = iconMarkup;
            iconMetadata.iconCount = iconCount;
        }

        return iconMetadata;
    };

    // Function to get the width of the text with our current settings
    TableView.getTextWidth = function(text, font){
        // re-use canvas object for better performance
        var canvas = TableView.getTextWidth._canvas || (TableView.getTextWidth._canvas = document.createElement("canvas"));
        var context = canvas.getContext("2d");
        context.font = font;
        var metrics = context.measureText(text);
        return metrics.width;
    };

    TableView.processDefaultIconsHtml = function(iconMarkup, icon, tempHoverText){
        if(iconMarkup.length > 0){
            var iconClassHtml = '<span class="specialIcon glyphicons glyphicons-';
            iconClassHtml += icon;
            if (tempHoverText) {
                iconClassHtml += '" title="' + tempHoverText + '"';
            } else {
                iconClassHtml += '"';
            }
            iconClassHtml += "></span>";
            iconMarkup = iconMarkup.concat(iconClassHtml);
            
        }
        else {
            iconMarkup = '<span class="specialIcon glyphicons glyphicons-';
            iconMarkup+=icon;
            if (tempHoverText) {
                iconMarkup += '" title="' + tempHoverText + '"';
            } else {
                iconMarkup += '"';
            }
            iconMarkup += "></span>";
        }

        return iconMarkup;
    };
    
    TableView._tokenResolve = function(value, dataContext) {
        if (value === '$date') {
            return new Date();
        } else if (value === "$user.loginName") {
            return app.user.get("loginName");
        } else if (value === "$user.displayName") {
            return app.user.get("displayName");
        } else if (value.indexOf("$") > -1 && dataContext[value.replace("$", "")]) {
            //This is the case that we send an arbitrary $ column with the oco
            return dataContext[value.replace("$", "")];
        } else {
            return value;
        }
    };

    TableView.getMimeTypeIcon = function(model, isContainer) {
        this.relatedObjectType = model.objectTypeReadOnly;

        var iconImageLocation = "assets/css/styles/img/icons/unknown.svg";

        //sometimes, we lose the mimeType when we refesh by clicking another document on the
        //stage. if this is the case, regrab it from the properties if it is a document
        if (!model.mimeType && model.Document) {
            if (model.Document instanceof Object) {
                model.mimeType = model.Document.mimetype;
            } else {
                model.mimeType = model.Document;
            }
        }
        var contentType = model.mimeType;

        // if mimetype is null it's a folder, if it matches get the image. If neither set to unknown
        if (isContainer === "true") {
            // if mimetype is null it's a folder
            iconImageLocation = "assets/css/styles/img/folder.svg";
        } else {
            var contentTypeConfig = app.context.getContentTypeConfigByMimiType(contentType);

            // if we've got a configuration set up for this mimeType, set the icon, otherwise we'll use the default
            if (contentTypeConfig) {
                iconImageLocation = contentTypeConfig.iconPath;
            }
        }
        return iconImageLocation;

    };

    // Default View.
    TableView.Views.Layout = Backbone.Layout.extend({
        template: "search/tableview",
        className: "table-view",
        events: function() {
            var events = {};
            events['click #quickSearch'] = 'openQuickSearch';
            events['click #columnChooser-' + this.cid] = 'contextMenu';
            events['click #closeTopPanel' + this.cid] = 'closePanel';
            events['click #selectAll-' + this.cid] = 'selectAll';
            events['click #exportAllResultsViaEmail-' + this.cid] = 'exportAllResultsViaEmail';

            return events;
        },
        initialize: function() {
            this.name = "table-view";
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.applyDefaults();
            this.context = this.options.context;
            this.isFirstRender = true;

			// if we are using configs set configs on the tableview and check to see if we are using facets.
			// otherwise ignore setting those configs and turn off facets
            if (this.searchResultsViewController.useConfigs) {
                TableView.searchConfig = this.getSearchConfig();
                TableView.searchConfigName = app.context.currentSearchConfig() ? "_" + app.context.currentSearchConfig().get("name") : "";
                this.keepFilter = this.options.searchResults.get("sidebarConfig") ? this.options.searchResults.get("sidebarConfig").get("keepFilter") : false;
            } else {
                this.keepFilter = false;
            }

            TableView.viewType = this.options.viewType;
            // this is only true when launching directly into thumbnail view in View All Docs
            this.isThumbnailViewOn = this.options.isThumbnailViewOn;
            this.isListViewOn = this.options.isListViewOn;

            this._applyListeners();
            this.switchingToThumbnailView = false;
            this.switchingToListView = false;

            this.appConfig = app.context.currentApplicationConfig();

            if (!this.collection.fullCollection) {
                this.collection.fullCollection = new Backbone.Collection(this.collection.models);
            } 

            if(this.searchResultsViewController.useConfigs) {
                // these functions rely on configs and should be skipped if not using configs
                this._debouncedOnHeaderChange = _.bind( _.debounce(this._onHeaderChangeHandler, 100), this);
                this._debouncedOnAutoSize = _.bind( _.debounce(this._onAutoSizeHandler, 100), this);
            }

            this.ocos = this.collection.models;
            var self = this;

            this.objType = this.ocos[0] ? this.ocos[0].get('objectType') : null;
            // Using a find so that we can break out of the loop if we want to retrieve thumbnails
            if (this.searchResultsViewController.useConfigs) {
                var retrieveLists = _.find(this.searchResults.get('resultsConfig').get('resultsTableConfig').get('types').models, function(conf) {
                    if (self.objType === conf.get("objectType") && conf.get("showLists")) {
                        return conf;
                    }
                });
                if (retrieveLists) {
                    self.retrieveLists();
                }
            }
        },

        /*
         * This let's anyone who cares (searchresultcontrols) know when
         * the columns change. It's debounced so that it's called once per
         * header render, not header cell render
         */
        _onHeaderChangeHandler: function(e, args) {
            var that = this;
            var headers = _.pluck(args.grid.getColumns(), "field");
            var headerLabels = _.pluck(args.grid.getColumns(), "name");

            var visibleColumns = headers.slice(0);
            //remove the first column (it's the checkboxes)
            headerLabels.slice(0);
            headers.shift();
            headerLabels.shift();
            this.searchResultsViewController.tableEventsRef.trigger("search:currentlyDisplayedFields", headers, headerLabels);
            //ensures that we have args and args.grid prior to rendering and invalidating rows
            if(args && args.grid){
                app.context.configService.getUserPreferences(function(currentUserPreferences) {
                    var prefs = currentUserPreferences.get("searchResultsTableview");
                    var queryType;
                    var config = that.getSearchConfig();
                    if (that.collection.queryParams.oc_type !== undefined) {
                        queryType = that.collection.queryParams.oc_type[0];
                    } else {
                        // IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
                        // we're still going to assume a collection is one type such as a parent type
                        // NOTE THIS MEANS IF A CLIENT WANTS MULTIPLE TYPES IT WILL NEED TO BE IMPLEMENTED
                        queryType = config.get("types").models[0].attributes.objectType + "-collection";
                    }
        
                    //setup column widths
                    var columnWidths = _.map(args.grid.getColumns(), function(column) {
                        //use column width default set in config-project
                        return {
                            'id': column.id,
                            'width': column.width,
                            'defaultWidth': column.defaultWidth
                        };
                    }, this);
        
                    //for context menu and streamability, check if configs are true and object is streamable
                    this.models = that.getSearchConfig().get("types").models;
                    var streamableObject = _.find(this.models, function(model) {
                        //This way we queryType[0] will hold just the type, in case -collection was added
                        return model.get("objectType") === queryType.split("-")[0];
                    });

                    if (streamableObject && streamableObject.get("showLists") === true) {
                        that.showLists = true;
                    } else {
                        that.showLists = false;
                    }
        
                    //if cookie doesn't exist, create new cookie
                    if (!prefs) {
                        prefs = {};
                    }
                    //If doctype/trac isn't configured yet for the cookie, create it
                    if (!prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName]) {
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName] = {};
                    }
                    if (!prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns) {
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns = {};
        
                    }
        
                    if (prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns) {
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths = {};
        
                    }
        
                    var foundDiff = false;
                    //lets see if we have a difference in selected columns
        
                    var i = 0;
                    for (i = 0; i < columnWidths.length; i++) {
                        //here we go!
                        if (!prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths[i] || prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths[i].id !== columnWidths[i].id) {
                            //diff id aka diff order.
                            foundDiff = true;
                            //ending this loop
                            i = prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].length;
                        }
                        if (!prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths[i] || prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths[i].width !== columnWidths[i].width) {
                            //diff id aka diff order.
                            foundDiff = true;
                            //ending this loop
                            i = prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].length;
                        }
                    }
        
        
        
        
                    if (foundDiff && that.searchResultsViewController.saveUserPrefs){
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths = columnWidths;
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns = visibleColumns;
                        currentUserPreferences.set("searchResultsTableview", prefs);
                        currentUserPreferences.save({ version: false }, { global: false });
                    }
        
                });
                // these two calls ensures that when columns are resized, icons don't disappear
                args.grid.invalidateAllRows();
                args.grid.render();
            }
            
        }, 

        
        repeatingComparer: function(x, y) {
            //first, sort the date array values in ascending order
            var xValArray = x.get("properties")[this.sortcol];
            var yValArray = y.get("properties")[this.sortcol];
            var rank;

            if (xValArray && yValArray && xValArray.length > 0 && yValArray.length > 0) {

                var xSortedArray = _.sortBy(xValArray, function(attr) {
                    if (_.isString(attr)) {
                        return attr.toLowerCase();
                    } else {
                        return attr;
                    }
                });

                var ySortedArray = _.sortBy(yValArray, function(attr) {
                    if (_.isString(attr)) {
                        return attr.toLowerCase();
                    } else {
                        return attr;
                    }
                });

                var compareValX = xSortedArray[0],
                    compareValY = ySortedArray[0];
                if (_.isString(compareValX)) {
                    compareValX = compareValX.toLowerCase();
                }
                if (_.isString(compareValY)) {
                    compareValY = compareValY.toLowerCase();
                }

                //now, compare the first repeating of each x and y
                if (compareValX > compareValY) {
                    rank = 1;
                } else if (compareValY > compareValX) {
                    rank = -1;
                } else {
                    rank = 0;
                }

            } else if (xValArray && xValArray.length > 0) {
                rank = -1;
            } else if (yValArray && yValArray.length > 0) {
                rank = 1;
            } else {
                rank = 0;
            }

            if(rank === 0) {
                // since these items have the same rank, compare the configured object title (ocName) to maintain a consistent order
                if(this.secondarySearchAttr) {
                    var xVal = x.get("properties")[this.secondarySearchAttr];
                    var yVal = y.get("properties")[this.secondarySearchAttr];

                    if(xVal && yVal) {
                        rank = xVal > yVal ? 1 : -1;
                    } else if(!xVal) {
                        rank = -1;
                    } else if (!yVal) {
                        rank = 1;
                    }
                } else {
                    // we still don't want the rank to equal 0
                    rank = 1;
                }
             }

             return rank;
        },

        comparer: function(x, y) {
            if (_.isArray(x.get("properties")[this.sortcol]) || _.isArray(y.get("properties")[this.sortcol]) ) {
                return this.repeatingComparer(x, y);
            }
            var compareValX = x.get("properties")[this.sortcol],
                compareValY = y.get("properties")[this.sortcol]; 
            
            if (_.isString(compareValX)) {
                compareValX = compareValX.toLowerCase();
            }
            if (_.isString(compareValY)) {
                compareValY = compareValY.toLowerCase();
            }
            if (this.sortcol === "Document") {
                //we're sorting on contentSize
                compareValX = compareValX.size;
                compareValY = compareValY.size;
            }

            var rank;

            // Flipping the logic causing the null values in a table 
            // to go to the bottom when sorting ascending. Mirrors excel.
            if (compareValX === compareValY) {
                rank = 0;
            } else if (compareValX && compareValY) {
                rank = compareValX > compareValY ? 1 : -1;
            } else if (!compareValX && compareValY) {
                rank = 1;
            } else if (compareValX && !compareValY) {
                rank = -1;
            }


            if(rank === 0) {
                 // since these items have the same rank, compare the configured object title (ocName) to maintain a consistent order
                 if(this.secondarySearchAttr) {
                    var xVal = x.get("properties")[this.secondarySearchAttr];
                    var yVal = y.get("properties")[this.secondarySearchAttr];

                    if(xVal && yVal) {
                        rank = xVal > yVal ? 1 : -1;
                    } else if(!xVal) {
                        rank = 1;
                    } else if (!yVal) {
                        rank = -1;
                    }
                } else {
                    // we still don't want the rank to equal 0
                    rank = 1;
                }
             }

             return rank;
        },

        repeatingDateComparer: function(x, y) {
            //first, sort the date array values in ascending order
            var xValArray = x.get("properties")[this.sortcol];
            var yValArray = y.get("properties")[this.sortcol];
            var rank;

            if (xValArray && yValArray && xValArray.length > 0 && yValArray.length > 0) {
                var xDateArray = [];
                var yDateArray = [];

                _.each(xValArray, function(dateString) {
                    if (_.isString(dateString)) {
                        if (dateString.indexOf(":") > -1) {
                            xDateArray.push(moment(dateString, this.appConfig.get("dateFormat") + " " + this.appConfig.get("timeFormat")).toDate().getTime());
                        } else {
                            xDateArray.push(moment(dateString, this.appConfig.get("dateFormat")).toDate().getTime());
                        }
                    } else {
                        xDateArray.push(dateString);
                    }
                });

                _.each(yValArray, function(dateString) {
                    if (_.isString(dateString)) {
                        if (dateString.indexOf(":") > -1) {
                            yDateArray.push(moment(dateString, this.appConfig.get("dateFormat") + " " + this.appConfig.get("timeFormat")).toDate().getTime());
                        } else {
                            yDateArray.push(moment(dateString, this.appConfig.get("dateFormat")).toDate().getTime());
                        }
                    } else {
                        yDateArray.push(dateString);
                    }
                });

                xDateArray = _.sortBy(xDateArray, function(date) { return date; });
                yDateArray = _.sortBy(yDateArray, function(date) { return date; });

                //now, compare the first date of each x and y
                if (xDateArray[0] > yDateArray[0]) {
                    rank = 1;
                } else if (yDateArray[0] > xDateArray[0]) {
                    rank = -1;
                } else {
                    rank = 0;
                }

            } else if (xValArray && xValArray.length > 0) {
                rank = 1;
            } else if (yValArray && yValArray.length > 0) {
                rank = -1;
            } else {
                rank = 0;
            }

            if(rank === 0) {
                // since these items have the same rank, compare the configured object title (ocName) to maintain a consistent order
                if(this.secondarySearchAttr) {
                    var xVal = x.get("properties")[this.secondarySearchAttr];
                    var yVal = y.get("properties")[this.secondarySearchAttr];

                    if(xVal && yVal) {
                        rank = xVal > yVal ? 1 : -1;
                    } else if(!xVal) {
                        rank = -1;
                    } else if (!yVal) {
                        rank = 1;
                    }
                } else {
                    // we still don't want the rank to equal 0
                    rank = 1;
                }
            }

            return rank;
        },

        dateComparer: function(x, y) {
            if (_.isArray(x.get("properties")[this.sortcol])) {
                return this.repeatingDateComparer(x, y);
            }

            var xValue = x.get("properties")[this.sortcol];
            var yValue = y.get("properties")[this.sortcol];

            var hasTime = false;
            if (xValue && _.isString(xValue)) {
                if (xValue.indexOf(":") > -1) {
                    hasTime = true;
                }
            }
            if (yValue && _.isString(yValue)) {
                if (yValue.indexOf(":") > -1) {
                    hasTime = true;
                }
            }
            if (xValue && yValue) {
                var leftSortAttrVal, rightSortAttrVal;

                if (hasTime) {
                    leftSortAttrVal = moment(xValue, this.appConfig.get("dateFormat") + " " + this.appConfig.get("timeFormat")).toDate().getTime();
                    rightSortAttrVal = moment(yValue, this.appConfig.get("dateFormat") + " " + this.appConfig.get("timeFormat")).toDate().getTime();
                } else {
                    if (_.isString(xValue)) {
                        leftSortAttrVal = moment(xValue, this.appConfig.get("dateFormat")).toDate().getTime();
                    } else {
                        leftSortAttrVal = xValue;
                    }
                    if (_.isString(yValue)) {
                        rightSortAttrVal = moment(yValue, this.appConfig.get("dateFormat")).toDate().getTime();
                    } else {
                        rightSortAttrVal = yValue;
                    }
                }

                var rank = leftSortAttrVal === rightSortAttrVal ? 0 : (leftSortAttrVal > rightSortAttrVal ? 1 : -1);

                if(rank === 0) {
                    // since these items have the same rank, compare the configured object title (ocName) to maintain a consistent order
                    if(this.secondarySearchAttr) {
                        var xVal = x.get("properties")[this.secondarySearchAttr];
                        var yVal = y.get("properties")[this.secondarySearchAttr];

                        if(xVal && yVal) {
                            rank = xVal > yVal ? 1 : -1;
                        } else if(!xVal) {
                            rank = -1;
                        } else if (!yVal) {
                            rank = 1;
                        }
                    } else {
                        // we still don't want the rank to equal 0
                        rank = 1;
                    }
                }

                return rank;
            } else if (!xValue) {
                return 1;
            } else {
                return -1;
            }
        },

        //save preferences for force fit
        _onAutoSizeHandler: function(e, args) {
            var that = this;
            if (args && args.grid) {
                var forcedFit = args.grid.getOptions().forceFitColumns;
                app.context.configService.getUserPreferences(_.bind(function(currentUserPreferences) {
                    var prefs = currentUserPreferences.get("searchResultsTableview");
                    var queryType;
                    var config = that.getSearchConfig();
                    if (that.collection.queryParams.oc_type !== undefined) {
                        queryType = that.collection.queryParams.oc_type[0];
                    } else {
                        // IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
                        // we're still going to assume a collection is one type such as a parent type
                        // NOTE THIS MEANS IF A CLIENT WANTS MULTIPLE TYPES IT WILL NEED TO BE IMPLEMENTED
                        queryType = config.get("types").models[0].attributes.objectType + "-collection";
                    }

                    // if cookie doesn't exist, create a new cookie
                    if (!prefs) {
                        prefs = {};
                    }
                    //If doctype/trac isn't configured yet for the cookie, create it
                    if (!prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName]) {
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName] = {};
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns = {};
                    }
                    if(!(($("#pane3").is(':visible') && $("#pane1").is(':visible')) && TableView.searchConfig.get("enableDualPaneForceFit") === false)){
                        prefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].isForceFit = forcedFit;
                     }
                     if(that.searchResultsViewController.saveUserPrefs){
                        currentUserPreferences.set("searchResultsTableview", prefs);
                    }
                }, that));
            }
        },

        //Custom method to apply default values to the searchResultsViewController
        //A custom method is needed because underscores extend does not do a deep copy
        //and JQueries extend does a merge. The searchResultsViewController cannot lose its
        //original reference
        applyDefaults: function(){
            var defaults = {
                plugins: [HPIConstants.TableView.Plugins.CheckboxColumn],
                saveUserPrefs : true,
                sortable: true,
                rowSelection: true,
                disableRightClickMenu: false,
                enableColumnPicker: true
            };
            _.each(Object.keys(defaults), function(key){
                if(!(key in this.searchResultsViewController)){
                    this.searchResultsViewController[key] = defaults[key];
                }
            }, this);
        },
        _searchSwitchingToThumbnailView: function() {
            this.switchingToThumbnailView = true;

            //If leaving standardized table view
            if(app.searchView === HPIConstants.TableView.ViewType.StandardTableView){
                //Resetting the page number and selected documents before going to thumbnail view since we don't want to retain any of this information
                this.searchResultsViewController.grid.getData().setPagingOptions({pageNum : 0});
                this.searchResultsViewController.tableEventsRef.trigger("search:selectedResults", []);
            }
        },
        _searchSwitchingToListView: function() {
            this.switchingToListView = true;

            //If leaving standardized table view
            if(app.searchView === HPIConstants.TableView.ViewType.StandardTableView){
                //Resetting the page number and selected documents before going to list view since we don't want to retain any of this information
                this.searchResultsViewController.grid.getData().setPagingOptions({pageNum : 0});
                this.searchResultsViewController.tableEventsRef.trigger("search:selectedResults", []);
            }
        },
        _searchSwitchingToTableView: function() {
            //If leaving standardized table view 
            if(app.searchView === HPIConstants.TableView.ViewType.StandardTableView){
                // Resetting the grid so that the selected documents and page numbers do not persist when generating std view
                this.searchResultsViewController.resetGrid();
            }
        },
        _gridClickHandler: function(evt, args){
            //Check to see if the column clicked was a link column
            if(this.grid.getColumns()[args.cell].isLink){
                var gridItem = this.grid.getData().getItem(args.row);

                if(this.resolver === 'stream')
                {
                    //log stream content with the objectId off the model var 
                    LogstashService.sendMetrics(
                        new LogstashService.PerformanceLog({
                            'eventTitle': HPIConstants.Logging.Events.StreamContent,
                            'objectId': gridItem.objectId
                        })
                    );
                        }
                }
        },
        _textFilterChange: function(textFilter) {
            //Resetting selected rows every time a text filter is applied                    
            this.grid.setSelectedRows([]);

            var filterArgs = {};                    
            filterArgs.text = textFilter.trim();

            //The text argument passed to the filter.
            var data = this.grid.getData();

            data.setFilterArgs(filterArgs);

            //Refreshing the data based on the filter.
            this.dataView.refresh();
            this.searchResultsViewController.tableEventsRef.trigger('filter:collection', this.collection);

            // When you perform a text search which returns no results and then add facets, the items are removed from grid object.
            // So to reset items we must update results from the facets. 
            if(data.getItems().length === 0){
                this.searchResultsViewController.tableEventsRef.trigger("search:updateFacetResults");
            }
        },
        _applyListeners: function() {
            this.stopListening();
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:deleteObjects", function(items) {
                _.each(items, function(item){
                    this.collection.remove(_.findWhere(this.collection.models, { "id": item }));
                }, this);
                this.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
                this.searchResultsViewController.tableEventsRef.trigger('filter:collection', this.collection);
                app.trigger("stage:resizePanes");
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "tableview:columnHeaderResize", this.columnHeaderResize);
            //This needs to be on app, This allows stage to calll all tableviews when resizing the page
            this.listenTo(app, "tableview:columnHeaderResize", this.columnHeaderResize);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "resultsHaveMutated tableview:tableAfterGridSetupDone", function() {
                //Our collection need all of the models now (i.e. the fullCollection
                //models).
                this.collection.reset(this.collection.fullCollection.models);
                this._reloadResults(this.collection);
                this.grid.getData().setPagingOptions({
                    pageSize:  this.searchResultsViewController.resultsPerPage
                });
            }, this);

            //setup action listeners for this layout:
            this.listenTo(this.searchResultsViewController.tableEventsRef, 'action:object-modified',  this._modified);

            this.listenTo(app, 'action:bulkProperties-objects-modified', this._modified);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:removeAllChecked", this.removeAllChecked);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:checkAllResults", function() {
                var rows = [];
                for (var i = 0; i < this.grid.getDataLength(); i++) {
                    rows.push(i);
                }
                this.grid.setSelectedRows(rows);
            }, this);

            // listen to get available and visable attributes that actions might need to use
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:currentlyDisplayedFields", function(attrs, attrLabels) {
                this.visibleAttrs = attrs;
                this.visibleAttrLabels = attrLabels;
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:switching-to-thumbnail-view", this._searchSwitchingToThumbnailView);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:switching-to-list-view", this._searchSwitchingToListView);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:switching-to-table-view", this._searchSwitchingToTableView);

            //These triggers manually click these elements because the slick.pager.js class sets up a listener
            // on click for them. This will trigger the pagination controls in slick grid
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:paginationControl:next", function(){
               this.$(".ui-icon-seek-next").trigger('click');
            }, this);
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:paginationControl:prev", function(){
               this.$(".ui-icon-seek-prev").trigger('click');
            }, this);

            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:results:text:filter:change", this._textFilterChange); 

            //apply collection listeners for the passed-in collection
            this._applyCollectionListeners();
        },
        _applyCollectionListeners: function() {
            // listen for query object changes and reload the data on new searchs or manual resets:
            // listen for filtering as well as this happens client-side
            // tableview might not be ready yet - check if we're created _reloadResults yet
            this.listenTo(this.collection, 'query:complete', this.queryCompleteHandler);
        },
        _modified: function(args){
            // This function can handle one or multiple documents being modified
            var modifiedOcos = args.newOcos ? args.newOcos.models : args.newOco;
            this.collection.set(modifiedOcos, {silent:true, remove:false});
            this.collection.reset(this.collection.models);
            this.searchResultsViewController.tableEventsRef.trigger('resultsHaveMutated');
        },
        removeAllChecked: function() {
            // If you don't reset the id to oco map first, the setSelectedRows picks up previous selections (aka doesn't rm them)
            this.grid.setSelectedObjects([]);
            this.grid.setSelectedRows([]);
        },
        queryCompleteHandler: function(collection, options) {
            this._reloadResults(this.collection);
            // Clearing out text filter when a new search is performed or when we are not in Tableview
            if((!options.sorting) || app.searchView === HPIConstants.TableView.ViewType.ResetTableView || app.searchView === HPIConstants.TableView.ViewType.StandardTableView) {
                // Once in Reset Tableview set searchView back to Tableview when clearing the text filter. 
                //** We update searchView from reset table view to table view here because this is the last place that Looks for reset table view, 
                //** and making this switch in table views after render can cause a race condition where the filters dont get cleared
                if(app.searchView === HPIConstants.TableView.ViewType.ResetTableView){
                    app.searchView = HPIConstants.TableView.ViewType.TableView;
                    TableView.viewType = HPIConstants.TableView.ViewType.TableView;
                }

                this.grid.getData().setFilterArgs("");
                this.searchResultsViewController.textFilter = "";
            }
            this.searchResultsViewController.linkColumnName = this.linkColumnName;
        },
        cleanup: function() {
            this.stopListening();
            //clean off SlickGrid
            this.removeView("#myGrid-" + this.cid);
            //clean up listening on body but it makes sure not to do so when moving to thumbnail view since we need to listen on body to close popover when clicking outisde it 
            //it will stop listening when switching to thumbnail view in search context but that should not cause problems since the popover never appears in that context
            if(!this.switchingToThumbnailView && !this.switchingToListView){
                $("body").off();
            }
            // dispose the dataview to get rid of any lingering subscribers
            if (this.dataView) {
                this.dataView.dispose();
            }
            if(this.grid){
                this.grid.destroy();
            }
            $(window).off('scroll', this.handleScrolling);
        },
        onClickStageLink: function(evt, args) {
            //We use 'href' when we are in search results, and 'objectId' when we are in the stage (no refresh in stage)
            var objectId = this.$(evt.target).attr('href') || this.$(evt.target).attr('objectId');
            //This will end up getting tied to the slick grid and if we have the second pane id
            var dualPaneObjectId = this.$(evt.target).attr('dualPaneObjectId');

            // only if the user clicked on the doc link or dual pane icon
            if(objectId || dualPaneObjectId) {
                var self = this;
                // temporarily killing this listener so we don't reloadResults with every stage trigger
                this.stopListening(this.searchResultsViewController.tableEventsRef, "resultsHaveMutated tableview:tableAfterGridSetupDone");

                // only fire if we clicked on the link - not a checkbox or other SlickGrid area
                if (objectId && this.resolver !== "stream") {
                    app.trigger("stage.refresh.documentId", objectId);
                    if (self.options.config.get('handler') === "rightSideActionHandler") {
                        app.trigger("stage.refresh.showPane3", true);
                        //don't hide the left bar unless in a large view
                        //the left bar will go to the top for small views
                        if (window.innerWidth > 991) {
                            app.trigger("toggleLeftBar", false);
                        }
                        self.paneSize = "rightPane";
                    } else if (self.options.config.get('handler') === "modalActionHandler") {
                        app.trigger("toggleLeftBar", true);
                        app[self.options.config.get("handler")].trigger("hide");
                    }
                } else if(evt.target.type === "checkbox" && args.grid.contextMenuShown) {
                    // hide the contextMenue when selecting a check box
                    $("#contextMenu-" + this.cid).hide();
                    args.grid.contextMenuShown = false;
                }
                
                // we will trigger the dual pane view.
                if(dualPaneObjectId){
                    app.trigger("stage.refresh.documentId2", {
                        objectId: dualPaneObjectId,
                        context: "viewAllDocuments"}
                    );
                }

                // add our listener back
                this.listenTo(this.searchResultsViewController.tableEventsRef, "resultsHaveMutated tableview:tableAfterGridSetupDone", function() {
                    //Our collection need all of the models now (i.e. the fullCollection models).
                    this.collection.reset(this.collection.fullCollection.models);
                    this._reloadResults(this.collection);
                    this.columnHeaderResize();

                    //making sure that the paging is correct.
                    this.grid.getData().setPagingOptions({
                        pageSize: this.searchResultsViewController.resultsPerPage
                    });
                }, this);
            }            
        },
        retrieveThumbnails: function() {
            var that = this;
            this.thumbnails = [];
            TableView.urls = [];
            this.defs = [];
            _.each(this.ocos, function(oco) {
                var def = $.Deferred();
                oco.getThumbnail("medium", function(thumbnailURL) {
                    var id = $.deparam(thumbnailURL.substr(thumbnailURL.indexOf('?') + 1)).objectId;
                    var oco = _.findWhere(that.ocos, { 'id': id });
                    if (oco) {
                        TableView.urls.push({
                            "thumbnailURL": thumbnailURL,
                            "objectName": oco.get("properties").objectName,
                            "id": id
                        });
                    }
                    def.resolve();
                }, this);
                that.defs.push(def);
            });
            $.when.apply(null, this.defs).done(_.bind(function() {
                that.render();
            }));
        },
        retrieveLists: function() {
            var that = this;
            this.lists = [];
            TableView.urls = [];
            this.defs = [];
            _.each(this.ocos, function(oco) {
                var def = $.Deferred();
                oco.getList("medium", function(listURL) {
                    var id = $.deparam(listURL.substr(listURL.indexOf('?') + 1)).objectId;
                    var oco = _.findWhere(that.ocos, { 'id': id });
                    if (oco) {
                        TableView.urls.push({
                            "listURL": listURL,
                            "objectName": oco.get("properties").objectName,
                            "id": id
                        });
                    }
                    def.resolve();
                }, this);
                that.defs.push(def);
            });
            $.when.apply(null, this.defs).done(_.bind(function() {
                that.render();
            }));
        },
        //The filter that is run by SlickGrid.
        //Note: this function gets compiled into a different function - see tsg.dataview.js:compileFilter
        //Be careful - the "compiler" will change any return statements (INCLUDING COMMENTS) into
        //slickgrid specific code. (EX: don't put a comment that says "return true;")
        slickgridFilter: function(item, args, grid) {
            //If we don't have any arguments to filter on, don't bother with this function
            if (!args) {
                return true;
            }

            var text = args.text || "";
            var ret = false;
            var cols = _.pluck(grid.getColumns(), 'field');
            // removing the checkbox column, identified by field "sel", if it exists
            cols = _.without(cols, "sel");
            var prop = "";
            var i;
            if (text) {
                //normal text filtering
                for (i = 0; i < cols.length; i++) {
                    prop = cols[i];
                    //Case insensitive filtering
                    if (item[prop] && item[prop].toString().toLowerCase().indexOf(text.toLowerCase()) > -1) {
                        ret = true;
                    }
                }
                return ret;
            } else {
                //no filter params
                return true;
            }
        },
        _reloadResults: function(newResults) {
            var self = this;
            var tableViewRenderStart = Date.now();
            if (newResults.length < 1 || !newResults.records.get('totalRecords')) {
                $("#tableNoResults-" + self.cid).show();
                $("#tableHolder-" + self.cid).hide();
                // Setting item on the dataView so that pagination is correctly updated for zero results
                if(self.dataView){
                    self.dataView.setItems(newResults, "objectId");      
                }
            } else {
                //If there is only one result, we don't need to traverse
                if (self.context !== HPIConstants.TableView.Context.VAD && self.context !== HPIConstants.TableView.Context.DatabaseTableView) {
                    if (self.collection.models.length > 1) {
                        if (SearchResultTraversal.latestResults.length > 0) {
                            SearchResultTraversal.latestResults = [];
                        }
                        _.each(self.collection.models, function(res) {
                            SearchResultTraversal.latestResults.push(res.id);
                        });

                        window.localStorage.setItem('latestResults', JSON.stringify(SearchResultTraversal.latestResults));
                    }
                    //There is either 1 or 0 result/s --> we want to remove what we have in localStorage
                    else {
                        window.localStorage.removeItem('latestResults');
                    }
                }

                $("#tableNoResults-" + self.cid).hide();
                $("#tableHolder-" + self.cid).show();

                if (!this.searchResultsViewController.useConfigs) {
                    // Add column size to the visible columns
                    self.grid.setColumns(self.searchResultsViewController.visibleColumns);
                    self.grid.setOptions({
                        forceFitColumns: true
                    });

                    // Checking if the window has a page size set and if not, pulls the value set in the admin. 
                    // Sets the page size on the paging options object so that the correct number of results are displayed. 
                    self.searchResultsViewController.determineResultsPerPage().done(function() {

                        // We tried to set this in the afterRender, but it was causing issues with pagination and would lose
                        // the selections from other pages than the last thumbnail view page we were on.  TODO if possible, move
                        self.setSelectedObjectsFromSearchResultsViewController();

                        self.collection.state.pageSize = self.searchResultsViewController.resultsPerPage;
                        //trigger the set items here to ensure that they are appearing on the first search.
                        if(self.collection.records.totalRecords() > 0){
                            self.dataView.setPagingOptions({
                                pageSize: self.collection.state.pageSize,
                                pageNum: self.collection.state.currentPage - 1
                            });

                            self.dataView.setItems(newResults, "objectId"); //set id prop to objectId

                        }
                    });
                    return;
                }
                

                var config = self.getSearchConfig();

                //update the columns
                var columns = [];
                //pull type off the query params
                //? do we want to support queries against multple types?
                var type;
                var queryType;
                if (newResults.queryParams.oc_type !== undefined) {
                    queryType = newResults.queryParams.oc_type[0];
                    
                    type = config.get("types").findWhere({
                        objectType: queryType
                    });
                } else {
                    //IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
                    // for now we are assuming it's just one parent type for collections
                    queryType = config.get("types").models[0].attributes.objectType + "-collection";
                    type = config.get("types").models[0];
                }
                //saving this here to retrieve in list view
                self.searchResultsViewController.queryType = queryType;
                if (!type) {
                    return;
                }

                var standardizedTableViewEnabled = type.get('standardizedTableViewEnabled');
                var standardizedTableView = type.get('standardizedTableView');

                self.resolver = type.get("resolver");

                self.externalLink = type.get("resolverExternalLink");

                //set the columns up with labels TODO more features available here
                app.context.configService.getAdminTypeConfig(type.get("objectType"), function(objectTypeConfig) {
                    columns = [];
                    if(_.contains(self.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.CheckboxColumn)){
                        var checkboxColumn = self.checkboxSelector.getColumnDefinition();
                        columns = [checkboxColumn]; //start with blank table with checkbox column
                    }

                    var sortable = true;
                    if((standardizedTableViewEnabled && standardizedTableView) || !self.searchResultsViewController.sortable){
                        sortable = false;
                    } 

                    _.each(type.get("fields"), function(fieldName) {
                        if (objectTypeConfig) {
                            var attrConfig = objectTypeConfig.get("attrs").findWhere({
                                ocName: fieldName.ocName
                            });
                            var column = {
                                id: fieldName.ocName,
                                name: window.localize(attrConfig.get("label")),
                                field: fieldName.ocName,
                                formatter: TableView.hpiFormatter,
                                sortable: sortable,
                                hpiConfig: attrConfig,
                                resolver: self.resolver,
                                externalLink: self.externalLink,
                                type: type.get("objectType"),
                                context: self.context
                            };
                            if (fieldName.ocName === type.get("title").ocName) {
                                column.isLink = true;
                                column.isContainer = objectTypeConfig.get("isContainer");
                                self.linkColumnName = fieldName.ocName; //this works because we're about to add the column
                                
                                // saving this here to retrieve in list view
                                self.searchResultsViewController.linkColumnName = fieldName.ocName;

                                // check to see if the current doc type has the attribute to show
                                var foundHasDocNotesAttr = _.find(objectTypeConfig.get('attrs').models, function(attr) {
                                    if (config.get('docIndicatorAttribute')) {
                                        return attr.get('ocName') === config.get('docIndicatorAttribute').attr;
                                    }

                                });

                                if (foundHasDocNotesAttr) {
                                    column.hasDocNotesIndicatorAttr = true;
                                }

                            }

                            columns.push(column);
                        } else {
                            //no config for this type, limited display
                            columns.push({
                                id: fieldName.ocName,
                                name: fieldName.ocName,
                                field: fieldName.ocName,
                                sortable: sortable
                            });
                        }
                    });

                    app.context.configService.getUserPreferences(function(currentUserPreferences) {
                        if(!app.searchView){
                            app.searchView="table";
                        }
                        if(standardizedTableView){
                            app.searchView=HPIConstants.TableView.ViewType.StandardTableView;
                        }

                        var columnDefaults = TableView.config[queryType];
                        var userPrefs = currentUserPreferences.get("searchResultsTableview");
                        //Returns user prefered columns
                        var visibleColumns = [];
                        if (!(standardizedTableView ||  TableView.viewType === HPIConstants.TableView.ViewType.ResetTableView) && userPrefs && userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName] && userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns.length > 0) {
                            var uservisibleColumns = userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].selectedColumns;
                            _.each(uservisibleColumns, function(visibleColumn) {
                                var prefColumn = _.find(userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths, function(column) {
                                    return column.id === visibleColumn;
                                });
                                _.each(columns, function(column) {
                                    if (visibleColumn === column.field) {
                                        if (userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].columnWidths) {
                                            if (prefColumn) {
                                                if (prefColumn.defaultWidth === undefined && columnDefaults && columnDefaults.columns[column.id]) {
                                                    column.width = columnDefaults.columns[column.id];
                                                    column.defaultWidth = true;
                                                } else {
                                                    column.width = prefColumn.width;
                                                    column.defaultWidth = false;
                                                }
                                            }
                                        }
                                        visibleColumns.push(column);
                                    }
                                });
                            });
                            // add any configured plugin columns
                            visibleColumns = self._addEnabledPluginColumnsToVisibleColumns(visibleColumns);

                            // Add column size to the visible columns
                            visibleColumns = self._addRowSizeToVisibleColumns(visibleColumns);
                            
                            self.grid.setColumns(visibleColumns);

                            //If no preference, show only visible fields (hidden fields configured)
                        } else if (type.get("fields").length > type.get("visibleFields").length) {
                            var tempVisibleFields = _.pluck(type.get("visibleFields"), 'ocName');
                            visibleColumns = _.filter(columns, function(column) {
                                if (_.indexOf(tempVisibleFields, column.field) !== -1) {
                                    return true;
                                } else {
                                    return false;
                                }
                            });
                            visibleColumns.unshift(columns[0]);
                            self.grid.setColumns(visibleColumns);

                            //If no hidden fields, show all fields
                        } else {
                            self.grid.setColumns(columns);
                        }

                        // set the options to hide the column picker options
                        self.options.hideForceFitOption = config.get('hideForceFitOption');
                        self.options.hideSynchronouResizeOptions = config.get('hideSynchronouResizeOptions');

                        // If the admin has enableDualPaneForceFit configured as false
                        // forceFitColumns will be set to false overriding user prefs / type configs
                        // This is used in the case of too many columns configured in VAD when in dualpane making 
                        // it hard to sort / rearrange / view the text of the columns
                        if ((TableView.searchConfig.get("enableDualPaneForceFit") === false)
                            && ($("#pane3").is(':visible') && $("#pane1").is(':visible')))
                        {
                            // Overriding the hideForceFitOption so that when the column picker options renders
                            // it won't show the option to change the forceFit value while in dualPane
                            self.options.hideForceFitOption = true;
                            var lastForceFitValue = self.grid.getOptions().forceFitColumns;
                            
                            self.grid.setOptions({
                                forceFitColumns: false
                            });
                            
                            // We only need to retrigger resultsHaveMutated if the forceFitValue was changed from true to false.
                            if (lastForceFitValue !== false) {
                                self.searchResultsViewController.tableEventsRef.trigger("resultsHaveMutated");
                            }
                        }
                        //If there are userPrefs of the desired type and the forcefit attribute exists
                        else if (userPrefs && userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName] && typeof userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].isForceFit != "undefined") {
                            if (userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName].isForceFit) {
                                self.grid.setOptions({
                                    forceFitColumns: true
                                });
                                self.grid.autosizeColumns();
                            } else {
                                self.grid.setOptions({
                                    forceFitColumns: false
                                });
                            }
                        }
                        //Else, fall back on the config.
                        else if (type.get("isForceFit") === "true") {
                            self.grid.setOptions({
                                forceFitColumns: true
                            });
                            self.grid.autosizeColumns();
                        } else if (type.get("isForceFit") === "false") {
                            self.grid.setOptions({
                                forceFitColumns: false
                            });
                        }

                        if(!(standardizedTableViewEnabled && standardizedTableView) && self.searchResultsViewController.enableColumnPicker) {
                            new Slick.Controls.ColumnPicker(columns, self.grid, self.options);
                        }
                       
                        var headers = _.pluck(columns, "field");
                        //remove the first column (it's the checkboxes)
                        headers.shift();

                        //on reset tableview, delete current searchResultsTableview user prefs for that trac
                        if (TableView.viewType === HPIConstants.TableView.ViewType.ResetTableView) {
                            delete userPrefs[queryType + '_' + app.context.configName() + TableView.searchConfigName];
                        }

                        //save user prefs if save is turned on or a reset is called
                        if(self.searchResultsViewController.saveUserPrefs || TableView.viewType === HPIConstants.TableView.ViewType.ResetTableView){
                            currentUserPreferences.set("searchResultsTableview", userPrefs);
                        }

                        //loop through each oco and change the object type to the queryType. This fixes
                        //the problem of the first page not loading due to deferreds not resolving.

                        //by splitting on "-" here, we can ensure that even if we are dealing with a collection query, that
                        //queryType[0] will contain the correct type instead of "Document-collection" for example.
                        queryType = queryType.split("-");

                        // This fetches the mimetype, native size, and renditioned
                        // size from the OCO and places it on the properties model
                        _.each(newResults.models, function(oco, index) {
                            oco.set("objectType", queryType[0]);
                            
                            // Set mimetype
                            if (oco.get("mimeType") && !oco.get("properties").mimeType) {
                                oco.get("properties").mimeType = oco.get("mimeType");
                            }

                            // Set native size
                            if (oco.get(HPIConstants.Properties.NativeSize) && !oco.get("properties").nativeSize) {
                                oco.get("properties").nativeSize = oco.get(HPIConstants.Properties.NativeSize);
                            }

                            // Set renditioned size
                            if (oco.get(HPIConstants.Properties.RenditionSize) && !oco.get("properties").renditionSize) {
                                oco.get("properties").renditionSize = oco.get(HPIConstants.Properties.RenditionSize);
                            }

                            oco.get("properties").ordinal = index + 1;

                            //Initialize number of copies for controlledPrint
                            if(_.contains(self.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.NumCopiesColumn)) {
                                oco.get("properties").numCopiesToPrint = 1;
                            }
                        });

                        // Checking if the window has a page size set and if not, pulls the value set in the admin. 
                        // Sets the page size on the paging options object so that the correct number of results are displayed. 
                        self.searchResultsViewController.determineResultsPerPage().done(function() {

                            // We tried to set this in the afterRender, but it was causing issues with pagination and would lose
                            // the selections from other pages than the last thumbnail view page we were on.  TODO if possible, move
                            self.setSelectedObjectsFromSearchResultsViewController();

                            self.collection.state.pageSize = self.searchResultsViewController.resultsPerPage;
                            //trigger the set items here to ensure that they are appearing on the first search.
                            if(self.collection.records.totalRecords() > 0){
                                self.dataView.setPagingOptions({
                                    pageSize: self.collection.state.pageSize,
                                    pageNum: self.collection.state.currentPage - 1
                                });

                                self.dataView.setItems(newResults, "objectId"); //set id prop to objectId

                            }
                        });
                    });
                });
            }

            if(self.collection.searchActuallyExecuted) {

                // save search statistic timings
                var tableViewRenderTimeEnd = Date.now();
                self.collection.totalTime = (tableViewRenderTimeEnd - self.collection.documentInfoStartTime) / 1000.0;
                self.collection.tableViewRenderTime = (tableViewRenderTimeEnd - tableViewRenderStart) / 1000.0;
                self.collection.OCMSTotalTime = self.collection.totalTime - self.collection.ocCallTime - self.collection.networkTime;
                self.collection.formatResultsTime = self.collection.state.formatResultsTime;
                app.trigger("tableViewLoaded");

                // reset our search variable
                self.collection.searchActuallyExecuted = false;
            }
        },
        // called from reloadResults
        _addEnabledPluginColumnsToVisibleColumns: function(visibleColumns) {
            //Plugins that should be at the back
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.OAPageSelectColumn)){
                var oaPageSelectColumnInstance = this.oaPageSelectColumn.getColumnDefinition();
                visibleColumns.push(oaPageSelectColumnInstance);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.NumCopiesColumn)){
                var controlledPrintNumCopiesColumnInstance = this.controlledPrintNumCopiesColumn.getColumnDefinition();
                visibleColumns.push(controlledPrintNumCopiesColumnInstance);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.SelectVersionColumn)){
                var selectVersionColumnInstance = this.selectVersionColumn.getColumnDefinition();
                visibleColumns.push(selectVersionColumnInstance);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.RowToggleColumn)){
                var rowToggleColumnInstance = this.rowToggleColumn.getColumnDefinition();
                visibleColumns.push(rowToggleColumnInstance);
            }

            //Plugins that should be in the front 
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.BookmarkColumn)){
                var bookmarkColumnInstance = this.bookmarkColumn.getColumnDefinition();
                visibleColumns.unshift(bookmarkColumnInstance);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.OrderInputColumn)){
                var orderInputColumnInstance = this.orderInputColumn.getColumnDefinition();
                visibleColumns.unshift(orderInputColumnInstance);
            }

            return visibleColumns;
        },
        // Adds column size to the table
        _addRowSizeToVisibleColumns: function(visibleColumns) {
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.RowSizeColumn)) {
                visibleColumns.push({
                    id: "_row_size",
                    name: window.localize("modules.search.tableView.size"),
                    field: "rowSize",
                    width: 100,
                    resizable: true,
                    sortable: true,
                    formatter: function(row, cell, value, columnDef, dataContext) {
                        if (dataContext) {
                            var size = null;

                            if (dataContext.renditionSize) {
                                size = dataContext.renditionSize;
                            } else {
                                size = dataContext.nativeSize;
                            }

                            return "<span>" + (size / tsgUtils.FILE_SIZE_CONVERSIONS.BYTES_TO_MEGABYTE).toFixed(2) + " MB</span>";
                        }

                        return null;
                    }
                });
            }

            return visibleColumns;
        },
        columnHeaderResize: _.debounce(function() {
            if (window.innerWidth >HPIConstants.WindowSize.Small){ // when not in list mode
                this.grid.resizeCanvas();
                var columnTotalWidth = 0;
                var columns = this.grid.getColumns();
                _.each(columns, function(column) {
                    columnTotalWidth += column.width;
                });
                var widthOfHeader = $("#myGrid-" + this.cid).width();
                if (widthOfHeader >= columnTotalWidth) {
                    if (columns.length !== 0) {
                        var difference = Math.floor((widthOfHeader - columnTotalWidth) / (columns.length - 1));
                        _.each(columns, function(column) {
                            if (column.id !== "_checkbox_selector") {
                                column.width += difference;
                            }
                        });
                        this.grid.setColumns(columns);
                    }
                }
            }
        }, 200),
        /*The slick.rowmovemanager sends the data as:
        args: {
            insertBefore: 2,
            rows: [0,7]
        }
        This code was obtained by following the examples on SLick Grids GitHub page
        https://github.com/mleibman/SlickGrid/blob/gh-pages/examples/example9-row-reordering.html
        */
        reorderRows: function(e,args, adjustedForPages){
            var extractedRows = [];
            var rows = args.rows;
            var insertBefore = args.insertBefore;
            //The adjustedForPages parameter tells us if the row numbers coming in have taken page size and 
            //what page they are on into account. Currently, while the orderInputPluginOnCellChange function 
            //does do this, the slick.rowmovemanager does not.
            if(!adjustedForPages) {
                // you need to pad out the selected rows by which page you're on * how big the pages are
                var pageInfo = this.searchResultsViewController.grid.getData().getPagingInfo();
                rows = _.map(args.rows, function(row){
                    return row += pageInfo.pageSize * pageInfo.pageNum; 
                });
                insertBefore = args.insertBefore + (pageInfo.pageSize * pageInfo.pageNum);
            }
            
            var data = this.collection.models;
            var left = data.slice(0, insertBefore);
            var right = data.slice(insertBefore, data.length);

            //Sort the rows to be in order
            rows.sort(function(a,b) { 
                return a-b; 
            });
            //grab the rows that we are going to move
            _.each(rows,function(row){
                extractedRows.push(data[row]);
            });
            //reverse the order of the rows so that when we splice the row numbers stay consistent
            //Always want to remove the higher rows first to avoid messing the splice up
            rows.reverse();
            //Remove rows being moved from the left and right split
            _.each(rows, function(row){
                if (row < insertBefore) {
                    left.splice(row, 1);
                } else {
                    right.splice(row - insertBefore, 1);
                }
            });
            //Add the rows extracted to the middle and set the result on data
            data = left.concat(extractedRows.concat(right));
            //Update the Ordinals on all of the models
            _.each(data, function(model,index){
                model.get("properties").ordinal =  index + 1;
            });

            this.grid.resetActiveCell();
            //Set the new order on the collection and dataView
            this.collection.models = data;
            this.dataView.setItems(this.collection, "objectId"); //set id prop to objectId
            this.grid.render();
        },
        launchOASelectedPages: function(options){
            var objectId = options.objectId;
            var row = options.row;
            var oaContainerModel = new OAContainer.Model({
                objectId: objectId,
                pages: options.selectedPages || ""
            });
             //If the action is configured for the RSAH, then we can use a modal instead of a popover
            var mode = this.searchResultsViewController.handler === "rightSideActionHandler" ? "modal" :"popover";
            var selectedPagesView = new OAContainer.SelectedPages({
                model: oaContainerModel,
                mode: mode,
                modalSize: "modal-xl"
            });

            this.listenTo(selectedPagesView, 'done:selectedPages', function(selectedPages){
                // destroy our listeners now that we are done
                this.stopListening(selectedPagesView);
                options.callBack(objectId, tsgUtils.getFormattedSelectedPages(selectedPages).join(','), row);
            });

            if(mode === "modal"){
                this.setView("#oa-modal-outlet", selectedPagesView).render();
            }else{
                app.popoverHandler.trigger("show", {
                    view: selectedPagesView,
                    title: window.localize("modules.openannotate.oacontainer.title"),
                    size: 'small'
                });
            }
        },
        launchSelectVersion: function(options) {
            // If the action is configured for the RSAH, then we can use a modal instead of a popover
            var mode = this.searchResultsViewController.handler === HPIConstants.Handlers.RightSideActionHandler ? "modal" :"popover";
            var selectVersionsView = new SelectVersion.View({
                mode: mode,
                objectId: options.objectId,
                objectIds: [options.objectId],
                objectName: options.objectName,
                row: options.row,
                selectedVersionLabel: options.selectedVersionLabel,
                persistSelectedVersions: options.callBack
            });

            if(mode === "modal") {
                this.setView("#select-version-modal-outlet", selectVersionsView).render();
            } else {
                app.popoverHandler.trigger("show", {
                    view: selectVersionsView,
                    title: window.localize("modules.actions.advancedCombineToPDF.selectVersionModal.title"),
                    size: 'small'
                });

                // extend the popover container to the full viewport height
                $('.popover.in').height('100vh');
            }
        },
        setupSlickGridPlugins: function(){
            //Check plugins config to see what should be created and registered
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.CheckboxColumn)){
                this.checkboxSelector = new Slick.CheckboxSelectColumn({
                    cssClass: "slick-cell-checkboxsel"
                });
                this.grid.registerPlugin(this.checkboxSelector);

            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.OrderInputColumn)){
                this.orderInputColumn = new Slick.OrderInputColumn({
                    onCellChange: _.bind(this.orderInputPluginOnCellChange,this)
                });
                this.grid.registerPlugin(this.orderInputColumn);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.RowToggleColumn)){
                this.rowToggleColumn = new Slick.RowToggleColumn({});
                this.grid.registerPlugin(this.rowToggleColumn);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.NumCopiesColumn)){
                this.controlledPrintNumCopiesColumn = new Slick.NumCopiesColumn({});
                this.grid.registerPlugin(this.controlledPrintNumCopiesColumn);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.BookmarkColumn)){
                this.bookmarkColumn = new Slick.BookmarkColumn({});
                this.grid.registerPlugin(this.bookmarkColumn);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.OAPageSelectColumn)){
                this.oaPageSelectColumn = new Slick.OASelectedPagesColumn({
                    launchOASelectedPages: _.bind(this.launchOASelectedPages, this),
                    HPISpinner: HPISpinner
                });
                this.grid.registerPlugin(this.oaPageSelectColumn);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.DragAndOrderRows)){
                this.moveRowsPlugin = new Slick.RowMoveManager({
                    cancelEditOnDrag: false
                });
                this.moveRowsPlugin.onMoveRows.subscribe(_.bind(this.reorderRows,this));
                this.grid.registerPlugin(this.moveRowsPlugin);
            }
            if(_.contains(this.searchResultsViewController.plugins, HPIConstants.TableView.Plugins.SelectVersionColumn)){
                this.selectVersionColumn = new Slick.SelectVersionColumn({
                    launchSelectVersion: _.bind(this.launchSelectVersion, this),
                    HPISpinner: HPISpinner
                });
                this.grid.registerPlugin(this.selectVersionColumn);
            }

            //PLUGINS FOR ALL SCENARIOS
            var tooltips = new Slick.AutoTooltips();
            this.grid.registerPlugin(tooltips);
        },
        orderInputPluginOnCellChange: function(e, args){
            //Only run code if the Ordering column has changed
            if(args.cell === args.grid.getColumnIndex('ordering')){
                //Ordinals start with 1, so adjust the values for zero indexed based
                var newRow = args.item.newOrdinal - 1;
                var oldRow = args.item.ordinal - 1;
                //if the user enters a negative number dont reorder rows
                if(newRow >= 0){
                    args.item.rowMoved = true;
                    if(oldRow < newRow){
                        this.reorderRows(null,{insertBefore: newRow + 1, rows: [oldRow]}, true);
                    }else{
                        this.reorderRows(null,{insertBefore: newRow, rows: [oldRow]}, true);
                    }
                }
            }
        },
        toggleSelectionPanel: function() {

            var items = this.grid.getData().isFiltered() ? this.grid.getData().getFilteredItems() : this.grid.getData().getItems();
            // visible as in not filtered out - I could view them by switching through pages
            var visibleIds = _.pluck(items, 'objectId');
            var selectedVisibleIds = _.intersection(visibleIds, this.grid.getSelectedIds());
            var numRowsSelectedTotal = selectedVisibleIds.length;

            var numRowsSelectedOnCurrentPage = this.grid.getNumberSelectedOnCurrentPage();

            // using the getLength takes care of the last page when it isn't full
            var areAllRowsOnCurrentPageSelected = numRowsSelectedOnCurrentPage === this.grid.getData().getLength();
            var areAllRowsOnAllPagesSelected = items.length === numRowsSelectedTotal;

            // allow user to select all docs only when all the current page's are
            // selected and there exist unselected docs on other pages
            if (areAllRowsOnCurrentPageSelected && !areAllRowsOnAllPagesSelected) {
                this.$("#pageCount-" + this.cid).html(numRowsSelectedOnCurrentPage);
                this.$("#totalCount-" + this.cid).html(this.collection.state.totalRecords);
                this.grid.setTopPanelVisibility(true);
            } else {
                this.grid.setTopPanelVisibility(false);
            }
        },
        setSelectedObjectsFromSearchResultsViewController: function() {
            if (this.searchResultsViewController && this.searchResultsViewController.grid) {
                //copy any selections over from thumbnail view
                this.grid.setSelectedObjects(this.searchResultsViewController.grid.getSelectedOCOs());
            }
        },
        exportAllResultsViaEmail: function () {
            var actionId = "exportSearchResultsEmail";
            var action = this.setupExportViaEmailAction(actionId);

            var defaultConfig = ActionModules.getDefaultConfig(actionId);
            defaultConfig.disableEmailFieldForExport = this.getSearchConfig().get("disableEmailFieldForExport");

            // Fire action
            app["modalActionHandler"].trigger("show", {
                action: action,
                config: new Backbone.Model(defaultConfig)
            });
        },
        setupExportViaEmailAction: function(actionId) {
            var exportViaEmailAction = new Action.Model({
                name: actionId
            });

            var queryParams = this.collection.getQueryParams();
            queryParams.limit_results = (this.getSearchConfig().get("emailExportResultsLimit") ? this.getSearchConfig().get("emailExportResultsLimit") : "1000");
            queryParams.allowMaxPermissionChecks = true;

            exportViaEmailAction.set("parameters", {
                queryParams: queryParams,
                sortFields: this.visibleAttrs,
                fieldLabels: this.visibleAttrLabels,
                asyncThread: "true"
            });

            return exportViaEmailAction;
        },
        afterRender: function() {
            var self = this;
            var columns = [];
            var showLists = false;
            var enableColumnReorder = this.searchResultsViewController.enableColumnReorder;
            var standardizedTableView = false;
            var standardizedTableViewEnabled = false;
            this.secondarySearchAttr;
            this.sortcol = "title";
            TableView.viewType = this.options.viewType;

            if (this.searchResults) {
                this.objType = this.ocos[0] ? this.ocos[0].get('objectType') : null;
                if(this.objType) {
                    var searchTypeObj;
                    var types = this.searchResults.get('resultsConfig').get('resultsTableConfig').get('types');

                    searchTypeObj = types.findWhere({
                        objectType: this.objType
                    });

                    // This is in case we ever support standardized or thumbnail views in Collections
                    if(!searchTypeObj) {
                        searchTypeObj = types.models[0];                            
                    }
                
                    standardizedTableViewEnabled = searchTypeObj.get('standardizedTableViewEnabled');
                    standardizedTableView = searchTypeObj.get('standardizedTableView');
                    showLists = searchTypeObj.get('showLists');

                    enableColumnReorder = !(standardizedTableViewEnabled && standardizedTableView);

                    var titleObj = searchTypeObj.get('title');
                    if(titleObj) {
                        this.secondarySearchAttr = titleObj.ocName;
                   }   
                }
            } 

            $(window).resize(_.bind(this.columnHeaderResize,this));

            var options = {
                enableCellNavigation: true,
                asyncEditorLoading: true,
                topPanelHeight: 25,
                forceFitColumns: false,
                autoHeight: true,
                defaultColumnWidth: 125,
                selectedCellCssClass: 'selected',
                //We will need to increase the row height if thumbnails are enabled
                rowHeight: 25,
                showLists: showLists,
                enableColumnReorder: enableColumnReorder,
                editable: true, //Needed for any columns we want to edit
                enableAsyncPostRender: true //Needed for the OAPageSelectColumn plugin
            };

            this.handleScrolling = function() {
                if ($("#myGrid-" + self.cid).length > 0) {
                    if ($(window).scrollTop() > $("#myGrid-" + self.cid).offset().top) {
                        var width = $("#myGrid-" + self.cid).width();

                        var topOffset = $('.navbar.navbar-inverse.navbar-fixed-top').height();
                        $(".slick-header").addClass("sticky").css("position", "fixed").css("width", width).css("top", topOffset + 2); //2px for comfort, completely arbitrary number
                    } else {

                        $(".slick-header").removeClass("sticky").css("position", "relative").css("top", 0);
                    }
                }
            };

            $(window).scroll(this.handleScrolling);

            $(".grid-header .ui-icon").addClass("ui-state-default ui-corner-all").mouseover(function(e) {
                $(e.target).addClass("ui-state-hover");
            }).mouseout(function(e) {
                $(e.target).removeClass("ui-state-hover");
            });
            //NOTE - We are starting with the dataview plugin, but if this has performance issues
            //we could write our own implmentation of a slickgrid data source that links to
            //backbone pageable -- particularly if we want server side paging
            this.dataView = new Slick.Data.DataView({
                inlineFilters: true,
                rowSelection: this.searchResultsViewController.rowSelection
            });

            //Create the Slick Grid instance
            this.grid = new Slick.Grid("#myGrid-" + this.cid, this.dataView, columns, options);
            //Put our tableEventsRef onto the grid, so that we can trigger events in Slick Grid
            this.grid.tableEventsRef = this.searchResultsViewController.tableEventsRef;
            //Put the new Grid onto the searchResultsViewController, THis will persist the grid from tableView
            // to thumbnail view

            //The dataview needs access to the grids data as well.
            this.dataView.setGrid(this.grid);               

            //This is SlickGrid's pager/paginator.
            new Slick.Controls.Pager(this.dataView, this.grid, $("#pager-" + this.cid));

            //The listener for anytime the paging info is changed.
            this.dataView.onPagingInfoChanged.subscribe(function(e, pagingInfo) {
                if (!app.searchView || app.searchView === HPIConstants.TableView.SearchView.THUMBNAIL || app.searchView === HPIConstants.TableView.SearchView.LIST) {
                    return;
                }

                self.searchResultsViewController.determineResultsPerPage().done(function() {
                    var resultsPerPage = self.searchResultsViewController.resultsPerPage;
                    // check if we have a previous filter
                    if (self.keepFilter && self.searchResultsViewController.textFilter) {
                        self.searchResultsViewController.tableEventsRef.trigger("search:results:text:filter:change", self.searchResultsViewController.textFilter);
                        self.searchResultsViewController.tableEventsRef.trigger("search:updateTextFilter", self.searchResultsViewController.textFilter);
                    }
                    //The defaulting the page size/resultsPerPage to what is stored on window.  Subsequent renders
                    //will use the last size used.
                    pagingInfo.pageSize = pagingInfo.pageSize < 1 ? resultsPerPage : pagingInfo.pageSize;

                    //We can't be at page 0
                    pagingInfo.pageNum = pagingInfo.pageNum < 1 ? 1 : pagingInfo.pageNum;

                    //Ensuring the totalPages is correct
                    pagingInfo.totalPages = Math.ceil(pagingInfo.totalRows / pagingInfo.pageSize);

                    //Ensuring that the records state that ocquery uses is up to date
                    self.collection.records.set('totalPages', pagingInfo.totalPages);

                    //Firing trigger to searchresultcontrols with new info.
                    self.searchResultsViewController.tableEventsRef.trigger("slickgrid:pagination:change", pagingInfo);
                });              
            });

            //Standard SlickGrid init and setting up filter.
            this.grid.init();
            this.dataView.beginUpdate();
            this.dataView.setFilter(this.slickgridFilter);
            this.dataView.endUpdate();

            //hide selection panel if the user pages or re-searches
            this.listenTo(this.collection, 'reset', function() {
                if (self.grid) {
                    self.grid.setTopPanelVisibility(false);
                }
            }, this);

            if (this.context === HPIConstants.TableView.Context.VAD) {
                //assign a click listener since SlickGrid swallows any events if it's not focused yet
                //normal TableView uses <a hrefs />
                this.grid.onClick.subscribe(_.bind(this.onClickStageLink, this));
            } else if( this.context === HPIConstants.TableView.Context.ACTPDF){
                this.grid.onClick.subscribe(_.bind(this.onClickACTPDFNewTabLink, this));
            }
            // move the selectionalert defined in a hidden div into grid top panel
            $("#selectionAlert-" + this.cid).appendTo(this.grid.getTopPanel()).show();
            $(this.grid.getTopPanel()).addClass("selectionAlertWrapper");

            // Increase the size of the selection alert div when there are two actions
            // present (select all / export via email)
            if (this.searchResultsViewController.useConfigs) {
                if (this.getSearchConfig().get("enableExportViaEmail") === "true") {
                    $(this.grid.getTopPanel()).addClass("twoActions");
                }

                //Whenever a document is right clicked, the context menu appears,
                //instantiating a new view with the configured actions.
                //We only want to work with this context menu if we are using configs
                this.grid.onContextMenu.subscribe(_.bind(this.displayRightClickContextMenu, this));
            }

            if(!(standardizedTableViewEnabled && standardizedTableView)) {
                // if these are undefined we should not be setting a subscribe to them
                if (!_.isUndefined(this._debouncedOnHeaderChange)) {
                    this.grid.onHeaderCellRendered.subscribe(this._debouncedOnHeaderChange);
                }
                if (!_.isUndefined(this._debouncedOnAutoSize)) {
                    this.grid.onAutoSize.subscribe(this._debouncedOnAutoSize);
                }
            }

            this.grid.setSelectionModel(new Slick.RowSelectionModel());

            //REGISTER PLUGINS
            this.setupSlickGridPlugins();

            function sortGrid(args) {
                // if we are sorting on an empty result set after filter, just return b/c there is nothing to sort
                if (self.dataView.isFiltered() && !self.dataView.getFilteredItems().length) {
                    return;
                }
                self.sortcol = args.sortCol.field;
                var dataType = args.sortCol.dataType ? args.sortCol.dataType : args.sortCol.hpiConfig.get("dataType");

                if ($.browser.msie && $.browser.version <= 8) {

                    // use numeric sort of % and lexicographic for everything else
                    self.dataView.fastSort(self.sortcol, args.sortAsc);
                } else {
                    // using native sort with comparer
                    // preferred method but can be very slow in IE with huge datasets
                    //self.dataView.sort(comparer, args.sortAsc);

                    if (dataType === "date") {
                        self.dataView.sort(_.bind(self.dateComparer, self), args.sortAsc);
                    } else {
                        self.dataView.sort(_.bind(self.comparer, self), args.sortAsc);
                    }
                }

                //hack to force the collection to notify everyone about its new ordering
                self.collection.reset(self.collection.models);
                self.collection.state.currentPage = 1;
                //This formats the search results after a sort
                self.collection.formatResults(undefined, {
                    'reset': true,
                    'sorting': true
                });

                //reflecting the newly sorted collection order on the latestResults
                if (self.context !== HPIConstants.TableView.Context.VAD) {
                    if(self.collection.models.length > 1 ) {
                        SearchResultTraversal.latestResults = _.pluck(self.collection.models, 'id');
                        window.localStorage.setItem('latestResults', JSON.stringify(SearchResultTraversal.latestResults));
                    }
                    //There is either 1 or 0 result/s --> we want to remove what we have in localStorage
                    else {
                        window.localStorage.removeItem('latestResults');
                    }
                }
            }
            this.grid.onSort.subscribe(function(e, args) {
                sortGrid(args);
            });

            this.grid.toggleSelectionPanel = _.debounce(self.toggleSelectionPanel, 100);

            this.grid.onSelectedRowsChanged.subscribe(_.bind(this.onSelectedRowsChanged, this));

            // if this is undefined we should not be setting a subscribe to it
            if (!_.isUndefined(this._debouncedOnHeaderChange)) {
                this.grid.onColumnsResized.subscribe(this._debouncedOnHeaderChange);
            }

            // Register all subscribes to events on tableview
            this.registerSubscribers();    

            // wire up model events to drive the self.grid
            this.dataView.onRowCountChanged.subscribe(function() {
                self.grid.updateRowCount();
                self.grid.render();
                self.searchResultsViewController.tableEventsRef.trigger("updateFilters", self.grid.getData().getFilteredItems());
            });

            this.dataView.onRowsChanged.subscribe(_.bind(this.onDataViewRowsChanged, this));
            
            // initialize the model after all the events have been hooked up
            this.dataView.beginUpdate();
            this.dataView.endUpdate();

            // if you don't want the items that are not visible (due to being filtered out
            // or being on a different page) to stay selected, pass 'false' to the second arg
            this.dataView.syncGridSelection(this.grid, false);

            // this is needed when loading view all docs and going directly into thumbnail view
            if (this.isThumbnailViewOn) {
                app.searchView =  HPIConstants.TableView.SearchView.THUMBNAIL;
                this._reloadResults(this.collection);
                this.isThumbnailViewOn = false;
            } else if (this.isListViewOn) {
                app.searchView = HPIConstants.TableView.SearchView.LIST;
                this._reloadResults(this.collection);
                this.isListViewOn = false;
            }

            if( TableView.viewType === HPIConstants.TableView.ViewType.ResetTableView || standardizedTableView) {
                this._reloadResults(this.collection);
                var formTypes = this.options.searchResults.get("sidebarConfig").get("attributeSearchConfig").get("formTypes");
                
                // Pull default sorting attribute from attribute search config                
                var currentFormType = _.find(formTypes, function(formType) {
                    return formType.type === self.objType;
                });

                var col = _.find(self.grid.getColumns(), function(col) {
                    return currentFormType.defaultSortAttr === col.field;
                });

                // if there are no column fields with the defaultSortAttr, sort by the first column
                if(!col) {
                    // return first column that isn't the checkbox column
                    col =  _.find(self.grid.getColumns(), function(column) {
                        return column.name !== "<input type='checkbox'>";
                    });
                }

                sortGrid({
                    sortAsc:  currentFormType.defaultSortOrder === "-1",
                    sortCol:  {
                        field: currentFormType.defaultSortAttr,
                        dataType: col.hpiConfig.get("dataType")
                    }
                });
            }

            this.searchResultsViewController.tableEventsRef.trigger("tableview:tableAfterGridSetupDone");

            if(this.searchResultsViewController.textFilter){
                this.searchResultsViewController.tableEventsRef.trigger("search:results:text:filter:change", this.searchResultsViewController.textFilter);
                this.searchResultsViewController.tableEventsRef.trigger("search:updateTextFilter", this.searchResultsViewController.textFilter);
            }

            if(this.searchResultsViewController.grid){
                //This ensures that the paging information persists when switching back from thumbnail view
                this.grid.getData().setPagingOptions(this.searchResultsViewController.grid.getData().getPagingInfo());
                //Setting the selected rows based on the grid on searchResultsViewController in case we are coming from thumbnail view
                //This is what allows documents selected in thumbnail view to continue to stay selected in tableview
                this.grid.setSelectedRows(this.searchResultsViewController.grid.getSelectedRows());
            }
            
            //Put the new Grid onto the searchResultsViewController, THis will persist the grid from tableView
            //to thumbnail view and list view
            this.searchResultsViewController.grid = this.grid;     

            this.searchResultsViewController.tableEventsRef.trigger("tableview:tableAfterRenderDone");

            // switch to listview
            if (window.innerWidth <=HPIConstants.WindowSize.Small && this.isFirstRender){
                this.isFirstRender = false;
                app.searchView = HPIConstants.TableView.SearchView.LIST;
                this.searchResultsViewController.tableEventsRef.trigger("search:showLists");
            }
        },
        displayRightClickContextMenu: function(e, args) {
            var self = this;
            //Check to see if the subview has actions or not
            if (app.context.currentSearchConfig().get('resultsConfig').get('resultsTableConfig').get('actions').models === 0 || this.searchResultsViewController.disableRightClickMenu) {
                return;
            } else {
                var cell = args.grid.getCellFromEvent(e);
                if (args.grid.getSelectedRows().length < 1) {
                    //Create the subview
                    this.setView("#contextMenu-" + this.cid, new TableView.Views.Menu({
                        e: e,
                        args: args,
                        collectionId: (this.collection && this.collection.collectionId ? this.collection.collectionId : null),
                        searchResults: this.getSearchResults(),
                        multipleSelected: false,
                        tableViewCid: this.cid,
                        searchResultsViewController: this.searchResultsViewController
                    })).render();
                } else {
                    //Create the subview
                    this.setView("#contextMenu-" + this.cid, new TableView.Views.Menu({
                        e: e,
                        args: args,
                        collectionId: (this.collection && this.collection.collectionId ? this.collection.collectionId : null),
                        searchResults: this.getSearchResults(),
                        groupActions: this.options.groupActions,
                        multipleSelected: true,
                        objectTypes: this.collection.queryParams.oc_type,
                        visibleAttrs: this.visibleAttrs,
                        visibleAttrLabels: this.visibleAttrLabels,
                        tableViewCid: this.cid,
                        searchResultsViewController: this.searchResultsViewController
                    })).render();
                }
                if(!_.contains(args.grid.getSelectedRows(), cell.row)) {
                    args.grid.setSelectedRows([cell.row]);
                }

                e.preventDefault();

                //Display the menu in the correct row and location where the user clicked
                $("#contextMenu-" + this.cid)
                    .data("row", args.grid.getData().getItem(cell.row).objectId)
                    .css("top", e.clientY)
                    .css("left", e.clientX)
                    .show();
                
                //unbind any previous listeners
                $("body").off().bind("click", function(e) {
                    if (!_.contains(e.target.classList, 'unlaunchableAction')) {
                        $("#contextMenu-" + self.cid).hide();
                    }
                });
                if (this.context === HPIConstants.TableView.Context.VAD) {
                    args.grid.contextMenuShown = true;
                }else{
                    // Need to hide context menu on checkbox clicks as well
                    $("input[type='checkbox']").one("click", function() {
                        $("#contextMenu-" + self.cid).hide();
                    });
                }
            }
        },
        onSelectedRowsChanged: function(evt, args) {
            var self = this;
            //If row selection is disabled then ignore this code. A better way to do this is to figure out how to have
            //Slick grids RowSelectionModel not fire this at all 
            if(this.searchResultsViewController.rowSelection){
                _.each(args.rows, function(selectedIdx) {
                    var oco = args.grid.getData().getItem(selectedIdx);
                    self.grid.addSelectedObject(oco.objectId, oco);
                });
                this.grid.toggleSelectionPanel.call(this);

                // Signal to view controller the changes in selections
                this.searchResultsViewController.tableEventsRef.trigger('search:selectedResults', this.grid.getSelectedOCOs());
            }
        },
        onDataViewRowsChanged: function(e, args) {
            this.grid.invalidateRows(args.rows);
            if (this.searchResultsViewController.useConfigs) {
                this.setDefaultTitleValue();
            }

            // recalculate which pages need to be set based on the global ids/ocos list on the grid
            var newPageRows = this.grid.getSelectedRowsOnCurrentPage();
            this.grid.setSelectedRows(newPageRows);

            this.grid.render();
        },
        registerSubscribers: function(){
                this.grid.onClick.subscribe(_.bind(this._gridClickHandler, this));
        },
        onClickACTPDFNewTabLink: function(evt, args) {
            evt.preventDefault();
            //Check to see if the column clicked was a link column
            if(this.grid.getColumns()[args.cell].isLink){
                var model = this.grid.getData().getItem(args.row);
                var objId = model.objectId;
                // check if we have a selected version to show instead
                if(this.grid.versionSelections && this.grid.versionSelections[objId]) {
                    objId =  this.grid.versionSelections[objId].selectedVersionId;
                }
                window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(model.objectName) + "?id=" + objId + "&contentType[]=pdf,txt,.*");
            }
        },
        setDefaultTitleValue: function() {
            var self = this;
            var config = this.getSearchConfig();
            if (self.collection && self.collection.length > 0) {
                var type;
                if (self.collection.queryParams.oc_type !== undefined) {
                    type = config.get("types").findWhere({
                        objectType: self.collection.queryParams.oc_type[0]
                    });
                } else {
                    //IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
                    // for now we are assuming it's just one parent type for collections
                    type = config.get("types").models[0];
                }
                _.each(self.collection.models, function(oco) {
                    if (oco.get("properties") && !oco.get("properties")[type.get("title").ocName]) {
                        oco.get("properties")[type.get("title").ocName] = window.localize("modules.search.tableView.noValue");
                    }
                });
            }
        },
        openQuickSearch: function() {
            this.grid.setTopPanelVisibility(!this.grid.getOptions().showTopPanel);
        },
        contextMenu: function(e) {
            //see slickgrid trigger method. That's how i'm basing the fake click from
            this.grid.onHeaderContextMenu.notify({}, e, this.grid);
        },
        closePanel: function() {
            this.grid.setTopPanelVisibility(!this.grid.getOptions().showTopPanel);
        },
        selectAll: function() {
            var newlySelectedOCOs = [];
            // we want to allow the user to select the entire subset of filtered items at once
            if (this.dataView.isFiltered()) {
                newlySelectedOCOs = this.dataView.getFilteredItems();
            } else {
                //if in client-mode, get all results, otherwise, return this page of results
                var collectionFromWhichToPluck = (this.collection.mode === HPIConstants.Properties.Client) ?  this.collection.fullCollection : this.collection;
                newlySelectedOCOs = collectionFromWhichToPluck.pluck(HPIConstants.Properties.Properties);
            }

            var allSelectedOCOs = _.union(this.grid.getSelectedOCOs(), newlySelectedOCOs);

            this.searchResultsViewController.tableEventsRef.trigger("search:selectedResults", allSelectedOCOs);

            this.grid.setTopPanelVisibility(!this.grid.getOptions().showTopPanel);
        },
        serialize: function() {
            this.options.isMobile = navigator.userAgent.toLowerCase().indexOf('android') > -1 ||
                navigator.userAgent.toLowerCase().indexOf('ipad') > -1 ||
                navigator.userAgent.toLowerCase().indexOf('iphone') > -1 ||
                navigator.userAgent.toLowerCase().indexOf('ipod') > -1;
            if (this.searchResultsViewController.useConfigs) {
                this.options.enableExportViaEmail = this.getSearchConfig().get("enableExportViaEmail") === "true";
            }
            this.options.cid = this.cid;
            this.options.showColumnPicker = this.searchResultsViewController.enableColumnPicker;
            return this.options;
        },
        getSearchConfig: function() {
            if (this.context === HPIConstants.TableView.Context.Search || this.context === HPIConstants.TableView.Context.Collections) {
                return this.options.searchConfig;
            } else {
                return app.context.currentSearchConfig().get("resultsConfig").get("resultsTableConfig");
            }
        },
        getSearchResults: function() {
            if (this.context === HPIConstants.TableView.Context.Collections) {
                return this.options.searchResults;
            } else {
                return app.context.currentSearchConfig();
            }
        }
    });

    TableView.Views.Menu = Backbone.Layout.extend({
        template: "search/tableviewActionMenu",
        initialize: function() {
            var cell = this.options.args.grid.getCellFromEvent(this.options.e);
            //get objectId from cell clicked in order to stream content/execute action
            this.options.objectId = this.options.args.grid.getData().getItem(cell.row).objectId;
            this.options.objectIds = _.union(this.options.args.grid.getSelectedIds(), this.options.objectId);
            this.options.objectName = this.options.args.grid.getData().getItem(cell.row).objectName;
            this.options.objectNames = _.union(this.options.args.grid.getSelectedObjectNames(), this.options.objectName);
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.tableViewCid = this.options.tableViewCid;

            this.actionConfigs = Action.getActionConfigs(this.options);
            var resolvedActions;
            if (this.options && this.options.collectionId) {
                resolvedActions = Action.resolveActions(this.options, this.options.collectionId);
            } else {
                resolvedActions = Action.resolveActions(this.options);
            }
            this.actionCollection = resolvedActions.actions;
            this.optionsConfigured = resolvedActions.optionsConfigured;
            this.stopListening(this.searchResultsViewController.tableEventsRef, "search:selectedResults");

            // this listener updates the items if we add selections after initializing the context menu
            this.listenTo(this.searchResultsViewController.tableEventsRef, "search:selectedResults", function(selectedObjects) {
                this.options.objectIds = _.pluck(selectedObjects, HPIConstants.Properties.ObjectId);
                this.options.objectNames = _.pluck(selectedObjects, HPIConstants.Properties.ObjectName);
            });

            //wait for actions to resolve
            $.when(resolvedActions.deferred).done(_.bind(function() {
                _.each(this.optionsConfigured, function(actionOption) {
                    // default to being able to launch action
                    actionOption.dontLaunchAction = 'false';
                    var aConfig = this.actionConfigs[actionOption.id];
                    // check if we want to run some condition validation on the action and determin if we want to be able to launch the action
                    if (aConfig && aConfig.get('hasClientCondition') && BooleanUtils.isTruthy(aConfig.get('hasClientCondition'))) {
                        var action = this.actionCollection.findWhere({ "actionId": actionOption.id });
                        var actionModule = ActionModules.getAction(actionOption.id);
                        // the client condtion evaluator failed, get the message from the action and display it as well as grey out the action label
                        if (!actionModule.evaluateClientCondition(action)) {
                            actionOption.dontLaunchAction = 'true';
                            actionOption.failedConditionMessage = actionModule.failedConditionMessage;
                        }
                    }
                }, this);
                this.render();
            }, this));
            //Context menu has been clicked, figure out if need to stream document or open action
            $("#contextMenu-" + this.tableViewCid).off().on('click', _.bind(function(e) {
                if (!$(e.target).is("li")) {
                    return;
                }

                // if we do not want to launch this action, return and dont do anything
                if (BooleanUtils.isTruthy($(e.target).data('dontlaunch'))) {
                    e.preventDefault();
                    return;
                }
                var attrs = $(e.target.attributes.data);

                //Action was selected in the menu, figure out which action and execute it
                var continueSearch = true;
                var modelIndex = 0;
                                    
                while (continueSearch === true) {
                    if (attrs.val() === "0") {
                        continueSearch = false;
                    } else if (this.actionCollection.at(modelIndex).get("actionId") === attrs.val()) {
                        this._setUpAction(attrs.val(), modelIndex, cell);
                        continueSearch = false;
                    }
                    modelIndex++;
                }
            }, this));
        },
        _setUpAction: function(actionId, index, cell) {
            var action = this.actionCollection.at(index);
            var aConfig = this.actionConfigs[actionId];

            action.get("parameters").objectTypes = this.objectTypes;
            action.get("parameters").context = "searchResultControls";
            if (this.options.objectIds) {
                action.get("parameters").sortFields = [];
                var getIds = function(obj) {
                    if (obj.id !== "_checkbox_selector") {
                        action.get("parameters").sortFields.push(obj.id);
                    }
                };
                _.each(this.searchResultsViewController.grid.getColumns(), getIds);
            } else {
                //set a single selected objectId
                var params = action.get("parameters");
                params.objectId = this.options.objectId;
                action.set("parameters", params);
            }
            action.get("parameters").fieldLabels = _.reject(_.pluck(this.args.grid.getColumns(), "name"), function(val) {
                return val.indexOf("input type='checkbox'") !== -1;
            });

            //hide sticky bar if there
            $('.slick-header.sticky').css('z-index', 10);

            if (aConfig.actionId.indexOf("openNewTab") !== -1 || aConfig.actionId.indexOf("copyText") !== -1) {

                action.get("parameters").selectedHtml = this.options.args.grid.getCellNode(cell.row,cell.cell);
            
                //TODO build up docvals array in opennewtab to avoid code duplication with thumbnail and searchresultcontrols
                var docVals = this.populateDocVals();
                
                // This will open the modal and then immediately close it
                app.modalActionHandler.trigger("launch", { action: this.actionCollection.at(index), config: aConfig, docVals: docVals});
                $("#contextMenu-" + this.tableViewCid).hide();
            } else {
                app[aConfig.get("handler")].trigger("show", {
                    'action': this.actionCollection.at(index),
                    'config': aConfig,
                    'searchResultsViewController': this.searchResultsViewController
                });
            }

            app.once(app[aConfig.get("handler")], "hide", this.restoreStickyHeaders);
        },
        populateDocVals: function(){
            var docVals = [];
            if (module.config() && module.config().useFirstThree) {
                var field1, field2, field3;
                field1 = this.args.grid.getColumns()[1].field;
                field2 = this.args.grid.getColumns()[2].field;
                field3 = this.args.grid.getColumns()[3].field;
                var selectedIndexes = this.args.grid.getSelectedRows();

                _.each(selectedIndexes, function(value) {
                    var oco = this.args.grid.getData().getItemByIdx(value);
                    var docMap = [];
                    docMap.push(oco[field1]);
                    docMap.push(oco[field2]);
                    docMap.push(oco[field3]);

                    docVals.push(docMap);
                }, this);
            }

            return docVals;
        },
        restoreStickyHeaders: function() {
            //restore sticky bar if there
            $('.slick-header.sticky').css('z-index', 1050);
        },
        serialize: function() {
            return {
                "optionsConfigured": this.optionsConfigured
            };
        }
    });

    // Return the module.
    return TableView;
    });