define([
	"app",
	"modules/hpiadmin/preferences/userpreferences",
	"modules/hpiadmin/preferences/publicpreferences",
	"moment",
	"handlebars"
],
	function (app, UserPreferences, PublicPreferences, moment, Handlebars) {
		"use strict";
		var SavedSearch = app.module();

		Handlebars.registerHelper('selectSearch', function (items, publicSearches, selected) {
			var out = "<select class='form-control' id='savedSearches'>";
			if (items.length > 0 || publicSearches.length > 0) {
				//add blank value
				out = out + "<option value=''></option>";
			} else {
				out = out + "<option value=''>" + window.localize("search.noSavedSearches") + "</option>";
			}
			if (items.length > 0) {
				out = out + "<optgroup label=\"My Saved Searches\">";
				_.each(items, function (savedSearch) {
					if (selected === savedSearch.get('name')) {
						out = out + "<option value=\"" + Handlebars.Utils.escapeExpression(savedSearch.get('name')) + "\" class='selectedSearch' selected>" + Handlebars.Utils.escapeExpression(savedSearch.get('name')) + "</option>";
					} else {
						out = out + "<option value=\"" + Handlebars.Utils.escapeExpression(savedSearch.get('name')) + "\" class='selectedSearch'>" + Handlebars.Utils.escapeExpression(savedSearch.get('name')) + "</option>";
					}
				});
				out = out + "</optgroup>";
			}
			if (publicSearches.length > 0) {
				out = out + "<optgroup label=" + window.localize("modules.search.savedSearch.publicSavedSearch") + ">";
				publicSearches.forEach(function (publicSearch) {
					if (selected === "_public_" + publicSearch.get('name')) {
						out = out + "<option value=\"_public_" + Handlebars.Utils.escapeExpression(publicSearch.get('name')) + "\" class='selectedSearch' selected>" + Handlebars.Utils.escapeExpression(publicSearch.get('name')) + "</option>";
					} else {
						out = out + "<option value=\"_public_" + Handlebars.Utils.escapeExpression(publicSearch.get('name')) + "\" class='selectedSearch'>" + Handlebars.Utils.escapeExpression(publicSearch.get('name')) + "</option>";
					}
				});
			}
			out = out + "</select>";
			return out;
		});

		SavedSearch.View = Backbone.Layout.extend({
			template: "search/savedsearch",
			events: {
				"click #saveSearchBtn": "saveSearch",
				"click #newSearchBtn": "toggleShowSearch",
				"click #backBtn": "toggleShowSearch",
				"change #savedSearches": "executeSearch",
				"click .selectedSearch": "executeSearch"
			},
			initialize: function () {
				var self = this;
				this.query = this.options.collection;
				this.selectedType = this.options.selectedType;
				this.selectedSearch = "";
				this.showSearches = true;

				//if a user preference object doesn't exist, this will throw a
				//silent oc error about not being able to find the file
				app.context.configService.getUserPreferences(_.bind(this.grabPreferences, this));

				app.context.configService.getApplicationConfig(function (appConfig) {
					self.dateFormat = appConfig.get("dateFormat");
				});

				// render the view once sortSavedSearchesByTrac function has finished
				this.setPublishingGroups().done(function () {
					self.applyListeners();
				});


			},
			afterRender: function () {
				this.hasRendered = true;
			},

			applyListeners: function () {
				this.listenTo(app, "searchExecuted:renderSavedSearch", function () {
					this.modifiedDateToRender = undefined;
					this.modifierToRender = undefined;
					this.selectedSearch = undefined;
					this.render();
				}, this);
			},
			grabPreferences: function (currentUserPreferences) {
				var self = this;
				this.userPreferences = currentUserPreferences;

				// only call public preferences if enabled
				if (this.options.enabledPublicSavedSearch) {
					app.context.configService.getPublicPreferences(function (publicPreferences) {
						self.publicPreferences = publicPreferences.findWhere({ tracName: app.context.configName() });

						// render to populate saved search picklist
						self.render();
					});
				} else {
					// still need to render if enabledPublicSavedSearch is false
					this.render();
				}

			},
			setPublishingGroups: function () {
				var self = this;
				var currentUserGroups = _.pluck(app.user.get("groups"), 'authorityId');
				var currentTrac = app.context.tracConfigs.findWhere({ name: app.context.configName() });
				var overallDeferred = new $.Deferred();
				var deferredCalls = [];

				var searchConfigName = currentTrac.get("SearchConfig");

				// create a deferred for each search config that the overall deferred will wait for
				var searchDeferred = new $.Deferred();
				deferredCalls.push(searchDeferred);

				app.context.configService.getSearchConfigByName(searchConfigName, function (searchConfig) {
					var groupsAllowedOnTrac = searchConfig.get("savedSearchAdminGroups").models;
					var attributes = _.pluck(groupsAllowedOnTrac, 'attributes');
					groupsAllowedOnTrac = _.pluck(attributes, 'name');
					if (groupsAllowedOnTrac.length < 1 || _.intersection(groupsAllowedOnTrac, currentUserGroups).length > 0) {
						self.editiblePSSUser = true;
					} else {
						self.editiblePSSUser = false;
					}
					searchDeferred.resolve();
				});

				// Once all the deferreds in deferredCalls have been resoved, resolve our overall Deferred
				$.when.apply($, deferredCalls).then(function () {
					overallDeferred.resolve();
				});
				return overallDeferred;
			},
			toggleShowSearch: function (save) {
				var self = this;
				this.showSearches = !this.showSearches;
				if (!(save instanceof Object) || (save.target && save.target.id !== "newSearchBtn")) {
					//clear out the selected search
					this.postToggleSearchName = this.selectedSearch;
					this.selectedSearch = "";
				}
				this.render().promise().done(function () {
					self.switchSearchView(save);
				});
			},
			switchSearchView: function (save) {
				var self = this;
				if ((save instanceof Object) && save.target && save.target.id === "newSearchBtn") {
					if (self.modifierToRender) {
						$("#searchName").val(self.selectedSearch.slice("_public_".length));
						self.oldSearchName = $("#searchName").val();
					} else {
						$('#searchName').val(self.selectedSearch);
					}
				}
				else {
					$('#searchName').val("");
					self.modifierToRender = undefined;
					self.modifiedDateToRender = undefined;
				}

				if (save === "new") {
					app.trigger("alert:changeNotification", 'alert-success', window.localize("generic.search") + " " + this.postToggleSearchName + " " + window.localize("stage.added"), "#saved-search-alert");
				}
				else if (save === "old") {
					app.trigger("alert:changeNotification", "alert-success", window.localize("generic.search") + " " + this.postToggleSearchName + " " + window.localize("stage.updated"), "#saved-search-alert");
				}
			},
			saveSearch: function () {
				this.selectedSearch = this.$('#searchName').val();

				if (this.selectedSearch === "") {
					app.trigger("alert:changeNotification", 'alert-warning', window.localize("search.savedSearch.searchNameRequired"), "#saved-search-alert");
				} else if (this.query.searchParameters === undefined || this.query.searchParameters.length <= 0) { //no search params
					app.trigger("alert:changeNotification", 'alert-warning', window.localize("search.savedSearch.searchParamsRequired"), "#saved-search-alert");
				} else {
					// We need to pass a copy of the search parameters, not a reference to it. Hence the copy.
					var copyOfSearchParams = $.extend(true, [], this.query.searchParameters);
	
					if (!this.modifierToRender) {
						var model = this.userPreferences.get("savedSearches").findWhere({
							'trac': app.context.configName(),
							'name': this.selectedSearch
						});
						if (model !== undefined) {
							this.userPreferences.get("savedSearches").remove(model);
							model = new UserPreferences.SavedSearchModel({
								name: this.selectedSearch,
								selectedType: this.selectedType(),
								searchParams: copyOfSearchParams,
								trac: app.context.configName()
							});
							this.userPreferences.get("savedSearches").add(model, { at: 0 });
							this.toggleShowSearch("old");
						} else {
							model = new UserPreferences.SavedSearchModel({
								name: this.selectedSearch,
								selectedType: this.selectedType(),
								searchParams: copyOfSearchParams,
								trac: app.context.configName()
							});
							this.userPreferences.get("savedSearches").add(model, { at: 0 });
							this.toggleShowSearch("new");
						}
						//update current user preferences
						if (this.userPreferences) {
							app.context.currentUserPreferences(this.userPreferences);
						}
						//save the user preferences
						app.context.configService.getUserPreferences(function (currentUserPreferences) {
							currentUserPreferences.saveNow({ version: false}, { global: false });
						});
					} else {
						var realSearchName = this.selectedSearch;
						//clear selected search - since we're saving this, it will be de-selected anyway, and we don't want them
						//creating a new public pref.
						this.selectedSearch = "";
						this.modifierToRender = undefined;
						this.modifiedDateToRender = undefined;
						var publicModel = this.publicPreferences.get("savedSearches").findWhere({ name: this.oldSearchName });
						this.publicPreferences.get("savedSearches").remove(publicModel);
						publicModel = new PublicPreferences.SavedSearchModel({
							name: realSearchName,
							selectedType: this.selectedType(),
							searchParams: copyOfSearchParams,
							trac: app.context.configName(),
							modifiedDate: moment(),
							modifier: app.user.get("displayName") + " (" + app.user.get("loginName") + ")"
						});
						this.publicPreferences.get("savedSearches").add(publicModel);
						this.publicPreferences.save();//save new saved search
						this.toggleShowSearch("new");
					}
				}
			},
			runSearchQuery: function (model) {
				app.trigger('search:runningSavedSearch');

				// Update search with the criteria stored in the saved search
				this.selectedType(model.get('selectedType'));
				var params = model.get('searchParams');
				this.query.searchParameters = $.extend(true, [], params); // makes a deep copy of the parameters to pass as a new object, not by reference

				// Search through the params for any quick search values to update the search bar with
				_.each(params, function (param) {
					if (param.paramType === "allproperties") {
						app.trigger("updateQuickSearchValue", param.paramValue);
					}
				});

				app.trigger('search:execute');
			},
			executeSearch: function () {
				var self = this;
				self.selectedSearch = ($("#savedSearches option:selected").val() === "") ? undefined : $("#savedSearches option:selected").val();
				if (self.selectedSearch && self.selectedSearch.indexOf("_public_") !== 0) {
					var model = self.userPreferences.get("savedSearches").findWhere({
						'trac': app.context.configName(),
						'name': self.selectedSearch
					});
					if (model !== undefined) {
						self.runSearchQuery(model);
					} else {
						self.selectedSearch = undefined;
					}
					self.modifierToRender = undefined;
					self.modifiedDateToRender = undefined;
				} else if (self.selectedSearch) {
					var realSearchName = self.selectedSearch.slice("_public_".length);
					var searchModel = self.publicPreferences.get("savedSearches").findWhere({
						'name': realSearchName
					});
					if (searchModel === undefined) {
						self.selectedSearch = undefined;
					} else {
						self.runSearchQuery(searchModel);
						self.modifierToRender = searchModel.get("modifier");
						self.modifiedDateToRender = searchModel.get("modifiedDate");
					}
				} else {
					self.modifierToRender = undefined;
					self.modifiedDateToRender = undefined;
				}
				self.render();
			},
			serialize: function () {
				return {
					showSavedSearches: this.showSearches,
					editiblePSSUser: this.editiblePSSUser,
					savedSearches: this.userPreferences ? this.userPreferences.get('savedSearches').where({ 'trac': app.context.configName() }) : [], //only show searches that belong to the selected trac
					selectedSearch: this.selectedSearch,
					publicSearches: this.publicPreferences ? this.publicPreferences.get("savedSearches") : [],
					modifier: this.modifierToRender,
					modifiedDate: this.modifiedDateToRender ? moment(this.modifiedDateToRender).format(this.dateFormat) : ""
				};
			}

		});
		return SavedSearch;
	});
