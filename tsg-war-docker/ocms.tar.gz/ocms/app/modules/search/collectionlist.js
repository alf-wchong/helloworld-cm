// Advancedsearch module
define([
	// Application.
	"app",
	"URIjs/URI",
	"plugins/jquery.cookie",
	"modules/common/action"
],

function(app, URI, cookie, Action) {

	"use strict";

	var CollectionList = app.module();

	var _selectedViewModel = null;

	function getResultViewModel(queryObject, loadedCollection) {
		return kb.ViewModel.extend({
			constructor: function(model, options) { 
				var self = this;
				self.model = model;
				kb.ViewModel.prototype.constructor.call(this, model, options);
				
				self.query = queryObject;
				self.isSelected = ko.observable(false);
				self.visibility = ko.observable(model.get("properties").hpi_collectionVisibility);
				
				//This sets the help text for the icon on the first load.
				self.visibilityTitle = ko.observable();
				if(self.visibility() === "Private"){
					self.visibilityTitle(window.localize("modules.search.collectionList.changePublic"));
				}else{
					self.visibilityTitle(window.localize("modules.search.collectionList.changePrivate"));
				}
				
				self.isEditing = ko.observable(false);
				self.collectionNameDisplay = ko.observable(self.model().get("properties").objectName);
				self.collectionNameHold = ko.observable(self.model().get("properties").objectName);

				self.model().set("objectType", "Collection");

				self.getCollectionItems = function() {
                    app.context.actionParamService.setExtraParameter("collectionId", self.model().id);
                    app.trigger("collection:collectionChange");

                    if(!app.collectionRelation) {
                        app.log.error(window.localize("modules.search.collectionSearch.theRelationObject"));
                    }
                    _selectedViewModel = self; // making this vm as the selected one
                    self.isSelected(true);

                    // Form the URL to store current state
                    var sortUrl = "";
                    var curUrl = Backbone.history.fragment.split("collections")[1];
                    var searchParam = "";
                    if ((new RegExp("&paramValue")).test(curUrl)) {
                        searchParam += "&paramValue=" + curUrl.split("&paramValue=")[1];
                    }
                    if (self.query.state.sortKey !== null) {
                        sortUrl += "&sortAttr=" + self.query.state.sortKey + "&sortOrder=" + self.query.state.order;
                    } else {
                        sortUrl += "&sortAttr=_&sortOrder=_";
                    }
                    var collectionUrl = "collections/" + self.model().id + "&pageNumber=" + self.query.state.currentPage + sortUrl + searchParam;
                    app.log.debug('collection list: fetching collection items: ' + collectionUrl);
                    // navigate to the URL and load the results
                    Backbone.history.navigate( collectionUrl );
                    // loadUrl works if we want to re-load the same query twice
                    Backbone.history.loadUrl( collectionUrl );
                };

				self.deleteCollection = function() {
					app.trigger("alert:confirmation", {
						header : window.localize("modules.search.collectionList.removeCollection"),
						message : window.localize("modules.search.collectionList.youAreAbout"),
						confirm: function() {
							self.model().destroy({
								success : function(){ 
									app.trigger("modelSaveOrDestroy");
									Backbone.history.loadUrl("collections", {trigger: true});
								}
							});
								
							//Check to see if the current config marked for deletion is loaded into the configDetail view.
							//If it is, remove the view and navigate back to the root URL.
							app.trigger("alert:changeNotification", "alert-success", window.localize("modules.search.collectionList.collectionSeccuessfullyDeleted"), "#content-outlet");

						}
					});
				};

				self.showForm = function(data, event) {
					self.isEditing(true);
					$(event.target).hide();
					event.stopPropagation();
				};

				self.cancelForm = function() {
					self.isEditing(false);
					event.stopPropagation();
					// TODO: This should reset collectionNameHold, but
					// as of right now, this screws up the name update
					//self.collectionNameHold(self.collectionNameDisplay());
				};

				self.clickEditBox = function(data, event) { 
					event.stopPropagation();
				};

				self.changeName = function() {
					self.model().get("properties").objectName = $.trim(self.collectionNameHold());
					self.collectionNameDisplay($.trim(self.collectionNameHold()));
					self.model().save({
						success: function(data) {
							app.log.debug(window.localize("modules.search.collectionList.collectionNameChanged"));
						}
					});
					self.isEditing(false);
				};

				self.changeVisibility = function(data, event) {
					if (self.visibility() === "Public") {
						self.visibility(window.localize("generic.private"));
						self.visibilityTitle(window.localize("modules.search.collectionList.changePublic"));
					} else {
						self.visibility(window.localize("modules.search.collectionList.public"));
						self.visibilityTitle(window.localize("modules.search.collectionList.changePrivate"));
					}
					self.model().get("properties").hpi_collectionVisibility = self.visibility();
					self.model().save({
						success: function() {
							app.log.debug(window.localize("modules.search.collectionList.collectionVisibitiyChanged"));
						}
					});
				};

				self.showEditIcon = function(data, event) { 
					var elem = $(event.target);
					var timeout = null;
					
					var editButton = elem.next();
					editButton.stop().fadeIn(100);

					var parent = elem.parent();
					parent.bind("mouseleave", function(event) {
						event.stopPropagation();
						timeout = setTimeout(function() {
							editButton.stop().fadeOut(100);
							elem.unbind(event);
						}, 300);
					});

				};

				var _prefObj = app.context.cookieService.getUserPreferences('collectionTab');
				if (loadedCollection === self.model().id && _prefObj.collectionTab === "myCollections") {
					_selectedViewModel = self;
					//only load the collection if the URL is empty
					if(Backbone.history.fragment.split("collections")[1].indexOf(self.model().id) < 0){
						self.getCollectionItems();
						self.isSelected(true);
					}
				}

				return self;
			}
		});
	}

	CollectionList.ViewModel = function(model, options){ 
		var self = this;

		self.results = kb.collectionObservable(model, {
			view_model : getResultViewModel(options.collectionItems, options.loadedCollection)/*(model, {collection : options.collection})*/
		});

		return self;
	};

	CollectionList.Views.Layout = Backbone.Layout.extend({
		template: "search/collectionlist",
		initialize: function() {
			var self = this;
			self.collections = this.options.collections;
			self.collectionItems = this.options.collectionItems;
			this.listenTo(app, "action:itemModified",  function(collectionId){
				_selectedViewModel.getCollectionItems();
			});
		},
		afterRender: function() { 
			var self = this;

			ko.bindingHandlers.enterKey = {
				init: function(element, valueAccessor, allBindings, vm) {
					ko.utils.registerEventHandler(element, "keyup", function(e) {
						if (e.keyCode === 13) {
							ko.utils.triggerEvent(element, "change");
							valueAccessor().call(vm, vm);
						}

						return true;
					});
				}
			};

			// do an query for hpi_collections
			self.collections.searchParameters = [];
			var sp;

			// add a search parameter for searching upon type hpi_collection
			sp = {
				paramName: "Collection",
				paramValue: "Collection",
				paramType : "type"
			};

			self.collections.searchParameters.push(sp);

			if(!app.uniqueUserName) {
	            app.log.error(window.localize("modules.search.collectionList.theUniqueUser"));
	        }
			sp = {
				paramName: "creator",
				paramValue: app.user.get(app.uniqueUserName),
				paramType: "property"
			};

			self.collections.searchParameters.push(sp);
			$("#myCollections").css("display", "none"); 

			self.collections.fetch({
				success: function() {
					
					if(document.readyState === "complete"){
						$("#myCollections").css("display", "block"); 
					}					
					self.vm = window.colVm = new CollectionList.ViewModel(self.collections, {collectionItems: self.options.collectionItems, loadedCollection : self.options.loadedCollection});
					
					self.listenTo(app, "collection:collectionChange", function() {
						_.each(self.vm.results(), function(result) {
							result.isSelected(false);
						});
					});
					
					kb.applyBindings(self.vm, self.$el[0]);
				}
			});
		}
	});

	return CollectionList;
});
