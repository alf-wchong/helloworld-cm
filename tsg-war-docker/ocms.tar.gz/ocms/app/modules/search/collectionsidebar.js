// Searchsidebar module
define([
  // Application.
  "app",
  "modules/search/collectionsearch",
  "modules/search/collectionlist",

  ],

// Map dependencies from above array.
function(app, CollectionSearch, CollectionList) {

    // Create a new module.
    var CollectionSidebar = app.module();

    /**
    *    CollectionSidebar.ResultViewModel
    *    A sub-view-model for each collection instance.
    **/

    //let's actually create an new collections item  so that search has its own
    //listing of items. it will still populate the same result view so that's fine
    //really

    CollectionSidebar.Views.Tabs = Backbone.Layout.extend({
        template: "search/collectionsidebar-tabs",
        events: {
            "click .nav-tabs": "changeTab"
        },
        initialize: function() {
            this.collections = this.options.collections;
            this.collectionItems = this.options.collectionItems;
            this.loadedCollection = this.options.loadedCollection;
            this.searchCollections = this.options.searchCollections;

            var prefObject = app.context.cookieService.getUserPreferences('collectionTab');

            if (prefObject.collectionTab === "searchCollections") {
                this.collectionActive = "searchCollections";
            } else {
                this.collectionActive = "myCollections";
            }

            this.setView("#myCollections-tabDiv", new CollectionList.Views.Layout({
                collections: this.collections,
                collectionItems : this.collectionItems,
                loadedCollection : this.loadedCollection
            }));

            this.setView("#searchCollections-tabDiv", new CollectionSearch.Views.Layout({
                collections: this.searchCollections,
                collectionItems : this.collectionItems,
                loadedCollection: this.loadedCollection
            }));
        },
        serialize: function() {
            return {
                collectionActive: this.collectionActive
            };
        },
        afterRender: function() {
            app.log.debug(window.localize("modules.search.collectionSidebar.collectionTab"));
        },
        changeTab: function(e) {
            var tabLabel = e.target.innerText;
            var oldPrefObj = app.context.cookieService.getUserPreferences('collectionTab');
            if (tabLabel === "Search Collections") {
                $("#myCollections-tabDiv").css("display", "none");  
                oldPrefObj.collectionTab = "searchCollections";
            } else {
                 $("#myCollections-tabDiv").css("display", "block");
                oldPrefObj.collectionTab = "myCollections";
            }
            app.context.cookieService.setUserPreferences('collectionTab', oldPrefObj);
        }

    });

    CollectionSidebar.Views.Layout = Backbone.Layout.extend({
        template: "search/collectionsidebar",

        initialize: function() {
            var self = this;
            self.name = "collection-sidebar";
            self.collections = this.options.collections;
            self.collectionItems = this.options.collectionItems;
            self.loadedCollection = this.options.loadedCollection;
            self.searchCollections = this.options.searchCollections;
            
        },
        beforeRender: function() {
            var self = this;
            this.setView("#collectiontab-outlet", new CollectionSidebar.Views.Tabs({
                collections: self.collections,
                collectionItems: self.collectionItems,
                loadedCollection: self.loadedCollection,
                searchCollections: self.searchCollections
            }));
        },
        afterRender: function() {
            app.log.debug(window.localize("modules.search.collectionSidebar.collectionSidebar"));
        }
        
    });

    // Return the module for AMD compliance.
    return CollectionSidebar;

});
