define([
	'app',
	'modules/wizard/services/queryservice',
	'modules/wizard/services/validationservice',
	'modules/wizard/services/formatservice'
	
], function(app, QueryService, ValidationService, FormatService){
    // 
    // var isRepeatable = function(controlType){
    //     var repeatableTypes = ['multiselect', 'checkbox', 'file', 'email', 'multitextinput'];
    //     return _.contains(repeatableTypes, controlType);
    // };
    // 
    // var isGrowable = function(controlType){
    //     var growableTypes = ['multiselect'];
    //     return _.contains(growableTypes, controlType);
    // };

    // lower aspects MAY depend on higher aspects
    //	higher aspects MAY NOT depend on lower aspec
    var aspectsInOrder = [	
        'selectable', 
        'repeatable',
        'growable',
        'formattable',
        'operable',
        'disabled'
    ];

    //this matrix of types and supporting aspects.
    //for example, a multselect is selectable, repeatable

    var Models = {};
    //core form field model
    Models.AbstractField = Backbone.Model.extend({
        idAttribute: "_id",
        initialize : function(config) {
            this.set('name', config ? config.name : '');
            this.set('displayValue', config ? config.displayValue : '');
            this.set('displayName', config ? config.displayName : this.get('name'));
            this.set('value', config ? config.value : '');
            this.set('type', config ? config.type : 'textbox'); //default control type to textbox
            this.set('placeholder', config ? config.placeholder : ''); //placeholder value

            //wait for blur to format any values/validation
            this.listenTo(this, 'control:blur', function(field){
                //do any formatting on blur
                this.setDisplayValue(field.getValue());
            }, this);
        }
        // getName: function(){
        //     return this.get('name');
        // },
        // validate : function() { 
        //     return;
        // },
        // setValue: function(newValue){
        //     this.set('value', newValue);
        //     if(_.isObject(newValue)){
        //         this.set('displayValue', newValue.displayValue || newValue.value);
        //     }else{
        //         //by default, mirror value to displayValue
        //         this.set('displayValue', newValue);
        //     }
        // },
        // setDisplayValue: function(newDisplayValue){
        //     this.set('displayValue', newDisplayValue);
        // },
        // getValue: function(){
        //     return this.get('value');
        // },
        // getDisplayValue: function(){
        //     return this.get('displayValue');
        // },
        // clear: function(){
        //     this.set('value', undefined);
        //     this.set('displayValue', undefined);
        // }
    });

    var AdvancedSearchAspects = {};
    
    _.each(aspectsInOrder, function(aspectName) {
        AdvancedSearchAspects[aspectName] = {};
    });

    //each aspect should have an augment function that applies any
    //custom attributes or functions
    AdvancedSearchAspects.selectable.augment =  function(config) {
        this.set('options', config ? config.options || [] : []);
        this.getOptions = function() {
            var deferred = $.Deferred();
            deferred.resolve(this.get('options'));
            return deferred.promise();
        };
        return this;
    };

    AdvancedSearchAspects.repeatable.augment = function(config) {
        var self = this;
        //value is now an array
        this.set('value', config ? config.values || config.value || [] : []);
        this.unset('getValue', {'silent': true}); //silence the unset

        this.stopListening(this, 'control:blur');
        //wait for blur to format any values/validation
        this.listenTo(this, 'control:blur', function(field){
            //do any formatting on blur
            this.setDisplayValue(field.getValues());
        }, this);

        //private util method for chec
        var isValidIndex = function(index){
            return index >= 0 && index < self.get('value').length;
        };

        //getValue now requires an index
        this.getValue = function(index){
            if(!isValidIndex(index)){
                return;
                //	app.log.debug('getValue() invalid index: ' + index);
            }else{
                return this.get('value')[index];
            }
        };
        // THIS DOESNT WORK - GOD ONLY KNOWS WHY
        this.addValue = function(item, index){
            var value = this.get('value');
            //append to the end of the array
            if(index === undefined){		
                value.push(item);
            }else if(isValidIndex(index)){
                value.splice(index, 0, item);
            }else{ //outside bounds of array
                app.log.debug(window.localize("modules.search.advancedSearch.advancedSearchAspects.addValue") + index + window.localize("modules.search.advancedSearch.advancedSearchAspects.noItemAdded"));
            }
            this.setValue(_.extend([], value));
        };
        this.setValue = function(items){
            //is array
            var value = items;
            if(Array.isArray(value)){
                this.set('value', value);
            }else{ //werap single item in an array
                if(value){
                    this.set('value', [value]);
                }else{
                    this.set('value', []);
                }
            }
        };

        this.setDisplayValue = function(items){
            //is array
            var displayValue = items;
            if(Array.isArray(displayValue)){
                this.set('displayValue', displayValue);
            }else{ //werap single item in an array
                if(displayValue){
                    this.set('displayValue', [displayValue]);
                }else{
                    this.set('displayValue', []);
                }
            }
        };

        // THIS DOESNT WORK - GOD ONLY KNOWS WHY
        this.removeValue = function(index){
            var value = _.extend([], this.get('value'));
            if(!isValidIndex(index)){
                app.log.debug(window.localize("modules.search.advancedSearch.advancedSearchAspects.removeValue") + index + window.localize("modules.search.advancedSearch.advancedSearchAspects.noItemRemoved"));
            }else{
                value.splice(index, 1);
            }
            this.set('value', value);
        };
        this.removeAll = function(){
            this.set('value', []);
        };
        //get all values
        this.getValues = function(){
            return this.get('value');
        };

        this.clear = function(){
            this.set('value', []);
            this.set('displayValue', []);
        };

        return this;
    };

    // AdvancedSearchAspects.queryable.augment = function(config){
    //     this.set('queriedOptions', config ? config.queriedOptions || [] : []);
    //     this.set('datasource', config ? config.datasource || undefined : undefined);
    //     this.getOptions = _.bind(function(response){
    //         var self = this;
    //         var deferred = $.Deferred();
    //         //fetch once
    //         if(this.get('datasource') && this.get('datasource') instanceof Backbone.Collection){
    //             $.ajaxSetup({
    //                 global: false
    //             });
    //             $.when(this.get('datasource').fetch({
    //                 type: 'POST'
    //             })).done($.proxy(function(response){
    //                 self.set('fetched', true);
    //                 //this is sometimes the datasource query object rather then the parsed results
    //                 self.set('queriedOptions', _.pluck(self.get('datasource').models, 'attributes'));
    //                 var concatedOptions = self.get('options').concat(self.get('queriedOptions'));
    //                 self.trigger('change:options', concatedOptions); //trigger an options change without modifying options			
    //                 self.set('allOptions', concatedOptions);
    //                 deferred.resolve(concatedOptions);
    //             }, self));
    //         }else{
    //             deferred.resolve(self.get('options'));
    //         }
    //         return deferred.promise();
    //     }, this);
    // 
    //     return this;
    // };

    AdvancedSearchAspects.growable.augment = function(config){
        this.set('growable', true);
        return this;
    };

    // AdvancedSearchAspects.validatable.augment = function(config){
    //     var self = this;
    //     //default validation type to regexp
    //     this.set('validationType', config ? config.validationType || 'regexp' : 'regexp');
    //     //type - email, date, etc
    //     this.set('type', config ? config.type || '' : '');
    // 
    //     this.getType = function(){
    //         return this.get('type');
    //     };
    //     this.validate = function(){
    //         return ValidationService[this.get('validationType')].validate(this.get('displayValue'), self);
    //     };
    //     return this;
    // };
    // 
    // AdvancedSearchAspects.justifiable.augment = function(config) {
    //     this.set('justifications', _.extend({}, config.justifications));
    //     return this;
    // };

    AdvancedSearchAspects.formattable.augment = function(config){
        this.set('displayValue', config ? config.displayValue || undefined : undefined);
        this.set('formatType', config ? config.formatType || undefined : undefined);
        this.set('format', config ? config.format || undefined : undefined);
        //init formatting
        this.set('displayValue', FormatService.format(this.get('value'), this.get('formatType'), this.get('format')));

        this.setValue = function(value){
            this.set('value', FormatService.unformat(value, this.get('formatType'), this.get('format')));
        };

        this.setDisplayValue = function(value){
            this.set('displayValue', FormatService.format(value, this.get('formatType'), this.get('format')));
        };

        return this;
    };

    // AdvancedSearchAspects.requirable.augment = function(config){
    //     var self = this;
    //     var validationErrors;
    //     var parent = _.extend({}, this);
    // 
    //     //if validatable isn't in the aspect chain,
    //     //requirable will return isValid() truthy
    //     this.validate = function(){
    //         validationErrors = [];
    //         //empty, undefined, or blank - single value or array
    //         if(Array.isArray(self.get('displayValue')) && self.get('displayValue').length === 0){
    //             validationErrors.push('Please select at least one option.');
    //         }
    //         if((!self.get('displayValue') && self.get('displayValue') !== 0) || ( typeof self.get('displayValue') === 'string' && !self.get('displayValue').trim() )) {
    //             validationErrors.push('This answer is required, please answer.');
    //         }
    //         if(parent.validate) { //requirable depends on validatable
    //             validationErrors.push(parent.validate());
    //         }
    //         //reject all undefined errors - those are valid
    //         validationErrors = _.reject(validationErrors, function(v) { return !v; });
    //         if(validationErrors.length > 0) {
    //             var validationErrorString = "";
    //             _.each(validationErrors, function(valMsg, idx) {
    //                 if(idx === validationErrors.length - 1) {
    //                     validationErrorString += valMsg;
    //                 } else {
    //                     validationErrorString = validationErrorString + "\n" + valMsg;
    //                 }
    //             });
    //             return validationErrorString;
    //         }
    //     };
    //     return this;
    // };

    AdvancedSearchAspects.disabled.augment = function(config){
        this.isDisabled = function(){
            return this.get('disabled'); 
        };

        this.enable = function(){
            this.set('disabled', false);
        };

        this.disable = function(){
            this.set('disabled', true);
        };

        this.toggle = function(){
            this.set('disabled', !this.get('disalbed'));
            return this.get('disabled');
        };

        return this;
    };

    AdvancedSearchAspects.operable.augment = function(config) {
		var operators = [];
		
		var controlType = config.controlType;
		var dataType = config.dataType;
		
		if(controlType === "TextBox"){
			if(dataType === "string"){
				operators = [{ "value" : "LOGIC_LIKE", "label" : "LIKE"},
							 { "value" : "OPERATOR_EQUALS", "label" : "EQUALS"},
							 { "value" : "OPERATOR_NOT_EQUALS", "label" : "NOT EQUAL TO"}];
			} else if(dataType === "integer" || dataType === "double"){
				operators = [{ "value" : "OPERATOR_LESS_THAN", "label" : "Less Than"},
							 { "value" : "OPERATOR_EQUALS", "label" : "Equal To"},
							 { "value" : "OPERATOR_GREATER_THAN", "label" : "Greater Than"},
						     { "value" : "OPERATOR_NOT_EQUALS", "label" : "Not Equal To"}];
			}
		}
    	this.set('operators', []);
        this.getOperators = function(){
        	return operators;
        };
      	return this;		 
    };
    	
    return {
        getAspectNamesInOrder : function() {
            return _.extend([], aspectsInOrder);
        },
        getAspectAugmentMethods : function() {
            return _.extend({}, AdvancedSearchAspects);
        },
        //get a fresh field to apply aspects on
        getAbstractField : function(config){
            return new Models.AbstractField(config);
        }
    };
});