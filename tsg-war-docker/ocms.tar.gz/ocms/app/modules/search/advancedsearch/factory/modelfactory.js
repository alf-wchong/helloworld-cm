// Abstract View contol module
define([
        "app",
        "modules/search/advancedsearch/models/dateboxmodel",
        "modules/search/advancedsearch/models/datetimeboxmodel",
        "modules/search/advancedsearch/models/textboxmodel",
        "modules/search/advancedsearch/models/autocompletemodel",
        "modules/search/advancedsearch/models/selectmodel",
        "modules/search/advancedsearch/models/proximitydatemodel"
    ],

    function (app, DateboxModel, DateTimeBoxModel, TextboxModel, AutoCompleteModel, SelectModel, ProximityDate) {

        // Create a new module.
        var ModelFactory = {};

        //Return specialized view here
        ModelFactory.GetModel = function (model) {
            var modelToReturn;
            switch (model.get('controlType')) {
                case 'AutoComplete':
                    modelToReturn = new AutoCompleteModel.Model(model);
                    break;
                case 'TextBox':
                    modelToReturn = new TextboxModel.Model(model);
                    break;
                case 'DropDown':
                    modelToReturn = new SelectModel.Model(model);
                    break;
                case 'DateBox':
                    modelToReturn = new DateboxModel.Model(model);
                    break;
                case 'DatetimeBox':
                    modelToReturn = new DateTimeBoxModel.Model(model);
                    break;
                case 'ProximityDateSearch':
                    modelToReturn = new ProximityDate.Model(model);
                    break;
                default:
                    modelToReturn = new TextboxModel.Model(model);
            }
            return modelToReturn;
        };

        return ModelFactory;
    });