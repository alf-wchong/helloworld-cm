// Abstract View contol module
define([
	"app",
    "modules/search/advancedsearch/views/dateboxview",
	"modules/search/advancedsearch/views/datetimeboxview",
    "modules/search/advancedsearch/views/operatorsview",
    "modules/search/advancedsearch/views/textboxview",
	"modules/search/advancedsearch/views/autocompleteview",
	"modules/search/advancedsearch/views/selectview",
	"modules/search/advancedsearch/views/proximitydateview"
],

function(app, DateboxView, DateTimeBoxView, OperatorsView, TextboxView, AutoCompleteView, SelectView, ProximityDate) {

	// Create a new module.
	var ViewFactory = {};

    //Return specialized view here
    ViewFactory.GetView = function(model){
        var view;
		var deferred = $.Deferred();
        switch( model.get('controlType') ) {
            case 'AutoComplete':
				app.context.picklistService.getPicklist(model.get('picklist'), function(data){
					view = new AutoCompleteView.View({options : data, model : model});
					deferred.resolve(view);
				});
                break;
            case 'TextBox':
                view = new TextboxView.View({model: model});
				deferred.resolve(view);
                break;
			case 'DropDown':
	            view = new SelectView.View({model: model});
				deferred.resolve(view);
	            break;
            case 'DateBox':
                view = new DateboxView.View({model: model});
				deferred.resolve(view);
                break;
			case 'DatetimeBox':
				view = new DateTimeBoxView.View({model: model});
				deferred.resolve(view);
				break;
			case 'ProximityDateSearch':
				view = new ProximityDate.View({model: model});
				deferred.resolve(view);
				break;
            default:
                view = new TextboxView.View({model: model});
				deferred.resolve(view);
        }
		return deferred.promise();
    };

	return ViewFactory;
});