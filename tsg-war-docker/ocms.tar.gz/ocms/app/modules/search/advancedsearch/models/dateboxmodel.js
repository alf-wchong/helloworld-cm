// DateBoxModel contol module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel"
],

function(app, AbstractModel) {

	// Create a new module.
	var DateBoxModel = {};
    
    DateBoxModel.Model = AbstractModel.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			DateBoxModel.Model.__super__.initialize.apply( this, model);
        },
		getValue: function(){
			var value;
			if(this.queryObj.attrValues[1] && this.queryObj.attrValues[0]) {
				value = this.queryObj.attrValues[0] + "|" + this.queryObj.attrValues[1];
			}
			//else ifs and else for conditions in which only one date box is selected or param is not datebox
			else if(this.queryObj.attrValues[1] && this.queryObj.attrValues[0] === undefined)	{
				value = "0|" + this.queryObj.attrValues[1];
			} else if (this.queryObj.attrValues[0]){
				value = this.queryObj.attrValues[0] + "|";
			}
			return value;
		}
    });


	return DateBoxModel;
});