// TextboxView contol module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel"
],

function(app, AbstractModel) {

	// Create a new module.
	var TextboxModel = {};
    
    TextboxModel.Model = AbstractModel.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			TextboxModel.Model.__super__.initialize.apply( this, model);
        },
		getValue: function(){
			return this.queryObj.attrValues[0];
		}
    });


	return TextboxModel;
});