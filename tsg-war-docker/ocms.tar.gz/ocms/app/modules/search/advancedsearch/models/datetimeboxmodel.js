// DateTimeBoxModel contol module
define([
		"app",
		"modules/search/advancedsearch/models/abstractmodel"
	],

	function (app, AbstractModel) {

		// Create a new module.
		var DateTimeBoxModel = {};

		DateTimeBoxModel.Model = AbstractModel.Model.extend({
			initialize: function (model) {
				this.attributes = model.attributes;
				DateTimeBoxModel.Model.__super__.initialize.apply(this, model);
			},
			getValue: function () {
				//In the following if statements, attrValues[0] is the from date selected, attrValues[1] is the to date selected
				var value;

				// We have a from and to dates
				if (this.queryObj.attrValues[1] && this.queryObj.attrValues[0]) {
					value = this.queryObj.attrValues[0] + "|" + this.queryObj.attrValues[1];
				}
				// We have only a to date
				else if (this.queryObj.attrValues[1] && !this.queryObj.attrValues[0]) {
					value = "0|" + this.queryObj.attrValues[1];
				}
				// We have only a from date
				else if (this.queryObj.attrValues[0]) {
					value = this.queryObj.attrValues[0] + "|";
				}

				return value;
			}
		});


		return DateTimeBoxModel;
	});