// AutoCompleteModel contol module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel"
],

function(app, AbstractModel) {

	// Create a new module.
	var AutoCompleteModel = {};
    
    AutoCompleteModel.Model = AbstractModel.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			AutoCompleteModel.Model.__super__.initialize.apply(this, model);
            this.defaultValues = app.context.picklistService.getPicklistConfig(this.attributes.picklist).get("defaultItems");
        },
		getValue: function(){
			return this.queryObj.attrValues[0];
		}, 
        clearValues: function() {
            if(this.defaultValues) {
                this.queryObj.attrValues[0] = this.defaultValues;
            } else {
                this.queryObj.attrValues = [];
            }
            this.trigger("values:clear");
        }
	});
	return AutoCompleteModel;
});