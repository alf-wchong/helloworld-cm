// RadioModel contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var RadioModel = {};
    
    RadioModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			RadioModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return RadioModel;
});