// SelectModel contol module
define([
	"app",
    "modules/search/advancedsearch/models/abstractmodel"
],

function(app, AbstractModel) {

	// Create a new module.
	var SelectModel = {};
    
    SelectModel.Model = AbstractModel.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			SelectModel.Model.__super__.initialize.apply( this, model);
        }, 
        getValue: function(model) {
            return this.queryObj.attrValues[0];
        }
    });


	return SelectModel;
});