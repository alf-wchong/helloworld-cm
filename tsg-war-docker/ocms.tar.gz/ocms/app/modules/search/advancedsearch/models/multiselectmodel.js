// MultiSelectModel contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var MultiSelectModel = {};
    
    MultiSelectModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			MultiSelectModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return MultiSelectModel;
});