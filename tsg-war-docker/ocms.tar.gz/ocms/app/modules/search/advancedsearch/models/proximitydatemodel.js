// ProximityDate contol module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel"
],

function(app, AbstractModel) {

	// Create a new module.
	var ProximityDate = {};
    
    ProximityDate.Model = AbstractModel.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
            ProximityDate.Model.__super__.initialize.apply( this, model);
        },
		getValue: function(){
			return this.queryObj.attrValues[0];
		}
	});
	return ProximityDate;
});