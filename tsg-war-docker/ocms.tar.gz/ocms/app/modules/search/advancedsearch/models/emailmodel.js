// EmailModel contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var EmailModel = {};
	
    EmailModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			EmailModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return EmailModel;
});