// Abstract Model contol module
define([
	"app",
	"modules/search/advancedsearch/advancedsearchaspects"
],

function(app, AdvancedSearchAspects) {

	// Create a new module.
	var AbstractModel = {};

    AbstractModel.Model = Backbone.Model.extend({
        initialize: function(options) {
			var self = this;         
            // this.options = attributes;
            // this.label = attributes.label;
            // this.controlType = attributes.controlType;
            // this.id = attributes.ocName;
            // this.uuid = new Date().valueOf(); //sometimes for dom id purposes this is useful //IE<IE9 don't support Date.now()
			// 
            // //If no label is set, use the id instead.
            // if (!this.label) {
            //     this.labelOrId = attributes.id;
            // }
            // else {
            //     this.labelOrId = attributes.label;
            // }
            
            //Adding the aspects
            var fieldAspects = [];
            
            //If we are in advanced search then we already know that we should have the 'operable' aspect
            //This will change later if/when this becomes more mainstream.
            fieldAspects.push('operable');
            
            // if (this.options.repeating) {
            //     fieldAspects.push('repeatable');
            // }
            // 
            // if(this.options.growable) {
            //     fieldAspects.push('growable');
            // }
            
            this.fieldAspects = fieldAspects;

            this.queryObj = {
                "attrName" : this.get('ocName'),
                "attrValues" : [],
                "operators" : []
            };
			
			var fieldA = _.uniq(this.fieldAspects);
			
			_.each(AdvancedSearchAspects.getAspectNamesInOrder(), function(aspectName) {
				if(_.contains(fieldA, aspectName)) {
					//initialize the augmentation with the context of the fieldModel
					self = AdvancedSearchAspects.getAspectAugmentMethods()[aspectName].augment.call(self, self.attributes);
				}
			});

        },

        clearValues: function() {
            this.queryObj.attrValues = [];
            this.trigger("values:clear");
        }
    });

    return AbstractModel;
});