// TextAreaModel contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var TextAreaModel = {};
    
    TextAreaModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			TextAreaModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return TextAreaModel;
});