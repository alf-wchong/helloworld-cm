// CalculationModel contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var CalculationModel = {};
    
    CalculationModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			CalculationModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return CalculationModel;
});