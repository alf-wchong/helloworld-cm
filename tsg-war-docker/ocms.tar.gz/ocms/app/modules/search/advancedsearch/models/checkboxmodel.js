define([
	"app"
],

function(app) {

	// Create a new module.
	var CheckboxModel = {};
    
    CheckboxModel.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
			CheckboxModel.Model.__super__.initialize.apply( this, model);
        }
    });


	return CheckboxModel;
});