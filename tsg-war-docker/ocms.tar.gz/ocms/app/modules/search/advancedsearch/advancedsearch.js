// Advanced Search module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel",
	"modules/search/advancedsearch/views/abstractview",
	"modules/search/advancedsearch/factory/modelfactory"
],
function(app, AbstractModel, AbstractView, ModelFactory) {

	// Create a new module.
	var AdvancedSearch = {};

	AdvancedSearch.LayoutView = Backbone.Marionette.LayoutView.extend({
		//el: "#fb-sidebar-outlet",
		template: "search/advancedsearch/advancedsearch",
		className: "advancedsearch",
        // manage: true,
		regions: {
			primaryAttrs: "#primaryAttrsRegion",
            secondaryAttrs : "#secondaryAttrsRegion",
			buttons : "#buttonRegion"
		},
		events: {
			'click #secondaryToggleButton' : "showSecondary"
		},
		initialize: function() {
            var self = this;
			this.config = this.options.config;
			this.OTC = this.options.OTC;
			this.defaultAllLogicBtn = this.searchConfig.get("sidebarConfig").get("advancedSearchConfig").get("defaultAllLogicBtn");
			//Getting the selected type
			this.selectedType = this.selectedType();

			//Creating our collections for the primary and secondary attributes
            AdvancedSearch.primaryFormControls = new AdvancedSearch.ControlsCollection();
            AdvancedSearch.secondaryFormControls = new AdvancedSearch.ControlsCollection();

			//Grabbing the form config, using search configs information.
            app.context.configService.getFormConfig(this.options.searchConfig.get("form"), function(retrievedForm) {
    		    self.retrievedForm = retrievedForm;
    		});

			//CONSIDER THIS TO BE THE 'onShow()' OF THIS VIEW.
			this.listenTo(app, "renderAdvancedSearch", this.renderAdvancedSearch); //end listenTo

			this.listenTo(app, "tracOrTypeChange", function(type){
				//If there is a type it means that the selectedType or trac has changed.  This calls for a reset of the
				//collections so that Marionette knows to re-render the views.
				if(type){
					AdvancedSearch.primaryFormControls.reset();
					AdvancedSearch.secondaryFormControls.reset();
					self.getForm(type.type);
				}
			});

			this.listenTo(app, "advancedsearch:clearform search:runningSavedSearch",function(){
				this.clearForm();
			},this);

			this.listenTo(app, "advancedsearch:populateviews search:runningSavedSearch", function(){
					self.populateViews();
			},this);



			//Get the form and go to work.
            this.getForm(this.selectedType.type);
		},

		renderAdvancedSearch: function() {
			//Show the views in the regions.
			this.getRegion("primaryAttrs").show(new AdvancedSearch.PrimaryFormControlsView({collection: AdvancedSearch.primaryFormControls}));
			this.getRegion("secondaryAttrs").show(new AdvancedSearch.SecondaryFormControlsView({collection: AdvancedSearch.secondaryFormControls}));
			var secondaryFormOcNames = AdvancedSearch.secondaryFormControls.pluck("ocName");
				
			var searchParamNames = _.pluck(this.collection.searchParameters, "paramName");
			var secondaryAttrSearch = _.intersection(searchParamNames, secondaryFormOcNames);
			if(secondaryAttrSearch && secondaryAttrSearch.length > 0) {
				this.getRegion("secondaryAttrs").currentView.isSecondaryShown = false;	
				this.showSecondary();	
			}
			else {
				this.getRegion("secondaryAttrs").currentView.isSecondaryShown = true;
				this.showSecondary();
			}
			this.getRegion("buttons").show(new AdvancedSearch.ButtonsView({searchParams: this.collection.searchParameters, defaultAllLogicBtn: this.defaultAllLogicBtn}));
					
			if(this.collection.searchParameters.length > 0){
				//i am populating with an existing query, i cant let the defaults chill, lets destroy them
				this.clearForm();
			}
			//Populate fields on refresh
			this.populateViews();
		},

		showSecondary: function() {
			if(this.getRegion("secondaryAttrs").currentView.isSecondaryShown) {
	    		this.getRegion("secondaryAttrs").$el.hide();
	    		this.getRegion("secondaryAttrs").currentView.isSecondaryShown = false;
	    		$("#secondaryButtonGlyph")[0].className = "glyphicon glyphicon-chevron-down";
	    		$("#secondaryButtonText")[0].textContent = window.localize("modules.search.advancedSearch.advancedSearch.moreFields");
			} else {
				this.getRegion("secondaryAttrs").$el.show();
				this.getRegion("secondaryAttrs").currentView.isSecondaryShown = true;
				$("#secondaryButtonGlyph")[0].className = "glyphicon glyphicon-chevron-up";
	    		$("#secondaryButtonText")[0].textContent = window.localize("modules.search.advancedSearch.advancedSearch.lessField");
			}
	    },
		clearForm: function(){
			_.each(_.union(AdvancedSearch.primaryFormControls.models, AdvancedSearch.secondaryFormControls.models), function(model) {
				if(model.queryObj && model.queryObj.attrValues){
					model.queryObj.attrValues = [];
				}			
			});
			_.each($('.searchParam'),function(param){
				param.value = "";
			});
		},
		//KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
        //onShow: function(){
        	//This doesn't work because manage has to be true for this to work.
			//Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
			//on the view.  Consider the 'listenTo' above to be the 'onShow()'
        //},
        populateViews: function() {
        	//Repopulate search parameters on reload of page
        	var self = this;
			_.each(this.collection.searchParameters, function(param) {
				self.populateModel(param);
				var nameAttr = param.paramName + "advanced";
				var searchParams = $('.searchParam');
				_.each(searchParams, function(object) {
					if(object.name === nameAttr) {
						var tempId = param.paramName + "OpsDropDown";
						var tempElement = $("#"+tempId)[0];

						if(tempElement){
							if(param.operator === "OPERATOR_EQUALS") {
								tempElement.innerText = "EQUALS";
							} else if(param.operator === "LOGIC_LIKE") {
								tempElement.innerText = "LIKE";
							} else if(param.operator === "OPERATOR_NOT_EQUALS") {
								tempElement.innerText = "NOT EQUAL TO";
							}
						}

						// proximity date search
						if (param.paramValue.indexOf("$*prx*$") !== -1) {
							var inputParams = param.paramValue.split('$*prx*$')[1];
                            // input params should be inthe format of proximityType|proximityNumber|proximityTimeSpan
                            inputParams = inputParams.split('|');

							if (object.id === 'proximityDateType') {
								object.value = inputParams[0];
							} else if (object.id === 'proximityDateNumber') {
								object.value = inputParams[1];
							} else if (object.id === 'proximityDateTimeSpan'){
								object.value = inputParams[2];
							}
						}

						 //Cases in which dateboxes are present
						else if(param.paramValue.indexOf("|") !== -1) {
							var elementID = object.id;
							var where, tempString, tempLong, time;
							//has both longs present & looking at fromDate
							if(elementID.indexOf("fromDate") !== -1  && param.paramValue.indexOf("|") !== -1) {
								where = param.paramValue.indexOf("|");
								tempString = param.paramValue.substring(0,where);
								//Making sure there is a date here
								if(tempString.length > 2){
									tempLong = parseFloat(tempString, 10);
									time = moment(tempLong).format(app.context.currentApplicationConfig().get("dateFormat"));
									object.value = time;
								}
							}
							//single value
							else if(elementID.indexOf("fromDate") !== -1 && param.paramValue.indexOf("|") === -1) {
								tempLong = parseFloat(param.value, 10);
								time = moment(tempLong).format(app.context.currentApplicationConfig().get("dateFormat"));
								object.value = time;
							}
							//both longs present & toDate object
							else if(elementID.indexOf("toDate") !== -1) {
								where = param.paramValue.indexOf("|");
								tempString = param.paramValue.substring(where+1,param.paramValue.length);
								//Making sure there is a date here
								if(tempString.length > 2){
									tempLong = parseFloat(tempString, 10);
									tempLong = tempLong - 86399999;
									time = moment(tempLong).format(app.context.currentApplicationConfig().get("dateFormat"));
									object.value = time;
								}
							} else if(elementID.indexOf("fromNumeric") !== -1){
								where = param.paramValue.indexOf("|");
								tempString = param.paramValue.substring(0,where);
								if(tempString){
									object.value = parseInt(tempString,10);
								}
							} else if(elementID.indexOf("toNumeric") !== -1){
								where = param.paramValue.indexOf("|");
								tempString = param.paramValue.substring(where+1,param.paramValue.length);
								if(tempString){
									object.value = parseInt(tempString,10);
								}
							}
						}
						//if not a datebox, set the param's value to the object
						else {
							object.value = param.paramValue;
						}
					}
				}); //end query loop
			}); //end searchParam loop
        },
		populateModel: function(param) {
			var models;
			if(param.logic) {
            	AdvancedSearch.logic = [];
            	AdvancedSearch.logic.push(param.logic);
            }

			//Setting our models to the correct collection
			// if(_.contains(_.pluck(AdvancedSearch.primaryFormControls.models, "id"), param.paramName)){
			if(_.contains(_.map(AdvancedSearch.primaryFormControls.models, function(m){ return m.get('ocName'); }), param.paramName)){
				models = AdvancedSearch.primaryFormControls.models;
			} else{
				models = AdvancedSearch.secondaryFormControls.models;
			}

        	_.each(models, function(model) {
        		var attrName = model.queryObj.attrName;
        		if(param.paramName === attrName) {
        			//set operator or logic, depending on what search parameter
    				if(param.operator) {
                    	model.queryObj.operators[0] = param.operator;
                	}else {
                		model.queryObj.operators[0] = "LOGIC_LIKE";
                	}
					if (param.paramValue.indexOf('$*prx*$') !== -1) {
						// this is a proximity date search param, just put the whole param value on the first attr
						model.queryObj.attrValues[0] = param.paramValue;
					} else if (param.paramValue.indexOf("|") !== -1) {
						var where = param.paramValue.indexOf("|");
						var fromDate = param.paramValue.substring(0,where);
						var toDate = param.paramValue.substring(where+1, param.paramValue.length);
						model.queryObj.attrValues[0] = fromDate;
						model.queryObj.attrValues[1] = toDate;
		 			} else{
   						model.queryObj.attrValues[0] = param.paramValue;
    				}
        		}
        	});  //end primary form control loop
        },
        getForm: function(objectTypeName){
			//Get the form associated with our trac and type.
            var formForType = _.find(this.retrievedForm.get("configuredTypes").models, function(formType){
                return formType.get("ocName") === objectTypeName;
            });

			//Helper function to place the models in the correct collection based on if they are primary or secondary attrs.
            var placeInProperCollection = function(model){
                if(_.contains(formForType.get("configuredAttrsPri").pluck("label"), model.get('label'))){
                    AdvancedSearch.primaryFormControls.add(model);
                } else{
                    AdvancedSearch.secondaryFormControls.add(model);
                }
            };

			//Getting the OTC and timezoneformatting settings.
            app.context.configService.getAdminTypeConfig(objectTypeName, function(otc){
                app.context.dateService.getDatetimeTimezoneFormat().done(function(){
                    if (otc){
                        var allConfiguredAttrs = formForType.get("configuredAttrsPri").models;
                        //only add secondary attrs for search
                        allConfiguredAttrs = _.union(formForType.get("configuredAttrsPri").models, formForType.get("configuredAttrsSec").models);

						//Loop through all the the configured attrs (both primary and secondary).
                        _.each(allConfiguredAttrs, function(availableAttribute) {

                            var otcAttr = _.find(otc.get("attrs").models, function(theAttr){
                                return availableAttribute.get("ocName") === theAttr.get("ocName");
                            });

                            availableAttribute.set("label", window.localize(otcAttr.get("label")));

                            // Keeping this here so that we remember that "aspects" need to be added
							// when formsupport is implemented
                            // var tempFormEditable = availableAttribute.get("formEditable");
                            // var tempRepoEditable = availableAttribute.get("editable");
                            // var tempRequired = availableAttribute.get("required");
							//
							// availableAttribute.set("formEditable", tempFormEditable);
                            // availableAttribute.set("editable", tempRepoEditable);
                            // availableAttribute.set("required", tempRequired);

							//Place our "formControl" in the correct collection.
                            placeInProperCollection(new ModelFactory.GetModel (availableAttribute) );
                        });
                    }
                });//end getDateFormat
            }); // end getAdminTypeConfig
        }
	});

	AdvancedSearch.SetQueryParams = function(options){
		var queryParams = [];

		_.each(_.union(AdvancedSearch.primaryFormControls.models, AdvancedSearch.secondaryFormControls.models), function(model) {
			var tempParam = {};
			tempParam.paramName = model.get('ocName');
			if(options === true) {
				tempParam.paramType = "compositeProperty";

			} else {
				tempParam.paramType = "property";
			}

			tempParam.paramValue = model.getValue();
			tempParam.operator = model.queryObj.operators[0];
			queryParams.push(tempParam);
		});
		return queryParams;
	};

	//View to display when there are so configured attrs.  (WILL REMOVE LATER)
    AdvancedSearch.EmptyFormView = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/emptyform"
    });

	// BUTTON REGION View
	AdvancedSearch.ButtonsView = Backbone.Marionette.ItemView.extend({
		template: "search/advancedsearch/buttons",
		events: {
			"click #advancedSearchBtn" : "executeSearch",
			"click #resetAttrsBtn" : "resetAttrs"
		},
		manage: false,
		initialize: function(options) {
			this.searchParams = options.searchParams;
			this.defaultAllLogicBtn = options.defaultAllLogicBtn;
		},
		executeSearch: function(e){
			app.trigger("search:execute", AdvancedSearch.prepareSearch(e));
			app.trigger('searchExecuted:renderSavedSearch');

			// remove the openAnnotateSearchValue from local storage when advanced search is executed.
			window.localStorage.removeItem("openAnnotateSearchValue");
		},
		resetAttrs: function(e){
			e.preventDefault();
			var tempParams = $('.searchParam');
			_.each(tempParams, function(param) {
				param.value = "";
			});
			_.each(_.union(AdvancedSearch.primaryFormControls.models, AdvancedSearch.secondaryFormControls.models), function(model) {
				model.clearValues();
			});
			if(this.defaultAllLogicBtn === "false") {
				$('#anyBtn')[0].checked = true;
			} else {
				$('#allBtn')[0].checked = true;
			}
		},
		onShow: function() {
			if(this.defaultAllLogicBtn === "false") {
				$('#anyBtn')[0].checked = true;
			} else {
				$('#allBtn')[0].checked = true;
			}
			_.each(this.searchParams, function(param) {
				//Only set these buttons if the previous search was an advanced search
				if(param.paramType === "type" && param.logic) {
					if(param.logic.indexOf("and") > -1) {
						$('#allBtn')[0].checked = true;
					} else {
						$('#anyBtn')[0].checked = true;
					}
				}
			});
		}
	});

    // HERE ARE THE TWO COLLECTION VIEWS THAT REPRESENT THE PRIMARY AND SECONDARY ATTRIBUTES
    AdvancedSearch.PrimaryFormControlsView = Backbone.Marionette.CollectionView.extend({
		childView: AbstractView.View,
		emptyView: AdvancedSearch.EmptyFormView,
        collection: AdvancedSearch.primaryFormControls,
		manage: false,
		initialize: function(options){
			this.options = options;
		}
	});
    AdvancedSearch.prepareSearch = function(e) {
        if(e) {
            e.preventDefault();
        }
        var tempButton = $('#allBtn');
        AdvancedSearch.logic = [];
        //ALL is checked
        if(tempButton[0].checked) {
            AdvancedSearch.logic[0] = " and ";
        } else { //ANY is checked
            AdvancedSearch.logic[0] = " or ";
        }
        return AdvancedSearch;
    };

    AdvancedSearch.SecondaryFormControlsView = Backbone.Marionette.CollectionView.extend({
		childView: AbstractView.View,
		emptyView: AdvancedSearch.EmptyFormView,
        collection: AdvancedSearch.secondaryFormControls,
		manage: false,
		initialize: function(options){
			this.options = options;
		}
	});

	AdvancedSearch.ControlsCollection = Backbone.Collection.extend({
		model: AbstractModel.Model
	});

	return AdvancedSearch;
});