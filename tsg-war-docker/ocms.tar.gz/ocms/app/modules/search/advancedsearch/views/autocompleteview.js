// AutoCompleteView contol module
define([
	"app",
	"oc",
	"handlebars"
],

function(app, OC, Handlebars) {

	// Create a new module.
	var AutoCompleteView = {};

    // AutoCompleteControl View
    AutoCompleteView.View = Backbone.Marionette.ItemView.extend({
		template: "search/advancedsearch/views/autocompletecontrol",
		className: 'form-horizontal',
		//model: AbstractControl.model,
		events: {
			'click .btn-typeahead': 'toggleDropdown',
			//scope clicks to just the dropdown menu, not the typeahead
			//mousedssown happens before blur
			'mousedown .typeahead-dropdown > .list-group-item' : 'optionSelected',
			'blur .btn-typeahead': 'onBlur',
			'blur .typeahead-input': 'onBlur'
		},
		manage:false,
		initialize: function(config){
			var self = this;
			this.options = (config.options instanceof Backbone.Collection ? _.pluck(config.options.models, 'attributes') : config.options) || [];

			if(!this.options){
				this.options = [];
			}
			this.loading = config.loading;
			if(this.loading){
				$.when(this.loading).done(function(options){
					self.updateOptions(options);
				});
			}

			this.selected = config.selected || '';
			this.placeholder = config.placeholder || '';
			this.displayKey = config.displayKey || 'label';
			this.searchOn = config.searchOn || 'label'; //fallback to label
			this.showDropDown = false;
			this.isGrowable = config.isGrowable || false; //default to false
			this.tabIndex = config.tabIndex ? "tabindex=" + config.tabIndex : ''; //if tabIndex is not set, leave it out completely
			this.disabled = config.disabled;
			this.defaultItems = app.context.picklistService.getPicklistConfig(config.model.get("picklist")).get("defaultItems");
			this.buildSearchIndex();
			this.listenTo(config.model, "values:clear", this.clear);

			this.overrideLoading = config.overrideLoading;

		},
		buildSearchIndex : function(){
			//add value and label for templating
			_.each(this.options, function(option){
				option.label = option[this.displayKey];
				if(!option.value){
					//only set the value field if it doesn't already exist
					option.value = option[this.searchOn];
				}
			}, this);
			var reinit = this.datasource;

			// constructs the suggestion engine
			/* jshint ignore:start */
			var self = this;
			this.datasource = new Bloodhound({
			    datumTokenizer: function(datum) {
			        var tokens = datum ? Bloodhound.tokenizers.whitespace(datum[self.searchOn]) : [];
				    _.each(tokens,function(value){
	                  	//push each character and value!
	                  	//onto the tokens array for mid-string matches
	                  	_.each(value, function(character, index){
	                  		tokens.push(character);
	                  		tokens.push(value.substr(index, value.length));
	                  	}, this);
            	  	});
            	  	return tokens;
			    },
			    queryTokenizer: Bloodhound.tokenizers.whitespace,
			    local: this.options
			});
			/* jshint ignore:end */
			// kicks off the loading/processing of `local` and `prefetch`
			return this.datasource.initialize(reinit);
		},
		toggleDropdown: function(evt){
			this.showDropDown = !this.showDropDown;
			if(this.showDropDown){
				this.$('.typeahead-dropdown-' + this.cid).show();
			}else{
				this.$('.typeahead-dropdown-' + this.cid).hide();
			}
		},
		getOptions: function(){
			return this.options;
		},
		before: function(){
			return this.el !== undefined;
		},
		clear: function(){
			this.before();
			this.selected = '';
			this.typeaheadEl.typeahead('val', '');
			if(this.defaultItems) {
				this.setOption(this.defaultItems, true);
			}
			this.trigger('change:selected', this.selected);
			return this;
		},
		optionSelected: function(evt){
			this.before();
			var selectedValue = $(evt.currentTarget).data('value').toString();
			this.setOption(selectedValue, true);
			//hide menu after selection
			this.toggleDropdown();
			return this;
		},
		updateOptions: function(options){
			this.options = options;
			this.datasource.clear();
			this.buildSearchIndex();
			//update dropdown list with new options
			if(this.rendered){
				this.render();
			}
			this.model.queryObj.attrValues[0] = options.currentTarget.value;
		},
		clearOptions: function(options){
			this.datasource.clear();
		},
		blur: function(){
			this.before();
			this.typeaheadEl.trigger('blur');
			return this;
		},
		onBlur: function(evt){
			var self = this;
			self.showDropDown = false;
			self.$('.typeahead-dropdown-' + self.cid).hide();
			if(!this.typeaheadEl){
				app.log.error(window.localize("modules.search.advancedSearch.views.autoCompleteView.typeInstance") + self.cid + window.localize("modules.search.advancedSearch.views.autoCompleteView.notFound"));
			}
			//verify that the user's input matches an option
			var selected = self.typeaheadEl.typeahead('val');
			self.datasource.get(selected, $.proxy(function(suggestions){
				if(!suggestions || suggestions.length === 0){
					if(self.isGrowable && selected.length > 0) {
						self.setOption({'value': selected});
					} else {
						this.setOption(selected, true);
						self.trigger('change:selected'); //proc empty selection
					}
				}else{
					//looking for an exact match
					var valid = false;
					_.each(suggestions, function(suggestion){
						if(selected.toLowerCase() === suggestion.label.toLowerCase()){
							valid = true;
							return;
						}
					}, self);
					if(!valid){
						self.trigger('change:selected'); //no match found, proc empty selection
					}
				}
			}, this));
		},
		setOption: function(value, updateTypeahead){
			var rendered = this.before();
			var selectedValue;
			if(value instanceof Array){
				selectedValue = value[0];
			}else{
				selectedValue = value;
			}
			//get whole option
			if(selectedValue instanceof Object){
				this.selected = selectedValue;
			}else{
				this.selected = _.findWhere(this.options, {'value': selectedValue});
				//if we don't have a match and the typeahead is growable, just add the value
				if(!this.selected && this.isGrowable) {
					this.selected = selectedValue;
				}
			}
			if(rendered && updateTypeahead && this.selected){
				this.typeaheadEl.typeahead('val', this.selected.label);
				this.model.queryObj.attrValues[0] = this.selected.value;
			}else{
				//we didn't find a value, but we still need to clear this puppy
				this.typeaheadEl.typeahead('val', "");
				this.model.queryObj.attrValues[0] = "";
			}

			this.trigger('change:selected', this.selected);
			return this;
		},
		onShow: function(){
			this.rendered = true;
			this.typeaheadEl = this.$('.typeahead-' + this.cid);
			if(!this.typeaheadEl){
				app.log.error(window.localize("modules.search.advancedSearch.views.autoCompleteView.typeInstance") + this.cid + window.localize("modules.search.advancedSearch.views.autoCompleteView.notFound"));
			}

			this.typeaheadEl.typeahead({
			    hint: true,
			    highlight: true,
			    minLength: 1
			},
			{
			    displayKey: this.displayKey || 'label',
			    // `ttAdapter` wraps the suggestion engine in an adapter that
			    // is compatible with the typeahead jQuery plugin
			    source: this.datasource.ttAdapter(),
			    templates: {
					empty: this.noResultTemplate(),
				    suggestion: this.searchResultTemplate()
				}
			})
			.on('typeahead:selected ', $.proxy(function (obj, datum) {
				this.setOption(datum, true);
			}, this))
			.on('typeahead:opened ', $.proxy(function () {
				this.showDropDown = false;
				this.$('.typeahead-dropdown-' + this.cid).hide();
			}, this))
			.on('typeahead:autocompleted', $.proxy(function (obj, datum) {
				this.setOption(datum, true);
			}, this));

			//typeahead re-rendered - set value if selected
			if(this.selected){
				this.typeaheadEl.typeahead('val', this.selected.label);
			}else if(this.defaultItems) {
				//make sure we also update our typeahead
				this.setOption(this.defaultItems, true);
			}

			//if options are showing, show them
			if(this.showDropDown){
				this.$('.typeahead-dropdown-' + this.cid).show();
			}
		},
		serializeData: function(){
			return {
				'ocName': this.model.get('ocName'),
				'cid': this.cid,
				'placeholder': this.placeholder,
				'options': this.options,
				'loading': this.disabled || (this.overrideLoading ? false : (this.loading ? (this.loading && this.loading.state() !== "resolved") : (!this.options || this.options.length === 0))),
				'tabIndex': this.tabIndex
			};
		},
		searchResultTemplate: function(){
			return Handlebars.compile('<p class="list-group-item typeahead-result typeahead-item" data-value="{{value}}">{{label}}</p>');
		},
		noResultTemplate: function(){
			if (this.isGrowable) {
				return Handlebars.compile('<p class="list-group-item typeahead-item">'+ window.localize("modules.search.advancedSearch.views.autoCompleteView.sorryPleaseHitTab") +'</p>');
			} else {
				return Handlebars.compile('<p class="list-group-item typeahead-item">'+ window.localize("modules.search.advancedSearch.views.autoCompleteView.sorryPleaseTryAgain") +'</p>');
			}
		}
	});

	return AutoCompleteView;
});