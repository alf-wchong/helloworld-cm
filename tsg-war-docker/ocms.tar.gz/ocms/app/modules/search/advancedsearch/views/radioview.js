// RadioView contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var RadioView = {};

    RadioView.View = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/views/radiocontrol",
		manage:false,
		events: {
			"keyup .searchParam" : "updateValue"
		},
		initialize: function(options){
			if(options){
				this.model = options.model;
			}
        },
        startListening: function(){
        	//RadioModel.__super__.startListening.apply(this, arguments);
        	this.stopListening(this.field, 'change:options');
           	this.listenTo(this.field, 'change:options', function(options){
           		this.concatedOptions = _.extend([], options);
	        	//only clear the answer if its not an availible option
        		if(!_.findWhere(this.concatedOptions, {value: this.field.getValue()})){
        			this.field.setValue();
        		}

                this.render();
            }, this);

            this.listenTo(this.field, 'change:allOptions', function(model, options){
           		this.concatedOptions = _.extend([], options);
	        	//only clear the answer if its not an availible option
        		if(!_.findWhere(this.concatedOptions, {value: this.field.getValue()})){
        			this.field.setValue();
        		}

                this.render();
            }, this);
	    },
        renderJustificationView : function(valueSelected){
            if(this.justificationViews[valueSelected] === undefined){
                //this.justificationViews[valueSelected] = new AbstractControl.JustificationView({model:this.field, valueUserSelected : valueSelected});
                this.field.get('justifications')[valueSelected] = this.field.get('justifications')[valueSelected] || "";
            }
            this.currentJustificationView = this.justificationViews[valueSelected];
            this.setView('.justification-output-'+ this.cid + '-' +_.pluck(this.field.get("options"),'value').indexOf(valueSelected), this.currentJustificationView).render();
        },

		check: function(evt){
			this.dontUpdateAgain = true;
			//We don't need to check on a click in the justification 
			if(!_.contains(evt.target.classList, 'justification')){
				//firefox doesn't support evt.srcElement
				var target = evt.currentTarget || evt.srcElement;
				if(_.contains(target.classList, "radio")){
					var value;
					if(this.$(target).attr('value')){
						value = this.$(target).attr('value');
					}else{
						value = $(target).find('.btn').val();
					}
					this.field.setValue(value);
					this.field.setDisplayValue(target.innerText.trim());
				}
			}
		},
		updateValue: function(e){
			//Here is where the model should be updated.
			this.model.queryObj.attrValues[0] = e.currentTarget.value;
		},
		afterRender: function(){
	    	//AbstractControl.prototype.afterRender.apply(this, arguments);
			//get selected radio button
			var value = this.field.getValue();
			this.$('[value="' + value + '"]').prop("checked", true);
			this.$('[value="' + value + '"]').toggleClass("active");
			//Need make sure the value actually gets set
			if(value && !this.dontUpdateAgain){
				this.field.setValue(value);
				this.field.setDisplayValue(value);
			}	
		},
		serializeData: function(){
			return {
				'options': this.concatedOptions,
				'cid': this.cid,
				'ocName' : this.options.attributes.ocName
			};
		}		
    });

	return RadioView;
});