define([
		"app",
		"moment",
		"handlebars"
	],

	function (app, moment, Handlebars) {

		// Create a new module.
		var DateboxView = {};

		// Constant that adds 23:59:59:999 to all from values to make them totally inclusive of the day
		var ROUND_UP_VALUE_TO_FIELD = DateboxView.ROUND_UP_VALUE_TO_FIELD = 86399999;

		DateboxView.View = Backbone.Marionette.ItemView.extend({
			template: "search/advancedsearch/views/dateboxcontrol",
			manage: false,
			initialize: function (options) {
				if (options) {
					this.model = options.model;
				}
			},
			onShow: function () {
				var self = this;
				this.$('.datepicker-lg').datepicker({
					changeMonth: true,
					changeYear: true,
					dateFormat: app.context.dateService.getJQueryDateFormat(app.context.currentApplicationConfig().get("dateFormat")),
					onClose: function (date, inst) {
						var tempDate = Date.parse(moment(date, app.context.currentApplicationConfig().get("dateFormat")).toDate());
						if (inst.id.indexOf("from") > -1) {
							self.model.queryObj.attrValues[0] = tempDate;
							// just got our from, so lets make sure our min date of the To field is after this
							$('#' + self.model.queryObj.attrName + 'toDate').datepicker("option", "minDate", date);
						} else if (inst.id.indexOf("to") > -1) {
							tempDate = tempDate + ROUND_UP_VALUE_TO_FIELD;
							self.model.queryObj.attrValues[1] = tempDate;
							// just got our to, so lets make sure our max date of the from field is after this
							$('#' + self.model.queryObj.attrName + 'fromDate').datepicker("option", "maxDate", date);
						}
					}
				});
			},
			onBlurMobile: function (evt) {
				this.hasFocus = false;
				this.field.setValue(this.$('.datepicker-mobile').val());
			},
			serializeData: function () {
				return {
					'ocName': this.model.attributes.ocName
				};
			}
		});

		return DateboxView;
	});