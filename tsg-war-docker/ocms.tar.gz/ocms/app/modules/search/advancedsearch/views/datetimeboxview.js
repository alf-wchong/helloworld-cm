define([
		"app",
		"moment",
		"handlebars"
	],

	function (app, moment, Handlebars) {

		// Create a new module.
		var DateTimeBoxView = {};

		// Constant that adds 59:999 to all from values to make them totally inclusive of the minute selected by the user.
		var ROUND_UP_VALUE_TO_FIELD = DateTimeBoxView.ROUND_UP_VALUE_TO_FIELD = 59999;

		DateTimeBoxView.View = Backbone.Marionette.ItemView.extend({
			template: "search/advancedsearch/views/datetimeboxcontrol",
			manage: false,
			initialize: function (options) {
				if (options) {
					this.model = options.model;
				}
			},
			onShow: function () {
				this.appConfigDateFormat = app.context.currentApplicationConfig().get("dateFormat");
				this.appConfigTimeFormat = app.context.currentApplicationConfig().get("timeFormat");
				this.jQueryDateFormat = app.context.dateService.getJQueryDateFormat(this.appConfigDateFormat);
				this.jQueryTimeFormat = app.context.dateService.getJQueryTimeFormat(this.appConfigTimeFormat);

				this.$('.datepicker-lg').datetimepicker({
					changeMonth: true,
					changeYear: true,
					dateFormat: this.jQueryDateFormat,
					timeFormat: this.jQueryTimeFormat,
					onClose: _.bind(this._datetimepickerOnClose, this),
					onSelect: this._datetimepickerOnSelect
				});
			},
			_datetimepickerOnClose: function (date, inst) {
				var momentDateUnix = moment(date, this.appConfigDateFormat + ' ' + this.appConfigTimeFormat).valueOf();

				if (inst.id.indexOf("from") > -1) {
					this.model.queryObj.attrValues[0] = momentDateUnix;
					// just got our from, so lets make sure our min date of the To field is after this
					$('#' + this.model.queryObj.attrName + 'toDate').datetimepicker("option", "minDate", date);
				} else if (inst.id.indexOf("to") > -1) {
					this.model.queryObj.attrValues[1] = momentDateUnix + ROUND_UP_VALUE_TO_FIELD;
					// just got our to, so lets make sure our max date of the from field is after this
					$('#' + this.model.queryObj.attrName + 'fromDate').datetimepicker("option", "maxDate", date);
				}
			},
			_datetimepickerOnSelect: function () {
				$(this).change();
			},
			onBlurMobile: function () {
				this.hasFocus = false;
				this.field.setValue(this.$('.datepicker-mobile').val());
			},
			serializeData: function () {
				return {
					'ocName': this.model.attributes.ocName
				};
			}
		});


		return DateTimeBoxView;
	});