// MultiSelectView contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var MultiSelectView = {};

    MultiSelectView.View = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/views/multiselectcontrol",
		manage:false,
		events: {
			"keyup .searchParam" : "updateValue"
		},
		initialize: function(options){
			if(options){
				this.model = options.model;
			}
		},
		onShow: function(){
			this.serializeData();
		},
		updateValue: function(e){
			//Here is where the model should be updated.
			this.model.queryObj.attrValues[0] = e.currentTarget.value;
		},
		serializeData: function(){
			return {
				'ocName' : this.options.attributes.ocName
			};
		}
    });

	return MultiSelectView;
});