// ProximityDateView contol module
define([
	"app",
	"handlebars"
],

function(app, Handlebars) {

	// Create a new module.
	var ProximityDateView = {};

    ProximityDateView.View = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/views/proximitydatecontrol",
		manage:false,
        // need to update the event to handle all 3 boxes changing
		events: {
			"change .searchParam" : "updateValue"
		},
		initialize: function(options){
			if(options){
				this.model = options.model;
			}
		},
		onShow: function(){
			this.serializeData();
		},
		updateValue: function(e){
			//Here is where the model should be updated.
			
			var proximityType = this.$('#proximityDateType').val();
			var proximityNumber = this.$('#proximityDateNumber').val();
			var proximityTimeSpan = this.$('#proximityDateTimeSpan').val();
			var value = '';
			
			// we only want to compute the value if all of the values have been filled in
			if (!proximityType || !proximityNumber || !proximityTimeSpan){
				return;
			}
			
			var proximityNumberAsInt = parseInt(proximityNumber, 10);
			var startDate = moment().startOf('day');
			var endDate = moment().startOf('day');
			
			if (proximityType.toLowerCase() === 'within'){
				startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
				endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
			} else if (proximityType.toLowerCase() === 'past') {
				startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
			} else { // next
				endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
			} 
			
			value = startDate.toDate().getTime() + '|' + endDate.toDate().getTime();
			
			// need to tack on the actual user input parameters that way we will be able to repopulate from a different
			// day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
			var proximityParams = '$*prx*$' + proximityType + '|' + proximityNumber + '|' + proximityTimeSpan;
			
			this.model.queryObj.attrValues[0] = value + proximityParams;
		},
		serializeData: function(){
			return {
				'ocName' : this.model.attributes.ocName
			};
		}
    });

	return ProximityDateView;
});