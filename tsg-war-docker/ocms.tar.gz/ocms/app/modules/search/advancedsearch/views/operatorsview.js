// Datebox contol module
define([
	"app"
],

function(app) {

	// Create a new module.
	var OperatorsView = {};

    OperatorsView.View = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/views/numericcontrol",
		manage: false,
		events: {
			"click .operatorOption" : "selectOperator"
		},
		initialize: function(options){
			if(options){
				this.model = options.model;
			}
		},
		selectOperator: function(e){
			this.model.attributes.operator = e.currentTarget.id;
			this.$("#" + this.model.get("ocName") + "OpsDropDown").text(e.currentTarget.textContent.trim());
			this.$("#" + this.model.get("ocName") + "OpsDropDown").append(" ");
			this.$("#" + this.model.get("ocName") + "OpsDropDown").append("<span class='caret'></span>");
			this.model.queryObj.operators[0] = e.currentTarget.id;
			app.trigger("operatorAdded", this.model);
		},
		serializeData: function(){
			return{
				'operatorsExist' : this.model.getOperators().length > 0,
				'operators' : this.model.getOperators,
				'ocName' : this.model.get('ocName')
			};
		}
    });

	return OperatorsView;
});