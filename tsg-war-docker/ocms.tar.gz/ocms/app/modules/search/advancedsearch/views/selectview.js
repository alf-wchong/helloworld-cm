// SelectView contol module
define([
	"app",
	"handlebars"
],

function(app, Handlebars) {

	// Create a new module.
	var SelectView = {};

    SelectView.View = Backbone.Marionette.ItemView.extend({
        template: "search/advancedsearch/views/selectcontrol",
		manage:false,
		events: {
			"change select" : "updateValue"
		},
		initialize: function(options){
			var self = this;
			if(options) {
				this.model = options.model;
			}

			
			app.context.picklistService.getPicklist(this.model.get('picklist'), function(data, defaultValues){
				self.options = data;
				self.render(data); 
			});
		},
		onShow: function(){
			this.serializeData();
		},
		updateValue: function(e){
			//Here is where the model should be updated.
			this.model.queryObj.attrValues[0] = e.currentTarget.value;
		},
		serializeData: function(){
			return {
				'ocName' : this.model.get('ocName'),
				'options' : this.options
			};
		}
    });

	return SelectView;
});