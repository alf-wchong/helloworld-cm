// Abstract View contol module
define([
	"app",
	"modules/search/advancedsearch/advancedsearchaspects",
	"modules/search/advancedsearch/views/operatorsview",
    "modules/search/advancedsearch/factory/viewfactory"
],

function(app, AdvancedSearchAspects, OperatorsView, ViewFactory) {

	// Create a new module.
	var AbstractView = {};

    AbstractView.View = Backbone.Marionette.LayoutView.extend({
        template: "search/advancedsearch/views/abstractcontrol",
		manage: false,
		regions: {
			controlView : "#controlView",
			advancedDropdown : "#advancedDropdown"
		},
		initialize: function(options){
            this.options = options;
		},
		onRender: function() {
			var self = this;
			if(this.model){
				this.getRegion("controlView").reset();
				ViewFactory.GetView(this.model).done(function(view){
					self.getRegion("controlView").show(view);
				});
			}	
            this.getRegion("advancedDropdown").show(new OperatorsView.View({model: this.model}));
	    },
		serializeData: function(){
			return {
				'label': this.model.get("label"),
				'advanced': _.contains(this.model.fieldAspects, 'operable')
			};
		}
    });
    
    
	return AbstractView;
});