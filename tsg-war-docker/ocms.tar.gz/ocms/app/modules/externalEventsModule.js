define([
    "app",
    "module",
    "modules/common/hpiconstants",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-util"
],
function(app, module, HPIConstants, CATUtil){
    var ExternalEventsModule  = app.module();
    var positionalAttributeName = module.config().positionalAttribute || HPIConstants.hpiMetadataPositions;
    // get the information from the selected input box and send a message to OA that we are going to use property indexing.
    ExternalEventsModule.initiateIndexerAnnotation = function(event, propertiesViewModel, oco) {
        if(this.tableSelectMode != true) {
            this.hasBoxSelected = true;
            this.inputBoxID = event.target.id;
            this.inputBoxName = event.target.name;
            this.listenTo(app.openAnnotate, "annotationUpdated", _.partial(ExternalEventsModule.processTextSelectModel,_,propertiesViewModel, oco));
            this.listenToOnce(app, 'blurInputBox', ExternalEventsModule.inputBoxDeselected);
            app.openAnnotate.trigger("newTextSelectRequested");
        }
    },

    // Set up the table select mode function call we will use when the user selects the first column header
    ExternalEventsModule.intiateTableSelectMode = function(event, propertiesViewModel) {
        this.listenTo(app.openAnnotate, "annotationUpdated", _.partial(ExternalEventsModule.tableSelection,_,propertiesViewModel));
        app.openAnnotate.trigger("newTextSelectRequested");
    },

    ExternalEventsModule.initiateCaptureAnnotation = function(event, propertiesViewModel) {
        // do we ever use form support to refer to a button's input directly without referring
        // to html
        this.listenTo(app.openAnnotate, "annotationUpdated", _.partial(ExternalEventsModule.processAnnotationModel,_,propertiesViewModel));
        this.listenToOnce(app.openAnnotate, "annotationCaptureCompleted", function() {

            //Since initiateCaptureAnnotation is called every time a new annotation is made,
            //multiple event listeners pile up for the same action. This is an attempt to 
            //clean them up. I'm making the assumption that no other functions are listening
            //for the "annotationUpdated" event, which may be wrong.
            this.stopListening(app.openAnnotate, "annotationUpdated");
        });
        app.openAnnotate.trigger("newRectangleAnnotationRequested");
    },

    ExternalEventsModule.createHighlightAnnotation = function(location) {
        app.openAnnotate.trigger("highlightAnnotationRequested", location);
    },

    ExternalEventsModule.removeAllAnnotations = function() {
        app.openAnnotate.trigger("removeAllAnnotationsRequested");
    },

    ExternalEventsModule.removeHighlightAnnotations = function() {
        app.openAnnotate.trigger("removeHighlightAnnotationsRequested");
    },

    ExternalEventsModule.locatesAnnotationPosition = function(positionalData) {
        //Since it is impossible to simultaneously scroll the viewport to draw attention
        //to all objects in the array, arbitrarily scroll to the first one
        app.openAnnotate.trigger("locatesAnnotationPosition", positionalData[0]);
    },

    ExternalEventsModule.createTextSelect = function(positionalData) {
        app.openAnnotate.trigger("textSelectRequested", positionalData);
    },

    //Stops listening for text select data
    ExternalEventsModule.inputBoxDeselected = function() {
        this.inputBoxID = "";
        this.inputBoxName = "";
        this.stopListening(app.openAnnotate, "annotationUpdated");
        this.hasBoxSelected = false;
    },

    /** 
     * Updates indexer form when table select mode is on and the first table header columns text is selected
     * By first, we are referring to the uppermost, and furthest left
     * 
     * @param{Object} childAppModel -- Model that OA is sending. Either contains annotation model or textSelect model.
     * @param{Object} propertyViewModel -- OCMS model to be updated.
     */
    ExternalEventsModule.tableSelection = function (childAppModel) {
        this.stopListening(app.openAnnotate, "annotationUpdated");

        // Adjust the coordinates/page to fit what Suggestr will be expecting
        var convertedCoords = CATUtil.tSCoordsToCaptureCoords.call(this, childAppModel.selectedArea);
        convertedCoords.pageNum = childAppModel.page;
        this.getTableSuggestions(convertedCoords);
    },

    /** 
     * Updates OCMS models when child app (OA) sends back information. Populates textbox with text if OA
     * sends back textSelect data.
     * @param{Object} textSelectModel -- Model sent by child app representing selected area on a page and its contents
     * @param{Object} propertyViewModel -- OCMS model to be updated with textSelectModel data.
     * @param{Object} oco -- OCO to update with metadata changes based on textSelectModel returned by OA
     */
    ExternalEventsModule.processTextSelectModel = function(textSelectModel, propertiesViewModel, oco) {
        
        if(textSelectModel.selectedText) {

            //update the inputbox value to display to the user AND the object so the information is saved
            //once that is done, automatically change to the next input box to add information.

            //check if the indexed value is a valid date
            var control = _.findWhere(propertiesViewModel.controls(),{id:this.inputBoxName});
            //pull the acceptable date formats (some others are accepted but not included)
            var validDateFormats = module.config().acceptedDateFormats;
            //pull the output date format based on the selected format in the admin config, timezones don't work because no time is selected.
            var outputDateFormat = app.context.currentApplicationConfig().get("dateFormat");

            if(control.controlType == HPIConstants.controlTypes.DateBox){
                if(moment(textSelectModel.selectedText,validDateFormats).isValid()){
                    //format that date to our typical date format
                    textSelectModel.selectedText = moment(textSelectModel.selectedText,validDateFormats).format(outputDateFormat);
                    control.dateDisplay(textSelectModel.selectedText);
                    this.$("#ui-datepicker-div").hide(); //hide the jquery datepicker popup
                    ExternalEventsModule.afterNonRepeatingSelection.call(this, propertiesViewModel);
                }
            } else {
                if (control.controlType === HPIConstants.controlTypes.TextBox) {
                    textSelectModel.selectedText = textSelectModel.selectedText.replace(/[\n\r]/g, ' ').replace(/(\s)+/g, ' ').trim();
                }
                //need to push to array and keep focus on control if its repeating
                if (control.isRepeating) {
                    //intialize value to an empty array so we have something to push to
                    if(!control.value()){
                        control.value([]);
                    }
                    control.value.push(textSelectModel.selectedText);
                    ExternalEventsModule.afterRepeatingSelection.call(this);
                } else {
                    control.value(textSelectModel.selectedText);
                    ExternalEventsModule.afterNonRepeatingSelection.call(this, propertiesViewModel);
                }
            }

            //Check if storing positional data is enabled in the admin configs
            var positionDataEnabled = false;
            if (this.config.actionId === HPIConstants.Actions.BulkUpload) {
                positionDataEnabled = this.config.get("positionDataEnabled");
            } else if (this.config.get("type") === "IndexerConfig"){
                var typeConfig = this.config.get("types").findWhere({ocName:propertiesViewModel.objectType()});
                if(typeConfig) {
                    positionDataEnabled = typeConfig.get("positionDataEnabled");
                }
            }
            
            // Save positional data if enabled/possible
            if (positionDataEnabled && oco) {

                //Assign the page number to each individual rectangle...currently in OA, all textSelect
                //rectangles are guaranteed to be on the same page but that is an unnecessary restriction for OCMS
                _.each(textSelectModel.selectedArea, function(area) {
                    area.page = textSelectModel.page;
                });

                // Create the object if it doesn't exist yet
                var ocoProps = oco.get("properties");
                var posProp = ocoProps[positionalAttributeName];
                if (!posProp) {
                    posProp = '{}';
                }

                //Set the positional metadata for the current attribute
                var stringToJson = JSON.parse(posProp);
                stringToJson[control.id] = textSelectModel.selectedArea;

                // Save the string back to the oco
                ocoProps[positionalAttributeName] = JSON.stringify(stringToJson);
                oco.set("properties", ocoProps);

                //When Suggestion Mode is enabled in indexer, set user feedback coordinates here
                if(this.acceptingCorrections) {
                    this.corrections[control.id] = textSelectModel.selectedArea;
                }
            }
        }
    },

    /**
     * Keeps focus on the current control and reset to be able to use text select to grab values again.
     */
    ExternalEventsModule.afterRepeatingSelection = function () {
        var currentInputBoxID = this.inputBoxName;
        this.$("#" + currentInputBoxID).focus();
        app.openAnnotate.trigger("newTextSelectRequested");
    },

    /**
     * Removes focus from current control and switches focus to the next one.
     * @param{Object} propertyViewModel -- OCMS model containing the controls
     */
    ExternalEventsModule.afterNonRepeatingSelection = function (propertiesViewModel) {
        var currentInputBoxID = this.inputBoxName;
        this.trigger("blurInputBox");
        ExternalEventsModule.changeInputFocus.call(this, currentInputBoxID, propertiesViewModel);
    },

    /** 
     * Updates OCMS model when child app (OA) sends back information about an annotation.
     * @param{Object} annotationModel -- Annotation model that OA is sending
     * @param{Object} propertyViewModel -- OCMS model to be updated.
     */
    ExternalEventsModule.processAnnotationModel = function(annotationModel, propertiesViewModel) {
        var xfdfFields = annotationModel.xfdfFields;
        var viewerData = annotationModel.viewerData;

        //If returing positional data about a rectangle annotation
        if(xfdfFields && xfdfFields.type === "Rectangle") {

            //Update positional data on the OCMS model
            propertiesViewModel.set("x", viewerData.x/xfdfFields.zoom);
            propertiesViewModel.set("y", viewerData.y/xfdfFields.zoom);
            propertiesViewModel.set("height", viewerData.height/xfdfFields.zoom);
            propertiesViewModel.set("width", viewerData.width/xfdfFields.zoom);
            propertiesViewModel.set("top", viewerData.y/xfdfFields.zoom);
            propertiesViewModel.set("bottom", (viewerData.y + viewerData.height)/xfdfFields.zoom);
            propertiesViewModel.set("left", viewerData.x/xfdfFields.zoom);
            propertiesViewModel.set("right", (viewerData.x + viewerData.width)/xfdfFields.zoom);
            propertiesViewModel.set("pageNum", xfdfFields.page);
        }
        
    },

    ExternalEventsModule.changeInputFocus = function (currentInputBoxID, propertiesViewModel) {
        var quickSelectControlArray = propertiesViewModel.quickSelectControls();
        var quickSelectControlIds = [];
        _.each(quickSelectControlArray, function (control) {
            quickSelectControlIds.push(control.id);
        });
        var inputIndex = _.indexOf(quickSelectControlIds, currentInputBoxID);
        var currentId = null;
        //focus on the next input field unless it's the last one in the quickSelectControlIds array
        if (inputIndex + 1 !== quickSelectControlIds.length) {
            //get the current id (some fields get the uuid appended onto their id)
            currentId = document.getElementsByName(quickSelectControlIds[inputIndex+1])[0].id;
            this.$("#" + currentId).focus();
        } else {
            //blur last element
            if(quickSelectControlIds && quickSelectControlIds.length){
                currentId = document.getElementsByName(quickSelectControlIds[inputIndex])[0].id;
            } else {
                currentId = currentInputBoxID;
            }
            this.$("#" + currentId).blur();
        }
    };

    return ExternalEventsModule;
});