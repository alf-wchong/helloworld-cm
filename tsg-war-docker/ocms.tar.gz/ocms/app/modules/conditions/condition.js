define([
	'app'
], function(app){
	
	var Condition = {};

	Condition.Model = Backbone.Model.extend({
		defaults: _.extend({}, {
				name: '',
				parameters: {},
				status: 'valid',
				message: 'invalid condition',
				required: false,
				group: null
		}),
		initialize: function(options){
			this.options = _.defaults(options, this.defaults);
			this.set(this.options);
			this.invalidConditionMessage = this.options.name + ': invalid condition';
		},
		getName: function(){
			return this.get('name');
		},
		getMessage: function(){
			return this.get('message') || this.invalidConditionMessage;
		},
		getStatus: function(){
			return this.get('status');
		},
		validate: function(){
			var reason;
			if(this.get('status') === 'invalid'){
				reason = this.get('message') || this.invalidConditionMessage;
			}
			return reason;
		}
	});

	Condition.Collection = Backbone.Collection.extend({
		model: Condition.Model,
		initialize: function(options){
			if(options.nodeIds || options.nodeId) {
				this.nodeIds = options.nodeIds || [options.nodeId];
			}
			this.conditions = options.conditions || [options.condition];
			this.parameters = options.parameters;
		},
		url: function(){
			var url = app.serviceUrlRoot + '/condition/evaluate?';
			_.each(this.conditions, function(condition){
				if(this.conditions.length === 1){
					url += 'conditionBeanId=' + condition + '&';
				}else{
					url += 'conditionBeanIds=' + condition + '&';
				}
			}, this);
			if(this.nodeIds) {
				_.each(this.nodeIds, function(nodeRef){
					if(this.nodeIds.length === 1){
						url += 'nodeId=' + nodeRef + '&';
					}else{
						url += 'nodeIds=' + nodeRef + '&';
					}
				}, this);
			}
			//chop off any trailing &
			if(url.substring(url.length - 1, url.length) === '&'){
				url = url.substring(0, url.length - 1);
			}
			return url;
		},
		getMessages: function(){
			var messages = [];
			this.each(function(condition){
				if(!condition.isValid()){
					messages.push(condition.getMessage());
				}
			}, this);
			return messages.join(', ');
		},
		validateCollection: function(){
			var isValid = true;
			this.each(function(condition){
				if(isValid){
					isValid = condition.isValid();
				}
			}, this);
			return isValid;
		},
		parse: function(rawJson){
			return rawJson;
		}
	});

	return Condition;
});