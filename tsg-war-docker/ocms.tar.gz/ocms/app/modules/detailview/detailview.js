// Searchresults module
define([
    // Application.
    "app",
    "knockout",
    "knockback",
    "oc",
    "modules/common/action",
    "moment",
    "modules/formsupport"
],

// Map dependencies from above array.
function(app, ko, kb, OC, Action, moment, FormSupport) {

    // Create a new module.
    var DetailView = app.module();

    DetailView.RenditionViewModel = function(model) { 
        var self = this;
        
        self.hidden = ko.observable();

        self.properties = kb.observable(model, "properties");
            self.model = model;

        self.thumbnailUrl = ko.observable();
        self.contentUrl = ko.observable();

        model.getThumbnail("medium", function(url) { 
            self.thumbnailUrl(url);
        });

        model.getContentUrl(function(url) {
            self.contentUrl(url);
        });

        self.downloadAsset = function() {
            if(self.contentUrl()) { 
               
                var hiddenIFrameID = 'hiddenDownloader',
                    iframe = document.getElementById(hiddenIFrameID);
                    if (iframe === null) {
                        iframe = document.createElement('iframe');
                        iframe.id = hiddenIFrameID;
                        iframe.style.display = 'none';
                        document.body.appendChild(iframe);
                    }
                iframe.src = self.contentUrl();
                
            }
            else { 
                app.log.error(window.localize("modules.detailView.detailView.cannotURLIsNot"));
            }
        };

        // hide if its of these types
        self.hiddenTypes = ['cm_thumbnail', 'cm_failedThumbnail'];
        // of if its one of these renditions
        self.hiddenRenditionTypes = ['hpiPreview'];

        if(_.indexOf(self.hiddenTypes, model.get("objectType")) !== -1) { 
            self.hidden(true);
        }
        if(_.indexOf(self.hiddenRenditionTypes, model.get("properties").hpi_previewType) !== -1) {
            self.hidden(true);
        }
    };

    DetailView.OverviewAttrModel = function(config, propertiesObservable) { 
        // return the class method so we can use inheritance AND pass in the config
        return kb.ViewModel.extend({
            constructor: function(model, options) { 
                var self = this;
                kb.ViewModel.prototype.constructor.apply(self, arguments, options);
                
                self.label = ko.observable();
                app.context.configService.getLabels(config.get("objectType"), model.get("ocName")).done(function(label) {
                    self.label(label);
                });

                self.value = ko.computed(function() { 
                    var value = propertiesObservable()[model.get("ocName")];
                    return value;
                });

                return self;
            }
        });
    };

    DetailView.FieldSetViewModel = function(fullConfig, propertiesObservable) { 
        // return the class method so we can use inheritance AND pass in the config
        return kb.ViewModel.extend({ 
            constructor: function(model, options) { 
                var self = this;
                kb.ViewModel.prototype.constructor.apply(this, arguments, options);

                // mixin backbone events
                _.extend(self, Backbone.Events);

                var Field = function(label, value) { 
                    return {
                        label: ko.observable(label),
                        value: ko.observable(value)
                    };
                };

                self.desiredFields = kb.observable(model, "fields");

                self.fields = ko.computed(function() { 
                    var set = [];
                    _.each(self.desiredFields(), function(configField) {
                        var fieldKey = configField.ocName();
                        var newField = new Field(fieldKey, propertiesObservable()[fieldKey]);
                        set.push(newField);
                    });
                    return set;
                });

                _.each(self.fields(), function(field) { 
                    app.context.configService.getLabels(fullConfig.get("objectType"), field.label()).done(function(label) {
                        field.label(label);
                    });    
                });

                return self;
            }
        });
    };

    DetailView.MediaDisplayModel = function(model, mediaConfig) { 
        // check if the format is eligible for preview
        var self = this;
        self.model = model;
        self.config = mediaConfig;
        
        // store some helper observables if we want to do anything unique
        self.format = ko.observable(self.config.type);
        self.mimetype = ko.observable(self.config.mimetype);

        // the content url that will be retrieved
        self.contentUrl = ko.observable();
        
        // determine what type of media we have and get its content url
        var childRendition = _.find(self.model.get("children").models, function(child) {
            return child.get("properties").hpi_previewType === self.config.renditionName;
        });
        if(childRendition) { 
            childRendition.getContentUrl(function(contentUrl) { 
                self.contentUrl(contentUrl);
            });
        } 
        else { 
            app.log.error(window.localize("modules.detailView.detailView.couldNotRetrieve") + self.config.renditionName + window.localize("modules.detailView.detailView.forThisAsset"));
        }

                
        return self;
    };

    DetailView.ViewModel = function(model, options) {

            var self = this;
            self.objectType = kb.observable(model, "objectType");
            self.config = options.config;

            self.showMediaPlayer = ko.observable(false);
            self.videoUrl = ko.observable();
        
            self.relations = ko.observableArray();

            self.pageLoaded = ko.observable(false);

            // flag indicating whether or not to generate a back to results button (passed all the way from the route)
            self.isBackAvailable = ko.observable(options.isBackAvailable);

            self.canWrite = ko.observable(false);

            if(!self.objectType()) { 
                app.log.error(window.localize("modules.detailView.detailView.objectTypeFor"));
            } else { 

                var typeConfig = self.config.get("types").findWhere({ objectType: self.objectType() });
                if(typeConfig) { 
                    
                    /***************************
                    SET UP PROPERTIES ON THE MODEL
                    ***************************/
                    self.properties = kb.observable(model, "properties");
                    self.fieldSets = kb.collectionObservable(typeConfig.get("fieldsets"), { 
                        factories: {
                            "models": DetailView.FieldSetViewModel(typeConfig, self.properties)
                        }
                    }); 

                    /****************************
                    OVERVIEW ATTRIBUTES (TOP METADATA)
                    ****************************/
                    if(typeConfig.get("overviewAttrs").models.length > 0) {
                        app.log.debug("Found overview attrs in config for this type...");
                        self.overviewAttrs = kb.collectionObservable(typeConfig.get("overviewAttrs"), {
                            view_model: DetailView.OverviewAttrModel(typeConfig, self.properties)
                        });
                    } else {
                        // if we dont have overview attrs configured, lets default to some basics
                        app.log.debug(window.localize("modules.detailView.detailView.noConfiguredOverview"));
                        self.overviewAttrs = ko.observableArray();
                    }

                    //self.fieldSets = kb.collectionObservable          

                } else {
                    app.log.error(window.localize("modules.detailView.detailView.noConfigFor"));
                    self.fieldSets = ko.observableArray();
                    self.overviewAttrs = ko.observableArray();
                }
            }

            self.renditions = kb.collectionObservable(model.get("children"), {
                factories: {
                    "models": DetailView.RenditionViewModel
                }
            });

            // media format map
            var formatMap = [
                {
                    mimetype: "video/mp4",
                    type: "video",
                    renditionName: "hpiPreview"
                },
                {
                    mimetype: "audio/x-m4a",
                    type: "audio",
                    renditionName: "hpiPreview" 
                },
                {
                    mimetype: "audio/mp3",
                    type: "audio",
                    renditionName: "hpiPreview"
                },
                {
                    mimetype: "audio/mpeg",
                    type: "audio",
                    renditionName: "hpiPreview"
                }
            ];

            if(_.pluck(formatMap, "mimetype").indexOf(model.get("properties").Document) !== -1) {
                
                // get our little config instance
                var mediaConfig = _.findWhere(formatMap, {mimetype: model.get("properties").Document});

                self.showMediaPlayer(true);
                self.mediaDisplay = new DetailView.MediaDisplayModel(model, mediaConfig);    
            }

            self.play = function(elem, element) { 
                $("video")[0].play();
                //$(".asset-preview video").find("video").play();
            };

            self.thumbnailUrl = ko.observable();
            model.getThumbnail("large", function(thumbUrl) {
                self.thumbnailUrl(thumbUrl);
            });

            //get the action configs and store them in an easy to access map for later use in the viewmodel
            var _actions = [];
            var _actionConfigMap = {};
            // pull these from the detailview config
            if(self.config.get("actions").models.length > 0) {
                self.config.get("actions").each(function(actionConfig){
                    // check if the action is applicable from the additional params
                    var otherProps = actionConfig.get("otherProperties");
                    var applicableTypesProp = otherProps.filter(function(prop) {
                        return prop.get("key") === "applicableTypes";
                    });
                    // if there is no appliableType config for this action, add it
                    if(!applicableTypesProp || applicableTypesProp.length < 1) { 
                        _actions.push( new Action.Model({actionId : actionConfig.actionId, ocActionId : actionConfig.get("ocActionId") || actionConfig.actionId}));
                        _actionConfigMap[actionConfig.actionId] = actionConfig;
                    }
                    // otherwise check the type before adding
                    else {
                        var types = applicableTypesProp[0].get("value");
                        var typesArray = types.split(",");
                        _.each(typesArray, function(type) {
                            // if our object matches one of the types
                            if(type.trim() === self.objectType()) { 
                                // add it
                                 _actions.push( new Action.Model({actionId : actionConfig.actionId, ocActionId : actionConfig.get("ocActionId") || actionConfig.actionId}));
                                _actionConfigMap[actionConfig.actionId] = actionConfig;                          
                            }
                        });
                    }


                });
            } else { 
                app.log.debug(window.localize("modules.detailView.detailView.thereAreNoActions"));
            }    

            self.ActionViewModel = kb.ViewModel.extend({
                constructor: function(model) {      

                    kb.ViewModel.prototype.constructor.call(this, model, {keys: ["actionId"]});          
                    
                    var self = this;   
                    
                    self.label = _actionConfigMap[model.get("actionId")].get("label");
                    
                    self.execute = function() {
                        app[_actionConfigMap[model.get("actionId")].get("handler")].trigger("show", {
                            action: model, 
                            config: _actionConfigMap[model.get("actionId")]
                        });
                    };
                }
            });

            //_actions.push(new Action.Model({ actionId: "createRelationships"}));
            var actionCollection = new Action.Collection(_actions, {objectId : model.get("objectId")});
            self.actions = kb.collectionObservable(actionCollection, { view_model: self.ActionViewModel });
            
            actionCollection.fetch({
                global: false,
                success: function(coll) { 
                    app.log.debug(window.localize("modules.detailView.detailView.detailViewActionsEval"));
                    Action.filterActions(coll);
                },
                error: function(coll) {
                    app.log.error(window.localize("modules.detailView.detailView.failedToEvalActions"));
                    actionCollection.reset();
                }
            });

            // relations
            self.getRelatedAssets = function(reset) { 
                
                if(reset !== undefined && reset === true) {
                    app.log.debug(window.localize("modules.detailView.detailView.resettingRelationships"));
                    
                    var copy = model.clone();
                    copy.unset("relations");
                    copy.set("relations", []);

                    model = copy;

                    self.relations.removeAll();
                    self.relations([]);
                }
                

                self.config.get("relations").each(function(relationConfig, itx){
      
                    var deferred = model.getRelatedObjects(relationConfig.get("relationName"), relationConfig.get("type"));    
                    deferred.done(function() {
                        //_.each(model.get("relations"), function(relation, idx) {
                        var relations = _.where(model.get("relations"), {relationName: relationConfig.get("relationName"), parentOrChild: relationConfig.get("type") });
                        _.each(relations, function(relation, idx) {
                            self.relations.push(new OC.RelationViewModel(relation, { config: relationConfig, ocObject: model }));
                        });
                    });
                });
    
            };         

            // go back to the search page
            self.backToSearch = function() {
                window.history.back();
            };

            model.canWrite(function(canWrite) { 
                self.canWrite(canWrite);
                if(self.canWrite() === true) {
                    app.log.debug(window.localize("modules.detailView.detailView.userHasWritePermissions"));
                }
                else {
                    app.log.debug(window.localize("modules.detailView.detailView.userDoesNot"));
                }
            });    

            return self;
    };

    DetailView.Views.Layout = Backbone.Layout.extend({

        template: "detailview/detailview",

        initialize: function() { 

            var self = this;
            self.model = this.options.model;
            self.config = this.options.config;
            self.name = "detailview";
            self.isBackAvailable = this.options.isBackAvailable;

        },

        beforeRender: function() { 
            var self = this;
            self.setViews({
                "#form-support" : new FormSupport.View()
            });
        },

        afterRender: function() { 
            var self = this;
            var deferredModel = self.model.fetch();
            var deferredConfig = self.config.fetch();
            var deferredChildRetrieval = self.model.getChildren();


            $.when(deferredModel, deferredConfig, deferredChildRetrieval).done(function() { 

                
                self.model.formatProperties().done(function() { 
                    app.log.debug(window.localize("modules.detailView.detailView.propertiesFormatted"));
                    
                    self.vm = window.dvm = new DetailView.ViewModel(self.model, {config: self.config, isBackAvailable: self.isBackAvailable });

                    self.vm.getRelatedAssets();

                    // set up asset preview modal
                    self.model.getContentUrl(function(thumbUrl) {
                        self.$el.find("#detail-modal img").attr("src", thumbUrl);
                        self.$el.find("#detail-modal").modal({
                            backdrop: true,
                            show: false
                        });
                        self.$el.find("#detail-modal .modal-body").css({ 'max-height': 'none' });

                    });  

                    self.$el.find("#detail-modal").on("show", function() { 
                        $(this).width($(this).find("#detail-modal img").width());

                        var margin = ($(window).width() - $(this).width()) / 2;
                        $(this).css({ "margin-left" : margin });
                    });

                    $("div.detailview").show();
                    self.vm.pageLoaded(true); 
                
                    kb.applyBindings(self.vm, self.$el[0]);
                    
                    app.log.debug("Detail View Rendered.");
    
                });


            });

            $.when(deferredModel, deferredConfig, deferredChildRetrieval).fail(function() { 

                self.vm = {
                    pageLoaded: ko.observable(false)
                };

                app.trigger("alert:error", {
                    header: window.localize("modules.detailView.detailView.errorLoadingAsset"),
                    message: window.localize("modules.detailView.detailView.thisIsNotAVaildAsset")
                });

                kb.applyBindings(self.vm, self.$el[0]);

            });

            // just use the built in stage listener (triggered by viewproperties.js)
            self.listenTo(app, "stage.refresh.documentId", function() {
                app.log.debug(window.localize("modules.detailView.detailView.refreshingDetails"));

                app.routers.detailView.details(app.context.configName(), self.model.get("objectId"), true);
                $("div.modal-backdrop").hide();
                $("div.modal-wrapper").hide();
                $("body").css({ 'overflow': 'auto' });
            });

            self.listenTo(app, "refreshRelationships", function() { 
                app.log.debug(window.localize("modules.detailView.detailView.refreshRelationships"));
                self.vm.getRelatedAssets(true);
            });

            app.log.debug(window.localize("modules.detailView.detailView.afterRender"));

        }

    });

    // Return the module for AMD compliance.
    return DetailView;

});