define([
    'app',
    'modules/wizard/events/pageeventmanager'
], function(app, PageEventManager) {

    var evaluateIfLastPage = function() {
        return this.psi.get('flowpath').length === 1 + this.activePageIndex;
    };

    var NavigationControlsView = Backbone.Layout.extend({
        template: 'wizard/navigationcontrols',
        events: {
            'click .nav-ctrl-previous': 'previousPressed',
            'click .nav-ctrl-next': 'nextPressed'
        },
        initialize: function(config) {
            this.state = {
                prevBtnEnabled: false
            };

            this.ui = {};
            this.psi = config ? config.psi : {};
            this.activePageIndex = config.activePageIndex;

            if (this.psi.get('pages').at(this.activePageIndex - 1)) {
                this.state.prevBtnEnabled = true;
            }

            this.isLastPage = evaluateIfLastPage.call(this);
            this.listenTo(this.psi.get('flowpath'), 'change add remove reset', function() {
                this.isLastPage = evaluateIfLastPage.call(this);
            }, this);

            return this;
        },
        previousPressed: _.debounce(function(evt) {
            evt.preventDefault();

            PageEventManager.trigger('activeform:flowpath:intendToChange', this.activePageIndex, this.activePageIndex - 1, this);
        }, 300, true),
        nextPressed: _.debounce(function(evt) {
            evt.preventDefault();

            if (this.isLastPage) {
                PageEventManager.trigger('activeform:flowpath:intendToChange', this.activePageIndex, 'summary', this);
            } else {
                PageEventManager.trigger('activeform:flowpath:intendToChange', this.activePageIndex, this.activePageIndex + 1, this);
            }

        }, 300, true),

        disablePrevBtn: function() {
            this.state.prevBtnEnabled = false;
            return this;
        },
        updateUI: function() {
            if (this.rendered) {
                this.ui.navctrlprevious = this.$('.nav-ctrl-previous');
                this.ui.navctrlprevious.prop('disabled', !this.state.prevBtnEnabled);
            }
            return this;
        },
        afterRender: function() {
            this.rendered = true;
            return this.updateUI();
        }
    });

    return NavigationControlsView;
});