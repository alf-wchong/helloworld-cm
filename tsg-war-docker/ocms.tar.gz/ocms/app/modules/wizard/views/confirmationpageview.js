define([
    'app'
], function(app){

    var ConfirmationPageView = Backbone.Layout.extend({
        template: 'wizard/confirmationpage',

        initialize: function(config){
            this.objectId = config.objectId;
            this.iframeHeight = 700;
            this.iframeWidth = 910;
        },
        afterRender: function() {
            if(!this.rendered) {
                var height = $('html').height() * 0.8;
                var width = this.$('.width-baseline-conf-page').width();
                this.iframeHeight = height;
                this.iframeWidth = width;
                this.rendered = true;
                this.render();
            }
        },
        serialize: function() {
            return {
                'serviceURL': app.serviceUrlRoot,
                'objectId'  : this.objectId,
                'iframeHeight' : this.iframeHeight,
                'iframeWidth' : this.iframeWidth
            };
        }

    });

    return ConfirmationPageView;
});
