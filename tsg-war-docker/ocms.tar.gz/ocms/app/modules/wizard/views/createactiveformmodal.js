define([
	'app',
	'modules/common/typeahead'
], function(app, HPITypeahead){

	var psiModal = Backbone.Layout.extend({
		template: 'wizard/createactiveformmodal',
		events: {
            'keydown'                   : 'disableDefault',
			'click .createActiveForm'	: 'createActiveForm'
		},
		initialize: function(formTypes){
			this.formTypes = new Backbone.Collection(formTypes);

			this.typeahead = new HPITypeahead({
       			options: this.formTypes,
       			displayKey: 'pageSetName',
				searchOn: 'pageSetName'
       		});

       		this.listenTo(this.typeahead, 'change:selected', function(option){
       			this.name = option ? option.pageSetName : undefined;
       		}, this);
		},
        disableDefault : function(evt){
            var code = evt.keyCode || evt.which;
            if(code == 13){
                evt.preventDefault();
                if(this.name){
                    this.createActiveForm(evt);
                }
            }
        },
		changeType: function(evt){
			var code = evt.keyCode || evt.which;
            this.name = this.$('select.activeform option:selected').text();
            if(code === 13) {
                evt.preventDefault();
                this.createActiveForm(evt);
            }
		},
		createActiveForm: function(evt){
			var form = this.formTypes.findWhere({'pageSetName': this.name});
			this.trigger('activeform:create', form);
			this.$(this.el).modal('hide');
			app.trigger('alert:close');
		},
		show: function(){
			this.$(this.el).modal('show');
		},
		beforeRender: function(){
            this.setView('.typeahead-outlet', this.typeahead);
		},
		serialize: function(){
			return {
				cid: this.cid
			};
		}
	});

	return psiModal;
});