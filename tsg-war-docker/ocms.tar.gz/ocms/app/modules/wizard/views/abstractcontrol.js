define([
	'app',
    'URIjs/URI',
    'modules/wizard/events/questioneventmanager'
], function(app, URI, QuestionEventManager){

    var updateClassName = function(currentClassName, config) {
        if(config.isInForm) {
            if(currentClassName) {
                return currentClassName + " form-control";
            } else {
                return "form-control";
            }
        }
    };

	var AbstractControl = Backbone.Layout.extend({
		initialize: function(options){
			this.ui = {};
			this.options = _.extend({}, options);
            this.question = this.options.question;
            this.field = this.options.field;
            this.elId = this.options.elId;

            this.className = updateClassName(this.className, options);

			this.startListening();

            this.justificationViews = {};
            this.currentJustificationView = null;
        },
        startListening: function(){
            this.stopListening(this.field);
            this.listenTo(this.field, 'change:value', this.onValueChange, this);
            this.listenTo(this.field, 'change:displayValue', this.onDisplayValueChange, this);
            this.listenTo(this.field, 'change:options', function(options){
                this.render();
            }, this);

            this.listenTo(this.field, 'justification:action', this.renderJustificationView);
        },
        renderJustificationView : function(valueSelected, remove){
            if(this.justificationViews[valueSelected] === undefined){
                this.justificationViews[valueSelected] = new AbstractControl.JustificationView({model:this.field, valueUserSelected : valueSelected});
                this.field.get('justifications')[valueSelected] = this.field.get('justifications')[valueSelected] || "";
            }
            if(remove){
                this.justificationViews[valueSelected].remove();
            } else{
				this.currentJustificationView = this.justificationViews[valueSelected];
				this.setView('.justification-output-'+ this.cid, this.currentJustificationView).render();
			}
        },
		onValueChange: function(evt){
            var fieldValue = this.field.getValue();
            if(fieldValue && _.isObject(fieldValue)){
                fieldValue = fieldValue.value;
            }
            if(this.currentJustificationView && this.field.get('justifications')[fieldValue] === undefined){
                this.currentJustificationView.remove();
            }
             //valid justification
            if(this.field.get('justifications') && this.field.get('justifications')[fieldValue] !== undefined){
                this.renderJustificationView(fieldValue);
            }
            this.render();
		},
        onDisplayValueChange: function(){
            this.render();
        },
        renderAnyExistingJustifications: function(fieldValue){
            if(fieldValue){
                var self = this;
                if(_.isArray(fieldValue)) {
                    _.each(fieldValue, function (value) {
                        if(this.field.get('justifications') && this.field.get('justifications')[value] !== undefined){
                           self.renderJustificationView(value);
                        }
                    }, this);
                }
                else{
                    var value = fieldValue;
                    //if an object, use the value as a key otherwise expect the string to be that value
                    if(_.isObject(fieldValue)){
                        value = fieldValue.value;
                    }
                    if(this.field.get('justifications') && this.field.get('justifications')[value] !== undefined){
                        self.renderJustificationView(value);
                    }
                }
            }
        },
		renderExternalLink: function(){
			if(this.field.hasAspect('linkable')){
                 var externalLink = new AbstractControl.ExternalLink({
                    'field': this.question.get('field'),
                    'url': this.question.get('field').get('temporary_properties').external_link
                });
				this.setView('.external-link-' + this.cid, externalLink).render();
			}
		},
        afterRender: function() {
            this.$el.attr('id', this.elId);
            //put value of this question in a data-binding to preserve it for formatting-on-the-fly
            this.$el.data('rawData', this.field.get('value'));
            this.startListening();
            this.renderAnyExistingJustifications(this.field.get('value'));
        },
		serialize: function(){
            return {
                'cid': this.cid,
                'model': this.field ? this.field.attributes : {},
                'disabled': this.field.isDisabled()
            };
        }
	});

    AbstractControl.JustificationView = Backbone.View.extend({
        template: 'formfields/justification',
        events: {
            //keydown is too much traffic
            'blur textarea': 'throttleUpdate'
        },
        initialize:function(options){
          this.model = options.model;
          this.valueUserSelected = options.valueUserSelected;
        },
        throttleUpdate: _.throttle(function(evt){
            var code = evt.keyCode || evt.which;
            if(code === 13) {
                evt.preventDefault();
            }
            var justification = this.$el.children().children()[1].value;
            this.model.get('justifications')[this.valueUserSelected] = justification;
            //fire validation events
            this.model.trigger('validate');
        }, 150, this),
        afterRender: function(){
            this.$el.children().children()[1].value = this.model.get('justifications')[this.valueUserSelected] ? this.model.get('justifications')[this.valueUserSelected] : "";
        },
        serialize: function(){
            return {
                'cid': this.cid
            };
        }
    });

	AbstractControl.ExternalLink = Backbone.View.extend({
		template: 'formfields/externallink',
        events: {
            'click .external-link-btn': 'updateModal'
        },
		initialize: function(options){
            this.field = options.field;
			this.url = new URI(options.url);

            //listen for change to change:value to update the External Link url
            this.listenTo(this.field, 'change:value', function(model, value){
                this.changeSelectedPages(value);
                this.updateModal();
            }, this);
		},
        uglifySelectedPages: function(selectedPages){
            //OpenAnnotate doesn't support - ranges, needs to be comma-seperated
            //update the pageSelectMode query param to be true if selectedPAges is empty
            //otherwise pageSelectMode needs to be a comma-delimited list of pages, no dashes
            if(!selectedPages || _.isArray(selectedPages) && selectedPages.length === 0){
                return 'true';
            }else{
                if(_.isString(selectedPages)){
                    if(selectedPages.indexOf('-' !== -1)){
                        //TODO: implement filler for page-range support
                        return selectedPages;
                    }
                    return selectedPages;
                }else if(_.isArray(selectedPages)){
                    return selectedPages.join(',');
                }
            }
            return 'true';
        },
        changeSelectedPages: function(selectedPages){
            //update query param
            var uglifiedSelectedPages = this.uglifySelectedPages(selectedPages);
            this.url.setQuery('pageSelectMode', uglifiedSelectedPages);
            //update question
            var stringifiedSelectedPages = selectedPages;
            if(_.isArray(selectedPages)){
                stringifiedSelectedPages = selectedPages.join(',');
            }
            //set value silently to not cause a loop
            this.field.set('value',stringifiedSelectedPages, {silent: true});
            this.field.setDisplayValue(stringifiedSelectedPages);
        },
        updateModal: function(selectedPages){
            this.changeSelectedPages(_.isString(selectedPages) ? selectedPages : this.field.getValue());
            this.$('#external-link-iframe-' + this.cid).attr('src', this.url.toString());
        },
        afterRender: function(){
            var self = this;
            this.stopListening(app.openAnnotate);
            this.$('#external-link-' + this.cid).on('shown.bs.modal', function(e){
                self.listenTo(app.openAnnotate, 'change:selectedPages', self.changeSelectedPages, this);
                self.listenTo(app.openAnnotate, 'closeWindow', self.updateModal, self);
            });
            this.$('#external-link-' + this.cid).on('hidden.bs.modal', function(e){
                self.stopListening(app.openAnnotate);
                self.$('.external-link-btn').blur();
            });
        },
		serialize: function(){
            return {
                'cid': this.cid,
                'hidden': this.hidden
            };
        }
	});

	return AbstractControl;
});
