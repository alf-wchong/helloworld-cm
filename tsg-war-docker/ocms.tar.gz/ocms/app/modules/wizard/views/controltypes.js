define([
	'app',
	'modules/wizard/views/abstractcontrol',
	'modules/common/tossacross',
	'modules/common/spinner',
	'modules/common/action',
	'modules/common/typeahead',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/populators/documentspopulator',
	'modules/wizard/controltypes/imagepreview',
	'ckeditorcore'
], function(app, AbstractControl, TossAcross, HPISpinner, Action, HPITypeahead, QuestionEventManager, DocumentsPopulator, ImagePreview){

	var SelectModel =  AbstractControl.extend({
		tagName: 'select',
		className: 'form-control input-medium',
		template: 'formfields/selectcontrol',
		events: {
			'change': 'updateValue'
		},
		initialize: function() {
			SelectModel.__super__.initialize.apply(this, arguments);
		},
		updateValue: function(evt){
			this.field.setDisplayValue(evt.currentTarget.displayValue || evt.currentTarget.value);
			this.field.setValue(evt.currentTarget.value);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			this.el.value = this.field.getValue();
		}
	});

	var SelectTypeAhead = AbstractControl.extend({
		template: 'formfields/selecttypeahead',
		initialize: function(){
			SelectTypeAhead.__super__.initialize.apply(this, arguments);
			this.field = this.options.field;
			var allOptions = this.field.get('options');
			if(this.field.has('allOptions')){
				allOptions = this.field.get('allOptions');
			}
			this.typeahead = new HPITypeahead({
				options: allOptions,
				disabled: this.field.isDisabled()
			});

			this.startListening();
		},
		startListening: function(){
			SelectTypeAhead.__super__.startListening.apply(this, arguments);
			this.stopListening(this.field, 'change:options');
			if(this.typeahead){
				this.stopListening(this.typeahead);

				this.listenTo(this.field, 'change:options', function(options){
					if(!options){
						options = [];
					}
					this.typeahead.updateOptions(options);
				}, this);

				this.listenTo(this.field, 'change:allOptions', function(model, options){
					if(!options){
						options = [];
					}
					this.typeahead.updateOptions(options);
				}, this);

				this.listenTo(this.typeahead, 'change:selected', function(option){
					this.field.setValue(option);
					this.field.setDisplayValue(option);
				}, this);
			}
		},
		onValueChange: function(){
			var value = this.field.getValue() ? this.field.getValue().value : undefined;
			if(this.currentJustificationView && this.field.get('justifications')[value] === undefined){
				this.currentJustificationView.remove();
			}
			//valid justification
			if(this.question.get('field').get('justifications') && this.question.get('field').get('justifications')[value] !== undefined){
				this.renderJustificationView(value);
			}

			if(this.typeahead){
				this.typeahead.setOption(this.field.getValue(), true);
			}
		},
		beforeRender: function(){
			this.setView('.typeahead-outlet', this.typeahead);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			//set option only after the typeahead has been rendered
			this.typeahead.setOption(this.field.getValue(), true);

			// this is here to make sure dependant queries are re-run if a form is resumed
			// we don't want to show the validation message of "need to complete this question" the first time, hence the added
			// "dontShowMessage" option
			if(!this.rendered) {
				this.field.trigger("validate", {"dontShowMessage": !this.rendered});
			}
			this.rendered = true;
		}
	});

	var MultiSelect = AbstractControl.extend({
		startListening: function(){
			MultiSelect.__super__.startListening.apply(this, arguments);
			this.stopListening(this.field, 'change:options');
			this.listenTo(this.field, 'change:options', function(options){
				this.buildTossAcross(options);
			}, this);

			this.listenTo(this.field, 'change:allOptions', function(model, options){
				this.buildTossAcross(options);
			}, this);
		},
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}

			QuestionEventManager.trigger('control:blur', this.question);
		},
		//disable re-render on display value change since tossacross uses an object for each value.
		//rendering displayValue before value is causing issues
		onDisplayValueChange: function(){},
		buildTossAcross: function(newOptions){
			this.availableOptions = [];
			var allOptions;
			//concat any pre-set options
			if(newOptions){
				allOptions = newOptions;
			}else{
				allOptions = this.field.get('allOptions') ? this.field.get('allOptions') : this.field.get('options');
			}

			//reject the configured values
			var values = _.pluck(this.field.getValues(), 'value');
			var availableValues = _.reject(allOptions, function(item){
				return _.indexOf(values, item.value) !== -1;
			});

			var srcCollection = new Backbone.Collection(availableValues);

			var targetCollection = new Backbone.Collection(this.field.getValues());

			//listen for changes to the target collection and update the model
			//when adding or removing the model is the added/removed backbone model and the second attribute is the backing collection
			this.listenTo(targetCollection, 'add remove', function(model, collection){
				var updatedCollection = collection instanceof Backbone.Collection ? collection.models : collection;
				//update value first
				this.field.setValue(_.pluck(updatedCollection, 'attributes'));
				this.field.setDisplayValue(_.pluck(_.pluck(updatedCollection, 'attributes'), 'displayValue'));
			}, this);

			//in the reset scenario the first param is the collection of touched models and attrs are the previous models
			this.listenTo(targetCollection, 'reset', function(collection){
				var updatedCollection = collection instanceof Backbone.Collection ? collection.models : collection;
				//update value first
				this.field.setValue(_.pluck(updatedCollection, 'attributes'));
				this.field.setDisplayValue(_.pluck(_.pluck(updatedCollection, 'attributes'), 'displayValue'));
			}, this);

			this.multiSelectTossAcross = new TossAcross.Layout({
				disabled: this.question.get('field').isDisabled(),
				//enable add and remove all
				enableAddRemove: true,
				clickAcross: true,
				srcCollection: {
					title: window.localize("modules.wizard.views.controlTypes.availableOptions"),
					filter: true,
					labelAttr: 'displayValue',
					valueAttr: 'value',
					collection: srcCollection
				},
				targetCollections: [
					{
						title: window.localize("modules.wizard.views.controlTypes.selectedOptions"),
						filter: true,
						labelAttr: 'displayValue',
						valueAttr: 'value',
						collection: targetCollection
					}
				]
			});
			this.setView(this.multiSelectTossAcross).render();
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			this.buildTossAcross();
		}
	});

	var RadioModel = AbstractControl.extend({
		template: 'formfields/radiocontrol',
		className: 'radioControl',
		events: {
			'click .radio': 'check'
		},
		initialize: function(){
			RadioModel.__super__.initialize.apply(this, arguments);
			this.field = this.options.field;
			this.concatedOptions = this.field.get('options');
			if(this.field.has('allOptions')){
				this.concatedOptions = this.field.get('allOptions');
			}

			this.startListening();
		},
		startListening: function(){
			RadioModel.__super__.startListening.apply(this, arguments);
			this.stopListening(this.field, 'change:options');
			this.listenTo(this.field, 'change:options', function(options){
				this.concatedOptions = _.extend([], options);
				//only clear the answer if its not an availible option
				if(!_.findWhere(this.concatedOptions, {value: this.field.getValue()})){
					this.field.setValue();
				}

				this.render();
			}, this);

			this.listenTo(this.field, 'change:allOptions', function(model, options){
				this.concatedOptions = _.extend([], options);
				//only clear the answer if its not an availible option
				if(!_.findWhere(this.concatedOptions, {value: this.field.getValue()})){
					this.field.setValue();
				}

				this.render();
			}, this);
		},
		renderJustificationView : function(valueSelected){
			if(this.justificationViews[valueSelected] === undefined){
				this.justificationViews[valueSelected] = new AbstractControl.JustificationView({model:this.field, valueUserSelected : valueSelected});
				this.field.get('justifications')[valueSelected] = this.field.get('justifications')[valueSelected] || "";
			}
			this.currentJustificationView = this.justificationViews[valueSelected];
			this.setView('.justification-output-'+ this.cid + '-' +_.pluck(this.field.get("options"),'value').indexOf(valueSelected), this.currentJustificationView).render();
		},

		check: function(evt){
			// if(!this.field.isDisabled){
			this.dontUpdateAgain = true;
			//We don't need to check on a click in the justification
			if(!_.contains(evt.target.classList, 'justification')){
				//firefox doesn't support evt.srcElement
				var target = evt.currentTarget || evt.srcElement;
				if(!this.field.isDisabled()){
					var value;
					if(this.$(target).attr('value')){
						value = this.$(target).attr('value');
					}else{
						value = $(target).find('.btn').val();
					}
					this.field.setValue(value);
					this.field.setDisplayValue(target.innerText.trim());
				}
			}
		},

		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			//get selected radio button
			var value = this.field.getValue();
			this.$('[value="' + value + '"]').prop("checked", true);
			this.$('[value="' + value + '"]').toggleClass("active");
			//Need make sure the value actually gets set
			if(value && !this.dontUpdateAgain){
				this.field.setValue(value);

				// looking for a display value from our list of options
				var displayValue = _.findWhere(this.concatedOptions, {"value" : value}).displayValue || value;

				if(displayValue) {
					this.field.setDisplayValue(displayValue);
				} else {
					this.field.setDisplayValue(value);
				}
			}
			this.$('.radio').attr('disabled',this.field.isDisabled());

			// this is here to make sure dependant queries are re-run if a form is resumed
			// we don't want to show the validation message of "need to complete this question" the first time, hence the added
			// "dontShowMessage" option
			if(!this.rendered) {
				this.field.trigger("validate", {"dontShowMessage": !this.rendered});
			}
			this.rendered = true;
		},
		serialize: function(){
			return {
				'options': this.concatedOptions,
				'cid': this.cid,
				'disabled': this.field.isDisabled()
			};
		}
	});

	var CheckboxModel = AbstractControl.extend({
		template: 'formfields/checkboxescontrol',
		className: 'checkbox',
		events: {
			'click input[type=checkbox]': 'check'
		},
		initialize: function(){
			CheckboxModel.__super__.initialize.apply(this, arguments);
			this.field = this.options.field;
			this.concatedOptions = this.field.get('options');
			if(this.field.has('allOptions')){
				this.concatedOptions = this.field.get('allOptions');
			}

			this.startListening();
		},
		startListening: function(){
			CheckboxModel.__super__.startListening.apply(this, arguments);
			this.stopListening(this.field, 'change:options');
			this.listenTo(this.field, 'change:options', function(options){
				this.concatedOptions = _.extend([], options);

				//only clear the answer if its not an availible option
				var allAvailible = true;
				_.each(this.field.getValues(), function(value){
					if(allAvailible){
						allAvailible = _.findWhere(this.concatedOptions, {'value': value});
					}
				}, this);
				if(!allAvailible){
					this.field.setValue([]);
				}
				this.render();
			}, this);

			this.listenTo(this.field, 'change:allOptions', function(model, options){
				this.concatedOptions = _.extend([], options);

				//only clear the answer if its not an availible option
				var allAvailible = true;
				_.each(this.field.getValues(), function(value){
					if(allAvailible){
						allAvailible = _.findWhere(this.concatedOptions, {'value': value});
					}
				}, this);
				if(!allAvailible){
					this.field.setValue([]);
				}
				this.render();
			}, this);
		},
		renderJustificationView : function(valueSelected, remove){
			if(this.justificationViews[valueSelected] === undefined){
				this.justificationViews[valueSelected] = new AbstractControl.JustificationView({model:this.field, valueUserSelected : valueSelected});
				this.field.get('justifications')[valueSelected] = this.field.get('justifications')[valueSelected] || "";
			}
			if(remove){
				this.justificationViews[valueSelected].remove();
			}
			this.currentJustificationView = this.justificationViews[valueSelected];
			this.setView('.justification-output-' + this.cid + '-' + _.pluck(this.concatedOptions,'value').indexOf(valueSelected), this.currentJustificationView).render();
		},
		onDisplayValueChange: function(){},
		check: function(evt){
			//firefox doesn't support evt.srcElement
			this.dontUpdateAgain = true;
			var target = evt.currentTarget || evt.srcElement;
			var value = this.$(target).attr('value');
			var checked = this.$(target).attr('checked');
			var selectedOptions;
			if(!checked){
				//remove from value list
				this.field.setValue(_.without(this.field.getValues(), value));
				//update display values
				//set display values from the options
				selectedOptions = _.reject(this.concatedOptions, function(option) {
					return this.field.getValues().indexOf(option.value) < 0;
				}, this);
			}else{
				//just pushing on a value doesn't trigger a change event, make a copy
				var newValues = _.extend([], this.field.getValues());
				newValues.push(value);
				this.field.setValue(newValues);
				//set display values from the options
				selectedOptions = _.reject(this.concatedOptions, function(option) {
					return this.field.getValues().indexOf(option.value) < 0;
				}, this);
			}
			this.field.setValue(_.pluck(selectedOptions, 'value'));
			this.field.setDisplayValue(_.pluck(selectedOptions, 'displayValue'));
		},

		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			//get selected checkboxes
			if(_.isArray(this.field.getValues())){
				_.each(this.field.getValues(), function(value){
					this.$('input[value="' + value + '"]').prop("checked", true);
				}, this);
				//Need make sure the value actually gets set
				if(!this.dontUpdateAgain){
					// here we are checking if there are any display values that we can us instead of the
					// regular display value
					this.field.setValue(this.field.getValues());

					// this will return an array of the proper display values, but won't error if it
					// doesn't exist as we will just use the value we started with
					var displayValues = _.map(this.field.getValues(), function(val){
						var valueObject = _.findWhere(this.field.get("options"), {"value" : val});
						// we are checking here to make sure 'valueObject' exists before grabbing the 
						// displayValue. if it doesn't exist, just use val (the value we started with)
						return valueObject ? valueObject.displayValue : val;
					}, this);
					
					// setting the proper display values 
					this.field.setDisplayValue(displayValues);
				}
			} else{
				//Its a string
				var value = this.field.getValues();
				this.$('input[value="' + value + '"]').prop("checked", true);
				//Need make sure the value actually gets set
				if(!this.dontUpdateAgain){
					this.field.setValue(value);

					// here we are going oto be checking if the field has a displayValue set
					// and if it is we want to ensure that it's being set on the field
					// not overridden with the "normal" value
					if(this.field.get("displayValue")) {
						this.field.setDisplayValue(this.field.get("displayValue"));
					} else {
						this.field.setDisplayValue(value);
					}
				}
			}
			this.renderAnyExistingJustifications(this.question.get('field').getValues());

		},
		serialize: function(){
			return {
				'options': this.concatedOptions,
				'cid': this.cid,
				'disabled': this.field.isDisabled()
			};
		}
	});

	var DateModel = AbstractControl.extend({
		template: 'formfields/datepicker',
		onBlurMobile: function(){
			this.hasFocus = false;
			var value = this.$('.datepicker-mobile').val();
			this.field.setValue(value);
			this.field.setDisplayValue(value);
			QuestionEventManager.trigger('control:blur:' + this.question.getAddress(), this.question);
		},
		//dont't allow default re-render, frags $.datepicker
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
		},
		events: {
			'change .datepicker-mobile': 'updateMobileDatePicker'
		},
		updateMobileDatePicker: function(){
			var newValue = this.$('.datepicker-mobile').val();
			this.field.setValue(newValue);
			this.field.setDisplayValue(newValue);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			var self = this;

			//set date format to what is in field format
			this.$('.datepicker-lg').datepicker({
				changeMonth: true,
				changeYear: true,
				dateFormat: this.field.get('format'),
				onSelect: function(date){
					self.hasFocus = true;
					self.field.setValue(date);
					self.field.setDisplayValue(date);
				},
				//case where datepicker is empty
				onClose: function(dateText){
					if( !dateText ){
						self.field.setValue('');
						self.field.setDisplayValue('');
					}
				},
				//disable pre-selecting today's date
				defaultDate: null,
				//longer number of years shown - 100 years back and 10 years into the future
				yearRange: "-100:+10"
			});

			//set date if there is one
			if(this.field.getDisplayValue() && this.field.getDisplayValue() !== "N/A" && this.field.isValid()) {
				this.$('.datepicker-lg').datepicker('setDate', this.field.getDisplayValue());
				// html5 (mobile only) date input requires the date value to be in the format 'YYYY-MM-DD'
				this.$('.datepicker-mobile').val(moment(this.field.getDisplayValue()).format('YYYY-MM-DD'));

			} else {
				this.$('.datepicker-lg').val('');
				this.$('.datepicker-mobile').val('');
			}
		}
	});

	var TextareaModel = AbstractControl.extend({
		tagName: function(){
			if(this.field.isDisabled()){
				return 'textarea input disabled="disabled" ';
			}else{
				return 'textarea';
			}
		},
		className: 'form-control',
		attributes: {'rows' : '4'},
		events: {
			'keyup'		: 'throttleUpdate',
			'blur'		: 'onBlur'
		},
		onBlur: function(){
			this.hasFocus = false;
			QuestionEventManager.trigger('control:blur', this.question);
		},
		throttleUpdate: _.throttle(function(){
			//track focus to decise weather or not to update the DOM element
			this.hasFocus = true;
			var text = this.$el.val();
			this.field.setValue(text);
			this.field.setDisplayValue(text);
		}, 50, this),
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			if(!this.hasFocus){
				this.$el.val(this.field.getValue());
			}
			//set placeholder text if any
			this.$el.attr("placeholder", this.field.get('placeholder'));
		}
	});

	var TextboxModel = AbstractControl.extend({
		tagName: function(){
			if(this.field.isDisabled()){
				return 'input disabled="disabled" maxlength="148"';
			}else{
				return 'input maxlength="148"';
			}
		},
		className: 'form-control',
		events: {
			'keydown'	: 'keyCheck',
			'keyup'		: 'throttleUpdate',
			'blur'		: 'onBlur'
		},
		//mock onValueChange
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
		},
		onDisplayValueChange: function(){
			// Only rerender the field if it is a formattable type
			if(this.field.get("fieldAspects").indexOf("formattable") > -1){
				this.render();
			}
		},
		onBlur: function(){
			this.throttleUpdate();

			this.hasFocus = false;
			if(this.field.getDisplayValue()){
				var formattedValue = this.field.getDisplayValue();
				if(formattedValue === 0 || formattedValue && formattedValue !== 'N/A'){
					this.$el.val(formattedValue);
				}else if(formattedValue){
					//formattedValue is N/A, set placeholder
					this.$el.val('');
					this.$el.attr("placeholder", formattedValue);
				}
			}else{
				this.field.setDisplayValue($(this.el).val());
			}
			QuestionEventManager.trigger('control:blur', this.question);
		},
		keyCheck: _.throttle(function(evt){
			var code = evt.keyCode || evt.which;
			if(code==13){
				//prevent default for enter key only
				evt.preventDefault();
			}
		}, 50, this),
		throttleUpdate: _.throttle(function(){
			this.hasFocus = true;
			var text = this.$el.val();
			this.field.setValue(text);
			this.field.setDisplayValue(text);
		}, 50, this),
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			if(!this.hasFocus){
				this.$el.val(this.field.getValue());
			}
			if(this.field.getDisplayValue()){
				this.onBlur();
			}
		}
	});

	//special fields

	var CalculationModel = TextboxModel.extend({
		//calculation fields are read-only
		className: 'form-control disabled',
		tagName: 'input disabled',
		onValueChange: function(){
			this.render();

			QuestionEventManager.trigger('control:blur', this.question);
		}
	});

	var EmailModel = AbstractControl.extend({
		tagName: function(){
			if(this.field.isDisabled()){
				return 'input type="email" disabled="disabled" maxlength="148"';
			}else{
				return 'input type="email" maxlength="148"';
			}
		},
		className: 'form-control',
		events: {
			'keydown': 'sanitizeKey',
			'change' : 'updateAddress'
		},
		//must intercept enter key on down press not keyup
		sanitizeKey: function(evt){
			var code = evt.keyCode || evt.which;
			if(code==13){
				//prevent default for enter key only
				evt.preventDefault();
			}
		},
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
		},
		//listen for changes from html5 controls
		updateAddress: function(){
			this.field.setValue($(this.el).val());
			this.field.setDisplayValue($(this.el).val());
			var value = this.field.getValue();
			$(this.el).attr('value', value)
				.val(value);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			$(this.el).val(this.field.getValue());
		}
	});

	//behaves similar to gmail's To: field. Enter and blur add the current text to the list.
	var MultiInputModel = AbstractControl.extend({

		template: 'wizard/multiinputcontrol',
		events: {
			'click li'		: 'removeValue',
			'keydown input'	: 'sanitizeKey',
			'keyup input'	: 'addValue',
			'blur input'	: 'addValue'
		},
		initialize: function(){
			AbstractControl.__super__.initialize.apply(this, arguments);
			this.ui = {};
			this.field = this.options.field;
			this.mask = this.field.get('format');
		},
		//must intercept enter key on down press not keyup
		sanitizeKey: function(evt){
			var code = evt.keyCode || evt.which;
			if(code==13){
				//prevent default for enter key only
				evt.preventDefault();
			}
		},
		removeValue: function(evt){
			//get value to remove based on the id
			if(!this.field.isDisabled()){
				var index = Number(this.$(evt.currentTarget).attr('id').replace('value-', ''));
				this.field.removeValue(index);
				this.onValueChange();
			}
		},
		addValue: function(evt){
			//space, click, and enter
			if(!this.field.isDisabled()){
				var keyBindings = [13, 1];
				var code = evt.keyCode || evt.which;
				if(_.contains(keyBindings, code) || evt.type === 'focusout'){
					this.ui.input = this.$('input');
					var newVal = this.ui.input.val() ? this.ui.input.val().trim() : '';
					if(newVal !== '') {
						this.field.setValue(_.extend([], this.field.getValues()).concat([newVal]));
						this.ui.input.val('');
						// //re-render options
						this.onValueChange();
					}
				}
			}
		},
		onValueChange: function(model){
			this.ui.selectedOptions = this.$('.selectedOptions');
			this.ui.selectedOptions.empty();
			//show selected files for upload
			_.each(this.field.getValues(), function(value, index){
				this.ui.selectedOptions.append('<li id="value-' + index + '"><span class="glyphicon glyphicon-remove" /> ' + value + '</li>');
			}, this);
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
			//update display values
			this.field.setDisplayValue(this.field.getValues());
		},
		onDisplayValueChange: function(){},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			//initial render of any selected options
			this.onValueChange();
			this.$('.multitextInput').attr('disabled',this.field.isDisabled());
			this.$('.add-value-btn').attr('disabled',this.field.isDisabled());

		},
		serialize: function(){
			return {
				mask: this.mask,
				disabled:this.field.isDisabled()
			};
		}
	});

	var PhoneModel = TextboxModel.extend({

		tagName: function(){
			if(this.field.isDisabled()){
				return 'input type = "tel" disabled="disabled" ';
			}else{
				return 'input type = "tel" ';
			}
		}
	});

	var NumberModel = TextboxModel.extend({
		tagName: 'input inputmode ="numeric"',
		events: {
			'change' 	: 'updateNumber'
		},
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
		},
		//listen for changes from html5 controls
		updateNumber: function(){
			var value = $(this.el).val();
			this.field.setValue(value);
			this.field.setDisplayValue(value);
			value = this.field.getValue();
			$(this.el).attr('value', value).val(value);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			var value = this.field.getValue();

			$(this.el).attr('min', 0)
				.attr('max', 100)
				.attr('step', 1)
				.attr('value', value)
				.val(value);
		}
	});

	var TimeModel = AbstractControl.extend({
		template: 'wizard/timecontrol',
		events: {
			'change .hours'  	: 'updateNumber',
			'change .minutes' 	: 'updateNumber',
			'blur input'		: 'formatTime'
		},
		initialize: function(){
			AbstractControl.__super__.initialize.apply(this, arguments);
			this.hours = 0;
			this.minutes = 0;
			this.field = this.options.field;
		},
		onValueChange: function(model){
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
		},
		onDisplayValueChange: function(){
			this.displayFormattedTime();
			this.setFieldValueFromDisplayValue();
		},
		formatTime: function(){
			QuestionEventManager.trigger('control:blur', this.question);
		},
		displayFormattedTime: function(){
			if(this.field.getDisplayValue()){
				var formattedValue = this.field.getDisplayValue();
				if(formattedValue && formattedValue !== 'N/A'){
					var time = this.field.getDisplayValue().split(':');
					this.$('.hours').val(time[0]);
					this.$('.minutes').val(time[1]);
				}else if(formattedValue){
					//formattedValue is N/A, set placeholder
					this.$('input').val('');
					this.$('input').attr("placeholder", formattedValue);
				}
			}
		},
		setFieldValueFromDisplayValue: function(){
			var time = this.field.getDisplayValue();
			this.field.setValue(time);
		},
		//listen for changes from html5 controls
		updateNumber: function(){
			var hours = this.$('.hours').val();
			var minutes = this.$('.minutes').val();
			var time = hours + ':' + minutes;
			if(time.trim() && time.trim()[0] === ':'){
				this.field.setValue('');
			}else{
				this.field.setValue(time);
			}
			this.$('.hours').attr('value', hours)
				.val(hours);
			this.$('.minutes').attr('value', minutes)
				.val(minutes);
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			var time = this.field.getValue();
			var timing = time.split(':');
			this.$('.hours').attr('min', 0)
				.attr('max', 24)
				.attr('step', 1)
				.attr('value', timing[0]);
			this.$('.minutes').attr('min', 0)
				.attr('max', 59)
				.attr('step', 1)
				.attr('value', timing[1]);
		}
	});

	var AttachedDocsModel = AbstractControl.extend({
		template: 'wizard/attacheddocscontrol',
		events: {
			'click li': 'removeDoc'
		},
		initialize: function(){
			AbstractControl.__super__.initialize.apply(this, arguments);
			this.ui = {};
			this.field = this.options.field;
			this.question = this.options.question;

			this.hasDragAndDropSupport = 'draggable' in document.createElement('span');

			this.folderCreated = $.Deferred();
			if(!this.hasDragAndDropSupport){
				app.trigger('psi:createfolder', undefined, this.folderCreated);
			}

			this.folderCreated.done($.proxy(function(result){
				this.parentId = result;
			}, this));
			//overriding initialize seems to break backbone event listeners
			this.listenTo(this.field, 'change:value', this.onValueChange, this);

			$(document).bind('drop dragover', function (e) {
				e.preventDefault();
			});
		},
		addDocs: function(data){
			//mark each value as a file IE doesn't support File API

			_.each(data.files, function(doc){
				doc.file = true;
			}, this);
			if(this.hasDragAndDropSupport){
				this.field.setValue(this.field.getValues().concat(data.files));
			}else{
				this.$('.addAttachedDoc').hide();
				this.field.setValue(data.files);
			}
			QuestionEventManager.trigger('control:blur', this.question);

		},
		removeDoc: function(evt){
			evt.preventDefault();
			var index = Number(this.$(evt.currentTarget).attr('id').replace('file-', ''));
			var file, confirm,fileName;
			if(this.hasDragAndDropSupport){
				//get file to remove based on the id
				if(this.field.getValue(index).id){
					file = this.field.getValue(index);
					//takes file.name if that is true otherwise goes to the parse.
					fileName = file.name || JSON.parse(file.formData.action).parameters.properties['prop-objectName'];
					//TODO: app.trigger confirmation is broken in Bootstrap 3
					confirm = window.confirm(window.localize("modules.wizard.views.controlTypes.areYouSUreYou") + fileName + "?");
					if(confirm){
						//delete now happens upon save or finishing the form
						this.field.removeValue(index);
					}
				}else{
					this.field.removeValue(index);
				}
			}else{
				file = this.field.getValue(index);
				//takes file.name if that is true otherwise goes to the parse.
				fileName = file.name || JSON.parse(file.formData.action).parameters.properties['prop-objectName'];
				//TODO: app.trigger confirmation is broken in Bootstrap 3
				confirm = window.confirm(window.localize("modules.wizard.views.controlTypes.areYouSUreYou") + fileName+ "?");
				if(confirm){
					this.field.removeValue(index);
					this.$('.addAttachedDoc').show();
				}
			}
			QuestionEventManager.trigger('control:blur', this.question);
		},
		onValueChange: function(model){
			this.ui.selectedFiles.empty();
			//show selected files for upload
			_.each(this.field.getValues(), function(file, index){
				//async load the image previews
				file.name = file.name || JSON.parse(file.formData.action).parameters.properties['prop-objectName'];
				if(ImagePreview.isImage(file.name) && window.FileReader !== undefined) {
					ImagePreview.loadImage(file).done(_.bind(function(previewView){
						// if preview, add that image to the DOM (account for possible duplicates)
						if(previewView && $('.img-' + file.name.split(".")[0]).length === 0){
							this.$('div.aw-image-previews').append(previewView.$el);
							previewView.render();
							file.loaded = true;
						}
					}, this));
				}

				if(_.isObject(file)){
					//IE doesn't support the file api
					this.ui.selectedFiles.append('<li id="file-' + index + ' " style="text-align:right;" > ' + file.name + '<span class="glyphicon glyphicon-remove" /></li>');
				}
			}, this);
			if(this.currentJustificationView && this.field.get('justifications')[model.get('value')] === undefined){
				this.currentJustificationView.remove();
			}
			this.updateBadge();
		},
		updateBadge: function(){
			if(this.hasDragAndDropSupport){
				this.$('.addAttachedDoc').css({
					'border-top-left-radius': '4px',
					'border-bottom-left-radius': '4px'
				});
				if(this.field.getValues().length === 0){
					this.ui.dropdownToggle.hide();
					this.$('.addAttachedDoc').css({
						'border-top-right-radius': '4px',
						'border-bottom-right-radius': '4px'
					});
				}else{
					this.ui.dropdownToggle.show();
					this.ui.badge.textContent = this.field.getValues().length;
					this.ui.addAttachedDoc.css({
						'border-top-right-radius': '0',
						'border-bottom-right-radius': '0'
					});
				}
			}
		},
		afterRender: function(){
			AbstractControl.prototype.afterRender.apply(this, arguments);
			var self = this;
			this.ui.badge = self.$('.badge')[0];
			this.ui.dropdownToggle = this.$('.dropdown-toggle');
			this.ui.uploader = this.$('.fileuploader-input');
			this.ui.selectedFiles = this.$('.selectedFiles');
			this.ui.animateDragDrop = this.$('.animateDragDrop');
			this.ui.helperText = this.$('#helpDragDrop');
			this.ui.addAttachedDoc = this.$('.addAttachedDoc');
			//show helper text in < IE 10
			if(!this.hasDragAndDropSupport){
				this.ui.helperText.show();
				if(this.field.getValues().length > 0){
					this.$('.addAttachedDoc').hide();
				}
			}

			this.updateBadge();

			//disable default drag and drop reactions

			this.ui.uploader.bind('dragenter dragover', function (e) {
				e.preventDefault();
			});

			this.ui.uploader.bind('dragleave drop', function (e) {
				e.preventDefault();
			});

			//input field
			if(!this.field.isDisabled()){
				this.ui.animateDragDrop.bind('dragenter dragover', function (e) {
					e.preventDefault();
					$(this).css({
						'border': '3px dashed #e83a00'
					});
				});

				this.ui.animateDragDrop.bind('dragleave drop', function (e) {
					e.preventDefault();
					$(this).css({
						'border': '3px dashed transparent'
					});
				});

				if(this.hasDragAndDropSupport){
					this.ui.uploader.fileupload({
						add: function (e, data) {
							self.addDocs(data);
						},
						dropZone: this.ui.animateDragDrop
					});
				}else{
					this.ui.uploader.fileupload({
						url: app.serviceUrlRoot + '/action/executeWithAttachmentStringResponse',
						forceIframeTransport: true,
						add: function (e, data) {
							self.folderCreated.done($.proxy(function(){
								var uploadSupportingDocAction = new Backbone.Model({
									name: 'bulkUpload',
									parameters: {
										objectId: self.parentId,
										objectType: 'Attached Document',
										properties: {
											"prop-objectName": data.files[0].name
										},
										hideFileExtensions: "true"
									}
								});

								data.formData = {
									'action': JSON.stringify(uploadSupportingDocAction)
								};
								self.addDocs(data);
								data.submit();
							}, this));
						},
						done: function (e, data){
							//IE 9 and iframes make getting the result object interesting
							//http://stackoverflow.com/questions/8814068/jquery-file-upload-ie-done-callback-data-result-issue
							var result = $( 'pre', data.result ).text();
							//bulkUploadMap is an escaped stringified map of {documentName : objectId}
							var cleaned = result.replace(/\\"/g, '"');
							//strip excess "double quotes"
							var cleanedJSON = JSON.parse(cleaned.substr(1, cleaned.length-2));
							var documentName = data.files[0].name;
							self.field.setValue([{
								'name': documentName,
								'id': cleanedJSON,
								'file': true
							}]);
							self.field.set('displayName', documentName);
						}
					});
				}
			}


			//initial render of any selected docs
			this.onValueChange();
			this.$('.addAttachedDoc').attr('disabled',this.field.isDisabled());
			this.$('.dropdown-toggle').attr('disabled',this.field.isDisabled());

		},
		serialize: function(){
			return {
				hasDragAndDropSupport: this.hasDragAndDropSupport,
				cid: this.cid,
				disabled:this.field.isDisabled()
			};
		}
	});

	var SSNModel = TextboxModel.extend({
		tagName: 'input maxlength="11" type="password"'
	});

	var WYSWIGModel = AbstractControl.extend({
		template: 'wizard/wyswigcontrol',
		events: function(){
			var events = {};
			//be precise here
			events['focus #wyswig-editor-' + this.cid] = 'onFocus';
			events['blur #wyswig-editor-' + this.cid] = 'onBlur';
			return events;
		},
		initialize: function(){
			AbstractControl.__super__.initialize.apply(this, arguments);
			this.ui = {
				'editor': 'wyswig-editor-' + this.cid
			};
		},
		buildEditor: function(){
			var self = this;


			// Turn off automatic editor creation first.
			CKEDITOR.disableAutoInline = true;

			if(!CKEDITOR.instances[this.ui.editor]){

				var instance = CKEDITOR.inline(this.ui.editor, {
					toolbar: "HPISimple",
					height: 100
				});

				instance.on( 'instanceReady', function( ev ) {
					var editor = ev.editor;
					editor.setReadOnly( false );
					editor.setData(self.field.getValue());
				});

				instance.on('change', function() {
					self.throttleUpdate();
				});

				instance.on('blur', function() {
					self.onBlur();
				});
			}

		},
		onFocus: function(){
			this.hasFocus = true;
			//only show WYSWIG if has focus and not disabled by configuration
			if(this.rendered && !this.field.isDisabled()){
				this.buildEditor();
			}
		},
		onBlur: function(){
			this.hasFocus = false;
		},
		keyCheck: _.throttle(function(evt){
			var code = evt.keyCode || evt.which;
			if(code==13){
				//prevent default for enter key only
				evt.preventDefault();
			}
		}, 50, this),
		throttleUpdate: _.throttle(function(){
			//track focus to decise weather or not to update the DOM element
			this.hasFocus = true;
			var text = CKEDITOR.instances[this.ui.editor].getData();
			this.field.setDisplayValue(text);
			this.field.setValue(text);
		}, 50, this),
		afterRender: function(){
			this.rendered = true;
			//insert the value for this question - expect raw html
			$('#' + this.ui.editor).html(this.field.getValue());
		},
		cleanup: function(){
			try {
				//remove this instance of CKEDITOR from the global registry
				//of CKEDITOR.instances to prevent memory leaks
				if(CKEDITOR.instances[this.ui.editor]){
					CKEDITOR.instances[this.ui.editor].destroy(true);
					CKEDITOR.instances[this.ui.editor].removeAllListeners(); // just in case
					delete CKEDITOR.instances[this.ui.editor];
				}
			} catch (e) {
				// ignoring linting for this catch block
				// eslint-disable-next-line no-console
				console.log("Error removing listeners from CKEditor: " + e);
			}
		},
		serialize: function(){
			return {
				'cid': this.cid,
				'disabled': this.field.isDisabled()
			};
		}
	});

	var PopulatorModel = DocumentsPopulator;

	return {
		'selectSimple' 	: SelectModel, //keeping this around in case you want to bring back regular select
		'select'        : SelectTypeAhead,
		'textbox' 		: TextboxModel,
		'textarea' 		: TextareaModel,
		'multiselect'	: MultiSelect,
		'date'			: DateModel,
		'radio'			: RadioModel,
		'checkbox' 	    : CheckboxModel,
		'calculation' 	: CalculationModel,
		'email'			: EmailModel,
		'phone'			: PhoneModel,
		'number'		: NumberModel,
		'file'			: AttachedDocsModel,
		'multitextinput': MultiInputModel,
		'time'			: TimeModel,
		'ssn'			: SSNModel,
		'wysiwyg'		: WYSWIGModel,
		'populator'		: PopulatorModel
	};
});
