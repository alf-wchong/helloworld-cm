define([
	'app',
	'module',
	'modules/common/action',
	'moment',
	'modules/common/spinner',
	'modules/wizard/pagesetinstanceuploadutils'
], function(app, module, Action, Moment, HPISpinner, PSIUtil){

	var FinishAndSubmit = PSIUtil.FinishAndSubmit.extend({
		template: 'wizard/finishandsubmitmodal',
		sendNotificationEmails : true, 
		actionType : 'finishAndSubmitPSI'
	});

	return FinishAndSubmit;
});