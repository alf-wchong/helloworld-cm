define([
    'app',
    'modules/wizard/events/questioneventmanager',
    'modules/wizard/events/pageeventmanager'
], function(app, QuestionEventManager, PageEventManager) {

    var FlowPathView = Backbone.Layout.extend({
        template: 'wizard/flowpath',
        events: {
            'click .aw-page-list-item.aw-page-link': 'nextPage',
            "click #navigation": "toggleFlowpath"
        },
        initialize: function(config) {
            var self = this;
            this.psi = config.psi;
            this.flowpath = config.flowpath;
            this.pages = [];
            this.controlVisibility = false;
            this.listenTo(this.flowpath, 'reset', function() {
                self.render();
            }, this);

            //get current page from the url and mark as selected
            this.currentPage = Backbone.history.fragment.split('/').pop().replace(/[a-z]/i, '');

            // this.listenTo(app, 'activeform:controls:page', function(pageIndex){
            // 	this.currentPage = pageIndex;
            // 	this.markCurrent();
            // }, this);
        },

        nextPage: function(evt) {
            var that = this;
            this.hideFlowpath().done(function() {
                PageEventManager.trigger('activeform:flowpath:intendToChange', parseInt(that.currentPage, 10), $(evt.currentTarget).data('awpage'), that);
            });

        },
        markCurrent: function() {
            //remove any markers
            this.$('.aw-page-list-item').removeClass('alert alert-warning bs-callout bs-callout-info');
            //mark current page
            this.$el.find("[data-awpage='" + this.currentPage + "']").addClass('alert alert-warning bs-callout bs-callout-warning');
        },
        toggleFlowpath: function(evt) {
            if (evt) { evt.preventDefault(); }
            if (this.controlVisibility === true) {
                this.hideFlowpath();
                this.controlVisibility = false;
            } else {
                this.$('.toggleable-nav-list').slideDown();
                this.controlVisibility = true;
            }
        },
        hideFlowpath: function() {
            var def = $.Deferred();
            this.$('.toggleable-nav-list').slideUp(400, function() {
                def.resolve();
            });
            return def.promise();
        },
        getIcon: function(page) {
            if (this.psi.isLocked(page.id)) {
                return '<span class="glyphicon glyphicon-lock"/>';
            } else {
				return !page.has('valid') ? 'Available' 
						  : page.get('valid') === true ? '<span class="glyphicon glyphicon-ok"/>' 
														: '<span class="glyphicon glyphicon-remove"/>';
            }
        },
        getStatus: function(page) {
            if (this.psi.isLocked(page.id)) {
                return 'alert-warning';
            } else {
                return !page.has('valid') ? '' : page.get('valid') === true ? 'alert-success' : 'alert-danger';
            }
        },
        beforeRender: function() {
            //build list of pages from flowpath
            this.pages = [];
            this.flowpath.each(function(page, index) {
                if (typeof page.attributes.description === 'object') {
                    page.attributes.description = undefined;
                }
                this.pages.push({
                    'id': 'aw-page-link' + (index),
                    'attributes': page.attributes,
                    'status': this.getStatus(page),
                    'showBadge': !page.has('valid'),
                    'complete': this.getIcon(page)
                });
            }, this);
        },
        afterRender: function() {
            //get current page from the url and mark as selected
            this.markCurrent();
        },
        serialize: function() {
            return {
                pages: this.pages
            };
        }
    });

    return FlowPathView;
});