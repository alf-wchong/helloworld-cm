define([
    'app'
], function(app){

    var AddFormNameModal = Backbone.Layout.extend({
        template: 'wizard/addformnamemodal',
        events: {
            'click .submit'	            : 'submitActiveForm',
            'keydown #form-name'	    : 'updateFormName'
        },
        initialize: function(config){
            this.psi = config.psi;
        },
        updateFormName: _.throttle(function(evt){
            //disable enter key form submit
            var code = evt.keyCode || evt.which;
            if(code === 13){
                //prevent default for enter key only
                evt.preventDefault();
            }
            if(this.$(evt.currentTarget).val() !== ''){
                if(code === 13){
                    this.submitActiveForm();
                }
                this.$('.submit').removeClass('disabled');
            }else{
                this.$('.submit').addClass('disabled');
            }
        }, 250, this),
        submitActiveForm: function(){
            if(this.$('#form-name').val() !== '') {
                this.psi.set('name',this.$('#form-name').val());
                app.routers.activeform.finishAndSubmitPSI(this.psi);
                this.$(this.el).modal('hide');
                app.trigger('alert:close');
            }
        }
    });

    return AddFormNameModal;
});