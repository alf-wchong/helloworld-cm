define(['app'],function(){
	var ImagePreview = {};

	ImagePreview.Model = Backbone.Model.extend({
		defaults: {
			'src': '',
			'filename': 'untitled'
		},
		initialize: function(options) {
  			this.options = _.defaults(options,this.defaults);
 		}
	});

	ImagePreview.View = Backbone.Layout.extend({
		initialize: function(options){
			this.model = options.model;
		},
		serialize: function(){
			return this.model.attributes;
		},
		getRawHTML: function(){
			window.JST["image/preview"] = _.template("<h4 class=\"aw-image-preview-header\"><%= filename %></h4><img class=\"aw-image-preview\" src=\"<%= src %>\" alt=\"<%= filename %>\" />");
			return window.JST["image/preview"](this.serialize());
		}
	});

	ImagePreview.isImage = function(filename){
		return filename.substring(filename.length-4).toLowerCase() === ".jpg" || filename.substring(filename.length-4).toLowerCase() === ".png";
	};

	// returns an ImagePreview of this HTML5 file upload
	ImagePreview.loadImage = function(file){
		// to determine if file is a file type or just an object
		if(file.src){
			// gets called upon reloading the preview
			return ImagePreview._loadFileObject(file);
		} else{
			// gets called upon uploading a image
			return ImagePreview._loadFileTypeObject(file);
		}
	};

	ImagePreview._loadFileObject = function(file){
		var deferred = $.Deferred();
		var preview = new ImagePreview.Model({
			'src': file.src,
			'filename': file.name
		});
		var previewView = new ImagePreview.View({
			'className': "img-" + file.name.split(".")[0],
			'model': preview
		});
		return deferred.resolve(previewView).promise();
	};

	ImagePreview._loadFileTypeObject = function(file){
		var deferred = $.Deferred();
		var reader = new FileReader();
		reader.addEventListener("load", function() {
			// create a ImageView
			var preview = new ImagePreview.Model({
				'src': reader.result,
				'filename': file.name
			});
			// set the src statically on the HTML5 file object for easy access by the summary page
			file.src = reader.result;
			deferred.resolve(new ImagePreview.View({
				'className': "img-" + file.name.split(".")[0],
				'model': preview
			}));
		});

		if (_.isObject(file)){
			//IE doesn't support the file api
			reader.readAsDataURL(file);
		}
		return deferred.promise();
	};

	// returns a string representation of the html markup of this file upload
	ImagePreview.getPreviewHTML = function(file) {
		var preview = new ImagePreview.Model({
			'src': file.src,
			'filename': file.name
		});
		var ip = new ImagePreview.View({
			'className': "img-" + file.name.split(".")[0],
			'model': preview
		});

		return ip.getRawHTML();
	};

	return ImagePreview;
});