define([
	'app',
	'modules/wizard/rules/calculationrule',
	'modules/wizard/rules/queryrule',
	'modules/wizard/rules/leadingrule',
	'modules/wizard/rules/metadatarule',
	'modules/wizard/rules/justificationrule'
], function(
	app,
	CalculationRule,
	QueryRule,
	LeadingRule,
	MetadataRule,
	JustificationRule
){
	var RuleService = {};

	RuleService.processRules = function(question){
		question.get('rules').each(function(rule){
			switch(rule.getType()){
				case 'calculation':
					CalculationRule.processActions(question, rule);
					break;
				case 'query':
					QueryRule.processActions(question, rule);
					break;
				case 'leading':
					LeadingRule.processActions(question, rule);
					break;
                case 'metadata':
                 	MetadataRule.processActions(question, rule);
                    break;
                case 'justification':
                	JustificationRule.processActions(question, rule);
                    break;
			}
		}, this);
	};

	return RuleService;
});