define([
	'app',
	'modules/wizard/models/field',
	'modules/wizard/services/formulaservice'
], function(app, Field, FormulaService){
	//util functions for copying questions and rules
	var QuestionUtils = {
		updateRules: function(question, questionGroups){
			if(question.has('rules')){
				question.get('rules').each(function(rule){
					rule.getActions().each(function(action){
						//formula
						if(action.has('formula')){
							//get the formula from the rule
							var formula = action.get('formula');

							_.each(FormulaService.expressions(formula), function(address){
								//only update formulas that are on this page and repeating
								//page #_input #_r #
								var updatedAddress = address;
								var variableAddress = address.split('_');
								if(question.page_id === variableAddress[0] && this.inQuestionGroup(questionGroups, address)){
									var rowNumber = _.last(question.id.split('_'));
									if(variableAddress.length == 2){
										variableAddress.push(rowNumber);
									}else if(variableAddress.length == 3){
										variableAddress[2] = rowNumber;
									}
								}else{
									app.log.debug("Not in question groups: "  + address);
								}
								updatedAddress = variableAddress.join('_');
								//update expression in the formula
								formula = formula.replace(address, updatedAddress);
								action.set('formula', formula);
							}, this);
						//query
						}else if(action.has('substitutions')){
							//listen for subsitutions required for this query
							_.each(action.get('substitutions'), function(dependency, index){
								var address = dependency.pageId + '_' + dependency.inputId;
								var variableAddress = dependency.inputId.split('_');
								if(question.page_id === dependency.pageId && this.inQuestionGroup(questionGroups, address)){
									var rowNumber = _.last(question.id.split('_'));
									if(variableAddress.length == 1){
										variableAddress.push(rowNumber);
									}else if(variableAddress.length == 2){
										variableAddress[1] = rowNumber;
									}
								}else{
									app.log.debug("Not in question groups: "  + address);
								}
								dependency.inputId = variableAddress.join('_');
							}, this);
						}
					}, this);
				}, this);
			}
			return question;
		},
		getNextRowNumber: function(questionGroups){
		    var max = -1;
		    _.each(questionGroups, function(row){
		        var address = row[0];
		        var addrParts = address.split('_');
		        var rowNumber;
		        //has row suffix
		        if(addrParts.length === 3){
		            //get row number
		           	rowNumber = Number(addrParts[2].replace(/[a-z]+/i, ''));
		            if(rowNumber > max){
		                max = rowNumber;
		            }
		        }else if(addrParts.length === 2){
		        	//first row being cloned
		        	rowNumber = 0; //no existing row number to start
		        	if(rowNumber > max){
		                max = rowNumber;
		            }
		        }
		    }, this);
		    return max + 1;
		},
		getNextAvalibleQuestionAddress: function(address, questionGroups){
		    var addrParts = address.split('_');
		    try{
		        var nextAddress = 'r' + this.getNextRowNumber(questionGroups);
		        //first row, no row suffix
		        if(addrParts.length === 2){
		            addrParts.push(nextAddress);
		        }else if(addrParts.length === 3){
		            addrParts[2] = nextAddress;
		        }
		    }catch(e){
		        app.log.debug(window.localize("modules.wizard.services.questionUtils.failedToGet"));
		    }
		    //stich the address back together
		    return addrParts[1] + '_' + addrParts[2];
		},
		getPageAndIndex: function(address){
			var parts = address.split('_');
			return parts[0] + '_' + parts[1];
		},
		//helper function for computing if an id is in a question group
		inQuestionGroup: function(questionGroups, address){
			var pageAndIndex = this.getPageAndIndex(address);
			var inGroup = false;
			_.each(questionGroups, function(group){
				if(!inGroup){
					_.each(group, function(row){
						if (row.indexOf(pageAndIndex) > -1){
							inGroup = true;
							return;
						}
					});
				}
			}, this);
			return inGroup;
		},
		copyQuestion: function(question, options, keepValues){
			//responsible for cleanly copying and de-referencing a question to give a correct cid, _id, etc
			var blacklist = ['_id', 'id', 'actions', 'conditions', 'datasource', 'queriedOptions'];
			var clone = _.extend({}, _.omit(question.attributes, ['_id', 'id', 'field', 'rules', 'fetched']));
			//only push on generic JSON, not Backbone Models, initing a Question builds that for us
			//field
			clone.field = new Field(_.omit(question.get('field').attributes, blacklist), options).toJSON();

			//remove any stored values
			clone.field.value = undefined;
			clone.field.displayValue = undefined;

			//rules
			var clonedRules = [];
			question.get('rules').each(function(rule){
				var clonedRule = _.omit(_.extend({}, rule.attributes), blacklist);
				//clone actions and conditions
				if(rule.has('actions')){
					//ther should only be one
					var clonedActions = [];
					rule.get('actions').each(function(action){
						clonedActions.push(_.extend({}, action.attributes));
					}, this);
					clonedRule.actions = clonedActions;
				}

				if(rule.has('conditions')){
					var clonedConditions = [];
					rule.get('conditions').each(function(condition){
						clonedConditions.push(_.extend({}, condition.attributes));
					}, this);
					clonedRule.conditions = clonedConditions;
				}
				clonedRules.push(clonedRule);
			}, this);
			clone.rules = clonedRules;
			return clone;
		},
		wizardTypeToAttrType: {
			"radio" : "string",
			"textarea" : "string",
			"textbox" : "string",
			"checkbox" : "string",
			"multiselect" : "string",
			"multitextinput" : "string",
			"date" : "date",
			"file" : "string"
		},
		wizardTypeIsRepeating: {
			"radio" : false,
			"textarea" : false,
			"textbox" : false,
			"checkbox" : true,
			"multiselect" : true,
			"multitextinput" : true,
			"date" : false,
			"file" : false
		}
	};

	return QuestionUtils;
});
