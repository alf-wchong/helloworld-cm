define([
	'app',
	'moment'
], function(app, Moment){
	var Requried = {};
    Requried.regexp = {
        validate: function(query, model){
            var regexConstants = {
                //use moment and the date service to validate dates
                'date' : {
                    verify: function(query){
                        return (query === 'N/A' || !query) ? window.localize("modules.wizard.services.requiredService.noDate") : undefined;
                    }
                }
            };

            var execute = function(query, type, format){
				if(type && regexConstants[type] === undefined){
					app.log.error(window.localize("modules.wizard.services.requiredService.neitherType")  +
							window.localize("modules.wizard.services.requiredService.mustAddAbility") + type);
				}else if(type){
					return regexConstants[type].verify(query, format);
				}
			};

			//expose just the isValid call
			return execute(query, model.get('formatType'), model.get('format'));
        }
    };

    //pass through if no valiation is supported - check for blank values
    Requried.validate = function(model){
        //empty, undefined, or blank - single value or array
        if(_.isArray(model.get('displayValue')) && model.get('displayValue').length === 0){
            return window.localize("modules.wizard.services.requiredService.pleaseSelectAt");
        }

        if((!model.get('value') && model.get('value') !== 0) ||
        ( typeof model.get('value') === 'string' && !model.get('value').trim() )) {
            return window.localize("modules.wizard.services.requiredService.thisAnswer");
        }

        if((!model.get('displayValue') && model.get('displayValue') !== 0) ||
        ( typeof model.get('displayValue') === 'string' && !model.get('displayValue').trim() )) {
            return window.localize("modules.wizard.services.requiredService.thisAnswer");
        }
    };

    return Requried;
});
