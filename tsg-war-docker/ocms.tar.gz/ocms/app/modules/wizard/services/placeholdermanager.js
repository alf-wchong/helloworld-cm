define([
	'app',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/events/psieventmanager',
	'modules/wizard/events/pageeventmanager'
], function(app, RuleEventManager, QuestionEventManager, PSIEventManager, PageEventManager){
	//runtime cache for tracking placeholders for questions with dependencies
	var PlaceholderManager = {};

	PlaceholderManager.Placeholder = Backbone.Model.extend({
		defaults: {
			'pageId': undefined,
			'inputId': undefined,
			'text': undefined,
			'value': undefined,
			'onpage': false
		},
		initialize: function(options){
			this.startListening();
			//set placeholderIsValid to true if no dependencies
			if(options.staticDependencies){
				this.set('placeholderIsValid', true);
			}
		},
		startListening: function(){
			//listen for any changes to this question
			this.listenTo(QuestionEventManager, 'change:question:validity:' + this.getAddress(), this.updateQuestion, this);
		},
		getAddress: function(){
			return this.get('pageId') + '_' + this.get('inputId');
		},
		updatePage: function(pageId){
			this.set('onpage', this.get('pageId') === pageId);
		},
		updateQuestion: function(question){
			//only update the value if they aren't a static place holder like a group name a la wizard_contributors
			if(!this.has('staticDependencies')){
				//set the question's validity here
				this.set('placeholderIsValid', question.isValid());
				//assume all placeholders are from the value attribute
				//repeating values?
				if(question.get('field').getValues){
					this.set('value', question.get('field').getValues());
				}else{
					this.set('value', question.get('field').getValue());
				}
			}else{
				//static placeholders are always valid
				this.set('placeholderIsValid', true);
			}
		},
		validate: function(){
			//placeholder is not "" or undefined
			var message = this.get('value') ? undefined : window.localize("modules.wizard.services.placeHolderManger.noAnswerFor") + this.getAddress();
			//placeholder satisifies its' questions' validation
			var placeholderIsValid = this.get('placeholderIsValid') ? undefined : window.localize("modules.wizard.services.placeHolderManger.invalidAnswer") + this.getAddress();
			message = (message === undefined && placeholderIsValid === undefined) ? undefined : message + window.localize("modules.wizard.services.placeHolderManger.or") + placeholderIsValid;
			//are we on the right page?
			if(!message){
				message = (this.get('onpage') || this.get('pageId') === app.wizardContext.getCurrentPage(window.location.pathname)) ? undefined : window.localize("modules.wizard.services.placeHolderManger.wrongPage");
			}
			return message;
		}
	});

	PlaceholderManager.Placeholders = Backbone.Collection.extend({
		model: PlaceholderManager.Placeholder,
		isValid: function(){
			var hasErrors = _.some(this.models, function(model){
			    return model.validate();
			});
			return !hasErrors;
		},
		//if there are no dependenices to satisfy but the question has dependencies (like group query params)
		hasDynamicDependencies: function(){
			var hasDynamicDependencies = _.some(this.models, function(placeholder){
				//break on the first dynamic placeholder
			    return !placeholder.has('staticDependencies');
			});
			return hasDynamicDependencies;
		},
		toJSON: function(){
			//we want to create a key -> value map of each repo attribute (text attr) and the value attr
			return  _.object(this.map(function(model) {
				var value = model.get('value');
				//check if its an array first, then an object
				if(_.isArray(value)){
					if(value.length === 0){
						value = '';
					}
					if(_.isObject(value[0])){
						// check if the object is a file, if so set value to be the object id
						if (value[0].file){
							var fileName = value[0].name;
							value = value[0].id[fileName];
						} else {
							//if value is an object, get the value attribute
							value = _.pluck(value, 'value');
						}
					}
					//stringify the array
					value = value.toString();
				//if value is an object, get the value attribute
				}else if(_.isObject(value)){
					value = model.get('value').value;
				}
				return [model.get('text'), value];
			}));
		}
	});

	PlaceholderManager.Model = Backbone.Model.extend({
		idAttribute: 'address',
		initialize: function(options){
			var question = this.question = options.question;
			var action = this.action = options.action;
			var rule = this.rule = options.rule;
			this.pageId = options.pageId;
			var placeholders = [];
			if(action.has('substitutions')){
				placeholders = action.get('substitutions');
			}

			//NOTE: pre-filled substitutions like group names have no implicit input and page id
			var defaults = {
				'inputId': this.question.id,
				'pageId': this.pageId,
				'staticDependencies': true
			};
			_.each(placeholders, function(placeholder){
				//_.defaults doesn't handle empty strings, just undefined
				if(!placeholder.inputId && !placeholder.pageId){
					placeholder = _.extend(placeholder, defaults);
				}
			}, this);
			this.set('placeholders', new PlaceholderManager.Placeholders(placeholders));

			//set address for dup detection and easy removal
			this.set('address', question.getAddress());
			//assume that this page isn't visible to the user yet
			this.set('onpage', false);

			//listen for this placeholders list to change and notify the parent question
			this.listenTo(this.get('placeholders'), 'change:value', function(){
				//if no dynamic dependencies, only fetch once
				if(!this.get('placeholders').hasDynamicDependencies()){
					if(!this.has('fetched')){
						RuleEventManager.trigger('change:placeholders:none', question, rule, action, this.get('placeholders'));
					}
				}else{
					RuleEventManager.trigger('change:placeholders:validity', question, rule, action, this.get('placeholders'), this.isValid(), this.validate());
				}
			}, this);

			//pageIndex is the page index in the url bar, pageId is the actual page as defined by the flowpath
			this.listenTo(PageEventManager, 'change:page', function(pageIndex, pageId){
				this.set('onpage', this.pageId === pageId);

				//update current page for each placeholder
				this.get('placeholders').each(function(placeholder){
					placeholder.updatePage(pageId);
				}, this);

				//fire an event iff placeholders are already valid - DON'T CALL CLEAR
				if(this.isValid() && !this.has('fetched')){
					//only fetch questions with no placeholders once
					this.set('fetched', true);
					RuleEventManager.trigger('change:placeholders:none', question, rule, action, this.get('placeholders'));
				}
			}, this);
		},
		validate: function(){
			var placeholders = this.get('placeholders');
			//if placeholders are empty
			if(placeholders.size() === 0){
				//make sure we're on the correct page
				return this.get('onpage') ? undefined : window.localize("modules.wizard.services.placeHolderManger.wrongPage");
			}else{
				return placeholders.isValid() ? undefined : window.localize("modules.wizard.services.placeHolderManger.placeholderPending") + this.get('question').getAddress();
			}
		}
	});

	PlaceholderManager.Collection = Backbone.Collection.extend({
		model: PlaceholderManager.Model,
		modelId: function(attrs) {
			return attrs.address; //avoid duplicate questions
		},
		initialize: function(options){
			this.stopListening(RuleEventManager);
			this.listenTo(RuleEventManager, 'setup:placeholders', function(question, rule, action){
				this.add({
					'question': question,
					'rule': rule,
					'action': action,
					//pass the question address in so we can track questions with multiple dependencies
					//(and remove this question by its address)
					'address': question.getAddress(),
					//save the page this question resides on
					'pageId': question.getPage()
				});
			}, this);

			//listen for questions to get deleted (grouped questions)
			this.listenTo(RuleEventManager, 'remove:question', function(address){
				var placeHolderToDelete = this.findWhere({'address': address});
				if (placeHolderToDelete){
					this.remove(placeHolderToDelete);
				}
			}, this);
		}
	});


	return PlaceholderManager.Collection;
});
