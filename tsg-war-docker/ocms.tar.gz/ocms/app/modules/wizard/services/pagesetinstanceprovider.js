define([
	'app',
	'modules/wizard/services/flowpathutils'
], function (app, FlowpathUtils) {

	var isRepeatable = function (controlType) {
		var repeatableTypes = ['multiselect', 'checkbox', 'file', 'email', 'multitextinput', 'populator'];
		return _.contains(repeatableTypes, controlType);
	};

	var isGrowable = function (controlType) {
		var growableTypes = ['multiselect'];
		return _.contains(growableTypes, controlType);
	};

	var getNextRuleId = function (rules) {
		//elevating rules causes id collisions - auto-increment
		var ruleIdentifier = rules.length !== 0 ? rules[rules.length - 1]._id : 'ru0'; //default to ru0
		ruleIdentifier = Number(ruleIdentifier.replace('ru', '')); //strip ru prefix and make numberic
		//increment numberId to avoid collision
		ruleIdentifier++;
		if (ruleIdentifier < 10) {
			ruleIdentifier = '0' + ruleIdentifier;
		}
		return 'ru' + ruleIdentifier;
	};

	var checkForJustificationForEachQuestionOption = function (optionsJson, fieldAspects, question) {
		//if there is justification push on a rule onto optionsJson
		var questionHasJustification = optionsJson.justification ? optionsJson.justification.required : undefined;

		if (questionHasJustification) {
			fieldAspects.push('justifiable');
			fieldAspects.push('validatable');
			question.field.validationType = 'justifiable';
			if (optionsJson.rules !== undefined || (optionsJson.rules = {})) {
				if (optionsJson.rules.rule !== undefined && Array.isArray(optionsJson.rules.rule) || optionsJson.rules.rule !== undefined && (optionsJson.rules.rule = [optionsJson.rules.rule]) || (optionsJson.rules.rule = [])) {
					optionsJson.rules.rule.push({
						type: 'justification',
						actions: {
							action: [{
								'justification': 'true'
							}]
						}
					});
				}
			}
		}
	};

	//a target page might originate from an add to end page
	var isPageAddToEnd = function (addToEndPages, pageId) {
		return _.findWhere(addToEndPages, {
			'id': pageId
		});
	};

	var transform = function (rawJson, appConfig) {
		try {
			var psi = {};
			if (!rawJson['page-set-instance']) {
				throw new Error(window.localize("modules.wizard.services.pageSetInstanceProvider.pageSetInstance"));
			}
			//name
			psi.name = rawJson['page-set-instance'].name;
			//workflow enabled?
			psi.hasWorkflow = rawJson['page-set-instance']['workflow-active'] &&
				rawJson['page-set-instance']['workflow-active'].value;
			//support for requiring all questions
			var allQuestionsRequired = rawJson['page-set-instance']['required-question-completion'] &&
				rawJson['page-set-instance']['required-question-completion'].value;
			psi.instanceType = rawJson['page-set-instance']['instance-type'];
			//pages
			psi.pages = [];
			if (!rawJson['page-set-instance'].pages.page) {
				throw new Error('pages not found');
			} else if (!Array.isArray(rawJson['page-set-instance'].pages.page)) {
				//wrap it - single page only
				rawJson['page-set-instance'].pages.page = [rawJson['page-set-instance'].pages.page];
			}

			//add all addToEnd pages at the end of all other leading pages
			var addToEndPages = [];

			_.each(rawJson['page-set-instance'].pages.page, function (pageJson) {
				//form type - should be the same across all pages (Simple CR, TS, etc)
				psi.psdName = pageJson['page-set-name'];

				var shortDescription = "";
				// strips all valid HTML syntax characters from the string
				var escapeHTMLString = function (str) {
					return str.replace(/<\/?[^>]+(>|$)/g, "");
				};
				if (typeof pageJson.description === 'string') {
					//sanitize short description
					var plaintext = escapeHTMLString(pageJson.description);
					//shorten to 78 characters
					shortDescription = plaintext.substr(0, 78);
					//append ellipsis if greater than 78 chars
					shortDescription += (plaintext.length > 78) ? "..." : "";
				}

				var page = {
					'_id': pageJson.id,
					'title': pageJson.title,
					'description': (typeof pageJson.description === 'string') ? pageJson.description : "",
					'shortDescription': shortDescription,
					'category': pageJson.category,
					'required': pageJson.required ? pageJson.required.value : false,
					'sectionalLockdown': (pageJson['sectional-lockdown'] && typeof pageJson['sectional-lockdown'] === 'string') ? pageJson['sectional-lockdown'].split(',') : [],
					'groupLabel' : (pageJson.groupLabel && typeof pageJson.groupLabel === 'string') ? pageJson.groupLabel : "",
					'questions': []
				};

				page.hideInPdf = pageJson['hide-in-pdf'] ? pageJson['hide-in-pdf'].value : false;

				//question groups
				page.questionGroups = [
					[]
				];

				// holds questions that are part of a non repeating question group
				page.nonRepeatingQuestionGroup = [];

				//make inputs into an array - ther may be no questions on this page
				if (pageJson.inputs && !Array.isArray(pageJson.inputs.input)) {
					pageJson.inputs.input = [pageJson.inputs.input];
				}
				//skip if no questions
				if (pageJson.inputs) {
					_.each(pageJson.inputs.input, function (inputJson, index) {

						if (inputJson === undefined) {
							return;
						}

						//generate field aspects
						var fieldAspects = [];
						//make every question validatable
						fieldAspects.push('validatable');

						var question = {
							'_id': inputJson.id,
							'short-label': inputJson['input-short-label'] ? inputJson['input-short-label'].text : inputJson['input-label'] ? inputJson['input-label'].text : '',
							'label': inputJson['input-label'] ? inputJson['input-label'].text : inputJson['input-short-label'] ? inputJson['input-short-label'].text : '',
							'field': {},
							'rules': [],
							'hideInPdf': inputJson['hide-in-pdf'].value ? inputJson['hide-in-pdf'].value : false,
							'columnWidth': inputJson['columnWidth'] ? ((inputJson['columnWidth'].value >= 1 && inputJson['columnWidth'].value <= 12) ? inputJson['columnWidth'].value : 12) : 12 // default to 12 if not provided or outside bounds
						};

						//are all questions required?
						if (allQuestionsRequired) {
							fieldAspects.push('requirable');
							question.required = true;
						}

						//references
						var references = {};
						if (inputJson['template-label'] &&
							typeof inputJson['template-label'] === 'string') {
							references.label = inputJson['template-label'];
						}
						//template-name is the link/url
						if (inputJson['template-name'] &&
							typeof inputJson['template-name'] === 'string') {
							references.url = inputJson['template-name'];
						}
						if (references !== {}) {
							question.references = references;
						}

						//help text
						if (inputJson['help-text']) {
							if (inputJson['help-text'].visible && inputJson['help-text'].visible !== false) {
								question.helpText = inputJson['help-text'].content;
							}
						}

						//part of a non repeating question group
						if (inputJson.nonRepeatingGroup && inputJson.nonRepeatingGroup !== '') {
							var groupItem = pageJson.id + '_' + inputJson.id;
							page.nonRepeatingQuestionGroup.push(groupItem);
						}

						//part of a question group
						if (inputJson.group && inputJson.group !== '') {
							var address = pageJson.id + '_' + inputJson.id;
							page.questionGroups[0].push(address);
						}

						//question type
						question.field.type = inputJson.type;

						var repeatable = isRepeatable(question.field.type);
						//repeatable aspect
						if (repeatable) {
							fieldAspects.push('repeatable');
						}

						var growable = isGrowable(question.field.type);
						//growable aspect
						if (growable) {
							fieldAspects.push('growable');
						}

						question.field.value = repeatable ? [] : '';
						//has options - selectable aspect
						if (inputJson.options && inputJson.options.option) {
							fieldAspects.push('selectable');
							var options = [];

							if (!Array.isArray(inputJson.options.option)) {
								inputJson.options.option = [inputJson.options.option];
							}
							_.each(inputJson.options.option, function (optionsJson) {
								var hideOptionPlaceholder = false;
								var queryResult = 'datasource';
								if (optionsJson.selected && optionsJson.selected.value === true) {
									queryResult = 'value';
									//Checking for more than one default
									if (question.field.value.length > 0) {
										//This is already an array, just push value
										if (_.isArray(question.field.value)) {
											question.field.value.push(optionsJson['option-value'].text);
										} else {
											var tempArr = [];
											tempArr.push(question.field.value);
											tempArr.push(optionsJson['option-value'].text);
											question.field.value = tempArr;
										}
									} else {
										question.field.value = optionsJson['option-value'].text;
									}
								}

								//modifies its parameters
								checkForJustificationForEachQuestionOption(optionsJson, fieldAspects, question);

								//optionsJson at option level - bubble up
								if (optionsJson.rules && optionsJson.rules.rule) {
									//make rules an array
									if (!Array.isArray(optionsJson.rules.rule)) {
										optionsJson.rules.rule = [optionsJson.rules.rule];
									}

									//rules for this option - elevate to the question level
									_.each(optionsJson.rules.rule, function (ruleJson, index) {
										var rule = {
											'_id': ruleJson.id,
											'type': ruleJson.type,
											'addToEnd': ruleJson.addToEnd,
											'actions': []
										};

										if (rule.type === 'query') {
											fieldAspects.push('queryable');
											rule.queryResult = queryResult;
											//hide an option if it is a querying option so users can't select it
											hideOptionPlaceholder = true;
											rule.defaultTo = rule.queryResult === 'value';
										}
										
										//are there actions?
										if (ruleJson.actions.action) {
											//make actions an array
											if (!Array.isArray(ruleJson.actions.action)) {
												ruleJson.actions.action = [ruleJson.actions.action];
											}

											_.each(ruleJson.actions.action, function (actionJson, actionName) {

												//make substitutions sane - wrap it in an array
												if (actionJson.substitution) {
													var substitutions = actionJson.substitution;
													delete actionJson.substitution;
													if (!_.isArray(substitutions)) {
														actionJson.substitutions = [substitutions];
													} else {
														actionJson.substitutions = substitutions;
													}
												}

												rule.actions.push(_.extend({}, actionJson));

												//if a leading action, append non-required page to the map for this page
												if (rule.type === 'leading') {
													var isEndPage = isPageAddToEnd(addToEndPages, page._id);
													//page's parent might be an add to end page, in which case it should go here
													if (rule.addToEnd || isEndPage) {
														//store add to end pages until flowpath has built all other routes
														//treat addToEndPages like a sub-tree ie. has an id and children
														//beacuse an Add To End node can have children

														//first check if the parent page is already an add to end page
														if (isEndPage) {
															isEndPage.children.push({
																'id': actionJson.page.id,
																'visible': false,
																'children': []
															});
														} else {
															addToEndPages.push({
																'id': actionJson.page.id,
																'visible': false,
																'children': []
															});
														}
													}
												}
											}, this);
										}
										//trigger this rule when the question has this value
										rule.triggerOn = [optionsJson['option-value'].text];

										// here we get two types of values - an empty object if no criteria was configured, or a string if it was...
										// save the criteria on the rule only if the object a string and the string is truthy (not '')
										rule.criteria = (typeof ruleJson.criteria === 'string' && ruleJson.criteria) ? ruleJson.criteria : '';

										rule._id = getNextRuleId(question.rules);
										question.rules.push(rule);
									}, this);
								}

								var option = {
									'value': optionsJson['option-value'].text,
									'displayValue': optionsJson['option-label'].text
								};
								//only add visible options
								if (!hideOptionPlaceholder) {
									options.push(option);
								} else {
									//queryable option placeholder dictates what this question's displayValue is
									question.field.displayValue = option.displayValue;
								}
							}, this);
							question.field.options = options;
						}

						//if formattable - add sane formattype and format defaults
						if (inputJson['input-mask'] && inputJson['input-mask'].type || question.field.type) {
							fieldAspects.push('validatable');
							var type = inputJson['input-mask'].type || question.field.type;

							switch (type) {
								case 'number':
									question.field.formatType = 'number';
									question.field.format = 'number';
									fieldAspects.push('formattable');
									break;
								case 'NotEqualtoAnotherAnswer':
									if (inputJson.rules && inputJson.rules.rule && inputJson.rules.rule.type === 'NotEqualtoAnotherAnswer') {
										question.field.compareType = "notEqual";
										question.field.compareTo = inputJson.rules.rule.actions.action['compare-to'].replace(/\$/g, "");
									}
									question.field.label = inputJson['input-label'].text;
									question.field.compareOperator = "!=";

									//had to throw in to stop errors in OC since part of code looks for a format value, don't neccessarily need in this case though
									question.field.format = "";
									break;
								case 'email':
									//email is tricky. it can ether be a single or multitextinput
									if (question.field.type === 'textbox') {
										question.field.type = 'email';
									}
									question.field.formatType = 'email';
									question.field.format = 'email';
									//email isn't formattable
									break;
								case 'date':
									var configFormat = "";
									var jqueryFormat = "";

									configFormat = appConfig.get("dateFormat");
									jqueryFormat = app.context.dateService.getJQueryDateFormat(configFormat);

									//separate date comparison logic from other date logic
									if (inputJson.rules && inputJson.rules.rule && inputJson.rules.rule.type === 'date' && !_.isEmpty(inputJson.rules.rule.actions.action['compare-to'])) {
										// in this case we have date rules of some type. we only will support a limited subset of rules for now.
										// the rules we support are just the compare-to, compare-oper, and the NEW offset parameters.

										question.field.compareType = "date";

										//question to compare value to has $'s attached to it, must remove them
										question.field.compareTo = inputJson.rules.rule.actions.action['compare-to'].replace(/\$/g, "");

										//3 options (<, >, =), comes back as less and greater
										if (inputJson.rules.rule.actions.action['compare-oper'] === "less") {
											question.field.compareOperator = "<";
										} else if (inputJson.rules.rule.actions.action['compare-oper'] === "greater") {
											question.field.compareOperator = ">";
										} else if (inputJson.rules.rule.actions.action['compare-oper'] === "equal") {
											question.field.compareOperator = "=";
										}

										//if unfilled, returns an empty object, sets value to an empty object
										question.field.compareOffset = inputJson.rules.rule.actions.action['offset'];
									}
									question.field.label = inputJson['input-label'].text;
									question.field.formatType = 'date';
									question.field.format = jqueryFormat;
									question.field.simpleDateFormat = app.context.dateService.getSimpleDateFormatterFormat(jqueryFormat);
									question.field.momentFormat = configFormat;
									fieldAspects.push('formattable');
									break;
								case 'phone':
									question.field.type = 'phone';
									fieldAspects.push('formattable');
									question.field.formatType = 'phone';
									question.field.format = 'US';
									break;
								case 'phonena':
									question.field.type = 'phone'; //actual control type
									fieldAspects.push('formattable');
									question.field.formatType = 'phonena';
									question.field.format = 'US';
									break;
								case 'currency':
									question.field.formatType = 'currency';
									question.field.format = 'USD';
									fieldAspects.push('formattable');
									break;
								case 'uscurrency':
									question.field.formatType = 'currency';
									question.field.format = 'USD';
									fieldAspects.push('formattable');
									break;
								case 'time':
									question.field.type = 'time';
									fieldAspects.push('formattable');
									question.field.formatType = 'time';
									question.field.format = 'time';
									break;
								case 'atleastthreechars':
									question.field.formatType = 'atleastthreechars';
									question.field.format = '3';
									break;
								case 'zip':
									question.field.formatType = 'zip';
									question.field.format = '3';
									break;
								case 'militarytime':
									question.field.type = 'time'; //actual control type
									fieldAspects.push('formattable');
									question.field.formatType = 'time';
									question.field.format = 'militarytime';
									break;
								case 'ssn':
									question.field.type = 'ssn';
									fieldAspects.push('formattable');
									question.field.formatType = 'ssn';
									question.field.format = 'ssn';
									break;
								case 'selectedPages':
									fieldAspects.push('formattable');
									question.field.formatType = 'selectedPages';
									question.field.format = 'selectedPages';
									break;
								default:
									question.field.formatType = '';
									question.field.format = '';
									break;
							}
						}

						//requirable aspect
						if (inputJson.required && inputJson.required.value === true) {
							fieldAspects.push('requirable');
							question.required = true;
						}

						//disabled aspec	t
						if (inputJson.disabled && inputJson.disabled.value === true) {
							fieldAspects.push('disabled');
						}

						// hidden aspect
						if (inputJson.hidden && inputJson.hidden.value === true) {
							fieldAspects.push('hidden');
						}

						if (inputJson.type === 'populator') {
							fieldAspects.push('selectable');
						}

						//set field aspects
						question.field.fieldAspects = fieldAspects;
						//are there rules?
						if (inputJson.rules && inputJson.rules.rule) {
							//make rules an array
							if (!Array.isArray(inputJson.rules.rule)) {
								inputJson.rules.rule = [inputJson.rules.rule];
							}

							//rules for this question
							_.each(inputJson.rules.rule, function (ruleJson) {
								if (ruleJson.type === "page-set-instance-property") {
									ruleJson.type = "metadata";
								}
								var rule = {
									'_id': ruleJson.id,
									'type': ruleJson.type,
									'addToEnd': ruleJson.addToEnd,
									'actions': []
								};

								var queryResult = 'datasource';
								if ((inputJson.selected && inputJson.selected.value === true) || !isRepeatable(question.field.type)) {
									queryResult = 'value';
								}

								if (rule.type === 'query') {
									fieldAspects.push('queryable');
									rule.queryResult = queryResult;
									rule.defaultTo = rule.queryResult === 'value';
								}
								
								//are there actions?
								if (ruleJson.actions.action) {
									//make actions an array
									if (!_.isArray(ruleJson.actions.action)) {
										ruleJson.actions.action = [ruleJson.actions.action];
									}

									_.each(ruleJson.actions.action, function (actionJson) {
										//make substitutions sane - wrap it in an array
										if (actionJson.substitution) {
											var substitutions = actionJson.substitution;
											delete actionJson.substitution;
											if (!_.isArray(substitutions)) {
												actionJson.substitutions = [substitutions];
											} else {
												actionJson.substitutions = substitutions;
											}
										}
										//if no substitutions
										rule.actions.push(_.extend({}, actionJson));
									});
								}

								question.rules.push(rule);
							}, this);
						}

						page.questions.push(question);
					}, this);
				}
				psi.pages.push(page);
			}, this);

			//flow path
			psi.flowpath = [];
			if (Array.isArray(rawJson['page-set-instance']['flow-path'].page)) {
				_.each(rawJson['page-set-instance']['flow-path'].page, function (flowpathJson) {
					psi.flowpath.push({
						'id': flowpathJson.id,
						'visible': true,
						'children': []
					});
				}, this);
			} else {
				// then we have just one page object.
				psi.flowpath.push({
					'id': rawJson['page-set-instance']['flow-path'].page.id,
					'visible': true,
					'children': []
				});
			}

			var getChildren = function (flowPage, candidatePages) {
				var children = [];
				_.each(flowPage.questions, function (question) {
					// if the question doesn't have any associated rules we don't have any children to add for that question
					if (question.rules) {
						_.each(question.rules, function (rule) {
							// if the rule doesn't have any actions we don't have to add anything
							if (rule.actions) {
								_.each(rule.actions, function (action) {
									// if the action doesn't have any associated pages we don't have to add anything
									if (action.page) {
										var pageToAdd = _.find(candidatePages, function (page) {
											return !page.required && page._id === action.page.id;
										});
										// recursively call getChildren for each child we are adding
										if (pageToAdd && !_.find(children, function (child) {
												return child.id === pageToAdd._id;
											})) {
											children.push({
												'id': pageToAdd._id,
												'visible': false,
												'children': getChildrenHelper(pageToAdd, candidatePages)
											});
										}
									}
								});
							}
						});
					}
				});
				return children;
			};

			// getChildren helper function that handles matching the page to the correct page for the flowpath
			var getChildrenHelper = function (pageToAdd, candidatePages) {
				var flowPage = _.find(candidatePages, function (page) {
					return pageToAdd._id === page._id;
				});

				var children;
				if (flowPage && flowPage.questions) {
					// call the getChildren with the flowPage we found 
					children = getChildren(flowPage, candidatePages);
				}

				return children;
			};

			var nonEndPages = [];
			// we need to know which are non-end pages since those won't be added to the flowpath until the end
			// this is what we'll pass into the getChildren function
			_.each(psi.pages, function (page) {
				if (!_.find(addToEndPages, function (endPage) {
						return endPage.id === page._id;
					})) {
					nonEndPages.push(page);
				}
			});

			// iterate through the base flowpath we have so far and add the children associated to each flowpath node
			// psi.flowpath is all required pages except for "addToEnd" pages since those are always added after the flowpath
			_.each(psi.flowpath, function (node) {

				// we grab the page that matches the ID from our pages array
				var flowPage = _.find(psi.pages, function (page) {
					return page._id === node.id;
				});

				// call the recursive getChildren function to populate the flowpath
				if (flowPage && flowPage.questions) {
					node.children = getChildren(flowPage, nonEndPages);
				}
			});

			_.each(addToEndPages, function (endingPage) {
				psi.flowpath.push(endingPage);
			}, this);
			return psi;
		} catch (e) {
			app.log.error(window.localize("modules.wizard.services.pageSetInstanceProvider.failedToTransform") + e.message);
			return 'N/A';
		}
	};

	return {
		transformJSON: function (rawJson, appConfig) {
			return transform(rawJson, appConfig);
		}
	};
});