define([
	'app',
	'moment'
], function(app, Moment){
	var MILITARY_TIME = 'militarytime';
	var TIME = 'time';

	var Validation = {};

	Validation.localization = {
		badRepeaterEmailMessage : 'You have selected an invalid email address. Please remove any invalid email addresses.',
		badSingleEmailMessage	: 'Please enter a valid email address.'

	};
	
	Validation.regexp = {
		validate: function(query, model){
			var regexConstants = {
				'email': {
					verify: function(query){
                        //the linter through an error about escaping were you looking for the . or \
						var emailRegex = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*" +
							"@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
						if(Array.isArray(query)){
							var validMsg;
							_.each(query, function(value){
								if(validMsg === undefined){ //not invalidated yet...
									validMsg = emailRegex.test(value) ? undefined : Validation.localization.badRepeaterEmailMessage;
								}
							}, this);
							return validMsg;
						}else{
							return emailRegex.test(query) ? undefined : Validation.localization.badSingleEmailMessage;
						}
					}
				},
				//use moment and the date service to validate dates
				'date' : {
					verify: function(query, format){
						var momentFormat = app.context.dateService.getMomentDateFormat(format);
						if(query === 'N/A' || !query){
							return undefined;
						}else{
							return Moment(query, momentFormat).isValid() ? undefined : window.localize("modules.wizard.services.validationServiece.invalidDateFormat");
						}
					}
				},
				'time' : {
					verify: function(query, format){
						var error;
						if(!query){
							app.log.debug( window.localize("modules.wizard.services.validationServiece.noTimeSpecified"));
							error = window.localize("modules.wizard.services.validationServiece.noTimeSpecified");
						}else{
							var time = query.split(':');
							if(time.length === 2){
								try{
									if(isNaN(Number(time[0]))){
										throw new Error(window.localize("modules.wizard.services.validationServiece.hoursAreNotANum"));
									}
								}catch(e){
									error = window.localize("modules.wizard.services.validationServiece.invalidHourFormat");
								}
								try{
									if(isNaN(Number(time[1]))){
										throw new Error(window.localize("modules.wizard.services.validationServiece.minutesAreNotANum"));
									}
								}catch(e){
									if(error){
											error += '; ' + window.localize("modules.wizard.services.validationServiece.invalidMinutesFormat");
									}else{
										error = window.localize("modules.wizard.services.validationServiece.invalidMinutesFormat");
									}
								}
								var hours = parseInt(time[0], 10);
								if((hours > 23 || hours < 0) && format === MILITARY_TIME){
									error = window.localize("modules.wizard.services.validationServiece.hoursBetweenZeroAndTwentyThree");
								}else if((hours > 12 || hours < 1) && format === TIME){
									error = window.localize("modules.wizard.services.validationServiece.hoursBetweenOneAndTwelve");
								}
								var minutes = parseInt(time[1], 10);
								if(minutes > 59 || minutes < 0){
									if(error){
											error += '; ' + window.localize("modules.wizard.services.validationServiece.minutesBetweenZeroAndFiftyNine");
									}else{
											error = window.localize("modules.wizard.services.validationServiece.minutesBetweenZeroAndFiftyNine");
									}
								}
							}
							return error;
						}
					}
				},
				'atleastthreechars': {
					verify: function(query){
						var error;
						if(query && query.length < Number(model.get('format'))){
							error = window.localize("modules.wizard.services.validationServiece.answerMustBeAtLeast") + Number(model.get('format')) + window.localize("modules.wizard.services.validationServiece.characters");
						}
						return error;
					}
				},
				'phone': {
					verify: function(query){
						var error;
						var sanitizedPhone = query.match(/\d/g) ? query.match(/\d/g).join('') : "";
						if(sanitizedPhone.length !== 10 && sanitizedPhone.length !== 11){
							error = window.localize("modules.wizard.services.validationServiece.answerMustContain");
						}
						return error;
					}
				},
				'phonena': {
					verify: function(query){
						var error;
						if(query.toUpperCase() === 'N/A' || query.toUpperCase() === 'NA'){
                        	return;
						}else{
							var sanitizedPhone = query.match(/\d/g) ? query.match(/\d/g).join('') : "";
							if(sanitizedPhone.length !== 10 && sanitizedPhone.length !== 11){
								error = window.localize("modules.wizard.services.validationServiece.answerMustContain");
							}
						}
						return error;
					}
				},
				'number': {
					verify: function(query){
						var error;
						try{
							var isNumber = Number(query);
							if(isNaN(isNumber)){
								throw new Error('NaN');
							}
						}catch(e){
							error = window.localize("modules.wizard.services.validationServiece.failedToConvert") + query + window.localize("modules.wizard.services.validationServiece.toNumber");
						}
						return error;
					}
				},
				'currency': {
					verify: function(query){
						var error;
						try{
							var currencyRegex = new RegExp(/^\$(([1-9]\d{0,2}(,\d{3})*)|(([1-9]\d*)?\d))(\.\d\d)?$/g);
							error = currencyRegex.test(query) ? undefined : window.localize("modules.wizard.services.validationServiece.invalidCurrency");

						}catch(e){
							error = window.localize("modules.wizard.services.validationServiece.failedToValidate") + query + window.localize("modules.wizard.services.validationServiece.asACurrency");
						}
						return error;
					}
				},
				'ssn': {
					verify: function(query){
						//credit: http://stackoverflow.com/questions/4087468/ssn-regex-for-123-45-6789-or-xxx-xx-xxxx
						var hyphenedSSNRegex = new RegExp(/^(?!(000|666|9))\d{3}-(?!00)\d{2}-(?!0000)\d{4}$/);
						var ssnRegex = new RegExp(/^(?!(000|666|9))\d{3}(?!00)\d{2}(?!0000)\d{4}$/);
						return (hyphenedSSNRegex.test(query) || ssnRegex.test(query)) ? undefined : window.localize("modules.wizard.services.validationServiece.invalidSocialSecurityNum");
					}
				},
				'zip': {
					verify: function(query){
						var zipCodeRegex = new RegExp(/^(\d{5}$)|(\d{5}-\d{4})$/);
						return zipCodeRegex.test(query) ? undefined : window.localize("modules.wizard.services.validationServiece.invalidZipCode");
					}
				},
				'selectedPages': {
					verify: function(query){
						var selectedPageRegex = new RegExp(/^[ (\d+\s*) | (\d+\s*),(\s*\d+) | (\d+\s*)\-(\d+\s*) ]+$/);
						return selectedPageRegex.test(query) ? undefined : window.localize("modules.wizard.services.validationServiece.invalidSelectPages");
					}
				}
			};

			var execute = function(query, type, format){
				if(type && regexConstants[type] === undefined){
					app.log.error(window.localize("modules.wizard.services.validationServiece.neitherTypeOrMask") +
							window.localize("modules.wizard.services.validationServiece.mustAddAbility") + type);
				}else if(type){
					//pass existance checks to the required service
					if(query === undefined || query === ''){
						return undefined;
					}
					return regexConstants[type].verify(query, format);
				}
			};

			//expose just the isValid call
			return execute(query, model.get('formatType'), model.get('format'));
		}
	};

    Validation.justifiable = {
        validate: function(option, model) {
            var isJustified;
            if(Array.isArray(option)){
                _.each(option, function(selectedValue){
                    if(model.get('justifications')[selectedValue] === ""){
                        isJustified = window.localize("modules.wizard.services.validationServiece.missingAJustification");
                    }
                });
            }
            else {
            	if(option && _.isObject(option)){
            		option = option.value;
            	}
                if(model.get('justifications')[option] === ""){
                    isJustified = window.localize("modules.wizard.services.validationServiece.missingAJustification");
                }
            }
            return isJustified;
        }
    };

	Validation.files = {
		validate: function(files){
			var message;
			if(!files || (Array.isArray(files) && files.length === 0)){
				return window.localize("modules.wizard.services.validationServiece.noFilesToValidate");
			}else{
				_.each(files, function(file){
					if(file.error){
						if(!message){
							//found an error, start building error message
							message = {};
						}
						message[file.name] = window.localize("modules.wizard.services.validationServiece.failedToUpload");
					}
				}, this);
			}

			return JSON.stringify(message);
		}
	};

	Validation.compare = {
		date: {
			validate: function(val1, val2, compareOperator, offset, val1Label, val2Label, model) {
				//check negative offsets

				//negative offset example: if val1 is 1/4/2018, offset is -2 and compareOperator is >, 
				//val2 must be 1/2/2018 or later

				var intOffset = parseInt(offset, 10);

				if(intOffset < 0 && compareOperator !== '=') {
					var messageOffset = intOffset * (-1);

					//greater than (for negative offset) 
					if(compareOperator === '>') {
						if(Moment(val1, model.get('momentFormat')) > Moment(val2, model.get('momentFormat')).add(intOffset-1, 'days')) {
							return;
						} else {
							return val1Label + " cannot be more than " + messageOffset + " days earlier than " + val2Label;
						}
					}
					//less than (for negative offset)
					if(compareOperator === '<') {
						if(Moment(val1, model.get('momentFormat')) < Moment(val2, model.get('momentFormat')).subtract(intOffset-1, 'days')) {
							return;
						} else {
							return val1Label + " cannot be more than " + messageOffset + " days later than " + val2Label;
						}
					}
				}

				//check positive offsets

				//positive offset example: if val1 is 1/4/2018, offset is 2 and compareOperator is <, 
				//val2 must be 1/2/2018 or earlier

				//for the positive offsets, must check for empty offset here or else message to user when failure looks bad

				if(compareOperator === '>') {
					if(Moment(val1, model.get('momentFormat')) > Moment(val2, model.get('momentFormat')).add(intOffset-1, 'days')) {
						return;
					} else if(intOffset === 0 || isNaN(intOffset)) {
						return " must be after " + val2;
					} else {
						return val1Label + " must be at least " + offset + " day(s) after " + val2Label;
					}
				}
				//check for empty offset here as well
				if(compareOperator === '<') {
					if(Moment(val1, model.get('momentFormat')) < Moment(val2, model.get('momentFormat')).subtract(intOffset-1, 'days')) {
						return;
					} else if(intOffset === 0 || isNaN(intOffset)) {
						return val1Label + " must be before " + val2Label;
					} else {
						return val1Label + " must be at least " + offset + " day(s) before " + val2Label;
					}
				}

				//check for equal value here
				if(compareOperator === '=') {
					if(val1 === val2) {
						return;
					} else {
						return val1Label + " must be the same as the " + val2Label + " answer";
					}
				}
			}
		},
		notEqual: {
			validate: function(val1, val2, compareOperator, offset, val1Label, val2Label, model) {

				//for string comparison (only text boxes and select boxes for now)

				if (val1 !== val2)
				{
					return;
				} else {
					return val1Label + " cannot be the same as the " + val2Label + " answer";
				}
			}
		}
	};

	return Validation;
});