define([
    'app'
], function(app){
    var FlowpathUtils = {
        /**
         * pages: a Backbone.Collection of Page models
         * srcPage: page id i.e. pg0, pg10
         * targetPage: page id i.e. pg0, pg10
        **/
        getPage: function(pages, srcPage, targetPage){
            return this.getPageHelper(pages, srcPage, targetPage, undefined, 0);
        },
        /**
         * This function recursivly walks the flowpath schema looking for the target page.
         * validParent verifies that the target page is attached to the correct parent.
         * This matters in situations where multiple pages lead to the same page.
         * See flowpathSpec.js 'supports leading to a page from two different pages'
        **/
        getPageHelper: function(pages, srcPage, targetPage, validParent, depth){
            // need to have context to have a correct scope for recursion
            var context = { getPageHelper: this.getPageHelper, result : undefined };
            if(!(pages instanceof Backbone.Collection)){
                pages = new Backbone.Collection(pages);
            }
            pages.each(function(page){
                if(!this.result){
                    //root pages don't have a parent page - depth === 0
                    if(page.id === targetPage && (validParent || depth === 0)){
                        this.result = page;
                    }else if(page.has('children')){
                        this.result = this.getPageHelper(page.get('children'), srcPage, targetPage, page.id === srcPage, depth + 1);
                    }
                }
            }, context);
            return context.result;
        },
        /**
         * Util for returning the parent page of the specified target page
        **/
        getParentPage: function(pages, srcPage, targetPage){
            return this.getParentPageHelper(pages, srcPage, targetPage, undefined, undefined, 0);
        },
        getParentPageHelper: function(pages, srcPage, targetPage, parent, validParent, depth){
            // need to have context to have a correct scope for recursion
            var context = { getParentPageHelper: this.getParentPageHelper, result : undefined };
            if(!(pages instanceof Backbone.Collection)){
                pages = new Backbone.Collection(pages);
            }
            pages.each(function(page){
                if(!this.result){
                    //root pages don't have a parent page - depth === 0
                    if(page.id === targetPage && (validParent || depth === 0)){
                        this.result = parent;
                    }else if(page.has('children')){
                        this.result = this.getParentPageHelper(page.get('children'), srcPage, targetPage, page, page.id === srcPage, depth + 1);
                    }
                }
            }, context);
            return context.result;
        }
    };

    return FlowpathUtils;
});
