define([
	'app',
	'URIjs/URI'
], function(app, URI){
	
	var SectionalLockdown = {};

	//fetch the status of this form
	SectionalLockdown.getStatus = function(formId){
		var self = this;
		var aw_status = '';
		var uri = new URI(app.serviceUrlRoot)
				.segment('content/properties')
				.setQuery('id', formId)
				.toString();
		$.ajax({
			'url': uri,
			'async': false,
			success: $.proxy(function(response){
				aw_status = response.properties.aw_status;
			}, self)
		});
		return aw_status;
	};

	//fetch the current roles for this user on this form
	SectionalLockdown.getMyWorkflowRoles = function(formId){
		var self = this;
		var roles = [];
		var uri = new URI(app.serviceUrlRoot)
				.segment('aw-workflow/getMyWizardTasks')
				.setQuery('formId', formId)
				.toString();
		$.ajax({
			'url': uri,
			'async': false,
			success: $.proxy(function(response){
				roles = response;
			}, self)
		});
		return roles;
	};

	SectionalLockdown.getApprovalDetails = function(formId){
		var self = this;
		var approvalDetails = [];
		var uri = new URI(app.serviceUrlRoot)
				.segment('aw-workflow/getWizardWorkflowStatus')
				.setQuery('formId', formId)
				.toString();
		$.ajax({
			'url': uri,
			'async': false,
			success: $.proxy(function(response){
				approvalDetails = response;
			}, self)
		});
		return approvalDetails;
	};

	SectionalLockdown.Page = Backbone.Model.extend({
		initialize: function(config, options){
			this.id = config.id;
			this.allowedRoles = config.allowedRoles || [];
			var isEnabled = false;
			
			//if no configured roles, then anyone can edit this page in an approval route
			//so long as no ther pages have sectional lockdown enabled
			if(_.isEmpty(this.allowedRoles)){
				isEnabled = true;
			}else{
				//has configured roles for this page
				switch(options.status){
					case 'Pending Approval': {
						if(_.isEmpty(options.myRoles)){
							//user has no roles and in a route
							this.set('lockedBy', {
								'reason': '<p>'+ window.localize("modules.wizard.services.sectionalLockdownService.youAreNot")+'</p>'
							});
							isEnabled = false;
						}else{
							var signedFor = false;
							//if any allowed roles are approved or rejected, this page is locked down
							_.some(this.allowedRoles, function(allowedRole){
								var roles = this.getRoles(allowedRole, _.extend({}, _.extend({}, options.approvalDetails)));
								_.some(_.pluck(roles, 'status'), function(status){
									signedFor = (status === 'approve' || status === "reject");
									return signedFor;
								});
								//a role on this page is signed for - page is locked down
								if(signedFor){
									//there may be any roles for parallel tasks but the role names are all the same here
									//getRoels sorts the roles in ascending order by signing date - with the earliest first
									//make sure we copy this to approval details doesn't get contaminated
									var lockedByRole = _.extend({}, roles[0]);

									//map status to the correcct tense
									var status = lockedByRole.status;
									switch(status){
										case 'approve':
											status = 'approved';
											break;
										case 'reject':
											status = 'rejected';
											break;
									}
									lockedByRole.status = status;
									lockedByRole.date = moment(lockedByRole.date).format();
									//if theres an assignee and this role is signed, let the user know who signed off on this page
									var reason = '<p>'+ window.localize("modules.wizard.services.sectionalLockdownService.thisPageIsDisabled") + lockedByRole.userId + window.localize("modules.wizard.services.sectionalLockdownService.has") + lockedByRole.status + window.localize("modules.wizard.services.sectionalLockdownService.asTheRole") +  lockedByRole.role + '.' +'</p>';
									lockedByRole.reason = reason;
									//put flag to display a table of info about the signer
									lockedByRole.info = true;
									this.set('lockedBy', _.pick(lockedByRole, ['role', 'userId', 'status', 'date', 'comment', 'reason', 'info']));
									isEnabled = false;
								}
								return signedFor; //breakout if a role is already been signed for
							}, this);
							//found a signature - break out
							if(signedFor){
								break;
							}
							//otherwise check if this page's configured roles match a pending task
							_.some(this.allowedRoles, function(allowedRole){
								isEnabled = _.findWhere(options.myRoles, {
												'roleName': allowedRole
											}) !== undefined;
								return isEnabled;
							}, this);

							//user has roles but lacks the right ones if we get here
							if(!isEnabled){
								this.set('lockedBy', {
									'reason': '<p>' +window.localize("modules.wizard.services.sectionalLockdownService.youAreNot")+'</p>'
								});
							}
						}
						break;
					}
					default: {
						//all other lifecycle states
						isEnabled = true;
					}
				}
			}
			this.set('enabled', isEnabled);
		},
		//is role approved or rejected? (not pending)
		getRoles: function(roleName, approvalDetails){
			var roleDetails;
			if(approvalDetails && approvalDetails.formSignatures){
				//multiple roles with the same name means parallel taasks
				roleDetails = _.where(approvalDetails.formSignatures, {
					'role': roleName
				});
				//sort roles by the date they were signed
				roleDetails = _.sortBy(roleDetails, function(role){
					//earliest date at the top and asencing order from there
					return -role.date; 
				});
			}
			return roleDetails;
		},
		isEnabled: function(){
			return this.get('enabled');
		},
		isLocked: function(){
			return !this.get('enabled');
		},
		disablePage: function(reason){
			//only lockdown the page if its still enabled
			//and no roles are configured for ir
			if(this.isEnabled() && _.isEmpty(this.allowedRoles)){
				this.set('enabled', false);
				this.set('lockedBy', {
					'reason': reason
				});
			}
		},
		getLockedBy: function(){
			return this.has('lockedBy') ? this.get('lockedBy') : undefined;
		}
	}); 


	SectionalLockdown.Pages = Backbone.Collection.extend({
		model: SectionalLockdown.Page,
		initialize: function(){
			this.bindEvents();
		},
		bindEvents: function(){
			this.on('add', this.sectionalLockdownEnabled, this );
		},
		sectionalLockdownEnabled: function(){
			var isSectionalLockdownEnabled = false;
			//if any page has sectional lockdown enabled, all pages are locked down regardless of their per-page configuration
			this.some(function(page){
				isSectionalLockdownEnabled = page.isLocked();
				return isSectionalLockdownEnabled;
			});
			
			//check tbe entire collection to lockdown pages without any configuration or roles
			if(isSectionalLockdownEnabled){
				//disable every page
				this.each(function(page){
					page.disablePage('<p>'+window.localize("modules.wizard.services.sectionalLockdownService.thisPageIs")+'</p>');
				});
			}
		}
	});

	SectionalLockdown.Service = Backbone.Model.extend({
		defaults: {
			'formId': ''
		},
		initialize: function(config){
			this.formId = config.formId;
			this.status = SectionalLockdown.getStatus(this.formId);
			this.myRoles = SectionalLockdown.getMyWorkflowRoles(this.formId);
			this.approvalDetails = SectionalLockdown.getApprovalDetails(this.formId);
			this.pages = new SectionalLockdown.Pages();
			//config.pages is an array of Page JS objects to not trigger the chained initialization
			_.each(config.pages, function(page){
				this.pages.add(new SectionalLockdown.Page({
					'id': page._id,
					'allowedRoles': page.sectionalLockdown
				}, 
				{
					'status': this.status,
					'myRoles': this.myRoles,
					'approvalDetails': this.approvalDetails
				}));
			}, this);
		},
		getPage: function(pageId){
			return this.pages.findWhere({
				'id': pageId
			});
		}
	});

	return SectionalLockdown;
});