define([
'app',
'modules/wizard/events/questioneventmanager'
], function(app){
	var QueryService = {};

	QueryService.WizardQuery = Backbone.Model.extend({
		initialize: function(options){
			this.queryName = options.queryName;
		},
		url: function(){
			return app.serviceUrlRoot + "/aw-form/getWizardQuery?queryName=" + this.queryName;
		}
	});

	QueryService.ResultSet = Backbone.Collection.extend({
		idAttribute: '_id',
		initialize: function(config){
			var self = this;
			this.question = config.question || {};
			this.action = _.extend({}, config.action.attributes);
			this.substitutions = {};
			//If the substitutions are directly on the config, use them.  Otherwise, use the substitutions on the action.
			if(_.pairs(config.substitutions).length > 0){
				this.substitutions = config.substitutions;
			} else{
				if(this.action.substitutions){
					_.each(this.action.substitutions, function(sub){
						self.substitutions[sub.text] = sub.value;
					});
				} else {
					_.each(this.action.substitution, function(sub){
						self.substitutions[sub.text] = sub.value;
					});
				}
				
			}
			this.columnNames = config.columnNames || [];
		},
		url: app.serviceUrlRoot + "/aw-form/executeWizardQuery",
		sync: function(method, collection, options){
		    // Post data as FormData object on create to allow file upload
		    if(method === 'read'){
		    	//FormData is not supported in IE 9
		  		var parameters = {
					'queryName': this.action.name,
					'substitutions[]': JSON.stringify(this.substitutions)
				};
				_.defaults(options || (options = {}), {
					data: parameters
				});
			}
			return Backbone.sync.call(this, method, collection, options);
		},
		parse: function(json){
			var column, models = [];
			_.each(json.results, function(model){
				var result = {};
				_.each(model.columns, function(column){
					//type is stored weirdly in type-specific key string -> strings double -> doubles
					result[column.name] = column[column.type + 's'][0];
					//field value and displayValue point to the columns to use
					if(column.name === this.question.get('field').get('value')){
						result.value = column[column.type + 's'][0];
					}
					if(column.name === this.question.get('field').get('displayValue')){
						result.displayValue = column[column.type + 's'][0];
					}
				}, this);
				//fallback to the first and second columns as value followed by displayValue
				//example query: aw users in group
				if(!result.value){
					column = model.columns[0];
					result.value = column[column.type + 's'][0];
				}
				// //enforce a displayText and value attr if only one column
				if(this.columnNames.length === 1 && !result.displayValue){
					//answer_value/triggerOn denotes which column we're interested in
					column = _.findWhere(model.columns, {'name': this.columnNames[0]});
					if(column){
						result.value = column[column.type + 's'][0];
						//attempt to set a display value, if no other column, set it to the value
						var possibleColumns = _.without(model.columns, column);
						if(possibleColumns.length === 0){
							result.displayValue = result.value;
						}else{
							//select the first column
							result.displayValue = possibleColumns[0][possibleColumns[0].type + 's'][0];
						}
					}
				}
				//final case - multipe columns but still no displayValue, assume the second column
				if(!result.displayValue){
					column = model.columns[1];
					result.displayValue = column[column.type + 's'][0];
				}
				models.push(result);
			}, this);
			return models;
		}
	});

	return QueryService;
});