define([
	'app',
	'modules/common/action',
	'module'
], function(app, Action, module){
	
	var PSIUtil = {};

	PSIUtil.createFolder = function(psi, deferred){
		if(!deferred){
			deferred = $.Deferred();
		}
		if(psi.has('psiFolderId')){
			deferred.resolve(psi.get('psiFolderId'));
			return deferred.promise();
		}
		var action = new Action.Model({
			name: 'createPSIFolder',
			parameters: {
				'folderType': 'Folder',
				'psiName': psi.get('name'),
				'folderPath': module.config().wizardPsiFolderPath || '/Wizard/wizard'
			}
		});

		action.execute({
			success: function(action){
				psi.set('psiFolderId', action.result);
				deferred.resolve(action.result);
			}
		});

		return deferred.promise();
	};

	return PSIUtil;
});