define([
	'app',
	'moment',
	'numeral',
	"modules/common/hpiconstants"
], function(app, Moment, Numeral, HPIConstants){

	var FormatService = {};

	FormatService.unformat = function(rawValue, formatType, format){
		//only attempt to unformat if a number-based format (currency for ex.)
		var unformatMatrix = {
			'currency': {
				'USD' : function(){
					try{
						if(rawValue === undefined || 
						   rawValue === '' 		  ||
						   rawValue === 'N/A'){
							throw new Error(window.localize("modules.wizard.services.formatService.notAValid"));
						}
						return Numeral().unformat(rawValue);
					}catch(e){
						return '';
					}
				}
			}
			//add custom unformatting here - see formatMatrix for the style
		};
		try{
			//no value to format
			if(rawValue === undefined){
				return rawValue;
			}
			//no formatType found
			else if(!unformatMatrix[formatType]){
				return rawValue;
			}else if(!unformatMatrix[formatType][format]){
				return rawValue;
			}else{
				return unformatMatrix[formatType][format]();
			}
		}catch(e){
			return rawValue;
		}
	};

	FormatService.format = function(rawValue, formatType, format){

		var formatTime = function(){
			try{
				if(rawValue === undefined || 
				   rawValue === '' 		  ||
				   rawValue === 'N/A'){
					throw new Error(window.localize("modules.wizard.services.formatService.notANumber"));
				}
				var time = rawValue.split(':');
				var hour = parseInt(time[0], 10);
				if(hour > -1 && hour < 10){
					if(!isNaN(time[0])){
						time[0] = '0' + hour;
					}
				}
				
				if(hour && time[1] === ""){
					time[1] = "00";
				}
				var minute = parseInt(time[1], 10);
				if(minute > -1 && minute < 10){
					if(!isNaN(time[1])){
						time[1] = '0' + minute;
					}
				}
				return time.join(':');
			}catch(e){
				return 'N/A';
			}
		};

		var formatMatrix = {
			'string': {
				'uppercase': function(){ return rawValue.toUpperCase(); },
				'lowercase': function(){ return rawValue.toLowerCase(); }  
			},
			'date' : {
				//To use the format service when checking for validity, dates not in moment format must be converted to moment format. ex: mm-dd-yy -> MM-DD-YYYY

				'MM/DD/YYYY': function(){
					var formattedDate = Moment(rawValue).format('MM/DD/YYYY');
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'MM-DD-YYYY': function(){
					var formattedDate = Moment(rawValue).format('MM-DD-YYYY');
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'mm-dd-yy': function(){ 
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.Long).format(HPIConstants.Date.moment.Long);
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'yy-dd-mm': function(){ 
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.ISO).format(HPIConstants.Date.moment.ISO); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'mm-dd-y': function(){ 
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.Short).format(HPIConstants.Date.moment.Short); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'YYYY-MM-DD': function(){ 
					var formattedDate = Moment(rawValue).format('YYYY-MM-DD'); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'yy-mm-dd': function(){ 
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.YearFirst).format(HPIConstants.Date.moment.YearFirst); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'dd-M-yy': function(){
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.Euro).format(HPIConstants.Date.moment.Euro);
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'MM-DD-YY z': function(){
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.ShortTZ).format(HPIConstants.Date.moment.ShortTZ); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'MM-DD-YYYY z': function(){
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.LongTZ).format(HPIConstants.Date.moment.LongTZ); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'DD, MM dd, yy': function(){
					var formattedDate = Moment(rawValue, HPIConstants.Date.moment.USA).format(HPIConstants.Date.moment.USA); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				},
				'YYYY-MM-DD HH:mm Z': function(){
					var formattedDate = Moment(rawValue).format('YYYY-MM-DD HH:mm Z'); 
					if(formattedDate === 'Invalid date'){
						return 'N/A';
					} 
					return formattedDate; 
				}
			},
			'phone' : {
				'US' : function(){ 
					var formattedValue = rawValue;
                    if(formattedValue.length >= 10){
                        var numbers = formattedValue.match(/\d/g).join('');
                        if(numbers.length === 10){
                            formattedValue = numbers.substr(0,3) + '-' + numbers.substr(3,3) + '-' + numbers.substr(6,4);
                        }
                        else if(numbers.length === 11){
                            formattedValue = numbers.substr(0,1) + '-' + numbers.substr(1,3) + '-' + numbers.substr(4,3) + '-' + numbers.substr(7,4);
                        }
                    }
					return formattedValue;
				}
			},
			'phonena' : {
				'US' : function(){ 
					var formattedValue = rawValue;
                    if(formattedValue.toUpperCase() === "N/A" ||formattedValue.toUpperCase() === "NA"){
                    	return "N/A";
                    }else if(formattedValue.length >= 10){
                        var numbers = formattedValue.match(/\d/g).join('');
                        if(numbers.length === 10){
                            formattedValue = numbers.substr(0,3) + '-' + numbers.substr(3,3) + '-' + numbers.substr(6,4);
                        }
                        else if(numbers.length === 11){
                            formattedValue = numbers.substr(0,1) + '-' + numbers.substr(1,3) + '-' + numbers.substr(4,3) + '-' + numbers.substr(7,4);
                        }
                    }
					return formattedValue;
				}
			},
			'currency': {
				'USD' : function(){
					try{
						if(rawValue === undefined || 
						   rawValue === '' 		  ||
						   rawValue === 'N/A'){
							throw new Error(window.localize("modules.wizard.services.formatService.notAValid"));
						}
						return Numeral(rawValue).format('$0,0.00');
					}catch(e){
						return '';
					}
				}
			},
			'time': {
				'time': formatTime,
				'militarytime': formatTime
			},
			'number': {
				'number': function(){
					try{
						if(rawValue === undefined || 
						   rawValue === '' 		  ||
						   rawValue === 'N/A'){
							throw new Error(window.localize("modules.wizard.services.formatService.notANumber"));
						}
						return Number(rawValue);
					}catch(e){
						return '';
					}
				}
			},
			'ssn': {
				'ssn': function(){
					try{
						if(rawValue === undefined || 
						   rawValue === '' 		  ||
						   rawValue === 'N/A'){
							throw new Error(window.localize("modules.wizard.services.formatService.notASocialSecurity"));
						}
						var formattedValue = rawValue;
						var numbers = formattedValue.match(/\d/g).join('');
						formattedValue = numbers.substr(0,3) + '-' + numbers.substr(3,2) + '-' + numbers.substr(5,4);
						return formattedValue;
					}catch(e){
						return 'N/A';
					}
				}
			},
			'selectedPages': {
				'selectedPages': function(){
					// replace any spaces between numbers with a comma
					var regex = /(\d)\s+(?=\d)/g;
					var formattedValue = rawValue.replace(regex, '$1,');
					// remove any whitespace
					regex = /\s+/g;
					formattedValue = formattedValue.replace(regex, '');
					return formattedValue;
				}
			}
		};
		try{
			//no value to format
			if(rawValue === undefined){
				return 'N/A';
			}
			//no formatType found
			else if(!formatMatrix[formatType]){
				app.log.error(window.localize("modules.wizard.services.formatService.noFormatType") + formatType);
				return 'N/A';
			}else if(!formatMatrix[formatType][format]){
				app.log.error(window.localize("modules.wizard.services.formatService.noFormat") + formatType + window.localize("modules.wizard.services.formatService.with") + format);
				return 'N/A';
			}else{
				return formatMatrix[formatType][format]();
			}
		}catch(e){
			app.log.error(e.message);
			return 'N/A';
		}
	};

	return FormatService;
});