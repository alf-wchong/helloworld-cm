define([
	'app',
	'numeral',
	'modules/wizard/events/psieventmanager'
], function(app, Numeral, PSIEventManager){

	var Formula = {};

	var unwrap = function(exp){
		return exp.replace(/\$/g, '');
	};

	//get solution for this variable
	var fufill = function(exp){
		var deferred = $.Deferred();
		PSIEventManager.trigger('psi:find:model', exp, deferred);
		return deferred.promise();
	};

	//get unwrapped expressions from the formula
	var getExpressions = function(formula, wrapped){
		var expressions = [];
		var variables = formula.match(/\$\w+\$/g);
	    _.each(variables, function(exp){ 
	    	if(wrapped){
	    		expressions.push(exp);
	    	}else{
	        	//unwrap $\w$ to get variable from expression
	        	expressions.push(unwrap(exp));
	    	}
	    });
		return expressions;
	};

	//get list of models to listen to for change
	Formula.expressions = function(formula){
		return getExpressions(formula);
	};

	//take an expression and tokenize ex: 100 * ($pg0_i1$ * $pg0_i2$) 
	Formula.evaluate = function(formula, decimalPrecision){
		var evalComplete = $.Deferred();
		var variables = getExpressions(formula, true);
		if(variables){
			var expCount = variables.length;
		    _.each(variables, function(exp){ 
		        //unwrap $\w$ to get variable from expression
		        fufill( unwrap(exp) ).done(function(model){
		        	//swap variable with its solution
		        	formula = formula.replace(exp, model.get('field').getValue());
		        	expCount--;
                    /* jshint ignore:start */
		        	if(expCount <= 0){
		        		try {
							var result = eval(formula);
							if(isNaN(result)){
								evalComplete.resolve('N/A');
							}else{
								//check for dcimal precision
								if(decimalPrecision){
									result = Number(result.toFixed(decimalPrecision));
								}
								evalComplete.resolve(result);
							}
						}
						catch (e) {
							evalComplete.resolve('N/A');
						}
		        	}
                    /* jshint ignore:end */
		        });
		    });
		}
        /* jshint ignore:start */
        else{
			//nothing to evaluate
			try {
				var result = eval(formula);
				if(isNaN(result)){
					evalComplete.resolve('N/A');
				}else{
					evalComplete.resolve(result);
				}
			}
			catch (e) {
				evalComplete.resolve('N/A');
			}
		}
        /* jshint ignore:end */
	    //wait for formula to eval all expressions
	   	return evalComplete.promise();
	};

	return Formula;
});