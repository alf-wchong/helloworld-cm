define([
	'app'
], function(app){
	var TemporaryAspects = {};

	TemporaryAspects.isPageEnabled = function(options){
		if(options && options.sls){
			var pageId = options.page_id;
			return options.sls.getPage(pageId).isEnabled();
		}
		//if no sectional lockdown, return true by default
		return true;
	};

	return TemporaryAspects;
});