define([
	'app',
	'modules/wizard/formfields/aspects',
	'modules/wizard/formfields/temporaryaspects'
], function(app, Aspects, TemporaryAspects){

	var FieldFactory = {};

	FieldFactory.applyTemporaryAspects = function(options){
		var tempAspects = [];
		if(!TemporaryAspects.isPageEnabled(options)){
			tempAspects.push('disabled');
		}
		return tempAspects;
	};

	FieldFactory.createField = function(config, options){
		var fieldAspects = config.fieldAspects || [];
		//apply any temporary aspects
		var allAspects = fieldAspects.concat(FieldFactory.applyTemporaryAspects(options));
		// remove and store options that the Field doesn't need.
		allAspects = _.uniq(allAspects);

		var fieldModel = Aspects.getAbstractField(config);
		//order the aspects before augmenting the model
		_.each(Aspects.getAspectNamesInOrder(), function(aspectName) {
			if(_.contains(allAspects, aspectName)) {
				//initialize the augmentation with the context of the fieldModel
				fieldModel = Aspects.getAspectAugmentMethods()[aspectName].augment.call(fieldModel, config);
			}
		});

		//remove duplicates
		fieldAspects = fieldModel.get('fieldAspects');
		fieldModel.set('fieldAspects', _.uniq(fieldAspects));

		return fieldModel;
	};

	return FieldFactory;
});
