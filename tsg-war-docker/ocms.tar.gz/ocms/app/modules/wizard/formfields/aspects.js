define([
	'app',
	'modules/wizard/services/queryservice',
	'modules/wizard/services/validationservice',
	'modules/wizard/services/requiredservice',
	'modules/wizard/services/formatservice',
	'modules/wizard/events/questioneventmanager'
], function(app, QueryService, ValidationService, RequiredService, FormatService, QuestionEventManager){
	// lower aspects MAY depend on higher aspects
	// higher aspects MAY NOT depend on lower aspect
	var aspectsInOrder = [
		'selectable',
		'repeatable',
		'queryable',
		'growable',
		'justifiable',
		'validatable',
		'formattable',
		'requirable',
		'disabled',
		'hidden',
		'linkable'
	];

	var Aspects = {};

	_.each(aspectsInOrder, function(aspectName) {
		Aspects[aspectName] = {};
	});

	//this matrix of types and supporting aspects.
	//for example, a multselect is selectable, repeatable

	var Models = {};
	//core form field model
	Models.AbstractField = Backbone.Model.extend({
		idAttribute: "_id",
		initialize : function(config) {
			this.set('name', config ? config.name : '');
			this.set('displayValue', config ? config.displayValue : '');
			this.set('displayName', config ? config.displayName : this.get('name'));
			this.set('value', config ? config.value : '');
			this.set('type', config ? config.type : 'textbox'); //default control type to textbox
			this.set('placeholder', config ? config.placeholder : ''); //placeholder value
			//wait for blur to format any values/validation
			this.listenTo(this, 'control:blur', function(field){
				//do any formatting on blur
				this.setDisplayValue(field.getValue());
			}, this);
		},
		getName: function(){
			return this.get('name');
		},
		validate : function() {
			return;
		},
		setValue: function(newValue){
			this.set('value', newValue);
		},
		setDisplayValue: function(newDisplayValue){
			this.set('displayValue', newDisplayValue);
		},
		getValue: function(){
			return this.get('value');
		},
		getDisplayValue: function(){
			return this.get('displayValue');
		},
		clear: function(){
			this.set('value', undefined);
			this.set('displayValue', undefined);
		},
		isDisabled: function(){
			return;
		},
		isVisible: function(){
			return true;
		},
		isRepeating: function(){
			return false;
		},
		applyAspect: function(aspect){
			//no-op if this aspect is already been applied
			if(this.hasAspect(aspect)){ return; }
			var aspects = this.get('fieldAspects');
			aspects.push(aspect);
			this.set('fieldAspects', aspects);
		},
		hasAspect: function(aspect){
			return _.contains(this.get('fieldAspects'), aspect);
		}
	});

	//each aspect should have an augment function that applies any
	//custom attributes or functions
	Aspects.selectable.augment =  function(config) {
		this.set('options', config ? config.options || [] : []);
		this.getOptions = function() {
			var deferred = $.Deferred();
			deferred.resolve(this.get('options'));
			return deferred.promise();
		};
		return this;
	};

	Aspects.repeatable.augment = function(config) {
		var self = this;
		//value is now an array
		this.set('value', config ? config.values || config.value || [] : []);
		this.unset('getValue', {'silent': true}); //silence the unset

		this.stopListening(this, 'control:blur');
		//wait for blur to format any values/validation
		this.listenTo(this, 'control:blur', function(field){
			//do any formatting on blur
			this.setDisplayValue(field.getValues());
		}, this);

		//private util method for chec
		var isValidIndex = function(index){
			return index >= 0 && index < self.get('value').length;
		};

		this.isRepeating = function(){
			return true;
		};

		//getValue now requires an index
		this.getValue = function(index){
			if(!isValidIndex(index)){
				return;
				//	app.log.debug('getValue() invalid index: ' + index);
			}else{
				return this.get('value')[index];
			}
		};
		// THIS DOESNT WORK - GOD ONLY KNOWS WHY
		this.addValue = function(item, index){
			var value = this.get('value');
			//append to the end of the array
			if(index === undefined){
				value.push(item);
			}else if(isValidIndex(index)){
				value.splice(index, 0, item);
			}else{ //outside bounds of array
				app.log.debug(window.localize("modules.wizard.formfields.aspects.addValueInvalid") + index + window.localize("modules.wizard.formfields.aspects.noItem"));
			}
			this.setValue(_.extend([], value));
		};
		this.setValue = function(items){
			//is array
			var value = items;
			if(Array.isArray(value)){
				this.set('value', value);
			}else{ //werap single item in an array
				if(value){
					this.set('value', [value]);
				}else{
					this.set('value', []);
				}
			}
		};

		this.setDisplayValue = function(items){
			//is array
			var displayValue = items;
			if(Array.isArray(displayValue)){
				this.set('displayValue', displayValue);
			}else{ //werap single item in an array
				if(displayValue){
					this.set('displayValue', [displayValue]);
				}else{
					this.set('displayValue', []);
				}
			}
		};

		// THIS DOESNT WORK - GOD ONLY KNOWS WHY
		this.removeValue = function(index){
			var value = _.extend([], this.get('value'));
			if(!isValidIndex(index)){
				app.log.debug(window.localize("modules.wizard.formfields.aspects.removeValue") + index + window.localize("modules.wizard.formfields.aspects.noItemRemoved"));
			}else{
				value.splice(index, 1);
			}
			this.set('value', value);
		};
		this.removeAll = function(){
			this.set('value', []);
		};
		//get all values
		this.getValues = function(){
			return this.get('value');
		};

		this.clear = function(){
			this.set('value', []);
			this.set('displayValue', []);
		};

		return this;
	};

	Aspects.queryable.augment = function(config){
		this.set('queriedOptions', config ? config.queriedOptions || [] : []);
		this.set('datasource', config ? config.datasource || undefined : undefined);
		this.getOptions = _.bind(function(){
			var self = this;
			var deferred = $.Deferred();
			//fetch once
			if(this.get('datasource') && this.get('datasource') instanceof Backbone.Collection){
				$.when(this.get('datasource').fetch({
					type: 'POST',
					global: false
				})).done($.proxy(function(response){
					self.set('fetched', true);

					var results = _.pluck(self.get('datasource').models, 'attributes');
					//send back no options by default
					var questionOptions = [];

					//by default, load queried options into the options list for a question
					if(!response.resultsType || response.resultsType === 'answers'){
						questionOptions = _.pluck(self.get('datasource').models, 'attributes');
						//this is sometimes the datasource query object rather then the parsed results
						self.set('queriedOptions', questionOptions);

						if (self.get('options')){
							questionOptions = self.get('options').concat(questionOptions);
						}
						//alternatively data might be metadata, not actual selectable options by the user
					}else if(response.resultsType === 'metadata'){
						//special case where the returned options are metadata we need, not selectable options
						switch(response.queryType){
						case 'External Link': {
								//add linkable aspect
							this.applyAspect('linkable');
							var temporary_properties = this.has('temporary_properties') ? this.get('temporary_properties') : {};
							temporary_properties.external_link = results[0].value;
							this.set('temporary_properties', temporary_properties);
							//force a change:value here to make the question re-render
							this.trigger('change:value');
							break;
						}
						}
					}
					self.trigger('change:options', questionOptions); //trigger an options change without modifying options
					self.set('allOptions', questionOptions);
					deferred.resolve(questionOptions);
				}, self));
			}else{
				deferred.resolve(self.get('options'));
			}
			return deferred.promise();
		}, this);

		return this;
	};

	Aspects.growable.augment = function(config){
		this.set('growable', true);
		return this;
	};

	Aspects.validatable.augment = function(config){
		var self = this;
		//default validation type to regexp
		this.set('validationType', config ? config.validationType || 'regexp' : 'regexp');


		//type - email, date, etc
		this.set('type', config ? config.type || '' : '');

		this.getType = function(){
			return this.get('type');
		};
		this.validate = function(){
			var primary = ValidationService[this.get('validationType')].validate;
			var compareTo;

			//wait till page set instance gets set
			if(app.psi !== undefined) {
				// if there is no compareTo, returns primary. runs primary first either way. only runs compareTo if primary passes.
				if( this.get("compareTo") && this._doesThisRequireCompareValidation(
					this.get("compareTo"), 
					this.get("compareType"), 
					app.psi.findModel(this.get("compareTo")).get("field").getDisplayValue())
				)
				{
					compareTo = ValidationService["compare"][this.get('compareType')].validate;
					return  primary(this.get('displayValue'), self) || compareTo(
						this.get('displayValue'),
						app.psi.findModel(this.get("compareTo")).get("field").getDisplayValue(),
						this.get('compareOperator'),
						this.get('compareOffset'),
						this.get('label'),
						app.psi.findModel(this.get('compareTo')).get('label'),
						self
					);
				} else {
					return primary(this.get('displayValue'), self);
				}
			}
		};

		//checking for types that need to be validated by the compare
		this._doesThisRequireCompareValidation = function(compareTo, compareType, compareToFieldValue) {
			if(compareTo) {
				if(compareType === "date" || compareType === "notEqual") {
					if(compareToFieldValue && compareToFieldValue !== "" && compareToFieldValue !== "N/A") {
						return true;
					}
				}
			}

			return false;
		};

		if(config.compareType) {
			// in this case we need to bind the compareTo question to fire this field's validation method
			//QuestionEventManager.listenTo()
			this.listenTo(
				QuestionEventManager, 
				"change:question:value:" + this.get("compareTo"), 
				function() {
					if(this.get('value') && this.get('value') !== "") {
						this.trigger("validate");
					}					
				}, 
				this);
		}

		return this;
	};

	Aspects.justifiable.augment = function(config) {
		this.set('justifications', _.extend({}, config.justifications));
		return this;
	};

	Aspects.formattable.augment = function(config){

		this.set('displayValue', config ? config.displayValue || undefined : undefined);
		this.set('formatType', config ? config.formatType || undefined : undefined);
		this.set('format', config ? config.format || undefined : undefined);
		//init formatting
		this.set('displayValue', FormatService.format(this.get('value'), this.get('formatType'), this.get('format')));

		this.setValue = function(value){
			this.set('value', FormatService.unformat(value, this.get('formatType'), this.get('format')));
		};

		//wait for blur to format any values/validation
		this.listenTo(this, 'control:blur', function(field){
			//do any formatting on blur
			this.setDisplayValueNormal(field.getValue());
		}, this);
		
		this.setDisplayValueNormal = function(value){
			this.set('displayValue', FormatService.format(value, this.get('formatType'), this.get('format')));
		};
		//wait to call display until the last entered text
		//without it will format with every input
		this.setDisplayValue = _.debounce(this.setDisplayValueNormal, 500);
		return this;
	};


	Aspects.requirable.augment = function(config){
		var self = this;
		var validationErrors;
		var parent = _.extend({}, this);

		//if validatable isn't in the aspect chain,
		//requirable will return isValid() truthy
		this.validate = function(){
			validationErrors = [];

			if(parent.validate) { //requirable depends on validatable
				validationErrors.push(parent.validate());
			}

			//generic validation for no blank values
			validationErrors.push(RequiredService.validate( self));

			if(this.get('validationType') && RequiredService[this.get('validationType')]){
				//preform type specific validation
				validationErrors.push(RequiredService[this.get('validationType')].validate(this.get('displayValue'), self));
			}


			//reject all undefined errors - those are valid
			validationErrors = _.reject(validationErrors, function(v) { return !v; });
			if(validationErrors.length > 0) {
				var validationErrorString = "";
				_.each(validationErrors, function(valMsg, idx) {
					if(idx === validationErrors.length - 1) {
						validationErrorString += valMsg;
					} else {
						validationErrorString = validationErrorString + "\n" + valMsg;
					}
				});
				return validationErrorString;
			}
		};
		return this;
	};

	Aspects.disabled.augment = function(config){
		//disable this field when this aspect is applied
		this.set('disabled', true);

		this.isDisabled = function(){
			return this.get('disabled');
		};

		this.enable = function(){
			this.set('disabled', false);
		};

		this.disable = function(){
			this.set('disabled', true);
		};

		this.toggle = function(){
			this.set('disabled', !this.get('disabled'));
			return this.get('disabled');
		};

		return this;
	};

	Aspects.hidden.augment = function(config){
		//hide this field when this aspect is applied
		this.set('visible', false);

		this.isVisible = function(){
			return this.get('visible');
		};

		this.hide = function(){
			this.set('visible', false);
		};

		this.show = function(){
			this.set('visible', true);
		};

		this.toggle = function(){
			this.set('visible', !this.get('visible'));
			return this.get('visible');
		};

		return this;
	};

	Aspects.linkable.augment = function(config){
		this.set('linkable', true);
		return this;
	};

	return {
		getAspectNamesInOrder : function() {
			return _.extend([], aspectsInOrder);
		},
		getAspectAugmentMethods : function() {
			return _.extend({}, Aspects);
		},
		//get a fresh field to apply aspects on
		getAbstractField : function(config){
			return new Models.AbstractField(config);
		}
	};
});
