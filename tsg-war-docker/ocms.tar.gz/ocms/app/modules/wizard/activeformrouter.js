define([
    // Application.
    'app',
    'URIjs/URI',
    'oc',
    'abstractrouter',
    'modules/common/action',
    'modules/wizard/activeform',
    'modules/wizard/views/createactiveformmodal',
    'modules/wizard/views/finishandsubmitmodal',
    'modules/wizard/views/saveandexitmodal',
    'modules/wizard/services/pagesetinstanceprovider',
    'modules/wizard/models/workflow/workflow',
    'modules/wizard/views/summaryview',
    'modules/wizard/views/workflowsummaryview',
    'modules/wizard/views/addformnamemodal',
    'modules/wizard/views/confirmationpageview',
    'modules/wizard/views/slformconfirmationview',
    'modules/wizard/models/slformconfirmationmodel',
    'modules/wizard/services/psiutilservice',
    'modules/wizard/models/pagesetinstance',
    'modules/wizard/models/wizardcontext',
    'modules/wizard/events/questioneventmanager',
    'modules/wizard/events/psieventmanager',
    "modules/common/tracselector",
    "modules/services/exitservice",
    'module',
    'resumeform',
    'cancelcheckout'
],

function(app, URI, OC, AbstractRouter, Action, ActiveForm, ActiveFormModal, FinishAndSubmitModal, SaveAndExitModal, PSIProvider,
        Workflow, SummaryView, WorkflowSummaryView, AddFormNameModal, ConfirmationPageView, SlFormConfirmationView, SlFormConfirmationModel, PSIUtilService, PSIModel, WizardContext,
        QuestionEventManager, PSIEventManager, TracSelector, ExitService, module, ResumeForm, CancelCheckout) {
    "use strict";

    ActiveForm.getPageSetDefinition = function(objectId){
        var deferred = $.Deferred();
        $.ajax({
            url: app.serviceUrlRoot + "/content/content?contentType[]=json,xml&id=" + encodeURIComponent(objectId),
            dataType: "json",
            success: function(json){
                app.context.configService.getApplicationConfig(function(cfg) {
                    deferred.resolve(PSIProvider.transformJSON(json, cfg));
                });
            },
            error: function(jqxhr, response, status){
                app.log.error('failed to retrieve json for: ' + objectId, status);
                deferred.resolve(undefined);
            }
        });

        return deferred.promise();
    };

    ActiveForm.getPageSetInstance = function(formId){
        var deferred = $.Deferred();
        $.ajax({
            url: app.serviceUrlRoot + "/content/content?contentType[]=json,xml&id=" + encodeURIComponent(formId),
            dataType: "json",
            success: function(json){
                deferred.resolve(json);
            },
            error: function(jqxhr, response, status){
                app.log.error(window.localize("modules.wizard.activeFormRouter.failedToRetrieve") + formId, status);
                deferred.resolve(undefined);
            }
        });

        return deferred.promise();
    };

    //get an array of of page sets
    ActiveForm.getPageSets = function(){
        var deferred = $.Deferred();
        $.ajax({
            url: app.serviceUrlRoot + "/aw-form/getPageSets",
            success: function(result) {
                var pageSets = new Backbone.Collection();
                 _.each(result, function(pageSet) {
                     if (pageSet.activeVersionLabel !== "") {
                        pageSets.add(pageSet);
                     }
                 }, this);

                var sortedPageSets = pageSets.sortBy(function(pageSet) {
                    return pageSet.get('pageSetName').toLowerCase();
                });

                 deferred.resolve(sortedPageSets);
            },
            error: function(jqXHR) {
                app.trigger("alert:info", {
                    header: window.localize("generic.alert"),
                    message: window.localize("modules.wizard.activeFormRouter.errorRetrievingTheList") +
                              jqXHR.status + " " + jqXHR.statusText
                });
            }
        });
        return deferred.promise();
    };

    ActiveForm.getActivePageSet = function(pageSetName, activeVersion){
        var deferred = $.Deferred();
        $.ajax({
            url: app.serviceUrlRoot + "/aw-form/getPageSet?pageSetName=" + pageSetName + "&versionLabel=" + activeVersion,
            success: function(result) {
                //this si the active objectId ather then the HEAD, LATEST object id
                ActiveForm.getPageSetDefinition(result.objectId).done(function(json){
                    deferred.resolve(json);
                });
            },
            error: function(jqXHR) {
                app.trigger("alert:info", {
                    header: window.localize("generic.alert"),
                    message: window.localize("modules.wizard.activeFormRouter.errorRetrievingTheActive") + pageSetName + window.localize("modules.wizard.activeFormRouter.fromTheServer") +
                              jqXHR.status + " " + jqXHR.statusText
                });
            }
        });
        return deferred.promise();
    };

    ActiveForm.checkForCurrentVersion = function(objectId){
        // we only want to make the check for the current version if the form has an objectId,
        // if it doesn't (ex - createing a new form) then there is no current form
        if (objectId){
            var response = $.ajax({
                url: app.serviceUrlRoot + "/content/resolveVersion?objectId=" + objectId + "&label=CURRENT",
                dataType: "json",
                global: false,
                async: false
            });

            var currentId = JSON.parse(response.responseText);

            if (currentId !== objectId){
                app.trigger("alert:info", {
                    header: window.localize("generic.alert"),
                    message: window.localize("modules.wizard.activeFormRouter.youAreAttempting"),
                    confirm : function() {
                        // Backbone.history.navigate('activeform/' + encodeURIComponent(currentId) + '/edit/0',{trigger:true});
                        window.location = 'activeform/' + encodeURIComponent(currentId) + '/edit/0';
                    }
                });
            }
        }
    };

    ActiveForm.Router = AbstractRouter.extend({

        routes: {
            "activeform"                                : 'launchCreateForm',
            "activeform/:formId/edit/:pageIndex"        : 'getExistingFormPage',
            "activeform/:formId/edit"                   : 'parseEditForm',
            "activeform/:psdName/new"                   : 'parseCreateForm',
            "activeform/:psdName/streamline/new"        : 'parseCreateFormStreamline',
            "activeform/:psdName/new/:pageIndex"        : 'getActiveFormPage',
            "activeform/:psdName/summary"               : 'launchSummary',
            "activeform/:psdName/workflow"              : 'launchWorkflow',
            "activeform/:psdName/formName"              : 'getTheFormNameIfNotAutoNumbered',
            'activeform/:psdName/confirm/:objectId'     : 'confirmationPage',
            'activeform/:psdName/exit'                  : 'exitForm',
            'activeform/:psdName/actionHandler/:objectId/:actionId/:streamline' : 'actionHandler',
            'activeform/streamline/:psdName/confirmation/:objectId' : 'slFormConfirmation'
        },
        initialize: function(){
            AbstractRouter.__super__.initialize.apply(this, arguments);

            //listen for vent to create psi folder
            this.listenTo(app, 'psi:createfolder', function(psi, deferred){
                if(!psi){
                    psi = this.psi;
                }
                PSIUtilService.createFolder(psi, deferred);
            }, this);
            //We do not want to display a warning if we leave the confirmation page
            if(window.location.pathname.indexOf('/activeform') != -1 && window.location.pathname.indexOf('/confirmation') == -1){
                ExitService.register('activeform.exit', function(){
                    //do nothing
                }, window.localize("modules.wizard.activeFormRouter.formInProgress"), function(){
                    return window.location.pathname.indexOf('/activeform') != -1;
                });
            }
            this.reservedName = null;
            this.formId = null;
            //The action will execute later
            this.action = new Action.Model({});
        },
        beforeRoute : function() {
            $("body").removeClass(); // removes all classes (such as login)
            this.layout = app.useLayout("layout-wizard");
            this.activeFormView = new Backbone.Layout();
            //only render the main layout once - this includes the header
            this.layout.once('afterRender', function(){
                this.layoutRendered = true;
                ActiveForm.checkForCurrentVersion(this.formId);
            }, this);
        },
        launchCreateForm: function(){
            this.beforeRoute();
            var self = this;
            ActiveForm.getPageSets().done(function(pageSets){
                var activeFormModal = new ActiveFormModal(pageSets);
                app.listenTo(activeFormModal, 'activeform:create', function(form){
                    //pageSetName in this context is TS Script or Simple CR
                    self.parseCreateForm(form.get('pageSetName'), {
                        'objectId': form.get('objectId')
                    });
                }, this);

                self.listenTo(self.activeFormView, 'afterRender', function(){
                    self.activeFormView.setView(activeFormModal).render();
                    //launch active form picklist
                    activeFormModal.show();
                }, this);
                self.layout.setViews({
                    "#content-outlet" : self.activeFormView
                }).render();
            });
        },
        parseCreateForm: function(psdName, params) {
            if(this.psi){
                this.psi.stopListening();
            }

            var self = this;
            self.psdName = psdName;

            // first time through reset the name and psi in case they were left over from an earlier form
            self.psi = undefined;
            self.formId = null;

            if(params){
                app.wizardContext.set(params);
            }

            if(params && params.newPsiName) {
                var reservedName = params.newPsiName;
                app.wizardContext.set('reservedName', reservedName);
            }

            var uri = new URI('activeform/' + self.psdName + '/new/0');
            Backbone.history.navigate(uri.toString(), {trigger:true, replace:true});
        },
        //Begin the streamline mode process
        parseCreateFormStreamline: function(psdName, params) {
            var that = this;
            //Get our wizard configs
            app.context.configService.getWizardConfig(function(config){ 
                //Search for the config corresponding to our form
                var formInfo = _.find(config.get("wizardForms").models, function(form) {
                    return form.get("formName") === psdName;
                });
                //If there is no corresponding config or streamline mode is off, skip streamline mode
                if (typeof formInfo == 'undefined' || !formInfo.get("streamline")) {
                    app.trigger("psi:notStreamline", psdName);
                    return;
                }
                //Our config says streamline mode is enabled, so set streamline mode to true and move to the standard create form page
                that.streamline = true;
                that.parseCreateForm(psdName, params);
            });
        },
        parseEditForm: function(formId) {
            if (this.psi) {
                this.psi.stopListening();
            }

            this.psi = undefined;

            //reset wizard context
            app.wizardContext = new WizardContext.Model();

            this.getExistingFormPage(formId, 0);
        },
        getExistingFormPage: function(formId, activePageValue){
            var self = this;
            self.activePageValue = activePageValue;

            //checkout the form
            this.executeResumeFormAction(formId).done(function(){
                //fetch repo object and set up for active form
                //hard page refresh
                if(!self.psi){
                    ActiveForm.getPageSetInstance(formId).done(function(json) {
                        self.psi = new PSIModel(json, {
                            'formId': formId
                    });
                        self.formId = formId;
                        self.reservedName = self.psi.get('name');
                        self.psdName = self.psi.get('psdName');
                        self.getActiveFormPage(self.psdName, activePageValue);
                    });
                }else{
                    self.getActiveFormPage(self.psdName, activePageValue);
                }
            }, this);
        },
        getActiveFormPage: function(psdName, activePageValue, params){
            this.beforeRoute();

            var self = this;
            self.psdName = psdName;
            self.activePageValue = activePageValue;
            var frag;
            if(self.activePageValue === "summary"){
                // normalize URL, we're assuming its a number at this point.
                frag = Backbone.history.fragment.split('/');
                Backbone.history.navigate(frag[0] + '/' + frag[1] + '/' + frag[2] + '/summary');
                this.launchSummary(self.psdName);
                return;
            }else if(self.activePageValue === "workflow"){
                //normalize URL, we're assuming its a number at this point.
                frag = Backbone.history.fragment.split('/');
                Backbone.history.navigate(frag[0] + '/' + frag[1] + '/' + frag[2] + '/workflow');
                this.launchWorkflow(self.psdName);
                return;
            }

            //get our stored context if its not on the url bar
            if(!params){
                params = app.wizardContext.attributes;
            }

            if(params && params.newPsiName) {
                var reservedName = params.newPsiName;
                this.reservedName = reservedName;
            }

            //rebuild wizard attributes
            self.setWizardParams(params).done(function(){
                self.activePageValue = Number(activePageValue || 0);

                // normalize URL, we're assuming its a number at this point.
                frag = Backbone.history.fragment.split('/');
                Backbone.history.navigate(frag[0] + '/' + frag[1] + '/' + frag[2] + '/' + self.activePageValue);


                if(self.psi){
                    //fire an event on the PSIEeventManager that the page has changed
                    PSIEventManager.trigger('change:page:loaded', self.activePageValue, self.psi.cid);
                    //re-init the view to preserve listeners
                    if(self.activeFormView !== undefined){
                        self.activeFormView.removeView();
                        self.activeFormView.remove();
                    }

                    //populate the form with any pre-defined answers
                    if(app.wizardContext && app.wizardContext.has('populateWith')){
                        _.each(app.wizardContext.get('populateWith'), function(value, key){
                            QuestionEventManager.trigger('change:question:value', key, value);
                        }, self);
                    }

                    self.activeFormView = new ActiveForm.Views.Layout({
                        user : app.user,
                        psi: self.psi,
                        activePageIndex: self.activePageValue
                    });

                    self.layout.setViews({
                        "#content-outlet" : self.activeFormView
                    });
                    self.renderLayout();
                }else{
                    //IE9 seems to be caching the PSI, so this is the point at which we can 'remove' any incorrectly cached PSI
                    self.psi = undefined;
                    ActiveForm.getPageSets().done(function (pageSets) {  //when does this get called
                        pageSets = new Backbone.Collection(pageSets);
                        //get page set based on the name of the form (Simple CR, TS My Script, etc)
                        var pageSet = pageSets.findWhere({'pageSetName': self.psdName});
                        ActiveForm.getActivePageSet(pageSet.get('pageSetName'), pageSet.get('activeVersionLabel')).done(function (json) {
                            if(!self.psi){
                                self.psi = new PSIModel(json);
                            }

                            //populate the form with any pre-defined answers
                            if(app.wizardContext && app.wizardContext.has('populateWith')){
                                _.each(app.wizardContext.get('populateWith'), function(value, key){
                                    QuestionEventManager.trigger('change:question:value', key, value);
                                }, self);
                            }

                            //fire an event on the PSIEeventManager that the page has changed
                            PSIEventManager.trigger('change:page:loaded', self.activePageValue, self.psi.cid);

                            self.activeFormView = new ActiveForm.Views.Layout({
                                user: app.user,
                                psi: self.psi
                            });
                            self.layout.setViews({
                                "#content-outlet": self.activeFormView
                            });
                            self.renderLayout();
                        });
                    });
                }
            });
        },
        renderLayout: function(){
            this.layout.render();
        },
        launchSummary: function(){
            this.beforeRoute();
            var self = this;
            this.psi.get('flowpath').trigger('update:summary', this.psi.get('flowpath'));

            //calculate wizard workflows before displaying the summary page
            var deferred = Workflow.build({
                'psdName': this.psi.get('psdName'),
                'psi': this.psi
            });
            $.when(deferred).done(function(workflow){
                //stash workflow on wizard context
                app.wizardContext.set('workflow', workflow);
                self.summaryView = new SummaryView({
                    psi: self.psi,
                    formId: self.formId,
                    showErrorsOnly: onlyShowSummaryPageOnError
                });

                // check if we want to skip the summary page, but we need to make sure that all of the pages are valid
                if (onlyShowSummaryPageOnError && !self.summaryView.psiInvalid){
                    self.getTheFormNameIfNotAutoNumbered();
                } else {
                    self.layout.setViews({
                        "#content-outlet": self.summaryView
                    });
                    self.layout.render();
                }
            });
        },
        launchWorkflow: function(){
            this.beforeRoute();
            var self = this;

            //avoid recalculating workflow if its already been calcualated
            if(app.wizardContext && app.wizardContext.has('workflow')){
                self.workflowSummaryView = new WorkflowSummaryView({
                    'workflow': app.wizardContext.get('workflow'),
                    'psi': self.psi
                });
                self.layout.setViews({
                    "#content-outlet": self.workflowSummaryView
                });

                self.layout.render();
            }else{
                var deferred = Workflow.build({
                    'psdName': this.psi.get('psdName'),
                    'psi': this.psi
                });
                $.when(deferred).done(function(workflow){
                    //stash workflow on wizard context
                    app.wizardContext.set('workflow', workflow);
                    self.workflowSummaryView = new WorkflowSummaryView({
                        'workflow': workflow,
                        'psi': self.psi
                    });
                    self.layout.setViews({
                        "#content-outlet": self.workflowSummaryView
                    });

                    self.layout.render();
                });
            }
        },
        getTheFormNameIfNotAutoNumbered : function(){
            var self = this;
            $.get(app.serviceUrlRoot + '/aw-form/isAutoNumbered?pageSetName=' + this.psdName)
                .done(function(isAutoNumbered){
                    if(isAutoNumbered){
                        self.finishAndSubmitPSI();
                    }
                    // if a name was provided earlier set it and bypass the set name page
                    else if(self.reservedName){
                        self.psi.set('name', self.reservedName);
                        self.finishAndSubmitPSI();
                    }
                    else{
                        if(self.addFormNameView === undefined){
                            self.addFormNameView = new AddFormNameModal({psi: self.psi});
                        }
                        self.layout.setViews({
                            "#content-outlet" : self.addFormNameView
                        });

                        self.layout.render();
                        var url = 'activeform/' + self.psdName + '/formName';
                        Backbone.history.navigate(url);
                        self.navigate(url);
                    }
                });
        },
        finishAndSubmitPSI: function(){
            var finishAndSubmitModal = new FinishAndSubmitModal({
                psi: this.psi,
                formId: this.formId,
                workflow: app.wizardContext.get('workflow'),
                streamline: this.streamline
            });
            this.layout.setViews({
                "#content-outlet": finishAndSubmitModal
            });
            this.layout.render();
        },
        confirmationPage : function(pageSetName, objectId){
            //there's no going back now
            this.psi = undefined;
            var self = this;
            self.confirmationPageView = new ConfirmationPageView({
                pageSetName : pageSetName,
                objectId    : objectId
            });
            self.layout.setViews({
                "#content-outlet": self.confirmationPageView
            });
            self.layout.render();
        },
        //Page we display after a streamline approval proccess is completed
        slFormConfirmation : function (psdName, objectId) {
            objectId = window.decodeURIComponent(objectId); 
            this.beforeRoute();
            this.psi = undefined;
            var self = this;
            //Ajax request to get all our configs
            app.context.configService.getWizardConfig(function(config){ 
                var formInfo = _.find(config.get("wizardForms").models, function(form) {
                    return form.get("formName") === psdName;
                });
                //If there is no corresponding config, use the default
                if (typeof formInfo == 'undefined') {
                    //Set up our model and view for the page using values from our config
                    self.slFormConfirmationModel = new SlFormConfirmationModel({
                        formId: psdName,
                        objectId : objectId
                    });
                }                  
                else {
                    //Convert Yes/No choices to true/false so they can be understood by handlebars 
                    //Set up our model and view for the page using values from our config
                    self.slFormConfirmationModel = new SlFormConfirmationModel({
                        title : formInfo.get("title"),
                        textAreaText: formInfo.get("message"),
                        hasRelaunch : formInfo.get("selectedRelaunchChoice"),
                        hasViewer : formInfo.get("selectedViewerChoice"),
                        hasStage : formInfo.get("selectedStageChoice"),
                        isOA : formInfo.get("isOA"),
                        formId: psdName,
                        objectId : objectId
                    });
                }
                self.slFormConfirmationView = new SlFormConfirmationView({
                    model : self.slFormConfirmationModel
                });
                //Display the page
                self.layout.setViews({
                    "#content-outlet": self.slFormConfirmationView
                });
                self.layout.render();
            });
        },
        saveAndExit: function(psi) {
            $("#wizard-form-save-and-exit-btn").prop("disabled",true);
            // call our action executer for save and exit
            app.log.debug("Save And Exit");
            this.psi = psi;
            if(this.reservedName) {
                this.psi.set('name', this.reservedName);
            }

            var saveAndExit = new SaveAndExitModal({
                psi: this.psi,
                formId: this.formId
            });
            this.layout.setViews({
                "#content-outlet": saveAndExit
            });
            this.layout.render();
            var url = 'activeform/' + this.psdName + '/save';
            Backbone.history.navigate(url,{replace:true});
            this.navigate(url);
            $("#wizard-form-save-and-exit-btn").prop("disabled",false);
        },
        executeResumeFormAction: function(formId) {
            var deferred = $.Deferred();
            var successFunction = function(response){
                //populate app.WizardContext
                var props = response.result;
                if(props.originFolders){
                    //only support a single origin source right now
                    app.wizardContext.set('folderId', props.originFolders[0]);
                }
                deferred.resolve();
            };
            var errorFunction = function() {
                app.trigger("alert:info", {
                    header: window.localize("modules.wizard.activeFormRouter.formIsLocked"),
                    message: window.localize("modules.wizard.activeFormRouter.errorCheckingOut"),
                    confirm : function() {
                        Backbone.history.navigate('Stage/wizard/' + encodeURIComponent(formId) + '|' + encodeURIComponent(formId),{trigger:true});
                    }
                });
                deferred.resolve();
            };
            ResumeForm.Service.execute({
                parameters: {
                    'objectId' : formId
                },
                'successFunction':successFunction,
                'errorFunction':errorFunction
            });
            return deferred.promise();
        },
        exitForm: function(psi) {
            var self = this;

            // call our action executer for save and exit
            app.log.debug(window.localize("modules.wizard.activeFormRouter.cancelCheckout"));
            self.psi = psi;
            if(self.reservedName) {
                self.psi.set('name', self.reservedName);
            }

            if(self.formId){
                var successFunction = function () {
                    Backbone.history.navigate('Stage/wizard/' + encodeURIComponent(self.formId) + '|' + encodeURIComponent(self.formId),{trigger:true});
                };
                var errorFunction = function() {
                    app.trigger("alert:info", {
                    header: window.localize("generic.alert"),
                    message: window.localize("modules.wizard.activeFormRouter.errorCancelingCheckout"),
                        confirm : function() {
                            Backbone.history.navigate('Stage/wizard/' + encodeURIComponent(self.formId) + '|' + encodeURIComponent(self.formId),{trigger:true});
                        }
                    });
                };
                CancelCheckout.Service.execute({
                    parameters: {
                        'objectId': self.formId
                    },
                    successFunction: successFunction,
                    errorFunction: errorFunction
                });
            }else{
                var parentFolderId = app.wizardContext.get('folderId');
                //form not saved to the repo - reroute to dashboard or the parent folder if configured in config-project
                if (returnToParentFolderOnExit && parentFolderId){
                    TracSelector.establishTrac({ id: parentFolderId, folderId: parentFolderId }, function(establishedTrac){
                        var url = "Stage/" + establishedTrac + "/" + parentFolderId ;
                        Backbone.history.navigate(url, {trigger: true});
                    });
                } else {
                    Backbone.history.navigate('dashboard',{trigger:true});
                }
            }
        },
        //Begin action on object
        submitAction: function(psdName, objectId, actionId) {
            var that = this;
            //Create and execute approval action
            if (actionId === "startWizardReviewWorkflow") {
                var approvers = [];
                $.ajax({
                    url: app.serviceUrlRoot + "/aw-workflow/getPotentialApprovers?formId=" + objectId,
                    type : "GET",
                    success:function(approverList){
                        if (approverList.length === 0) {
                            window.alert("This form is configured to go into the review route on submit, but there are no approvers. The review route will not be started.");
                            app.trigger("psi:viewForm", objectId);
                            return;
                        }
                        //if users are in approval list, add to selected users list
                        _.each(approverList, function(approver) {
                            approvers.push(approver.loginName);
                        });
                        that.action.set('name',actionId);
                        that.action.set('parameters',{
                            'objectId' : objectId,
                            'reviewerIds' : approvers,
							'appRoot': app.root
                        });
                        that.action.execute({
                            success: function(){
                                app.trigger("psi:viewForm", objectId);
                                return;
                            }   
                        });
                    }
                });
            }
           else if (actionId === "startWizardApprovalWorkflow") {
                $.ajax({
                    url: app.serviceUrlRoot + "/aw-workflow/getPotentialApprovers?formId=" + objectId,
                    type : "GET",
                    success:function(approverList){
                        if (approverList.length === 0) {
                            window.alert("This form is configured to go into the approval route on submit, but there are no approvers. The approval route will not be started.");
                            app.trigger("psi:viewForm", objectId);
                            return;
                        }
                        that.action.set('name',actionId);
                        that.action.set('parameters',{
                            'objectId' : objectId,
							'appRoot' : app.root
                        });
                        that.action.execute({
                            success: function(){
                                app.trigger("psi:viewForm", objectId);
                                return;
                            }   
                        });
                    }
                });
            }
            else {
                window.alert(actionId + " is not a configured action. The action will not be submitted.");
                app.trigger("psi:viewForm", objectId);
                return;
            }
        },
        //Begin action on object
        submitActionStreamline: function(psdName, objectId, actionId) {
            var that = this;
            //Create and execute approval action
            if (actionId === "startWizardReviewWorkflow") {
                var approvers = [];
                $.ajax({
                    url: app.serviceUrlRoot + "/aw-workflow/getPotentialApprovers?formId=" + objectId,
                    type : "GET",
                    success:function(approverList){
                        if (approverList.length === 0) {
                            window.alert("This form is configured to go into the review route on submit, but there are no approvers. The review route will not be started.");
                            app.trigger("psi:action:finished", psdName, objectId, true);
                            return;
                        }
                        //if users are in approval list, add to selected users list
                        _.each(approverList, function(approver) {
                            approvers.push(approver.loginName);
                        });
                        that.action.set('name',actionId);
                        that.action.set('parameters',{
                            'objectId' : objectId,
                            'reviewerIds' : approvers
                        });
                        that.action.execute({
                            success: function(){
                            app.trigger("psi:action:finished", psdName, objectId, true);
                                return;
                            }   
                        });
                    }
                });
            }
           else if (actionId === "startWizardApprovalWorkflow") {
                $.ajax({
                    url: app.serviceUrlRoot + "/aw-workflow/getPotentialApprovers?formId=" + objectId,
                    type : "GET",
                    success:function(approverList){
                        if (approverList.length === 0) {
                            window.alert("This form is configured to go into the approval route on submit, but there are no approvers. The approval route will not be started.");
                            app.trigger("psi:action:finished", psdName, objectId, true);
                            return;
                        }
                        that.action.set('name',actionId);
                        that.action.set('parameters',{
                            'objectId' : objectId
                        });
                        that.action.execute({
                            success: function(){
                                app.trigger("psi:action:finished", psdName, objectId, true);
                                return;
                            }   
                        });
                    }
                });
            }
            else {
                window.alert(actionId + " is not a configured action. The action will not be submitted.");
                app.trigger("psi:action:finished", psdName, objectId, true);
                return;
            }
        },
        actionHandler : function (psdName, objectId, actionId, streamline) {
            objectId = window.decodeURIComponent(objectId); 
            if (streamline.localeCompare("true") === 0) {
                this.submitActionStreamline(psdName, objectId, actionId);
            }
            else {
                this.submitAction(psdName, objectId, actionId);
            }
        },
        setWindowLocation: function(location){
            //check for push state to support IE 9
            if(!history.pushState){
                location = '#' + location;
            }
            return window.location.protocol + "//" + window.location.host + app.root + location;
        },
        setWizardParams: function(params){
            var deferred = $.Deferred();
            
            if (!params) {
                deferred.resolve();
                return deferred; //no-op if no parameters
            }

            //reset wizard context
            app.wizardContext = new WizardContext.Model();
            app.wizardContext.build(this.psdName, params, formFolderPropToQuestionMap);
            
            //if we made it this far, need to return empty deferred
            deferred.resolve();
            return deferred;
        }
    });

    var formFolderPropToQuestionMap = module.config().folderPropertyToQuestionLabelMap || {} ;
    var onlyShowSummaryPageOnError = module.config().onlyShowSummaryPageOnError || false;
    var returnToParentFolderOnExit = module.config().returnToParentFolderOnExit || false;

    return ActiveForm.Router;

});
