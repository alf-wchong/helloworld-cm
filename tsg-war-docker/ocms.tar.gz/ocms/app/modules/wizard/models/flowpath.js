define([
	'app',
	'modules/wizard/models/page',
	'modules/wizard/models/pagecollection',
	'modules/wizard/services/flowpathutils',
	'modules/wizard/events/pageeventmanager',
	'modules/wizard/events/psieventmanager'
], function(app, Page, PageCollection, FlowpathUtils, PageEventManager, PSIEventManager){

	var Schema = {};

	Schema.Node = Backbone.Model.extend({
		defaults: {
			id: "",
			visible: true,
			children: []
		},
		initialize: function(config){
			var children = new Schema.Collection();
			_.each(config.children || [], function(node) {
				children.add(node);
			}, this);
			this.id = config.id || "";
			this.set('visible', config.visible);
			this.set('children', children);
		},
		//only return visible child pages
		getVisibleChildren: function(){
			return new Schema.Collection(
				this.get('children').filter(function(page){
					return page.has('visible') && page.get('visible'); //visible by default
				}, this)
			);
		},
		isVisible: function(){
			return this.get('visible');
		},
		setVisible: function(isVisible){
			this.set('visible', isVisible);
		}
	});

	Schema.Collection = Backbone.Collection.extend({
		model: Schema.Node
	});

	var FlowPath = PageCollection.extend({
		model: Page,
		initialize: function(config, options){
			this.options = options;
			if(!options.schema){
				app.log.error('no flow path found!');
			}
			this.flowpathSchema = new Schema.Collection(options.schema);

			if(!options.pages){
				app.log.error('no pages referenced in the flowpath');
			}

			this.listenTo(this.flowpathSchema, 'change', this.updateFlowPath, this);

			this.listenTo(PSIEventManager, 'build', this.build, this);

			this.listenTo(PageEventManager, 'leading:action:' + options.psiId, function(rule, srcPage, targetPage){
				this.addPage(rule, srcPage, targetPage);
			}, this);

			this.listenTo(PageEventManager, 'remove:action:' + options.psiId, function(rule, srcPage, targetPage){
				this.removePage(rule, srcPage, targetPage);
			}, this);

			this.listenTo(PageEventManager, 'change:page:validity:' + options.psiId, function(){
				this.updateFlowPath();
			});
		},
		build: function(){
			this.updateFlowPath();
		},
		addPage: function(rule, srcPage, targetPage){
			var page = FlowpathUtils.getPage(this.flowpathSchema, srcPage, targetPage);
			//bail if no page to add
			if(!page){
				app.log.debug(window.localize("modules.wizard.models.flowpath.flowpathTarget") + targetPage);
				return;
			}
			//make this page visible
			page.setVisible(true);

			//re-evaluate children for any leading actions
			page.get('children').each(function(child){
				this.evaluatePage(child.id);
			}, this);

			//update visile pages in flowpath
			this.updateFlowPath();
		},
		removePage: function(rule, srcPage, targetPage){
			//remove page from flowpath
			var page = FlowpathUtils.getPage(this.flowpathSchema, srcPage, targetPage);
			//bail if no page to remove
			if(!page){
				app.log.debug(window.localize("modules.wizard.models.flowpath.flowpathTarget") + targetPage);
				return;
			}
			//hide this page
			page.setVisible(false);

			//re-evaluate children for any leading actions
			page.get('children').each(function(child){
				this.evaluatePage(child.id);
			}, this);

			//update visible pages in flowpath
			this.updateFlowPath();
		},
		//re-examine rules, triggers, etc
		evaluatePage: function(pageId){
			var page = this.options.pages.get(pageId);
			page.get('questions').each(function(question){
				question.processRules();
			}, this);
		},
		flattenFlowPath: function(pages){
			var flattenedPages = [];
			if(!pages){
				return flattenedPages;
			}
			pages.each(function(page){
				//not all root pages are visible by default
				if(page.isVisible()){
					flattenedPages.push(page.get('id'));
					//its children might be
					flattenedPages = flattenedPages.concat(this.flattenFlowPath(page.get('children')));
				}
			}, this);
			return flattenedPages;
		},
		updateFlowPath: function(){
			var pages = [];
			pages = this.flattenFlowPath(this.flowpathSchema);
			//swap ids for pages
			_.each(pages, function(pageId, index){
				pages[index] = this.options.pages.get(pageId);
			}, this);
            this.reset(pages);
		},
		getPageByIndex: function(pageIndex){
			return this.at(pageIndex);
		}
	});

	//override Flowpath's toJSON
	FlowPath.prototype.toJSON = function() {
		//return just the flowpath map
		return _.extend([], this.flowpathSchema.toJSON());
	};

	return FlowPath;
});
