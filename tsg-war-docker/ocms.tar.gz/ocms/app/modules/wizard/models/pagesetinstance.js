define([
	'app',
	'modules/wizard/models/flowpath',
	'modules/wizard/models/pagecollection',
	'modules/wizard/services/placeholdermanager',
	'modules/wizard/services/sectionallockdownservice',
	'modules/wizard/models/actioncache',
	'modules/wizard/models/metadata',
	'modules/wizard/events/wizardeventmanager',
	'modules/wizard/events/psieventmanager',
	'modules/wizard/events/pageeventmanager'
], function(app, FlowPath, Pages, PlaceholderManager, SectionalLockdown, ActionCache, Metadata, WizardEventManager, PSIEventManager, PageEventManager){

	var PageSetInstance = Backbone.Model.extend({
		initialize: function(config, options){
			var cachedActions = new ActionCache();

			//listen at the app layer for requests from the services (formula)
			this.listenTo(PSIEventManager, 'psi:find:model psi:find:model:' + this.cid, function(address, deferred){
				this.findModel(address, deferred);
			}, this);

			this.listenTo(PSIEventManager, 'page:on:flowpath page:on:flowpath:' + this.cid, function(pageId, deferred){
				this.onFlowPath(pageId, deferred);
			}, this);

			this.listenTo(PSIEventManager, 'metadata:add:' + this.cid, function(attrs){
				//add metadata rule to the map, we'll arrive at the correct state upon upload
				this.get('metadata').add(attrs);
			});

			this.listenTo(PSIEventManager, 'cache:add:page:' + this.cid, function(questionId, ruleId, pageId, targetPageId){
				cachedActions.add({
					'id': [questionId, ruleId, pageId, targetPageId].join('_'),
					'questionId': questionId,
					'ruleId': ruleId,
					'pageId': pageId,
					'targetPageId': targetPageId
				});
			});

			this.listenTo(PSIEventManager, 'cache:remove:page:' + this.cid, function(questionId, ruleId, pageId, targetPageId, deferred){
				//first, check if page is cahched then remove this page from cache
				var page = {
					'id': [questionId, ruleId, pageId, targetPageId].join('_'),
					'questionId': questionId,
					'ruleId': ruleId,
					'pageId': pageId,
					'targetPageId': targetPageId
				};
				cachedActions.removeCachedPage(page);
				//allow page to be removed or false if there are other references
				deferred.resolve(cachedActions.canRemove(targetPageId));
			});

			this.listenTo(PSIEventManager, 'change:page:loaded:' + this.cid, function(pageIndex){
				var page = this.get('flowpath').getPageByIndex(pageIndex);
				PageEventManager.trigger('change:page', pageIndex, page.id);
			}, this);

			//get a placeholders instance for this PSI
			new PlaceholderManager([], {
				'psiId': this.cid
			});

			//if editing an existing form
			if(options && options.formId){
				//put sectional lockdown service on the pages' context for synchranous access
				this.sls = options.sls = new SectionalLockdown.Service({
					'formId': options.formId,
					'pages': this.get('pages')
				});
			}

			//build up pages
			var pages = new Pages(this.get('pages'), _.extend({}, options, {
				'psiId': this.cid
			}));

			//proc init chain of models - this handles the initialization chain
			this.set({
				'name': config.name,
				'psdName': config.psdName,
				'pages': pages
			});

			this.set({
				'flowpath' : new FlowPath({}, _.extend({}, options, {
					'pages': this.get('pages'),
					'schema': this.get('flowpath'),
					'psiId': this.cid
				}))
			});

            this.set({
               'metadata': new Metadata.Collection([])
            });

			//proc build command across the heirarchy
			PSIEventManager.trigger('build');

			//currently assumes only one psi can exist at any given time
			app.psi = this;
		},
		//given an address like $p44_q07$ find the corrsponding model
		findModel: function(address, deferred){
			if(address.indexOf('$') !== -1){
				address = address.replace(/\$/g, '');
			}
			var levels = address.split('_'); //delimit on underscore
			var model;
			switch(levels.length){
				//pages -> question -> row
				case 3: {
					model = this.get('pages').findWhere({'_id': levels[0]})
										 .get('questions').findWhere({'_id': levels[1] + '_' + levels[2]});
					break;
				}
				//pages -> question
				case 2: {
					model = this.get('pages').findWhere({'_id': levels[0]})
										 .get('questions').findWhere({'_id': levels[1]});
					break;
				}
				//pages
				case 1: {
					model = this.get('pages').findWhere({'_id': levels[0]});
					break;
				}
			}
			if(deferred){
				deferred.resolve(model);
			}
			if(!model){
				app.log.error(window.localize("modules.wizard.models.pageSetInstance.failedTo") + address);
			}
			//synchronous
			return model;
		},
		//given a page id like pg1, return weather or not its on the flowpath
		onFlowPath: function(pageId, deferred){
			var onFlowpath = this.get('flowpath').findWhere({'_id': pageId});
			if(deferred){
				deferred.resolve(onFlowpath);
			}
			//synchronous
			return onFlowpath;
		},
		//given a page id like pg1, return weather or not its locked
		isLocked: function(pageId){
			if(this.sls){
				return this.sls.getPage(pageId).isLocked();
			}
			return false;
		},
		toJSON: function(){
			var json = Backbone.Model.prototype.toJSON.call(this);
			//get current metadata state
			json.metadata = Metadata.getMetadata(this);
			return json;
		}
	});

	return PageSetInstance;
});
