define([
	'app',
	"oc",
	'URIjs/URI'
], function(app, OC, URI){
	//simple module for storing flags and states relevent to the Wizard
	var WizardContext = app.module();

	WizardContext.Model = Backbone.Model.extend({

		getCurrentPage: function(pathname){
			var formPath = new URI(pathname);
			// the current page number is always the last segment of the path
			return "pg" + (window.parseInt(formPath.segment()[formPath.segment().length - 1]));
		},
		build: function(psdName, params, formFolderPropToQuestionMap) {
			var self = this;

			app.context.configService.getWizardConfig(function(config) { 
	            //Search for the config corresponding to our form
	            var formInfo = _.find(config.get("wizardForms").models, function(form) {
	                return form.get("formName") === psdName;
	            });

	            if (params) {			
					// extract the newPsiName if one was provided
		            //(url would look like: http://localhost:9000/activeform/Simple%20CR/new?newPsiName=newPsiName)
					if (params.newPsiName) {
		                var reservedName = params.newPsiName;

		                self.set('reservedName', reservedName);
		                delete params.newPsiName;
		            }

		            if (params.wfDocIds) {
		                var wfDocIds = params.wfDocIds;

		                if (!_.isArray(wfDocIds)) {
		                    wfDocIds = [wfDocIds];
		                }

		                //add workflow doc ids to context
		                self.set('wfDocIds', wfDocIds);
		                delete params.wfDocIds;
		            }

		            if (params.relationName) {
		                var relationName = params.relationName;

		                //add workflow doc ids to context
		                self.set('relationName', relationName);
		                delete params.relationName;
		            }

		            if (params.psiIdToRelate) {
		                var psiIdToRelate = params.psiIdToRelate;

		                //add workflow doc ids to context
		                self.set('psiIdToRelate', psiIdToRelate);
		                delete params.psiIdToRelate;
		            }

		            //if populate flag is true
		            if (params.populate === "true") {
		                //get values and populate the form
		                var populateWith = {};

		                _.each(params, function(value, key){
		                    populateWith[window.decodeURIComponent(key)] = window.decodeURIComponent(value);
		                }, this);

		                self.set('populateWith', populateWith);
		            }
				}

				// we check if formInfo is defined because if the form has no config associated with it, we cannot look for the endpoint config settings
	            // check if we want to populate using an external endpoint and ensure a valid endpoint (non-null and not an empty string)
	            if (formInfo && formInfo.get('externalEndpointForPrepopulation') && formInfo.get('prePopulationEndpoint') !== "") {
	            	self.retrieveFormPropertiesJson(formInfo.attributes.prePopulationEndpoint).done(function(json) {
	            		self.parseJson(json);
	            	});
	            } else if (params && params.folderId) {
	                self.set('folderId', params.folderId);

	                if (params.getFolderProps === "true") {
	                    //need to fetch folder and get props
	                    if (formFolderPropToQuestionMap[psdName]) {
	                        var folderOco = new OC.OpenContentObject({'objectId': params.folderId});

	                        return folderOco.fetch({
	                            success: function(oco) {
									var populateWith = {};

	                                _.each(formFolderPropToQuestionMap[psdName], function(psQuestion, ocoProp){
	                                    if (oco.get("properties")[ocoProp]) {
	                                        populateWith[psQuestion] = oco.get("properties")[ocoProp];
	                                    }
	                                });

	                                self.set('populateWith', populateWith);
	                            }
	                        });
	                    }
	                }
	            }
	        });
		},
		/**
		 * Ajax call to the endpoint provided to retrieve any json properties.
		 * @param {String} jsonEndpoint - string indicating the url of our enpoint
		 */
		retrieveFormPropertiesJson: function(jsonEndpoint) {
			var deferred = $.Deferred();

			$.ajax({
				url: jsonEndpoint,
				dataType: "json",
				method: "GET",
				success: function(jsonPropertiesObject) {
					deferred.resolve(jsonPropertiesObject);
				},
				error: function() {
					app.log.error(window.localize("modules.wizard.models.wizardcontext.endpointFailure"));
	                deferred.resolve(undefined);
				}
			});

			return deferred.promise();
		},
		/**
		 * Parses the json retrieved from the ajax call and extends populateWith if
		 * it already exists; then sets populateWith on the wizard context.
		 * @param {Object} jsonObject - the json object retrieved from the ajax call
		 */
		parseJson: function(jsonObject) {
			if (jsonObject) {
				// valid json, set populateWith using the jsonObject
				var populateWith = {};

	            _.each(jsonObject, function(value, key){
	                populateWith[window.decodeURIComponent(key)] = window.decodeURIComponent(value);
	            });

	            // currentPopulateWith is what is currently on the wizardContext;
	            // this could be undefined if no URL params were set earlier or
	            // it could have already been set earlier with the URL params
	            var currentPopulateWith = this.get("populateWith");
	            
	            // extend the currentPopulateWith if it is available
	            if (currentPopulateWith) {
	            	var extendedPopulateWith = _.extend(currentPopulateWith, populateWith);
	            	this.set('populateWith', extendedPopulateWith);
	            } else {
	            	this.set('populateWith', populateWith);
	            }
			} else {
				// unable to parse the json
				app.trigger("alert:error", { message: window.localize("modules.wizard.models.wizardcontext.populateFailure") });
			}
		}
	});

	//apply to app
	app.wizardContext = new WizardContext.Model();
	return WizardContext;
});
