define([
	'app'
], function(app){
	//runtime memory for tracking all actions in the page set instance
	var ActionCache = {};

	//supprt leading actions. TODO: actions to support: query, justification
	ActionCache.Model = Backbone.Model.extend({
		defaults: {
			'questionId': '',
			'ruleId': '',
			'pageId': '',
			'targetPageId': ''
		},
		initialize: function(options){
			this.options = _.defaults(options, this.defaults);
		}
	});

	ActionCache.Collection = Backbone.Collection.extend({
		model: ActionCache.Model,
		getCachedPages: function(targetPageId){
			return this.where({'targetPageId': targetPageId});
		},
		//careful here
		//two scerios to cover: 
		//page 1 points to pages 2, 3 and 4 from one rule
		//page 1 points to page 2 from one rule
		//basically one-to-one and one-to-many
		removeCachedPage: function(reference){
			this.remove(this.findWhere(reference));
		},
		canRemove: function(targetPageId){
			//only allow a page to be removed if its the only reference in the cache or its not cahced at all
			return _.isEmpty(this.getCachedPages(targetPageId));
		}
	});

	return ActionCache.Collection;
});