define([
	'app',
	'modules/wizard/models/field'
], function(app, Field){
	var FieldCollection = Backbone.Collection.extend({
		model: Field	
	});

	return FieldCollection;
});