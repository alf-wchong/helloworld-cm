define([
	'app',
	'underscore',
	'modules/wizard/models/questioncollection',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/events/pageeventmanager'
], function(app, _, Questions, QuestionEventManager, PageEventManager){
	var Page = Backbone.Model.extend({
		idAttribute: '_id',
		defaults: {
			'name': window.localize("modules.wizard.models.page.page"),
			'instructions': window.localize("modules.wizard.models.page.pleaseComplete")
		},
		initialize: function(config, options){
			options.page_id = this.id;
			this.category = config.category;
			this.description = config.description;
			options.questionGroups = config.questionGroups;
			options.nonRepeatingQuestionGroup = config.nonRepeatingQuestionGroup;
			options.sectionalLockdown = config.sectionalLockdown;

			this.set({
				questions: new Questions(this.get('questions'), options)
			});

			//initalize questions then processGroupedQuestions
			this.get('questions').processGroupedQuestions();

			this.get('questions').each(function(question){
				this.listenTo(QuestionEventManager, 'change:question:validity:' + question.getAddress(), function(model){
					this.validateCollection();
					PageEventManager.trigger('change:page:validity:' + options.psiId, this.get('id'), this);
				}, this);
			}, this);

			//listen for question collection to change (grouped questions)
			this.listenTo(QuestionEventManager, 'change:question:collection:validity', function(model){
				//listen to any new individual questions
				this.get('questions').each(function(question){
					this.stopListening(QuestionEventManager, 'change:question:validity:' + question.getAddress());
					this.listenTo(QuestionEventManager, 'change:question:validity:' + question.getAddress(), function(model){
						this.validateCollection();
						PageEventManager.trigger('change:page:validity:' + options.psiId, this.get('id'), this);
					}, this);
				}, this);
				//validate the page
				this.validateCollection();
				PageEventManager.trigger('change:page:validity:' + options.psiId, this.get('id'), this);
			}, this);
		},
		validateCollection: function(){
			//validate just this page
			var message = this.get('questions').validateCollection();
			this.set('valid', message === undefined);
			return message;
		},
		isValid: function(){
			return this.get('valid');
		}
	});

	Page.prototype.toJSON = function() {
		return _.extend({}, Backbone.Model.prototype.toJSON.apply(this, arguments), { 'questionGroups' : this.get('questions').questionGroups });
	};

	return Page;
});
