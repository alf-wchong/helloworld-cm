//The model for our streamline approved confirmation page
define([
    'app'
], function(app){
	var slFormConfirmationModel = Backbone.Model.extend({
        defaults: {
            title: 'Confirmation Page',
            textAreaText: 'Thank you for filling out the form',
            hasRelaunch: true, //Do we display the relaunch button or not
            hasViewer : true, //Do we display the viewer or not
            isOA : true, //Are we displaying openAnnotate or not (as opposed to just a pdf)
            formId : "",
            objectId : ""
        },
        initialize: function(){
            //If we want to display the viewer, but do not have a viwerType, set a default
        	if (this.get("hasViewer") && !this.has("isOA")) {
                this.set("isOA",true);        	
            }
            //If we want to dispay open annotate set our open annotate properties
            if (this.get("isOA")) {
                this.set('oaURL', app.openAnnotateURL);
                this.set('oaUserName', app.user.get("loginName"));
            }
        }
    });

    return slFormConfirmationModel;
});