define([
	'app'
], function(app){
	 var ANSWER_VALUE = 'answer_value',
 	 	 ANSWER_DISPLAY_TEXT = 'answer_display_text',
 	 	 ANSWER_JUSTIFICATION = 'answer_justification';

	//runtime instaance for tracking all metadata rules for a form
	var Metadata = {};

	Metadata.Model = Backbone.Model.extend({
		defaults: {
			'page_id': '',
			'question_id': '',
			'repoAttr': '',
			'answer': '',
			'type': ANSWER_VALUE
		}, 
		initialize: function(options){
			this.options = _.defaults(options, this.defaults);
			//include the metadata type to support multiple metadfata rules on a single question
			this.id = [this.options.page_id, this.options.question_id, this.options.repoAttr, this.options.type].join('_');

			this.set({
				'repoAttr': this.options.repoAttr,
				'answer': this.options.answer,
				'type': this.options.type
			});
		},
		getAnswer: function(){
			return this.get('answer');
		},
		getRepoAttr: function(){
			return this.get('repoAttr');
		}
	});
	
	Metadata.Collection = Backbone.Collection.extend({
		model: Metadata.Model,
		modelId: function(attrs) {
		 	//What is this? - as of Backbone 1.1 model ids are overridden at the collection level
	        //be sure to create a unique identifier for the model so adding a duplicate to the collection is a no-op (see the backbonejs.ord docs)
			return [attrs.options.page_id, attrs.options.question_id, attrs.options.repoAttr, this.options.type].join('_');
	    }
	});

	//synchranous function for parsing and updating the metadata map of the passed-in page set instance
	Metadata.getMetadata = function(psi){
		var metadataMap = {};
		//track all metadata answers not on the flowpath to blank them out correctly
		var notOnFlowpath = {};
		//bucket together all repo attrbutes on the flowepath to assess precedence
		var repoAttributes = {};
		psi.get('metadata').each(function(metadataRule){
			var page_id = metadataRule.get('page_id');
			var question_id = metadataRule.get('question_id');
			var repoAttr = metadataRule.get('repoAttr');
			var type = metadataRule.get('type');
			var onFlowPath = psi.onFlowPath(page_id);
			var answer = '';
			if(onFlowPath){
				//get the latest answer to this question and update the metadata map
				//address is page_id + _ + question_id
				var question = psi.findModel(page_id + '_' + question_id);
				answer = question.get('field');
                if(type === ANSWER_VALUE){
					//value may be an object in the case of typeahead or tossacross
					if(answer.getValues){
						var answerValues = answer.getValues();
						answer = _.pluck(answerValues, 'value');
					}else{
						var answerValue = answer.getValue();
						if(typeof answerValue === 'object'){
							answerValue = answerValue.value;
						}
						answer = answerValue;
					}
				}else if(type === ANSWER_DISPLAY_TEXT){
					answer = answer.getDisplayValue();
				}else if(type === ANSWER_JUSTIFICATION){
					//justifications
					var justifications = [];
					_.each(answer.get('justifications'), function(value, key){
						justifications.push(value);
					}, this);
					answer = justifications.join(', ');
				}
				//going to make two passes, first pass to figure out metadata rule precedence - order of the metadata rules matter
				//bucket together each repo type
				if(!repoAttributes[repoAttr]){
					repoAttributes[repoAttr] = [];
				}
				repoAttributes[repoAttr].push({
					'type': type,
					'answer': answer
				});
			}else{
				notOnFlowpath[repoAttr] = '';
			}
		}, this);
		//second pass gets the associated answer for that type - it must have an answer as well
		_.each(repoAttributes, function(answers, attr){
			var repoAttrValue = '';
			var foundAttr = false;
			if(answers && answers.length > 0){
				//precedence is based on the order of the metadata rules for this question - last one wins
				var metadataRule = answers[answers.length - 1];
				repoAttrValue = metadataRule.answer;
				foundAttr = true;
			}
			if(!foundAttr){
				app.log.error(window.localize("modules.wizard.models.metaData.failedTo") + attr);
			}
			metadataMap[attr] = repoAttrValue;
		}, this);
		//clear out each attribute not on the flowpath
		return _.extend({}, notOnFlowpath, metadataMap);
	};

	return Metadata;
});