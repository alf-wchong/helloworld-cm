define([
	'app',
	'modules/wizard/formfields/fieldfactory',
	'modules/wizard/events/fieldeventmanager'
], function(app, FieldFactory){
	var Field = function(config, options){
		var model = FieldFactory.createField(config, options);
		//vent any field level validations
		//wait for displayValue to be formatted before tripping validation
		model.on('validate change:displayValue', function(options){
			//send a validation event to question.js
			var message = model.validate();
			if(options.dontShowMessage) {
				message = "";
			}
			if(message){
				model.trigger('field:invalid', message);
			}else{
				model.trigger('field:valid');
			}
		}, this);
		
		//field factory returns backbone models
		return model;
	};

	return Field;
});
