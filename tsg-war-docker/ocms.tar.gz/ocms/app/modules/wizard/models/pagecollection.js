define([
	'app',
	'modules/wizard/models/page'
], function(app, Page){
	var PageCollection = Backbone.Collection.extend({
		model: Page
	});

	return PageCollection;
});