define([
	'app',
	'modules/wizard/services/questionutils',
	'modules/wizard/models/question',
	'modules/wizard/models/rule',
	'modules/wizard/models/rulecollection',
	'modules/wizard/models/field',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/events/psieventmanager'
], function(app, QuestionUtils, Question, Rule, RuleCollection, Field, RuleEventManager, QuestionEventManager, PSIEventManager){

	var QuestionCollection = Backbone.Collection.extend({
		model: Question,
		initialize: function(config, options){
			//keep reference to the parent page
			this.page_id = options ? options.page_id : undefined;
			this.psiId = options ? options.psiId : undefined;

			//question groups are piggy backing off question collection, slice it and push the reat as question models
			if(config && config.questionGroups){
				this.questionGroups = _.extend([], config.questionGroups);
				delete config.questionGroups;
			}
			else if(options && options.questionGroups){
				this.questionGroups = options.questionGroups;
			}
			else{
				var tempArray = [];
				this.questionGroups = [tempArray];
			}

			// the non repeating question group associated with the question collection
			this.nonRepeatingQuestionGroup = options.nonRepeatingQuestionGroup ? options.nonRepeatingQuestionGroup : [];

			//send all events to validateCollection
			this.bindEvents();
		},
		bindEvents: function(){
			this.on('add remove reset', this.validateCollection, this );
		},
		// we're doing extra work in here, we can reduce this if need be.
		/**
		 * validateCollection is used to aggregate the validity results of the various questions that belong to it
		 *
		 * @return undefined if there are no errors, a map of validation errors if so
		 */
		validateCollection: function(){
			var validation = {};
			var allValid = true;
			if(this.models.length === 0){
				return window.localize("modules.wizard.models.questionCollection.noQuestion");
			}
			this.each(function(question){
				//validate each field
				var message = question.get('field').validate();
				if(message){ //all questions not valid
					allValid = false;
				}
				validation[question.get('field').cid] = message;
			}, this);
			if(allValid){
				return;
			}else{
				return validation;
			}
		},
		//mark questions as grouped for processing in OC/Summary page
		processGroupedQuestions: function(){
			//mark each question as grouped if included in questionGroups
			this.each(function(question){
				var fullQuestionId = this.page_id + '_' + question.id;
				var grouped = false;
				_.each(this.questionGroups, function(group){
					grouped = _.contains(group, fullQuestionId);
					if(grouped){
						question.set('grouped', true);
						return; //break, found it
					}
				}, this);
			}, this);
		},
		//Need to do more than simply returning the last elememnt of the array... Since we reorder this.questionGroups,
		//We need to search for the one with the highest '_r' and return that.
		getLastQuestionGroup: function(){
			var groupToReturn;
			var highest = 0;
			_.each(this.questionGroups, function(group){
				if(group[0].split("_")[2]){
					if(group[0].split("_")[2].slice(-1) > highest){
						groupToReturn = group;
					}
				}
			});
			if(!groupToReturn){
				return this.questionGroups[0];
			}else{
				return groupToReturn;
			}
		},
		//Calculates the number of hidden questions per row
		getNumHidden: function(){
			var numHidden = 0;
			var questionGroup = this.models.slice(0, this.getLastQuestionGroup().length);
			_.each(questionGroup, function(question){
				if(!question.get("field").isVisible()){
					numHidden++;
				}
			});
			return numHidden;
		},
		getQuestionsPerRow: function(){
			return this.questionGroups[0].length;
		},
		cloneQuestions: function(){
			//since the question group is a subset of the question collection
			//loop through and clone the questions in place, no need to vent
			var nextRow = [];
			var newQuestionsRow = [];
			var lastRow = this.getLastQuestionGroup();
			_.each(lastRow, function(id, index){
				//get model to clone
				//trim off page id
				var inputId;
				if(id.split('_')[2]){
					inputId = id.split('_')[1] + '_' + id.split('_')[2];
				}else{
					inputId = id.split('_')[1];
				}
				var model = this.findWhere({'_id': inputId});
				if(model){
					var parent_page = model.page_id;

					var options = {
						page_id: parent_page
					};
					//copy model
					var copy = QuestionUtils.copyQuestion(model, options);
					//get next id in this WIP row
					copy._id = QuestionUtils.getNextAvalibleQuestionAddress(id, this.questionGroups);

					//clone model - convert any sub-models to their json
					var clonedQuestion = new Question(copy, options);
					//update reference in questionGroups to the last row
					var newAddress = this.page_id + '_' + clonedQuestion.id;
					nextRow[index] = newAddress;
					//add to this collection
					newQuestionsRow.push(clonedQuestion);
				}
			}, this);
			//add new row to the question groups registry
			this.questionGroups.push(nextRow);

			// must now update the addresses of any calculation fields, and any other rules that may depend upon the new models being in place.
		    _.each(newQuestionsRow, function(question){
		    	QuestionUtils.updateRules(question, this.questionGroups);
		    }, this);

			//re-build, reset, and then re-bind - THIS IS IMPORTANT - DON'T MODIFY
			this.reset(this.models.concat(newQuestionsRow));
			PSIEventManager.trigger('build');
			this.bindEvents();

            //notify this page of its state
            QuestionEventManager.trigger('change:question:collection:validity');

			// return newQuestionsRow incase we want to auto populate it
			return newQuestionsRow;
		},
		//similar to cloning questions, deleting questions is based on the question group
		deleteQuestions: function(row){
			//if the last row, don't remove
			if(!row || row === 0){
				return;
			}
			var updatedModels;

			//remove this row of questions
			_.each(this.questionGroups[row], function(address){
				//possible addresses: p1_in0 or p1_in0_r0
				var questionId = _.rest(address.split('_'), 1).join('_');
				//fire event on the RuleManager to clean up this removed question
				RuleEventManager.trigger('remove:question', address);
				//keep track of the models being removed
				var questionToBeDeleted = this.findWhere({'_id': questionId});
				if(updatedModels){
					updatedModels = _.without(updatedModels, questionToBeDeleted);
				}else{
					updatedModels = this.without(questionToBeDeleted);
				}
				
				questionToBeDeleted.stopListening();
				this.remove(questionToBeDeleted);
			}, this);

			this.questionGroups.splice(row, 1);
			// in Backbone 1.1.2 reset does not release listeners correctly, need to call remove on individual models
			// this.reset(updatedModels);
			this.bindEvents();
            //notify this page of its state
            QuestionEventManager.trigger('change:question:collection:validity');
		},
		//expose question groups so page view can render correctly
		getQuestionGroups: function(){
			//create a table of questions
			//only pass in questions belong ing to this group
			var individualQuestions = new Backbone.Collection();
			var groupedQuestions = new Backbone.Collection();
			var nonRepeatingGroupedQuestions = new Backbone.Collection();
			var concatedQuestionGroups = [];
			concatedQuestionGroups = concatedQuestionGroups.concat.apply(concatedQuestionGroups, this.questionGroups);

			// loops through all questions of each question group
			this.each(function(question){
				if(question){
					// if the question is part of a regular repeating group, add it to the corresponding collection
					if (concatedQuestionGroups.indexOf(this.page_id + '_' + question.id) !== -1) {
						groupedQuestions.add(question);

					// if the question is in the non repeating question group, add it to the corresponding collection
					} else if (this.nonRepeatingQuestionGroup.indexOf(this.page_id + '_' + question.id) !== -1) {
						nonRepeatingGroupedQuestions.add(question);

					// else it is an individual question
					} else {
						individualQuestions.add(question);
					}
				}
			}, this);

			return {
				'individualQuestions': individualQuestions,
				'groupedQuestions': groupedQuestions,
				'nonRepeatingGroupedQuestions': nonRepeatingGroupedQuestions
			};
		},
		//Here we are doing bubble sort where many swaps are made.  This is required because we can't just simply swap questions,
		//we need to make sure there is a shift up/down if you moce a row more than one row away.
		reorderQuestions: function(selectedRow, moveTo){
			var self = this;

			this.reorderQuestionGroups(this.questionGroups, selectedRow - 1, moveTo - 1);

			//The difference in rows shows us how many times we have to swap the questions
			var differenceInRows = Math.abs(selectedRow - moveTo);
			this.questionsPerRow = this.getQuestionsPerRow();
            this.groupedQuestions = this.getQuestionGroups().groupedQuestions;
            var startingIndex = (selectedRow - 1) * this.questionsPerRow;
            var srcRange = _.range(startingIndex, startingIndex + this.questionsPerRow);
			//Need different login based on whether you are moving up or down.
			if(selectedRow < moveTo){
                 _.each(_.range(1, differenceInRows + 1), function(n){
                     _.each(srcRange, function(indexOfSrc){
                         self.swapQuestions( self.groupedQuestions.at(indexOfSrc), self.groupedQuestions.at( indexOfSrc + (self.questionsPerRow * n) ) );
                     });
                 });
             } else{
                 _.each(_.range(1, differenceInRows + 1), function(j){
                     _.each(srcRange, function(indexOfSrc){
                         self.swapQuestions( self.groupedQuestions.at(indexOfSrc), self.groupedQuestions.at( indexOfSrc - (self.questionsPerRow * j) ) );
                     });
                 });
             }
        },
        swapQuestions: function(modelA, modelB){
        	var indexA = this.indexOf(modelA);
        	var indexB = this.indexOf(modelB);
        	this.models[indexA] = modelB;
        	this.models[indexB] = modelA;
        },
		reorderQuestionGroups: function(arr, from, to){
			var element = arr[from];
    		arr.splice(from, 1);
    		arr.splice(to, 0, element);
	   },
		toJSON: function(){
			return _.extend([], Backbone.Collection.prototype.toJSON.apply(this, arguments), { questionGroups : this.questionGroups });
		}
	});

	return QuestionCollection;
});
