define([
	'app',
	'modules/wizard/models/rule'
], function(app, Rule){
	var RuleCollection = Backbone.Collection.extend({
		model: Rule
	});

	return RuleCollection;
});