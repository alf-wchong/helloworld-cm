define([
	'app'
], function(app){
	var Rule = Backbone.Model.extend({
		idAttribute: '_id',
		initialize: function(config, options){
			this.set('conditions', new Backbone.Collection(config ? config.conditions : []));
			this.set('type', config ? config.type : '');
			this.set('addToEnd', config ? config.addToEnd : false);
			this.set('actions', new Backbone.Collection(config ? config.actions : []));
			this.set('triggerOn', config ? config.triggerOn : '');
		},
		getActions: function(){
			return this.get('actions');
		},
		getType: function(){
			return this.get('type');
		},
		getTrigger: function(){
			return this.get('triggerOn');
		}
	});

	return Rule;
});