define([
	'app',
	'modules/wizard/models/workflow/workflowruleevaluator',
	'modules/wizard/events/psieventmanager'
], function(app, WFRuleEvaluator, PSIEventManager){
	var USER_INPUT_RULES = 'user-input-rules';
	var WorkflowRule = Backbone.Model.extend({
		defaults: {
			'input-id': '',
			'page-id': '',
			'option-value': '',
			'current-value': undefined,
			'input-type': 'string',
			'input-label': '',
			'input-short-label': '',
			'input-operator': undefined,
			'users': [],
			'ruleType': undefined,
			'operator': 'OR'
		},
		getOption: function(){
			return this.get('option-value');
		},
		getValue: function(){
			return this.get('current-value');
		},
		getOperator: function(){
			return this.get('input-operator');
		},
		getLabel: function(){
			return this.get('input-label');
		},
		getShortLabel: function(){
			return this.get('input-short-label');
		},
		getType: function(){
			return this.get('input-type');
		},
		isRepeating: function(){
			return this.get('isRepeating');
		},
		getUsers: function(){
			if(this.getRuleType() === USER_INPUT_RULES){
				return _.isArray(this.getValue()) ? this.getValue() : [this.getValue()];
			}
			return _.isArray(this.get('users')) ? this.get('users') : [this.get('users')];
		},
		hasUsers: function(){
			return this.getUsers() && this.getUsers().length > 0;
		},
		getReason: function(){
			return this.get('reason');
		},
		getRuleType: function(){
			return this.get('ruleType');
		},
		getBooleanOperator: function(){
			return this.get('operator');
		},
		//override fetch and return the substitution for this rule
		fetch: function(){
			var self = this;
			var fetched, onFlowPath, getQuestion;
			fetched = $.Deferred();
			onFlowPath = $.Deferred();
			getQuestion = $.Deferred();
			PSIEventManager.trigger('page:on:flowpath', self.get('page-id'), onFlowPath);
			$.when(onFlowPath).done(function(page){
				//only bother getting the value if its even on the flowpath
				var onFlowpath =  page !== undefined ? true : false;
				self.set('onFlowpath', onFlowpath);
				if(onFlowpath){
					PSIEventManager.trigger('psi:find:model', self.get('address'), getQuestion);
					$.when(getQuestion).done(function(question){
						//might be repeating - CR Approvers for example
						var isRepeating = question.get('field').isRepeating();
						var value = isRepeating ? question.get('field').getValues() : question.get('field').getValue();
						self.set('isRepeating', isRepeating);
						self.set('input-label', question.get('label') || question.get('short-label'));
						self.set('current-value', value);
						self.set('current-displayvalue', question.get('field').get('displayValue'));
						fetched.resolve(value);
					});
				}else{
					fetched.resolve(undefined);
				}
			});
			return fetched;
		},
		//modify isValid to tac on an isValid attr for easy view rendering later
		isValid: function(){
			//call parent isValid - don't re-invent wheel
			var isValid = Backbone.Model.prototype.isValid.call(this);
			this.set('isValid', isValid);
			return isValid;
		},
		validate: function(){
			if(!this.get('onFlowpath')){
				return 'not on flowpath';
			}
			var isValid;
			var operator = this.getOperator();
			var isProximityDate = WFRuleEvaluator.isProximityDate(operator);
			if(isProximityDate){
				var numDays = Number(operator.match(/^[0-9]+/)[0]);
				isValid = WFRuleEvaluator.evaluate(isProximityDate, {
					'target': this.getOption(),
					'value': this.getValue(),
					'numDays': numDays, 
					'type': this.getType(),
					'isRepeating': this.isRepeating()
				}) ? undefined : 'invalid date';
			}else{
				isValid = WFRuleEvaluator.evaluate(operator, {
					'target': this.getOption(),
					'value': this.getValue(),
					'type': this.getType(),
					'isRepeating': this.isRepeating()
				}) ? undefined : 'invalid';
			}
			if(!isValid){ //valid is undefined
				//set end-user reason
				this.set('reason', WFRuleEvaluator.getReason(isProximityDate || operator, {
					'label': this.getLabel(),
					'target': this.getOption(),
					'value': this.getValue(),
					'type': this.getType(),
					'isRepeating': this.isRepeating()
				}));
			}
			return isValid;
		}
	});

	return WorkflowRule;
});