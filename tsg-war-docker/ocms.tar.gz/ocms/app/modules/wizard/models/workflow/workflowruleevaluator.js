define([
	'app'
], function(app){
	var WorkflowRuleEvaluator = {};
	
	var PROXIMITY_DATE_BUSINESS_DAYS = 'proximitydateexcludeweekends';
	var PROXIMITY_DATE = 'proximitydate';
	var DATE = "date";
	var TODAY = "Date Saved";
	var BLANK = "blank";
	var DATE_FORMAT = "MM/DD/YYYY";
	var IGNORE_CASE = 'i';

	//gregorian days of the week: saturday = 6, sunday is 0
	var SATURDAY = 6;
	var SUNDAY = 0;
	//return an array of dates in range from the specified startDate
	var getDaysInRange = function(startDate, rangeOfDays, businessDaysOnly){
	    var daysInRange = [startDate.format(DATE_FORMAT)];
	    _.each(_.range(1, Math.abs(rangeOfDays) + 1), function(numDays){
		    //reset to startDate
	        var targetDate = startDate.clone();
	        while(numDays > 0){
	            if(rangeOfDays > -1){
	                targetDate = targetDate.add(1, 'day');
	            }else{
	                targetDate = targetDate.subtract(1, 'day');
	            }
	            var dayOfWeek = targetDate.day();
	            while(businessDaysOnly && (dayOfWeek === SATURDAY || dayOfWeek === SUNDAY)){
	                //only tick forward days that are business days
	                if(rangeOfDays > -1){
	                    targetDate = targetDate.add(1, 'day');
	                }else{
	                    targetDate = targetDate.subtract(1, 'day');
	                }
	                dayOfWeek = targetDate.day();
	            }
	            numDays--;
	        }
	        //keep order
	        if(rangeOfDays > -1){
	            daysInRange.push(targetDate.format(DATE_FORMAT));
	        }else{
	            daysInRange.unshift(targetDate.format(DATE_FORMAT));
	        }
	    }, this);
	    return daysInRange;
	};
	//support function for regexing strings from either the start or the end
	var tokenize = function(word, fromEnd){
	    var tokens = [];
	    //push each character and value
	    //in this impl, not mid-string matches allowed
	    _.each(_.range(word.length), function(character, index){
	    	if(fromEnd){
	            tokens.push(word.substr(index, word.length));   
	        }else{
	        	//from beginning
	            tokens.push(word.substr(0, index + 1));   
	        }
	    }, this);
	    return tokens;
	};

	//Util function for parsing repeating values into comma-seperated strings or passing through regular strings
	//or reeturns the display value of an object
	var parseDisplayValues = function(result){
		var displayValues;
		if(_.isArray(result)){
			if(typeof result[0] === 'string'){
				displayValues = result.slice(0, result.length - 1);
				return displayValues.join(', ') + ' or ' + displayValues[displayValues.length-1];
			}else{ //each selected option is an object
				displayValues = _.pluck(result, 'displayValue');
				var clauses = displayValues.slice(0, displayValues.length - 1);
				return clauses.join(', ') + ' or ' + displayValues[displayValues.length-1];
			}
		}else if(typeof result === 'object'){
			return result.displayValue;
		}else{
			return result; //just a string, pass through
		}
	};

	//util function for converting an array of objects otr strings to lowercase
	var convertRepeatingValues = function(repeatingValues){
		var optionsToEval = [];
		if(!repeatingValues || repeatingValues[0] === undefined){
			return optionsToEval;
		//pluck and toLowerCase each value
		}else if(typeof repeatingValues[0] === 'string'){
			_.each(repeatingValues, function(val){
				optionsToEval.push(val.toLowerCase());
			}, this);
		}else{
			//each option is an object, gget each value and toLowerCase
			optionsToEval = _.pluck(repeatingValues, 'value');
			_.each(optionsToEval, function(val){
				optionsToEval.push(val.toLowerCase());
			}, this);
		}
		return optionsToEval;
	};

	WorkflowRuleEvaluator.isProximityDate = function(operator){
		//either return after, before, beforeafter, or undefined
		var isProximityDate = new RegExp(/^[0-9]+~\$~(before|after|beforeafter)$/).test(operator);
		if(isProximityDate){
			return operator.replace(/^[0-9]+~\$~/, '');
		}
		return;
	};

	//localizations for each operation we want a reason from
	var reasons = {
		'equal': {
			getReason: function(options){
				switch(options.type){
					case 'string':
						if(options.target === BLANK){
							return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isBlank");
						}else{
							return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.is") + parseDisplayValues(options.value);
						}
						break;
					case 'date':
						var currentDate = moment(options.value, DATE_FORMAT).format(DATE_FORMAT);
						return  options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.is") + currentDate;
					default:
						return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.is") + options.value;
				}
			}
		},
		'not equal': {
			getReason: function(options){
				switch(options.type){
					case 'string':
						if(options.target === BLANK){
							return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isNotBlank");
						}else{
							return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isNot") + parseDisplayValues(options.target);
						}
						break;
					case 'date':
						var targetDate = moment(options.target, DATE_FORMAT).format(DATE_FORMAT);
						return  options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isNot") + targetDate;
					default:
						return options.label + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isNot") + options.target;
				}
			}
		},
		'contains': {
			getReason: function(options){
				return options.target + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.contains") + parseDisplayValues(options.target);
			}
		},
		'not contains': {
			getReason: function(options){
				return options.target + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.doesNotContain") + parseDisplayValues(options.target);
			}
		},
		'starts with': {
			getReason: function(options){
				return options.target + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.startsWith") + parseDisplayValues(options.target);
			}
		},
		'ends with': {
			getReason: function(options){
				return options.target + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.endsWith") + parseDisplayValues(options.target);
			}
		},
		'less than': {
			getReason: function(options){
				return options.value + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isLessThan") + options.target;
			}
		},
		'greater than': {
			getReason: function(options){
				return options.value + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isGreaterThan") + options.target;
			}
		},
		'before': {
			getReason: function(options){
				return options.value + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isBefore") + options.target;
			}
		},
		'after': {
			getReason: function(options){
				return options.value + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isAfter") + options.target;
			}
		},
		'beforeafter': {
			getReason: function(options){
				return options.value + window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.isInRangeOf") + options.target;
			}
		}
	};

	var operations = {
		'equal': {
			validate: function(options){
				switch(options.type){
					case 'string':
						if(options.target === BLANK && options.isRepeating){
							return options.value && options.value.length === 0;
						}else if(options.target === BLANK){
							return !options.value || options.value === undefined || options.value === '';
						}
						if(options.isRepeating){
							return _.contains(convertRepeatingValues(options.value), options.target.toLowerCase());
						}else{
							//case-insensitive matching
							if(typeof options.value === 'string'){
								return options.value.toLowerCase() === options.target.toLowerCase();
							}else{ //each selected option is an object
								return options.value.value.toLowerCase() === options.target.toLowerCase();
							}
						}
						break;
					case 'date':
						var targetDate = moment(options.target, DATE_FORMAT).format(DATE_FORMAT);
						var currentDate = moment(options.value, DATE_FORMAT).format(DATE_FORMAT);
						return  targetDate === currentDate;
					default:
						return options.target === options.value;
				}
			}
		},
		'not equal': {
			validate: function(options){
				switch(options.type){
					case 'string':
						if(options.target === BLANK && options.isRepeating){
							return options.value && options.value.length !== 0;
						}else if(options.target === BLANK){
							return options.value && options.value !== undefined && options.value !== '';
						}
						if(options.isRepeating){
							return !_.contains(convertRepeatingValues(options.value), options.target.toLowerCase());
						}else{
							//case-insensitive matching
							if(typeof options.value === 'string'){
								return options.value.toLowerCase() !== options.target.toLowerCase();
							}else{ //each selected option is an object
								return options.value.value.toLowerCase() !== options.target.toLowerCase();
							}
						}
						break;
					case 'date':
						var targetDate = moment(options.target, DATE_FORMAT).format(DATE_FORMAT);
						var currentDate = moment(options.value, DATE_FORMAT).format(DATE_FORMAT);
						return  targetDate !== currentDate;
					default:
						return options.target !== options.value;
				}
			}
		},
		'contains': {
			validate: function(options){
				switch(options.type){
					case 'string':
						var value = options.value.value !== undefined ? options.value.value : options.value;
						if(options.isRepeating){
							if(value && value.length > 0){
								if(typeof value[0] === 'string'){
									return _.contains(value, options.target.toLowerCase());
								}else{ //each selected option is an object
									return _.contains(_.pluck(value, 'value'), options.target.toLowerCase());
								}
							}
						}else{
							//case-insensitive matching
							return options.target.toLowerCase().indexOf(value.toLowerCase()) !== -1;
						}
						break;
					default:
						return options.target.indexOf(value) !== -1;
				}
			}
		},
		'not contains': {
			validate: function(options){
				switch(options.type){
					case 'string':
						if(options.isRepeating){
							if(options.value && options.value.length > 0){
								if(typeof options.value[0] === 'string'){
									return !_.contains(options.value, options.target.toLowerCase());
								}else{ //each selected option is an object
									return !_.contains(_.pluck(options.value, 'value'), options.target.toLowerCase());
								}
							}
						}else{
							//case-insensitive matching
							return options.target.toLowerCase().indexOf(options.value.toLowerCase()) === -1;
						}
						break;
					default:
						return options.target.indexOf(options.value) === -1;
				}
			}
		},
		'starts with': {
			validate: function(options){
				var startsWith = new RegExp('^' + tokenize(options.target).join('|') + '[\\w]*', IGNORE_CASE);
				return startsWith.test(options.value);
			}
		},
		'ends with': {
			validate: function(options){
				var endsWith = new RegExp('^[\\w]*' + tokenize(options.target, true).join('|') + '$', IGNORE_CASE);
				return endsWith.test(options.value);
			}
		},
		'less than': {
			validate: function(options){
				return options.value < options.target;
			}
		},
		'greater than': {
			validate: function(options){
				return options.value > options.target;
			}
		},
		'before': {
			validate: function(options){
				var targetDate;
				if(options.target === TODAY){
					targetDate = moment(); //get current date
				}else{
					targetDate = moment(options.target, DATE_FORMAT);
				}
				var selectedDate = moment(options.value, DATE_FORMAT);
				var numDaysBefore = options.numDays * -1;
				if(options.type === PROXIMITY_DATE_BUSINESS_DAYS){
					return _.contains(getDaysInRange(targetDate, numDaysBefore, true), selectedDate.format(DATE_FORMAT));
				}else if(options.type === PROXIMITY_DATE){
					return _.contains(getDaysInRange(targetDate, numDaysBefore), selectedDate.format(DATE_FORMAT));
				}else if(options.type === DATE){
					return selectedDate.isBefore(targetDate);
				}
			}
		},
		'after': {
			validate: function(options){
				var targetDate;
				if(options.target === TODAY){
					targetDate = moment(); //get current date
				}else{
					targetDate = moment(options.target, DATE_FORMAT);
				}
				var selectedDate = moment(options.value, DATE_FORMAT);
				var numDaysAfter = options.numDays;
				if(options.type === PROXIMITY_DATE_BUSINESS_DAYS){
					return _.contains(getDaysInRange(targetDate, numDaysAfter, true), selectedDate.format(DATE_FORMAT));
				}else if(options.type === PROXIMITY_DATE){
					return _.contains(getDaysInRange(targetDate, numDaysAfter), selectedDate.format(DATE_FORMAT));
				}else if(options.type === DATE){
					return selectedDate.isAfter(targetDate);
				}
			}
		},
		'beforeafter': {
			validate: function(options){
				return WorkflowRuleEvaluator.evaluate('before', options) || WorkflowRuleEvaluator.evaluate('after', options);
			}
		}
	};

	//function wrapper for re-using and chaining together operations
	WorkflowRuleEvaluator.evaluate = function(operator, options){
		if(operator === undefined){
			//user-input-rules have no operators
			return true;
		}else if(!operations[operator]){
			app.log.error(window.localize("modules.wizard.models.workflow.workflowRuleEvaluator.workflowRules") + operator);
			return false;
		}
		return operations[operator].validate(options);
	};

	//function wrapper for retrieving the end-user message for a rule
	WorkflowRuleEvaluator.getReason = function(operator, options){
		//we assume the question is valid
		if(!reasons[operator]){
			//app.log.error('workflow rules message: no operator found for ' + operator);
			return;
		}
		return reasons[operator].getReason(options);
	};

	return WorkflowRuleEvaluator;
});