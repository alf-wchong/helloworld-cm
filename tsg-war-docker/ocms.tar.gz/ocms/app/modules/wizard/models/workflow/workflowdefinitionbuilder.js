define([
	'app',
	'modules/wizard/models/workflow/workflowdefinitionprovider'
], function(app, WFDefProvider){
	//constants
	var TOP_LEVEL_RULES = 'top-level-rules';
	var USER_INPUT_RULES = 'user-input-rules';
	var USER_RULES = 'user-rules';

	var ROLE_TYPE_USER = 'user';

	var WorkflowBuilder = {};

	var getRole = function(role){
		var deferred = $.Deferred();
		$.ajax({
			url: app.serviceUrlRoot + "/content/content?contentType[]=json&id=" + encodeURIComponent(role.get('objectId')),
            dataType: "json",
            success: function(json){
            	//parse out rules and the owner
            	var roleJson = _.extend({}, json.role["rule-containers"]["rule-container"], {
            		'priority': role.get('priority'),
            		'owner': json.role.owner,
            		'name': role.get('name'),
            		'esig-psi': json.role['esig-psi'].enabled,
            		'esig-wf-docs': json.role['esig-wf-docs'].enabled,
            		'type': role.get('type') || ROLE_TYPE_USER //default to user role
            	});

            	var roleModel = new WorkflowBuilder.Role(WFDefProvider.transform(roleJson));
            	$.when(
            		roleModel.evaluate()
        		).done($.proxy(function(){
        			deferred.resolve(roleModel);
        		}, this));
            }
		});
		return deferred;
	};

	var evaluateRules = function(rules){
		var validityVector = [];
		_.each(rules, function(rule){
			if(Array.isArray(rule)){ //evaluateORdRules
				validityVector.push(evaluateRulesCollection(rule));
			}else{ //stand alone ORed rule
				validityVector.push(rule.isValid());
			}
		}, this);
		//or together the results to get the validity of this rules set
		return _.contains(validityVector, true);
	};

	var evaluateRulesCollection = function(rules){
		var validityVector = [];
		var booleanOperator;
		_.each(rules, function(rule){
			if(!booleanOperator){
				booleanOperator = rule.getBooleanOperator();
			}
			validityVector.push(rule.isValid());
		}, this);
		//either AND or OR together all rules in this set. This shouldn't be undefined but just in case
		if(!booleanOperator || booleanOperator === "OR"){
			return _.contains(validityVector, true);
		}else{
			return !_.contains(validityVector, false);
		}
	};

	WorkflowBuilder.Role = Backbone.Model.extend({
		defaults: {
			'name': '',
			'type': '',
			'top-level-rules': [],
			'user-input-rules': [],
			'user-rules': [],
			'owner': undefined
		},
		populateRules: function(level){
			var self = this;
			var rulesPopulated = $.Deferred();
			var deferreds = [];
			_.each(this.get(level), function(rules){
				if(rules){ //may be empty
					if(!Array.isArray(rules)){
						rules = [rules];
					}
					_.each(rules, function(rule){
						deferreds.push(rule.fetch());
					}, this);
				}
			}, this);
			$.when.apply($, deferreds).done(function(){
				rulesPopulated.resolve(self.get(level));
			});
			return rulesPopulated;
		},	
		evaluate: function(){
			var self = this;
			var deferred = $.Deferred();
			//first evaluate top-level rules - if these fail, the role user is the owner
			var populateTopLevelRules = self.populateRules(TOP_LEVEL_RULES);
			$.when(populateTopLevelRules).done(function(){
				//evaluate top-level-rules
				var evaluateTopLevelRules = evaluateRules(self.get(TOP_LEVEL_RULES));
				//push results of validation onto the model
				self.set('validation', {
					'top-level-rules': evaluateTopLevelRules,
					'user-input-rules': false,
					'user-rules': false
				});
				if(evaluateTopLevelRules){
					$.when(self.populateRules(USER_INPUT_RULES),
						self.populateRules(USER_RULES)).done(function(userInputRules, userRules){
						//rules have now been populated, compute each level of rules
						var validation = self.get('validation');
						validation[USER_INPUT_RULES] = evaluateRules(self.get(USER_INPUT_RULES));
						validation[USER_RULES] = evaluateRules(self.get(USER_RULES));
						self.set('validation', validation);
						deferred.resolve(self);
					});
				}else{
					deferred.resolve(self);
				}
			});
			return deferred;
		}
	});

	WorkflowBuilder.Roles = Backbone.Collection.extend({
		comparator: 'priority',
		initialize: function(options){
			this.pageSetName = options.pageSetName;
		},
		url: function(){
			return app.serviceUrlRoot + '/aw-admin/getRoles?pageSetName=' + this.pageSetName;
		}
	});

	WorkflowBuilder.evaluate = function(psi, role){
		var evaluateRole = $.Deferred();
		//fetch the json content and de-serialize rules
		$.when(getRole(role)).done(function(evaluatedRole){
			evaluateRole.resolve(evaluatedRole);
		});
		return evaluateRole;
	};

	return WorkflowBuilder;
});