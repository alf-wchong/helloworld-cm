define([
	'app',
	'modules/wizard/models/workflow/workflowdefinitionbuilder'

], function(app, WFBuilder){
	var Workflow = {};
	var TOP_LEVEL_RULES = 'top-level-rules';
	var USER_INPUT_RULES = 'user-input-rules';
	var USER_RULES = 'user-rules';

	var Roles = Backbone.Collection.extend({
		comparator: 'priority',
		initialize: function(options){
			this.psdName = options.psdName;
		},
		url: function(){
			return app.serviceUrlRoot + '/aw-admin/getRoles?pageSetName=' + this.psdName;
		}
	});

	Workflow.Collection = Backbone.Collection.extend({
		comparator: 'priority',
		getTopLevelReason: function(tlr){
			if(tlr && tlr.reasons){ //list of reasons OR'd
				return _.uniq(tlr.reasons).join(', ').trim();
			}else{ //object
				return _.pluck(tlr, 'reason').join(' and ').trim();
			}
		},
		getPriorities: function(){
			return this.priorities;
		},
		//prep function for creating the workflow definition
		parseRoles: function(role, level, tlr){
			var roleWrapper = [];
			_.each(role.get(level), function(rules){
				//if no users, fall back to the owner
				if(!Array.isArray(rules)){
					rules = [rules];
				}
				_.each(rules, function(rule){
					if(rule.isValid()){
						var ruleWrapper = {
							//if no reason, fall back to top-level-rule's reason
							'reason': rule.getReason() || this.getTopLevelReason(tlr),
							'users': rule.hasUsers() ? rule.getUsers() : [role.get('owner')],
							'type': rule.getRuleType()
						};
						var users = _.extend([], ruleWrapper.users);
						//ensure that each user has a content and id
						_.each(ruleWrapper.users, function(user, index){
							if(_.isString(user)){
								var userString = user;
								user = _.extend({}, {
									'id': userString,
									'content': userString
								});
							}else if(_.isObject(user) && (!user.id || !user.content)){
								user.id = user.value;
								user.content = user.displayText || user.displayValue;
							}
							users[index] = user;
						}, this);
						ruleWrapper.users = _.extend([], users);
						roleWrapper.push(ruleWrapper);
					}
				}, this);
			}, this);
			//reject all duplicate reasons - map FTW
			var uniqueReasonsFilter = {};
			_.each(roleWrapper, function(ruleWrapper){
				uniqueReasonsFilter[ruleWrapper.reason] = ruleWrapper;
			}, this);
			var uniqueTrippedRules = [];
			_.each(uniqueReasonsFilter, function(rule, reason){
				uniqueTrippedRules.push(rule);
			}, this);
			return uniqueTrippedRules;
		},
		//util function for creating a view of thw workflow summary or seralizing for the server
		parsePriorities: function(){
			var priorities = [];
			this.each(function(priorityBucket){
				var priorityWrapper = {
					'task': priorityBucket.get('task'),
					'priority': priorityBucket.get('priority'),
					'roles':  []
				};
				var topLevelRules, userInputRules, userRules, rules;
				//serialize roles for easy rendering
				//just display user-rules and user-input-rules
				_.each(priorityBucket.get('roles'), function(role){
					topLevelRules = this.parseRoles(role, TOP_LEVEL_RULES);
					userInputRules = this.parseRoles(role, USER_INPUT_RULES, topLevelRules);
					userRules = this.parseRoles(role, USER_RULES);
					//if no user rules or user-input-rules, fall back to TLRs ex. Group-Based WF rules
					rules = userInputRules.concat(userRules);
					if(!rules || rules.length === 0){
						rules = this.createRoleOwnerRule(role, topLevelRules);
					}
					priorityWrapper.roles.push({
						'name': role.get('name'),
						'roleOwner': role.get('owner').content,
						'esigPSI': role.get('esig-psi'),
            			'esigWFDoc': role.get('esig-wf-docs'),
            			'top-level-reason': this.getTopLevelReason(topLevelRules),
            			'type': role.get('type'),
						'rules': rules
					});
				}, this);
				priorities.push(priorityWrapper);
			}, this);
			return priorities;
		},
		createRoleOwnerRule: function(role, topLevelRules){
			return [
				{
					reason: this.getTopLevelReason(topLevelRules),
					type: TOP_LEVEL_RULES,
					users: [
						{
							content: role.get('owner').content,
							id: role.get('owner').id
						}
					]
				}
			];
		},
		//utiliy for building up json for WorkflowSummary view
		serialize: function(){
			this.priorities = this.parsePriorities();
			return this;
		},
		//utility for serializing workflow into a Workflow Definition
		toJSON: function(){
			var wizardWorkflowDefinition = {
				'wizardActivities': [],
				'approvalType': 'blanket'
			};
			//structure for bucketing all tassks with their priority
			var wizardActivitiesByPriority = {};
			_.each(this.parsePriorities(), function(priorityBucket){
				var priority = priorityBucket.priority;
				_.each(priorityBucket.roles, function(role){
					//each activity contains all roles with the same priority - 
					//check if one exists already and add to it
					if(!wizardActivitiesByPriority[priority]){
						wizardActivitiesByPriority[priority] = _.extend({}, {
							'name': role.name,
      						'wizardRoles': []
						});
					}
					var activityWrapper = wizardActivitiesByPriority[priority];
					//Delete top-level-reason from workflow definition
					//just used for display purposes
					delete role['top-level-reason'];
					_.each(role.rules, function(rule){
						var ruleWrapper = _.extend({}, {
							'priority': priority
						}, _.omit(role, 'rules'));
						//get users' ids
						var ruleTripped =  false;
						ruleWrapper.assignees = _.pluck(rule.users, 'id');
						if(rule.type === TOP_LEVEL_RULES){
							ruleTripped = true;
							if(!ruleWrapper.topLevelReason){
								ruleWrapper.topLevelReason = [];
							}
							ruleWrapper.topLevelReason.push(rule.reason);
						}else if(rule.type === USER_RULES || rule.type === USER_INPUT_RULES){
							ruleTripped = true;
							if(!ruleWrapper.userLevelReason){
								ruleWrapper.userLevelReason = {};
							}
							//create user (id) key with the value being the reason
							_.each(rule.users, function(user){
								var key = user.content + ' (' + user.id + ')';
								ruleWrapper.userLevelReason[key] = [rule.reason];
							}, this);
						}
						//only add a wrapper if a rule was tripped
						if(ruleTripped){
							//each of these roles will be completed in parallel
							activityWrapper.wizardRoles.push(ruleWrapper);
						}
					}, this);
				}, this);
			}, this);
			//build the activities list in order of priority - all roles under a task are completed in parallel, all dicrete taska are completed in serial
			if(_.keys(wizardActivitiesByPriority)){
				//sort wizardActivities by priority
				_.each(_.keys(wizardActivitiesByPriority), function(priority){
					wizardWorkflowDefinition.wizardActivities.push(wizardActivitiesByPriority[priority]);
				}, this);
				return wizardWorkflowDefinition;
			}else{
				app.log.error(window.localize("modules.wizard.models.workflow.workflow.noWizard"));
				return undefined;
			}
		}
	});

	Workflow.build = function(options){
		var context = _.extend(this, options);
		var deferred = $.Deferred();
		var fetchRoles = new Roles({
			'psdName': options.psdName
		});
		var resolvedRoles = [];
		$.when(fetchRoles.fetch()).done($.proxy(function(){
			//fetch and process each role
			fetchRoles.each(function(role){
				resolvedRoles.push(WFBuilder.evaluate(options.psi, role));
			}, context);
			//return validated and marshaled roles and pass up the deferred chain
			$.when.apply($, resolvedRoles).done(function(){
				var priorities = [];
				var tasksCounter = 1;
				//unpack results into an array for backbone-ification
				//we'll want to return a list of the roles groupded by their priority -all 1s together, all 2s together
				//Workflow will be a backbone collection of priorities
				_.each(arguments, function(role, index){
					//only show valid roles
					if(role.get('validation')[TOP_LEVEL_RULES] === true){
						var priority = role.get('priority');
						var priorityBucket = _.findWhere(priorities, {'priority': priority});
						if(!priorityBucket){
							priorities.push({
								'priority': priority,
								'task': 'Priority ' + tasksCounter++ + ' Tasks',
								'roles': []
							});
							//get pointer to bucket
							priorityBucket = _.findWhere(priorities, {'priority': priority});
						}
						//strip priority flag so we don't have to worry about it - buckets now have priority
						role.unset('priority', {silent: true});
						priorityBucket.roles.push(role);
					}
				}, this);
				if(priorities && priorities.length > 0){
					deferred.resolve(new Workflow.Collection(priorities).serialize());
				}else{
					deferred.resolve(undefined);
				}
			});
		}, this));
		return deferred;
	};

	return Workflow;
});