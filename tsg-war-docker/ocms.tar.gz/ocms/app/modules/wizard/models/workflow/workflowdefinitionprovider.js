define([
	'app',
	'modules/wizard/models/workflow/workflowrule'
], function(app, WFRule){
	//constants
	var TOP_LEVEL_RULES = 'top-level-rules';
	var USER_INPUT_RULES = 'user-input-rules';
	var USER_RULES = 'user-rules';

	var WorkFlowDefinitionProvider = {};

	var initRule = function(attributes, users, type){
		var config = _.extend({}, attributes);
		config.ruleType = type;
		if(config['input-type']){
			//set type to lowercase to avoid any String vs string issues
			config['input-type'] = config['input-type'].toLowerCase();
		}
		if(config['page-id'] && config['input-id']){
			//build up address for retreiving a question by address
			config.address = config['page-id'] + '_' + config['input-id'];
			config.users = users;
		}
		return new WFRule(config);
	};

	var createRules = function(role, ruleType){
		var updatedRules = [];
		_.each(role.rules, function(ruleWrapper){
			//parse out users
			var users = [];
			if(ruleWrapper && ruleWrapper.users && ruleWrapper.users.user){
				users = ruleWrapper.users.user;
				if(!Array.isArray(ruleWrapper.users.user)){
					users = [ruleWrapper.users.user];
				}
			}
			//base rules attributes
			var ruleAttributes = {};

			//flag for wither to AND or OR togehter this rule set
			var LOGICAL_OPERATOR = 'OR';
			//special case for user-input rules <-- different layout from user-rule and top-level-rule
			if(ruleWrapper && ruleWrapper.rule && ruleWrapper.rule.input){
				//normalize the attributes
				ruleAttributes.input = {
					'input-id': ruleWrapper.rule.input.id,
					'page-id': ruleWrapper.rule.page.id,
					'input-type': ruleWrapper.rule.type,
					'input-short-label': ruleWrapper.rule.input['input-short-label']
				};
			//what does this one catch?
			}else if(ruleWrapper && ruleWrapper.rules && ruleWrapper.rules.rule && ruleWrapper.rules.rule.rule){
				LOGICAL_OPERATOR = 'AND';
				ruleAttributes = ruleWrapper.rules.rule.rule;
			//AND together these rules
			}else if(ruleWrapper && ruleWrapper.rule && ruleWrapper.rule.rule){
				LOGICAL_OPERATOR = 'AND';
				ruleAttributes = ruleWrapper.rule.rule;
			//OR these rules
			}else if(ruleWrapper && ruleWrapper.rule){
				LOGICAL_OPERATOR = 'OR';
				ruleAttributes = ruleWrapper.rule;
			}
			//^CLEAN THIS UP!!
			//ruleAttributes may be an array
			if(_.isArray(ruleAttributes)){
				var associatedRules = [];
				_.each(ruleAttributes, function(ruleContainer){
					//last case is a a sub array of conditions that should bew ANDed together
					var attributes = ruleContainer.input || ruleContainer.rule.input || ruleContainer.rule;
					if(_.isArray(attributes)){
						//sub routines are ANDed together
						attributes.operator = 'AND';
						_.each(attributes, function(rule){
							associatedRules.push(initRule(rule.input, users, ruleType));
						}, this);
					}else{
						attributes.operator = LOGICAL_OPERATOR;
						associatedRules.push(initRule(attributes, users, ruleType));
					}
				}, this);
				updatedRules.push(associatedRules);
			}else if(ruleAttributes){
				var attributes = ruleAttributes.input;
				if(attributes){
					attributes.operator = LOGICAL_OPERATOR;
				}
				updatedRules.push(initRule(attributes, users, ruleType));
			}
		}, this);
		return updatedRules;
	};
	//cleaning up json from the AW Admin here
	WorkFlowDefinitionProvider.transform = function(rawJson){
		var result = rawJson;
		if(!Array.isArray(result[TOP_LEVEL_RULES].rules)){
			result[TOP_LEVEL_RULES].rules = [result[TOP_LEVEL_RULES].rules];
		}
		//top level rules don't have associated users
		if(!Array.isArray(result[USER_INPUT_RULES].rules)){
			result[USER_INPUT_RULES].rules = [result[USER_INPUT_RULES].rules];
		}

		result[USER_RULES].rules = result[USER_RULES]['user-rule'];
		//remove user-rulw wrapper and make rules like all the others
		delete result[USER_RULES]['user-rule'];
		if(!Array.isArray(result[USER_RULES].rules)){
			result[USER_RULES].rules = [result[USER_RULES].rules];
		}

		//set up rule models for each rule classification
		result[TOP_LEVEL_RULES] = createRules(result[TOP_LEVEL_RULES], TOP_LEVEL_RULES);
		result[USER_INPUT_RULES] = createRules(result[USER_INPUT_RULES], USER_INPUT_RULES);
		result[USER_RULES] = createRules(result[USER_RULES], USER_RULES);
		return result;
	};

	return WorkFlowDefinitionProvider;
});
