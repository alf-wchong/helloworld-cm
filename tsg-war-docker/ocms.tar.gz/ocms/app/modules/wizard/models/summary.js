/**
 * Created by dlafeir on 9/22/2014.
 */
define([
    'app',
    'modules/wizard/controltypes/imagepreview'
], function(app, ImagePreview){

    var SimpleQuesionModel = Backbone.Model.extend({
        defaults : {
            question : null,
            answer : null,
            questionGroup : null
        }
    });

    var SimplePageModel = Backbone.Model.extend({
        defaults : {
            pageName : "",
            questionAndAnswer : [],
            validPage : false,
            pageId: null
        }
    });

    var parseMultiSelectQuestion = function(question, hasJustification){
        var answers = _.pluck(question.get('field').get('value'), 'displayValue');
        if(hasJustification){
            var answersValuesMapForJustifications = _.pluck(question.get('field').get('value'), 'value');
            _.each(answersValuesMapForJustifications, function(value, index){
                if(question.get('field').get('justifications')[value]){
                    answers[index] += " (" + question.get('field').get('justifications')[value] + ")";
                }
            });
        }
        return answers.join(', ');
    };

    var parseFileUploadQuestion = function(question){
        var answers = [];
        _.each(question.get('field').get('value'), function(file){
            //IE doesn't support the file api
            var fileName = file.name || JSON.parse(file.formData.action).parameters.properties['prop-objectName'];
            // if this file is an image, push its view to answers instead of the filename
            if(file.loaded && file.name && ImagePreview.isImage(file.name) &&  window.FileReader !== undefined){
                var viewHTML = ImagePreview.getPreviewHTML(file);
                answers.push(viewHTML);
            }else{
                answers.push(fileName);
            }
        });

        return answers.join('<br />');
    };

    var parseQuestionIntoSimpleQuestionModel = function(question){
        var answers = "";
        var hasJustificationWithAnswer = false;
        if(question.get('field').get('justifications')){
            hasJustificationWithAnswer = true;
        }

        //decide which type it is
        if (_.isArray(question.get('field').get('value'))) {
            answers = [];
            if (question.get('field').get('type') === 'file') {
                answers = parseFileUploadQuestion(question);
            }
            else if (question.get('field').get('type') === 'multiselect') {
                answers = parseMultiSelectQuestion(question, hasJustificationWithAnswer);
            }else{
                if(question.get('field').has('displayValue')){
                    answers = question.get('field').get('displayValue');
                }else{
                    answers = question.get('field').get('value');
                }
                //check if value is an object (from a select typeahead control)
                var questionAnswers = _.extend([], answers);
                var answerSummaries = []; //array containing each answer and any justiifcations
                _.each(questionAnswers, function(answer, index){
                    var answerSummary;
                    if(_.isString(answer)){
                        answerSummary = answer;
                    }else if(_.isObject(answer) && answer instanceof Backbone.Model){
                        answerSummary = answer.get('displayValue');
                    }
                    //process justifications 
                    if(hasJustificationWithAnswer){
                        var answerValue;
                        if(_.isArray(question.get('field').get('value'))){
                            answerValue = question.get('field').get('value')[index];
                        }
                        answerValue = _.isObject(answerValue) ? answerValue.value : answerValue;
                        if(question.get('field').get('justifications')[answerValue]){
                            var justification = " (" + question.get('field').get('justifications')[answerValue] + ")";
                            //add to this answer summary
                            answerSummary = answerSummary.concat(justification);
                        }
                    }
                    answerSummaries.push(answerSummary);
                }, this);
                answers = answerSummaries.join(', ');
            }
        }
        else {
            var answer = question.get('field').get('value');
            //get justifications
            if(_.isObject(answer)){
                answer = answer.value;
            }
            var option;
            if(question.get('field').has('displayValue')){
                option = question.get('field').get('displayValue');
            } else {
                option = question.get('field').get('value');
            }
            
            //check if value is an object (from a select typeahead control)
            if(_.isObject(option)){
                //show the displayValue
                answers = option.displayValue;
            }else{
                answers = option;
            }
            
            if(hasJustificationWithAnswer && question.get('field').get('justifications')[answer]){
                answers += " (" + question.get('field').get('justifications')[answer] + ")";
            }
        }

        return new SimpleQuesionModel(
            { question: question.get('label'), answer: answers, isHidden: !question.get('field').isVisible() }
        );
    };

    var Summary = Backbone.Collection.extend({});

    /**
     * Invoke with a Summary and the current flowpath
     * @return new Summary Collection
     */
    var SummaryBuilder = function(flowpath, onlyShowErrors) {
        var pages = [];
        flowpath.each(function(page) {
            var questionAndAnswerToAdd = [];
            var questionGroupToAdd = [];
            var questionGroupsOnPage = page.get('questions').questionGroups;
            page.get('questions').each(function(question){
                if(questionGroupsOnPage[0].length !== 0 && question.get('hideInPdf') !== true && question.get('grouped')){
                    questionGroupToAdd.push(parseQuestionIntoSimpleQuestionModel(question));
                }
                else if(question.get('hideInPdf') !== true) {
                    questionAndAnswerToAdd.push(parseQuestionIntoSimpleQuestionModel(question));
                }
            });
            var orderedQuestionAndAnswerToAdd = [];
            if(questionGroupToAdd.length !== 0){
                //insert the group question in the order of the questions
                //find the index of the first grouped question
                var firstGroupQuestionIndex = null;
                page.get('questions').each(function(question, index){
                   if(firstGroupQuestionIndex === null && question.get('grouped')){
                       firstGroupQuestionIndex = index;
                   }
                });

                orderedQuestionAndAnswerToAdd = questionAndAnswerToAdd.slice(0,firstGroupQuestionIndex);
                orderedQuestionAndAnswerToAdd.push(new SimpleQuesionModel(
                    { questionGroup: questionGroupToAdd }
                ));
                orderedQuestionAndAnswerToAdd = orderedQuestionAndAnswerToAdd.concat(questionAndAnswerToAdd.slice(firstGroupQuestionIndex, questionAndAnswerToAdd.length));
            }
            else {
                orderedQuestionAndAnswerToAdd = questionAndAnswerToAdd;
            }

            //validate this page
            page.validateCollection();
            
            if (!onlyShowErrors || !page.isValid()){
                var pageToAdd = new SimplePageModel({
                    pageName : page.get('title'),
                    questionAndAnswer : orderedQuestionAndAnswerToAdd,
                    validPage : page.get('valid') ? false : true,
                    pageId : page.id
                });
                // need to have the check here to see if onlyShowErrors is turned on b/c there could be the case where
                // only the errors are being shown in the summary, but the page that has an error also has hideInPdf turned on
                // so the user would be stuck on summary with nothing showing
                if(page.get('hideInPdf') !== true || !page.isValid()) {
                    pages.push(pageToAdd);
                }
            }
        });
        return new Summary(pages);
    };

    return {
        Builder : SummaryBuilder,
        Collection : Summary
    };
});