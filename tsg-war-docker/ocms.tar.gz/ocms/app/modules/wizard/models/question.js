define([
	'app',
	'modules/wizard/models/field',
	'modules/wizard/models/rulecollection',
	'modules/wizard/services/ruleservice',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/events/psieventmanager'
], function(app, Field, Rules, RuleService, QuestionEventManager, PSIEventManager){
	var Question = Backbone.Model.extend({
		idAttribute: '_id',
		initialize: function(config, options){
			this.options = _.extend({}, options);

			this.psiId = this.options ? this.options.psiId : undefined;
			this.page_id = this.options ? this.options.page_id : undefined;

			this.set({
				'field': new Field(this.get('field'), options),
				'rules': new Rules(this.get('rules'), options)
			});

			//is this question part of a group?
			if(options && options.grouped){
				this.set({'grouped': options.grouped});
			}

			//listen for all models to be built
			this.listenTo(PSIEventManager, 'build', function(){
				this.build();
			}, this);

			this.listenTo(this.get('field'), 'field:valid field:invalid', function(message){
				QuestionEventManager.trigger('change:field:validity', this, message);
			}, this);

			this.listenTo(this.get('field'), 'change:options', function(options){
				QuestionEventManager.trigger('change:field:options', this, options);
			}, this);

			this.listenTo(QuestionEventManager, 'change:question:value', this.populate, this);
		},
		build: function(){
			this.processRules();
		},
		getAddress : function(){
			return this.page_id + '_' + this.id;
		},
		getPage: function(){
			return this.page_id;
		},
		processRules: function(){
			var self = this;
			//loop through rules and apply methods
			RuleService.processRules(self);
		},
		validate: function(){
			//bubble up field-level validation
			return this.get('field').validate();
		},
		populate: function(label, value){
			//remove any spaces and toLowerCase
			var questionLabel = this.get('label').toLowerCase().replace(/ /g, '');
			if(questionLabel === label.toLowerCase().replace(/ /g, '')){
				switch(this.get('field').getType()){
					case 'textbox':
						this.get('field').set('value', value);
						this.get('field').set('displayValue', value);
						break;
					case 'email':
						this.get('field').set('value', value);
						this.get('field').set('displayValue', value);
						break;
					case 'select':
						this.get('field').set('value', value);
						this.get('field').set('displayValue', value);
						break;
					case 'date':
						//if we have a date, we need to format it back to hpi style - dateTimeFormat.dateFormat
						var formattedTZDate = moment(value).format(this.get('field').get('momentFormat'));
						this.get('field').set('value', formattedTZDate);
						this.get('field').set('displayValue', formattedTZDate);
						break;
					default:
						this.get('field').set('value', value);
						break;
				}
			}
		},
        toJSON: function(){
        	var json = Backbone.Model.prototype.toJSON.call(this);
        	return _.omit(json, ['options', 'psiId']);
        }
	});

	return Question;
});
