define([
	'app',
	'modules/wizard/models/pagesetinstance',
	'modules/wizard/views/pagesetinstanceview',
	'modules/wizard/views/flowpathview',
	'modules/wizard/views/navigationcontrolsview',
    'modules/wizard/views/psiheaderview',
	'modules/wizard/events/psieventmanager'
], function(app, PageSetInstance, PageSetInstanceView, FlowPathView, NavControls, PsiHeaderView, PSIEventManager){
	var ActiveForm = app.module();

	ActiveForm.Views.Layout = Backbone.Layout.extend({
		template: 'wizard/wizard',
		events: {
			'click #wizard-form-save-and-exit-btn' : 'saveAndExit',
			'click #wizard-form-cancel-and-exit-btn' : 'cancelAndExit'
		},
		initialize: function(options){
			if(options){
				this.ui = {};
				this.user = options.user;
				this.psi = options.psi;
				this.activePageIndex = options.activePageIndex ? options.activePageIndex : 0;
			}
            this.psi = this.psi instanceof PageSetInstance ? this.psi : new PageSetInstance(this.psi);

			this.wizardPsi = new PageSetInstanceView({
				model: this.psi,
				activePageIndex: this.activePageIndex
			});

			this.wizardPsiHeader = new PsiHeaderView({
				psi: this.psi,
			    flowpath: this.psi.get('flowpath'),
			    psdName: this.psi.get('psdName')
			});

			//update the current page from flowpath
			this.listenTo(app, 'activeform:flowpath:change', function(pageIndex){
				var frag = Backbone.history.fragment.split('/');
				Backbone.history.navigate(frag[0] + '/' + frag[1] + '/' + frag[2] + '/' + pageIndex, {trigger: true});
				// recenter user to top of page
				window.scrollTo(0,0);
			}, this);

			this.flowpath = new FlowPathView({
				psi: this.psi,
				flowpath: this.psi.get('flowpath')
			});

			this.controls = new NavControls({
				psi: this.psi,
				activePageIndex: this.activePageIndex
			});

			//notify the page set instance that its being loaded with this page
			PSIEventManager.trigger('change:page:loaded', this.activePageIndex, this.psi.cid);
        },
        renderSubviews: function(pageIndex) {
			this.wizardPsiHeader.renderActivePageHeader(pageIndex);
			this.wizardPsi.renderActivePage(pageIndex);
			//validate this page
			if(pageIndex){
				this.wizardPsi.validatePage(pageIndex);
			}
        },
        beforeRender: function(){
            this.setViews({
                '.wizard-psi': this.wizardPsi,
                '.psi-header': this.wizardPsiHeader,
                '.wizard-flowpath': this.flowpath,
                '.psi-controls': this.controls
            });
            this.renderSubviews(this.activePageIndex);
		},
		afterRender: function() {
			this.rendered = true;
		},
		saveAndExit: _.debounce(function() {
			var confirmed = window.confirm(window.localize("modules.wizard.activeForm.areYouSure"));

			if(confirmed) {
				// perform our save and exit action.
				app.log.debug(window.localize("modules.wizard.activeForm.saveAndExit"));
				app.routers.activeform.saveAndExit(this.psi);
			}
		},500,true),
		cancelAndExit: _.debounce(function() {
			var confirmed = window.confirm(window.localize("modules.wizard.activeForm.areYouSureYouWant"));

			if(confirmed) {
				// perform our save and exit action.
				app.log.debug(window.localize("modules.wizard.activeForm.exitAndCancel"));
				app.routers.activeform.exitForm(this.psi);
			}
		},500,true),
		serialize: function(){
			return {
				psi: this.psi.attributes,
				streamline: app.wizardContext.get('streamline')
			};
		}
	});

	return ActiveForm;
});
