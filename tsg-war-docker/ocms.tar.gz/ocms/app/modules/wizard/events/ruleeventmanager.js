define([
	'app',
	'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager){

	var RuleEventManager = _.extend({}, BaseEventManager, {
		name:'Wizard Rule',
		listenToEvents: function(){
			this.stopListening();
			this.listenTo(this, 'setup:placeholders', function(question, rule, action){
				this.trigger('setup:placeholders:' + question.getAddress(), question, rule, action);
			});

			this.listenTo(this, 'change:placeholders:validity', function(question, rule, action, placeholders, isValid, message){
				this.trigger('change:placeholders:validity:' + question.getAddress(), question, rule, action, placeholders, isValid, message);
			}, this);

			this.listenTo(this, 'change:placeholders:none', function(question, rule, action, placeholders){
				this.trigger('change:placeholders:none:' + question.getAddress(), question, rule, action, placeholders, true);
			}, this);

			this.listenTo(this, 'remove:question', function(address){
				this.trigger('remove:question:' + address, address);
			});
		}
	});

	RuleEventManager.listenToEvents();

 	return RuleEventManager;
});
