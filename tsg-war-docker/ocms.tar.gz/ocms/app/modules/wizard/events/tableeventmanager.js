define([
	'app',
	'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager){

	var TableEventManager = _.extend({}, BaseEventManager, {
        name: 'TableEventManager'
    });
    
    return TableEventManager;
});