define([
	'app',
	'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager){
	var FieldEventManger = _.extend({}, BaseEventManager, {
		name: 'Field', //namespace for logging purposes
		listenToEvents: function(){
			this.stopListening();
		}
	});
 
    return FieldEventManger;
});