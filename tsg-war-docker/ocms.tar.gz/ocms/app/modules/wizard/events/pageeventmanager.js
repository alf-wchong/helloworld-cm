define([
    'app',
    'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager) {
    var PageEventManager = _.extend({}, BaseEventManager, {
        name: 'Page',
        listenToEvents: function() {
            this.stopListening();

            //update the current page from flowpath
            this.listenTo(this, 'activeform:flowpath:intendToChange', function(currentpageIndex, intendedPageIndex, options) {

                app.context.configService.getWizardConfig(function(config) {
                    //Search for the config corresponding to our form
                    var wizardFormConfig = _.find(config.get("wizardForms").models, function(form) {
                        return form.get("formName") === options.psi.get("name");
                    });

                    //If we aren't letting the user navigate away from invalid pages, we need to check if the page is valid
                    if (wizardFormConfig && !wizardFormConfig.get("navigationAwayFromInvalidPages")) {
                        //if the current page is not valid
                        if (!options.psi.get('flowpath').models[currentpageIndex].get("valid")) {
                            PageEventManager.trigger('showInvalidPageMessage');
                            return;
                        }
                    }

                    app.trigger('activeform:flowpath:change', intendedPageIndex);
                });

            }, this);
        }
    });

    PageEventManager.listenToEvents();

    return PageEventManager;
});