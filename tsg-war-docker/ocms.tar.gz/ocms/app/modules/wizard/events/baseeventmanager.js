define([
	'app',
	'module'
], function(app, module){

	var logEvents = module && module.config() && module.config().logging ? module.config().logging : false;

	//base model for all other event managers
	var BaseEventManager = _.extend({}, Backbone.Events, {
		'name': 'Wizard Event', //namespace for logging purposes
		'logEvents': logEvents,
		initialize: function(config, options){
			this.config = config || {};
			this.listenToEvents();
		},
		//proc listen to on events this manager is responisble for
		listenToEvents: function(){
			this.stopListening();
			app.log.error(window.localize("modules.wizard.events.baseEventManager.listenToEvent"));
		},
		//call this.stopListening along with any custom cleanup required
		stopListeningToEvents: function(){
			this.stopListening();
		},
		//careful of order here, make sure any overrides of Backbone.Events come after it in the _.extend() precedence
		trigger: function(){
			//configurable logging of events
			if(this.logEvents){
				try{
					app.log.info('Wizard Event - ' + this.name, JSON.stringify(arguments, null, 2));
				}catch(exception){
					app.log.info('Wizard Event', arguments);
				}
			}
        	Backbone.Model.prototype.trigger.apply(this, arguments);
   		}
	});

	return BaseEventManager;
});