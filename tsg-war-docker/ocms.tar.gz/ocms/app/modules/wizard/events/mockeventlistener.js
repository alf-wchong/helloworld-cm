define([
	'app',
	'modules/wizard/events/wizardeventmanager'
], function(app, WizardEventManager){
	
	var MockEventListener = Backbone.Model.extend({
		initialize: function(){
			this.listenTo(WizardEventManager, 'test', function(){
				this.set('heardEvent', true);
			}, this);
		},
		getEventManager: function(){
			return WizardEventManager;
		}
	});

	return MockEventListener;
});