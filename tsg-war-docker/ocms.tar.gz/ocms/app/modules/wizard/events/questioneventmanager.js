define([
	'app',
	'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager){
	var QuestionEventManager = _.extend({}, BaseEventManager, {
		name: 'Question', //namespace for logging purposes
		listenToEvents: function(){
			this.stopListening();

			//listen for field to change - call validate
			this.listenTo(this, 'change:field:validity', function(model, message){
                //broadcast to any one listening on the Question channel
           		this.trigger('change:question:validity', model.getAddress(), model, message);
				this.trigger('change:question:validity:' + model.getAddress(), model, message);
				if(!message) {
					//then this is a valid result, and we can broadcast an addressed change value event
					this.trigger('change:question:value:' + model.getAddress(), model);
				}
            }, this);

            this.listenTo(this, 'change:field:options', function(question, options){
            	this.trigger('change:field:options:' + question.getAddress(), options);
            }, this);

			//used to pass blur and ui events down to the field
            this.listenTo(this, 'control:blur', function(question){
            	//fire a signed event for anyone listening to this question to change - format and validation services
            	this.trigger('control:blur:' + question.getAddress(), question);
            	//notify this question's field of any ux changes - for ex. user blurred
            	question.get('field').trigger('control:blur', question.get('field'));
            }, this);
		}
	});


	//start listening for events
	QuestionEventManager.listenToEvents();

	return QuestionEventManager;
});