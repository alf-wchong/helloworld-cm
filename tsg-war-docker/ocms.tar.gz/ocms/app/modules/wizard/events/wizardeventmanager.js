define([
	'app',
	'modules/wizard/events/baseeventmanager'
], function(app, BaseEventManager){
	var WizardEventManager = _.extend({}, BaseEventManager, {
		name: 'Wizard',
		listenToEvents: function(){}
	});
 
    return WizardEventManager;
});