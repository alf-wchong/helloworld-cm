define([
	'app',
	'modules/wizard/events/baseeventmanager'

], function(app, BaseEventManager){

	var PSIEventManager = _.extend({}, BaseEventManager, {
		name: 'PSI',
		listenToEvents: function(){
			this.stopListening();
			this.listenTo(this, 'change:page:loaded', function(pageIndex, cid){
				//rebroadcast the page change event to the listening PSI
				this.trigger('change:page:loaded:' + cid, pageIndex);
			}, this);
			//Once our submit fininshes, begin the approval process
			this.listenTo(app, "psi:submit:finished", function(psdName, objectId, actionId, streamline){
				window.ExitService.deregister("activeform.exit"); //Remove popups on page leave
				var url;
				var encodedObjectId = window.encodeURIComponent(objectId); 
				//Determine our route based upon whether we are in streamline mode or not
				if (streamline) {
					url = window.location.protocol + '//' + window.location.host + app.root + 'activeform/' + psdName + '/actionHandler/' + encodedObjectId + '/' + actionId + "/" + true;
				}
				else {
					url = window.location.protocol + '//' + window.location.host + app.root + 'activeform/' + psdName + '/actionHandler/' + encodedObjectId + '/' + actionId + "/" + false;
                }
           		window.location = url;
            });
            //Once our approve finishes, direct to the confirmation page or stage
            this.listenTo(app, "psi:action:finished", function(psdName, objectId, streamline){
            	window.ExitService.deregister("activeform.exit");//Remove popups on page leave
				var url;
				var encodedObjectId = window.encodeURIComponent(objectId); 
				//If we are in streamline mode go to the confirmation page, otherwise go straight to stage
				if (streamline) {
					url = window.location.protocol + '//' + window.location.host + app.root + 'activeform/streamline/' + psdName + '/confirmation/' + encodedObjectId;
					window.location = url;
				}
				else {
					Backbone.history.navigate("#StageSimple/" + encodedObjectId,{trigger:true});
                }
           		
            });
            //If the user clicks the relaunch button, launch a new form
            this.listenTo(app, "psi:relaunch", function(psdName){
            	window.ExitService.deregister("activeform.exit"); //Remove popups on page leave
				var url = window.location.protocol + '//' + window.location.host + app.root + 'activeform/' + psdName + '/streamline/new';
           		window.location = url;
            });
            //If the user clicks the view form button, launch the form in stage
            this.listenTo(app, "psi:viewForm", function(objectId){
            	var encodedObjectId = window.encodeURIComponent(objectId); 
            	window.ExitService.deregister("activeform.exit"); //Remove popups on page leave
				Backbone.history.navigate("#StageSimple/" + encodedObjectId,{trigger:true});
            });
            //If the form is not configured for streamline mode, direct the user to begin creating a form in non-streamline mode
            this.listenTo(app, "psi:notStreamline", function (psdName) {
            	window.ExitService.deregister("activeform.exit"); //Remove popups on page leave
				var url = window.location.protocol + '//' + window.location.host + app.root + 'activeform/' + psdName + '/new';
           		window.location = url;
            });
		}
	});

 	//start listening for events
	PSIEventManager.listenToEvents();

 	return PSIEventManager;
});
