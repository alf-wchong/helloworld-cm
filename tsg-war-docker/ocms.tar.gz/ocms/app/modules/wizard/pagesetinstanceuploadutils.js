define([
	'app',
	'module',
	'modules/common/action',
	'moment',
	'modules/common/spinner'
], function(app, module, Action, Moment, HPISpinner){
	
	//configre sending hard-coded email addresses in wizard forms
	var sendEmail = module.config() ? module.config().sendEmail : false;
	var fromAddress = module.config() ? (module.config().fromAddress || 'noreply@tsgrp.com') : 'noreply@tsgrp.com';

	var hasDragAndDropSupport = 'draggable' in document.createElement('span');

	var vent = _.extend({}, Backbone.Events);

	var uploadSupportingDocument = function(parentId, index, file){
		var deferred = $.Deferred();
		var fd = new FormData();
		var xhr = new XMLHttpRequest();

		// keep track of progress, written to console for now
		xhr.upload.addEventListener("progress", function(e) {
			if (e.lengthComputable) {
				var percentage = Math.round((e.loaded * 100) / e.total);
				file.percentage = percentage;
				vent.trigger('update');
			}
		}, false);

		xhr.upload.addEventListener("load", function(){
		}, false);
		
		xhr.open("POST", app.serviceUrlRoot + '/action/executeWithAttachment');
		xhr.onreadystatechange = function() {
			// doc is finished upload, get response
			if(xhr.readyState === 4) {
				if(xhr.status > 300){
					//error
					deferred.resolve({
						'index': index,
						'status': 'error',
						'name': file.name
					});
				}else{
					deferred.resolve({
						'index': index,
						'objectId': JSON.parse(xhr.response).result,
						'status': 'ok',
						'name': file.name
					});
				}
				
			}
		};
		//build action
		var uploadSupportingDocAction = new Backbone.Model({
			name: 'bulkUpload',
			parameters: {
				objectId: parentId,
				objectType: 'Attached Document',
				properties: {
					 "prop-objectName": file.name
				},
				hideFileExtensions: "true"
			}
		});

		file.formData = {
			'action': JSON.stringify(uploadSupportingDocAction)
		};
		//add file
		fd.append('parts', file, file.name);
		// add the action parameters we built up
		fd.append('action', file.formData.action);

		// send our request
		xhr.send(fd);

		return deferred.promise();
	};

	var PSIUtil = {
		//options to clean from each field before submission - 
		//don't remove options as those are static and not regenerated
		blacklistOptions: ['queriedOptions', 'cachedOptions', 'datasource'],
		specificQuestionBlacklistAttrs: [{ questionType: 'populator', attr: 'options'}]
	};

		
	PSIUtil.FinishAndSubmit = Backbone.Layout.extend({
		sendNotificationEmails: sendEmail,
		fromAddress: fromAddress,
		initialize: function(config){
			this.psi = config.psi;
			this.workflow = config.workflow;
			this.ui = {};
			this.action = new Action.Model({});
			if (config.formId) {
				this.formId = config.formId;
			}
			else {
				this.formId = null;
			}
			//disable grey out
			var globVal = $.ajaxSetup().global;
			$.ajaxSetup({
			  global: false
			});
			this.submit();
			//restore prev val
			$.ajaxSetup({
				global: globVal
			});
		},
		submit: function(){
			var self = this;
			self.files = [];
			//clean up any queried options
			this.cleanupQueriedOptions();
			//find any supporting docs
            /* jshint ignore:start */
            this.psi.get('pages').each(function(page){
				page.get('questions').each(function(question){
					if(question.get('field').getValues){
						_.each(question.get('field').getValues(), function(answer){
							if(answer.file){
								self.files.push(answer);
							}
						}, this);
					}
				}, this);
			}, this);
            /* jshint ignore:end */

			//documents not already uploaded
			if(!this.psi.has('psiFolderId')){
				//create psi folder
				var createPSIFolder = $.Deferred();
				app.trigger('psi:createfolder', this.psi, createPSIFolder);
				createPSIFolder.done(function(parentId){
					self.parentId = parentId;
					self.findAndUploadSupportingDocuments(self.parentId, self.files).done($.proxy(self.processSupportingDocs, self));
				});
			}else{
				self.parentId = this.psi.get('psiFolderId');
				self.findAndUploadSupportingDocuments(self.parentId, self.files).done($.proxy(self.processSupportingDocs, self));
			}
		},
		findAndUploadSupportingDocuments: function(parentId, files){
			var deferreds = [];
			var docsUploadedDeferred = $.Deferred();
			if(hasDragAndDropSupport){
				_.each(files, function(file, index){
					var deferred;
					if(!file.id) {
						deferred = uploadSupportingDocument(parentId, index, file);
						deferreds.push(deferred);
					}else{
						//file already uploaded, pass along the metadata
						deferred = $.Deferred();
						deferreds.push(deferred);
						deferred.resolve(_.extend({}, file, {
							//tack on the objectId
							'objectId': file.id,
							//and the index to spoof a file upload - its already in the repo
							'index': index
						}));
					}

				}, this);
				//done uploading supporting docs, upload page set instance
				$.when.apply($, deferreds).then(function(){	
					docsUploadedDeferred.resolve(arguments);
				});
			}
			else {
				var fileArray = [];
				_.each(files, function(file, index){
					var formattedFile = {
						'index': index,
						'objectId': file.id,
						'status': 'ok',
						'name': file.name
					};
					fileArray.push(formattedFile);
				});
				docsUploadedDeferred.resolve(fileArray);
			}
			
			return docsUploadedDeferred.promise();
		},
		processSupportingDocs: function(docs){
			//upload psi to its folder
			var self = this;
			var supportingDocIds = [];
			var supportingDocsError = false;
			_.each(docs, function(doc){
				if(doc.status === 'error'){
					supportingDocsError = true;
				}else{
					if(hasDragAndDropSupport){
						self.files[doc.index].id = doc.objectId;
						self.files[doc.index].name = doc.name;
						self.files[doc.index].alreadyAssoc = true;
						supportingDocIds.push(doc.objectId);
					}
					else{
						if(!self.files[doc.index].alreadyAssoc){
							self.files[doc.index].alreadyAssoc = true;
							self.files[doc.index].name = doc.name;
							supportingDocIds.push(doc.objectId);
						}
					}
				}
			}, this);

			if(supportingDocsError){
				//upload failed, destroy the psi folder and rollback
				app.log.error(window.localize("modules.wizard.pageSetInstanceUploadUtils.supportingDocs"));
				self.rollbackUpload();
				return;
			}
			self.uploadPageSetInstance(supportingDocIds).done($.proxy(function(){
			}, self));		
		},
		uploadPageSetInstance: function(supportingDocIds){
			var self = this;
			var deferred = $.Deferred();
			
			//adding a context object to the PSI
			if(!this.psi.has('context')){
				this.psi.set('context', {});
			}

			var psiContext = this.psi.get('context');

			if(app.wizardContext.get('folderId') || this.psi.get('targetFolderId')) {
				psiContext.targetFolderId = app.wizardContext.get('folderId') || psiContext.targetFolderId;
				this.psi.targetFolderId = psiContext.targetFolderId;
			}
			
			
			this.action.set("name", self.actionType);
			this.action.set("parameters", {
					'parentId': self.parentId,
					'psiName': this.psi.get('name'),
					'psdName' : this.psi.get('psdName'),
					'psiType': this.psi.get('instanceType') || 'Page Set Instance',
					'psi': JSON.stringify(this.psi),
					'workflow': this.workflow ? JSON.stringify(this.workflow) : '',
					'supportingDocIds': supportingDocIds,
					'psiId': self.formId,
					'appId': app.appId,
					'context': JSON.stringify(app.wizardContext),
					'sendTimingEmails': self.sendNotificationEmails,
					'streamline' : self.streamline
				});
			this.action.execute({
				success: function(action){
					deferred.resolve(action.result);
					app.context.configService.getWizardConfig(function(config){ 
                		//Search for the config corresponding to our form
                		var formInfo = _.find(config.get("wizardForms").models, function(form) {
                    		return form.get("formName") === action.parameters.psdName;
                		});
                		//If there is no corresponding config, proceed to stage
                		if (typeof formInfo == 'undefined') {
                    		app.trigger("psi:viewForm", action.result);
                		} 
                    	else if (formInfo.get("selectedActionId") === "") {
                    		app.trigger("psi:action:finished", action.parameters.psdName, action.result, action.parameters.streamline);
                    	}
                    	else {
                    		app.trigger("psi:submit:finished", action.parameters.psdName, action.result, formInfo.get("selectedActionId"), action.parameters.streamline);
                   		}
					});
				}
			});

			return deferred.promise();
		},
		rollbackUpload: function(){
			//TODO: procedure for rolling back a failed psi upload
		},
		//util function for removing queried options as we don't want to presist hundreds of options that were never selected
		cleanupQueriedOptions: function(){
			//don't remove the options attribute
			this.psi.get('pages').each(function(page){
				page.get('questions').each(function(question){
					var field = question.get('field');
					_.each(PSIUtil.blacklistOptions, function(blacklistOption){
						if(field.has(blacklistOption)){
							field.unset(blacklistOption, {silent: true});
						}
					}, this);
					
					var attrsToRemove = _.map(PSIUtil.specificQuestionBlacklistAttrs, function(questionAttr){
						if (questionAttr.questionType === field.getType()){
							return questionAttr.attr;
						}
					});
					
					_.each(attrsToRemove, function(attr){
						if(question[attr]){
							delete question[attr];
						}
					});
				}, this);
			}, this);
		},
		afterRender: function(){
			this.ui.spinner = this.$(".spinner");
			// create our loading spinner
			HPISpinner.createSpinner({
				lines: 	13, // The number of lines to draw
				length: 40, // The length of each line
				width: 	10, // The line thickness
				radius: 60, // The radius of the inner circle
				trail: 	25, // Afterglow percentage
				shadow: true, // Whether to render a shadow
				top: '50%',
				left: '50%'
			}, this.ui.spinner[0]);
            this.$('.loading-spinner').css('margin-top', '160px');
		}
	});

	return PSIUtil;
});