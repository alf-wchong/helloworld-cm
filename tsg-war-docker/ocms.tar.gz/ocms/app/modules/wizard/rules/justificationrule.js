define([
	'app',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager'
], function(app, RuleEventManager, QuestionEventManager){
	var JustificationRule = {};

	JustificationRule.processActions = function(question, rule){
		rule.getActions().each(function(action){
            if(!action.has('justification')){
                app.log.error('no justification found');
            }else{
            	//scope context of this rule to this listenTo so events line up with the correct rule
                var context = _.extend({}, {
					'question': question,
					'rule': 	rule,
					'options': 	question.options,
					'action': 	action
				});

                var triggerRule = _.bind(JustificationRule._checkJustifications, context);
                
                //this is a global vent - keep scope with the above context
                RuleEventManager.listenTo(QuestionEventManager, 'change:question:validity:' + question.getAddress(), triggerRule);
            }
        }, this);
	};

	JustificationRule._checkJustifications = function(question){
		var field = question.get('field');
    	var selectedOption = field.getValue();
    	if(selectedOption && _.isObject(selectedOption)){
    		selectedOption = selectedOption.value;
    	}
    	var triggered = false;
        if(_.contains(this.rule.getTrigger(), selectedOption)){
        	//add placeholder to justifications for this triggered option - preserve any existing justification
        	if(field.get('justifications')[selectedOption] === undefined){
        		field.get('justifications')[selectedOption] = '';
        	}
            field.trigger('justification:action', selectedOption);
            triggered = true;
        }else if(field.getValues !== undefined){
            _.each(field.getValues(), function(eachValueSelected){
                if(_.contains(this.rule.getTrigger(), eachValueSelected)){
                	//add placeholder to justifications for this triggered option - preserve any existing justification
                	if(field.get('justifications')[eachValueSelected] === undefined){
                		field.get('justifications')[eachValueSelected] = '';
                	}
                    field.trigger('justification:action', eachValueSelected);
                    triggered = true;
                }
            }, this);
        }
        if(!triggered){
        	//remove the justification view as that option is no longer selected
        	field.trigger('justification:action',this.rule.getTrigger(), true);
        }
	};

	return JustificationRule;
});