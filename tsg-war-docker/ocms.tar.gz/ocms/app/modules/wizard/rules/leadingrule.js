define([
	'app',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager',
	'modules/wizard/events/pageeventmanager',
	'modules/wizard/events/psieventmanager'
], function(app, RuleEventManager, QuestionEventManager, PageEventManager, PSIEventManager){
	var LeadingRule = {};

	LeadingRule.processActions = function(question, rule){
		rule.getActions().each(function(action){
			if(!action.has('page')){
				app.log.error('no leading page found');
			}else{
				//scope context of this rule to this listenTo so events line up with the correct rule
				var context = _.extend({}, {
					'question': question,
					'rule': 	rule,
					'options': 	question.options,
					'action': 	action
				});
				//listen for value to match the onTrigger
				var triggerRule = _.bind(LeadingRule._triggerRule, context);

				//check if trigger is already set
				triggerRule.call(this, question.get('field'));

				//this is a global vent - keep scope with the above context
				RuleEventManager.listenTo(QuestionEventManager, 'change:question:validity:' + question.getAddress(), function(question){
					_.throttle(triggerRule.call(this, question.get('field')), 250);
				});
			}
		}, this);
	};

	LeadingRule._triggerRule = function(field){
		var triggered;
		if(field.getValues){
			//repeating values
			//check if thety're objects
			var values = field.getValues();
			if(field.getValues() && field.getValues().length > 0){
				if(typeof field.getValues()[0] !== 'string'){
					values = _.pluck(field.getValues(), 'value');
				}
			}
			_.each(values, function(value){
				// Since this is an each, we'll go through this more than once... at least one hit will result into true
				if(LeadingRule._isRuleTriggered(this.rule, value)){
					triggered = true;
				}
			}, this);
		}else{
			var value = field.getValue();
			//check if field.getValue() is an object, if so, get the value attr
			if(field.getValue() && typeof field.getValue() !== 'string'){
				value = field.getValue().value;
			}
			triggered = LeadingRule._isRuleTriggered(this.rule, value);
		}
		if(triggered){
			PSIEventManager.trigger('cache:add:page:' + this.question.psiId, this.question.id, this.rule.id, this.options.page_id, this.action.get('page').id);
			PageEventManager.trigger('leading:action:' + this.question.psiId, this.rule, this.options.page_id, this.action.get('page').id);
		}else{
			var deferred = $.Deferred();
			PSIEventManager.trigger('cache:remove:page:' + this.question.psiId, this.question.id, this.rule.id, this.options.page_id, this.action.get('page').id, deferred);
			$.when(deferred).done(_.bind(function(canRemove){
				if(canRemove){
					//option has changed, rremove this page from the active flowpath
					PageEventManager.trigger('remove:action:' + this.question.psiId, this.rule, this.options.page_id, this.action.get('page').id);
				}
			}, this));
		}
	};

	LeadingRule._isRuleTriggered = function(rule, value){
		isTriggered = false;

		if(rule.get('criteria')){
			isTriggered = rule.get('criteria') === value;
		} else if(_.isArray(rule.getTrigger())){
			isTriggered = _.contains(rule.getTrigger(), value);
		} else{
			isTriggered = rule.getTrigger() === value;
		}

		return isTriggered;
	};

	return LeadingRule;
});
