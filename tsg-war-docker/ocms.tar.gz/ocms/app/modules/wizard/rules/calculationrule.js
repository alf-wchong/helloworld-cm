define([
	'app',
	'modules/wizard/services/formulaservice',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager'
], function(app, FormulaService, RuleEventManager, QuestionEventManager){
	var CalculationRule = {};

	CalculationRule.processActions = function(question, rule){
		rule.getActions().each(function(action){
			//get the formula from the rule
			var formula = action.get('formula');
			var precision = action.get('precision');
			_.each(FormulaService.expressions(formula), function(address){
				RuleEventManager.listenTo(QuestionEventManager, 'change:question:validity:' + address, function(){
					FormulaService.evaluate(formula, precision).done(function(result){
						RuleEventManager.trigger('calculation:rule:evaluated:' + question.getAddress(), result);
						//NOTE: multiple targets no longer supported
						//this assummes that the rule is on the target question
						question.get('field').setValue(result);
						//manually call setDisplayValuie here as the control is most likely read-only
						question.get('field').setDisplayValue(result);
					});
				}, this);
			}, this);

			//initial computation for any pre-existing values
			FormulaService.evaluate(formula).done(function(result){
				question.get('field').setValue(result);
				//manually call setDisplayValuie here as the control is most likely read-only
				question.get('field').setDisplayValue(result);
			});
		}, this);
	};

	return CalculationRule;
});