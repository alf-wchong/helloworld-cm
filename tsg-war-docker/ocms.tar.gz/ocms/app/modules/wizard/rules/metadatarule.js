define([
	'app',
	'modules/wizard/events/psieventmanager'
], function(app, PSIEventManager){
	var MetadataRule = {};

	MetadataRule.processActions = function(question, rule){
		var metadataPropertyName = rule.get('actions').models[0].get('property-name');
        var type = rule.get('actions').models[0].get('property-value').source;
        //add this question and its current state to the metadata map
        PSIEventManager.trigger('metadata:add:' + question.psiId, {
    		'page_id': question.page_id,
			'question_id': question.id,
			'repoAttr': metadataPropertyName,
			'answer': question.get('field'),
    		'type': type
    	});
	};

	return MetadataRule;
});