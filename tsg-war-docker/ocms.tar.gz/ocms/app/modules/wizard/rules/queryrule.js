define([
	'app',
	'modules/wizard/services/queryservice',
	'modules/wizard/events/ruleeventmanager',
	'modules/wizard/events/questioneventmanager'
], function(app, QueryService, RuleEventManager, QuestionEventManager){

	var QueryRule = _.extend({}, Backbone.Events);

	//Exposed interal function for testing purposes.
	QueryRule._updateQuestion = function(question, rule, action, placeholders, isValid, message){
		var field = question.get('field');

		//clear this question's value and any queried options
		if(!_.contains(field.get("fieldAspects"), "growable")){
			field.setValue();
			field.setDisplayValue();
		}				
		field.unset('queriedOptions');
		field.unset('allOptions');
		if(isValid){
			QueryRule._executeQuery(question, rule, action, placeholders.toJSON());
		}
	};

	QueryRule.processActions = function(question, rule){
		//question's value and display value hold the column names - remove if not fetched yet
		if(!question.get('field').get('fetched')){
			question.get('field').clear();
		}

		rule.getActions().each(function(action){
			this.stopListening(RuleEventManager, 'change:placeholders:validity:' + question.getAddress());
			this.listenTo(RuleEventManager, 'change:placeholders:validity:' + question.getAddress(), QueryRule._updateQuestion, this);

			this.listenTo(RuleEventManager, 'change:placeholders:none:' + question.getAddress(), function(question, rule, action, placeholders){
				QueryRule._executeQuery(question, rule, action, placeholders.toJSON());
			}, this);

			RuleEventManager.trigger('setup:placeholders', question, rule, action);
		}, this);
	};

	QueryRule._executeQuery = function(question, rule, action, substitutions, columnNames){
		QuestionEventManager.trigger('question:activity:start:' + question.getAddress());
		var context = {
			'question': question,
			'rule': rule,
			'action': action,
			'substitutions': substitutions,
			'columnNames': columnNames
		};

		var debounceQuery = _.debounce(_.bind(function(){
			//fire the query
			var query = new QueryService.ResultSet({
				'question': question,
				'action': action,
				'substitutions': substitutions,
				'columnNames': rule.getTrigger()
			});
			question.get('field').set('datasource', query);
			question.get('field').getOptions().done($.proxy(function(options){
				if(options && options.length > 0){
					//if theres only one option, default to that value
					if(rule.get('queryResult') === 'value' && options.length === 1){
						question.get('field').setValue(options[0] ? options[0].value : '');
					}else if(rule.has('defaultTo') && rule.get('defaultTo')){
						if(question.get('field').has('queriedOptions')){
							var queriedOption = question.get('field').get('queriedOptions') && question.get('field').get('queriedOptions')[0] ? question.get('field').get('queriedOptions')[0].value : '';
							question.get('field').setValue(queriedOption);
						}else{
							question.get('field').setValue(options[0].value);
						}
					}else if(rule.get('queryResult') === 'value'){
						//reset value if set to value, otherwise passthrough
						question.get('field').setValue();
					}
				}
				QuestionEventManager.trigger('question:activity:stop:' + question.getAddress());

			}, this));
		}, context), 250); //wait 1/4 second to proc a query

		debounceQuery();
	};

	return QueryRule;
});
