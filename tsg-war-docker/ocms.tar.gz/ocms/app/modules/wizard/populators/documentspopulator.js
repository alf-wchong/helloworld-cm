define([
    'app',
    'module',
    "modules/common/ocquery",
    'modules/wizard/events/questioneventmanager',
    "managerelations",
    'modules/wizard/events/tableeventmanager'
], function(app, module, OcQuery, QuestionEventManager, ManageRelations, TableEventManager){
    var DocumentsPopulator = {};

    DocumentsPopulator.Config = _.extend({}, ManageRelations.Config, {
		//hotspot function for getting table headers and associated attributes
		getAttributes: function(){
			return module.config().attributes || [
                {
                    'displayName': 'Name',
                    'ocoName': 'objectName',
                    'createLink': true
                },
                {
                    'displayName': 'Category',
                    'ocoName': 'hpi_folderTags'
                }
            ];
		},
		openLink: function(event){
			//override and stream back this document
			window.open(app.serviceUrlRoot + '/content/content?id=' + event.target.id  + "&contentType[]=" + ["pdf"]);
		}
	});

    DocumentsPopulator.Table = ManageRelations.DocumentsTable.extend({
        template: 'wizard/populator/documents',
        initialize: function(options){
            this.searchConfigs = module.config().searchConfig;
            options.config = DocumentsPopulator.Config;
            DocumentsPopulator.Table.__super__.initialize.apply(this, arguments);
            this.docsFeteched = $.Deferred();
            this.fetchFolderDocs();

            var self = this;
            this.listenTo(TableEventManager, this.question.page_id + ':populator:check:checkbox', function (rowProps, checked) {
                // make sure that the rowProps coming in here actually have a value in their prop
                var atLeastOneProp = false;
                _.each(rowProps, function(prop, key){
                    if (_.isArray(prop)){
                        if (prop.length > 0){
                            atLeastOneProp = true;
                        }
                    } else if (prop){
                        atLeastOneProp = true;
                    }
                });

                if (atLeastOneProp){
                    var deletedDocModel = _.find(self.documents.models, function(model){
                        var ocoNormalizedKeys = self.getNormalizedKeys(model.get('oco'));
                        // loop through each of rowProps and see if they don't match any of the current oco properties,
                        // if we find a properties that doesn't match then move on to the next oco in the docs list
                        var notThisOco = _.find(rowProps, function(prop, key){
                            // if the ocoNormalizedKeys doesn't have one of the properties that the rowProps has, then just ignore it
                            if (!ocoNormalizedKeys[key] ){
                                return false;
                            }
                            // need to check if the prop was populated from a nonrepeating field into a repeating field
                            if (!_.isArray(ocoNormalizedKeys[key]) && _.isArray(prop)){
                                prop = prop[0];
                            }

                            if (ocoNormalizedKeys[key] !== prop){
                                return true;
                            }
                        });

                        if (!notThisOco){
                            return true;
                        }
                    });

                    if (deletedDocModel){
                        deletedDocModel.trigger("set:checkbox", checked);
                    }
                }
            });
        },
        getNormalizedKeys: function(oco){
            var ocoNormalizedKeys = {};
            _.each(oco, function(value, key){
                var newKey = key.toLowerCase().replace(/ /g, '');
                ocoNormalizedKeys[newKey] = value;
            });

            return ocoNormalizedKeys;
        },
        onDocChecked: function(doc, checked){
            var questionLabels = _.map(this.question.collection.models, function(model){
                return model.get('short-label').toLowerCase().replace(/[-_ ]/g, '');
            });

            // make a copy of the doc's oco its keys are in the same format as the questionLabels (no spaces & all lowercase)
            var ocoNormalizedKeys = this.getNormalizedKeys(doc.get('oco'));

            // find the properties we need to set on the question table row
            var selectedDocProps = {};
            _.each(questionLabels, function(label){
                if (ocoNormalizedKeys[label]){
                    selectedDocProps[label] = ocoNormalizedKeys[label];
                }
            });
            if (checked){
                this.field.setValue(doc);

                // fire event to create and populate a new row in the questions table
                TableEventManager.trigger(this.question.page_id + ':append:group', selectedDocProps);

            } else {
                TableEventManager.trigger(this.question.page_id + ':populator:delete:group', selectedDocProps);
            }
        },
        setSearchParameters: function(map){
            var searchParams = _.extend([], _.map(this.searchConfigs, _.clone));
			_.each(searchParams,function(param) {
                //set the Parent id to the current parent folder - Alfresco needs it encoded
				if(param.paramValue === "none" && map[param.paramName]){
                    param.paramValue = window.encodeURIComponent(map[param.paramName]);
				}
			},this);
			return searchParams;
        },
        fetchFolderDocs: function(){
            var self = this;
            var docQuery = new OcQuery.Collection([],{
				mode: "client"
			});
			docQuery.searchParameters = this.setSearchParameters({
                'Parent': app.wizardContext.get('folderId')
            });

			docQuery.fetch({
				success: function(data){
                    var documents = [];
					data.fullCollection.each(function(oco){
						var newOco = _.extend({}, oco.get("properties"), {
							"objectId": oco.get("objectId"),
							"objectName": oco.get("properties").objectName,
							"title": oco.get("properties").title
						});
                        documents.push(new ManageRelations.Document({
							'oco': newOco
						}));
					});

                    self.listenTo(self.documents, 'check', function(doc){
                        self.onDocChecked(doc, true);
                    });

                    self.listenTo(self.documents, 'uncheck', function(doc){
                        self.onDocChecked(doc, false);
                    });

                    self.documents.reset(documents);
                    self.docsFeteched.resolve();
				},
				error: function(){
					app.log.error(window.localize("modules.wizard.populators.documentsPopulator.documentsPopulator"));
				}
			});

        },
        afterRender: function(){
            var self = this;
            $.when(this.docsFeteched).done(function(){
                TableEventManager.trigger(self.question.page_id + ':populator:get:questionsGroups');
            });
        }
    });

    return DocumentsPopulator.Table;
});
