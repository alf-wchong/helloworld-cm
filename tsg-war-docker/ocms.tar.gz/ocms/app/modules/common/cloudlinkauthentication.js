// Repotype module
define([
    "app",
    "modules/actions/actionmodules",
    "modules/common/action",
    "modules/common/spinner",
    "wlapi"
],
function(app, actionModules, action, HPISpinner, WL) {
    var CloudLinkAuthentication = app.module();

    CloudLinkAuthentication.View = Backbone.Layout.extend({
        template: "common/cloudlinkauthentication/cloudlinkauthentication",
        initialize: function() {
            var self = this;
            this.returnObject = {};

            // child view to display links to documents and folders from cloud services that are currently unsupported
            this.unsupportedLinksView = new CloudLinkAuthentication.UnsupportedLinksView({
                "unsupportedCloudLinks" : this.options.cloudResults.unsupportedCloudLinks,
                "supportedCloudLinks" : (this.options.cloudResults.supportedCloudLinks === undefined) ? false : true
            });

            // all found links to content from supported cloud services. this is where the user selects which items to
            // import, and can modify the url's that were parsed from the MSG files
            this.supportedLinksView = new CloudLinkAuthentication.SupportedLinksView({
                    "supportedCloudLinks" : this.options.cloudResults.supportedCloudLinks, 
                    "unsupportedCloudLinks" : (this.options.cloudResults.unsupportedCloudLinks === undefined) ? false : true
            });

            // switch from unsupported links view to supported links view on "next" clicked
            self.listenTo(app, "unsupportedlinks:nextPressed", function() {
                // create our return object here, which will contain authentication access tokens retreived from
                // each selected service
                this.returnObject = this.options.cloudResults.supportedCloudLinks;
                self.supportedLinksView = new CloudLinkAuthentication.SupportedLinksView({
                    "supportedCloudLinks" : this.options.cloudResults.supportedCloudLinks
                });
                this.switchViews(self.supportedLinksView);
            });

            // switch from supported links view to the authentication route
            self.listenTo(app, "supportedlinks:nextPressed", function(selectedLinks) {
                var self = this;
                this.returnObject = {};
                this.routeMap = [];

                // configure the route map, which will direct the user between different authentication processes
                _.each(selectedLinks, function(content, service) {
                    if(content.selectedLinks.length !== 0) {
                        self.returnObject[service] = content;
                        self.routeMap.push({"service": service, "view": null});
                    }
                });
                // kick off the authentication route
                app.trigger("authenticationRouter:next", 0);

            });

            self.listenTo(app, "authenticationRouter:next", function(index) {
                var self = this;
                // if index is -1, we are navigating back to supported links
                if(index === -1) {
                    this.switchViews(self.supportedLinksView);
                }
                // if index equals the size of our route map, we are finished. trigger the callback
                // and send our result object to bulk upload
                else if(index === _.size(self.routeMap)) {
                    // close the modal
                    // collect all the tokens
                    $('#cloudAuthFinished').click();
                    _.each(self.routeMap, function(routeItem) {
                        if(!routeItem.view) {
                          self.returnObject[routeItem.service].authentication = {}; 
                        }
                        else {
                            self.returnObject[routeItem.service].authentication = routeItem.view.options.authObject;
                        }
                    });
                    app.trigger("authentication:finished", self.returnObject);
                }
                else {
                    // google
                    if(this.routeMap[index].service === "Google") {
                        self.googleAuthenticationView = new CloudLinkAuthentication.GoogleAuthenticationView({
                            "selectedLinks" : self.returnObject.Google.selectedLinks,
                            "routeIndex" : index,
                            "clientId": self.options.googleClientId

                        });
                        this.routeMap[index].view = self.googleAuthenticationView;
                        this.switchViews(self.googleAuthenticationView);
                    }
                    // microsoft
                    else if(this.routeMap[index].service === "OneDrive") {
                        self.microsoftAuthenicationView = new CloudLinkAuthentication.MicrosoftAuthenticationView({
                            "selectedLinks" : self.returnObject.OneDrive.selectedLinks,
                            "routeIndex" : index,
                            "clientId" : self.options.microsoftClientId

                        });
                        this.routeMap[index].view = self.microsoftAuthenicationView;
                        this.switchViews(self.microsoftAuthenicationView);
                    }
                    else if(this.routeMap[index].service == "Dropbox") {
                        app.trigger("authenticationRouter:next", index+1);
                    }

                }
            });
            // handle the back button pressed from supported links, switch between the appropriate views
            self.listenTo(app, "supportedLinks:backPressed", function() {
                this.switchViews(self.unsupportedLinksView);
            });
        },
        afterRender: function() {
            // find out what our first view will be based on whether we found supported or 
            // unsupported cloud links
            var firstView = (this.options.cloudResults.unsupportedCloudLinks === undefined) ? this.supportedLinksView : this.unsupportedLinksView;
            // first set view to unsupported links
            this.setView("#cloudLinkAuthenticationSubView", firstView, true).render();
           // listen to all navigation
        },
        
        switchViews: function(newView) {
            // remove the old view
            this.removeView("#cloudLinkAuthenticationSubView");
            // set the new view
            this.setView("#cloudLinkAuthenticationSubView", newView, true).render();
        }
    });

    CloudLinkAuthentication.UnsupportedLinksView = Backbone.Layout.extend({
        template: "common/cloudlinkauthentication/unsupportedlinks",
        events: {
            "click .toSupportedLinksView" : "next"
        },
        initialize: function() {
            var self = this;
            this.unsupportedCloudLinks = [];
            this.unsupportedCloudServices = [];
            _.each(this.options.unsupportedCloudLinks, function(links, service) {
                this.service = service;
                var cloudLinkObj = {
                    "title" : service,
                    "urls" : []
                };
                _.each(links, function(link) {
                    cloudLinkObj.urls.push({"service": this.service, "shortOption" : link["short"], "longOption" : link["long"]});
                });
                self.unsupportedCloudServices.push(cloudLinkObj);
            });
            if(this.unsupportedCloudLinks.length === 0) {
                this.next();
            }
        },
        serialize: function() {
            return {
                unsupportedCloudLinks : this.unsupportedCloudServices,
                supportedCloudLinks : this.options.supportedCloudLinks
            };
        },
        next : function() {
            app.trigger("unsupportedlinks:nextPressed");
        }
    });

    CloudLinkAuthentication.SupportedLinksView = Backbone.Layout.extend({
        template: "common/cloudlinkauthentication/supportedlinks",
        events: {
            "click .toAuthenticationView" : "next",
            "click .backToUnsupportedView" : "back"
        },
        initialize: function() {
            var self = this;
            this.supportedCloudLinks = [];
            this.supportedCloudServices = [];
            _.each(this.options.supportedCloudLinks, function(links, service) {
                this.service = service;
                var cloudLinkObj = {
                    "title" : service,
                    "urls" : []
                };
                _.each(links, function(link) {
                    cloudLinkObj.urls.push({"service": this.service, "shortOption" : link["short"], "longOption" : link["long"]});
                });
                self.supportedCloudServices.push(cloudLinkObj);
            });
        },
        serialize: function() {
            return {
                supportedCloudServices : this.supportedCloudServices, 
                unsupportedCloudLinks : this.options.unsupportedCloudLinks
            };
        },
        next : function() {
            var selectedLinks = {
                "Google": {
                    "authentication" : {},
                    "selectedLinks" : [] 
                },
                "OneDrive": {
                    "authentication" : {},
                    "selectedLinks" : [] 
                },
                "Dropbox": {
                    "authentication" : {},
                    "selectedLinks" : []
                }
            };

            $("input:checked").each(function() {
                var service = $(this).parent().parent().parent().attr('id');
                selectedLinks[service].selectedLinks.push($(this).parent().next().val());
            });
            app.trigger("supportedlinks:nextPressed", selectedLinks);
        },
        back : function() {
            app.trigger("supportedLinks:backPressed");
        }
    });

    CloudLinkAuthentication.GoogleAuthenticationView = Backbone.Layout.extend({
        template: "common/cloudlinkauthentication/serviceauthentication",
        events: {
            "click .authorize" : "authorize",
            "click .backToSupportedView" : "back"
        },
        initialize: function() {
            var self = this;
            // listen for result of authentication
            this.listenTo(app, "googleAuthentication:callback", function(result) {
                // if we successfully authenticated, put the access_token on Google's authObject
                if(result && !result.error) {
                    self.options.authObject = {"access_token": result.access_token};
                }
                // otherwise throw an error
                else {
                    $('#cloudLinkAuthenticationSubView').append("<div class='alert alert-error'>Error authenticating Google Drive user</div>");
                    self.options.authObject = {};
                }
                app.trigger("authenticationRouter:next", this.options.routeIndex + 1);
            });
            
        },
        serialize: function() {
            return { service: "Google"};
        },
        googleCallback: function(result) {
            app.trigger("googleAuthentication:callback", result);
        },
        authorize: function() {
           var self = this;
           this.clientId = this.options.clientId;
            window.gapi.auth.authorize(
            {
                "client_id": self.clientId,
                "scope": "https://www.googleapis.com/auth/drive",
                "immediate": false
            },
            self.googleCallback
            );
        },
        back: function() {
            app.trigger("authenticationRouter:next", this.options.routeIndex - 1);
        }
    });
    
    CloudLinkAuthentication.MicrosoftAuthenticationView = Backbone.Layout.extend({
        template: "common/cloudlinkauthentication/serviceauthentication",
        events: {
            "click .authorize" : "authorize",
            "click .backToSupportedView" : "back"
        },
        initialize: function() {
            this.clientId = this.options.clientId;
            // listen for successful authentication callback. trigger the next step in the authentication route
            this.listenTo(app, "microsoftAuthenicationView:callback", function() {
                app.trigger("authenticationRouter:next", this.options.routeIndex + 1);
            });
 
        },
        serialize: function() {
             return {
                service : "OneDrive"
            };
        },
        authorize: function() {
            var self = this;
            // authenticate user with Microsoft OneDrive
            window.WL.init({
                client_id: self.clientId,
                redirect_uri: window.location.protocol + "//" + window.location.host + app.root + "hpi/dummy/path",
                scope: "wl.skydrive", 
                response_type: "token"
            }).then(function(){
                window.WL.login({
                    // contacts_skydrive scope allows shared documents to be accessed by the api, as well as
                    // the user's own documents (OneDrive handles these seperately)
                    scope: ["wl.basic", "wl.contacts_skydrive"]
                }, self.onLogin).then(
                    function(response) {
                        // login response contains an authentication token and an access token, both of which
                        // are needed to get content from OneDrive so put these on the authObject
                        self.options.authObject = {
                            "auth_token": response.session.authentication_token,
                            "access_token": response.session.access_token
                        };
                        app.trigger("microsoftAuthenicationView:callback");
                    },
                    function (responseFailed) {
                        // could not authenticate, so display an error
                        $('#cloudLinkAuthenticationSubView').append("<div class='alert alert-error'>Error authenticating OneDrive user</div>");
                    }
                );
            });
        },
        onLogin: function (response) {
            WL.logout();
        },
        back: function() {
            app.trigger("authenticationRouter:next", this.options.routeIndex - 1);
        }

    });
    
    return CloudLinkAuthentication;
});

