define([
	"app"
],
function(app) {

	var GoogleDocs = app.module();

	// called to authenticate our user with Google
	//     state - the state to pass through once a user authenticates HPI with Google
	//     reauthorize - true to force an authorization URL to be opened in a new window regardless of the current
	//                   user credentials stored in the repo
	//     authenticateCallback - the callback to call with the result of authentication
	GoogleDocs.authenticateUser = function(state, reauthorize, authenticateCallback) {
		$.ajax({
			url: app.serviceUrlRoot + "/googledocs/authenticate",
			method: "GET",
			data: {
				// this state gets passed through to the redirectURI if the user isn't currently authenticated
				// at which point we use it to actually create the Google doc once they've finished authenticating
				state: encodeURIComponent(JSON.stringify(state)),
				override: reauthorize
			},
			success: function(response) {
				// our result was successful
				var result = {
					"result": "success"
				};

				// if the user isn't authenticated or we're forcing a reauthorization, then we want to
				// open the returned authorization URL in a new window
				if(!response.authenticated || reauthorize) {
					// we unfortunately can't force this to open in a new tab - it comes down to 
					// the user's browser configuration if this happens
					window.open(response.authURL);

					// set that the user is not authenticated and pass through the value of reauthorization
					result.isAuthenticated = false;
					result.reauthorize = reauthorize;

					// invoke the callback
					authenticateCallback(result);
				} else {
					// the user is authenticated
					result.isAuthenticated = true;

					// invoke the callback
					authenticateCallback(result);
				}
			},
			error: function() {
				// invoke our callback that we failed to authenticate or grab an authentication URL
				authenticateCallback({
					"result": "error",
					"errorMsg": (window.localize("modules.common.googleDocs.failedToReceive"))
				});
			}
		});
	};

	// called to create a new Google document
	//    state - the state to pass through if authentication with Google fails, this should be an object with
	//            the following properties: parentObjectId (where to create the document), objectType (the object
	//            type of the new repo object), googleDocumentType ('document', 'spreadsheet' or 'presentation')
	//            and action ('create')
	//    replace - false to open a new window to edit the new Google doc, true to replace the URL of the current window
	GoogleDocs.createGoogleDoc = function(state, replace, createDocCallback) {
		// make our call to actually create the Google document
		$.ajax({
			url: app.serviceUrlRoot + "/googledocs/create",
			method: "GET",
			data: {
				parentObjectId: state.parentObjectId,
				// this is the type of repository object we're going to create
				objectTypeBeanName: state.objectType,
				googleDocType: state.googleDocumentType
			},
			// don't want to trigger an global setup since a 401 may be returned if the
			// authorization is stale
			global: false,
			success: function(response) {
				// once we've successfully created the Google document, let's check it out
				GoogleDocs.checkOutGoogleDoc(response.objectId, replace, createDocCallback);
			},
			statusCode: {
				// if a 401 occurs, then we failed to authenticate with Google because the user probably
				// revoked access for HPI, so let's force a reauthorization
				401: function() {
					// passing the reautorize parameter as "true" to force a new authorization URL
					GoogleDocs.authenticateUser(state, true, createDocCallback);
				}
			},
			error: function(jqXHR) {
				// if any other error occurs besides a 401, then let's display to the user that we failed
				// to create their document
				if(jqXHR.status !== 401) {
					createDocCallback({
						"result": "error",
						"errorMsg": (window.localize("modules.common.googleDocs.failedToCreate")) + state.googleDocumentType + "."
					});
				}
			}
		});
	};

	// called to check out a repository document for Google docs editing
	//     objectId - the objectId of the repo object to check out for editing
	//     replace - false to open a new window to edit the new Google doc, true to replace the URL of the current window
	//     callback - the callback to invoke when we've finished with the checking out of the Google document
	GoogleDocs.checkOutGoogleDoc = function(objectId, replace, callback) {
		$.ajax({
			url: app.serviceUrlRoot + "/googledocs/checkout",
			method: "GET",
			data: {
				objectId: objectId
			},
			success: function() {
				// on success let's open our document for Google Docs editing
				GoogleDocs.openDocumentInGoogleDocs(objectId, replace);

				// invoke our callback that we were successful in checking out the document
				callback({
					result: "success"
				});
			},
			error: function() {
				// invoke our callback that an error occured trying to check out our document
				callback({
					result: "error",
					errorMsg: (window.localize("modules.common.googleDocs.failedToCheck"))
				});
			}
		});
	};

	// called to check if an object has the correct conditions to be edited in Google Docs
	//    state - the state to pass through if we need to reauthenticate before editing
	//    replace - false to open a new window to edit the new Google doc, true to replace the URL of the current window
	//    callback - the callback to invoke once we've checked the editing conditions
	GoogleDocs.getEditingConditions = function(state, replace, callback) {
		var objectId = state.objectId;

		// when we open this action we want to kick off a request to get the conditions necessary to determine
		// if the document is ready to be opened in a new window for Google Docs editing
		$.ajax({
			url: app.serviceUrlRoot + "/googledocs/getEditingConditions",
			method: "GET",
			data: {
				objectId: objectId
			},
			success: function(response) {
				// if the response is checked out and has the "editing in Google Docs" relation, then
				// we're ready to go and can open this document for editing in the share Google Docs editor
				if(response.hasEditingInGoogleDocsRelation && response.isCheckedOut) {
					// let's open our document for Google Docs editing
					GoogleDocs.openDocumentInGoogleDocs(objectId, replace);

					// invoke our callback that we were successful
					callback({
						result: "success"
					});
				} else if(response.hasEditingInGoogleDocsRelation && !response.isCheckedOut) {
					// if the document has the editing in google docs relation but isn't checked out,
					// it most likely was uploaded successfully but failed to check out
					GoogleDocs.checkOutGoogleDoc(objectId, replace, callback);
				} else {
					// the document has neither the editing in google docs relation nor is checked out
					// so let's do an upload so we can edit this document
					GoogleDocs.uploadDocumentForGoogleDocsEditing(objectId, state, replace, callback);
				}
			},
			error: function() {
				// invoke our callback that we failed to check if the document can be edited in Google Docs
				callback({
					result: "error",
					errorMsg: (window.localize("modules.common.googleDocs.failedToRetrieveInfo"))
				});
			}
		});
	};

	// called when we're ready to open the document in the Google Docs share editor
	//    objectId - the objectId of the object to open in the Google Docs share editor
	//    replace - false to open a new window to edit the new Google doc, true to replace the URL of the current window
	GoogleDocs.openDocumentInGoogleDocs = function(objectId, replace) {
		var googleDocsUrl = app.shareURL + "/page/context/mine/googledocsEditor?nodeRef=" + encodeURIComponent(objectId) + "&return=context%2Fmine%2Fmyfiles%23filter%3Dpath%257C%252Fhpi%252Fcontent%252FGoogle%252520Docs%257C%26page%3D1";

		// if the user wants to replace the current URL, let's do that
		if(replace) {
			window.location.replace(googleDocsUrl);
		} else { // the user wants to open the URL in a new window
			window.open(googleDocsUrl);
		}
	};

	// called to upload a document for Google Docs editing - it copies the content of the repo object to a new
	// blank Google document that is then opened for editing
	//    objectId - the objectId of the object whose content we want to edit in Google Docs
	//    state - the state to pass through if we need to reauthorize before uploading
	//    replace - false to open a new window to edit the new Google doc, true to replace the URL of the current window
	//    callback - the callback to invoke once we've uploaded the document for Google Docs editing
	GoogleDocs.uploadDocumentForGoogleDocsEditing = function(objectId, state, replace, callback) {
		$.ajax({
			url: app.serviceUrlRoot + "/googledocs/upload",
			method: "GET",
			data: {
				objectId: objectId
			},
			success: function() {
				// now that we've successfully uploaded the object (and checked it out), we're ready to open
				// the document to be edited in the share Google Docs editor
				GoogleDocs.openDocumentInGoogleDocs(objectId, replace);

				// invoke our callback that we were successful
				callback({
					result: "success"
				});
			},
			statusCode: {
				// if a 401 occurs, then we failed to authenticate with Google because the user probably
				// revoked access for HPI, so let's force a reauthorization
				401: function() {
					GoogleDocs.authenticateUser(state, true, callback);
				}
			},
			error: function(jqXHR) {
				// if any other error occurs besides a 401, then let's display to the user that we failed
				// to create their document
				if(jqXHR.status !== 401) {
					callback({
						result: "error",
						errorMsg: (window.localize("modules.common.googleDocs.failedToUpload"))
					});
				}
			}
		});
	};

	return GoogleDocs;
});