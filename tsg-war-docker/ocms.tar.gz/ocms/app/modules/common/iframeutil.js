define([
	'app',
	'handlebars'
], function(app, Handlebars){

	var IFrameUtil = _.extend({}, Backbone.Events);

	IFrameUtil.processTemplate = function(template, options){
		var context = options;
		var deferred = $.Deferred();
		var prefix = 'app/templates/';
		var path = prefix + template + '.html';

		$.ajax({ url: app.root + path }).done(function(contents){
			var rawTemplate = Handlebars.compile(contents);
			deferred.resolve(rawTemplate(context));
		});

		return deferred.promise();
	};

	IFrameUtil.submitForm = function(html){
		var $iframe,
        iframe_doc;

        if (($iframe = $('#download_iframe')).length === 0) {
            $iframe = $("<iframe id='download_iframe'" +
                        " style='display: none' src='about:blank'></iframe>"
                       ).appendTo("body");
        }

        iframe_doc = $iframe[0].contentWindow || $iframe[0].contentDocument;
        if (iframe_doc.document) {
            iframe_doc = iframe_doc.document;
        }

        iframe_doc.open();
        iframe_doc.write(html);
        $(iframe_doc).find('form').submit();

       	IFrameUtil.trigger('iframe:submitted');
	};

	IFrameUtil.Form = Backbone.Layout.extend({
		template: 'common/iframeutil',
		initialize: function(options){
			this.options = options;
			this.options.formData = this.options.formData ? this.options.formData : [];
			var keys = _.keys(this.options.data);
			_.each(keys, function(key){
				var attr = {
					'key': key,
					'value': JSON.stringify(this.options.data[key])
				};
				this.options.formData.push(attr);
			}, this);
		},
		execute: function(){
			IFrameUtil.processTemplate(this.template, this.options).then($.proxy(function(form){
				IFrameUtil.submitForm(form);
			}, this));
		},
		serialize: function(){
			return this.options;
		}
	});

	return IFrameUtil;
});