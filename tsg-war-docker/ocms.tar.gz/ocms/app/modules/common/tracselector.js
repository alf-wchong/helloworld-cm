define([
    // Application.
    "app",
    "oc"
],
function(app, OC) {
    
    var TracSelector = {};

    TracSelector.TracSelectionView = Backbone.Layout.extend({
        template : "common/tracselector",
        events : {
            "click .tracoption" : "tracselected"
        },
        serialize : function() {
            return {
                tracs : this.options.tracs
            };
        },
        tracselected : function(e) {
            e.preventDefault();
            var trac = $(e.currentTarget).data("id");
            this.options.success(trac);
        }
    });

    // This method can be overridden for custom behavior the default
    // is to use the document in context to establish the object type
    // look that up against known type configs. If there is only one config it will use that otherwise it 
    // will provide a dialog to the user to select a trac
    // It then calls the supplied callback passing the established trac as the first param
    TracSelector.establishTrac = function(options, callback) {
        if(options.id){
            var objectToFindTracFor = new OC.OpenContentObject();

            objectToFindTracFor.set("objectId", options.id).fetch({
                success: function(fetchedObj){
                    var objectType = fetchedObj.get("objectType");
                    if(!objectType) {
                        app.log.error(window.localize("modules.common.tracSelector.unableToDetermine"));
                        return;
                    }

                    var validTracs = TracSelector.getValidTracs(objectType, app.context.tracConfigs);

                    if(validTracs.length === 1) {
                        callback(validTracs[0].get("name"), fetchedObj);
                    } else if(validTracs.length > 1) {
                        //we need to check if a folder id was also passed in.
                        //If so, we want to filter the number of valid tracs down
                        //some more
                        if(options.folderId){
                            var parentFolderObj = new OC.OpenContentObject();
                            parentFolderObj.set("objectId", options.folderId).fetch({
                                success: function(fetchedParentFolder){
                                    var folderType = fetchedParentFolder.get("objectType");
                                    if(!folderType) {
                                        app.log.error("Unable to determin objectType for folder in trac selector.");
                                        TracSelector.setupTracSelectionView(validTracs, callback);
                                    } else {
                                        var validFolderTracs = TracSelector.getValidTracs(folderType, app.context.tracConfigs);
                                        //intersection isn't supported on backbone models, so need to find the intersection
                                        //of our two arrays the hard way
                                        validTracs = _.filter(validTracs, function(docTrac){
                                            return _.find(validFolderTracs, function(folderTrac){ return folderTrac.get("name") === docTrac.get("name"); });
                                        });
                                        if(validTracs.length === 1){
                                            callback(validTracs[0].get("name"), fetchedObj);
                                        } else {
                                            TracSelector.setupTracSelectionView(validTracs, callback);
                                        }
                                    }
                                }
                            });
                        } else {
                            TracSelector.setupTracSelectionView(validTracs, fetchedObj, callback);
                        }        
                    } else {
                        app.trigger("alert:error", {
                            header : window.localize("modules.common.tracSelector.noAvailableTracs"), 
                            message : window.localize("modules.common.tracSelector.thereAreNo") + objectType
                        });
                    }
                }
            });
        } else { // didn't pass in an ID to this method
            app.log.error(window.localize("modules.common.tracSelector.noIdSupplied"));
        }
    };
    
    // used to find the trac for just an objectType,
    // use null since there will be no oco to passback
    TracSelector.establishTracByObjectType = function(objectType, callback){
        var validTracs = TracSelector.getValidTracs(objectType, app.context.tracConfigs);
         if (validTracs.length === 1) {
            callback(validTracs[0].get("name"), null);
         } else if (validTracs.length > 1) {
             TracSelector.setupTracSelectionView(validTracs, null, callback);
         } else {
             app.trigger("alert:error", {
                header : window.localize("modules.common.tracSelector.noAvailableTracs"), 
                message : window.localize("modules.common.tracSelector.thereAreNo") + objectType
            });
         }
    };

    TracSelector.getValidTracs = function(objectType, tracConfigs){
        return tracConfigs.filter(function(trac) {
            var typesUsedInTrac = trac.get('typesUsedInTrac');
            // if the specified objectType is in the list of valid ones, then this trac is good to go
            if(_.contains(typesUsedInTrac, objectType)) {
                return true;
            } else {
                return false;
            }
        });
    };

    TracSelector.setupTracSelectionView = function(validTracs, objectToFindTracFor, callback){
        var tracSelectionView = new TracSelector.TracSelectionView({
            // the goal of using 'map' is just to end up with an array of trac displayNames, falling back to name if displayName 
            // or label aren't there
            tracs: _.map(validTracs, function(item) {
                return item.get("displayName") || item.get("name");
            }), 
            success: function(trac) {
                _.each(validTracs, function(item) {
                    if(item.get("displayName") === trac || item.get("name") === trac) {
                        callback(item.get("name"), objectToFindTracFor);
                    }
                });
            }
        });
        app.trigger("alert:custom", {
            view : tracSelectionView, 
            width: 600 
        });
    };

    return TracSelector;

});