// Repotype module
define([
	"app"
],

function(app) {
	/*
	ISSUES
	1 - header needs re rendered after deleting last notification - if we just re render the notificaitons view
	the header notification bell stays orange - is this really an issue? any load anywhere else would clear this? 
	*/
	var Notification = app.module();

	Notification.Model = Backbone.Model.extend({
		// setting the id attribute here, otherwise the destroy event will not pass the workflow id back to the server
		idAttribute: "objectId",
		initialize: function(attributes) {
			var self = this;
			
			app.context.dateService.getFormattedDate(attributes.dateSent).done(function(formattedDate) {
				self.set('dateSent', formattedDate);
			});

			if (attributes.archived) {
				app.context.dateService.getFormattedDate(attributes.completedDate).done(function(formattedDate) {
					self.set('completedOn',formattedDate);
				});
			} else {
				app.context.dateService.getFormattedDate(attributes.dueDate).done(function(formattedDate) {
					self.set('dueDate',formattedDate);
				});
			}

			// all other form dates
			_.each(self.get("extraNotificationProps"), function(extraProp) {
				if (extraProp.controlType === "DateBox" ) {
					app.context.dateService.getFormattedDate(extraProp.value).done(function(formattedDate) {
						extraProp.value = formattedDate;
					});
				} else if (extraProp.controlType === "DatetimeBox" ) {
					app.context.dateService.getFormattedDatetime(extraProp.value).done(function(formattedDate) {
						extraProp.value = formattedDate;
					});
				}
			});

			//If userA sends a notification in regards to a document to userB and then the document is deleted the attachedObjectName (which identifies the document) will be erased. Therefore, it will be null
			//The documentHasBeenDeleted will be set to true to not show certain elements. See notifications.html for elements shown or not shown
			//If the attachedObjectName is null but the document has not been deleted this message will still show. See elements on notifications.html that will show
			//This will also occur if the user does not have permission to view the document
			self.set('documentHasBeenDeleted', !self.get('attachedObjectName'));
		}
	});

	Notification.Collection = Backbone.Collection.extend({
        model: Notification.Model,
        sortKey: 'dateSent',
		reverseSortDirection: false,
        comparator: function(a, b) {
            var dataA = a.get(this.sortKey),
            dataB = b.get(this.sortKey);

            // if we cant find data on the top level - try the extra parameters 
            if (dataA === undefined && a.get('extraNotificationProps') && a.get('extraNotificationProps')[this.sortKey]) {
                dataA = a.get('extraNotificationProps')[this.sortKey].value;
            }
            if (dataB === undefined && b.get('extraNotificationProps') && b.get('extraNotificationProps')[this.sortKey]) {
                dataB = b.get('extraNotificationProps')[this.sortKey].value;
            }

            if (this.reverseSortDirection) {
                if (dataA > dataB) { return -1; }
				if (dataB > dataA) { return 1; }
				if (!dataB && dataA){ return -1; }
				if (dataB && !dataA){ return 1; }
                return 0;
            } else {
                if (dataA < dataB) { return -1; }
				if (dataB < dataA) { return 1; }
				if (!dataB && dataA){ return 1; }
				if (dataB && !dataA){ return -1; }
                return 0;
            }
		},
		fetch: function (options) {
			var self = this;
			self.notificationType = options.getCurrent ? "getNotifications" : "getArchivedNotifications";
			this.isCurrent = options.getCurrent;
			return Backbone.Collection.prototype.fetch.call(this, _.extend({
				data: {
					maxToReturn: 100, eventName: "hpi_notification"
				},
				type: 'GET',
				reset: true,
				url: app.serviceUrlRoot + "/notification/" + self.notificationType
			}, options));
		}
	});

	Notification.View = Backbone.Marionette.ItemView.extend({
        template: "common/notification",
        tagName: "tr",
		events: {
			"click #stageLink" : "navigateToStage",
			"click .notificationBtn" : "deleteNotification"
		},
		serialize: function(){
			return {
                "attributes": this.model.attributes
			};
		},
		navigateToStage: function() {
			// check this
			Notification._navigateToStage(this.model.attributes.attachedObjectId);
		},
		deleteNotification: function() {
			var deleteEndpoint = this.model.get('archived') ? "deleteArchivedNotification" : "deleteNotification";
			var deleteUrl = app.serviceUrlRoot + "/notification/" + deleteEndpoint + "?notificationId=" + this.model.get('objectId');
			
			this.model.destroy({ 
				url: deleteUrl,
				wait: true,
				error: function(message) {
                    app.trigger("alert:error", {
                        header: window.localize("common.notifications.failed.header"),
                        message: window.localize("common.notifications.failed.message") + message.statusText
					});
				}
			});
			
		}
	});
	// here for overriding if you don't want the default behavior of showing the trac chooser and allowing the
	// user to choose which trac to use for displaying the object in the stage
	Notification._navigateToStage = function(id) {
		// don't really want to update the URL, the user doesn't have to see this messiness
		app.routers.main.stageSimple(id);
	};
	
	return Notification;

});
