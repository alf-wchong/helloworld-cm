// OC module
define([
  // Application.
  "app",
  "knockback",
  "libs/backbone.paginator"
],

// Map dependencies from above array.
function(app, kb){

  // Create a new module.
  var OC = app.module();

	OC.otcTypes = [];

	/****private helper methods *****/

	/**
	* Formats a single value based on the filter property on that attribute's config
	* Either returns the formatted value or puts a jQuery deferred object on an array
	* of deferred objects.
	*
	* @param propValue - value to be formatted
	* @param attrConfig - configuration of the attribute whose value is being formatted
	* @param options - object passed in with various options that affects how/if a value is formatted
	* @param jqXhrs - array of jQuery deferred objects that an individual deferred object should be
	*				put on if the formatting process involves an ajax call
	* @param properties - full list of properties for the object. If you are using an ajax call,
	*				you should directly modify your attribute's value in this array
	*/
	OC._formatSingleValue = function(propValue, attrConfig, options, jqXhrs, properties)
	{
		if(attrConfig.get("filter") === "date"){
			OC.setISODateProp(propValue, attrConfig, properties);
			propValue = OC.getDateToFormat(propValue, attrConfig, properties);
			jqXhrs.push(app.context.dateService.getFormattedDate(propValue).done(function(formattedDate){
				properties[attrConfig.get("ocName")] = formattedDate;
			}));
		} else if(attrConfig.get("filter") === "datetime"){
			OC.setISODateProp(propValue, attrConfig, properties);
			propValue = OC.getDateToFormat(propValue, attrConfig, properties);
			jqXhrs.push(app.context.dateService.getFormattedDatetime(propValue).done(function(formattedDatetime){
				properties[attrConfig.get("ocName")] = formattedDatetime;
			}));
		} else if(attrConfig.get("filter") === "time"){
			OC.setISODateProp(propValue, attrConfig, properties);
			propValue = OC.getDateToFormat(propValue, attrConfig, properties);
			jqXhrs.push(app.context.dateService.getFormattedTime(propValue).done(function(formattedTime){
				properties[attrConfig.get("ocName")] = formattedTime;
			}));
		} else if (attrConfig.get("filter") === "mimeType"){
			//only alfresco should use mimetype filter, this is assuming that propValue is actually cm:content
			if(propValue instanceof Object){
				properties[attrConfig.get("ocName")] = propValue.mimetype;
			}else{
				//if its not an object, idk why its configured but lets just keep the previous value
				properties[attrConfig.get("ocName")] = propValue;
			}
			
		} else if (attrConfig.get("filter") === "userDisplayName") {
			//the userDisplayName filter is intended for items that come back as a username;
			//we'll want to take the loginName and return the displayName
			if (propValue) {
				var loginName = propValue;
				var userDisplayNameXhr = app.context.filterService.getUserDisplayName(loginName, function(displayUsername){
					properties[attrConfig.get("ocName")] = displayUsername;
				});

				jqXhrs.push(userDisplayNameXhr);
			}
		} else if (attrConfig.get("filter") === "picklist") {

			// TODO pull picklist name from a new config item - (https://github.com/tsgrp/HPI/issues/1923)
			var picklistName = "OTCFilterPicklist";

			if (propValue) {
				var filterValueThroughPicklistXhr = app.context.filterService.filterValueThroughPicklist(
					propValue, 
					picklistName, 
					function(val){ properties[attrConfig.get("ocName")] = val; }
				);

				jqXhrs.push(filterValueThroughPicklistXhr);
			}
		}
		else{
			return propValue; // nothin to format!
		}
	};

	OC.setISODateProp = function(propValue, attrConfig, properties){
		//this is a bit weird, but we were seeing dates change when we would re-format them in tableview (due to the timezone
		//constantly getting re-applied) with something like a sort - we need to hold onto the true isoString of the date BEFORE
		//we overwrite the date field and use that for all subsequent formats

		//this will be true the first time this is hit when something like tableview is initialzed, let's create
		//a new property on the oco that only this code knows about which is the true isoString of the date
		if (_.isNumber(propValue)) {
			properties[attrConfig.get("ocName") + "_ISO"] = propValue;
		}
	};

	OC.getDateToFormat = function(propValue, attrConfig, properties){
		//check here is the oco has an ISO value on it for current date, and if so, prefer that property's value to be passed for formatting
		var dateToFormat;
		if (properties[attrConfig.get("ocName") + "_ISO"]) {
			dateToFormat = properties[attrConfig.get("ocName") + "_ISO"];
		} else {
			dateToFormat = propValue;
		}
		return dateToFormat;
	};

	var _objectTypeConfigCallback = function(ocObject, options, objectTypeConfig, deferred){
		var jqXhrs = [];
		//get a copy of the properties
		var properties = $.extend(true, {}, ocObject.get('properties') );

		//if no object type config was found, don't format anything
		if(!objectTypeConfig){
			deferred.resolve(properties);
			return deferred.promise();
		}

		// right now we're just going to parse the date!
		objectTypeConfig.get("attrs").each(function(attrConfig){

			if(attrConfig.get("isRepeating") === "true")
			{
				var _formattedValues = [];
				_.each(properties[attrConfig.get("ocName")], function(propValue){
					_formattedValues.push(OC._formatSingleValue(propValue, attrConfig, options, jqXhrs, properties));
				});
				properties[attrConfig.get("ocName")] = _formattedValues;
			}
			else
			{
				var formattedVal = OC._formatSingleValue(properties[attrConfig.get("ocName")], attrConfig, options, jqXhrs, properties);
				//since some formatting relies on async ajax calls, 
				//we may not actually return the value, so make sure
				//we have one so we don't accidentally override what an
				//async call may be setting
				if(formattedVal){
					properties[attrConfig.get("ocName")] = formattedVal;
				}
			}
			
		});
		
		if(jqXhrs.length > 0 ) {
			$.when.apply(null, jqXhrs).done(function(){
				if(options.modifyObject){
					ocObject.set("properties", properties);
				}
				deferred.resolve(properties);
			});
		}
		else
		{
			deferred.resolve(properties);
		}
		return deferred.promise();
	};

	var _formatValues = OC._formatValues = function(ocObject, options){
		var deferred = $.Deferred();
		if (options.objectTypeConfig){
			_objectTypeConfigCallback(ocObject, options, options.objectTypeConfig, deferred);
		}
		else{
			app.context.configService.getAdminTypeConfig(ocObject.get("objectType"), function(result){
					_objectTypeConfigCallback(ocObject, options, result, deferred);
				});
		}
		return deferred;
	};

  // Default Model.
  OC.OpenContentObject = Backbone.Model.extend({
		idAttribute: "objectId",
		url: function() { 
			return app.serviceUrlRoot + "/openContentObject?id=" + this.id;
		},
		defaults: function() { 
			return {
				objectType: "",
				properties: [],
				relations: []
			};
		},
		/* BLACKLIST
		Add any attributes here that you do not want syncing back to the server, usually data
		that is reserved to be used as "read only" or data that is set after the original object
		is retrieved.
			~ mbowen
		*/
		blacklist: ["relations", "children"],
		// toJSON is modified to omit the blacklisted objects. If there are any issues with serialization
		// please see mbowen for more info.
		toJSON: function() {
			return _.omit(this.attributes, this.blacklist);
		},
		getChildren: function(options) {		
			// set up the children collection 
			var defaults = {
				mimetypeFilters : undefined,
				includeRenditionable : "false"
			};

			options = _.extend(defaults, options); 

            var childCollection;
			if(options.mimetypeFilters && options.mimetypeFilters.length > 0){
				childCollection = new OC._Children({id: this.id, mimetypeFilters: options.mimetypeFilters, includeRenditionable : options.includeRenditionable});
            }else{
                childCollection = new OC._Children({id: this.id});
            }
			
			childCollection.id = this.id;
			childCollection.mimetypeFilters = options.mimetypeFilters;
			childCollection.includeRenditionable = options.includeRenditionable;
			this.set("children", childCollection);
			//don't cache the result, we want this fresh
			//each time, specifically added for folder notes action
			return childCollection.fetch({
				cache: false,
				global: false
			});
		},
		/**
		*	getRelatedObjects
		*	relationName: the relationship name
		*	parentOrChild: direction of the relationship - parent, child, or if left blank will get both
		**/
		getRelatedObjects: function(relationName, parentOrChild) { 
			
			var self = this;
			if(!parentOrChild || parentOrChild === null) {
				parentOrChild = "both";
			}
			
			var relation = new OC.PageableRelatedObjects({});

			relation.id = self.id;
			relation.relationName = relationName;
			relation.parentOrChild = parentOrChild;

			self.get("relations").push(relation);

			return relation.fetch({
				global: false
			});
		},
		removeRelation: function(associatedObject, parentOrChild, relationName, options) {
			var self = this;
			var actionId = "removeRelationship";
			var childId = null;
			var parentId = null;
			if(parentOrChild === "parent") { 
				// the incoming associatedObject is the parent
				parentId = associatedObject.id;
				childId = self.id;	
			}
			else {
				// the oc object we're operating on is the parent
				parentId = self.id;
				childId = associatedObject.id;
			}
			
			// try to remove relationships from both directions..
			$.ajax({
				//url: app.serviceUrlRoot + "/action/execute?" + "actionId=" + actionId + "&objectId=" + parentId + "&otherObject=" + childId + "&relationName=" + relationName,
				url: app.serviceUrlRoot + "/action/execute?id=" + parentId,
				contentType: "application/json",
				data: JSON.stringify({
					name: actionId,
					parameters: {
						objectId: parentId,
						otherObject: childId,
						relationName: relationName
					}
				}),
				type: "POST",
				success: function() { 
					$.ajax({
						url: app.serviceUrlRoot + "/action/execute?id=" + childId,
						contentType: "application/json",
						data: JSON.stringify({
							name: actionId,
							parameters: {
								objectId: childId,
								otherObject: parentId,
								relationName: relationName
							}
						}),
						type: "POST",
						success: function(data) { 
							app.log.debug("Removed Relation Successfully...");
							app.trigger("alert:changeNotification", "alert-success", window.localize("modules.common.oc.successfullyRemoved"), "#content-outlet");
							options.success(data);
						},
						error: function(data) { 
							app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.common.oc.failedToRemove"), "#content-outlet");
							options.error(data);
						},
						global: false
					});	
				},
				error: function(data) { 
					app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.common.oc.failedToRemove"), "#content-outlet");
					options.error(data);
				},
				global: false
			});
			
		
			
		},
		getThumbnail: function(size, callback) { 
			
			var sizes = {
				small : "hpiSmall",
				medium : "hpiMedium",
				large : "hpiLarge"
			};
			
			var self = this;

			// call to check if it exists - if so: return the URL
					var thumbUrl = app.serviceUrlRoot + "/content/getThumbnail";
					thumbUrl += "?objectId=" + self.id + "&thumbnailName=" + sizes[size];
					callback(thumbUrl);



		},

		canWrite: function(callback) { 
			var self = this;
			$.ajax({
				url: app.serviceUrlRoot + "/permission/write?id=" + encodeURIComponent(self.id),
				type: "GET",
				success: function(data) { 
					callback(data);
				}, 
				error: function() {
					app.log.error("Error when determining write permissions...");
				},
				global: false
			});
		},
		getContentUrl: function(callback) { 
			var self = this;
			var contentUrl = app.serviceUrlRoot + "/content/content?id=" + encodeURIComponent(self.id) + "&download=true";
			callback(contentUrl);
		},
		/*
		* This function formats only !repoEditable props
		* If you have a repoeditable prop, you're expected to hook it up to a
		* control that handles the displaying of the formatted value, but the
		* maintains the correct underlying data. E.g. Datapicker.
		*/
		formatProperties: function(config){
			var self = this;
			if (config){
				//store unformatted values in case we need to revert
				return _formatValues(self, {modifyObject: true, objectTypeConfig: config});
			}
			else {
				//stor unformatted values in case we need to revert
				return _formatValues(self, {modifyObject: true});
			}
		},
		/**
		* This function formats all the properties as nice displayble strings, but as
		* such makes the object unsuitable to send back to OC.
		* 
		*/ 
		formatPropertiesReadOnly: function(config){
			var self = this;
				self.formatted = true;
				self.url = function(){
					throw window.localize("modules.common.oc.thisObject");
				};
				if (config){
					return _formatValues(self, {all : true, modifyObject: true, objectTypeConfig: config});
				}
				else{
					return _formatValues(self, {all : true, modifyObject: true});
				}
			
		},
		getFormattedProperties: function(config){
			var self = this;
			if (config){
				return _formatValues(self, {all : true, objectTypeConfig: config});
			}
			else{
				return _formatValues(self, {all : true});
			}
		}

	});
	
	//internal method for fetching relayted children
	OC._Children = Backbone.PageableCollection.extend({
		model: OC.OpenContentObject,
        state: {
            pageSize: 500,
            firstPage: 0
        },
		
		url : function() { 
			var urlString = app.serviceUrlRoot + "/content/getChildren?id=" + this.id;
            if(this.mimetypeFilters){
				urlString += "&mimetypeFilters=" + this.mimetypeFilters;
			}
			if (this.includeRenditionable){
				urlString += "&includeRenditionable=" + this.includeRenditionable;
			} 
			return urlString;
        }
    });

	//Collection of OCOs
	OC.OpenContentObjectCollection = Backbone.Collection.extend({
		model: OC.OpenContentObject,
		initialize: function(options){
			this.ids = options ? options.id || options.ids : [];
		},
		url: function() {
			//Url to for a collection of OCOs.
			return app.serviceUrlRoot + "/openContentObjects?ids=" + encodeURIComponent(JSON.stringify(this.ids));
		}
	});

	OC.Folder = Backbone.Model.extend({
		defaults: function() { 
			return {
				objectId: "",
				objectName: ""
			};
		}
	});

	OC.User = Backbone.Model.extend({
		idAttribute: "loginName",
		initialize: function(){
			this.failQuietly = false;
			if (this.get('failQuietly') && _.isBoolean(this.get('failQuietly'))) {
				this.failQuietly = this.get('failQuietly');
			}

			if (this.attributes && _.isBoolean(this.attributes.includeGroups)) {
				this.includeGroups = this.attributes.includeGroups;
			} else {
				this.includeGroups = true;
			}
			this.getGroups = function(){
				this.includeGroups = true;
				return this.fetch();
			};
			
		},
		url: function(){
			app.log.debug("Fetching user, includeGroups: " + this.includeGroups);
			var url = app.serviceUrlRoot+ "/users/user/" + encodeURIComponent(this.id) + "/"; // trailing slash - see https://jira.springsource.org/browse/SPR-6164 (issue where dot in trailing path variable is truncated at last .)
			url = url + "?failQuietly=" + this.failQuietly;

			if(this.includeGroups){
				url = url + "&includeGroups=true";
			}
			return url;
		},
		//extending the fetch method to allow caching
		//if you want us to reload the user send in the option reload:true
		fetch: function(options){
			var that = this;
			//'adapted' from here https://gist.github.com/tbranyen/3950130
			options = options || {};
			// Save a reference to the original deferred.
			var oldDef = this._def;
			this.hasGroups = false;
		 
			// Return early if we already fetched/there was no reload request/ and we have the groups or don't want them
			if (this._def && !options.reload && !this.reload && (this.hasGroups || this.gettingGroups || !this.includeGroups) ) {
				return this._def.promise();
			}
			if(this.includeGroups){
				this.gettingGroups = true;
			}
		 
			// If a deferred doesn't exist, create one.  If the clear flag is provided,
			// jump in to create a new deferred.
			this._def = $.Deferred();
		 
			// If the clear was provided and there is an existing deferred, resolve it
			// once this has resolved.
			if (options.reload && oldDef) {
				this._def.done(oldDef.resolve);
			}
			
			// Call the original `fetch` method and store its return value (jqXHR).
			var req = Backbone.Model.prototype.fetch.apply(this, arguments);
		 
			// Once the request has finished, resolve this deferred.
			req.done(_.bind(function() {
				this._def.resolveWith(this, [this]);
				if(that.includeGroups){
					that.includeGroups = false;
					that.hasGroups = true;
				}
			}, this));
		 
			// Return the deferred to wait with.
			return this._def.promise();
		},
		parse: function(response) { 
			//return an object labeled groupNames
			if(response){
				response.groupNames = _.pluck(response.groups,'authorityId');
			}
			return response;
		}
	});



// view model that represents a relation in OC
    OC.RelationViewModel = function(model, options) {

        var self = this;
        self.config = options.config;
        self.ocObject = options.ocObject;
        // lets just do this manually to keep it clean
        //kb.ViewModel.prototype.constructor.apply(this, arguments, options);
        //self.name = kb.observable(model, "name");
        self.relationName = ko.observable(model.relationName);
        self.type = ko.observable(model.parentOrChild);
        self.items = ko.observableArray();
        self.name = ko.observable(self.config.get("name"));

        self.items = kb.collectionObservable(model.get("objects"), {
            view_model: OC.RelatedObjectViewModel
        });

        self.emptyText = function() { 
            return "No " + self.name() + " available.";
        };

        self.removeRelation = function(item) {
            
            app.trigger("alert:confirmation", {
                message: window.localize("modules.common.oc.areYouSure"),
                header: window.localize("modules.common.oc.confirmRemoval"),
                confirm: function() { 
                    self.ocObject.removeRelation(item.model, self.type(), self.relationName(), {
                        success: function() { 
                            app.log.debug(window.localize("modules.common.oc.triggeringRefresh"));
                            app.trigger("refreshRelationships");
                        },
                        error: function() {
                        }
                    });
                }
            });
            
        };

        return self;
    };	

    // view model that represents a related object that belongs to a relation
    OC.RelatedObjectViewModel = kb.ViewModel.extend({
        constructor: function(model) { 
            
            var self = this;

            kb.ViewModel.prototype.constructor.apply(self, arguments); 

            self.properties = kb.observable(model, "properties");

            self.model = model;

            self.thumbnailUrl = ko.observable();

            // make sure the id is set 
            model.id = model.get("objectId");

            model.getThumbnail("medium", function(url) {
                self.thumbnailUrl(url);
            });

            self.downloadAsset = function() {
                var iframe = document.getElementById("hiddenDownloader");
                if (iframe === null) {
                    iframe = document.createElement('iframe');
                    iframe.id = "hiddenDownloader";
                    iframe.style.visibility = 'hidden';
                    document.body.appendChild(iframe);
                }
                iframe.src = app.serviceUrlRoot + "/content/content?id=" + model.id +"&download=true";
            };

            self.showAssetDetail = function() { 
                var url = "details/" + app.context.configName() + "/" +encodeURIComponent(model.id);
                Backbone.history.navigate(url, {trigger: true});
            };

            return self;

        }
    });

    OC.PageableRelatedObjects = Backbone.PageableCollection.extend({
        mode: "client",
        model: OC.OpenContentObject,
        state: {
            pageSize: 500,
            firstPage: 0
        },
        url: function() {
            if (this.parentOrChild === "Children") {
                return app.serviceUrlRoot + "/content/getChildRelations?id=" + this.id + "&relationName=" + this.relationName + "&textContentRequest=" + this.textContentRequest;
            } else if (this.parentOrChild === "Parents") {
                return app.serviceUrlRoot + "/content/getParentRelations?id=" + this.id + "&relationName=" + this.relationName;
            } else if (this.parentOrChild === "Siblings") {
                return app.serviceUrlRoot + "/content/getRelations?id=" + this.id + "&relationName=" + this.relationName + "&direction=sibling";
			} else if (this.parentOrChild === "allRelations") {
                return app.serviceUrlRoot + "/content/getRelations?id=" + this.id + "&relationName=" + this.relationName;
			}
		}
    });

  // Return the module for AMD compliance.
  return OC;

});
