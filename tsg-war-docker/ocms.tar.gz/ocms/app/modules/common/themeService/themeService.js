// Repotype module
define([
	"app"
],

function(app) {
	var Theme = app.module();

	// Default Model.
	Theme.Model = Backbone.Model.extend({
		headerCss: function(){
			var foundCss = $('#customAppCss');
			if(!foundCss[0]){
				app.context.configService.getApplicationConfig(_.bind(this.executeHeaderCssForApplicationConfig, this));
			}
		},
		executeHeaderCssForApplicationConfig: function(configs){
			var innerHtmlStyle = '';
			if(configs.get('navigationBarCssTop') && configs.get('navigationBarCssBottom')){	
				var navigationBarColorTop = configs.get('navigationBarCssTop');	
				var navigationBarColorBottom = configs.get('navigationBarCssBottom');	

				innerHtmlStyle += 'div.navbar .container-fluid {\n' +
										'\tbackground: -webkit-linear-gradient(' + navigationBarColorTop  + ' , ' + navigationBarColorBottom + ');\n' +
										'\tbackground: -moz-linear-gradient( ' + navigationBarColorTop  + ' , ' + navigationBarColorBottom + ');\n' +
										'\tbackground: linear-gradient(' + navigationBarColorTop  + ' , ' + navigationBarColorBottom + ');\n' +
									'}\n' +
									'div.navbar .navbar-inverse {\n' +
										'\tborder-color: ' + navigationBarColorBottom  + ';\n' +
									'}\n';
			}
			
			if(configs.get('buttonCss') && configs.get('primaryBtnTextColor')){	
				var buttonColor = configs.get('buttonCss');	
				var primaryBtnTextColor = configs.get('primaryBtnTextColor');

				innerHtmlStyle += 'a.btn.btn-hpi,\n' +
									'button.btn-hpi,\n' + 
									'label.btn-hpi {\n' +
										'\tcolor: ' + primaryBtnTextColor + ';\n' +
										'\tbackground-color: ' + buttonColor + ';\n' +
										'\tbackground-image: linear-gradient(to bottom, ' + buttonColor + ', ' + buttonColor + ');\n' +
										'\tborder-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);\n' +
									'}\n' +
									'.btn-hpi:hover {\n' +
										'\tfilter: brightness(60%);\n' +
									'}\n' +
									'.btn-hpi:focus,\n' + 
									'.btn-hpi:active, \n' +
									'.btn-hpi.active {\n' +
										'\tcolor: ' + primaryBtnTextColor + ';\n' +
										'\tbackground-color: ' + buttonColor + ';\n' +
										'\tbackground-image: linear-gradient(to bottom, ' + buttonColor + ', ' + buttonColor + ');\n' +
										'\tborder-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);\n' +
									'}\n' +
									'.badge.badge-hpi {\n' +
										'\tcolor: ' + primaryBtnTextColor + ';\n' +
										'\tbackground-color: ' + buttonColor + ';\n' +
										'\tbackground-image: linear-gradient(to bottom, ' + buttonColor + ', ' + buttonColor + ');\n' +
										'\tborder-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);\n' +
									'}\n' +
									//this addition is for toss across styling. Specifically the buttons for clicking to toss over
									'.toss-across-click-section{\n'+
										'\tcolor: ' + primaryBtnTextColor + ';\n' +
										'\tbackground-color: ' + buttonColor + ';\n' +
										'\tbackground-image: linear-gradient(to bottom, ' + buttonColor + ', ' + buttonColor + ');\n' +
										'\tborder-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25);\n' +
									'}\n' + 
									'.dashboard ul#navTabs li.active a{\n'+
										'\tbackground-color: ' + buttonColor + ';\n' +
									'}\n';
			}
			
			if(configs.get('linkCss')){	
				var linkColor = configs.get('linkCss');	

				innerHtmlStyle += 'a,\n' +
									'a:link,\n' +
									'a:visited {\n' +
										'\tcolor: ' + linkColor + ';\n' +
									'}\n' +
									'a:hover {\n' +
										'\tcursor: pointer;\n' +
									'}\n' +
									'a.btn {\n' +
										'\tcolor: ' + linkColor + '\n' +
									'}\n' +
									// The addition to table view's link format changes are very specific, they are taken from an update that TSG made in tableview.styl sometime before to always display links in tableview as a blue color.
									'.table-view div.tableHolder .link,\n' +
									'.table-view div.tableHolder .myGrid .slick-cell a.btn-link {\n' +
										'\tcolor: ' + linkColor + ' !important;\n' +
									'}\n';
			}
			
			if(configs.get('headerCss')){	
				var headerColor = configs.get('headerCss');	

				innerHtmlStyle += 'h1,\n' +
									'h2,\n' +
									'h3,\n' +
									'h4,\n' +
									'h5 {\n' +
										'\tcolor: ' + headerColor + ';\n' +
									'}\n';
			}
			if(configs.get('selectedCss')){	
				var selectedColor = configs.get('selectedCss');		

				innerHtmlStyle += 'ul.nav.navbar-nav li.active a.glyphicons {\n' +
										'\tbackground-color: ' + selectedColor + ';\n' +
									'}\n';
			}
			

			if(configs.get('hoverTextCss') && configs.get('navigationBarTextCss')){	
				var hoverColor = configs.get('hoverTextCss');	
				var headerTextColor = configs.get('navigationBarTextCss');	
				/*jshint multistr: true */		  
				innerHtmlStyle += 'ul.nav.navbar-nav li a.glyphicons {\n' +
										'\tcolor: ' + headerTextColor + ';\n' +
									'}\n' +
									'ul.nav.navbar-nav li.active a.glyphicons {\n' +
										'\tcolor: ' + hoverColor + ';\n' +
									'}\n' +
									'ul.nav.navbar-nav li a.glyphicons :hover {\n' +
										'\tcolor: ' + hoverColor + ';\n' +
									'}\n' +
									'ul.nav.navbar-nav li p.navbar-text {\n' +
										'\tcolor: ' + headerTextColor + ';\n' +
									'}\n' ;
			}
			// The two lines below are a temporary fix. These lines prevent the color selected for buttons to be applied to other HTML elements that are STYLED as buttons, but really don't server the functionality of buttons. These elements should ideally be changed to be <div> or other elements, not buttons.
			if (configs.get('secondaryBtnColor') && configs.get('secondaryBtnTextColor')) {
				var secondaryBtnColor = configs.get('secondaryBtnColor');
				var secondaryBtnTextColor = configs.get('secondaryBtnTextColor');
				innerHtmlStyle += '.btn.btn-default {\n' +
					'\tcolor: ' + secondaryBtnTextColor + ';\n' +
					'\tbackground-color: ' + secondaryBtnColor + ';\n}\n';
			}
			
			var style = document.createElement('style');
			style.type = 'text/css';
			style.id = 'customAppCss';
			style.innerHTML = innerHtmlStyle;
			document.getElementsByTagName('head')[0].appendChild(style);
		}
	});
	return Theme;
});
