define([
        "app",
        "underscore"
    ],
    function(app, _) {
        "use strict";
        
        //Module to handle gathering workflow info.
        
        var WorkflowUtil = {};

        WorkflowUtil._getTasksFromWorkflowInstanceIds = function(resultDef, limit, includeNonWhiteListTasks){
            var self = this;
            this.deferreds = [];

            //Check to see if there are any workflow instance ids before making the second ajax call
            if(this.wfInstances.length > 0){
                _.each(this.wfInstances, function(wfInstanceId) {
                    var def = $.Deferred();
                    self.deferreds.push(def);
                    $.ajax({
                        url: app.serviceUrlRoot + "/workflow/gettasks?workflowInstanceId=" + wfInstanceId + "&limit=" + limit + "&includeNonWhiteListTasks=" + includeNonWhiteListTasks,
                        success: function(tasks) {
                            //check to see if the tasks array returned is greater than 1, if so set it to the tasks variable
                            //most cases there is only one workflow instance id returned, but in the case of AW Approve there
                            //is two ids returned. The parent process id will return nothing for the task list, but the subprocess id will.
                            if (tasks.length > 0){
                                self.tasks = tasks;
                            }
                            def.resolve();
                        },
                        error: function() {
                            app[self.myHandler].trigger("loading", false);
                            app[self.myHandler].trigger("showError", window.localize("modules.common.workflowUtil.failedToRetrieve"));
                        }
                    });
                });    
            } else{
                //Resolving our deferred with an empty string.
                resultDef.resolve("");
            }

            $.when.apply($, this.deferreds).done(function(){
                resultDef.resolve(self.tasks);
            });

            return resultDef;
        };

        //Function that returns a deferred's promise so we can return the "result" if there is a workflow that
        //has been started on a document.
        WorkflowUtil.getTasks = function(objectId, limit, includeNonWhiteListTasks){
            var self = this;
            var resultDef = $.Deferred();

            //Check to see if a limit is set, if not default to -1 meaning to bring back all tasks
            this.limit = limit ? limit : -1;

            this.includeNonWhiteListTasks = includeNonWhiteListTasks ? includeNonWhiteListTasks : false;

            this.tasks = [];
            
            //The taskId that is returned from the first server call.
            this.wfInstances = [];
          
            //Getting the taskId
            $.ajax({
                url: app.serviceUrlRoot + "/workflow/getWorkflowInstanceInfo?objectId=" + objectId,
                success: function(result) {
                    _.each(result, function(workflowInstanceInfoMap){
                        if (workflowInstanceInfoMap.processId){
                            self.wfInstances.push(workflowInstanceInfoMap.processId);
                        }
                    });
                },
                error: function() {
                    app[self.myHandler].trigger("loading", false);
                    app[self.myHandler].trigger("showError", window.localize("modules.common.workflowUtil.failedToRetrieve"));
                },
                global: false
            }).done(function(){
                resultDef = WorkflowUtil._getTasksFromWorkflowInstanceIds(resultDef, self.limit, self.includeNonWhiteListTasks);

            });
            
            //Returning our promise.
            return resultDef.promise();
        };
                
        //View that generates a "table" of workflow properties.
        WorkflowUtil.View = Backbone.Layout.extend({
            template: "common/workflowutil",
            events: {},
            initialize: function(options) {
                this.options = options;
                this.objectId = options.objectId;
                this.multipleCandidateGroups = options.multipleCandidateGroups ? options.multipleCandidateGroups : false;
                this.attrToShow = (options.attrToShow === undefined ? "" : options.attrToShow);
			
                this.groupAssigneeExists = false;

                //Kicks off the action -- getting the task ID is the first step.
                this.getTaskId(this.objectId);
            },
            //Gets the task id associated with the content on the stage.
            getTaskId: function(objectId) {
                var self = this;
                WorkflowUtil.getTasks(objectId, 1, true).done(function (wfTask) {
                    self.getWorkflowOwner(wfTask[0]);
                });
            },
            //Gets the task (and thus the assignee) from the task ID.
            getWorkflowOwner: function(task) {
                //The workflow is assigned to a group.
                if (task.candidateGroups.length > 0) {
                    // The really weird case where you have group assignees set as a repeating attr
                    // allowing the user to choose which group to acquire as. If that's the case we don't
                    // want to show the group assignee field no matter what to avoid confusion.
                    if (!this.multipleCandidateGroups) {
                        this.groupAssignee = task.candidateGroups[0];
                        this.groupAssigneeExists = true;
                        this.render();
                    }
                }
                
                this.renderUserName(task.initiator, 'initiator');    
                this.wfName = task.processName;
                this.folderName = app.context.container.get("properties").objectName;
                
                if(task.allVariables.wf_reviewOutcome){
                    this.decision = task.allVariables.wf_reviewOutcome;
                }

                //The workflows name
                if(task.name){
                    this.taskName = task.name;
                }
                
                // If attrToShow is passed in, set attachedDocument with client chosen attribute value
                // otherwise, default to objectName 
                if(!_.isEmpty(this.attrToShow)) {
                    if (app.context.document.get("properties")[this.attrToShow]) {
                        this.attachedDocument = app.context.document.get("properties")[this.attrToShow];
                    }
                } else if(app.context.document.get("properties").objectName) {
                    this.attachedDocument = app.context.document.get("properties").objectName;
                }
        
                //"Setting the result" (this simply resovles our deferred, fulfilling our promise to do so.)
                this.setResult(task);
                    
            },
            //Gets the display name from the username for UI purposes.
            renderUserName: function(userName, prop) {
                var self = this;
                app.context.filterService.getUserDisplayName(userName, function(fullName) {
                    self[prop] = fullName; 
                    self.render();
                });
            },
            //Setting the result by resolving our result deferred.
            setResult: function(result){
                if(this.resultDef){
                    this.resultDef.resolve(result);
                }
            },
            //Returing a promise that will get resolved when the approprite calls have been made and returned.
            getResult: function(){
                //Putting the deferred on 'this' because we need to access it outside this function.
                this.resultDef = $.Deferred();
                return this.resultDef.promise();
            },
            serialize: function() {
                return {
                    wfName: this.wfName,
                    taskName: this.taskName,
                    folderName: this.folderName,
                    attachedDocument: this.attachedDocument,
                    initiator: this.initiator,
                    groupAssigneeExists: this.groupAssigneeExists,
                    groupAssignee: this.groupAssignee,
                    decision: this.decision,
                    decisionExists: this.decision ? true : false
                };
            }
        });

        return WorkflowUtil;
    });