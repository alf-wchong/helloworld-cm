define([
	'app',
	'modules/common/typeahead',
	'handlebars'
], function(app, HPITypeahead, Handlebars){

	var QueryableTypeahead = HPITypeahead.extend({
		template: 'common/typeahead/queryabletypeahead',
		events: {
			'click .clearSearchBtn' : 'clear'
		},
		initialize: function(config){
			this.options = (config.options instanceof Backbone.Collection ? _.pluck(config.options.models, 'attributes') : config.options) || [];
			if(!this.options){
				this.options = [];
			}
			this.selected = config.selected || '';
			this.placeholder = config.placeholder || '';
			this.displayKey = config.displayKey || 'displayName';
			this.searchOn = config.searchOn || 'displayName'; //fallback to displayName
			this.clearable = config.clearable !== undefined ? config.clearable : true;
			this.minLength = config.minLength || 1;
			this.limit = config.limit || 5;
			if(config.queryUrl.indexOf("?") === -1){
				this.queryUrl = config.queryUrl + "?query=%QUERY";
			} else {
				this.queryUrl = config.queryUrl + "&query=%QUERY";
			}
			
			//Action using queryable typeahead is responsible for maintaining this array.
			//This allows previously selected results to be omitted from the suggestions list
			//If left blank, all suggestions are listed as expected.
			this.selectedObjectNames = [];
			this.buildSearchIndex();
		},
		buildSearchIndex: function(){
			var reinit = this.datasource;
			/* jshint ignore:start */
			var self = this;
			this.datasource = new Bloodhound({
				datumTokenizer:function(datum){
					var tokens = datum ? Bloodhound.tokenizers.whitespace(datum[self.searchOn]) : [];
				    _.each(tokens,function(value){
	                  	//push each character and value!
	                  	//onto the tokens array for mid-string matches
	                  	_.each(value, function(character, index){
	                  		tokens.push(character);
	                  		tokens.push(value.substr(index, value.length));
	                  	}, this);
            	  	});
            	  	return tokens;
			    },
			    queryTokenizer: Bloodhound.tokenizers.whitespace,
			    remote:{
			    	url: this.queryUrl,
			    	filter: function(results){
			    		return $.map(results, function(user){
			    			return _.each(user, function(prop, key){
			    					return {key: prop};
			    			});
			    		});
			    	}
			    },
			    limit: this.limit
			});
			/* jshint ignore:end */ 
			return this.datasource.initialize(reinit);
		},
		onBlur: function(){
			this.showDropDown = false;
			this.$('.typeahead-dropdown-' + this.cid).hide();

			//verify that the user's input matches an option
			var selected = this.typeaheadEl.typeahead('val');
			this.datasource.get(selected, $.proxy(function(suggestions){
				if(!suggestions || suggestions.length === 0){
					this.trigger('change:selected'); //proc empty selection	
				}else{
					//looking for an exact match
					var valid = false;
					_.each(suggestions, function(suggestion){
						if(selected.toLowerCase() === suggestion.displayName.toLowerCase()){
							valid = true;
							return;
						}
					}, this);
					if(!valid){
						this.trigger('change:selected'); //no match found, proc empty selection	
					}
				}
			}, this));
		},
		setOption: function(value, updateTypeahead){
			//var self = this;
			var rendered = this.before();
			var selectedValue = value;
			//get whole option
			if(selectedValue instanceof Object){
				this.selected = selectedValue;
			}else{
				this.selected = '';
			}
			if(rendered && updateTypeahead && this.selected){
				this.typeaheadEl.typeahead('val', this.selected.displayName);
			}
			this.trigger('change:selected', this.selected);
			return this;
		},
		clear: function(evt){
			if(evt){
				//might be deployed inside a form - prevent form submission
				evt.preventDefault();
			}
			//clear input
			this.typeaheadEl.typeahead('val','');
			//notify any stakeholders
			this.trigger('typeahead:clear');
		},
		afterRender: function(){
			var self = this;
			this.typeaheadEl = this.$('.typeahead-' + this.cid);

			this.typeaheadEl.typeahead({
			    hint: true,
			    highlight: true,
			    minLength: this.minLength
			},
			{
			    displayKey: this.displayKey || 'displayName',
			    //This allows us to filter out suggestions that have already been selected
			    //Selected options are tracked on the typeahead object
			    source: function(query, cb){
			    	self.datasource.get(query, function(suggestions){
			    		cb(self.filterOutSelected(suggestions));
			    	});
			    },
			    templates: {
					empty: this.noResultTemplate(),
				    suggestion: this.searchResultTemplate()
				}
			}).on('typeahead:selected ', $.proxy(function (obj, datum) {
				this.setOption(datum, true);
			}, this)).on('blur', $.proxy(function (){
				if(!this.typeaheadEl.val()){
					this.setOption(undefined, false);
				}
			}, this)).on('typeahead:opened ', $.proxy(function () {
				this.showDropDown = false;
				this.$('.typeahead-dropdown-' + this.cid).hide();
			}, this)).on('typeahead:autocompleted', $.proxy(function (obj, datum) {
				this.setOption(datum, true);
			}, this)).on('typeahead:closed', $.proxy(function(){
				if(!this.typeaheadEl.val()){
					this.setOption(undefined, false);
				}
			}, this));
		},
		filterOutSelected: function(suggestions){
			var self = this;
			return $.grep(suggestions, function(suggestion){
				return $.inArray(suggestion.displayName, self.selectedObjectNames) === -1;
			});
		},
		searchResultTemplate: function(){
			return Handlebars.compile('<p class="list-group-item typeahead-result typeahead-item" data-value="{{value}}">{{displayName}}</p>');
		},
		serialize: function(){
			return {
				cid: this.cid,
				placeholder: this.placeholder,
				clearable: this.clearable
			};
		}
	});
	return QueryableTypeahead;
});