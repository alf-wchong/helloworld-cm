// Rightsideactionhandler module
define([
    // Application.
    "app",
    "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, ActionModules) {

    // Create a new module.
    var Rightsideactionhandler = app.module();

    var config, paneSize;

    var MODULE_ID = "rightSideActionHandler";

    //this, like any action handler, when instantiated will put an event watcher on app
    app.rightSideActionHandler = _.extend({}, Backbone.Events);

    Rightsideactionhandler.View = Backbone.Layout.extend({
        template: "common/rightsideactionhandler",

        // give view an id so the wrapping div created by backbone is accessible
        id: "rightSideActionHandler-backbone-wrapper",

        events: {
            "click #close-rsah" : "closeRsah",
            "click #rightSideActionHandler-error-close": "closeErrorMessage"
        },
        
        closeErrorMessage : function(){
            $("#" + MODULE_ID + "-error").hide();
        },

        closeRsah : function() {
            var numPanesVisible = this.getNumPanesVisible();

            // If RSAH is the only pane remaining, we'll close it and ensure
            // that we trigger the default folder launch action.
            if (numPanesVisible === 1) {

                app.trigger("pane3:manually:closed");

			// Other panes remain open     
            } else {

				// When we hide the rsah, we want to remove the view that was there
				this.removeView("#" + MODULE_ID + "-content");
				app.rightSideActionHandler.trigger("hide", true);

				if (this.currentRsahView && _.isFunction(this.currentRsahView.onDismiss)) {
					this.currentRsahView.onDismiss();
                }
            }

            app.trigger("closeTour");
        },
		getNumPanesVisible : function() {
            var numPanesVisible = 0;
			var maxPanesAllowed = 3;
            
			var i = 0;
            while (i++ < maxPanesAllowed) {
                if ($("#pane" + i).is(':visible')) {
                    numPanesVisible++;
                }
            }

			return numPanesVisible;
		},
        insertSubView : function(options){
            var self = this;
            config = options.config;

            //ActionModules is a function
            var actionModule = ActionModules.getAction(config.get("actionId") );
            //add dynamic params to the config -- these contain the overrideable/overridden
            //functions that we need
            var dynamicParams = ActionModules.getDynamicParams(config.get("actionId"));
            if(dynamicParams){
                _.extend(options.config, dynamicParams);
            }
            //Check to see if previous a previous action was on the view. If so remove it (if we're not reusing it)
            if(self.views["#" + MODULE_ID + "-content"] && !options.reuseView) {
                self.removeView("#" + MODULE_ID + "-content");
            }
            
            // since we have styling applied to the error/message containers - we have to hide them as well as removing their contents
            this._hide("error");
            this._hide("warning");
            this._hide("message");
            this._hide("info");
            this._hide("progressBar");

            // check if we need to create a new view for this action, or if we can resuse our most recent one
            this.currentRsahView;
			if (options.oldView && options.reuseView){
                // only time we will reuse a view is if it is on the right side, so set our panesize accordingly
                this.currentRsahView = options.oldView;
                paneSize = "rightPane";
               
            } else {
                this.currentRsahView = new actionModule.View(options);
                // create an options object
                var rsahOptions = {
                    rsahView: this.currentRsahView,
                    rsahAction: options.action,
                    rsahConfig: options.config
                };
                // set our options on the app to help keep track of it
                app.trigger("newRSAHSubviewInserted", rsahOptions);
                paneSize = config.get("paneSize");
            }
            self.setView("#" + MODULE_ID + "-content", this.currentRsahView).render();

            if(paneSize === undefined){
                paneSize = "noPane";
            }

            //Load the supplied URL into the modal body.
            app.trigger("toggleRSAH", true, paneSize, options.showDualPane);

            //shows content in case the last view was a message/error (content was hidden)
            //keep content hidden if specified by action -- ACTPDF shows progress bar on initialize 
            // and content should stay hidden until the progress bar is complete and ACTPDF calls show itself
            if (!this.currentRsahView.keepRSAHContentHiddenUntilSubActionCallsShow) {
                $("#" + MODULE_ID + "-content").show();
            }

            //adds title and subtitle to the header
            $("#rsahTitle").html(window.localize(config.get("label")));
            $("#rsahSubTitle").html(config.get("subTitle") ? config.get("subTitle") : "");
        },
		// this function is used to show html elements based on the end of their id string 
		// which is passed in as a parameter, you can also pass in a message or view to display the
		// html element with and a clearContent boolean which says whether or not we want to clear the content 
		// before showing it
        _show : function( idStringEnding,  messageOrView,  clearContent) {
            if(clearContent) {
                $("#" + MODULE_ID + "-content").hide();
            }

            if (_.isString(messageOrView)) {
                $("#" + MODULE_ID + "-" + idStringEnding).html(messageOrView);
            } else if (_.isObject(messageOrView)){
                this.setView("#" + MODULE_ID + "-" + idStringEnding, messageOrView).render();
            }

            $("#" + MODULE_ID + "-" + idStringEnding).show();
        },
		// this function is used to hide html elements based on the end of their id string 
		// which is passed in as a parameter
        _hide : function( idStringEnding ) {
            $("#" + MODULE_ID + "-" + idStringEnding).hide();
        },
        _applyListeners : function() {
            var self = this;
            this.listenTo(app.rightSideActionHandler, "show", self.insertSubView);

            this.listenTo(app.rightSideActionHandler, "showError",function(message, maintainModal) { 
                this._show("error", message, !maintainModal); 
            });

            this.listenTo(app.rightSideActionHandler, "hideError", function() { 
                this._hide("error"); 
            });

            this.listenTo(app.rightSideActionHandler, "showWarning", function(messageOrView) { 
                this._show("warning", messageOrView, false); 
            });

            this.listenTo(app.rightSideActionHandler, "hideWarning", function() { 
                this._hide("warning"); 
            });	

            this.listenTo(app.rightSideActionHandler, "showMessage", function(message) { 
                this._show("message", message, true); 
            }); 	

            this.listenTo(app.rightSideActionHandler, "hideMessage", function() { 
                this._hide("message"); 
            });

            this.listenTo(app.rightSideActionHandler, "showInfo", function(message) { 
                this._show("info", message, false); 
            });

            this.listenTo(app.rightSideActionHandler, "hideInfo", function() { 
                this._hide("info"); 
            });

            this.listenTo(app.rightSideActionHandler, "showProgress", function() { 
                this._show("progressBar", null, false); 
            });

            this.listenTo(app.rightSideActionHandler, "hideProgress", function(){
                this._hide("progressBar");
                //lets also make sure its at 0 for bothIds
                $("#" + MODULE_ID + "-progressBar .progress-bar").width(0 + '%');
                $("#" + MODULE_ID + "-progressBar .progress-bar").text(0 + '%');
            });

            this.listenTo(app.rightSideActionHandler, "updateProgress", function(percent){
                $("#" + MODULE_ID + "-progressBar .progress-bar").width(percent + '%');
                $("#" + MODULE_ID + "-progressBar .progress-bar").text(percent + '%');
            });

            this.listenTo(app.rightSideActionHandler, "loading", function(showLoading){
                if(showLoading){
                    $("#" + MODULE_ID + "-content").hide();
                    $("#" + MODULE_ID + "-loader").show();
                }else{
                    $("#" + MODULE_ID + "-content").show();
                    $("#" + MODULE_ID + "-loader").hide();
                }
            });

            this.listenTo(app.rightSideActionHandler, "hide", function(){
                app.trigger("toggleRSAH", false);
            });

            this.listenTo(app, "stage.refresh.documentId", function(){
                app.trigger("toggleRSAH", false); //We want to close the view without triggering the hide function, to avoid the file displaying
            });

            this.listenTo(app, "stage.refresh.bothIds", function(containerId, documentId){
                if(config&&config.get("handler")!=="rightSideActionHandler"){
                    if(containerId === true && documentId === true){
                        app.rightSideActionHandler.trigger("hide");
                    }
                }
            });
        },
        initialize : function() {
            this._applyListeners();
        }
    });

    // Return the module for AMD compliance.
    return Rightsideactionhandler;

});