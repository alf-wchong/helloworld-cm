// SlickGridTableView module
define([
    // Application.
    "app",
    "slickgrid",
    "libs/backbone.paginator"
],

// Map dependencies from above array.
function(app) {

    // Create a new module.
    var SlickGridTableView = app.module();

    //create a vent for all search control modules
    SlickGridTableView.vent = _.extend({}, Backbone.Events);

    SlickGridTableView.View = Backbone.Layout.extend({
        template: "common/slickgridtableview",

        events: {
            "click #columnChooser-slickview": "contextMenu"
        },

        initialize: function() {

            var self = this;

            this.collection = this.options.query;

            this.handler = this.options.handler;

            // listen for query object changes and reload the data on new searchs or manual resets:
            //this.listenTo(this.collection, 'sync', this.reloadResults);
            
            this.listenTo(this.collection, 'query:complete', this.reloadResults);

            
            this.collection.fetch();

            this.tracConfig = this.options.tracConfig;
            this.searchType = this.options.searchType;
            this.rows = [];
            this.visibleAttrs = [];

            this.searchConfig = {};
            this.searchConfigDeferred = $.Deferred();
            var resultTableConfig = {};
            if(app.context.currentSearchConfig()){
                self.searchConfig = app.context.currentSearchConfig();
                resultTableConfig = self.searchConfig.get("resultsConfig").get("resultsTableConfig");
                self.searchConfigDeferred.resolve();
            }else{
                app.context.configService.getSearchConfigForTrac(this.tracConfig  , function(searchConfig){
                    self.searchConfig = searchConfig;
                    resultTableConfig = self.searchConfig.get("resultsConfig").get("resultsTableConfig");
                    self.searchConfigDeferred.resolve();
                });
            }

            //this are the attrs the user currently sees in search results
            //e.g. the columns in table view
            this.listenTo(SlickGridTableView.vent, "search:currentlyDisplayedFields", function(attrs){
                self.visibleAttrs = attrs;
            });


            /*
			 * This let's anyone who cares (searchresultcontrols) know when
			 * the columns change. It's debounced so that it's called once per
			 * header render, not header cell render
			 */
			this._debouncedOnHeaderChange = _.debounce(function(e, args) {
				var headers = _.pluck(args.grid.getColumns(), "field");
				var headerLabels = _.pluck(args.grid.getColumns(), "name");
				var columnWidths = _.map(args.grid.getColumns(), function(column) {
					return {'id': column.id , 'width': column.width};
				});
				var visibleColumns = headers;

				SlickGridTableView.vent.trigger("search:currentlyDisplayedFields", headers, headerLabels);
				app.context.configService.getUserPreferences(function(currentUserPreferences){
					var prefs = currentUserPreferences.get("searchResultsTableview");
					var queryType;

					if(self.collection.queryParams.oc_type !== undefined) {
						queryType = self.collection.queryParams.oc_type[0];
					} else {
						// IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
						// we're still going to assume a collection is one type such as a parent type
						// NOTE THIS MEANS IF A CLIENT WANTS MULTIPLE TYPES IT WILL NEED TO BE IMPLEMENTED
						queryType = resultTableConfig.get("types").models[0].attributes.objectType + "-collection";
					}

					//if cookie doesn't exist, create new cookie
					if(!prefs) {
						prefs = {};
					}
					//If doctype/trac isn't configured yet for the cookie, create it
                    if(!prefs[queryType + '_' + app.context.configName()]) {
                        prefs[queryType + '_' + app.context.configName()] = {};
                        prefs[queryType + '_' + app.context.configName()].selectedColumns = {};
                        prefs[queryType + '_' + app.context.configName()].columnWidths = {};
					}

                    prefs[queryType + '_' + app.context.configName()].columnWidths = columnWidths;
                    prefs[queryType + '_' + app.context.configName()].selectedColumns = visibleColumns;

                    //going to make sure our user prefs keep the checkbox column because i'm not sure what else to do
                    prefs[queryType + '_' + app.context.configName()].columnWidths.unshift({'id': "_checkbox_selector", 'width': 30});
                    prefs[queryType + '_' + app.context.configName()].selectedColumns.unshift("sel");

					currentUserPreferences.set("searchResultsTableview", prefs);
					currentUserPreferences.save({version: false}, {global: false});
				});
			}, 100);

			//save preferences for force fit
			this._debouncedOnAutoSize = _.debounce(function(e, args) {
				var forcedFit = args.grid.getOptions().forceFitColumns;
				app.context.configService.getUserPreferences(function(currentUserPreferences){
					var prefs = currentUserPreferences.get("searchResultsTableview");
					var queryType;
					if(self.collection.queryParams.oc_type !== undefined) {
						queryType = self.collection.queryParams.oc_type[0];
					} else {
						// IN HERE WE ASSUME WE ARE DEALING WITH A COLLECTION
						// we're still going to assume a collection is one type such as a parent type
						// NOTE THIS MEANS IF A CLIENT WANTS MULTIPLE TYPES IT WILL NEED TO BE IMPLEMENTED
						queryType = resultTableConfig.get("types").models[0].attributes.objectType + "-collection";
					}

					// if cookie doesn't exist, create a new cookie
					if(!prefs) {
						prefs = {};
					}
					//If doctype/trac isn't configured yet for the cookie, create it
					if(!prefs[queryType]) {
						prefs[queryType] = {};
						prefs[queryType].selectedColumns = {};
					}
					prefs[queryType].isForceFit = forcedFit;
					currentUserPreferences.set("searchResultsTableview", prefs);
					SlickGridTableView.vent.trigger("newTableRendered");
				});
			}, 100);

        },

        beforeRender: function() {
            var config = {
                collection: this.collection
            };
            var options = this.options;

            this.filterControl = new SlickGridTableView.Views.FilterControl(options, config);

            this.setViews({'.upload-lookup-search-result-filter-control': this.filterControl});
        },

        //The filter that is run by SlickGrid.
        //Note: this function gets compiled into a different function - see tsg.dataview.js:compileFilter
        //Be careful - the "compiler" will change any return statements (INCLUDING COMMENTS) into
        //slickgrid specific code. (EX: don't put a comment that says "return true;")
        slickgridFilter: function(item, args) {
            //If we don't have any arguments to filter on, don't bother with this function
            if (!args) {
                return true;
            }

            var text = args.text || "";
            var ret = false;
            var cols = _.pluck(this.grid.getColumns(), 'field').splice(1);
            var prop = "";
            var i;
            if (text) {
                //normal text filtering
                for (i = 0; i < cols.length; i++) {
                    prop = cols[i];
                    //Case insensitive filtering
                    if (item[prop] && item[prop].toString().toLowerCase().indexOf(text.toLowerCase()) > -1) {
                        ret = true;
                    }
                }
                return ret;
            } else {
                //no filter params
                return true;
            }
        },

        render: function() {
            //this.$el.html(_.template('<%= content %>', this.collection.toJSON()));
            //return this;
        },
        reloadResults: function(collection){
            var self = this;
            if(collection){
                this.collection = collection;
                self.unfilteredCollection = this.collection.fullCollection.models;
            }
            //only cache referenced configs if this trac exists

            var gridOptions = {
				enableCellNavigation: true,
				asyncEditorLoading: true,
				topPanelHeight: 25,
				forceFitColumns: false,
				autoHeight: true,
				defaultColumnWidth: 125,
				selectedCellCssClass: 'selected'
			};

            function repeatingComparer(x, y) {
                //first, sort the date array values in ascending order
                var xValArray = x.get("properties")[sortcol];
                var yValArray = y.get("properties")[sortcol];

                if(xValArray && yValArray && xValArray.length > 0 && yValArray.length > 0){

                    var xSortedArray = _.sortBy(xValArray, function(attr){
                        if (_.isString(attr)){
                            return attr.toLowerCase();
                        } else {
                            return attr;
                        }
                    });

                    var ySortedArray = _.sortBy(yValArray, function(attr){
                        if (_.isString(attr)){
                            return attr.toLowerCase();
                        } else {
                            return attr;
                        }
                    });

                    var compareValX = xSortedArray[0], compareValY = ySortedArray[0];
                    if (_.isString(compareValX)) {
                        compareValX = compareValX.toLowerCase();
                    }
                    if (_.isString(compareValY)) {
                        compareValY = compareValY.toLowerCase();
                    }

                    //now, compare the first date of each x and y
                    if(compareValX > compareValY){
                        return 1;
                    } else if (compareValY > compareValX){
                        return -1;
                    } else {
                        return 0;
                    }

                } else if(xValArray && xValArray.length > 0){
                    return 1;
                } else if(yValArray && yValArray.length > 0){
                    return -1;
                } else {
                    return 0;
                }
            }

            function comparer(x, y) {
                if (_.isArray(x.get("properties")[sortcol])) {
                    return repeatingComparer(x, y);
                }

                var compareValX = x.get("properties")[sortcol], compareValY = y.get("properties")[sortcol];
                if (_.isString(compareValX)) {
                    compareValX = compareValX.toLowerCase();
                }
                if (_.isString(compareValY)) {
                    compareValY = compareValY.toLowerCase();
                }
                return compareValX == compareValY ? 0 : (compareValX > compareValY ? 1 : -1);
            }

            function repeatingDateComparer(x, y){
                //first, sort the date array values in ascending order
                var xValArray = x.get("properties")[sortcol];
                var yValArray = y.get("properties")[sortcol];

                if(xValArray && yValArray && xValArray.length > 0 && yValArray.length > 0){
                    var xDateArray = [];
                    var yDateArray = [];

                    _.each(xValArray, function(dateString) {
                        if (dateString.indexOf(":") > -1) {
                            xDateArray.push(moment(dateString, app.context.currentApplicationConfig().get("dateFormat")+" "+app.context.currentApplicationConfig().get("timeFormat")).toDate().getTime());
                        } else {
                            xDateArray.push(moment(dateString, app.context.currentApplicationConfig().get("dateFormat")).toDate().getTime());
                        }
                    });

                    _.each(yValArray, function(dateString) {
                        if (dateString.indexOf(":") > -1) {
                            yDateArray.push(moment(dateString, app.context.currentApplicationConfig().get("dateFormat")+" "+ app.context.currentApplicationConfig().get("timeFormat")).toDate().getTime());
                        } else {
                            yDateArray.push(moment(dateString, app.context.currentApplicationConfig().get("dateFormat")).toDate().getTime());
                        }
                    });

                    xDateArray = _.sortBy(xDateArray, function(date){ return date; });
                    yDateArray = _.sortBy(yDateArray, function(date){ return date; });

                    //now, compare the first date of each x and y
                    if(xDateArray[0] > yDateArray[0]){
                        return 1;
                    } else if (yDateArray[0] > xDateArray[0]){
                        return -1;
                    } else {
                        return 0;
                    }

                } else if(xValArray && xValArray.length > 0){
                    return 1;
                } else if(yValArray && yValArray.length > 0){
                    return -1;
                } else {
                    return 0;
                }
            }

            function dateComparer(x, y) {
                if (_.isArray(x.get("properties")[sortcol])) {
                    return repeatingDateComparer(x, y);
                }

                var xValue = x.get("properties")[sortcol];
                var yValue = y.get("properties")[sortcol];

                var hasTime = false;
                if (xValue.indexOf(":") > -1 || yValue.indexOf(":") > -1) {
                    hasTime = true;
                }
                if(xValue && yValue){
                    var leftSortAttrVal, rightSortAttrVal;

                    if (hasTime) {
                        leftSortAttrVal = moment(xValue, app.context.currentApplicationConfig().get("dateFormat")+" "+ app.context.currentApplicationConfig().get("timeFormat")).toDate().getTime();
                        rightSortAttrVal = moment(yValue, app.context.currentApplicationConfig().get("dateFormat")+" "+ app.context.currentApplicationConfig().get("timeFormat")).toDate().getTime();
                    } else {
                        leftSortAttrVal = moment(xValue, app.context.currentApplicationConfig().get("dateFormat")).toDate().getTime();
                        rightSortAttrVal = moment(yValue, app.context.currentApplicationConfig().get("dateFormat")).toDate().getTime();
                    }

                    return leftSortAttrVal === rightSortAttrVal ? 0 : (leftSortAttrVal > rightSortAttrVal ? 1 : -1);
                } else if(!xValue){
                    return 1;
                } else {
                    return -1;
                }
            }

            

            self.handleScrolling = function() {
                if ($('.slickgridHolder').scrollTop() > $(".slick-header").height()) {
                    var width = $("#slickgrid-tableview-grid").width();
                    $("#slickgrid-tableview-grid .slick-header").addClass("sticky").css("position", "fixed").css("width", width);
                } else {
                    $("#slickgrid-tableview-grid .slick-header").removeClass("sticky").css("position", "relative");
                }
            };

            //$('.slickgridHolder').show();

            $('.slickgridHolder').scroll(self.handleScrolling);

            $(".grid-header .ui-icon").addClass("ui-state-default ui-corner-all").mouseover(function(e) {
                $(e.target).addClass("ui-state-hover");
            }).mouseout(function(e) {
                $(e.target).removeClass("ui-state-hover");
            });

            var sortcol = "objectName";

            var columns = [];
            var grid;

            self.dataView = new Slick.Data.DataView({
                inlineFilters: true
            });


            self.grid = grid = new Slick.Grid("#slickgrid-tableview-grid", self.dataView, columns, gridOptions);

            $.when(self.searchConfigDeferred).done(function(){

                self.typeColumns = _.find(self.searchConfig.get('resultsConfig').get('resultsTableConfig').get('types').models,function(tableViewType){
                    return tableViewType.get('objectType') === self.searchType;
                });

                var queryType = self.searchType;

                //set the columns up with labels TODO more features available here
                app.context.configService.getAdminTypeConfig(self.searchType, function(objectTypeConfig) {
                    _.each(self.typeColumns.get('fields'), function(fieldName) {
                        if (objectTypeConfig) {
                            var attrConfig = objectTypeConfig.get("attrs").findWhere({
                                ocName: fieldName.ocName
                            });
                            var column = {
                                    id: fieldName.ocName,
                                    name: window.localize(attrConfig.get("label")),
                                    field: fieldName.ocName,
                                    sortable: true,
                                    hpiConfig: attrConfig
                            };

                            columns.push(column);
                        } else {
                            //no config for this type, limited display
                            columns.push({
                                id: fieldName.ocName,
                                name: fieldName.ocName,
                                field: fieldName.ocName,
                                sortable: true
                            });
                        }
                    });

                    app.context.configService.getUserPreferences(function(currentUserPreferences){
                        var userPrefs = currentUserPreferences.get("searchResultsTableview");
                        //Returns user prefered columns
                        var visibleColumns = [];
                        if (userPrefs && userPrefs[queryType] && userPrefs[queryType].selectedColumns.length > 0) {
                            var uservisibleColumns = userPrefs[queryType].selectedColumns;
                            _.each(uservisibleColumns, function(visibleColumn) {
                                var tempColumn = _.find(userPrefs[queryType].columnWidths, function(column) {
                                    return column.id === visibleColumn;
                                });
                                _.each(columns, function(allColumns) {
                                    if (visibleColumn === allColumns.field) {
                                        if(userPrefs[queryType].columnWidths) {
                                            if(tempColumn) {
                                                allColumns.width = tempColumn.width;
                                            }
                                        }
                                        visibleColumns.push(allColumns);
                                    }
                                });
                            });
                            grid.setColumns(visibleColumns);

                        //If no preference, show only visible fields (hidden fields configured)
                        } else if (self.typeColumns.get('fields').length > self.typeColumns.get("visibleFields").length) {
                            var tempVisibleFields = _.pluck(self.typeColumns.get("visibleFields"), 'ocName');
                            visibleColumns = _.filter(columns, function(column) {
                                if (_.indexOf(tempVisibleFields, column.field) !== -1) {
                                    return true;
                                } else {
                                    return false;
                                }
                            });
                            visibleColumns.unshift(columns[0]);
                            grid.setColumns(visibleColumns);

                        //If no hidden fields, show all fields
                        } else {
                            grid.setColumns(columns);
                        }

                        //If there are userPrefs of the desired type and the forcefit attribute exists
                        if (userPrefs && userPrefs[queryType] && typeof userPrefs[queryType].isForceFit != "undefined") {
                            if(userPrefs[queryType].isForceFit){
                                grid.setOptions({
                                    forceFitColumns: true
                                });
                                grid.autosizeColumns();
                            }else{
                                grid.setOptions({
                                    forceFitColumns: false
                                });
                            }
                        }
                        //Else, fall back on the config.
                        else if (self.typeColumns.get("isForceFit") === "true") {
                            grid.setOptions({
                                forceFitColumns: true
                            });
                            grid.autosizeColumns();
                        } else if (self.typeColumns.get("isForceFit") === "false") {
                            grid.setOptions({
                                forceFitColumns: false
                            });
                        }

                        new Slick.Controls.ColumnPicker(columns, grid, gridOptions);
                        var headers = _.pluck(columns, "field");

                        app.off("search:requestDisplayedFields");
                        app.on("search:requestDisplayedFields", function(){
                            SlickGridTableView.vent.trigger("search:currentlyDisplayedFields", headers);
                        });

                        self.visibleAttrs = headers;

                        currentUserPreferences.set("searchResultsTableview", userPrefs);

                        //loop through each oco and change the object type to the queryType. This fixes
                        //the problem of the first page not loading due to deferreds not resolving.

                        //by splitting on "-" here, we can ensure that even if we are dealing with a collection query, that
                        //queryType[0] will contain the correct type instead of "Document-collection" for example.
                        queryType = queryType.split("-");

                        _.each(self.collection.models,function(oco) {
                            oco.set("objectType",queryType[0]);
                            if(oco.get("mimeType") && !oco.get("properties").mimeType ){
                                oco.get("properties").mimeType = oco.get("mimeType");
                            }
                        });


                        grid.setSelectionModel(new Slick.RowSelectionModel());


                        grid.toggleSelectionPanel = function(numRows) {
                            if (self.collection.state.totalRecords > numRows &&
                                numRows % self.collection.length === 0 &&
                                numRows !== 0) {
                                self.$("#pageCount").html(numRows);
                                self.$("#totalCount").html(self.collection.state.totalRecords);
                                grid.setTopPanelVisibility(true);
                            }else{
                                grid.setTopPanelVisibility(false);
                            }
                        };

                        var tooltips = new Slick.AutoTooltips();
                        grid.registerPlugin(tooltips);

                        grid.onHeaderCellRendered.subscribe(self._debouncedOnHeaderChange);
                        grid.onColumnsResized.subscribe(self._debouncedOnHeaderChange);
                        grid.onAutoSize.subscribe(self._debouncedOnAutoSize);
                        grid.setSelectionModel(new Slick.RowSelectionModel());

                        grid.onSort.subscribe(function(e, args) {
                            sortcol = args.sortCol.field;

                            if ($.browser.msie && $.browser.version <= 8) {

                                // use numeric sort of % and lexicographic for everything else
                                self.dataView.fastSort(sortcol, args.sortAsc);
                            } else {
                                // using native sort with comparer
                                // preferred method but can be very slow in IE with huge datasets
                                //self.dataView.sort(comparer, args.sortAsc);

                                if (args.sortCol.hpiConfig.get("dataType") === "date") {
                                    self.dataView.sort(dateComparer, args.sortAsc);
                                } else {
                                    self.dataView.sort(comparer, args.sortAsc);
                                }
                            }
                        });

                        grid.onSelectedRowsChanged.subscribe(function(evt, args) {
                            //a row has been selected, lets copy these values
                            var rowOco = self.collection.models[args.rows[0]];
                            
                            app.trigger("bulkupload:copyValuesToForm",rowOco);
                        });

                        // wire up model events to drive the grid
                        self.dataView.onRowCountChanged.subscribe(function() {
                            grid.updateRowCount();
                            grid.render();
                        });

                        self.dataView.onRowsChanged.subscribe(function(e, args) {
                            grid.invalidateRows(args.rows);
                            grid.render();
                        });

                        self.listenTo(SlickGridTableView.vent, "slickgridtableview:results:text:filter:change", function(textFilter) {
                            var filterArgs = {};
                            filterArgs.text = textFilter.trim();
                            //The text argument passed to the filter.
                            self.grid.getData().setFilterArgs(filterArgs);
        
                            //Refreshing the data based on the filter.
                            self.dataView.refresh();

                        });

                        // initialize the model after all the events have been hooked up
                        self.dataView.beginUpdate();
                        self.dataView.setFilter(self.slickgridFilter);
                        self.dataView.endUpdate();

                        // if you don't want the items that are not visible (due to being filtered out
                        // or being on a different page) to stay selected, pass 'false' to the second arg
                        self.dataView.syncGridSelection(grid, false);

                        //filter needs this defined on window
                        window.grid = self.grid;

                        //trigger the set items here to ensure that they are appearing on the first search.
                        self.dataView.setItems(self.collection, "objectId"); //set id prop to objectId

                    });
                });

            });
            
            $('.slickgridHolder').css({'overflow': 'auto', 'height': $('#' + self.handler + '-content').height() - 100});
            $('#slickgrid-tableview-filter').val('');
	
        },
        afterRender: function(){            
        },
        serialize: function() {

        }

    });

    SlickGridTableView.Views.FilterControl = Backbone.Layout.extend({
        template: 'search/filtercontrol',
        events: {
            'keydown input.filter': 'sanitizeKey',
            'keyup input.filter': 'updateTextFilter',
            'click button.clear-filter': 'clearFilter'
        },

        initialize: function(options, config) {

            this.filter = window.localStorage.getItem("userFilter") || "";
            this.collection = config.collection;
            this.options = options;
            this._stopListening();
            this.startListening();
            this.searchResults = options.searchResults;

            this.showFilterControls = true;

        },
        _stopListening: function() {
            //stop listening first -- don't want multiple listeners registered
            this.stopListening(SlickGridTableView.vent);
        },
        startListening: function() {
            //stop listening first -- don't want multiple listeners registered
            this.stopListening(SlickGridTableView.vent);

            //listen for search to update/change
            this.listenTo(SlickGridTableView.vent, 'slickgridtableview:result:controls:reset', function() {
                this.clearFilter();
            }, this);

            this.listenTo(SlickGridTableView.vent, 'slickgridtableview:filter:reset', function() {
                this.clearFilter();
            }, this);

        },
        
        //must intercept enter key on down press not keyup
        sanitizeKey: function(evt) {
            var code = evt.keyCode || evt.which;
            if (code == 13) {
                //prevent default for enter key only
                evt.preventDefault();
            }
        },
        updateTextFilter: _.throttle(function() {
            this.filter = this.ui.filter.val().toLowerCase();
            if (_.isEmpty(this.filter)) {
                SlickGridTableView.vent.trigger("setIsTextFiltering", false);
                this.ui.clear.hide();
            } else {
                SlickGridTableView.vent.trigger("setIsTextFiltering", true);
                this.ui.clear.show();
            }
            SlickGridTableView.vent.trigger("slickgridtableview:results:text:filter:change", this.filter);
        }, 20),
        clearFilter: function(evt) {
            if(evt) {
                evt.preventDefault();
            }
            
            if (this.rendered) {
                this.ui.filter.val(''); //reset filter if search changed
                this.ui.clear.hide();
                this.updateTextFilter();
            }
        },
        afterRender: function() {
            this.rendered = true;
            this.ui = {
                filter: this.$('input.filter'),
                clear: this.$('.clear-filter')
            };
            if (_.isEmpty(this.filter)) {
                this.ui.clear.hide();
            } else {
                this.ui.clear.show();
            }
        },
        cleanup: function() {
            this._stopListening();
        },
        serialize: function(){
            return {
                'showFilterControls': this.showFilterControls
            };  
        }
    });

    // Return the module for AMD compliance.
    return SlickGridTableView;

});
