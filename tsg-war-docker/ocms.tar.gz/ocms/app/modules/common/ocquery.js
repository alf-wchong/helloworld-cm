// OCQuery module
define([
    // Application.
    "app",
    "knockout",
    "oc",
    "modules/common/stringutils",
    "modules/common/hpiconstants",
    "libs/backbone.paginator"
],

// Map dependencies from above
function(app, ko, OC, StringUtils, HPIConstants) {

    // Create a new module.
    var OCQuery = app.module();

    //pipe events between the search interfaces
    OCQuery.events = _.extend({}, Backbone.Events);

    var PageableProto = Backbone.PageableCollection.prototype;

    //do a normal fetch without any processing
    OCQuery.protofetch = function(options){
        if(!options){
            options = {};
        }
        this.searchActuallyExecuted = true;
        var fetchComplete = $.Deferred();
        //don't pass the original options as this will trigger success / error callbacks prematurely
        //force all requests to be GETs and disable AJAX global by default
        var fetched = PageableProto.fetch.call(this, {
            'type': 'GET',
            'global': options.global === undefined ? 'false' : options.global,
            'context': options.context
        });
        //fire the proper success / error callbacks
        //capture the response from Backbone.Paginator
        var _response;
        //fire a custom event when search finishes
        fetched.done(_.bind(function(updatedCollection, status, response) {
            _response = response;
            //when in client-side the state object will change
            var results = updatedCollection;
            if (updatedCollection.results) {
                //only OpenContent queries store the results on a results attr,
                //everyone else should be a straight list of results
                //eat that difference here
                results = updatedCollection.results;
            }
            this.reset(results);

            // format OCOs
            this.formatResults(fetchComplete);

        }, this));

        $.when(fetchComplete).done(_.bind(function() {
            // This options object reprsents the options passed to a Backbone ajax call. If we don't use the "call" or "apply" functions here
            // we won't be respecting the context passed into the ajax call, so this makes sure we respect that if it's present.
            // If undefined is passed as context to the "call" function, javascript will default it to the window.
            var contextForCb = options.context;
            
            //fire success / error callbacks based on the reponse from Backbone.Paginator
            if (_response.status < 400 && options.success) {
                options.success.call(contextForCb, this, 'success', _response);
            } else if (_response.status > 400 && options.error) {
                options.error.call(contextForCb, this, 'error', _response);
            }

            // add a complete callback handler
            if(options.complete){
                options.complete.call(contextForCb, this, 'complete', _response);
            }
        }, this));

        //pass back the original deferred
        return fetchComplete.promise();
    };

    //specialized fetch to handle OpenContent queries
    OCQuery.fetch = function(options){
        if(!options){
            options = {};
        }
        this.searchActuallyExecuted = true;
        //wait for formatting to be done before declaring fetch complete
        var fetchComplete = $.Deferred();
        if(this.searchParameters && this.searchParameters.length > 0) {
            if(this.state.firstPage === 0){
                this.state.currentPage = 0;
            }

            this.documentInfoStartTime = Date.now();

            //don't pass the original options as this will trigger success / error callbacks prematurely
            //force all requests to be GETs and disable AJAX global by default
            var fetched = PageableProto.fetch.call(this, {
                'type': 'GET',
                'global': options.global === undefined ? 'false' : options.global,
                'url': this.url,
                'headers': {"timeOCCall": "true", "requestTimestamp" : this.documentInfoStartTime},
                'context': options.context
            });
            //capture the response from Backbone.Paginator
            var _response;
            //fire a custom event when search finishes
            fetched.done(_.bind(function(updatedCollection, status, response) {
                _response = response;

                var documentInfoEndTime = Date.now();

                this.queryBuildTime = response.getResponseHeader("query_build_time") / 1000.0;
                this.queryExecuteTime = response.getResponseHeader("query_execute_time") / 1000.0;
                this.queryParseTime = response.getResponseHeader("query_parse_time") / 1000.0;
                this.ocCallTime = response.getResponseHeader("OCCallTime");
                // use total time in OC and the time from start of Ajax till now to determine total network time 
                this.networkTime = (documentInfoEndTime - this.documentInfoStartTime - this.ocCallTime) / 1000.0;
                this.ocCallTime /= 1000.0;

                // only reset the values if the attributes are not already set
                if (!this.attrsSet){
                    //when in client-side the state object will change
                    var results = updatedCollection;
                    if (updatedCollection.results) {
                        //only OpenContent queries store the results on a results attr,
                        //everyone else should be a straight list of results
                        //eat that difference here
                        results = updatedCollection.results;
                    }

                    this.reset(results);
                }
                
                this.state = updatedCollection.state;

                //update the internal recordkeeper
                this.records.set(this.state);
                //format OCOs
                this.formatResults(fetchComplete, options);
            }, this));

            $.when(fetchComplete).done(_.bind(function() {
                //backbone paginator has a 'directions' array that transforms the state from 1 or -1 to desc
                //or asc before sending OC - thus we need to change it back so the next query call is correct
                if (this.state.order === 'asc') {
                    this.state.order = '-1';
                } else if (this.state.order === 'desc') {
                    this.state.order = '1';
                }

                // This options object reprsents the options passed to a Backbone ajax call. If we don't use the "call" or "apply" functions here
                // we won't be respecting the context passed into the ajax call, so this makes sure we respect that if it's present.
            	// If undefined is passed as context to the "call" function, javascript will default it to the window.
                var contextForCb = options.context;
                
                //fire success / error callbacks based on the reponse from Backbone.Paginator
                if (_response.status < 400 && options.success) {
                    options.success.call(contextForCb, this, 'success', _response);
                } else if (_response.status > 400 && options.error) {
                    options.error.call(contextForCb, this, 'error', _response);
                }

                // add a complete callback handler
                if(options.complete){
                    options.complete.call(contextForCb, this, 'complete', _response);
                }

            }, this));
        }else{
            fetchComplete.resolve();
        }

        //pass back the original deferred
        return fetchComplete.promise();
    };

    // Default Collection.
    OCQuery.Collection = Backbone.PageableCollection.extend({
        model: OC.OpenContentObject,
        url: function(url) {
            // composite mode?
            if(url){
                return url;
            }else{
                if(app.context.currentSearchConfig()){
                    return app.serviceUrlRoot + '/query/search' + '?appId=' + app.appId + '&searchConfigName=' + app.context.currentSearchConfig().get('name');
                }else{
                    return app.serviceUrlRoot + '/query/search' + '?appId=' + app.appId;
                }
            }           
        },
        initialize: function(collection, config) {
            //default to client-side
            this.mode = config && config.mode ? config.mode : 'client';
            this.context = config && config.context ? config.context : 'GENERAL_CONTEXT';
            //create an internal records keeper - can't trust the server
            this.records = new OCQuery._TotalRecords({}, {
                'collection': this
            });
            this.applyListeners();
            //call parent init
            OCQuery.Collection.__super__.initialize.apply(this, arguments);
        },
        applyListeners: function() {
            //listen for changes and update the internal recordkeeper
            if (this.client()) {
                this.on("add remove", this._updateRecords, this);
                //reset is a special snowflake since we need to also notify tsg.dataview via the query:complete event
                this.on("reset", function() {
                    this._updateRecords();
                }, this);
            }
        },
        unbindListeners: function() {
            this.off("reset add remove");
        },
        //internal method for updating the records object
        _updateRecords: function() {
            this.records.set(this.state);
            //update prev <--> next pages
            this.records.changePage(this.state.currentPage);
        },
        resetRecords: function() {
            this.records = new OCQuery._TotalRecords({}, {
                'collection': this
            });
        },
        _setupQuery: function(){
            this.queryParams.oc_property = [];
            this.queryParams.oc_type = [];
            this.queryParams.oc_allproperties = [];
            this.queryParams.oc_searchallversions = [];
            this.queryParams.oc_compositeProperty = [];
            this.queryParams.defaultIndicators = [];
            //add the configured search mode - client vs server
            this.queryParams.mode = this.mode;

            //Set logic to and/or
            this.queryParams.logic = [];
        },
        getQueryParams: function() {
            return {
                "oc_property": this.queryParams.oc_property,
                "oc_type": this.queryParams.oc_type,
                "oc_allproperties": this.queryParams.oc_allproperties,
                "oc_searchallversions": this.queryParams.oc_searchallversions,
                "oc_compositeProperty": this.queryParams.oc_compositeProperty,
                "defaultIndicators": this.queryParams.defaultIndicators,
                "mode": this.queryParams.mode,
                "logic": this.queryParams.logic,
                "order": this.queryParams.directions[this.state.order],
                "sort_by": this.state.sortKey
            };
        },
        //override to turn search params into query params
        fetch: function(options){
            //setup query parameters
            if(this.composite){
                this.fetchComposite(options);
            }else{
                if(app.context.currentSearchConfig()){
                    this.url = app.serviceUrlRoot + '/query/search' + '?appId=' + app.appId + '&searchConfigName=' + app.context.currentSearchConfig().get('name');
                }else{
                    this.url = app.serviceUrlRoot + '/query/search' + '?appId=' + app.appId;
                }

                this._setupQuery();
                if(options && options.defaultIndicators !== undefined){
                    this.queryParams.defaultIndicators = options.defaultIndicators;//getting the array of strings to pass as query parameters
                }
    
                if (this.logic && this.logic.length > 0) {
                    this.queryParams.logic.push(this.logic[0]);
                } else {
                    var tempLogic = " and ";
                    _.each(this.searchParameters, function(param) {
                        if (param.logic) {
                            tempLogic = param.logic + " ";
                        }
                    });
                    this.queryParams.logic.push(tempLogic);
                }
                _.each(this.searchParameters, function(item) {
                    if (item.paramType === 'property') {
                        if (_.isArray(item.paramValue)) {
                            item.paramValue = item.paramValue.join("~|~");
                        }
                        //custom delimiter for allowing colons as search terms
                        var tsg_delimiter = '~:~';
                        // check if we have a proximity time search, if so only send the 2 dates
                        // the second check here in the if protects us against properties that are not strings (or dates that have been converted
                        // to their isoString) in the object model
                        if (item.paramValue && _.isString(item.paramValue) && item.paramValue.indexOf('$*prx*$') > 0) {
                            var proxyValue = item.paramValue.split('$*prx*$')[0];
                            this.queryParams.oc_property.push(item.paramName + tsg_delimiter + proxyValue + (item.operator ? tsg_delimiter + item.operator : tsg_delimiter + "LOGIC_LIKE"));
                        }
                        //querying for empty params makes OC angry...
                        else if (item.paramValue) {
                            this.queryParams.oc_property.push(item.paramName + tsg_delimiter + item.paramValue +
                                (item.operator ? tsg_delimiter + item.operator : tsg_delimiter + "LOGIC_LIKE") +
                                (item.searchMod ? tsg_delimiter + item.searchMod : tsg_delimiter + "CASE_INSENSITIVE") +
                                (item.termLogic ? tsg_delimiter + item.termLogic : tsg_delimiter + "AND"));
                        }
                    } else {
                        this.queryParams = this.addGenericParam(item, this.queryParams);
                    }
                }, this);
    
                if(app.context.currentApplicationConfig() && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") === 'true'){
                    this.queryParams.alfrescoCmisQuery = true;
                }
                
                // call generic OCQuery fetch and pass back the deferred
                return OCQuery.fetch.apply(this, arguments);
            }
        },
        fetchComposite: function(options){
            //setup query parameters for composite
            this.url = app.serviceUrlRoot + "/query/searchComposite" + "?appId=" + app.appId + '&searchConfigName=' + app.context.currentSearchConfig().get('name');                
            this._setupQuery();
            var compositeParams = [];
            _.each(this.searchParameters, function(param) {
                if (param.paramType === 'compositeProperty') {
                    if (_.isArray(param.paramValue)) {
                        param.paramValue = param.paramValue.join("~|~");
                    }
                    compositeParams.push(param);
                } else {
                    this.queryParams = this.addGenericParam(param, this.queryParams);
                }
            }, this);
            var completedCompositeParams = [];
            completedCompositeParams = this.setUpCompositeParams(compositeParams, options.selectedType, this.queryParams);
            this.parseCompositeParams(completedCompositeParams, this.queryParams.oc_compositeProperty);
            //flag this as a composite search
            this.compositeSearch = true;

            if(app.context.currentApplicationConfig() && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") === 'true'){
                this.queryParams.alfrescoCmisQuery = true;
            }

            // call generic OCQuery fetch and pass back the deferred
            return OCQuery.fetch.apply(this, arguments);
        },
        formatResults: function(deferred, options) {
            this.state.formatResultsStart = Date.now();
            if (!deferred) {
                deferred = $.Deferred();
            }
            //format OCOs
            var jqxhrArray = [];
            this.each(function(oco) {
                var typeConfig = $.Deferred();
                jqxhrArray.push(typeConfig);
                //store objectTypes in memory
                app.context.configService.getAdminTypeConfig(oco.get('objectType'), function(otc) {
                    typeConfig.resolve(otc);
                });
                $.when(typeConfig).done(function(otc) {
                    var formatJqxhr = oco.formatProperties(otc);
                    jqxhrArray.push(formatJqxhr);
                });
            });
            $.when.apply($, jqxhrArray).done(_.bind(function() {
                //Ensuring that the totalRecords property matches the total number of models
                //This is important because tableview checks this property when doing a render.
                this.state.totalRecords = this.models.length;
                
                //fire event with the search results count
                app.trigger("search:result:controls:numResults", this.state.totalRecords);
                //fire an event notifying any listeners
                //that search was fetched and formatted
                app.log.debug('query complete. found ' + this.state.totalRecords + ' results');
                this.state.formatResultsEnd = Date.now();
                this.state.formatResultsTime = (this.state.formatResultsEnd - this.state.formatResultsStart) / 1000.0;

                this.trigger('query:complete', this, options);
                // only setup facets if we're not sorting
                if(options && !options.sorting && options.searchResultsViewController) {
                    options.searchResultsViewController.tableEventsRef.trigger('facets:setupFacets');
                }
                deferred.resolve(this);
            }, this));

            return deferred.promise();
        },
        //before we filter - create a snapshot of the current state to go back to
        snapshotState: function() {
            this.snapshot = new OCQuery._Snapshot(_.extend({}, this.records.attributes), this.fullCollection);
        },
        snapshotFacets: function() {
            this.facetsSnapshot = new OCQuery._Snapshot(_.extend({}, this.records.attributes), this.fullCollection);
        },
        deleteSnapshot: function(type) {
            // returns true if successful or false if error
            if (type === 'facets') {
                if (this.facetsSnapshot) {
                    delete this.facetsSnapshot;
                } else {
                    // No facets snapshot found! Returning current state.
                    return false;
                }
            } else {
                if (this.snapshot) {
                    delete this.snapshot;
                } else {
                    // No snapshot found! Returning current state.
                    return false;
                }
            }
            return true;
        },
        getSnapshot: function(type) {
            if (type === 'facets') {
                if (this.facetsSnapshot) {
                    return this.facetsSnapshot;
                } else {
                    app.log.error("No facets snapshot found! Returning current state.");
                    return;
                }
            } else {
                if (this.snapshot) {
                    return this.snapshot;
                } else {
                    app.log.error("No snapshot found! Returning current state.");
                    return;
                }
            }
        },
        //util methods for supporting different search modes
        getMode: function() {
            return this.mode;
        },
        //default to client mode
        client: function() {
            return this.mode === 'client';
        },
        server: function() {
            return this.mode === 'server';
        },
        parse: function(query) {
            //state_keys are exepected to be in camelCase
            _.each(query.state, function(value, key) {
                var camelCase = StringUtils.toCamelCase(key);
                query.state[camelCase] = value;
                //only delete the key if snake_case differs from camelCase
                if (camelCase !== key) {
                    delete query.state[key];
                }
            }, this);
            //get inital attributes such as firstPage, lastPage, etc
            //OpenContent doesn't return these state attributes
            query.state = _.extend(this.state, query.state);
            return query;
        },
        parseRecords: function() {
            app.log.debug('OCQuery: parsing records');
        },
        getPage: function(page) {
            //update the internal records keeper
            this.records.changePage(page);
            //call parent implementation
            OCQuery.Collection.__super__.getPage.apply(this, arguments);
        },
        setPageSize: function(pageSize) {
            //update the internal records keeper
            this.records.changePageSize(pageSize);
            //call parent implementation
            OCQuery.Collection.__super__.setPageSize.apply(this, arguments);
        },
        setFacets: function(facets) {
            this.state.facets = facets;
            if (facets) {
                this.records.set('facets', facets);
            } else {
                this.records.unset('facets');
            }
            if (!this.snapshot && facets) {
                //only do this once
                //snapshot the current state
                this.snapshotState();
            }
        },
        setFiltering: function(filtering) {
            this.state.filtering = filtering;
            this.records.set('filtering', filtering);
            if (!this.snapshot && filtering) {
                //only do this once
                //snapshot the current state
                this.snapshotState();
            }
        },
        _loadSnapshot: function(type) {
            var snapshot = this.getSnapshot(type);
            //internal method for loading a snapshot as the working state of the collection
            var loadSnapshotDeferred = $.Deferred();
            if (!snapshot) {
                app.log.error("No " + type + " snapshot found! Returning current state.");
            }
            this.state = _.extend({}, this.state, _.omit(snapshot.attributes, 'pageSize'));
            //update the backing collection
            // must deep copy full collection to de-reference all the nested attributes for GC to dispose of
            this.fullCollection.reset(_.extend([], snapshot.fullCollection.models));
            //update page size
            this.setPageSize(this.state.pageSize);
            //reset currentPage to the firstPage
            this.getPage(0);
            loadSnapshotDeferred.resolve(this);
            return loadSnapshotDeferred.promise();
        },
        addGenericParam: function(param, queryParams) {
            if (param.paramType === 'type') {
                queryParams.oc_type.push(param.paramName);
            } else if (param.paramType === 'allproperties') {
                queryParams.oc_allproperties.push(param.paramValue);
            } else if (param.paramType === 'searchallversions') {
                queryParams.oc_searchallversions.push(param.paramValue);
            } else if (param.paramType === 'options') {
                if (param.paramName === 'limit_results') {
                    queryParams.limit_results = param.paramValue;
                }
            }

            return queryParams;
        },
        setUpCompositeParams: function(searchParameters, selectedType) {
            // This will hold the correct setup for the composite params to be used in search.
            var compositeParams = [];

            app.context.configService.getAdminTypeConfig(selectedType, function(currentOTC) {
                _.each(searchParameters, function(param) {
                    _.each(currentOTC.get('attrs').models, function(attr) {
                        // Determine if this is an attribute we are interested to search on (and push as a search param).
                        var pushAsSearchParam = (attr.get('ocName') === param.paramName);
                        var typeAttrMap = [];

                        _.each(attr.get('attrTable'), function(attrParam) {
                            if (pushAsSearchParam) {
                                // Build up the attr type map (the single object types that compose this composite attr)
                                typeAttrMap.push({
                                    'type': attrParam.typeOCname,
                                    'attr': attrParam.attrOCname
                                });
                            }

                        });

                        if (pushAsSearchParam) {
                            compositeParams.push({
                                'value': param.paramValue,
                                'typeAttrMap': typeAttrMap
                            });
                        }
                    });
                });

            }); //end getAdminOTC

            return compositeParams;
        },
        parseCompositeParams: function(compositeParams, compositeQueryParams) {
            _.each(compositeParams, function(param) {
                var tempString = '';
                tempString += param.value;
                tempString += '~_~';
                _.each(param.typeAttrMap, function(typeAttr) {
                    tempString += typeAttr.type;
                    tempString += '~:~';
                    tempString += typeAttr.attr;
                    tempString += '~:~';
                    tempString += typeAttr.operator;
                    tempString += '#';
                  });

                tempString = tempString.substring(0, tempString.length - 1);

                //add to compositeQueryParams
                compositeQueryParams.push(tempString);
            });
        }
    });

    //DO NOT INSTANTIATE DIRECTLY - OCQuery owns an internal copy
    OCQuery._TotalRecords = Backbone.Model.extend({
        //override the URL to fetch the total records and initial page count
        url: app.serviceUrlRoot + "/query/totalRecords",
        defaults: {
            'prev': false,
            'next': false,
            'filtering': false,
            'currentPage': 0,
            'totalPages': 1
        },
        initialize: function(options, config) {
            this.options = options;

            this.collection = config.collection;

            this.mode = config.collection.mode || 'client';

            this.applyListeners();
        },
        applyListeners: function() {
            //listen to internal changes
            this.listenTo(this, 'change:currentPage', function(model, currentPage) {
                this.changePage(currentPage);
            }, this);

            if (this.mode === 'client') {
                //listen for the collection to update when in client-mode
                this.listenTo(this.collection, 'query:complete', function(updatedCollection) {
                    this.collection = updatedCollection;

                    //correct state can be found on the collection object
                    this.set(this.collection.state);

                    //update prev / next pages
                    this.changePage(this.collection.state.currentPage);
                }, this);
            }
        },
        parseRecords: function(response) {
            //don't parse for search results, just return the metadata
            return response;
        },
        fetch: function() {
            //when configured for server-side we need to make an initial call to get the total results and total page count

            //this is weird here but we need to proc a full query to get the records back
            //masqurading as a Backbone.Pageable collection
            //this is because a Backbone collection or model only supports one backing URL

            //we only want to fetch once - from there we can re-calculate the number of pages
            //as the page size changes client-side
            var fetched;
            if (this.collection.mode === 'server') {
                fetched = this.collection.fetch({
                    //highjack the /query url to point to /totalRecords instead
                    url: this.url,
                    //do it silently so we don;t alert anyone to this 'meta' search
                    silent: true
                });
            } else {
                //client-mode
                fetched = $.Deferred();
                fetched.resolve(this.collection.state);
            }

            //doing this weird collection -> model fetch doesn't call parse automatically
            fetched.done(_.bind(function(response) {
                this.parse(response);
            }, this));

            return fetched.promise();
        },
        parse: function(json) {
            //we only care about:
            // * current_page
            // * page_size
            // * total_records
            // * total_pages
            this.set(_.pick(json, ['currentPage', 'pageSize', 'totalRecords', 'totalPages']));
        },
        changePage: function(currentPage) {
            switch (currentPage) {
                case 'prev':
                    currentPage = this.get('currentPage') - 1;
                    break;
                case 'next':
                    currentPage = this.get('currentPage') + 1;
                    break;
            }
            //update prev / next
            this.set({
                'currentPage': currentPage,
                'prev': currentPage - 1 > 0,
                'next': currentPage + 1 <= this.totalPages()
            }, {
                silent: true
            }); //don't cause a change loop
        },
        changePageSize: function(resultsPerPage) {
            var prevPageSize = this.pageSize(); //save this
            //update page size and re-calculate the total pages
            this.set('pageSize', resultsPerPage);
            this.set('totalPages', this.totalPages());
            //if page size has changed - reset to page #1
            if (prevPageSize !== this.pageSize()) {
                this.changePage(1); //goto page 1 and update next / prev
            }
        },
        currentPage: function() {
            return this.get('currentPage') < 1 ? 0 : this.get('currentPage');
        },
        totalPages: function() {
            var totalPages = Math.ceil(this.get('totalRecords') / this.get('pageSize'));
            return (window.isNaN(totalPages) || totalPages < 1) ? 1 : totalPages;
        },
        pageSize: function() {
            return this.get('pageSize');
        },
        totalRecords: function() {
            return this.get('totalRecords') || 0;
        },
        prev: function() {
            return this.get('prev');
        },
        next: function() {
            return this.get('next');
        }
    });

    ////DO NOT INSTANTIATE DIRECTLY - OCQuery owns an internal copy
    //snapshot implementation of TotalRecords that never updates
    //and doesn't have a reference to the backing collection
    OCQuery._Snapshot = OCQuery._TotalRecords.extend({
        url: undefined,
        initialize: function(options, fullCollection) {
            //omit the filtering flag
            this.options = _.omit(options, ['filtering']);
            this.fullCollection = fullCollection.clone();
        }
    });

    //Composite Search
    OCQuery.CompositeSearch = OCQuery.Collection.extend({
        mode: "client",
        url: function() {
            return app.serviceUrlRoot + "/query/searchComposite" + "?appId=" + app.appId + '&searchConfigName=' + app.context.currentSearchConfig().get('name');
        },
        initialize: function(collection, config) {
            // selected object type
            this.type = config.type;
            //call parent init
            OCQuery.CompositeSearch.__super__.initialize.apply(this, arguments);
        },
        fetch: function() {
            //setup query parameters
            this._setupQuery();
            var compositeParams = [];
            _.each(this.searchParameters, function(param) {
                if (param.paramType === 'compositeProperty') {
                    if (_.isArray(param.paramValue)) {
                        param.paramValue = param.paramValue.join("~|~");
                    }
                    compositeParams.push(param);
                } else {
                    this.queryParams = this.addGenericParam(param, this.queryParams);
                }
            }, this);
            var completedCompositeParams = [];
            completedCompositeParams = this.setUpCompositeParams(compositeParams, this.type, this.queryParams);
            this.parseCompositeParams(completedCompositeParams, this.queryParams.oc_compositeProperty);
            //flag this as a composite search
            this.compositeSearch = true;

            if(app.context.currentApplicationConfig() && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") && app.context.currentApplicationConfig().get("enableAlfrescCmisQuery") === 'true'){
                this.queryParams.alfrescoCmisQuery = true;
            }
            // call generic OCQuery fetch and pass back the deferred
            return OCQuery.fetch.apply(this, arguments);
        },
        setUpCompositeParams: function(searchParameters, selectedType) {
            // This will hold the correct setup for the composite params to be used in search.
            var compositeParams = [];

            app.context.configService.getAdminTypeConfig(selectedType, function(currentOTC) {
                _.each(searchParameters, function(param) {
                    _.each(currentOTC.get('attrs').models, function(attr) {
                        // Determine if this is an attribute we are interested to search on (and push as a search param).
                        var pushAsSearchParam = (attr.get('ocName') === param.paramName);
                        var typeAttrMap = [];

                        _.each(attr.get('attrTable'), function(attrParam) {
                            if (pushAsSearchParam) {
                                // Build up the attr type map (the single object types that compose this composite attr)
                                typeAttrMap.push({
                                    'type': attrParam.typeOCname,
                                    'attr': attrParam.attrOCname
                                });
                            }

                        });

                        if (pushAsSearchParam) {
                            compositeParams.push({
                                'value': param.paramValue,
                                'typeAttrMap': typeAttrMap
                            });
                        }
                    });
                });

            }); //end getAdminOTC

            return compositeParams;
        },
        parseCompositeParams: function(compositeParams, compositeQueryParams) {
            _.each(compositeParams, function(param) {
                var tempString = '';
                tempString += param.value;
                tempString += '~_~';
                _.each(param.typeAttrMap, function(typeAttr) {
                    tempString += typeAttr.type;
                    tempString += '~:~';
                    tempString += typeAttr.attr;
                    tempString += '~:~';
                    tempString += typeAttr.operator;
                    tempString += '#';
                  });

                tempString = tempString.substring(0, tempString.length - 1);

                //add to compositeQueryParams
                compositeQueryParams.push(tempString);
            });
        }
    });

    OCQuery.RelatedChildren = OCQuery.Collection.extend({
        mode: "client",
        // todo: add the correct new url for fetching a collections items (can we pass the id and use the same endpoint or should it be a new endpoint?)
        // todo: verify that using this in the collections route does not break the search route (test that it return results fine)
        // url: app.serviceUrlRoot + "/cmhr/collections/" + this.id
        initialize: function(options) {
            //call super constructor
            OCQuery.RelatedChildren.__super__.initialize.apply(this, arguments);
            var self = this;
            self.relationName = options.relationName;
            self.collectionId = options.collectionId;
        },
        url: function() {
            return app.serviceUrlRoot + "/content/getChildRelations?relationName=" + this.relationName + "&id=" + this.collectionId;
        },
        fetch: function(){
            // call generic OCQuery fetch and pass back the deferred
            return OCQuery.protofetch.apply(this, arguments);
        },
        formatResults: function(deferred, options) {
            if (!deferred) {
                deferred = $.Deferred();
            }
            //format OCOs
            var jqxhrArray = [];
            this.each(function(oco) {
                var typeConfig = $.Deferred();
                jqxhrArray.push(typeConfig);
                //store objectTypes in memory
                app.context.configService.getAdminTypeConfig(oco.get('objectType'), function(otc) {
                    typeConfig.resolve(otc);
                });
                $.when(typeConfig).done(function(otc) {
                    var formatJqxhr = oco.formatProperties(otc);
                    jqxhrArray.push(formatJqxhr);
                });
            });
            $.when.apply($, jqxhrArray).done(_.bind(function() {
                this.trigger('query:complete', this, options);
                deferred.resolve(this);
            }, this));

            return deferred.promise();
        }
    });

    OCQuery.FolderChildren = OCQuery.Collection.extend({
        model: OC.Folder,
        mode: "client",
        state: {
            pageSize: 20000,
            firstPage: 0
        },
        initialize: function(config) {
            //call super constructor
            OCQuery.FolderChildren.__super__.initialize.apply(this, arguments);
            this.config = config;
        },
        url: function() {
            return app.serviceUrlRoot + "/content/getFolderChildren?id=" + this.id;
        },
        fetch: function(){
            // call generic OCQuery fetch and pass back the deferred
            return OCQuery.protofetch.apply(this, arguments);
        },
        formatResults: function(deferred){
            app.log.warn('formatResults is not implemented for OCQuery.FolderChildren, only resolving deferred...');
            return deferred.resolve(this).promise();
        },
        parse: function(response) {
            OCQuery.FolderChildren.__super__.parse.apply(this, arguments);
            var compare = function(a, b) {
                if (a.objectName.toUpperCase() < b.objectName.toUpperCase()) {
                    return -1;
                }
                if (a.objectName.toUpperCase() > b.objectName.toUpperCase()) {
                    return 1;
                }
                return 0;
            };
            var newResponse = [];
            _.each(response, function(object) {
                if (object.objectName.charAt(0) !== '.') {
                    newResponse.push(object);
                }
            });
            response = newResponse.sort(compare);
            return response;
        }
    });

    OCQuery.NoFolderChildren = OCQuery.Collection.extend({
        mode: "client",
        state: {
            pageSize: 500,
            firstPage: 0
        },
        initialize: function(config) {
            //call super constructor
            OCQuery.NoFolderChildren.__super__.initialize.apply(this, arguments);
            this.config = config;
        },
        url: function() {
            return app.serviceUrlRoot + "/content/getChildren?id=" + this.id;
        },
        fetch: function(){
            // call generic OCQuery fetch and pass back the deferred
            return OCQuery.protofetch.apply(this, arguments);
        },
        formatResults: function(deferred){
            app.log.warn('formatResults is not implemented for OCQuery.NoFolderChildren, only resolving deferred...');
            return deferred.resolve(this).promise();
        },
        parse: function(response) {
            OCQuery.NoFolderChildren.__super__.parse.apply(this, arguments);
            var self = this;
            self.modelsToKeep = [];
            _.each(response, function(model) {
                var type = self.config.findWhere({
                    ocName: model.objectType
                });
                if (type && type.get("isContainer") !== "true") {
                    self.modelsToKeep.push(model);
                }
            });
            return self.modelsToKeep;
        }
    });

    OCQuery.Children = OCQuery.Collection.extend({
        state: {
            pageSize: 500,
            firstPage: 1
        },
        url : function() {
            if(this.mimetypeFilters){
                return app.serviceUrlRoot + "/content/getChildren?id=" + this.id + "&mimetypeFilters=" + this.mimetypeFilters;
            }else{
                return app.serviceUrlRoot + "/content/getChildren?id=" + this.id;
            }
        },
        fetch: function(){
            this.queryParams.oc_type = [];
            _.each(this.searchParameters, function(param) {
                this.addGenericParam(param, this.queryParams);
            }, this);

            var fetchType;

            if (this.context === HPIConstants.TableView.Context.VAD) {
                fetchType = OCQuery.fetch;
            } else {
                fetchType = OCQuery.protofetch;
            }
            
            return fetchType.apply(this, arguments);
        },
        formatResults: function(){
            OCQuery.Children.__super__.formatResults.apply(this, arguments);
        }
    });

    OCQuery.ChildrenWithLabels = OCQuery.Collection.extend({
        url: function() {
            return app.serviceUrlRoot + "/hpi/getChildrenWithLabels?id=" + encodeURIComponent(this.id);
        },
        fetch: function(){
            return OCQuery.protofetch.apply(this, arguments);
        },
        formatResults: function(deferred){
            app.log.warn('formatResults is not implemented for OCQuery.ChildrenWithLabels, only resolving deferred...');
            return deferred.resolve(this).promise();
        },
    });

    // Return the module for AMD compliance.
    return OCQuery;
});