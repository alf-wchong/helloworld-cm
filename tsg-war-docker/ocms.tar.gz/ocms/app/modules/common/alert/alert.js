// Alert module
define([
	"app"
],

function(app) {

	var Alert = app.module();

	// Default Model.
	Alert.Model = Backbone.Model.extend({
	
	});
	
	Alert.Views.Notification = Backbone.View.extend({
		template: "common/alert/notification",

		serialize: function() {
			return {
				message : this.options.notificationMsg,
				style : this.options.notificationStyle
			};
		}
	});
	
	// Default View.
	Alert.Views.Layout = Backbone.Layout.extend({
		tagName: "div",
		
		className: "modal",
		
		events: {
			"click #alertOK"	: "onClickAlertOK",
			"click #alertYes"	: "onClickAlertYes",
			"click #alertNo"	: "onClickAlertNo",
			"click #alertSignIn" : "onClickAlertSignIn"
		},

		template: "common/alert/item",

		initialize: function() {

			var that = this;
			that.$el.modal({backdrop: "static", show: false});

			// style: the kind of bootstrap alert we'd like to display. sample choices would be alert-success or alert-danger
			// message: the message that the alert should display. ie) "Error saving configuration"
			// element: the element to prepend the alert to. #configDetail will place it right above the right pane of hpiadmin
			this.listenTo(app, "alert:changeNotification", function(style, message, element, stay) {
				var notificationEl = new Alert.Views.Notification({
						notificationStyle : style,
						notificationMsg : message
					});
				// prepend notification to specified element
				if(that.notificationDisplayed !== true)
				{
					$(element).prepend(notificationEl.el);
					that.notificationDisplayed = true;
					notificationEl.render();
					
					//if stay is true, then make the alert stay visible
					if(!stay){
						// this bit of js removes the notification after a few moments
						setTimeout( function() {
							$(notificationEl.el).fadeTo(500, 0).slideUp(500, function(){
								$(that).remove();
								that.notificationDisplayed = false;
							});
						}, 5000);
					}
				}				
			});

			this.listenTo(app, "alert:changeNotificationClear", function() {
				$("#modificationAlert").remove();
				that.notificationDisplayed = false;
			});

			//alert error modal
			this.listenTo(app, "alert:error", function(options) {
				$(".modal").modal("hide");
				that.confirm = options.confirm;
				that.cancel = options.cancel;
				that.model = new Alert.Model({
					header: options.header,
					message: options.message,
					confirmLabel: options.confirmLabel || "OK",
					cancelLabel: options.cancelLabel || "Cancel",
					isConfirmation: false,
					timeStamp: Date()
				});
				that.render().promise().done(function(){
					//activate the modal
					that.$el.modal('show');
				});
			});

			//alert info modal
			this.listenTo(app, "alert:info", function(options) {
				that.confirm = options.confirm;
				that.cancel = options.cancel;
				that.model = new Alert.Model({
					header: options.header,
					message: options.message,
					confirmLabel: options.confirmLabel || window.localize("generic.ok"),
					cancelLabel: options.cancelLabel || window.localize("generic.cancel"),
					isConfirmation: false
				});
				that.render().promise().done(function(){
					//activate the modal
					that.$el.modal('show');
				});
			});

			//alert confirmation modal with different options "yes" and "no" for confirmation
			this.listenTo(app, "alert:confirmation", function(options) {
				that.confirm = options.confirm;
				that.cancel = options.cancel;
				that.model = new Alert.Model({
					header: options.header,
					message: options.message,
					confirmLabel: options.confirmLabel || window.localize("generic.yes"),
					confirmBtnClass: options.confirmBtnClass || "btn-default",
					cancelLabel: options.cancelLabel || window.localize("generic.no"),
					isConfirmation: true
				});
				that.render().promise().done(function(){
					//activate the modal
					that.$el.modal('show');
				});
			});

			//alert confirmation modal with different options "yes" and "no" for confirmation
			this.listenTo(app, "alert:authentication", function(options) {
				that.confirm = options.confirm;
				that.cancel = options.cancel;
				that.isAuthentication = true;
				that.model = new Alert.Model({
					header: options.header,
					message: options.message,
					confirmBtnClass: options.confirmBtnClass || "btn-default",
					confirmLabel: options.cancelLabel || window.localize("generic.cancel"),
					isConfirmation: false,
					isAuthentication: true
				});
				that.render().promise().done(function(){
					//activate the modal
					that.$el.modal('show');
				});
			});

			//alert custom modal
			this.listenTo(app, "alert:custom", function(options) {
				//wait for subview to render before displaying
				that.listenTo(options.view, 'afterRender', function(){
					//activate the modal
					_.defer(function(that){
						that.$el.modal({backdrop: "static", show: true});
					}, this);
				}, this);
				that.setView(options.view, false).render();
				//model is undefined so that other markups are rendered
				that.model = undefined;
			});

			//alert close
			this.listenTo(app, "alert:close", function() {
				that.$el.modal("hide");	
			});
		},
		cleanup : function(){
			this.$el.modal("hide");
		},

		beforeRender: function() {
			this.cleanup();
			this.removeView();	
		},
		afterRender: function(){
			this.rendered = true;
		},
		serialize: function() {
			if(this.model) {
				return this.model.toJSON();
			} else {
				return;
			}
		},

		onClickAlertOK: function(event) {
			this.$el.modal("hide");
			
			if(this.confirm) {
				this.confirm();
			}
			if(this.isAuthentication){
				app.stopListening(app, "alert:authSuccess");
				app.stopListening(app, "alert:authentication");
			}
		},
		
		onClickAlertYes: function(event) {
			this.$el.modal("hide");
			
			if(this.confirm) {
				this.confirm();
			}
		},
		
		onClickAlertNo: function(event) {
			this.$el.modal("hide");
			
			if(this.cancel) {
				this.cancel();
			}
		},

		/**
		 * Function grab username and password textboxes within modal and authenticate a user.
		 * Ensures that the user that we are authenticating is currently logged in.
		 * @param {*} event 
		 */
		onClickAlertSignIn: function(event){
			var that = this;

			//grab username and password
			var username = that.$('#login-modal-username').val();
			var password = that.$('#login-modal-password').val();


			//ensure that username matches currently logged in user
			if(username === app.user.get("loginName")){
				var opts = {
					type:   "POST",
					contentType:    "application/json",
					url:    app.serviceUrlRoot + "/authentication/newSession?username=" + username,
					data: JSON.stringify(password),
					success: function(result){
						//trigger listener in form support waiting for a successful login
						app.trigger("alert:authSuccess", {
							authSuccess : true
						});
						that.$el.modal("hide");
					},
					statusCode: {
						//need to keep this in here otherwise we get some really strange behaviour...
						401: function(){
							return;
						}
					},
					error: function(){
						//display error saying unable to authenticate
						that.$('#login-modal-error').show().fadeOut(7000);
					}
				};
				$.ajax(opts);
			}else{
				//display error saying invalid user
				that.$('#login-modal-invalidUserError').show().fadeOut(7000);
			}
		}
	});


// Return the module for AMD compliance.
return Alert;

});
