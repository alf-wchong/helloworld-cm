define([
	// Application.
	"app",
	"oc",
	"modules/actions/actionmodules",
	"modules/common/ocquery",
	"modules/common/action"
	
],

function(app,OC, actionModules, OCQuery, Action) {

	// Create a new module.
	var SplitDocumentsView = app.module();

	SplitDocumentsView.Section = Backbone.Model.extend({
        initialize: function(options){
            this.pageRange = options && options.pageRange ? options.pageRange : '';
            this.oco = options && options.oco ? options.oco : {};
            
            // Corresponds to whether the section in question is being edited, in which case we want to disable the delete button
            this.disabled = false;
        }
    });

    SplitDocumentsView.Sections = Backbone.Collection.extend({
        model: SplitDocumentsView.Section
    });

    //The subview that contains the information of the child documents of the document we are currently splitting.
	SplitDocumentsView.SelectedSplitsView = Backbone.Layout.extend({
        template: "common/splitdocumentsview",
        events: {
            'click a.btn-danger' : 'deleteSection',
            'click a.btn-primary' : 'previewSection',
            'click .savedsearch-result-link': 'updateSelectedSplit'
        },
        initialize: function() {
           var self = this;
           //if the user selects/deselects a page 
           this.listenTo(app.openAnnotate, 'changeActiveDocument', function(selectedPages) {
			 	this.setUnactive(selectedPages);
			});

           this.listenTo(app, "unhighlightSplitRows", function() {
           		this.allRowsUnactive();
           });

            // Selected pdfs
            this.sections = new SplitDocumentsView.Sections();

            _.each(this.options.sections, function(section) {
            	self.sections.add(section);
            	section.set("active", false);
            });

            // Whether or not the table should be shown (number of selected splits > 0) 
            if(this.sections.size() > 0) {
                self.showTable = true;
            }
            else {
            	self.showTable = false;
            }

            this.successList = [];
            this.errorList = [];
            this.errorMessage = undefined;

            this.listenTo(app, 'selectedsplitsview:remove', function(objectName) {
                // find target model
                var modelToRemove = this.sections.find(function(model) {
                    return model.get("objectName") === objectName;
                });

                // remove the target model
                this.sections.remove(modelToRemove);

                // remove table if no sections left
                if(this.sections.size() === 0) {
                    self.showTable = false;
                }

                this.render();
            });
        }, 
        addSection: function(oco, pageRange, overwriteObjName, isValid) {
            var section = new SplitDocumentsView.Section({pageRange: pageRange, oco: oco, objectName: oco.objectName, objectId: oco.objectId, active: false});

            if(overwriteObjName !== null) {
                var updateModel = this.sections.find(function(model) {
                    return model.get('objectName') === overwriteObjName;
                 });       
               
                updateModel.set("pageRange", pageRange);
                updateModel.set("oco", oco);
                //updateModel.set("disabled", false);
            }
            else {
                this.sections.add(section);
            }

            _.each(this.sections.models, function(model) {
            	model.set("active", false);
            });
            
            if(this.sections.size() === 1) {
                this.showTable = true;
            }

            this.render();
        },
        deleteSection: function(event) { 
            var self = this;
            var targetObjectName;
            if (event) {
                // Get the row that corresponds to the clicked delete button
                var row = this.$(event.currentTarget)[0].parentElement.parentElement;

                // Get the first child of the row, which will be the objectName of the split to delete
                targetObjectName = $(row).closest('tr').find('td:eq(0)').text();
            } else {
                // var formValues = this.getView("#splitpdf-fs-outlet").getValues();
                targetObjectName = this.getView('#splitpdf-fs-outlet').properties.objectName;
            }

            // Find the target model in the collection
            var modelToRemove = this.sections.find(function(model) {
                return model.get('objectName') === targetObjectName;
            });


            var deleteDocument = new Action.Model({
				name: 'deleteDocument',
			 	parameters: {
			 		objectId: modelToRemove.get("objectId"),
			 		auditEvent: false
			 	}
			});

			var errorMessage = window.localize("splitDocumentsView.deleteDoc");
			app.trigger("alert:confirmation", {
				header: window.localize("generic.warning"),
				message: errorMessage,
				confirm: function() {
					deleteDocument.execute({
					 	success: function() {
					 		if(modelToRemove.get("active") === true) {
				            	app.openAnnotate.trigger("pageSelectionRequested", []);
				            }
				            //show parent doc properties
				            app.trigger("showParentDocProperties");
					 		// Remove the target model
				            self.sections.remove(modelToRemove);

				            // If we no longer have sections, don't show the table
				            if(self.sections.size() === 0) {
				                self.showTable = false;
				            }
				            //Trigger event so the pages are removed from the pages being used array we
				            //use to determine what pages are accounted for in the split documents.
				            app.trigger("deleteSplitPages", modelToRemove.pageRange, modelToRemove.get("objectName"));

				            self.render();
						},
				 		error: function() {
					 		app.trigger({
					 			header: window.localize("splitDocumentsView.deleteDocError"),
					 			message: window.localize("splitDocumentsView.docDidNotDelete")
					 		});
					 	}
		 			});
				}		
			});

			


        },
        previewSection: function(event) {
            // Get the row that corresponds to the clicked delete button
            var row = this.$(event.currentTarget)[0].parentElement.parentElement;

            // Get the first child of the row, which will be the objectName of the split to delete
            var targetObjectName = $(row).closest('tr').find('td:eq(0)').text();

            // Find the target model in the collection
            var previewTarget = this.sections.find(function(model) {
                return model.get("objectName") === targetObjectName;
            });

            app.trigger("IndexerSplitPDF:previewRange", previewTarget.get('pageRange'));

        },
        //When user clicks on a name of one of the split docs
        updateSelectedSplit: function(evt){
            evt.preventDefault();
            this.sections.forEach(function(model) {
            	model.set("active", false);
            });

            var targetObjectName = evt.currentTarget.firstChild.nodeValue;
            var targetModel = this.sections.find(function(model) {
                return model.get("objectName") === targetObjectName;
            });
            _.each(this.sections.models, function(model) {
            	if(model.get("objectName") === targetObjectName) {
            		model.set("active", true);
            		targetModel.attributes.pageRange.map(Number);
            	}
            });

            app.openAnnotate.trigger("pageSelectionRequested", targetModel.attributes.pageRange);
            app.trigger("replacePropertiesView", targetModel.get("oco"));

            this.render();
        },
        //if the user selects/deselects a page the row that is currently active should be set to unactive
        setUnactive: function(selectedPages) {
        	var self = this;
         	this.sections.find(function(model) {
                if( model.get('active') === true) {
                 	if(model.attributes.pageRange.toString() !== selectedPages.toString()) {
                 		model.set("active", false);
                 		self.render();
                 	}
                 }
            });
         	app.trigger("showParentDocProperties");
        },

        allRowsUnactive: function() {
        	var self = this;
        	_.each(this.sections.models, function(model) {
        		if(model.get("active")) {
        			model.set("active", false);
        			self.render();
        		}
        	});
        	app.openAnnotate.trigger("pageSelectionRequested", []);
        },

        serialize: function() {
            return {
                showTable: this.showTable,
                selectedSplits: this.sections.models
            };
        }

    });

	return SplitDocumentsView;

});