// AddDocTemplate module
define([
	// Application.
	"app",
	"modules/common/ocquery"
],

// Map dependencies from above array.
function(app, Ocquery) {
	"use strict";

	var AddDocTemplate = app.module();

	AddDocTemplate.View = Backbone.View.extend({
		template: "common/addDocTemplate/addDocTemplate",
		events: {
			"click .availableTrac": "newObjectType"
		},
		initialize: function(){
			var self = this;
			this.objectTypes = [];
			this.templates = {};

			// needed for handle bars to not show the No Templates view untill the query returns
			this.firstRender = true;

			this.query = new Ocquery.Collection();
			this.query.searchParameters = [
				{
					paramType: "type",
					paramName: "tsgTemplate"
				},
				{
					paramType: "property",
					paramName: "tsgTemplateType",
					paramValue: "content"
				}
			];

			this.query.state.pageSize = 5000;

			this.query.fetch({
				global: false,
				success: function(resp){
					self.firstRender = false;
					self.parseTemplates(resp);
				}
			});
		},
		parseTemplates: function(resp){
			var self = this;
			app.context.configService.getAdminOTC(function(OTC){
				self.currentType = {ocName: window.localize("modules.common.addDocTemplate.selectAnObject"), label: window.localize("modules.common.addDocTemplate.selectAnObject")};

				self.configuredObjects = OTC.get("configs");

				_.each(resp.models, function(model){
					var objectType = self.configuredObjects.where({ocName: model.get("properties").tsgTargetType})[0];
					if(objectType){
						if(!self.templates[objectType.get("ocName")]){
							self.templates[objectType.get("ocName")] = new Backbone.Collection();
							self.objectTypes.push({ocName: objectType.get("ocName"), label: objectType.get("label")});
						}
						self.templates[objectType.get("ocName")].add(model);

						// need to have name directly on model to work with bulk upload file object.
						model.name = model.get("properties").objectName;
						// setting flag stating that this is a template document (grab content on back end)
						model.existingRepoId = model.get("objectId");

						// adding an 'isTemplate' flag so that we can check if we need to check the configured
						// white list when adding a template during Bulk Upload (we don't in this instance)
						model.isTemplate = true;
					}
				});

				if(self.objectTypes.length === 1){
					self.singleObjectType = true;
					self.currentType = self.objectTypes[0];

					self.setView("#addDocTemplate-selectedTemplate", new AddDocTemplate.TemplateListView({collection: self.templates[self.currentType.ocName]}));
				}

				self.render();
			});
		},
		newObjectType: function(event){
			if(this.currentType.ocName !== $(event.target).attr("value")){
				var newObjectType = _.where(this.objectTypes, {ocName: $(event.target).attr("value")})[0];
				this.currentType = newObjectType;
				this.setView("#addDocTemplate-selectedTemplate", new AddDocTemplate.TemplateListView({collection: this.templates[$(event.target).attr("value")]}));

				this.render();
			}
		},
		afterRender: function(){
			$(".dropZone").hide();
			$(".addDocButton").hide();
		},
		serialize: function(){
			return {
				currentType: this.currentType,
				objectTypes: this.objectTypes,
				singleObjectType: this.singleObjectType,
				firstRender: this.firstRender
			};
		}

	});

	AddDocTemplate.TemplateListView = Backbone.Layout.extend({
		template: "common/addDocTemplate/templateListView",
		events: {
			// "click .addTemplateDocRow": "addTemplateToList",
			"click .addTemplateDocLink": "addTemplateToList"
		},
		initialize: function(){
			this.templates = this.options.collection;

			var compare = function(a, b){
				if(a.get('properties').objectName < b.get('properties').objectName){
					return -1;
				}
				else{
					return 1;
				}
				return 0;
			};

			this.templates.models.sort(compare);
		},
		addTemplateToList: function(event){
			event.stopPropagation();
			var selectedModels = [];
			var objectId = $(event.target).attr("value");
			if(!objectId){
				objectId = $(event.target.parentElement).attr("value");
			}

			selectedModels.push(this.templates.where({objectId: objectId})[0]);


			app.trigger('bulkupload:filesUploaded', selectedModels);

			this.render();
		},
		afterRender: function(){
			$(".dropZone").hide();
			$(".addDocButton").hide();
		},
		serialize: function(){
			return {
				templates: this.templates.models
			};
		}
	});

	app.log.debug("Add Doc Template Module Initialized");

	return AddDocTemplate;
});