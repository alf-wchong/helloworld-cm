define([
	'app',
	'handlebars',
	'modules/common/hpiconstants'
], function(app, Handlebars, HPIConstants){

	var TypeAhead = Backbone.Layout.extend({
		template: 'common/typeahead/typeahead',
		className: 'form-horizontal',
		events: {
			'click .btn-typeahead': 'toggleDropdown',
			'mousedown .typeahead-dropdown > .list-group-item' : 'optionSelected',
			'blur .typeahead-dropdown': 'onDropdownBlur',
			'blur .typeahead-input': 'onBlur',  // tab triggers this, since the typeahead box loses focus when you hit tab, it can't be lumped in with the 'validateKeyPress' call
			'keypress': 'validateKeyPress'
		},
		initialize: function(config){
			this.options = (config.options instanceof Backbone.Collection ? _.pluck(config.options.models, 'attributes') : config.options) || [];
			this.loading = config.loading;
			if(this.loading){
				$.when(this.loading).done(_.bind(this.updateOptions, this));
			}
			this.selected = config.selected || '';
			this.placeholder = config.placeholder || '';
			this.displayKey = config.displayKey || 'displayValue';
			this.searchOn = config.searchOn || 'displayValue'; //fallback to displayValue
			this.showDropDown = false;
			this.isGrowable = config.isGrowable || false; //default to false
			this.tabIndex = config.tabIndex ? "tabindex=" + config.tabIndex : ''; //if tabIndex is not set, leave it out completely
			this.disabled = config.disabled;
			this.buildSearchIndex();
			this.hideNoResultMessage = config.hideNoResultMessage ? config.hideNoResultMessage : false;
			this.enterKeys = config.enterKeys ? config.enterKeys : [HPIConstants.CHARCODES.Enter];  // default to enter only if nothing is passed
			this.overrideLoading = config.overrideLoading;
		},
		buildSearchIndex : function(){
			//add value and displayValue for templating
			_.each(this.options, function(option){
				option.displayValue = option[this.displayKey];
				if(!option.value){
					//only set the value field if it doesn't already exist
					option.value = option[this.searchOn];
				}
			}, this);
			var reinit = this.datasource;

			// constructs the suggestion engine
			/* jshint ignore:start */
			var self = this;
			this.datasource = new Bloodhound({
			    datumTokenizer: function(datum) {
			        var tokens = datum ? Bloodhound.tokenizers.whitespace(datum[self.searchOn]) : [];
				    _.each(tokens,function(value){
	                  	//push each character and value!
	                  	//onto the tokens array for mid-string matches
	                  	_.each(value, function(character, index){
	                  		tokens.push(character);
	                  		tokens.push(value.substr(index, value.length));
	                  	}, this);
            	  	});
            	  	return tokens;
			    },
			    queryTokenizer: Bloodhound.tokenizers.whitespace,
			    local: this.options
			});
			/* jshint ignore:end */ 
			// kicks off the loading/processing of `local` and `prefetch`
			return this.datasource.initialize(reinit);
		},
		toggleDropdown: function () {
			this.showDropDown = !this.showDropDown;
			if (this.showDropDown) {
				this.$('.typeahead-dropdown-' + this.cid).show();
				// move the focus from the btn-typeahead to our dropdown
				// this allows us to use the scrollbar in IE
				this.$('.typeahead-dropdown-' + this.cid).focus();
			} else {
				this.closeDropdown();
			}
		},
		closeDropdown: function() {
			this.showDropDown = false;
			this.$('.typeahead-dropdown-' + this.cid).hide();
		},
		// close the dropdown as long as we didn't click on the typeahead button
		// since btn-typeahead click event calls toggleDropdown
		onDropdownBlur: function(event) {
			var shouldCloseDropdown = true;
			// if event.relatedTarget (the element gaining focus) is falsy, we'll close the dropdown
			// e.g. relatedTarget will be null if we clicked on an element 
			// the browser doesn't think gets focus such as a div with no tabindex
			if(event.relatedTarget) {
				// don't close the dropdown if the related target is the btn-typeahead
				shouldCloseDropdown = !_.contains(event.relatedTarget.classList, 'btn-typeahead');
			}

			if(shouldCloseDropdown) {
				this.closeDropdown();
			}
		},	
		validateKeyPress: function(e){
			if (this.enterKeys.indexOf(e.charCode) > -1){ // can't use "includes()" in IE 
				e.preventDefault(); // prevent any of these "enter keys" from actually showing up in the input box
				this.onBlur();
			}
		},
		getOptions: function(){
			return this.options;
		},
		before: function(){
			return this.typeaheadEl !== undefined;
		},
		clear: function(){
			this.before();
			this.selected = '';
			this.typeaheadEl.typeahead('val', '');
			this.trigger('change:selected', this.selected);
			return this;
		},
		optionSelected: function(evt){
			this.before();
			var selectedValue = $(evt.currentTarget).data('value').toString();
			this.setOption(selectedValue, true);
			//hide menu after selection
			this.toggleDropdown();
			return this;
		},
		updateOptions: function(options){
			this.options = options;
			this.datasource.clear(); 
			this.buildSearchIndex();
			//update dropdown list with new options
			if(this.rendered){
				this.render();
			}
		},
		clearOptions: function(){
			this.datasource.clear();
		},
		blur: function(){
			this.before();
			this.typeaheadEl.trigger('blur');
			return this;
		},
		onBlur: function () {
			this.closeDropdown();
			if (!this.typeaheadEl) {
				app.log.error(window.localize("modules.common.typeAhead.typeAheadInstance") + this.cid + window.localize("modules.common.typeAhead.notFound"));
			}
			
			var selected = this.typeaheadEl.val();
			if(!selected) {
				// The value of selected has changed and is now blank. We need to update $.typeahead and this.selected
				this.clear();
			} else {				
				//verify that the user's input matches an option
				this.datasource.get(selected, $.proxy(function(suggestions){
					this.processDatasourceSuggestions(suggestions, selected);
				}, this));
			}
		},

		processDatasourceSuggestions: function(suggestions, selected){
			if(!suggestions || suggestions.length === 0){
				if(this.isGrowable && selected.length > 0) {
					this.setOption({'value': selected});
				} else {
					// trigger text to disappear in typeahead on tab with no autocomplete suggestions
					this.setOption({'value': undefined, 'displayValue': undefined});
					this.trigger('change:selected'); //proc empty selection	
				}
			}else{
				//looking for an exact match
				var valid = false;
				_.each(suggestions, function(suggestion){
					if(selected.toLowerCase() === suggestion.displayValue.toLowerCase()){
						valid = true;
						return;
					}
				}, this);
				if(!valid){
					this.setOption({'value': undefined, 'displayValue': undefined});
					this.trigger('change:selected'); //no match found, proc empty selection	
				}else{
					this.setOption({'value': selected, 'displayValue': selected});
				}
			}
		},

		setOption: function(value, updateTypeahead){
			var rendered = this.before();
			var selectedValue = value;
			//get whole option
			if(selectedValue instanceof Object){
				this.selected = selectedValue;
			}else{
				this.selected = _.findWhere(this.options, {'value': selectedValue});
				//if we don't have a match and the typeahead is growable, just add the value
				if(!this.selected && this.isGrowable) {
					this.selected = value;
				}
			}
			if(rendered && updateTypeahead && this.selected){
				this.typeaheadEl.typeahead('val', this.selected.displayValue);
			}
			this.trigger('change:selected', this.selected);
			return this;
		},
		afterRender: function(){
			this.rendered = true;
			this.typeaheadEl = this.$('.typeahead-' + this.cid);
			if(!this.typeaheadEl){
				app.log.error(window.localize("modules.common.typeAhead.typeAheadInstance") + this.cid + window.localize("modules.common.typeAhead.notFound"));
			}
			this.typeaheadEl.typeahead({
			    hint: true,
			    highlight: true,
			    minLength: 1
			},
			{
			    displayKey: this.displayKey || 'displayValue',
			    // `ttAdapter` wraps the suggestion engine in an adapter that
			    // is compatible with the typeahead jQuery plugin
			    source: this.datasource.ttAdapter(),
			    templates: {
					empty: this.noResultTemplate(),
				    suggestion: this.searchResultTemplate()
				}
			})
			.on('typeahead:selected ', $.proxy(function (obj, datum) {
				this.setOption(datum);
			}, this))
			.on('typeahead:opened ', $.proxy(this.closeDropdown, this))
			.on('typeahead:autocompleted', $.proxy(function (obj, datum) {
				this.setOption(datum);
			}, this));

			//typeahead re-rendered - set value if selected
			if(this.selected){
				this.typeaheadEl.typeahead('val', this.selected.displayValue);
			}

			//if options are showing, show them
			if(this.showDropDown){
				this.$('.typeahead-dropdown-' + this.cid).show();
			}
			
			this.trigger('render:done');
		},
		serialize: function(){
			return {
				cid: this.cid,
				placeholder: this.placeholder,
				options: this.options,
				loading: this.disabled || (this.overrideLoading ? false : (this.loading ? (this.loading && this.loading.state() !== "resolved") : (!this.options || this.options.length === 0))),
				tabIndex: this.tabIndex
			};
		},
		searchResultTemplate: function(){
			return Handlebars.compile('<p class="list-group-item typeahead-result typeahead-item" data-value="{{value}}">{{displayValue}}</p>');
		},
		noResultTemplate: function(){
			if (this.hideNoResultMessage){
				return '';
			}
			if (this.isGrowable) {
				return Handlebars.compile('<p class="list-group-item typeahead-item">'+ window.localize("modules.common.typeAhead.sorryToAdd")+'</p>');
			} else {
				return Handlebars.compile('<p class="list-group-item typeahead-item">' +window.localize("modules.common.typeAhead.sorryPleaseTry")+'</p>');
			}
		}
	});

	return TypeAhead;
});