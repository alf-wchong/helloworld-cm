define([
	"app",
	"spin"
],
function(app, Spinner) {

	var HPISpinner = app.module();

	// method to create a spinner using the spin.js library and return it - accepts an object representing the settings to use
	// (any left out overrides will use the defaults) and a domElement of where to append the spinner as a first child of (NOTE: this
	// must be a sinlge element [a jQuery selector statement will return an array of matched elements])
	HPISpinner.createSpinner = function(overrideOpts, domElement) {
		// these are actually overrides of the defaults defined in spin.js but for us we can consider them defaults
		// the passed in overrideOpts will override any of these or any of the defaults in spin.js
		var defaultOpts = {
			lines: 20, // The number of lines to draw
			length: 0, // The length of each line
			width: 3, // The line thickness
			radius: 6, // The radius of the inner circle
			rotate: 25, // The rotation offset
			corners: 0,
			speed: 1.1,
			direction: 1,
			color: '#ff9015',
			fadeColor: '#FFFFFF',
			animation: 'spinner-line-fade-quick',
			shadow: false, // Whether to render a shadow
			hwaccel: false, // Whether to use hardware acceleration
			className: 'loading-spinner' // The CSS class to assign to the spinner
		};

		// override our defaults with the passed in options
		var spinnerOpts = _.extend(defaultOpts, overrideOpts);

		// create our spinner, append it to the DOM and return it - so the calling function can manage it
		return new Spinner(spinnerOpts).spin(domElement);
	};

	// method to destroy a spinner, which means remove the spinner from the DOM
	HPISpinner.destroySpinner = function(spinner) {
		// if we've defined a spinner, let's stop it (which removes it from the DOM too)
		if(spinner) {
			spinner.stop();	
		}
	};

	return HPISpinner;

});