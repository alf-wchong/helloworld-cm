// printToRepo module
define([
	// Application.
	"app",
	"oc",
	"moment",
	"modules/common/ocquery"
],

// Map dependencies from above array.
function(app, OC, Moment, Ocquery) {

	var printToRepo = app.module();

	printToRepo.View = Backbone.View.extend({
		template: "common/printToRepo/printToRepo",
		events: {
			"click button#addDocLink": "addDocToList",
			"click button#removeFromRepo" : "removeFromRepo",
			"click .launchInNewTab" : "launchInNewTab"
		},
		initialize: function(options){
			/** Master list of all models brought back from query */
			this.queryResults = {};

			/** Object of only the models showing in the table */
			this.modelsToDisplay = {};

			/** Array of docuemnts selected for print */
			this.addedDocs = [];
			
			this.query = new Ocquery.Collection();
			this.query.searchParameters = [
				{
					paramName: "tsg_username",
					paramValue: app.user.get(app.uniqueUserName),
					paramType : "property"
				},
				{
					paramName: "tsg_printToRepo",
					paramType: "type",
					paramValue: "tsg_printToRepo"
				}
			];

			this.query.state.pageSize = 5000;

			this.query.fetch({
				global: false,
				context: this,
				success: this.parseResponse
			});

			// get selected files from bulk upload and show them in the file picker blob
			_.each(options.selectedFiles, function(file){
				this.addedDocs.push(file.existingRepoId);
			}, this);

			// listen for documents being removed from file picker blob and 
			// show them in the table
			this.listenTo(app, "printToRepo:updateTable", function(objectId){
				this.addedDocs.splice(this.addedDocs.indexOf(objectId), 1);		
				this.modelsToDisplay[objectId] = this.queryResults[objectId];
				this.render();
			});
		},

		parseResponse: function(resp){
			app.context.dateService.getDatetimeTimezoneFormat().done(_.bind(function(dateTimeFormat) {
				this.formatProperties(dateTimeFormat, resp);
			}, this));			

			this.render();
		},

		/**
		 * Handles the response brought back from the OCQuery
		 * @param {Object} resp : response brought back from ajax call
		 * @param {Object} dateTimeFormat : allows us to format date 
		 */
		formatProperties: function(dateTimeFormat, resp) {
			var dateFormat = dateTimeFormat.dateFormat;
			var timeFormat = dateTimeFormat.timeFormat;
			var timezoneFormat = dateTimeFormat.timezoneFormat;

			_.each(resp.models, function(model){
				//map model to objectId
				this.queryResults[model.get("properties").objectId] = model;
				this.modelsToDisplay[model.get("properties").objectId] = model;

				// need to have name directly on model to work with bulk upload file object.
				model.name = model.get("properties").objectName;

				// add new creation date directly to model for easy grabbing in html
				model.creationDate = app.context.dateService._formatDatetime(model.get("properties").creationDate, dateFormat, timeFormat, timezoneFormat);
				//model.creationDate = app.context.dateService.getFormattedDatetime(model.get("properties").creationDate);
				
				// setting flag stating that this is a template document (grab content on back end)
				model.existingRepoId = model.get("properties").objectId;

				// setting flag stating that this is a print from repo document
				model.isPrintToRepo = "true";
			}, this);
		},

		/**
		 * Adds a document to the bulk upload blob when selected
		 * @param {*} event 
		 */
		addDocToList: function(event){
			event.stopPropagation();
			var selectedModels = [];
			var objectId = $(event.target).attr("value");

			selectedModels.push(this.queryResults[objectId]);

			//add to master array of files in blob
			this.addedDocs.push(objectId);

			app.trigger('bulkupload:filesUploaded', selectedModels);
			this.render();
		},

		/**
		 * Prompts user with a modal to confirm removing a document from repo
		 * @param {*} event 
		 */
		removeFromRepo : function(event){
			event.stopPropagation();
			var modelObjectId = $(event.target).attr("value");

			//prompt with modal to confirm removal
			app.trigger("alert:confirmation", {
                message: window.localize("common.printToRepo.modal"),
                header: window.localize("modules.common.oc.confirmRemoval"),
                confirm: _.bind(this.modalConfirmation, this, modelObjectId)
            });
		},
		
		/**
		 * Removes a document from the repository and view
		 * @param {String} modelObjectId : objectId of the model 
		 */
		modalConfirmation : function(modelObjectId){
			//Create new oco so that we can destroy it
			var newOco = new OC.OpenContentObject({
				objectId: modelObjectId
			});
			newOco.destroy();

			//delete object form our master list and view
			delete this.queryResults[modelObjectId];
			delete this.modelsToDisplay[modelObjectId];

			this.render();
		},

		/**
		 * Launches a preview of the selected document in a new tab
		 * @param {*} event 
		 */
		launchInNewTab : function(event){
			var objectId = $(event.target).attr("value");
			//get filename from master list
			var objectName = this.queryResults[objectId].name;

			window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(objectName) + "?id=" + 
			objectId + "&overlay=true&contentType[]=" + ["pdf", "txt", ".*"], "_blank");
		},

		beforeRender: function(){
			//ensure that documents that are selected do not appear in table
			_.each(this.addedDocs, function(objectId){
				delete this.modelsToDisplay[objectId];
			}, this);
		},
		
		serialize: function(){
			return {
				docs : this.modelsToDisplay
			};
		}
	});

	return printToRepo;
});