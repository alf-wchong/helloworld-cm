define([
    "app",
    'oc',
    "modules/hpiadmin/hpiadmin"
],

function(app, OC,Hpiadmin) {

    var ForgotPassword = app.module();
    ForgotPassword.Model = Hpiadmin.Config.extend({
        type: "ForgotPassword",
        defaults: {
            type: "ForgotPassword"
        }
    });

    ForgotPassword.Views.Layout = Backbone.Layout.extend({
        className: "ForgotPassword",
        template: "forgotPassword",
        events: {
            "click #forgotPassword-enter": "checkEmailAndUsername",
            "keyup #forgotPassword-emailUserName-input": "checkIfEmpty"
        },
        initialize: function(){
            this.userName = null;
        },
        checkIfEmpty: function(){
            var self = this;
            self.input = $('#forgotPassword-emailUserName-input').val();
            if(self.input === ''){
                $('#forgotPassword-enter').attr("disabled", true);
            }else{
                $('#forgotPassword-enter').attr("disabled", false);
            }
        },
        checkEmailAndUsername: function(){
            var self = this;
            self.input = $('#forgotPassword-emailUserName-input').val();

            //should I check that this email exists?
            //this just checks to see if an @ symbol is in the input field
            // var emailReg =/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9])+$/;
            self.userName = self.input;
            $.ajax(
            {
                url: app.serviceUrlRoot + "/users/userForgotPassword?userName=" + self.userName, 
                type: "POST",
                contentType: "application/json",
                success: function (results) {
                    $('#forgotPassword-emailUserName-input-error').text('');
                    var passingOptions = {
                        'results': results
                    };
                    self.setView('#forgotPassword-modal', new ForgotPassword.RecoveryCode(passingOptions)).render();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app.log.debug("'The user you have entered does not exist.");
                    if(jqXHR.status === 500){
                        $('#forgotPassword-emailUserName-input-error').text('The user you have entered does not exist.');
                    }
                },     
                global : false
            });
        }

    });
   ForgotPassword.RecoveryCode = Backbone.Layout.extend({
        template: "forgotPasswordRecoveryCode",
        events: {
            "click #forgotPassword-code-enter" : "checkRecoveryCode",
            'keyup #forgotPassword-newPassword': "checkPasswords",
            'keyup #forgotPassword-newPasswordConfirm': "checkPasswords"
        },
        initialize: function(options) {
            this.userInfo = options.results;
        },
          checkPasswords: function(){
            var password = this.$("#forgotPassword-newPassword").val();
            var confirmPassword = this.$("#forgotPassword-newPasswordConfirm").val();
            if(confirmPassword === password){
                this.$("#forgotPassword-newPasswordConfirm-error").text('');
                this.$("#forgotPassword-newPassword-error").text('');
                 $('#forgotPassword-code-enter').attr("disabled", false);
            }else{
                 this.$("#forgotPassword-newPasswordConfirm-error").text('Password and Confirm Password dont match!');
                 this.$("#forgotPassword-newPassword-error").text('Password and Confirm Password dont match!');
                  $('#forgotPassword-code-enter').attr("disabled", true);
            }
        },
        checkRecoveryCode: function(){
            var self = this;

            //"/users/checkRecoveryCode
            self.code = $('#forgotPassword-code').val();
            self.password = self.$("#forgotPassword-newPassword").val();
            $.ajax(
            {
                url: app.serviceUrlRoot + "/users/checkRecoveryCode?userName=" + self.userInfo.userName +"&code=" + self.code+ "&password=" + self.password, 
                type: "POST",
                contentType: "application/json",
                success: function (results) {
                    $('#forgotPassword-code-error').text('');
                    app.trigger("alert:close");
                   
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app.log.debug("There was an error with the code. Please make sure you entered in the code correctly.");
                    if(jqXHR.status === 500){
                        $('#forgotPassword-code-error').text('There was an error with the code. Please make sure you entered in the code correctly.');
                    }
                },     
                global : false
            });
        }
        
    });
    return ForgotPassword;
});
