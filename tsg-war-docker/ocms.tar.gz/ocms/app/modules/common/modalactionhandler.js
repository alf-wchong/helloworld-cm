// Modal Action Handler
// Responsible for Displaying Actions in a Bootstrap Modal Dialog

define([
    "app",
    "modules/actions/actionmodules",
    'modules/common/hpiconstants'
],

function(app, ActionModules, HPIConstants) {

    // Create a new module
    var ModalActionHandler = app.module();

    // This, like any action handler, when instantiated will put an event watcher on app
    app.modalActionHandler = _.extend({}, Backbone.Events);

    // ### Main View
    ModalActionHandler.View = Backbone.Layout.extend({

        // Choose the template / classname of the created div and some basic DOM interactivity event handling
        template: "common/modalactionhandler",
        className : "modal-wrapper",
        events: {
            "shown.bs.modal #modal-action-handler": "_insertSubView",
            "hidden.bs.modal #modal-action-handler": "_onModalHidden",
            "click #modal-close-div": "_displayDisabledMessage"
        },
		initialize: function () {
            //initialize empty action (this will contain the context of the action that is currently being used)
            this.action = {};

            //initialize the modal elements (updated in the afterRender)
            this.$modal = null;
            this.$modalTitle = null;
            this.$modalSubTitle = null;

            this._applyListeners();
        },
        _clearModal: function () {
            $("#" + HPIConstants.Handlers.ModalActionHandler + "-content").children().remove();

            $("#" + HPIConstants.Handlers.ModalActionHandler + "-error").empty();
            $("#" + HPIConstants.Handlers.ModalActionHandler + "-message").empty();
            $("#" + HPIConstants.Handlers.ModalActionHandler + "-info").empty();

            // since we have styling applied to the error/message containers - we have to hide them as well as removing their contents
            this._hide("error");
            this._hide("warning");
            this._hide("message");
            this._hide("info");
            this._hide("progressBar");
        },
        _onModalHidden: function () {
            this._clearModal();
            $("#modalIFrame").attr("src","about:blank");
            this._toggleModalClose(false);
            app[HPIConstants.Handlers.ModalActionHandler].trigger("hide");

            if (this.currentActionView && _.isFunction(this.currentActionView.onDismiss)) {
                this.currentActionView.onDismiss();
            }
        },

        _displayDisabledMessage: function() {
            if(this.action.options.config.get("modalBackdrop") === "static" && this.action.options.config.get("instantExecute") === "true") {
                this._show("error", window.localize("modalActionHandler.error.cantCloseModal"), false);
            }
        },

        _toggleModalClose: function(val) {
            this.$("#close").attr("disabled", val);
        },
        /** 
        * Set and render the action in the modal. Add success and error listeners if the action is a subaction.
        */
        _insertSubView: function () {
            this.currentActionView = new this.actionModule.View(this.action.options);
            
            if(this.action.options.subactionDeferred && this.action.options.isSubaction) {
                // listen for success and failure events on the subaction
                // resolve or reject the parent action deferred accordingly
                this.listenTo(this.currentActionView, "action:success", this._resolveSubactionDeferred);
                this.listenTo(this.currentActionView, "action:failure", this._rejectSubactionDeferred);
            }

            this.setView("#" + HPIConstants.Handlers.ModalActionHandler + "-content", this.currentActionView).render();
        },
        _removeSubView: function (confirmationMessage){
            //if confirmation exists, this will be true (truthy value)
            //if the action is complete, then don"t show the confirmation message
            if(confirmationMessage){
                if(window.confirm(confirmationMessage)){
                    this.$modal.modal("hide");
                    //use the showPane booleans on the stage viewModel to correctly
                    //show what panes should be shown
                    app.trigger("stage.showPanes");
                    this.removeView("#" + HPIConstants.Handlers.ModalActionHandler + "-content");
                }
            } else {
                //This causes a redundant call to this method, but it also procs bs.modal's
                //  hide event, which isn't proc'd when an action calls hide, while this function is.
                //  Don't really know if this is what we want or what it would affect.
                this.$modal.modal("hide");
                //use the showPane booleans on the stage viewModel to correctly
                //show what panes should be shown
                app.trigger("stage.showPanes");
                this.removeView("#" + HPIConstants.Handlers.ModalActionHandler + "-content");
            }
        },

        /**
         * Removes subview if the removeSubactionOnCompletion flag is truthy
         */
        _cleanupSubactionView: function () {
            if(this.action.options.removeSubactionOnCompletion) {
                this._removeSubView();
            }
        },

        /**
         * Callback for the action:failure event. Cleanup subview and reject subaction deferred
         * @param  {Object} actionResults An object containing the results of the subaction.
         */
        _rejectSubactionDeferred: function (actionResults) {
            this._cleanupSubactionView();
            this.action.options.subactionDeferred.rejectWith(this.action.options.actionContext, [actionResults]);
        },

        /**
         * Callback for the action:success event. Cleanup subview and resolves subaction deferred
         * @param  {Object} actionResults An object containing the results of the subaction.
         */
        _resolveSubactionDeferred: function (actionResults) {
            this._cleanupSubactionView();            
            this.action.options.subactionDeferred.resolveWith(this.action.options.actionContext, [actionResults]);
        },

		// this function is used to show html elements based on the end of their id string 
		// which is passed in as a parameter, you can also pass in a message or view to display the
		// html element with and a _clearModal boolean which says whether or not we want to clear the modal 
		// before showing it
        _show: function( idStringEnding,  messageOrView,  _clearModal) {
            if(_clearModal) {
                this._clearModal();
            }

            if (_.isString(messageOrView)) {
                $("#" + HPIConstants.Handlers.ModalActionHandler + "-" + idStringEnding).html(messageOrView);
            } else if (_.isObject(messageOrView)){
                this.setView("#" + HPIConstants.Handlers.ModalActionHandler + "-" + idStringEnding, messageOrView).render();
            }
            
            $("#" + HPIConstants.Handlers.ModalActionHandler + "-" + idStringEnding).show();
        },

        /*
        * Sets the modal size, backdrop settings and the modal title.
        */
        _setupModal: function () {
            // Add our title to the modal -- retrieved from the action configuration in config-details.xml
            this.$modalTitle.html(window.localize(this.action.options.config.get("label")));
            this.$modalSubTitle.html(this.action.options.config.get("subTitle") ? this.action.options.config.get("subTitle") : "");

            var modalOptions = this.$modal.data("bs.modal").options;
            modalOptions.backdrop = this.action.options.config.get("modalBackdrop");

            if(modalOptions.backdrop === 'static' && this.action.options.config.get("instantExecute") === "true") {
                this._toggleModalClose(true);
            }

            if (this.action.options.config.get("modalSize") === HPIConstants.ModalSizes.Small) {
                this.$modal.find(".modal-dialog").removeClass("modal-xl").removeClass("modal-lg").addClass("modal-sm");
            } else if (this.action.options.config.get("modalSize") === HPIConstants.ModalSizes.ExtraLarge) {
                this.$modal.find(".modal-dialog").removeClass("modal-sm").removeClass("modal-lg").addClass("modal-xl");
            } else {
                this.$modal.find(".modal-dialog").removeClass("modal-sm").removeClass("modal-xl").addClass("modal-lg");
            }
        },

        /*
        * Grabs the action module and applies dynamic params.
        */
        _setupAction: function (options) {
            //set up the action
            this.action.options = options;

            this.actionModule = ActionModules.getAction(this.action.options.config.get("actionId"));
            
            //add dynamic params to the config -- these contain the overrideable/overridden
            //functions that we need
            var dynamicParams = ActionModules.getDynamicParams(this.action.options.config.get("actionId"));

            if (dynamicParams) {
                _.extend(this.action.options.config, dynamicParams);
            }
        },

        /*
        * Sets up the modal and displays it to the user. Callback for the show event.
        */
        _showModal: function (options) {
            this._clearModal();
            this._setupAction(options);
            this._setupModal();
            this.$modal.modal("show");
        },

		// this function is used to hide html elements based on the end of their id string 
		// which is passed in as a parameter
        _hide: function( idStringEnding ) {
            $("#" + HPIConstants.Handlers.ModalActionHandler + "-" + idStringEnding).hide();
        },
        _applyListeners : function() {
			// ## Module Listeners
            // This handler by nature is very event driven.  We can trigger events to show/hide the entire modal itself
            // messages contained within etc.

            // ### Listeners for Error Handling and Messaging
            // Basic listeners will replace the designated message areas on the dom with any relevant messages
            var that = this;
            this.listenTo(app.modalActionHandler, "showWarning",  function(messageOrView) { 
                this._show("warning", messageOrView, false); 
            });

            this.listenTo(app.modalActionHandler, "hideWarning", function() { 
                this._hide("warning"); 
            });

            this.listenTo(app.modalActionHandler, "showError", function(message, maintainModal) { 
                this._show("error", message, !maintainModal); 
            });

            this.listenTo(app.modalActionHandler, "hideError", function() { 
                this._hide("error"); 
            });
            
            this.listenTo(app.modalActionHandler, "showMessage", function(message) { 
                this._show("message", message, true); 
            });

            this.listenTo(app.modalActionHandler, "hideMessage", function() { 
                this._hide("message"); 
            });

            this.listenTo(app.modalActionHandler, "showInfo", function(message) { 
                this._show("info", message, false); 
            });

            this.listenTo(app.modalActionHandler, "hideInfo", function() { 
                this._hide("info"); 
            });

            this.listenTo(app.modalActionHandler, "showProgress", function() { 
                this._show("progressBar", null, false); 
            });

            this.listenTo(app.modalActionHandler, "hideProgress", function(){
                this._hide("progressBar"); 
                //lets also make sure its at 0 for bothIds
                $("#" + HPIConstants.Handlers.ModalActionHandler + "-progressBar .progress-bar").width(0 + '%');
                $("#" + HPIConstants.Handlers.ModalActionHandler + "-progressBar .progress-bar").text(0 + '%');
            });

            this.listenTo(app.modalActionHandler, "updateProgress", function(percent){
                $("#" + HPIConstants.Handlers.ModalActionHandler + "-progressBar .progress-bar").width(percent + '%');
                $("#" + HPIConstants.Handlers.ModalActionHandler + "-progressBar .progress-bar").text(percent + '%');
            });

            // show a loading indicator when we're setting up etc.
            this.listenTo(app.modalActionHandler, "loading", function(showLoading){
                if(showLoading){
                    $("#" + HPIConstants.Handlers.ModalActionHandler + "-content").hide();
                    $("#" + HPIConstants.Handlers.ModalActionHandler + "-loader").show();
                }else{
                    $("#" + HPIConstants.Handlers.ModalActionHandler + "-content").show();
                    $("#" + HPIConstants.Handlers.ModalActionHandler + "-loader").hide();
                }
            });

            this.listenTo(app.modalActionHandler, 'toggleModalClose', this._toggleModalClose);

            // ### Show Modal Listener
            // This handles much of the work needed to actually set up an actively displayed modal with an action
            this.listenTo(app.modalActionHandler, "show", this._showModal);

            // ### Hide Modal Listener
            // Responsible for cleaning up the modal when it's hidden
            this.listenTo(app.modalActionHandler, "hide", this._removeSubView);

            // ### Launch Modal Listener
            // This handles much of the work needed to actually set up an actively displayed modal with an action
            this.listenTo( app.modalActionHandler, "launch", function(options){
                that._clearModal();
                var config = options.config;
                //set up the action
                that.action.options = options;

                that.actionModule = ActionModules.getAction(that.action.options.config.get("actionId") );
                //add dynamic params to the config -- these contain the overrideable/overridden
                //functions that we need
                var dynamicParams = ActionModules.getDynamicParams(config.get("actionId"));
                if(dynamicParams){
                    _.extend(options.config, dynamicParams);
                }

                that.action.options.config = options.config;

                that.currentActionView = new that.actionModule.View(that.action.options);
                that.currentActionView.render();
            });
        },
        afterRender: function() {
            this.$modal = this.$(".modal");
            this.$modalTitle = this.$(".modal-title");
            this.$modalSubTitle = this.$(".modal-sub-title");

            this.$modal.modal({
                backdrop: 'static',
                keyboard: true,
                show: false
            });
        }
    });

    // Return the module for AMD compliance.
    return ModalActionHandler;
});
