define([
], function(){
	//a suite of utility functions for use throughout HPI
	var StringUtils = {};

    //convert snake_case to camcelCase
    StringUtils.toCamelCase = function(key){
        var words = key.split('_');
        var camelCase = '';
        //first word is lowercase
        camelCase += words.shift().toLowerCase();
        _.each(words, function(word){
      	     camelCase += (word[0].toUpperCase() + word.substr(1, word.length));
         }, this);
         return camelCase;
    };

    return StringUtils;
});
