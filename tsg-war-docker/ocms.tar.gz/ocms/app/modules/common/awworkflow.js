// Ocquery module
define([
	// Application.
	"app",
	"knockback",
	"knockout"
],

// Map dependencies from above array.
function (app, kb, ko) {

	// Create a new module.
	var AWWorkflow = app.module();

	/////////////// AWWorkflow TASKS ///////////////
	//Task Model
	AWWorkflow.TaskModel = Backbone.RelationalModel.extend({
		initialize: function (model, options) {
			var self = this;

			if (options && options.taskId) {
				self.id = options.taskId;
			}
		},
		parse: function (task) {
			//Format the task assigned date
			task.assignedDate = AWWorkflow.formatTaskDate(task.assignedDate);

			return task;
		}
	});

	//Unclaimed Task Group Model
	AWWorkflow.TaskGroupModel = Backbone.RelationalModel.extend({
		relations: [
			{
				type: Backbone.HasMany,
				key: 'tasks',
				relatedModel: AWWorkflow.TaskModel
			}
		],
		defaults: function () {
			return {
				"tasks": new AWWorkflow.TaskModel()
			};
		}
	});

	AWWorkflow.AWTasksModel = Backbone.Model.extend({
		model: AWWorkflow.TaskGroupModel,
		initialize: function(){
			this.groupTasks = new AWWorkflow.GroupTasksCollection();
			this.userTasks = new AWWorkflow.UserTasksCollection();
		},
		url: function () {
			//Get unclaimed tasks
			return app.serviceUrlRoot + "/aw-workflow/getAllWizardUserAndGroupTasks";
		},
		parse: function (response) {
			//The response is just a list of tasks. We need to 'sort' them into their respective groups.
			var collection = [];


			_.each(response, function (task) {

				//Format the assigned date
				task.assignedDate = AWWorkflow.formatTaskDate(task.assignedDate);

				if(task.candidateGroups.length > 0 && !task.assignee) {
					this.groupTasks.push(task);
				} else {
					this.userTasks.push(task);
				}
				
			}, this);
			collection = {
				"userTasks" : this.userTasks,
				"groupTasks": this.groupTasks
			};

			return collection;
		}
	});

	AWWorkflow.GroupTasksCollection = Backbone.PageableCollection.extend({
		mode: "client",
        state: {
            pageSize: 500,
            firstPage: 0
        },
		model: AWWorkflow.TaskGroupModel
	});

	AWWorkflow.UserTasksCollection = Backbone.PageableCollection.extend({
		mode: "client",
        state: {
            pageSize: 500,
            firstPage: 0
        },
		model: AWWorkflow.TaskGroupModel
	});

	//View Model for a task
	AWWorkflow.TaskViewModel = kb.ViewModel.extend({
		constructor: function (model) {
			var self = this;

			//kb.ViewModel.prototype.constructor.call(this, model, options);

			self.wfDocList = ko.observableArray();
			self.showWfDocList = ko.observable(false);
			self.psiName = kb.observable(model, "psiName");
			self.psiId = kb.observable(model, "psiId");
			self.roleName = kb.observable(model, "roleName");
			self.description = kb.observable(model, "description");
			self.assignedDate = kb.observable(model, "assignedDate");
			self.assignee = kb .observable(model, "assignee");
			self.assignTaskSuccess = ko.observable(false);

			self.claimTask = function () {
				//Make sure the task is pooled and unclaimed.
				if (self.assignee() === null && window.confirm(window.localize("modules.common.aWWorkflow.areYouSure"))) {
					self.assignTaskSuccess(false);
					$.ajax({
						url: app.serviceUrlRoot + "/workflow/acquiretask?taskId=" + model.get("id"),
						success: function () {
							self.assignTaskSuccess(true);
						}
					});
				}
			};

			return self;
		},
		showWfDocs: function(){
			var self = this;
			$.ajax({
				global: false,
				url: app.serviceUrlRoot + "/aw-workflow/getListOfWFDocsProps?formId=" + self.psiId(),
				success: function(response) {
					if (response !== undefined) {
						if(response.length > 0) {
							self.wfDocList(_.pluck(_.pluck(response,'properties'), 'documentNumber'));
						} else {
							self.wfDocList.push("No workflow docs.");
						}
					}
				}
			});
			self.showWfDocList(true);
		}
	});

	AWWorkflow.TaskGroupViewModel = kb.ViewModel.extend({
		constructor: function (model) {
			this.tasks = kb.collectionObservable(model.get("tasks"), { view_model: AWWorkflow.TaskViewModel });
		}
	});
	/////////////// UTIL METHODS FOR WF ///////////////

	//We don't have any OTCs for dashboard items, so we'll have to do our formatting manually.
	AWWorkflow.formatTaskDate = function (date) {
		return $.datepicker.formatDate("MM d, yy", new Date(date));
	};

	return AWWorkflow;
});