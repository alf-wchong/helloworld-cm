define([
        "app",
        "modules/services/logstashservice",
        "modules/common/hpiconstants"
    ],

    function(app, LogstashService, HPIConstants) {
        "use strict";

        var module = app.module();

        /**
         * Asynchronously downloads from the given URL, performing a POST with the data and calling the errorCb if an issue occurs
         * Calls cb after the request is -made-, but not after it has completed. This means the callback is NOT async
		 * Note that, until we implement a new cookie in OpenContent, we do NOT call it on success of the requerst.
         * 
         * @param {*} url 
         * @param {*} data 
         * @param {*} cb 
         * @param {*} errorCb 
         */
        module.asyncDownload = function(url, data, cb, errorCb) {
            if (!data) {
                data = {};
                data.name = HPIConstants.Logging.Events.UnknownAction;
            }

            //store and log the action init time
            data.startTime = Date.now();
            LogstashService.sendMetrics(
                new LogstashService.PerformanceLog({
                    'eventTitle': HPIConstants.Logging.Events.ExecuteAction + "-Init",
                    'events' : {
                        'action': data.name
                    }
                })
            );

            //serialize the data ourselves.. unfortunately, the $.param library and how we do it aren't
            //directly compatible.
            var keys = _.keys(data);
            var obj = {};
            _.each(keys, function(key) {
                var serialized_value = data[key];
                try {
                    serialized_value = JSON.stringify(data[key]).replace(/\'/g, "###");
                } catch (e) {
                    //unable to parse - fallback
                    serialized_value = data[key];
                    app.log.error(window.localize("modules.common.downloadUtils.failedTo") + data[key]);
                }
                obj[key] = serialized_value;
            });
            $.fileDownload(url,{
                httpMethod: "POST",
                data: obj,
                failCallback: errorCb
            });
            if(cb) {
                cb();
            }
        };

		/**
		 * Makes a new fileDownload request, where the success/fail callbacks DO fire after the request is complete
		 *
		 **/
		module.asyncCallbackDownload = function(url, successCallback, failCallback, data) {
            var ajaxOptions = {
                httpMethod: "POST"
            };
            if (successCallback) {
                ajaxOptions.successCallback = successCallback;
            }
            if (failCallback) {
                ajaxOptions.failCallback = failCallback;
            }
            if (data) {
                ajaxOptions.data = {
                    postDataStr: JSON.stringify(data)
                };
            }

            $.fileDownload(url, ajaxOptions);
        };

        return module;

    });