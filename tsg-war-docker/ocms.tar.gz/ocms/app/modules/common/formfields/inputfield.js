define([
	// Application.
	"app"
],

// Map dependencies from above array.
//this module is deprecated - use the Wizard components instead
function(app) {
	"use strict"; 

	// Create a new module.
	var InputField = app.module();

	InputField.View = Backbone.Layout.extend({
		template: 'common/formfields/inputfield',
		tagName: 'tr',
		events:{
			'blur .answer': 'validate',
			'keyup .answer': 'throttledValidate'
		},
		initialize: function(){
			if(this.options){
				this.model = this.options;
			}else{
				this.model = {};
			}
			this.value = this.model.value;
			this.readonly = this.model.readonly;
			this.required = this.model.required;
			this.valid = this.model.valid;

			if(this.readonly){
				this.valid = true; //readonly fields are valid
				this.events = []; //remove all events in readonly mode
				this.undelegateEvents();
			}
		},
		validate: function(e){
			var obj = e.target;
			if(obj.validity.valueMissing || obj.validity.typeMismatch){
				this.$('.errorMessage').show();
			}else{
				this.$('.errorMessage').hide();
			}
		},
		isValid: function(){
			return this.valid;
		},
		throttledValidate: function(e){
			_.throttle(this.validate(e), 100);
		},
		afterRender: function(){
			var self = this;
			this.$('.answer').on('input', _.throttle(function(){
				this.model.value =  this.$('.answer').val();
				if(!this.model.value){
					this.valid = false;
					this.trigger('update', 1, this.model.value);	
				} else
				if(!this.valid && this.required){
					this.valid = true;
					this.trigger('update', -1, this.model.value);
				}else{
					this.trigger('update', 0, this.model.value); //non-required value
				}
			}, 500).bind(this));

			app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
				var jqueryFormat = app.context.dateService.getJQueryDateFormat(dateTimeFormat.dateFormat);

				self.$(".datepicker").datepicker({
					changeMonth: true,
					changeYear: true,
					dateFormat: jqueryFormat
				});
			
				self.$('.datepicker').on('change', function(){
					if(self.$('.answer').datepicker('getDate') !== null){
						//silence error message when using datepicker
						self.$('.errorMessage').hide();
						self.model.value =  self.$('.answer').datepicker({dateFormat: jqueryFormat}).val();
						if(!self.valid && self.required){
							self.valid = true;
							self.trigger('update', -1, self.model.value);
						}else{
							self.trigger('update', 0, self.model.value); //non-required value
						}
					}else if(self.valid){ //was valid, but not anymore
						self.model.value = null;
						self.valid = false;
						self.trigger('update', 1, '');
					}
				}.bind(self));
			});
		},
		serialize: function(){
			var errorLevel = 'info';
			var errorMessage = '';
			var required = '';
			var type = "text";
			var className = '';
			if(this.required){
				required = 'required';
				errorLevel = 'danger';
				errorMessage = window.localize ("modules.common.inputfield.requiredField");
			}
			if(this.model.type){
				if(this.model.type.indexOf('date') > -1){
					className = 'datepicker';
					errorMessage = window.localize ("modules.common.inputfield.dateMustBe");
				}else{
					type = this.model.type;
					errorMessage = window.localize ("modules.common.inputfield.formatMustBe") + type;
				}
			}
			return {
				label: this.model.label,
				value: this.model.value,
				readonly: this.model.readonly,
				type: type,
				required: required,
				clazz: className,
				error: errorMessage,
				errorLevel: errorLevel
			};
		}
	});

	//AMD compliance
	return InputField;
});