// Stageconfig module
define([
	// Application.
	"app"
],

// Map dependencies from above array.
//this module is deprecated - use the Wizard components instead
function(app) {
	"use strict"; 

	// Create a new module.
	var FormField = app.module();

	FormField.View = Backbone.Layout.extend({
		template: 'common/formfields/formfield',
		events: {
			'focus .field .view'		: 'edit',
			'keydown .edit'				: 'updateOnEnter',
			'click a.cancel-edits-btn'	: 'showViewAndCancelEdits',
			'click a.save-edits-btn'	: 'showViewAndSave'
		},
		initialize: function(options) {
			this.value = options && options.value ? options.value : '';
			this.wrapperType = options && options.wrapperType ? options.wrapperType : 'input';
			this.fieldStyle = options && options.fieldStyle ? options.fieldStyle : 'font-size: 1em;';
			this.controlType = options && options.controlType ? options.controlType : 'text';
			this.placeholder = options && options.placeholder ? options.placeholder : ''; //placeholder text
			this.controlAttrs = options && options.controlAttrs ? options.controlAttrs : '';
			this.readonly = options && options.readonly ? options.readonly : false;
			if(this.readonly){
				this.events = []; //remove all events in readonly mode
				this.undelegateEvents();
			}
		},
		renderWrapper: function(){ //this allows us to let extended FormField classes not break the base afterRender 
			var firstTime = !this.inputWrapperEl;

			this.labelWrapperEl = this.$('div.view');
			this.inputWrapperEl = this.$('div.edit');

			this.labelWrapperEl.val(this.value);
			if(firstTime) {
				this.inputWrapperEl.find(this.wrapperType).val(this.value);
				this.labelWrapperEl.find('label').html(this.value);
				this.inputEl = this.inputWrapperEl.find(this.wrapperType);
				this.labelEl = this.labelWrapperEl.find('label');
			}
		},
		afterRender: function() {
			this.renderWrapper();
		},
		edit: function() {
			this.showEdit();
			this.inputWrapperEl.focus();
		},
		showEdit: function() {
			this.labelWrapperEl.hide();
			this.inputWrapperEl.show();
			this.inputEl.focus();
		},
		_showView: function() {
			if( this.inputEl.val() !== this.labelEl.html() ) {
				this.$('div.view p').show();
			} else {
				this.$('div.view p').hide();
			}

			this.labelWrapperEl.show();
			this.inputWrapperEl.hide();

		},
		showViewAndSave: function() {
			var newVal = this.inputEl.val();
			this.trigger('newval', newVal);
			this.labelEl.html(newVal);

			this._showView();
		},
		showViewAndCancelEdits: function() {
			this.inputEl.val( this.labelEl.html() );

			this._showView();
		},
		showViewButRetainEdits: function(event) {
			this.$('div.view p').show();

			this._showView();
		},
		updateOnEnter: function(event) {
			if (event.keyCode == 13) {
				this.showViewAndSave();
			} else if(event.keyCode == 9) {
				this.showViewAndSave();
			}
		},
		serialize: function() {
			return {
				'fieldStyle' : this.fieldStyle,
				'placeholder': this.placeholder,
				'controlType' : this.controlType,
				'controlAttrs' : this.controlAttrs,
				'readonly': this.readonly
			};
		}
	});
	
	// Return the module for AMD compliance.
	return FormField;

});