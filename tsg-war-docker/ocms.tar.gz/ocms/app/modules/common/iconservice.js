define([
	// Application.
	"app",
	"module",
	"knockout"
	],
function(app, module, ko) {
	var IconService = app.module();
	
	ko.bindingHandlers.hpiIconChooser = {
		init: function(element, valueAccessor) {
			//add popover to icon for glyphicons
			$(element).popover({
				placement: 'right',
				trigger: 'focus',
				title: window.localize("modules.common.iconService.glyphicons"),
				html : true,
				content: window.localize("modules.common.iconService.someCommon") + "<a href='http://glyphicons.com' target='_blank'>"+ window.localize ("modules.common.iconService.onThis")+"</a>.",
				delay: {show: 500}
			});

			var originalSpan = $('span#previewArea');
			$(originalSpan).removeClass();
			$(originalSpan).addClass('glyphicons glyphicons-'+ valueAccessor().peek());
			if( window.getComputedStyle(document.querySelector('span#previewArea'), ':before').getPropertyValue('content') === "") {
				$(originalSpan).addClass('isText');
				$(originalSpan).text("No Icon Selected");
			}

			ko.utils.registerEventHandler(element, "blur", function(event) {
				var tempSpan = $('span#previewArea');
				$(tempSpan).removeClass();
				$(tempSpan).empty();
				$(tempSpan).addClass('glyphicons glyphicons-'+ valueAccessor().peek());
				if(window.getComputedStyle(document.querySelector('span#previewArea'), ':before').getPropertyValue('content') === "") {
					$(tempSpan).addClass('isText');
					$(tempSpan).text("No Icon Selected");
				}
			});

			ko.utils.registerEventHandler(element, "change", function(event) {
				var observable = valueAccessor();
				observable($(event.currentTarget).val());
			});
		},
		update: function(element, valueAccessor) {
			var icon = ko.utils.unwrapObservable(valueAccessor());
			$(element).val(icon);
		}
	};

	IconService.getIconClass = function(iconKey){
		return "glyphicons glyphicons-" + iconKey;
	};
	// Return the module for AMD compliance.
	return IconService;
});