define([
], function(){
	//a suite of utility functions for use throughout HPI
	var BooleanUtils = {};

	//since HPI admin stores everything as Strings - check if they're a Boolean
	BooleanUtils.isBoolean = function(input){
		var boolState;
		//rely on underscore otherwise
		if(_.isBoolean(input)){
			boolState = input;
		}else if(_.isString(input)){
			var lowerInput = input.toLowerCase();
			var isTrue = _.some(['true'], function(truthy){
				return truthy === lowerInput;
			});
			var isFalse = _.some(['false', undefined], function(falsey){
				return falsey === lowerInput;
			});
			boolState = (isTrue || isFalse ? (isTrue || isFalse) : undefined);
		}
		return boolState;
	};

	BooleanUtils.isTruthy = function(input){
		if(_.isBoolean(input)){
			return input;
		}
		var lowerInput = input.toLowerCase();
		return _.some([true, 'true'], function(truthy){
			return truthy === lowerInput;
		});
	};

	BooleanUtils.isFalsey = function(input){
		if(_.isBoolean(input)){
			return input;
		}
		var lowerInput = input.toLowerCase();
		return _.some([false, 'false', undefined], function(falsey){
			return falsey === lowerInput;
		});
	};

	return BooleanUtils;
});
