define([
    "app"
    ],

    function(app) {
        var LinkFormatter = {
            stage: function(trac, oco, resolver) {
                var url;
                app.context.configService.getAdminTypeConfig(oco.get("objectType"), function(configModel) {
                        
                    // if we're in collections, then we have no context, and therefore no trac, so we'll use StageSimple instead
                    if (trac) {
                        url = "Stage/" + trac + "/";
                    } else {
                        url = "StageSimple/";
                    }
                    // build our URL depending on what resolver the user has configured
                    if (resolver.match("wizard")) {
                        url += app.context.util.getWizardStageUrlIdPart(oco.get("objectId"));
                    } else if (configModel && configModel.get("isContainer") === "true") {
                        url += oco.get("objectId");
                    } else {
                        // if they're using the stage resolver and this is a document then we need to check if we have a trac defined
                        // if we don't have one defined, then we're using the StageSimple and we don't want a pipe before our document objectId
                        if(trac) {
                            url += "|";
                        }

                        url += oco.get("objectId");
                    }
                   
                });
                return url;
            },
            docViewer: function(trac, oco) {
                return ("DocViewer/" + trac + "/" + encodeURIComponent(oco.get("objectName")) + "?id=" + encodeURIComponent(oco.get("objectId")));
            },
            stream: function(oco) {  
                return ("View/" + encodeURIComponent(oco.get("objectName")) + "?id=" + encodeURIComponent(oco.get("objectId")));
            },
            externalLink: function(oco, externalLink) {
                var newLink = externalLink.replace(/\$\{objectId\}/g, oco.get("objectId"));
                return newLink;
            },
            getLinkElement: function(oco, value, resolver, externalLink, title) {
                var tracToUse, linkElement;

                if (Backbone.history.fragment.indexOf("collections") === -1) {
                    tracToUse = encodeURIComponent(app.context.configName());
                }
                if (resolver.match("stage")) {
                    if (Backbone.history.fragment.indexOf("Stage") !== -1) {
                        linkElement = "<a class='btn-link stage-link' objectId='" + oco.get("objectId") + "' title='" + title + "'>" + value + "</a>";
                    } else {
                        var stageUrl = this.stage(tracToUse, oco, resolver);
                        linkElement = "<a class='btn-link' href='" + stageUrl + "' title='" + title + "'>" + value + "</a>";
                    }
                } else if (resolver === "docviewer") {
                    var self = this;
                    app.context.configService.getAdminOTC(function(OTC){
                        var url;
                        //folders can't be viewed or downloaded in docViewer so open stream instead
                        if(OTC.get("configs").where({ocName: oco.get("objectType")}).length > 0 && OTC.get("configs").where({ocName: oco.get("objectType")})[0].get("isContainer") === "true") {
                            url = self.stream(oco);
                        }
                        else{
                           url = self.docViewer(tracToUse, oco);
                        }
                        linkElement = "<a class='btn-link' href='" + url + "' target='_blank' title='" + title +"' data-bypass>" + value + "</a>";
                    });
                } else if (resolver === "stream") {
                    var streamUrl = this.stream(oco);
                    linkElement = "<a class='btn-link' href='" + streamUrl + "' target='_blank' title='" + title +"' data-bypass>" + value + "</a>";
                } else if (resolver === "external-link") {
                    var externalLinkUrl = this.externalLink(oco, externalLink);
                    linkElement = "<a class='btn-link' href='" + externalLinkUrl + "' target='_blank' title='" + title +"' data-bypass>" + value + "</a>";
                }

                return linkElement;
            }
        };

        return LinkFormatter;
});
