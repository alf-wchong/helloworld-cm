define([
	//Application.
	"app",
	"oc",
	"modules/common/ocquery",
	"modules/actions/actionmodules"
],

function(app) {
	"use strict";

	var ExportWithAnnotations = app.module();

	ExportWithAnnotations.View = Backbone.Layout.extend({
		template: "common/exportwithannotations",
		events: {
			"change #authorCheckbox" : "setAnnotationInfo",
			"click .uncheck-all-authors" : "uncheckAllAuthors",
			"click #launchOA" : "launchInOpenAnnotate"
		},
		initialize: function() {
			var self = this;
			this.action = this.options.action;
			this.annotationInfo = {};

			// We will add each item in allAttachments to the action parameters so that all authors will be selected by default.
			_.each(this.allAttachments, function(attachment) {
				self.annotationInfo[attachment.id] = attachment.authors;	
			});

			// Set the action parameters
			this.action.get("parameters").annotationInfo = this.annotationInfo;
		},
		setAnnotationInfo: function(e) {
			var self = this;
			var authors = [];
			
			var id = self.$(e.currentTarget).data("id"); // Get the document ID of the selected author
			var index = self.$(e.currentTarget)[0].getAttribute("data-index"); 
			var attachment = _.findWhere(self.allAttachments, {id: id}); 
			var authorName = attachment.authors[index];

			// If the author has just been selected, we want to add it to our action parameter
			if($(e.currentTarget)[0].checked) {
				authors.push(authorName);

				if(self.annotationInfo[id]) {
					self.annotationInfo[id].push(authorName);
				} else {
					self.annotationInfo[id] = authors;
				}	
			// If the author has just been deselected, we want to remove it from the action parameter
			} else {
				if(self.annotationInfo[id]) {
					self.annotationInfo[id] = _.without(self.annotationInfo[id], authorName);
				} 
			}

			// Update the action parameters
			this.action.get("parameters").annotationInfo = this.annotationInfo;
		},
		uncheckAllAuthors: function(e) {
			var self = this;
			var id = self.$(e.currentTarget).data("id"); // Get the document ID of the unchecked author

			// Make sure all authors of the specified doc are unchecked.
			self.$('[data-id="'+id+'"]').removeAttr('checked');

			if(self.annotationInfo[id]) {
				delete self.annotationInfo[id];
			} 

			// Update the action parameters with no authors selected
			this.action.get("parameters").annotationInfo = self.annotationInfo;
		},
		launchInOpenAnnotate: function(e) {
			var self = this;
			var id = self.$(e.currentTarget)[0].getAttribute("data-id"); // Get the document ID of the selected author

			// Open OA in a separate window / tab
			window.open(app.openAnnotateURL + "/login/external.htm?docId=" + id + "&username=" + app.user.get("loginName") + "&readOnlyView=true");
		},
		serialize: function() {
			return {
				allAttachments: this.allAttachments
			};
		}
	});

	return ExportWithAnnotations;
});