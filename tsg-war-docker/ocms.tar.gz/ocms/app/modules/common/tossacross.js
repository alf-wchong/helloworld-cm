define(['app'], function(app){

	var TossAcross = app.module();

	var Item = Backbone.Layout.extend({
		template: 'common/tossacross/item',
		model: Backbone.Model,
		tagName: "div",
		className: 'tossacross-item',
		defaults:{
			'labelAttr': 'name',
			'valueAttr': undefined
		},
		events:{
			'add-item'	 : 'addItem',
			'remove-item': 'removeItem',
			'drop-item'	 : 'dropItem',
			'click .toss-across-click-section' : 'clickItem'
		},
		initialize: function(options){
			this.add = true;
			if(options){
				this.options = _.defaults(options, this.defaults);
				if(!this.options.valueAttr){
					this.options.valueAttr = this.options.labelAttr;
				}
				this.model = options.model;
			}
		},
		//we route the sortable events through here to get the backing backbone model
		addItem: function(event, id, index){
			if(this.options.disabled){ return; } //no-op
			this.trigger('collection-add-item', id, this, this.model, index);
		},
		removeItem: function(event, id, index){
			if(this.options.disabled){ return; } //no-op
			this.trigger('collection-remove-item', id, this, this.model);
		},
		dropItem: function(event, id, index){
			if(this.options.disabled){ return; } //no-op
			this.trigger('collection-update-item', id, this, this.model, index);
		},
		clickItem: function(event){
			if(this.options.disabled){ return; } //no-op
			var id = '#' + this.$el.parent().attr('id');
			this.trigger('collection-remove-item', id, this, this.model);
			//add to other collection thats not this one
			this.trigger('collection-move-item', id, this, this.model);

		},
		serialize: function(){
			return {
				'tossacross-label': this.model.get(this.options.labelAttr),
				'tossacross-value': this.model.get(this.options.valueAttr),
				'disabled': this.options.disabled,
				'clickAcrossIcon': this.options.clickAcross === 'add' ?
								   'glyphicon glyphicon-plus' : this.options.clickAcross === 'remove' ?
								   								'glyphicon glyphicon-remove' : undefined
			};
		}
	});

	var Collection = TossAcross._Collection = Backbone.Layout.extend({
		template: 'common/tossacross/collection',
		defaults: {
			filter: false,
			title: 'Collection',
			labelAttr: 'name',
			valueAttr: undefined,
			sortAttr: 'ordinal'
		},
		initialize: function(options){
			var self = this;
			self.filterValue = '';
			this.ui = {
				filter: '.tossacross-filter',
				collection: '#tossacross-collection-' + this.cid
			};
			this.options = _.defaults(options, this.defaults);

			if(this.options.filter){
				this.filter = new Filter(this.options);

				this.listenTo(this.filter, 'filter:update', function(query){
					self.filterValue = query;
					self.populateCollection();
				}, this);
			}

			this.filteredCollection = new Backbone.Collection();

			this.filteredCollection.bind('remove', function(){
				if(this.filteredCollection.size() === 0 && this.filter){
					//wait for ux thread to finish moving items to their lists
					//before clearing the filter out
					_.defer(function(self){
						self.filter.clear();
					}, this);
				}
			}, this);

			this.items = [];

			this.populateCollection();
		},
		populateCollection: function(){
			var self = this;
			//clear values and models
			this.filteredCollection.reset();
			this.items = [];
			//transform the collection into a trossacross collection, using the passed in fields
			this.options.collection.models = _.sortBy(this.options.collection.models, function(model){return model.get(self.options.sortAttr);});
			this.options.collection.each(function(model, index){
				var label, value, ordinal, item;

				label = model.get(this.options.labelAttr);
				value = model.get(this.options.valueAttr);
				//if no ordinal attribute specified, use the index
				ordinal = model.get(this.options.sortAttr) || index;
				//if the collection is being filtered, only render items who pass the query
				if(this.passFilter(model, this.filterValue)){
					item = new Item({
						'labelAttr': this.options.labelAttr,
						'valueAttr': this.options.valueAttr,
						'model': model,
						'clickAcross': this.options.clickAcross,
						'disabled': this.options.disabled
					});

					//listen for broadcast events
					//BROADCAST EVENTS - item may be leaving or joining collection -
					//broadcast to the controller view
					this.listenTo(item, 'collection-add-item', function(id, view, model, index){
						this.trigger('broadcast-add', id, view, model, index);
					}, this);

					this.listenTo(item, 'collection-remove-item', function(id, view, model){
						this.trigger('broadcast-remove', id, view, model);
					}, this);

					this.listenTo(item, 'collection-update-item', function(id, view, model, index){
						this.trigger('broadcast-update', id, view, model, index);
					}, this);

					this.listenTo(item, 'collection-move-item', function(id, view, model){
						this.trigger('broadcast-move', id, view, model);
					}, this);
					///BROADCAST EVENTS////

					//models
					this.filteredCollection.add(model);

					//views
					this.items.push(item);
				}
			}, this);

			//render collection
			this.removeView(this.ui.collection);
			_.each(this.items, function(itemView){
				//not on DOM - insert it
				this.insertView(this.ui.collection, itemView).render();
			}, this);
		},
		passFilter: function(model, query){
			var label = model.get(this.options.labelAttr);
			return (query === undefined || query === '') || (query !== undefined && label.toLowerCase().indexOf(query) !== -1);
		},
		getCollectionId: function(){
			return this.ui.collection;
		},
		addItem: function(model, index){
			//save off the ordinal --> index --> 0 //fallback gracefully
			var ordinal = model.get(this.options.sortAttr) ? model.get(this.options.sortAttr) : index ? index : 0;
			if(this.filterValue !== ''){
				if(this.filter){
				//wait for ux thread to finish moving items to their lists
					//before clearing the filter out
					_.defer(function(self){
						self.filter.clear();
					}, this);
				}
				ordinal = this.options.collection.length;
			}
			//ordinal is nice to have, use what's configured
			model.set(this.options.sortAttr, ordinal);

			this.options.collection.add(model);

			//set it in the correct position
			this.updateItem(model, ordinal);

			$(this.ui.collection).stop().animate({borderColor: "#3737A2"}, 250).animate({borderColor: "#FFFFFF"}, 250);
		},
		removeItem: function(model){
			var query = {};
			if(this.options.sortAttr){
				model.set(this.options.sortAttr,undefined);
			}
			//remove the model based on its label - field might have a different name
			query[this.options.labelAttr] = model.get(this.options.labelAttr);
			var removeModel = this.options.collection.findWhere(query);
			this.options.collection.remove(removeModel);
			this.filteredCollection.remove(removeModel);
		},
		updateItem: function(model, position){
			var query = {};
			query[this.options.labelAttr] = model.get(this.options.labelAttr);
			var unsortedModel = this.options.collection.findWhere(query);
			if(!unsortedModel){ //newly added
				app.log.debug(window.localize("modules.common.tossAcross.noItem"));
			}
			//remove the current model so we can re-add it with the updated ordinal
			this.options.collection.remove(unsortedModel);

			//update the ordinals on each model
			this.options.collection.each(function (item, index) {
				var ordinal = item.get(this.options.ordinal) || index;
				if (index >= position) {
					ordinal++;
				}
				item.set(this.options.sortAttr, ordinal);
			}, this);

			//add the model back with it's new ordinal
			model.set(this.options.sortAttr, position);
			this.options.collection.add(model, {at: position});
		},
		updateCollection : function(collection){
			//we just want to update the models, not break the collection events - simple assignemnt won't work here
			this.options.collection.reset(collection instanceof Backbone.Collection ? collection.models : collection);

			if(this.filter){
				//wait for ux thread to finish moving items to their lists
				//before clearing the filter out
				_.defer(function(self){
					self.filter.clear();
				}, this);
			}
			this.populateCollection();
		},
		getCollection: function(){
			return this.options.collection;
		},
		getFilteredCollection: function(){
			return this.filteredCollection;
		},
		beforeRender: function(){
			if(this.options.filter && !this.getView(this.ui.filter)){
				//only render the filter once
				this.setView(this.ui.filter, this.filter);
			}
			//initial rendering
			_.each(this.items, function(itemView){
				this.insertView(this.ui.collection, itemView);
			}, this);
		},
		serialize: function(){
			return {
				filter: this.options.filter,
				cid: this.cid,
				title: this.options.title,
				options: this.options
			};
		}
	});

	var Filter = TossAcross._Filter = Backbone.Layout.extend({
		template: 'common/tossacross/filter',
		defaults:{
			placeholder: 'Filter'
		},
		events: {
			'keyup .tossacross-filter' : 'update'
		},
		initialize: function(options){
			this.options = _.defaults(this.defaults, options);
		},
		clear: _.throttle(function(e){
			this.$('.tossacross-filter').val('');
			this.trigger('filter:update', '');
		}, 100, this),
		update: _.throttle(function(e){
			this.trigger('filter:update', this.$(e.currentTarget).val().toLowerCase());
		}, 100, this), //throttle filter update so we arn't spamming renders
		serialize: function(){
			return {
				placeholder: this.options.placeholder,
				cid: this.cid,
				disabled: this.options.disabled
			};
		}
	});

	TossAcross.Layout = Backbone.Layout.extend({
		template: 'common/tossacross/tossacross-mainlayout',
		defaults: {
			targetCollections: []
		},
		events: {
			'click #tossacross-remove-all'  : 'removeAll',
			'click #tossacross-add-all' 	: 'addAll'
		},
		initialize: function(options){
			this.ui = {
				srcCollection: '.source-collection',
				targetCollections: '.target-collections'
			};
			if(options){
				this.options = _.extend({}, options);
				options.srcCollection = _.extend(options.srcCollection, this.options);
				options.srcCollection.clickAcross = 'add';

				this.srcCollection = new Collection( options.srcCollection ); //collection options
				//bind events
				this.bindCollectionEvents(this.srcCollection);
			}
			//build map of each list by its id
			this.tossacrossLists = {};

			//source list
			this.tossacrossLists[this.srcCollection.getCollectionId()] = this.srcCollection;

			this.targetCollections = [];

			_.each(this.options.targetCollections, function(collectionOps){
				collectionOps = _.extend(collectionOps, this.options);
				collectionOps.clickAcross = 'remove';

				var collectionView = new Collection( collectionOps );
				//bind events
				this.bindCollectionEvents(collectionView);
				//build target views
				this.targetCollections.push(collectionView);
				//get id
				this.tossacrossLists[collectionView.getCollectionId()] = collectionView;
			}, this);

			//get list of linked collections
			this.collectionIds = _.keys(this.tossacrossLists);
		},
		bindCollectionEvents: function(collection){
			//listen for add, remove and delete from the individual items
			//pass it to the right collection
			this.listenTo(collection, 'broadcast-add', function(collectionId, view, model, index){
				//remove this view from its old collection
				//DOM el has moved, but the backbvone item view still has a reference to its old parent
				this.tossacrossLists[view.__manager__.selector].removeView(view);
				if(this.tossacrossLists[collectionId].options.sortAttr){
					model.set(this.tossacrossLists[collectionId].options.sortAttr,undefined);
				}
				this.tossacrossLists[collectionId].addItem(model, index);
				this.tossacrossLists[collectionId].populateCollection();
			}, this);
			//remove from one list and pass to another
			this.listenTo(collection, 'broadcast-remove', function(collectionId, view, model){
				this.tossacrossLists[collectionId].removeItem(model);
			}, this);
			//sort
			this.listenTo(collection, 'broadcast-update', function(collectionId, view, model, index){
				this.tossacrossLists[collectionId].updateItem(model, index);
				this.tossacrossLists[collectionId].populateCollection();
			}, this);

			this.listenTo(collection, 'broadcast-move', function(collectionId, view, model){
				//get other collection - there should only be one other
				var adjacentCollection;
				_.each(this.tossacrossLists, function(list, id){
					if(collectionId !== id){
						adjacentCollection = list;
						return adjacentCollection;
					}
				}, this);
				if(!adjacentCollection){
					app.log.debug(window.localize("modules.common.tossAcross.tossAcrossFailed"));
				}
				this.tossacrossLists[collectionId].removeView(view);
				view.$el.fadeOut(400);
				//this.tossacrossLists[view.__manager__.selector].removeView(view);
				adjacentCollection.addItem(model, adjacentCollection.collection.length);
				adjacentCollection.populateCollection();
			}, this);
		},
		getSourceCollection: function(){
			return this.srcCollection;
		},
		getTargetCollections: function(){
			return this.targetCollections;
		},
		//move everything in source to the first target
		addAll: function(evt){
			evt.preventDefault();
			//copy the filtered collection - it will get reset when the src collection rerenders
			var filteredCollection = _.extend(new Backbone.Collection(), this.srcCollection.getFilteredCollection().clone());
			//only remove the ones in the filtered collection - not everything else
			var withoutFiltered = this.srcCollection.getCollection().reject(function(item){
				return filteredCollection.findWhere(item.attributes);
			}, this);
			this.srcCollection.updateCollection(withoutFiltered);
			//add src to nearest target
			var target = this.targetCollections[0].getCollection();
			filteredCollection.each(function(item){
				target.add(item);
			}, this);
			this.targetCollections[0].updateCollection(target);
		},
		//this will remove everything from every target
		removeAll: function(evt){
			evt.preventDefault();
			//copy the filtered collection - it will get reset when the src collection rerenders
			var filteredCollection = _.extend(new Backbone.Collection(), this.targetCollections[0].getFilteredCollection().clone());
			//only remove the ones in the filtered collection - not everything else
			var withoutFiltered = this.targetCollections[0].getCollection().reject(function(item){
				return filteredCollection.findWhere(item.attributes);
			}, this);
			this.targetCollections[0].updateCollection(withoutFiltered);
			//add src to nearest target
			var src = this.srcCollection.getCollection();
			filteredCollection.each(function(item){
				src.add(item);
			}, this);
			this.srcCollection.updateCollection(src);
		},
		disable: function(){
			this.$(this.collectionIds.join()).sortable('disable');
		},
		beforeRender: function(){
			this.setView(this.ui.srcCollection, this.srcCollection);

			//clean up before adding more items
			this.removeView(this.ui.targetCollections);
			_.each(this.targetCollections, function(collectionView){
				this.insertView(this.ui.targetCollections, collectionView);
			}, this);
		},
		afterRender: function(){
			this.$(this.collectionIds.join()).sortable({
				connectWith: '.tossacross-collection',
				//pass an item to another list
				receive: function(event, ui) {
				    ui.item.trigger('add-item', ['#' + this.id, ui.item.index()]);
				},
				//remove an item
				remove: function(event, ui) {
					ui.item.trigger('remove-item', ['#' + this.id, ui.item.index()]);
				},
				//sorting on the same list
				stop: function(event, ui){
					ui.item.trigger('drop-item', ['#' + this.id, ui.item.index()]);
				}
			});
			//if clickAcross is enabled, disable tossacross
			if(this.options.disabled){
				//If there is 'clickacross' we want to disable drag and drop, but mainatin the correct style.
				this.$(this.collectionIds.join()).sortable("disable").disableSelection();
			}
		},
		serialize: function(){
			return {
				'enableAddRemove': this.options.enableAddRemove,
				'disabled': this.options.disabled,
				'fullscreen': this.options.fullscreen
			};
		}
	});

	//only return the main layout for public use
	return TossAcross;
});
