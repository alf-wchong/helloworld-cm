define([
    "app",
    "jqplot",
    "jqplotBarRenderer",
    "jqplotCanvasOverlay",
    "jqplotCategoryAxisRenderer",
    "jqplotCanvasTextRenderer",
    "jqplotCanvasAxisTickRenderer",
    "jqplotDateAxisRenderer",
    "jqplotPieRenderer",
    "jqplotPointLabels",
    "jqplotTrendline"
],

function(app) {


    var DefaultJQPlotSettings = {
        pieChart: {
            title: "",
            seriesDefaults:{
                renderer:$.jqplot.PieRenderer, 
                trendline:{ show:false }, 
                rendererOptions: { 
                    startAngle: 180, 
                    sliceMargin: 2, 
                    showDataLabels: true,
                    shadow: false
                }
            },
            legend:{
                show: true,
                location: "e",
                renderer: $.jqplot.EnhancedPieLegendRenderer
            },
            canvasOverlay: {
                show: true,
                objects: []
            }
        },
        barChart:  {    
            title: "",
            stackSeries: true,
            seriesDefaults: {
                renderer: $.jqplot.BarRenderer,
                rendererOptions: {
                    fillToZero: true,
                    varyBarColor: false
                },
                pointLabels: {
                    show:true,
                    edgeTolerance:-10,
                    hideZeros: true,
                    ypadding: 0
                },
                shadow: false
            },
            legend: {
                renderer: $.jqplot.EnhancedLegendRenderer,
                show: true,
                placement:'inside'  
            },
            axes: {
                xaxis: {
                    label: "",
                    ticks: [],
                    renderer: $.jqplot.CategoryAxisRenderer,
                    tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                    tickOptions:{ 
                        angle: 30,
                        labelPosition:'end'
                    }
                },
                yaxis: {
                    label: "",
                     tickOptions: { 
                        formatString: '%d' 
                    } 
                }
            },
            series: [{}],
            canvasOverlay: {
                show: true,
                objects: []
            }
        },
        lineChart: {
            title: "",
            seriesDefaults: {
                rendererOptions: {
                    smooth: true
                },
                shadow: false
            },
            axes: {
                xaxis: {
                    label: "",
                    pad: 0
                },
                yaxis: {
                  label: ""
                }
            },
            legend: {
                renderer: $.jqplot.EnhancedLegendRenderer,
                show: true,
                placement:'inside'  
            },
            series: [{}],
            canvasOverlay: {
                show: true,
                objects: []
            }
        },
        applyRenderers: function(configObject) {
            // base renderer
            if(configObject.seriesDefaults.renderer === "$.jqplot.BarRenderer") {
                configObject.seriesDefaults.renderer = $.jqplot.BarRenderer;
            }
            else if(configObject.seriesDefaults.renderer === "$.jqplot.PieRenderer") {
                configObject.seriesDefaults.renderer = $.jqplot.PieRenderer;
            }

            // legend renderer
            if(configObject.legend.renderer === "$.jqplot.EnhancedLegendRenderer") {
                configObject.legend.renderer = $.jqplot.EnhancedLegendRenderer;
            }

            // xaxis renderer
            if(configObject.axes.xaxis.renderer === "$.jqplot.CategoryAxisRenderer") {
                configObject.axes.xaxis.renderer = $.jqplot.CategoryAxisRenderer;
            }
            else if(configObject.axes.xaxis.renderer === "$.jqplot.DateAxisRenderer") {
                configObject.axes.xaxis.renderer = $.jqplot.DateAxisRenderer;
            }

            // xaxis tick renderer
            if(configObject.axes.xaxis.tickRenderer === "$.jqplot.CanvasAxisTickRenderer") {
                configObject.axes.xaxis.tickRenderer = $.jqplot.CanvasAxisTickRenderer;
            }

            return configObject;
        },
        applyGraphConfigurations: function(graphType, config, xAxisTicks, labels) {
            var baseConfig;
            if(graphType === 'pie'){
                baseConfig = this.pieChart;
            }
            else if(graphType === 'bar'){
                baseConfig = this.barChart;
            }
            else if(graphType === 'line'){
                baseConfig = this.lineChart;
            } 

            var updatedJSONConfig = baseConfig; 

            updatedJSONConfig.title = config.get("graphTitle");
            updatedJSONConfig.stackSeries = config.get("stackedSeries") === "true" ? true : false;
            updatedJSONConfig.legend.show = config.get("showLegend") === "true" ? true : false;
            updatedJSONConfig.seriesDefaults.rendererOptions.varyBarColor = config.get("varyColors") === "true" ? true : false;

            updatedJSONConfig.series = labels;

            // Add any horizontal or vertical target lines
            var horizontalTargets = config.get("referenceLineVal").split(",");
            updatedJSONConfig.canvasOverlay.objects = [];
            _.each(horizontalTargets, function(target){
                if(target !== "") {
                    updatedJSONConfig.canvasOverlay.objects.push( {dashedHorizontalLine: {name: 'line', y: target, lineWidth: 2, xOffset: 0, color: 'rgb(89, 198, 154)' }} );
                }
            });

            var formattedAxisTicks = xAxisTicks;
            if(config.get("graphType")  === "line") {
                formattedAxisTicks = [];
                _.each(xAxisTicks, function(axisTick, i){
                    formattedAxisTicks.push([i, axisTick]);
                });
            }
            // Add the x and y axis labels
            if(config.get("graphType")  !== "pie") {
                updatedJSONConfig.axes.xaxis.label = config.get("xAxisLabel");
                updatedJSONConfig.axes.yaxis.label = config.get("yAxisLabel");
                // Apply formatted ticks to x-axis, as the actual data is just integers
                updatedJSONConfig.axes.xaxis.ticks = formattedAxisTicks;
                
            }
            

            return updatedJSONConfig;

        }
    };

    return DefaultJQPlotSettings;
});
