define([], function(){
    var HPIConstants = {};

    HPIConstants.AppName = "Alfresco Content Accelerator";

    HPIConstants.TableView = {
        Context : {
            VAD : "viewalldocuments",
            Collections : "collections",
            Search : "search",
            ACTPDF : "actpdf",
            DatabaseTableView: "databasetableview"            
        }
    };

	HPIConstants.Properties = {
		ObjectName: "objectName",
		ObjectId: "objectId",
		Properties: "properties",
		Client: "client",
		RenditionSize: "renditionSize",
		NativeSize: "nativeSize"
    };
    
    HPIConstants.hpiMetadataPositions = "hpi_metadataPositions";

    HPIConstants.DataTypes = {
        Date: "date"
    };

    HPIConstants.Filter = {
        Date: "date",
        Datetime: "datetime"
    };

    HPIConstants.controlTypes = {
        AutoComplete: 'AutoComplete',
        Cascading: 'Cascading',
        CheckBox: 'CheckBox',
        Computed: 'Computed',
        DateBox: 'DateBox',
        DatetimeBox: 'DatetimeBox',
        DropDown: 'DropDown',
        MultiSelect: 'MultiSelect',
        NumericRange: 'NumericRange',
        ProximityDateSearch: 'ProximityDateSearch',
        RadioButton: 'RadioButton',
        TextArea: 'TextArea',
        TextAreaList: 'TextAreaList',
        TextBox: 'TextBox'
    };

    HPIConstants.TableView.ViewType = {
        TableView : "Table View",
        ResetTableView : "Reset Table View",
        StandardTableView : "Standardized Table View",
        ThumbnailView : "Thumbnail View",
        ListView : "List View"

    };

    HPIConstants.TableView.SearchStatistics = {
        NUMBEROFDECIMALS : 3 
    };
    
    HPIConstants.TableView.SearchView = {
        TABLE : "table",
        LIST : "list",
        THUMBNAIL : "thumbnail",
    };

    HPIConstants.TableView.Plugins = {
        CheckboxColumn : "checkbox",
        OrderInputColumn : "orderInput",
        NumCopiesColumn : "numCopiesColumn",
        RowToggleColumn : "rowToggle",
        BookmarkColumn : "bookmark",
        OAPageSelectColumn : "OAPageSelect",
        DragAndOrderRows : "dragAndOrderRows",
		SelectVersionColumn : "selectVersion",
		RowSizeColumn : "rowSize"
    };

    //Search Config Constants
    HPIConstants.SearchCriteriaConfig = {};
    HPIConstants.SearchCriteriaConfig.Within = "within";
    HPIConstants.SearchCriteriaConfig.Past = "past";
    HPIConstants.SearchCriteriaConfig.Next = "next";

    // DocViewer Constants
    HPIConstants.Logging = {};
	HPIConstants.Logging.Events = {};
	HPIConstants.Logging.Events.PerformanceLogging = "performanceLogging";
	HPIConstants.Logging.Events.ViewDocument = "viewDocument";
	HPIConstants.Logging.Events.LaunchAction = "launchAction";
	HPIConstants.Logging.Events.ExecuteAction = "executeAction";
	HPIConstants.Logging.Events.Search = "search";
	HPIConstants.Logging.Events.BulkUpload = "bulkUpload";
	HPIConstants.Logging.Events.DownloadDocument = "downloadDocument";
	HPIConstants.Logging.Events.OpenInNewTab = "openInNewTab";
	HPIConstants.Logging.Events.OpenInNewWindow = "openInNewWindow";
	HPIConstants.Logging.Events.OCMSClientError = "OCMSClientError";
	HPIConstants.Logging.Events.StreamContent = "streamContent";
	HPIConstants.Logging.Events.UnknownAction = "unknownAction";

	HPIConstants.Resolvers = {
		Stage : "Stage",
		Wizard: "Wizard",
		Stream: "Stream"
	};

	// Date Constants
    HPIConstants.Date = {};

    HPIConstants.Date.jQuery = {};
    HPIConstants.Date.jQuery.ISO = "yy-dd-mm";
    HPIConstants.Date.jQuery.Short = "mm-dd-y";
    HPIConstants.Date.jQuery.Long = "mm-dd-yy";
    HPIConstants.Date.jQuery.ShortTZ = "mm-dd-y";
    HPIConstants.Date.jQuery.LongTZ = "mm-dd-yy";
    HPIConstants.Date.jQuery.Euro = "dd-M-yy";
    HPIConstants.Date.jQuery.YearFirst = "yy-mm-dd";
    HPIConstants.Date.jQuery.USA = "DD, MM dd, yy";

    HPIConstants.Date.moment = {};
    HPIConstants.Date.moment.ISO = "YYYY-DD-MM";
    HPIConstants.Date.moment.Short = "MM-DD-YY";
    HPIConstants.Date.moment.Long = "MM-DD-YYYY";
    HPIConstants.Date.moment.ShortTZ = "MM-DD-YY z";
    HPIConstants.Date.moment.LongTZ = "MM-DD-YYYY z";
    HPIConstants.Date.moment.Euro = "DD-MMM-YYYY";
    HPIConstants.Date.moment.YearFirst = "YYYY-MM-DD";
    HPIConstants.Date.moment.USA = "dddd, MMMM DD, YYYY";

    HPIConstants.Date.simpleDate = {};
    HPIConstants.Date.simpleDate.ISO = "yyyy-dd-MM";
    HPIConstants.Date.simpleDate.Short = "MM-dd-yy";
    HPIConstants.Date.simpleDate.Long = "MM-dd-yyyy";
    HPIConstants.Date.simpleDate.ShortTZ = "MM-dd-yy";
    HPIConstants.Date.simpleDate.LongTZ = "MM-dd-yyyy";
    HPIConstants.Date.simpleDate.Euro = "dd-MMM-yyyy";
    HPIConstants.Date.simpleDate.YearFirst = "yyyy-MM-dd";
    HPIConstants.Date.simpleDate.USA = "EEEEE, MMMMM dd, yyyy";

    // ContentViewer Constants
    HPIConstants.ContentViewer = {
        PDFViewer : "viewerjs",
        VideoViewer : "videojs",
        ImageViewer : "imageviewer",
        HTMLViewer : "htmlviewer",
        LegacyViewer : "legacyviewer",
        OAViewer : "oaviewer",
        VAViewer : "vaviewer",
        ImageMimetype : "image/png",
        XMLViewer: "xmlviewer"
    };

    // OpenAnnotate Modes
    HPIConstants.OpenAnnotate = {
        Modes : {
            OpenViewer : 'openviewer'
        }  
    };

    // HPI Actions
    HPIConstants.Actions = {
        ViewVersions : "viewVersions",
        BulkUpload : "bulkUpload"
    };

    // HPI Handlers
    HPIConstants.Handlers = {
        RightSideActionHandler : "rightSideActionHandler",
        ModalActionHandler : "modalActionHandler"  
    };

    //Constants dealing with different ObjectTypes
    HPIConstants.ObjectTypes = {
        Collection: "Collection",
        AttachedDocument: "Attached Document"
    };

    HPIConstants.MimeTypes = {
        ApplicationPdf: "application/pdf"
    };

    HPIConstants.oaIframeExtenWhiteList = ['pdf','jpeg', 'jpg', 'png', 'gif', 'doc', 'docx','docm', 'msg', 'potm', 'potx', 'ppsm', 'ppsx', 'ppt', 'pptx', 'pub', 'xls', 'xlsx', 'xlsb', 'xlsm', 'xltm', 'xltx', 'xltx', 'xps', 'html', 'txt', 'xml', 'json', 'eml'];

    HPIConstants.ThumbnailView = {
        MimetypeWhitelist : [
            "application/pdf",
            "image/bmp",
            "application/msword", //doc
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", //docx
            "image/gif",
            "text/html",
            "image/jpeg", //jpg
            "application/vnd.contact.cmsg", //msg
            "application/vnd.ms-outlook", //msg
            "application/pdf",
            "image/png",
            "application/vnd.ms-powerpoint", //ppt
            "application/vnd.openxmlformats-officedocument.presentationml.presentation", //pptx
            "image/tiff",
            "text/plain", //txt
            "application/vnd.ms-excel", //xls
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", //xlsx
            "application/xml"
        ]
    };

    HPIConstants.ListView = {
        MimetypeWhitelist : [
            "application/pdf",
            "image/bmp",
            "application/msword", //doc
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document", //docx
            "image/gif",
            "text/html",
            "image/jpeg", //jpg
            "application/vnd.contact.cmsg", //msg
            "application/vnd.ms-outlook", //msg
            "application/pdf",
            "image/png",
            "application/vnd.ms-powerpoint", //ppt
            "application/vnd.openxmlformats-officedocument.presentationml.presentation", //pptx
            "image/tiff",
            "text/plain", //txt
            "application/vnd.ms-excel", //xls
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", //xlsx
            "application/xml"
        ]
    };

    //HTTP Status Codes
    HPIConstants.HTTP = {
        Status : {
            UnsupportedMediaType : 415,
            Locked : 423,
			PreconditionFailed : 412,
			PaymentRequired : 402,
            Unauthorized: 401
        }
    };

    HPIConstants.CHARCODES = {
        Enter : 13, 
        Semicolon : 59, 
        Comma : 44, 
        Space : 32
    };

    HPIConstants.ByteArrayOutputStream = "ByteArrayOutputStream";

    HPIConstants.OpenContentObject = {
        ObjectId: "objectId",
        Properties: {}
    };

    HPIConstants.Modal = "modal";
    HPIConstants.Popover = "popover";
    
    HPIConstants.ModalSizes = {
        Small: "small",
        Large: "lg",
        ExtraLarge: "xl",
    };
    
    HPIConstants.WindowSize = {
        Small: 768
    };

	HPIConstants.MimeTypeMapping = {
		'video/mp4': 'mp4',
		'video/x-msvideo': 'avi',
		'video/quicktime': 'mov'
	};

    HPIConstants.WizardSupportingDocsTabs = {
        AddAdHocDocumentsTab: "addAdHocDocumentsTab",
        ExistingAdHocDocumentsTab: "existingAdHocDocumentsTab"
    };

    HPIConstants.WizardGroups = {
        WizardContributorGroup: "wizard_contributors"
    };

    HPIConstants.Errors = {
        OCUser : {
            ExistenceError: "DOES_NOT_EXIST",
            DisabledError: "DISABLED",
            FetchingDataError: "ERROR_FETCHING_DATA"
        }
    };
    return HPIConstants;
});
