define([
  // Application.
  "app",
  "underscore",
  "oc",
  "modules/actions/actionmodules",
  "modules/formsupport",
  "modules/common/spinner",
  "modules/common/action",
  "modules/common/hpiconstants"
],

// Map dependencies from above array.
function(app, _, OC, actionModules, FormSupport, HPISpinner, Action, HPIConstants) {    

    var PropertiesView = app.module();
    // this is basically a container for form support
    PropertiesView.PropertyList = Backbone.Layout.extend({
        template: "common/propertylist",
        initialize: function() {

            // we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
            // on the bulk properties page)
            var defaults = {
                properties: {},
                enableRequired: true
            };

            this.options = _.extend(defaults, this.options);

            // this properties view model is what form support uses to put its controls on and other functions
            this.propertiesViewModel = this.options.propertiesViewModel = {};

            // init form support - we only want atCreation attributes to show up since we're uploading stuff
            FormSupport.tsgFormSupport(this.propertiesViewModel, { 
                'isCreate': true,
                'enableRequired': this.options.enableRequired,
                'enableReadonly': this.options.enableReadonly,
                'formName': this.options.formName,
                'disableDefaults': this.options.disableDefaults
            });

            // set the form control properties once the controls have finished building
            this.propViewModelSubscription = this.propertiesViewModel.controls.subscribe(function() {
                this._setControlValues();

                //Wait until the controls are initialized to set up this listener
                if(this.options.controlValueChangeHandler) {
                    this.forwardControlValueChange(this.options.controlValueChangeHandler);
                }
            },this);

            // emit an event whenever the form's validity changes
            this.propertiesViewModel.isValid.subscribe(function(isValid) {
                var externalMessage = this.options.propertiesViewModel.externalFormMessage;
                app.trigger(this.options.listener + ':formIsValid', {'isValid': isValid, 'externalFormValidationMessage' : externalMessage, showExternal: this.options.propertiesViewModel.showExternalValidityMessage()});
            },this);

            // set the object type which will trigger the controls to be generated
            this.propertiesViewModel.objectType(this.options.objectType);

        },
        // function for unit testing purposes only - sets the form control properties
        _setControlValues: function() {
            //since we only need to set these once, dispose afterward
            this.propViewModelSubscription.dispose();
            // set our initial values once the controls have built
            _.each(this.propertiesViewModel.controls(), function (control) {
                if (control.value()) {
                   this.options.properties[control.id] = control.value(); 
                }
            }, this);

            if(this.options.contextlessActionOptions){
                this.configureContextlessActionProperties();
            }
            
            this.propertiesViewModel.setValues(this.options.properties);
        },
        forwardControlValueChange: function(callback) {
            this.listenTo(this.propertiesViewModel.eventManager, "fs:change", callback);
        },
        configureContextlessActionProperties: function(){
            if(this.options.contextlessActionOptions.oc_property){
                _.each(this.options.contextlessActionOptions.oc_property, function(prop){
                    var propInArray = prop.split("~:~");
                    var key = propInArray.splice(0,1)[0];
                    var val = propInArray; //all of the values here if there are multiple values

                    //THIS CALL IS ONLY SYNCHRONOUS FOR BULK UPLOAD BECAUSE OTC IS ALREADY CACHED//
                    app.context.configService.getAdminTypeConfig(this.objectType, function (typeConfig) {
                        var dateModel = _.find(typeConfig.get("attrs").models, function (attr) {
                            return attr.get("ocName") === key && attr.get("dataType") === HPIConstants.DataTypes.Date;
                        });
                        if(dateModel){
                            _.each(val, function(value, index){
                                    val[index] = parseInt(value);
                            });
                        }
                    });
                    
                    if(val.length <= 1){
                        val = propInArray[0]; //if only one value, take out of an array
                    }
                    this.options.properties[key] = val;
                }, this);
              
            }
        },
        afterRender: function() {
            // form support uses knockout so let's apply those bindings
            kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
        },
        getValues: function() {
            return this.options.propertiesViewModel.getValues();
        },
        isValid: function() {
            return this.options.propertiesViewModel.isValid();
        },
        serialize: function() {
            return {
                objectType: this.options.objectType,
                // whether or not we're on the bulk properties page - used to display user instructions about what happens
                // with these bulk properties
                bulkProperties: this.options.bulkProperties,
                // only used if we're not in bulk properties page - to display the original document name of the document
                // currently being edited
                title: this.options.title
            };
        }
    });
    return PropertiesView;
});