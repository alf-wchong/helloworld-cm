// Security module
define([
    "app",
    "module",
    "knockout",
    "knockback",
    "oc",
    "backbone",
    "modules/hpiadmin/tracconfig/tracconfig",
    "modules/hpiadmin/preferences/userpreferences",
    "modules/services/exitservice",
    "modules/stage/searchresulttraversal",
    "modules/common/forgotPassword",
    "modules/hpiadmin/userconfig/userconfig",
    // gets loaded onto jquery so not referenced in factory sig below
    "jquery",
    "modules/common/hpiconstants",
    "URIjs/URI",
    "plugins/jquery.cookie",
    "bootstrap"
], function(app, module, ko, kb, OC, Backbone, TracConfig, UserPreferences, ExitService,
    SearchResultTraversal, ForgotPassword, UserConfig, $, HPIConstants) {
    var Security = app.module();

    Security.ocUserCheck = function() {
        //Check that the ocUser cookie exists and does not contain an error flag
        if ($.cookie("ocUser") && !_.contains(_.values(HPIConstants.Errors.OCUser), $.cookie("ocUser")) ) {
            app.log.debug("Welcome " + $.cookie("ocUser"));
            app.user = new OC.User({ loginName: $.cookie("ocUser") });
            app.user.fetch({
                global: false,
                success: function(user) {
                    user.fetched = true;
                },
                error: function() {
                    if(app.enableSSO) {
                        $.cookie("ocUser", "ERROR_FETCHING_DATA",{
                            path: "/",
                            secure: app.secureBrowserCookies
                        } );
                    } else {
                        app.savedUrl = Backbone.history.fragment;
                        $.removeCookie('ocUser', {
                            'path': '/'
                        });
                        Backbone.history.navigate("/", {trigger : true});
                    }
               }
            });
        }
    };
    Security.ocUserCheck();

    Security.ViewModel = function(model) {
        this.username = kb.observable(model, "username");
        this.password = kb.observable(model, "password");
        this.loading = ko.observable(false);
        this.licenseSuccess = ko.observable("");
        this.failure = ko.observable("");
    };

    Security.Views.Layout = Backbone.Layout.extend({
        template: "login",
        events: {
            "submit #login-form" : "submit",
            "click #forgot-password" : "onClickForgotPassword",
            "click #login-new-user" : "onClickRegisterUser",
            "keyup #login-password" : "removeErrorMessage"
        },
        removeErrorMessage: function() {
            var self = this;
            if ($("#login-password").val() !== "") {
               self.viewModel.failure(null);
            }
        },
        initialize: function() {
            if (this.errorMode === "licenseError") {
                Backbone.history.navigate("/licenseError",
                    { trigger: true }, { replace: true });
            } else if (this.errorMode === "licenseErrorTooManyUsers") {
                Backbone.history.navigate("/licenseErrorTooManyUsers",
                    { trigger: true }, { replace: true });
            } else if (this.errorMode === "licenseErrorExpired") {
                Backbone.history.navigate("/licenseErrorExpired",
                    { trigger: true }, { replace: true });
            } else if (this.errorMode === "generalError") {
                Backbone.history.navigate("/connectError", 
                    { trigger: true }, { replace: true });
            } else {
                this.model = new Backbone.Model({ username : "", password: ""} );
                this.viewModel = new Security.ViewModel(this.model);
                
                if (this.licenseValidated) {
                    this.viewModel.licenseSuccess("Successfully Validated License!");
                }
                
                this.checkTicket();
            }

            this.forgotPassword = module.config() ? module.config().forgotPassword : false;
            this.registerUser = module.config() ? module.config().registerUser : false;

            if(app.enableSSO) {
                this.template = undefined;
            }
        },
        onClickForgotPassword: function() {
            var forgotPasswordModal = new  ForgotPassword.Views.Layout();
                app.trigger('alert:custom', {
                view: forgotPasswordModal
            }); 
        },
        onClickRegisterUser: function() {
            var self = this;
            var options = "register";
            var registerUser = new  UserConfig.CreateUserView({ 'register':options });
             self.listenTo(app, "registeredUser", function(username, password, event) {
                self.model.attributes.username = username;
                self.model.attributes.password = password; 
                self.viewModel = new Security.ViewModel(self.model);
                self.submit(event);
            });  
            app.trigger('alert:custom', {
                view: registerUser
            });
        },
        afterRender: function() {
            // If we are using SSO let's navigate to our
            // default page
            if (app.enableSSO) {
                this.loadUserPreferences.call(this);
            } else {
                if(this.viewModel) {
                    // Otherwise, send them to the login form
                    kb.applyBindings(this.viewModel, this.getLoginForm());
                }
            }
        },
        getLoginForm: function() {
            return $("#login-form")[0];
        },
        checkTicket: function() {
            // is ticket valid?
            $.ajax({
                url : app.serviceUrlRoot + "/authentication/validateSession",
                type: 'POST',
                success: function() {
                    if (_.isUndefined(app.context.currentApplicationConfig())) {
                        app.context.configService.getApplicationConfig(function() {
                            Backbone.history.navigate(app.context.currentApplicationConfig().get("defaultPath")
                                || "/dashboard", { trigger: true }); 
                        });
                    } else {
                        Backbone.history.navigate(app.context.currentApplicationConfig().get("defaultPath")
                            || "/dashboard", { trigger: true }); 
                    }   
                }
            });
        },
        submit: function(evt) {
            evt.preventDefault();
            this.viewModel.loading(true);
            
            // Do NOT copy this code. We should be using save/sync when possible. Currently
            // there is no login endpoint that accepts json in OC. 
            // TODO: fix with aforementioned endpoint
            Backbone.ajax({
                url: app.serviceUrlRoot + "/authentication/newSession?username=" + this.model.get("username"),
                data: this.model.get("password"),
                contentType: "text/plain",
                type: "POST",
                success: this.onSubmitSuccess,
                error: this.onSubmitError,
                context: this,
                async: false
            });
        },
        onSubmitSuccess: function() {
            app.user = new OC.User({loginName: this.model.get("username")});
            this.loadUserPreferences.call(this);
        },
        onSubmitError: function() {
            this.viewModel.licenseSuccess(null);
            this.viewModel.failure(window.localize("templates.login.failure"));
            this.viewModel.password(null);
            this.viewModel.loading(false);
        },
        loadUserPreferences: function() {
            var view = this;
            // loading in User Preferences
            // async call, needs a callback, reason why things are bombing
            // also, we cleared our localStorage, so re-fetch it here so it gets back into localStorage
            app.context.configService.getUserPreferences(function() {
                ExitService.register('userpreferences.save', function() {
                    if (app.context.currentUserPreferences()) {
                        // delete the unneccasru recentObject userp preferences and save the user preferences
                        app.context.configService.getDashboardConfig(function(dashconfig) {
                                //C heck what recent object dashlets are configured and remove the user preferences that are not needed
                                var recentObjectsDashlets = dashconfig.get("dashlets").where({
                                    dashletType: "RecentObjectsDashlet"
                                });
                                var dashletUserPrefs = _.keys(app.context.currentUserPreferences().get("recentObjectsDashlets"));
                                var dashletIds = _.invoke(recentObjectsDashlets, "get", "dashletId");
                                var removeIds = _.difference(dashletUserPrefs, dashletIds);
                                
                                _.each(removeIds, function(id) {
                                    if (id !== "_id") {
                                        delete app.context.currentUserPreferences().get("recentObjectsDashlets")[id];
                                    }
                                });
                            app.context.currentUserPreferences().saveNow({ version: false }, { global: false });
                        });
                    }
                });
                app.user.fetch({
                    success: function(user) {
                        user.fetched = true;
                        if (view.model.get("username") === undefined) {
                            app.log.error("Username is undefined.. this is an error.");
                            // refresh the page
                            Security.setWindowLocation(app.root);
                        }
                        $.cookie("ocUser", view.model.get("username"),{
                            path: "/",
                            secure: app.secureBrowserCookies
                        } );
                        view.viewModel.loading(false);
                        // get the default config name from the application config and set it on the context
                        var deferred = $.Deferred();
                        app.context.configService.initServicesThatRequireConfigs(deferred);
                        
                        $.when(deferred).done(function() {
                            //logic for actually setting the default config on app
                            var setDefaultConfig = function() {
                                var lastSearchTrac = app.context.cookieService.getUserPreferences('searchTrac');
                                if (lastSearchTrac.searchTrac && app.context.tracConfigs.findWhere({name: lastSearchTrac.searchTrac})) {
                                    app.context.configName(lastSearchTrac.searchTrac);
                                } else {
                                    app.context.tracConfigs.sort();
                                    app.context.configName(app.context.tracConfigs.at(0).get("name"));
                                }
                                if (app.savedUrl && app.savedUrl !== null) {
                                    Backbone.history.navigate(app.savedUrl, {trigger: true});
                                } else {
                                    Backbone.history.navigate(app.context.currentApplicationConfig().get("defaultPath")
                                        || "/dashboard", { trigger: true });
                                }
                            };
                            //if we don't have the trac configs yet, navigate to the 
                            //tracAuthorizationError page. 
                            if (app.context.tracConfigs.length === 0) {
                                Backbone.history.navigate("/tracAuthorizationError", { trigger: true }, { replace: true });                                   
                            } else {
                                setDefaultConfig();
                            }
                        });
                    }
                });
            });
        },
        serialize: function() {
             return {
                "forgotPassword": this.forgotPassword,
                "registerUser": this.registerUser,
                "ocmsVersion": $('meta[name=ocmsVersion]').attr('content')
            };
        }
    });
    Security.Views.Logout = Backbone.Layout.extend({
        template: "logout",
        initialize: function() {
            app.log.debug("security module init");
            this.logoff();
        },
        render: function() {
        },
        afterRender: function() {
        },
        deleteTicket: function() {
            Backbone.ajax({
                url: app.serviceUrlRoot + "/authentication/endSession",
                type: "GET",
                success: function() {
                }
            });
        },
        logoff: function() {
            var self = this;
            // save the user preferences THEN preform logoff logic
            app.context.configService.getUserPreferences(function(currentUserPreferences) {
                currentUserPreferences.saveNow({version: false}, {
                    global: false,
                    async: false
                }).done(function() {
                    // removes ticket
                    self.deleteTicket();
                    app.log.debug("logoff");
                    $.removeCookie("lang", { path : '/' });
                    $.removeCookie("ocUser", { path: '/' });
                    $.removeCookie("localPreferences", { path: '/' });
                    $.removeCookie('securedAdminAccess', { path: '/'});
                    app.user = "";
                    // Removing the data for search traversal of results on stage
                    window.localStorage.removeItem('latestResults');
                    SearchResultTraversal.latestResults = [];
                    if (!module.config().logoutScreen) {
                        Security.setWindowLocation(app.root);
                    } else {
                        Backbone.history.navigate('', {trigger : false});
                    }
                });
            });
        }
    });
    Security.setWindowLocation = function(location) {
        window.location = location;
    };
    // Return the module for AMD compliance.
    return Security;
});