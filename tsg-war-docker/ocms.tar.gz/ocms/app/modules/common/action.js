define([
	"app",
	"modules/hpiadmin/actionconfig/hpiactionconfig",
	"modules/services/logstashservice",
	"modules/common/hpiconstants"
],
function(app, ActionConfig, LogstashService, HPIConstants) {

	// Create a new module.
	var Action = app.module();

	// an action from the repo
	Action.Model = Backbone.Model.extend({
		initialize: function(attrs, options) {

			// define a function called execute, which is really just save
			this.execute = function(options) {
				//store and log the action init time
				this.set("startTime", Date.now());
				LogstashService.sendMetrics(
					new LogstashService.PerformanceLog({
						'eventTitle': HPIConstants.Logging.Events.ExecuteAction + "-Init",
						'events' : {
							'action': this.get("name")
						}
					})
				);

				//don't send conditions or ocActionId back to the server
				this.unset("conditions");
				this.unset("ocActionId");
				
				//Wait for action to finish executing before firing "action:execute" trigger  
				$.when(this.sync("create", this, options)).done(function(){
					app.trigger("action:execute");
				});
			}; 

			this.isValid = function() {
				// look at the conditions see if they're all valid
				var conditionsValid = true;
				// create map based on group
				var groupedConditions = [];

				var hasGroupConditions = false;

				_.each(this.get("conditions"), function(condition) {
					if(!condition.group){
						if("valid" !== condition.status && condition.required) {
							// if a required condition failed, bail out, no need to check other conditions
							conditionsValid = false;
						}
					} else {
						// build a list of all grouped conditions, keyed by group
						if(!groupedConditions[condition.group]) {
							hasGroupConditions = true;
							groupedConditions[condition.group] = [];
						}
						groupedConditions[condition.group].push(condition);
					}
				});

				// bail out, a required condition failed
				if(!conditionsValid) {
					return false;
				}

				// if there are grouped actions
				if(hasGroupConditions) {
					var groupedConditionsResults = [];
					// check any grouped conditions
					_.each(groupedConditions, function(group) {
						var passes = true;
						_.each(group, function(condition) { //check each condition within a group
							if("valid" !== condition.status) { //if a condition failed, the whole group fails
								passes = false;
							}
						});
					
						groupedConditionsResults.push(passes);
					});
					
					var groupedConditionsValid = false;
					_.each(groupedConditionsResults, function(groupedCondition) { //loop throuugh the groups and OR them, if one group passes, return true
						if(groupedCondition) {
							groupedConditionsValid = true;
						}
					});
					return conditionsValid && groupedConditionsValid;
				} else {
					return conditionsValid;
				}
			};
		},
		url: function() {
			// return the url to execute the action if there is a container id include it in url else don't. For backend to have access to container id.
			if (app.context.container.id){
				return app.serviceUrlRoot + "/action/execute?" + $.param({"parentObjectId": app.context.container.id});
			}else{
				return app.serviceUrlRoot + "/action/execute?"
			}
		},
		defaults: function() {
			return {
				conditions : []
			};
		}
	});

	// fetching a collection of actions will essentially evaluate them against the collections current objectId
	Action.Collection = Backbone.Collection.extend({
		initialize: function(models, options) {
			if(options && options.objectId) {
				this.objectId = options.objectId;
				this.objectName = options.objectName;
			} else if(options && options.objectIds){
				this.objectIds = options.objectIds;
				this.objectNames = options.objectNames;
			}
			if(options && options.collectionId) {
				this.collectionId = options.collectionId;
			}
		},
		model: Action.Model,
		url: function() {
			// append all the actionIds of the models in this collection
			// we add in the pseudo action whycanti based on configuration sometimes, make
			// sure we remove it here since OC has no idea what it is
			var actionIds = _.without(this.pluck("ocActionId"), "whyCantI");
			// append as actionList[]=action1&actionList[]=2
			var url = app.serviceUrlRoot + "/action/evaluate?" + $.param({"actionList[]" : actionIds});
			if(this.objectId) {
				// =+ is not an operator fyi
				url += "&id=" + this.objectId;
			} else if(this.objectIds) {
				// TODO - mstein
				// If this list is large the server dies
				// for now we'll just evaluate the first 4
				// we could change this to a post in the future
				if(this.objectIds.length > 25) {
					// need to use a temp array or we are cutting the first
					// four results off of the list of objectIds, which are
					// used when exporting search results
					var tempArray = this.objectIds.slice(0);
					url += "&" + $.param({"idList[]" : tempArray.splice(0,4)});
				} else {
					url += "&" + $.param({"idList[]" : this.objectIds});
				}
			}

			//some actions need a collection Id for proper condition evaluation in OC
			if(this.collectionId) {
				url += "&" + $.param({"collectionId" : this.collectionId});
			}

			// put the container id on the url if it exists so backend can use this variables
			if (app.context.container.id){
				url += "&" + $.param({"parentObjectId" : app.context.container.id});
			}
			

			return url;
		},
		parse: function(data, options) {
			// now, we need to match up the oc action ids we got back from OC
			// and match them correctly with the hpi action ids
			//
			// ex. folderNotes from OC would map to both folderNotes and abbspiraFolderNotes in HPI
			var parsedData = [];
			this.each(function(model) {
				for(var i = 0; i < data.length; i++){
					var ocItem = data[i];
					if(ocItem.actionId === model.get("ocActionId")) {
						var newItem = _.extend({}, ocItem, {actionId : model.get("actionId"), ocActionId : model.get("ocActionId")});
						parsedData.push(newItem);
						break;
					}
				}
			});

			return parsedData;
		}
		
	});

	/*
	* Given an action collection removes bad actions
	*
	*/
	Action.filterActions =  function(actionCollection, config){
		var badActions = [];
		var goodActions = [];
		actionCollection.resolved = true;
		var whyCantIActions = [];
		
		actionCollection.each(function(action) {
			// set the objectId and type on the action
			if(actionCollection.objectId !== undefined) {
				action.get("parameters").objectId = actionCollection.objectId;
				action.get("parameters").objectName = actionCollection.objectName;
			} else {
				action.get("parameters").objectIds = actionCollection.objectIds;
				action.get("parameters").objectNames = actionCollection.objectNames;
			}

			if(action.isValid()) {
				goodActions.push(action);
			} else {
				badActions.push(action);

				if (config) {
					//see if any of these actions are configured to show in the "why cant i" action
					var aConfig = config.get("actions").findWhere({actionId : action.get("actionId")} );
					if (aConfig && aConfig.get("whyCantI")) {
						var invalidConditions = _.filter(action.get("conditions"), function(condition) {
							return condition.status === "invalid" && condition.required;
						});
						action.set("conditions", invalidConditions);
						whyCantIActions.push(action);
			}
				}
			}
		});

		actionCollection.remove(badActions);

		//build up our pseudo "why cant i" action complete with config
		if (whyCantIActions.length > 0){

			var whyCantIIcon = !config.get("whyCantIIcon") ? window.localize("modules.common.action.whyCantI") : config.get("whyCantIIcon");
			var whyCantILabel = !config.get("whyCantILabel") ? window.localize("modules.common.action.whyCantI") : config.get("whyCantILabel");

			config.get("actions").models.push(new ActionConfig.Model({
				actionId: "whyCantI",
				handler: "modalActionHandler",
				icon: whyCantIIcon,
				isHeaderMode: false,
				label: whyCantILabel,
				modalBackdrop: "true",
				modalSize: "large",
				ocActionId: "whyCantI"
			}));

			actionCollection.push(new Action.Model({
				name: "whyCantI",
				actionId: "whyCantI",
				whyCantIActions: whyCantIActions
			}));
		}
	};


	Action.Views.Dropdown = Backbone.Layout.extend({
		template: "actions/action-dropdown",
		className: "btn-group gridViewActions",
		events:{
			"click .dropdown-toggle" : "dropDownClicked"
		},
		initialize: function(options) {
			var self = this;

			this.model = this.options.model; 
			var objectId = this.model.get("objectId");
	 		this.config = this.options.config;

	 		this.open = false;

	 		var _actions = [];
	 		this.actionConfigMap = {};
	 		//Create build a collection of actions that will be passed for requests and save all actions from the config
	 		//  to a map, because they contain data need that is not necessary for the request (and thus would be stripped
	 		//  our action collection ).
	 		this.config.get("actions").each(function(actionConfig){
				_actions.push( new Action.Model({actionId : actionConfig.actionId, ocActionId : actionConfig.get("ocActionId") || actionConfig.actionId}));
				self.actionConfigMap[actionConfig.actionId] = actionConfig;
			});

	 		this.actionCollection = new Action.Collection(_actions, {objectId : objectId});

	 		this.listenTo(this.actionCollection, "sync", function(collection) {
				//Filter actions then render with the remaining actions
	 			Action.filterActions(collection);
				self.renderActions(collection);
	 		});
		},
		renderActions: function(actionCollection){
			var self = this;
			_.each(this.actionCollection.models, $.proxy(self.renderAction, self));
			self.render();
		},
		renderAction: function(actionModel){
			var self = this;
			var actionItemView = new Action.Views.Dropdown.Item({
				model: actionModel,
				config: self.actionConfigMap[actionModel.get("actionId")]
			});

			this.insertView(".action-dropdown-outlet", actionItemView);
		},
		dropDownClicked: function(){
			var self = this;
			if(this.open === false){
				_.each(app.context.actionParamService.getExtraParameters(), function(key, value) {
					self.actionCollection[key] = value;
				});
				self.actionCollection.fetch(
					{
						global: false,
						error: function(){
							app.log.error(window.localize("modules.common.action.failedTo"));
							self.actionCollection.reset();
						}
				});
			}
			this.open = this.open ? false : true;
		}
	});

	Action.Views.Dropdown.Item = Backbone.Layout.extend({
		template: "actions/action-dropdown-item",
		events:{
			"click .action-dropdown-item" : "itemClicked"
		},
		tagName: "li",
		initialize: function(options) {
			//Actual action object that's been filtered/synced
			this.actionModel = this.options.model;
			//The action entry from the config still has label and handler
	 		this.config = this.options.config;

	 		this.open = false;

		},
		itemClicked: function(){
			//Perform the appropriate action for this item by getting its handler
			app[this.config.get("handler")].trigger("show", {action: this.actionModel, config: this.config }); 
			//Swaps true & false
			
		},
		serialize: function(){
			return {action : this.config.get("label")};
		}
	});

	Action.getSearchConfig = function(options){
		if(options !== undefined && options.searchResults !== undefined && options !== null && options.searchResults !== null) {
			return options.searchResults;
		}
		return app.context.currentSearchConfig();
	};

	Action.getActionConfigs = function(options){

		var actionConfigMap = {};
		var searchResultsConfig = Action.getSearchConfig(options).get('resultsConfig');

		var singleActions = searchResultsConfig.get('resultsTableConfig').get('actions');
		var groupedActions = searchResultsConfig.get('groupActionsConfig').get('actions');

		//build single action configs mapping
		singleActions.each(function(actionConfig){
            actionConfigMap[actionConfig.actionId] = actionConfig;
        }, this);

		//build grouped action configs mapping
		groupedActions.each(function(actionConfig){
            actionConfigMap[actionConfig.actionId] = actionConfig;
        }, this);

        return actionConfigMap;
	};

	Action.resolveActions = function(options, collectionId){
		var optionsConfigured = [];

		//create actioncollection
		var actionCollection = new Action.Collection();

		var _actions = [];

		var searchResultsConfig = Action.getSearchConfig(options).get('resultsConfig');

		var singleActions = searchResultsConfig.get('resultsTableConfig').get('actions');
		var groupedActions = searchResultsConfig.get('groupActionsConfig').get('actions');

		if(!options.objectIds || options.objectIds.length === 1){
			singleActions.each(function(configuredAction){
				// check to see if we are in search controls or a right click
				// if in search controls blacklist the copy text action
				// otptions.args will only be defined if we are coming from TableView
				if(configuredAction.actionId !== "copyText" || (configuredAction.actionId === "copyText" && options.args)){
					if(collectionId) {
						_actions.push(new Action.Model({actionId: configuredAction.actionId, parameters: {}, label: configuredAction.get("label"), icon: configuredAction.get("icon"), handler: configuredAction.get("handler"), ocActionId: configuredAction.get("ocActionId") || configuredAction.actionId, collectionId: collectionId }) );

					} else {
						_actions.push(new Action.Model({actionId: configuredAction.actionId, parameters: {}, label: configuredAction.get("label"), icon: configuredAction.get("icon"), handler: configuredAction.get("handler"), ocActionId: configuredAction.get("ocActionId") || configuredAction.actionId }) );
					}
				}
			});
			actionCollection.objectId = options.objectId;
			actionCollection.objectName = options.objectName;
		}else{
			groupedActions.each(function(configuredAction){
				_actions.push( new Action.Model({actionId : configuredAction.actionId, ocActionId : configuredAction.get("ocActionId") || configuredAction.actionId }));
			});
		}
		actionCollection.reset();
		//Set each of the configured actions onto the actionCollection
		if(!options.objectIds || options.objectIds.length === 1){
			if(collectionId) {
				actionCollection.reset(_actions);
				actionCollection.collectionId = collectionId;
			} else {
				actionCollection.reset(_actions);
			}
		}else{
			//check for a collection Id, and if so, add it into the options for colllection creation
			if(collectionId) {
				actionCollection = new Action.Collection(_actions, {objectIds : options.objectIds, collectionId: collectionId}); //  these will all be group actions, so no objectId!
			} else {
				actionCollection = new Action.Collection(_actions, {objectIds : options.objectIds, objectNames : options.objectNames}); //  these will all be group actions, so no objectId!
			}
		}
		var deferred = actionCollection.fetch({
			global: false,
			success: _.bind(function(data){
				//Filter out the actions this the user does not have permission to execute
				Action.filterActions(data);
				//For each action, add it to the configured collection
				if(_.size(actionCollection.models) !== 0)
				{
					_.each(actionCollection.models, function(action){
						var actionData = null;
						var actionId = action.get("actionId");
						if(!actionId){
							action.set("actionId", action.get("ocActionId"));
						}

						if(!options.objectIds || options.objectIds.length === 1){
							actionData = singleActions.findWhere({actionId : action.get("actionId")} );
						}else{
							actionData = groupedActions.findWhere({actionId : action.get("actionId")} );
						}

						var actionOption = {
							"id":action.get("actionId"),
							"name":actionData.get("label")
						};

						optionsConfigured.push(actionOption);
					});
				}
				else
				{
					var actionOption = {
						"id":0,
						"name":"No Actions Available"
					};
					optionsConfigured.push(actionOption);
				}
			}, this),
			error: function(){
				app.log.error("Failed to get document actions");
			}
		});
		return {
			'actions': actionCollection,
			'optionsConfigured': optionsConfigured,
			'deferred': deferred
		};
	};

	// Return the module for AMD compliance.
	return Action;

});

