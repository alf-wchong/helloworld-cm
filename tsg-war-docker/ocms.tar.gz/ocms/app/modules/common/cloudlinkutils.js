define([
    "app",
    "wlapi"
],

function(app, WLAPI) {

    var CloudLinkUtil = {
        Google: {
            parseLink: function(url) {
                // pull the file or folder id out of the url and return it
                return url.match(/[-\w]{25,}/);
            },
            getDocuments: function(id, authObject) {
                // use url to get an array of document objects, where each object contains document url
                // document name and document id
                var deferredObjects =[];
                var objects = [];
                window.gapi.client.load('drive', 'v2', function() {
                    // we don't know hwether the id we parse from the url is for a file or
                    // folder at this point, so create two requests
                        var fileRequest = window.gapi.client.drive.files.get({
                            'fileId' : id
                        });
                        var folderRequest = window.gapi.client.drive.children.list({
                            'folderId' : id 
                        });

                        var deferredContents = [];

                        // execute request to see if folder has children
                        var defFile = $.Deferred();

                        fileRequest.execute(function(resp) {
                            if(resp.code === undefined) {
                                // we found something, now determine if it is a file and we are done, or it's a folder
                                // and we have to get children and make requests for each of them
                                if(!resp.downloadUrl && !resp.exportLinks) {
                                    folderRequest.execute(function(contents) {
                                        _.each(contents.items, function(child) {

                                            var childRequest = window.gapi.client.drive.files.get({
                                                'fileId' : child.id
                                            });
                                            // this call may execute async. so defer
                                            var defFolder = new $.Deferred();
                                            childRequest.execute(function(file) {
                                                // create a document object that will be used to generate blank OCOs in bulkupload
                                                var documentObj = {
                                                    name: file.title,
                                                    downloadUrl: (file.downloadUrl === undefined) ? file.exportLinks['application/pdf'] : file.downloadUrl,
                                                    cloudLinkDoc: true,
                                                    authToken: authObject.access_token,
                                                    mimeType: "pdf"
                                                };
                                                // push this object into our objects array and resolve
                                                objects.push(documentObj);
                                                defFolder.resolve();
                                                return defFolder.promise();
                                            });
                                        deferredContents.push(defFolder);
                                    });
                                    // send contents back to bulkupload to create dummy ocos
                                    $.when.apply($, deferredContents).done(function() {
                                        app.trigger('bulkupload:filesUploaded', objects);
                                    });
                                });
                            }
                        else {
                            var documentObj = {
                                name: resp.title,
                                downloadUrl: (resp.downloadUrl === undefined) ? resp.exportLinks['application/pdf'] : resp.downloadUrl,
                                cloudLinkDoc: true,
                                authToken: authObject.access_token, 
                                mimeType: "pdf"
                            };
                            objects = [];
                            objects.push(documentObj);
                            defFile.resolve();
                            return defFile;
                        }
                    }
                    else {
                        $("#bulk-upload-uploader-output").append("<div class='alert alert-error'>" + window.localize("modules.actions.cloudlinkUtils.errorImporting") + "</div>");
                    }   
                });
                deferredObjects.push(defFile);
                 // send contents back to bulkupload to create dummy ocos
                 $.when.apply($, deferredObjects).done(function(res) {
                    app.trigger('bulkupload:filesUploaded', objects);

                });
            });
        }
    },
    OneDrive: {
        parseLink: function(url) {
            // One drive requires id in the following format: file.{creator id lowecase}.{creator id uppercase}!{resource id}
            var creatorId = url.match(/(resid=)([\w\d]+)/)[2];
            var resourceId = url.match(/resid=[^&]*/)[0];

            resourceId = resourceId.split(/(!|%)/)[2];

            // using url decoding, realized the last three digits are what matters here
            if(resourceId.length > 3) {
                resourceId = resourceId.substr(resourceId.length - 3);
            }
            var path = creatorId.toLowerCase() + "." + creatorId.toUpperCase() + "!" + resourceId;
            return path;
        },
        getDocuments: function(path, authObject) {
            var objects = [];
            window.WL.api({
                // first try to get a folder. analyze response
                path: "folder." + path + "/files" + "?access_token=" + authObject.access_token,
                method: "GET"
                }).then(
                function (response) {
                    _.each(response.data, function(file) {
                        var documentObj = {
                            name: file.name,
                            downloadUrl: file.source,
                            cloudLinkDoc: true,
                            authToken: "",
                            mimeType: file.name.match(/\.([0-9a-z]+)(?:[\?#]|$)/i)[1]
                        };
                        documentObj.authToken = authObject.auth_token; 
                        objects.push(documentObj);
                    });                    
                    app.trigger('bulkupload:filesUploaded', objects);
                },
                function (responseFailed) {
                    // if we couldn't get a folder by the path we parsed out of the url, try to get a file at that path
                    window.WL.api({
                        path: "file." + path + "?access_token=" + authObject.access_token,
                        method: "GET"
                        }).then(
                        function (response) {
                            var documentObj = {
                                name: response.name,
                                downloadUrl: response.source,
                                cloudLinkDoc: true,
                                authToken: "",
                                mimeType: response.name.match(/\.([0-9a-z]+)(?:[\?#]|$)/i)[1]
                            };
                            documentObj.authToken = authObject.auth_token; 
                            objects.push(documentObj);
                            app.trigger('bulkupload:filesUploaded', objects);
                        },
                        function (responseFailed) {
                            // couldn't get file or folder - show an error
                            $("#bulk-upload-uploader-output").append("<div class='alert alert-error'>Could not import from OneDrive</div>");
                        }
                    );
                    
                }
            );
   
        }
    },
    Dropbox: {
        parseLink: function(url) {
            var index;
            // file with encoded url, ex: https://www.dropbox.com/s/w4r6gxaygniehmm/test.jpg?dl=0
            if(url.match(/.*dropbox\.com\/s\/.*dl=0/g)) {
                // parse out filename
                index = url.lastIndexOf('/');
                var filename = url.substr(index + 1, url.length);
                filename = filename.match(/.*(?=\?)/)[0];
                return {"filename": filename, "downloadUrl": this.convertUrlToDownload(url)};
            }
            // folder with encoded url
            else if(url.match(/.*dropbox\.com\/sh\/.*dl=0/g)) {
                return {"downloadUrl": this.convertUrlToDownload(url)};
            }
            else {
                // path case, currently not supported
                index = url.lastIndexOf("/");
                var path = url.substr(index + 1, url.length);
                return {"path": path};
            }

        },
        // dl=1 to enable download
        convertUrlToDownload: function(url){
            return url.substr(0, url.length-1) + 1;
        },
        getDocuments: function(data, authObject) {
            var objects = [];
            var deferred = $.Deferred();
            // check to see what kind of data we are dealing with
            if(data.filename !== undefined) {
                var documentObj = {
                    name: data.filename,
                    downloadUrl: data.downloadUrl,
                    cloudLinkDoc: true,
                    authToken:"",
                    mimeType: data.filename.match(/\.([0-9a-z]+)(?:[\?#]|$)/i)[1]
                };
                objects.push(documentObj);
                app.trigger('bulkupload:filesUploaded', objects);
            }
           else {
                // the case of a shared folder returns a folder as a zip so the content must unzipped in OC
                $.ajax({
                    url: app.serviceUrlRoot + "/hpi/getFilesInZip?url=" + data.downloadUrl,
                    type: "POST",
                    success: function(zipFile) {
                        _.each(zipFile, function(byteArray, filename) {
                            if(filename !== "/") {
                                // create the doc object as usual, but no authentication is required AND the byte array
                                // must be passed in so we don't need to request the content again
                                var documentObj = {
                                        name: filename,
                                        downloadUrl: "",
                                        authToken: "",
                                        cloudLinkDoc: true,
                                        mimeType: filename.match(/\.([0-9a-z]+)(?:[\?#]|$)/i)[1],
                                        byteArray: byteArray
                                    };
                                objects.push(documentObj);
                            }
                        });
                        deferred.resolve();
                        return deferred.promise();
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                    }
                });
            }
            $.when(deferred).done(function() {
                app.trigger('bulkupload:filesUploaded', objects);
            });
        }
    }
};
    return CloudLinkUtil;
});
