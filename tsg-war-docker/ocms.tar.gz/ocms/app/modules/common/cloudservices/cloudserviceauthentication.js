define([
    "app",
],
function(app) {
    var CloudServiceAuthentication = app.module();

    CloudServiceAuthentication.google = {
        authenticate: function(options){
            window.gapi.load("client", function(){
                window.gapi.client.load('gmail', 'v1', function() {
                    window.gapi.auth.authorize(options, function(result){ 
                        app.trigger("cloudservicesauthentication:google:authenticated", result);
                    });
                });
            });
        }
    };
 
    CloudServiceAuthentication.googleDrive = {
        authenticate: function(options){
            window.gapi.load("client", function(){
                window.gapi.client.load('drive', 'v3', function() {
                    window.gapi.auth.authorize(options, function(result){ 
                        app.trigger("cloudservicesauthentication:google:authenticated", result);
                    });
                });
            });
        }
    };

    CloudServiceAuthentication.microsoft365 = {
        authenticate: function(options){

            var self = this;
            self.access_token = "";

            // Configuration object constructed
            const config = {
                auth: {
                    clientId: options.clientId,
                    redirectUri: options.redirectUrl
                },
                cache: {
                    cacheLocation: "localStorage",
                    storeAuthStateInCookie: true
                }
            };

            // create UserAgentApplication instance
            self.msalInstance = new window.Msal.UserAgentApplication(config);

            var msalRequest = {
               scopes: ["user.read", "Files.ReadWrite.All", "Files.ReadWrite.AppFolder", "Files.ReadWrite.Selected", "offline_access", "openid", "Sites.ReadWrite.All"]
            };
           
           // this will pop up a login window to have the user sign-in and accept the permissions that are requested in the scopes array
           self.msalInstance.loginPopup(msalRequest)
            .then(function() {
                // the response will return a valid user id token, if successfully and has an account we can proceed
                if (self.msalInstance.getAccount()) {

                    // here will acquire token silently with above permission scopes again and the response will contain the access token we need
                    self.msalInstance.acquireTokenSilent(msalRequest)
                        .then(function(response) {
                            // get access token from response
                            // response.accessToken
                            app.trigger("cloudservicesauthentication:microsoft365:authenticated", response.accessToken);
                        })
                        .catch(function(err) {
                            // could also check if err instance of InteractionRequiredAuthError if you can import the class.
                            if (err.name === "InteractionRequiredAuthError") {
                                return self.msalInstance.acquireTokenPopup(msalRequest)
                                    .then(function(response) {
                                        // get access token from response
                                        // response.accessToken
                                        app.trigger("cloudservicesauthentication:microsoft365:authenticated", response.accessToken);
                                    })
                                    .catch(function() {
                                        app.trigger("cloudservicesauthentication:microsoft365:error");
                                    });
                            }
                        });
                } else {
                    app.trigger("cloudservicesauthentication:microsoft365:error");
                }
            })
            .catch(function() {
                app.trigger("cloudservicesauthentication:microsoft365:error");
            });

            
        }
    };
    
    return CloudServiceAuthentication;
});