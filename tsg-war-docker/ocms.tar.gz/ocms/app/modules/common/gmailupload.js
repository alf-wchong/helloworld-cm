define([
    "app",
    "cloudserviceauthentication",
    "modules/common/spinner",
    "module",
    "handlebars",
    "tsgUtils"
],
function(app, CloudServiceAuthentication, HPISpinner, module, Handlebars, tsgUtils) {
    
    "use strict";

    var GmailUpload = {};

    //backbone model for an individual thread
    //from - last person to send email on thread
    //subject - subject of thread
    //snippent - beginning of email body
    //threadId - google id for the thread
    GmailUpload.Thread = Backbone.Model.extend({
        defaults: function(){
            return _.extend({}, {
                from: "",
                subject: "",
                snippet: "",
                received: "",
                threadId: ""
            });
        }
    });

    //collection of thread models
    GmailUpload.ThreadCollection = Backbone.Collection.extend({
        model: GmailUpload.Thread
    });

    //represents one page of result threads from gmail
    //pageToken - google id for a specific page
    //threads - collection of threads associated with this page
    //pageNumber - what page of results this is
    GmailUpload.ResultPage = Backbone.Model.extend({
        defaults: function(){
            return _.extend({}, {
                pageToken: "",
                threads: new GmailUpload.ThreadCollection(),
                pageNumber: 1
            });
        },
        initialize: function(options){
            var defaultVals = this.defaults();
            if(options && options.threads){
                if(options.threads instanceof Backbone.Collection){
                    this.set("threads", options.threads);
                } else {
                    this.set("threads", new GmailUpload.ThreadCollection(options.threads));
                }
            } else {
                this.set("threads", defaultVals.threads);
            }

            if(options && options.pageToken){
                this.set("pageToken", options.pageToken);
            } else {
                this.set("pageToken", defaultVals.pageToken);
            }

            if(options && options.pageNumber){
                this.set("pageNumber", options.pageNumber);
            } else {
                this.set("pageNumber", defaultVals.pageNumber);
            }
        }
    });

    //collection of result pages
    GmailUpload.ResultPageCollection = Backbone.Collection.extend({
        model: GmailUpload.ResultPage
    });

    //this is a model that contains all results we get
    //back from gmail
    //query - user provided query to limit results
    //numResults - estimated number of total results provided by google
    //resultsPerPage - number of threads shown/page
    //resultPages - collection of result pages
    GmailUpload.Results = Backbone.Model.extend({
        defaults: function(){
            return _.extend({}, {
                query: "label:INBOX",
                numResults: 0,
                resultsPerPage: 25,
                resultPages: new GmailUpload.ResultPageCollection()
            });
        },
        initialize: function(options){
            var defaultVals = this.defaults();
            if(options && options.resultPages){
                if(options.resultPages instanceof Backbone.Collection){
                    this.set("resultPages", options.resultPages);
                } else {
                    this.set("resultPages", new GmailUpload.ResultPageCollection(options.resultPages)); 
                } 
            } else {
                this.set("resultPages", defaultVals.resultPages);
            }

            if(options && options.query){
                this.set("query", options.query);
            } else {
                this.set("query", defaultVals.query);
            }

            if(options && options.numResults){
                this.set("numResults", options.numResults);
            } else {
                this.set("numResults", defaultVals.numResults);
            }

            if(options && options.resultsPerPages){
                this.set("resultsPerPage", options.resultsPerPage);
            } else {
                this.set("resultsPerPage", defaultVals.resultsPerPage);
            }
        }
    });

    GmailUpload.View = Backbone.Layout.extend({
        template: "common/gmail/gmailupload",
        events: {
            "click #gmail-add-emails-btn": "addMessagesToBulkUpload",
            "click #gmail-cancel-btn": "closeModal"
        },
        initialize: function(options){
            var self = this;
            this.fileNames = options.fileNames;
            this.model = this.options.model ? new GmailUpload.Results(this.options.model) : new GmailUpload.Results();
            this.userEmail = app.user.get("emailAddress");
            this.selectedThreads = new Backbone.Collection();
            this.visibleMessageType = this.options.visibleMessageType ? this.options.visibleMessageType : "threads";
            this.labelId = "";
            this.sterilizeAttributes = options.sterilizeAttributes;

            //set-up listeners here
            this.listenTo(app, "cloudservicesauthentication:google:authenticated", function(result){
                self.authenticated = result;
                self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"));
            });

            //user clicks the next button
            this.listenTo(app, "gmail:nextButton:clicked", function(){
                self.setSpinner();
                //get page id of current result page, and then show the next one
                var pageId = self.getView("#gmail-results-table").model.get("pageToken");
                var resultIndex = 0;
                if(pageId){
                    var resultPageModel = self.model.get("resultPages").findWhere({"pageToken": pageId});
                    resultIndex = self.model.get("resultPages").indexOf(resultPageModel);
                }
                var newPage = self.model.get("resultPages").at((resultIndex+1));
                if(newPage.get("threads").length === 0){
                    if(self.pageType === 'query'){
                        self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"), newPage.get("pageToken"));
                    }
                    else{
                        self.getMessages("", this.model.get("resultsPerPage"), newPage.get("pageToken"), this.model.get("labelId"));
                    }
                } else {
                    self.loading = false;
                    self.setView("#gmail-results-table", new GmailUpload.TableView({ model: newPage, prevSelectedThreads: self.selectedThreads })).render();
                    if(resultIndex+1 === self.model.get("resultPages").length-1){
                        app.trigger("gmail:lastPageReturned", newPage.get("threads").length);
                    } else {
                        app.trigger("gmail:newPageReturned");
                    }
                }

            });
            
            //user clicks the previous button
            this.listenTo(app, "gmail:prevButton:clicked", function(){
                self.setSpinner();
                //get page id of current result page, and then show the prev one
                var pageId = self.getView("#gmail-results-table").model.get("pageToken");
                var resultIndex = 0;
                if(pageId){
                    var resultPageModel = self.model.get("resultPages").findWhere({"pageToken": pageId});
                    resultIndex = self.model.get("resultPages").indexOf(resultPageModel);
                }
                var newPage = self.model.get("resultPages").at((resultIndex-1));
                if(newPage.get("threads").length === 0){
                    if(self.pageType === 'query'){
                        self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"), newPage.get("pageToken"));
                    }
                    else{
                        self.getMessages("", this.model.get("resultsPerPage"), newPage.get("pageToken"), this.model.get("labelId"));
                    }
                } else {
                    self.loading = false;
                    self.setView("#gmail-results-table", new GmailUpload.TableView({ model: newPage, prevSelectedThreads: self.selectedThreads })).render();
                }
            });

            this.listenTo(app, "gmailUpload:addThreadModel", function(threadModel){
                self.selectedThreads.add(threadModel);
                self.validate();
            });

            this.listenTo(app, "gmailUpload:removeThreadModel", function(threadModel){
                self.selectedThreads.remove(threadModel);
                self.validate();
            });

            this.listenTo(app, "gmailUpload:validate", function(){
                self.validate();
            });

            this.listenTo(app, "gmailUpload:stopSpinner", function(){
                self.stopSpinner();
            });

            this.listenTo( app, "gmailUpload:getThreadMode", function(){
                self.visibleMessageType = "threads";
                self.setSpinner();
                //clear out resultPages
                self.model.set("resultPages", new GmailUpload.ResultPageCollection());
                self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"));
            });

            this.listenTo( app, "gmailUpload:getMessageMode", function(){
                self.visibleMessageType = "messages";
                self.setSpinner();
                //clear out resultPages
                self.model.set("resultPages", new GmailUpload.ResultPageCollection());
                self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"));
            });

            //user clicks the search button
            this.listenTo(app, "gmail:searchButtonClicked", function(newQuery){
                if(!newQuery || newQuery !== self.query){
                    if(!newQuery){
                        //user emptied out the search, so let's go back to original query
                        self.model.set("query", "label: INBOX");
                    } else if(newQuery !== self.query){
                        //new query
                        self.model.set("query", newQuery);
                    }

                    //clear out resultPages
                    self.model.set("resultPages", new GmailUpload.ResultPageCollection());

                    $("#gmail-results-table").hide();
                    self.getView("#gmail-controls").remove();

                    //put our spinner back in and get the docs
                    self.setSpinner();

                    self.pageType = "query";

                    self.getMessages(this.model.get("query"), this.model.get("resultsPerPage"));
                }
            });

            //user clicks the search button
            this.listenTo(app, "gmail:searchLabelButtonClicked", function(newLabel){
                if(!newLabel || newLabel !== self.labelId){
                    if(!newLabel){
                        //user emptied out the search, so let's go back to original query
                        self.model.set("query", "label: INBOX");
                    } else if(newLabel !== self.labelId){
                        //new label
                        self.model.set("labelId", newLabel);
                    }

                    //clear out resultPages
                    self.model.set("resultPages", new GmailUpload.ResultPageCollection());

                    $("#gmail-results-table").hide();
                    self.getView("#gmail-controls").remove();

                    //put our spinner back in and get the docs
                    self.setSpinner();

                    self.labelId = newLabel;

                    self.pageType = "label";

                    self.getMessages("", this.model.get("resultsPerPage"), null, this.model.get("labelId"));
                }
            });
            

            CloudServiceAuthentication.google.authenticate({
                client_id: this.options.client_id,
                scope: this.options.scope,
                immediate: this.options.immediate
            });

            this.loading = true;
        },
        getMessages: function(query, numResults, pageToken, label){
            var self = this;
            var options = {
                'userId': self.userEmail,
                'q': query + " -is:chat",
                'maxResults': numResults
            };

            if(label){
                options = {
                    'userId': self.userEmail,
                    'labelIds': label,
                    'maxResults': numResults
                };
            }

            if(pageToken){
                options.pageToken = pageToken;
            }

            window.gapi.client.load('gmail', 'v1', function() {
                var request = null;
                if(self.visibleMessageType === "threads"){
                   request = window.gapi.client.gmail.users.threads.list(options);
                    request.execute(function(results){
                        self.parseMessages(results, pageToken);
                    });
                }
                else{
                    request = window.gapi.client.gmail.users.messages.list(options);
                    request.execute(function(results){
                        self.parseMessages(results, pageToken);
                    });
                }
            });
        },
        compareThreads: function(a, b){
            var aDate, bDate = 0;
            for(var i=0; i<a.messages.length; i++){
                if(_.where(a.messages[i].payload.headers, ({name: "Date"})).length > 0){
                    aDate = Date.parse(_.where(a.messages[i].payload.headers, {name: "Date"})[0].value);
                    break;
                }
            }

            for(var j=0; j<b.messages.length; j++){
                if(_.where(b.messages[j].payload.headers, ({name: "Date"})).length > 0){
                    bDate = Date.parse(_.where(b.messages[j].payload.headers, {name: "Date"})[0].value);
                    break;
                }
            }

            if(aDate && bDate){
                if(aDate > bDate){
                    return -1;
                } else if(aDate < bDate){
                    return 1;
                }
            } else if(aDate) {
                return -1;
            } else if(bDate){
                return 1;
            }

            return 0;
        },
        compareMessages: function(a, b){
            var aDate, bDate = 0;
                if(_.where(a.payload.headers, ({name: "Date"})).length > 0){
                    aDate = Date.parse(_.where(a.payload.headers, {name: "Date"})[0].value);
                }

                if(_.where(b.payload.headers, ({name: "Date"})).length > 0){
                    bDate = Date.parse(_.where(b.payload.headers, {name: "Date"})[0].value);
                }

            if(aDate && bDate){
                if(aDate > bDate){
                    return -1;
                } else if(aDate < bDate){
                    return 1;
                }
            } else if(aDate) {
                return -1;
            } else if(bDate){
                return 1;
            }

            return 0;
        },
        parseMessages: function(messages, pageToken){
            var self = this;
            this.metadataThreads = [];
            var deferreds = [];
            
            deferreds.push(self.getUserLabels());

            if(this.visibleMessageType === "threads"){
                _.each(messages.threads, function(message){
                    deferreds.push(self.getMetadataMessage(message.id, "metadata"));
                });
            }
            else{
                _.each(messages.messages, function(message){
                    deferreds.push(self.getMetadataMessage(message.id, "metadata"));
                });
            }

            $.when.apply($, deferreds).done(function() {
                if(self.visibleMessageType === "threads"){
                    self.metadataThreads.sort(self.compareThreads);
                }
                else{
                    self.metadataThreads.sort(self.compareMessages);
                }

                self.threadCollection = new GmailUpload.ThreadCollection();
                var deferreds2 = self.parseThreadsOrMessages();

                $.when.apply($, deferreds2).done(function(){
                   

                    var resultPage;

                    if(self.model.get("resultPages").findWhere({"pageToken": pageToken})){
                        resultPage = self.model.get("resultPages").findWhere({"pageToken": pageToken}).set("threads", self.threadCollection);
                    } else {
                        //if we didn't fine a result page, this means we have the first page
                        resultPage = new GmailUpload.ResultPage({
                            'threads': self.threadCollection
                        });

                        self.model.get("resultPages").push(resultPage);

                        //if this is our first page, we want to set the control view
                        self.setView("#gmail-controls", new GmailUpload.ControlsView({
                            "totalNumber": messages.resultSizeEstimate,
                            "query": self.model.get("query"),
                            "visibleMessageType": self.visibleMessageType,
                            "hasResults": messages.resultSizeEstimate > 0,
                            "labelId": self.labelId,
                            "userLabels": self.userLabels
                        }));

                        self.model.set("numResults", messages.resultSizeEstimate);
                    }

                    //we also need to save the nextPageToken on a new ResultPage
                    if(messages.nextPageToken){
                        var nextResultPage = new GmailUpload.ResultPage({
                            'pageToken': messages.nextPageToken
                        });
                        self.model.get("resultPages").push(nextResultPage);
                        app.trigger("gmail:newPageReturned");
                    } else {
                        app.trigger("gmail:lastPageReturned", resultPage.get("threads").length);
                    }

                    self.setView("#gmail-results-table", new GmailUpload.TableView({
                        model: resultPage,
                        prevSelectedThreads: self.selectedThreads
                    }));


                    self.loading = false;
                    self.stopSpinner();
                    if(self.hasRendered){
                        self.render();
                    }
                });
            });
        },
        getUserLabels: function(){
            var self = this;
            var deferred = $.Deferred();
            var request = window.gapi.client.gmail.users.labels.list({
                'userId': self.userEmail
              });
              request.execute(function(resp){
                if(resp.code !== 404) {
                    var userLabels = [];

                    _.each(resp.labels, function(labelObject){
                        if(labelObject.type === 'user'){
                            userLabels.push(labelObject);
                        }
                    });

                    userLabels = _.sortBy(userLabels, 'name');

                    self.userLabels = userLabels;
                    deferred.resolveWith(userLabels);
                }
                else{
                    deferred.resolve();
                }
            });
            return deferred;
        },
        getMetadataMessage: function(messageId, format){
            var self = this;
            var request = null;
            if(this.visibleMessageType === "threads"){
                request = window.gapi.client.gmail.users.threads.get({
                    id: messageId,
                    userId: this.userEmail,
                    format: format
                });
            }
            else{
                request = window.gapi.client.gmail.users.messages.get({
                    id: messageId,
                    userId: this.userEmail,
                    format: format
                });
            }

            var deferred = $.Deferred();
            request.execute(function(response){
                if(response.code !== 404) {
                    self.metadataThreads.push(response);
                    deferred.resolveWith(response);
                }
                else{
                    deferred.resolve();
                }
            });
            return deferred;
        },
        parseThreadsOrMessages: function(){
            var self = this;

            //first, convert our result threads to GmailUpload.Thread models
            var deferreds = [];
            if(self.visibleMessageType === "threads"){
                _.each(self.metadataThreads, function(thread){
                    var longDate = Date.parse(_.where(thread.messages[0].payload.headers, {name: "Date"})[0].value);
                    deferreds.push(self.createThread(thread.messages[0], longDate));
                });
            }
            else{
                _.each(self.metadataThreads, function(thread){
                    var longDate = Date.parse(_.where(thread.payload.headers, {name: "Date"})[0].value);
                    deferreds.push(self.createThread(thread, longDate));
                });
            }
            return deferreds;

        },
        createThread: function(thread, longDate){
            var self = this;
            var deferred = $.Deferred();
            app.context.dateService.getFormattedDate(longDate).done(function(formattedDate) {
                self.threadCollection.push(new GmailUpload.Thread({
                    from: _.where(thread.payload.headers, {name: "From"})[0].value,
                    subject: _.where(thread.payload.headers, {name: "Subject"})[0].value,
                    snippet: $('<div/>').html(thread.snippet).text(),
                    received: formattedDate,
                    threadId: thread.id
                }));
                deferred.resolve();
            });
            return deferred;
        },
        addMessagesToBulkUpload: function(){
            var self = this;
            this.setSpinner();
            $("#gmail-results-table").hide();
            var deferreds = [];
            this.contentMessages = [];
            _.each(self.selectedThreads.models, function(messageModel){
                deferreds.push(self.getFullMessage(messageModel.get("threadId"), "full"));
            });

            $.when.apply($, deferreds).done(function() {
                // make message into a "file" and send to bulk upload
                self.files = [];
                _.each(self.contentMessages, function(messageObject){
                    self.parseFullMessage(messageObject);
                });


                app.trigger('gmailUpload:emailsSelected', self.files);   
                app.trigger("alert:close");  
            });

        },
        getFullMessage: function(threadId, format){
            var self = this;
            var request = null;
            if(this.visibleMessageType === "threads"){
                request = window.gapi.client.gmail.users.threads.get({
                    id: threadId,
                    userId: this.userEmail,
                    format: format
                });
            }
            else{
                request = window.gapi.client.gmail.users.messages.get({
                    id: threadId,
                    userId: this.userEmail,
                    format: format
                });
            }

            var deferred = $.Deferred();
            request.execute(function(response){
                self.contentMessages.push(response);
                deferred.resolveWith(response);
            });
            return deferred;
        },
        parseFullMessage: function(messageObject){
            var self = this;
            // check to see if we have a thread or message by seeing if messageObject.messages is defined
            if(!messageObject.messages){
                // if its just a message convert it into a thread type object.
                messageObject = {
                    historyId: messageObject.historyId,
                    id: messageObject.id,
                    messages: [messageObject]
                };
            }
            var blobArray = [];
            var attachments = [];
            var emailBodyParts = null;
            var blobPart = null;
            var blobType = null;
            var skipFinal = null;
            // Alfresco breaks if you have a # in the name. So, we remove any #s. 
            // We also strip out any #s from the emails, as those break Alfresco.
            var messageName = self.sterilizeFilename(_.where(messageObject.messages[0].payload.headers, {name: "Subject"})[0].value + ".html", self.sterilizeAttributes);
            var messageId = messageObject.id;
            
            var messageProps = null;

            var threadLength = messageObject.messages.length;
            _.each(messageObject.messages, function(message, index){

                // Only add the final thread (it has all the messages included in it) 
                if(self.visibleMessageType !== "threads" || (self.visibleMessageType === "threads") && index === threadLength-1){
                    messageProps = self.getMessageObjectProps(message.payload.headers);
                    blobArray.push(self.convertHeadersToBlob(message.payload.headers));

                    var hasAttachments = false;
                    skipFinal = false;
                    var parts = message.payload.parts;
                    // no attachment
                    if(!parts){
                        skipFinal = true;
                        blobType = _.where(message.payload.headers, {name: "Content-Type"})[0].value;
                        blobPart = message.payload.body.data;
                    }
                    // attachment
                    else{
                        emailBodyParts = parts;
                        if(parts[0].parts){
                            hasAttachments = true;
                            emailBodyParts = parts[0].parts;
                        }
                        
                        _.each(emailBodyParts, function(part){
                            if(part.mimeType === "text/html"){
                                blobPart = part.body.data;
                                if(!blobType){
                                    blobType = _.where(part.headers, {name: "Content-Type"})[0].value;
                                }
                            }
                        });
                    }
                    blobArray.push(self.convertBodyToBlob(blobPart));

                    //check for attachments, and put on file if they exist
                    if (hasAttachments && parts.length > 1) {
                        for (var i=1; i<parts.length; i++){
                            var attachmentBlobType = _.where(parts[i].headers, {name: "Content-Type"})[0].value;
                            var attachmentBlob = new Blob([], {type: attachmentBlobType});
                            
                            attachmentBlob.name = self.sterilizeFilename(parts[i].filename, self.sterilizeAttributes);
                            attachmentBlob.id = parts[i].body.attachmentId;
                            attachments.push(attachmentBlob);
                        }
                    }
                }
            });

            var finalBlobArray = [];
            if(!skipFinal){
                _.each(blobArray, function(blobArrayPart){
                    _.each(blobArrayPart, function(byteArray){
                        finalBlobArray.push(byteArray);
                    });
                });
            }
            else {
                finalBlobArray = self.convertBodyToBlob(blobPart);
            }
            self.createMessageAndBlob(finalBlobArray, blobType, attachments, messageId, messageName, messageProps);
        },
        createMessageAndBlob: function(finalBlobArray, blobType, attachments, messageId, messageName, messageProps){

            var file = new Blob(finalBlobArray, {type: blobType});
            file.name =  messageName;
            file.id = messageId;
            file.attachments = attachments;
            file.emailProps = messageProps;

            this.files.push(file);
        },
        convertHeadersToBlob: function(headers){
            var messageProps = this.getMessageProps(headers);

            var htmlString = '<div><table><tbody><tr><td colspan="2"><span><b>from:</b></span></td><td colspan="2"><span>'+messageProps.from+'</span></td></tr><tr><td colspan="2"><span><b>to:</b></span></td><td colspan="2"><span><span>'+messageProps.to+'</span><br></span></td></tr><tr><td colspan="2"><span><b>cc:</b></span></td><td colspan="2"><span>'+messageProps.cc+'</span></td></tr><tr><td colspan="2"><span><b>date:</b></span></td><td colspan="2"><span>'+messageProps.date+'</span></td></tr><tr><td colspan="2"><span><b>subject:</b></span></td><td colspan="2"><span>'+messageProps.email_subject+'</span></td></tr></tbody></table></div>';

            return this.convertBodyToBlob(btoa(window.unescape(encodeURIComponent(htmlString))));
        },
        getMessageProps: function(headers){
            var messageProps = {};

            var to = this.getPropValue(_.where(headers, {name: "To"})[0]);
            var from  = this.getPropValue(_.where(headers, {name: "From"})[0]);
            var cc = this.getPropValue(_.where(headers, {name: "CC"})[0] ? _.where(headers, {name: "CC"})[0] : _.where(headers, {name: "Cc"})[0]);
            var subject = this.getPropValue(_.where(headers, {name: "Subject"})[0]);
            var date = this.getPropValue(_.where(headers, {name: "Date"})[0]);

            if(!subject){
                subject = "No Subject";
            }

            messageProps.to = this.cleanUpAddressRepeatingProps(to.split(">,"));
            messageProps.from = this.cleanUpAddressProps(from);
            messageProps.cc = this.cleanUpAddressRepeatingProps(cc.split(">,")); 
            messageProps.email_subject = this.cleanUpProps(subject);
            messageProps.date = this.cleanUpProps(date);

            return messageProps;
        },
        getMessageObjectProps: function(headers){
            var messageProps = {};

            var to = this.getPropValue(_.where(headers, {name: "To"})[0]);
            var from  = this.getPropValue(_.where(headers, {name: "From"})[0]);
            var cc = this.getPropValue(_.where(headers, {name: "CC"})[0] ? _.where(headers, {name: "CC"})[0] : _.where(headers, {name: "Cc"})[0]);
            var subject = this.getPropValue(_.where(headers, {name: "Subject"})[0]);
            var date = this.getPropValue(_.where(headers, {name: "Date"})[0]);

            if(!subject){
                subject = "No Subject";
            }

            var jsDate = new Date(date);

            messageProps.to = this.cleanUpAddressRepeatingProps(to.split(">,"));
            messageProps.from = this.cleanUpAddressProps(from);
            messageProps.cc = this.cleanUpAddressRepeatingProps(cc.split(">,")); 
            messageProps.email_subject = this.cleanUpProps(subject);
            messageProps.date = jsDate.getTime();

            if(messageProps.cc.length === 1 && messageProps.cc[0] === ""){
                delete messageProps.cc;
            }

            return messageProps;
        },
        getPropValue: function(prop){
            if(prop){
                return prop.value;
            }
            else{
                return "";
            }
        },
        cleanUpAddressRepeatingProps: function(propArray){
            var newArray = [];
            _.each(propArray, function(prop){
                prop = prop.replace(' <', ' - ');
                prop = prop.replace('>', '');
                newArray.push(prop);
            });

            return newArray;
        },
        cleanUpAddressProps: function(prop){
            prop = prop.replace(' <', ' - ');
            prop = prop.replace('>', '');
            return prop;
        },
        cleanUpProps: function(prop){
            return prop.replace('<','').replace('>','');
        },
        // This is done differently than in generic bulkupload, so we redefined it here.
        sterilizeFilename: function(oldFilename, sterilizeAttributes) {
            var sterilizedFileName = oldFilename;
            if (sterilizeAttributes.shouldSterilizeFilenames === 'true') {
                sterilizedFileName = tsgUtils.sterilizeFilename(oldFilename, sterilizeAttributes);
            }
            
            var fileExt = null; 
            if (sterilizedFileName.indexOf('.') > 0) {
                // Split on the .
                var splitName = sterilizedFileName.split('.');
                
                //The extension is the last split value 
                fileExt = splitName[splitName.length-1];

                // Start building up the name again with the first split value
                sterilizedFileName = splitName[0];

                // If there are multiple .'s in the name, this loop will put all the rest of the name back together (including the origianl .'s)
                for(var i=1;i<splitName.length-1;i++){
                    sterilizedFileName += ".";
                    sterilizedFileName += splitName[i];
                }
            }

            var newFileName = sterilizedFileName;

            if (_.contains(this.fileNames, (fileExt ? sterilizedFileName + "." + fileExt : sterilizedFileName))) {
                var index = 1;
                var doesContain = true;
                
                while (doesContain) {
                    newFileName = sterilizedFileName + "-" + index;
                    
                    if (!_.contains(this.fileNames, (fileExt ? newFileName + "." + fileExt : newFileName))) {
                        doesContain = false;
                    } else {
                        index++;
                    }
                }
            }

            if (fileExt) {
                newFileName = newFileName + "." + fileExt;
            }

            this.fileNames.push(newFileName);

            return newFileName;
        },
        convertBodyToBlob: function (gmailBody){
            if(!gmailBody){
                gmailBody ="";
            }
            var sliceSize = 1024;
            var byteCharacters = atob(gmailBody.replace(/-/g, '+').replace(/_/g, '/'));
            var bytesLength = byteCharacters.length;
            var slicesCount = Math.ceil(bytesLength / sliceSize);
            var byteArrays = new Array(slicesCount);

            for (var sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
                var begin = sliceIndex * sliceSize;
                var end = Math.min(begin + sliceSize, bytesLength);

                var bytes = new Array(end - begin);
                var i = 0;
                var offset = begin;
                while(offset < end) {
                    bytes[i] = byteCharacters[offset].charCodeAt(0);
                    i++;
                    offset++;
                }
                byteArrays[sliceIndex] = new Uint8Array(bytes);
            }
            return byteArrays;

        },
        setSpinner: function(){
            var spinElem = this.$("#gmail-loading")[0];
            if(spinElem) {
                // animate our loading indicator with spin.js (lighter weight than animated gif)
                this.spinner = HPISpinner.createSpinner({
                    top: '15px',
                    left: '640px',
                    color: '#000'
                }, spinElem);
            }
        },
        stopSpinner: function(){
            if(this.spinner){
                HPISpinner.destroySpinner(this.spinner);
            }
        },
        validate: function(){
            if(this.selectedThreads.length < 1){
                $("#gmail-add-emails-btn").addClass("disabled");
            }
            else{
                $("#gmail-add-emails-btn").removeClass("disabled");
            }
        },
        closeModal: function(){
            app.trigger("alert:close");
        },
        afterRender: function(){
            if(this.loading){
                this.setSpinner();
            }
            else{
                this.stopSpinner();
            }

            this.hasRendered = true;
            var mulltiplier = $(window).width() / 11520;
            $(".gmailUploadModal").css("left", parseInt($(window).width()*mulltiplier, 10));
            $(".gmailUploadModal").css("top", parseInt($(window).height()/20, 10));
            $(".gmailUploadModal").css("width", parseInt($(window).width()/1.42, 10));
            $(".gmailTable").css("max-height", parseInt($(window).height()/2, 10));
        }
    });
    
    //this view holds the search input and arrow buttons
    GmailUpload.ControlsView = Backbone.Layout.extend({
        template: "common/gmail/gmailcontrolview",
        events: {
            "click #prevPageButton": "goPrevPage",
            "click #nextPageButton": "goNextPage",
            "click #gmailSearchButton": "searchGmail",
            "click #gmailLabelSearchButton": "searchGmailLabel",
            "change #gmailSearchInput": "updateGmailSearch",
            "change #gmailLabelSearchInput": "updateGmailLabelSearch",
            "click #enable" : "showThreads",
            "click #disable" : "showMessages"
        },
        initialize: function(options){
            var self = this;
            this.query = options && options.query && options.query != "label:INBOX" ? options.query : "";
            this.lowNumber = 1;
            this.highNumber = 0;
            this.totalNumber = options && options.totalNumber ? options.totalNumber : 25;
            this.pageSize = 25;
            this.disablePrev = true;
            this.disableNext = false;
            this.visibleMessageType = this.options.visibleMessageType ? this.options.visibleMessageType : "threads";

            this.labelId = options && options.labelId ? options.labelId : "";
            this.userLabels = options && options.userLabels ? options.userLabels : [];

            this.listenTo(app, "gmail:lastPageReturned", function(lastPageSize){
                self.disableNext = true;
                self.newPageUpdate(lastPageSize, true);
            });

            this.listenTo(app, "gmail:newPageReturned", function(){
                self.newPageUpdate(self.pageSize, false);
            });

            Handlebars.registerHelper("disable", function(val, options){
                var fnTrue = options.fn, fnFalse = options.inverse;
                if(!val || val === "false"){
                    return fnFalse();
                } else {
                    return fnTrue();
                }
            });
        },
        goPrevPage: function(evt){
            evt.stopPropagation();
            app.trigger("gmail:prevButton:clicked");
            this.lowNumber = this.lowNumber - this.pageSize;
            //if the high number can be evenly divided by the pageSize
            //that means we have a 'full' page, so we can subtract
            //the pageSize from highNumber
            if(this.highNumber % this.pageSize === 0){
                this.highNumber = this.highNumber - this.pageSize;
            } else {
                //if we don't have a full page, we only want to subtract
                //the number of results being shown, which is the remainder
                //of when we divide the highNumber by the page size
                this.highNumber = this.highNumber - (this.highNumber % this.pageSize);
            }
            if(this.lowNumber === 1){
                //if lowNumber is 1, can't go any farther back
                //so disable the previous button
                this.disablePrev = true;
            }
            //if we click the prev button, we have a next page available
            this.disableNext = false;
            this.render();
        },
        goNextPage: function(evt){
            //because we don't know how many results we are going
            //to get for the new page, we can't update highNumber
            evt.stopPropagation();
            app.trigger("gmail:nextButton:clicked");
            this.lowNumber = this.lowNumber + this.pageSize;
            this.disablePrev = false;
            this.render();
        },
        newPageUpdate: function(pageSize, isLastPage){
            this.highNumber = this.highNumber + pageSize;
            
            //if this is the last page, our total number
            //is whatever the high number is
            if(isLastPage){
                this.totalNumber = this.highNumber;
            } else if (this.highNumber >= this.totalNumber){
                //if we aren't on the last page and our high number
                //is bigger/equal to the total number of results,
                //we need to increase it
                this.totalNumber = this.highNumber + this.pageSize;
            }
            this.render();
        },
        searchGmail: function(evt){
            evt.stopPropagation();
            app.trigger("gmail:searchButtonClicked", this.query);
        },
        searchGmailLabel: function(evt){
            evt.stopPropagation();
            app.trigger("gmail:searchLabelButtonClicked", this.labelId);
        },
        updateGmailSearch: function(evt){
            this.query = $(evt.target).val();
        },
        updateGmailLabelSearch: function(evt){
            this.labelId = $(evt.target).val();
        },
        showThreads: function(event) {
            if(this.visibleMessageType !== "threads"){
                this.visibleMessageType = "threads";
                //Add or remove css classes based on slider position
                $('#approve-status-slider-element').addClass("left");
                $('#enableTitle').addClass("gmailTextColorWhite");
                $('#disableTitle').addClass("gmailTextColorBlack");

                $('#approve-status-slider-element').removeClass("right");
                $('#enableTitle').removeClass("gmailTextColorBlack");
                $('#disableTitle').removeClass("gmailTextColorWhite");
                event.stopPropagation();
                app.trigger("gmailUpload:getThreadMode");
            }
            else{
                event.stopPropagation();
            }
        },
        showMessages: function(event) {
            if(this.visibleMessageType !== "messages"){
                this.visibleMessageType = "messages";
                //Add or remove css classes based on slider position
                $('#approve-status-slider-element').addClass("right");
                $('#enableTitle').addClass("gmailTextColorBlack");
                $('#disableTitle').addClass("gmailTextColorWhite");

                $('#approve-status-slider-element').removeClass("left");
                $('#enableTitle').removeClass("gmailTextColorWhite");
                $('#disableTitle').removeClass("gmailTextColorBlack");
                event.stopPropagation();

                app.trigger("gmailUpload:getMessageMode");
            }
            else{
                event.stopPropagation();
            }
        },
        serialize: function(){
            var self = this;
            return{
                lowNumber: this.lowNumber,
                highNumber: this.highNumber,
                total: this.totalNumber,
                query: this.query,
                disablePrev: this.disablePrev,
                disableNext: this.disableNext,
                isThreadMode: this.visibleMessageType === "threads" ? true : false,
                hasResults: this.options.hasResults,
                currentLabel: _.where(this.userLabels, {id: this.labelId})[0],
                labels: _.filter(this.userLabels, function(labelObject){
                    return labelObject.id !== self.labelId;
                })
            };
        }
    });

    GmailUpload.TableView = Backbone.Layout.extend({
        template: "common/gmail/gmailuploadtable",
        initialize: function(){
            var self = this;
            this.userEmail = app.user.get("emailAddress");
            this.headers = [{name: "from", label: "From"}, {name: "subject", label: "Subject"}, {name: "snippet", label: "Snippet"}, {name: "received", label: "Received"}];
            this.prevSelectedThreads = this.options.prevSelectedThreads ? this.options.prevSelectedThreads : new Backbone.Collection();
            this.messageViews = [];
            this.hasResults = true;
            if(!this.model.get("threads").length){
                this.hasResults = false;
            }

            this.model.get("threads").each(function(thread){
                var isChecked = false;
                if(self.prevSelectedThreads.where({threadId: thread.get("threadId")}).length > 0){
                    isChecked = true;
                }
                var messageRow = new GmailUpload.MessageRow({
                    'attrs': self.headers,
                    'model': thread,
                    'isChecked': isChecked
                });
                self.messageViews.push(messageRow);
                self.insertView('.gmailtable-rows-outlet', messageRow).render();
            });

            this.listenTo(app, "gmailUpload:messageChecked", function(threadId){
                var threadModel = self.model.get("threads").where({'threadId': threadId});
                app.trigger("gmailUpload:addThreadModel", threadModel);
            });

            this.listenTo(app, "gmailUpload:messageUnChecked", function(threadId){
                var removeModel = self.model.get("threads").where({'threadId': threadId});
                app.trigger("gmailUpload:removeThreadModel", removeModel);
            });
        },
        afterRender: function(){
            app.trigger("gmailUpload:stopSpinner");
            app.trigger("gmailUpload:validate");
        },
        serialize: function(){
            return {
                headers: this.headers,
                hasResults: this.hasResults
            };
        }
    });

    GmailUpload.MessageRow = Backbone.Layout.extend({
        tagName: 'tr',
        template: "common/gmail/gmailuploadrow",
        events: {
            "click .addGmailMessageCheckbox": "checkClicked"
        },
        initialize: function(){
            var self = this;
            this.attrs = this.options.attrs;
            //order is based off of the order of the attrs array
            this.serializedAttributes = [];
            _.each(this.attrs, function(attr){
                this.serializedAttributes.push(self.model.get(attr.name));
            }, this);
        },
        checkClicked: function(event){
            if($(event.target).attr("checked")){
                app.trigger("gmailUpload:messageChecked", $(event.target).attr("threadId"));
            }
            else{
                app.trigger("gmailUpload:messageUnChecked", $(event.target).attr("threadId"));
            }
        },
        serialize: function(){
            return {
                'attributes': this.serializedAttributes,
                'threadId': this.model.get("threadId"),
                'isChecked': this.options.isChecked
            };
        }
    });

    return GmailUpload;
});