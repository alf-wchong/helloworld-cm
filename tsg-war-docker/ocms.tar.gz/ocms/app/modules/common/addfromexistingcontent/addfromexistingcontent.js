// AddFromExistingContent module
define([
	// Application.
	"app",
	"modules/common/ocquery",
	"module"
],

// Map dependencies from above array.
function(app, Ocquery, module) {
	"use strict";

	var AddFromExistingContent = app.module();

	AddFromExistingContent.SearchView = Backbone.View.extend({
		template: "common/addfromexistingcontent/searchview",
		events: {
			"click #addfromexisting-search-btn": "search",
			"keyup #addfromexisting-search-input": "validate"
		},
		initialize: function(){
			this.objectTypes = [];
			this.templates = {};

			this.resetQuery();
		},
		resetQuery: function(){
			this.query = new Ocquery.Collection();

			this.query.state.pageSize = 5000;

			this.query.searchParameters = module.config().searchConfig || 	[
				{
					paramType: "property",
					paramName: "objectName",
					paramValue: "none",
					operator: "LOGIC_LIKE",
					andOr: " and "
				},
				{
					logic: " and ",
					paramName: "Document",
					paramType: "type",
					paramValue: "Document",
					relatedObjectOperator: null
				}
			];

			if(this.oldSearchValue){
				this.validate();
			}
		},
		search: function(event){
			var self = this;

			this.query.fetch({
				global: false,
				success: function(resp){
					var jqxhrArray = [];

					//we could have some dates we want to show, run all of the oco's throught the formatter
					_.each(self.query.models, function(oco){
						var indJqxhr = oco.formatPropertiesReadOnly();
						jqxhrArray.push(indJqxhr);
					});

					$.when.apply(null, jqxhrArray).done(function(){
						self.setView("#addfromexisting-table-area", new AddFromExistingContent.ResultsListView({collection: self.query})).render();
						self.resetQuery();
					});
				}
			});			
		},
		addParamValue: function(){
			var self = this;
			_.each(this.query.searchParameters, function(object){
				if(object.paramValue === self.oldSearchValue || object.paramValue === ""){
					object.paramValue = self.$("#addfromexisting-search-input").val();
				}
			});
			this.oldSearchValue = this.$("#addfromexisting-search-input").val();
		},
		validate: function(event){
			if(this.$("#addfromexisting-search-input").val().length > 2){
				this.addParamValue();

				this.$("#addfromexisting-search-btn").prop("disabled", false);
				this.$(".addfromexisting-smallFont").hide();

				if(event){
					this.checkEnter(event);
				}
			}
			else{
				this.$("#addfromexisting-search-btn").prop("disabled", true);
				this.$(".addfromexisting-smallFont").show();
			}
		},
		checkEnter: function(event){
			if(event.keyCode === 13){
				this.search();
			}
		},
		afterRender: function(){
			$(".dropZone").hide();
			$(".addDocButton").hide();
			$(".templateDocButton").hide();
		}
	});

	AddFromExistingContent.ResultsListView = Backbone.Layout.extend({
		template: "common/addfromexistingcontent/resultslistview",
		events: {
			"click .addExistingDocLink": "addExistingToList"
		},
		initialize: function(){
			var self = this;
			this.resultDocs = this.options.collection;

			var compare = function(a, b){
				if(a.get('properties').objectName < b.get('properties').objectName){
					return -1;
				}
				else{
					return 1;
				}
				return 0;
			};

			this.tableHeaders = module.config().attributes || [
				{
					'displayName': 'Name',
					'ocoName': 'objectName',
					'createLink': true
				},
				{
					'displayName': 'Title',
					'ocoName': 'title'
				},
				{
					'displayName': 'Version',
					'ocoName': 'versionLabel'
				}
			];

			this.resultDocs.models.sort(compare);

			// parse the collection adding necessary attributes
			_.each(this.resultDocs.models, function(model){
				model.name = model.get("properties").objectName;
				model.existingRepoId = model.get("objectId");
				model.isAddingFromExistingContent = true;
			});

			if(this.resultDocs.length > 0){
				this.hasResults = true;
			}

			this.listenTo(app, "addingFromExistingContent:fileRemoved", function(model){
				var tableRows = $(".hiddenId");
				_.each(tableRows, function(element){
					if($(element).attr("value") === model[0].get("objectId")){
						$(element.parentElement.parentElement).removeClass("tableHidden");
						$(element).removeClass("hiddenId");
					}
				});
			});

			this.listenTo(app, "addingFromExistingContent:renderTable", function(){
				$($(".addFromExisitingContent-table").children()).remove();
				_.each(self.resultDocs.models, function(model){
					self.insertView('.addFromExisitingContent-table', new AddFromExistingContent.DocumentRow({
						'attrs': self.tableHeaders,
						'model': model
					})).render();
				});
			});
		},
		addExistingToList: function(event){
			event.stopPropagation();
			var selectedModels = [];
			var objectId = $(event.target).attr("value");
			if(!objectId){
				objectId = $(event.target.parentElement).attr("value");
			}

			selectedModels = this.resultDocs.where({objectId: objectId});

			app.trigger('bulkupload:filesUploaded', selectedModels);

			var tableRows = $(".addExistingDocLink");
			_.each(tableRows, function(element){
				if($(element).attr("value") === objectId){
					$(element.parentElement.parentElement).addClass("tableHidden");
					$(element).addClass("hiddenId");
				}
			});
		},
		afterRender: function(){
			if(this.hasResults){
				app.trigger("addingFromExistingContent:renderTable");
			}
		},
		serialize: function(){
			return {
				hasResults: this.hasResults,
				tableHeaders: this.tableHeaders
			};
		}
	});

	AddFromExistingContent.DocumentRow = Backbone.Layout.extend({
		tagName: 'tr',
		template: 'common/addfromexistingcontent/documentrow',
		events: {
			'click .addDocCheckbox': 'validate'
		},
		initialize: function(){
			var self = this;
			this.model = this.options.model;
			this.attrs = this.options.attrs;
			//order is based off of the order of the attrs array
			this.serializedAttributes = [];
			_.each(this.attrs, function(attr){
				if(attr.createLink){
					this.serializedAttributes.push({name: self.model.get('properties')[attr.ocoName], isLink: true, objectId: self.model.get('objectId')});
				}else{
					this.serializedAttributes.push({name: self.model.get('properties')[attr.ocoName], isLink: false});
				}
			}, this);
		},
		serialize: function(){
			return {
				'attributes': this.serializedAttributes
			};
		}
	});

	app.log.debug("Add Doc From Existing Content Module Initialized");

	return AddFromExistingContent;
});