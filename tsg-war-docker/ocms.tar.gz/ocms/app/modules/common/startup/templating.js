define([
    "backbone",
    "jquery",
    "handlebars"
    
], function(Backbone, $, Handlebars) {

    var prefix = "app/templates/";
    var fileExtension = ".html";

    var JST = window.JST || {};

    /**
     * The Templating module is responsible for loading templates, compiling if necessary, 
     * and setting them up inside our view engines.
     * 
     * The two scenarios that these methods support are:
     *   1) Compiling templates from scratch, which look like this
     *      <div id={{some-replace-stuff}}>Hardcoded Text</div>
     *   2) Rendering precompiled templates, via the JST require code in this module.
     * 
     * This module currently supports setting up both the legacy 
     * Backbone.Layout and the more modern Backbone.Marionette templates
     */
    var Templating = {};
    
    Templating.init = function() {
        
        Backbone.Layout.configure({
            manage: true,
            fetchTemplate: function(name) {
                
                var path = prefix + name + fileExtension;
        
                if(!JST[path]) {
                    $.ajax({
                        type: "GET",
                        url: path,
                        async: false,
                        global: false, // do not grey out screen for these requests
                        success: function(html) {
                            JST[path] = Handlebars.compile(html);
                            JST[path].__compiled__ = true;
                        }
                    });
                }

                if(JST[path].__compiled__) {
                    return JST[path];
                }
                return Handlebars.template(JST[path]);
            }
        });

        Backbone.Marionette.TemplateCache.prototype.loadTemplate = function(name) {
            
            var path = prefix + name + fileExtension;

            if(!JST[path]) {
                $.ajax({
                    type: "GET",
                    url: path,
                    async: false,
                    global: false, //do not grey out screen for these requests
                    success: function(html) {
                        JST[path] = html;
                    }
                });
            }

            return JST[path];
        };

        Backbone.Marionette.TemplateCache.prototype.compileTemplate = function(html) {
            if(typeof html === "object") {
                return Handlebars.template(html);
            }
            return Handlebars.compile(html);
            
        };
    }

    return Templating;
});