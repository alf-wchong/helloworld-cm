define([
    "app",
    "handlebars"
],
function(app, Handlebars) {
    "use strict";

    var HandlebarsService = app.module();

    HandlebarsService.registerHelpers = function(){
      
        Handlebars.registerHelper('ifEquals', function(v1, v2, options) {
            // If they are equal, proceed with the html contained in the handlebars syntax, otherwise proceed with the else block if provided
            return v1 === v2 ? options.fn(this) : options.inverse(this);
        });
        
        //This helper determines what value should be selected in the picklist
        //dropdown for each attribute
        Handlebars.registerHelper("setSelectedOption", function(options) {
            //options.hash.picklist is the value of picklist on the current model
            //options.hash.currentOption is the value of the current option from the
            //template
            //if this matches the model's picklist, then we should return selected
            if (options.hash.selectedPicklist === options.hash.currentOption) {
                return "selected";
            } else {
                return "";
            }
        });

        // A helper to color code the display times.
        Handlebars.registerHelper('timeColor', function(time, timeCompare1, timeCompare2){
            if(time <= timeCompare1) {
                return '#28a745';
            } else if(time <= timeCompare2) {
                return '#ffc107';
            } else {
                return '#dc3545';
            }
        });

        Handlebars.registerHelper('orArguments', function() {
            var criteriaObjects = _.initial(arguments);
            var handlebarsOpts = arguments[arguments.length - 1];
            var result = _.reduce(
                    criteriaObjects, 
                    function(memo, arg) {
                        return memo || arg;
                    }, 
                    false);

            if(result) {
                handlebarsOpts.fn(this);
            } else {
                handlebarsOpts.reverse(this);
            }

        });

        //Concatinates together all arguments given except the last one
        //Which is the context in which the function is called
        Handlebars.registerHelper('concatArguments', function() {
            var argsToAdd = _.initial(arguments);
            var result = _.reduce(
                    argsToAdd, 
                    function(memo, arg) {
                        return memo + arg;
                    }, 
                    '');

            return result;

        });
        
        // the combination of anchor tag click listeners in backbone and
        // using this helper can help prevent click events from firing
        // when app.replaceAnchorTags is true.
        // See BulkUpload.Results for an example
        Handlebars.registerHelper('dynamicOcmsAnchorTag', function() {
            if (app.replaceAnchorTags) {
                return "span";
            }
            return "a";
        });

    };
    return HandlebarsService;
});