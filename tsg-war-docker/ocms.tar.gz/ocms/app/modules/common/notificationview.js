// Repotype module
define([
	"app",
	"modules/common/notification"
],

function(app, Notification) {

	var NotificationView = app.module();
	
	NotificationView.filterDebounceTime = 400;
	// LAYOUT VIEW - This is the main view that holds both the controls view and the
	// collection view containing the users notifications (this should only render once)
	// NOTE: this view is used for both the dashlet and the custom alert modal
	NotificationView.Views.Layout = Backbone.Marionette.LayoutView.extend({
		template: "common/notificationview",
		ui: {
			archiveTab: "#archiveTab",
			currentTab: "#currentTab",
		},
		events: {
			"click @ui.archiveTab": "showArchived",
			"click @ui.currentTab": "showCurrent",
		},
		childEvents: {
			"render:collection": "renderCollection"
		},
		regions: {
			notificationTable: ".notification-table",
			notificationControls: "#notificationControls"
	    },
		initialize: function() {
			this.notificationCollection = this.options.notifications;
			this.isDashlet = false;
			this.dashletName = "";
			// we are only passed a config if we are loading the dashlet 
			// we need to create / fetch the collection in this case
			if (this.config) {
				this.setupDashlet();
			} else {
				this.setupViews();
			}
		},
		setupDashlet: function () {
			this.isDashlet = true;
			this.dashletName = this.config.get("dashletName");
			this.notificationCollection = new Notification.Collection();
			this.notificationCollection.fetch({ 
				getCurrent: true,
				context: this
			}).done(this.setupViews);
		},
		setupViews: function () {
			this.notificationControlView = new NotificationView.NotificationControlsView({ collection: this.notificationCollection});
			this.currentNotificationView = new NotificationView.CollectionView({ collection: this.notificationCollection });
			this.render();
		},
		renderCollection: function () {
			// Here we reset the region (which destroys our notification view and removes cached el) 
			// set the filterQuery, render the view, and show the region
			this.getRegion("notificationTable").reset();
			this.currentNotificationView = new NotificationView.CollectionView({collection: this.notificationCollection});
			this.getRegion("notificationTable").show(this.currentNotificationView);
		},
		afterRender: function() {
			if (this.notificationControlView) {
				this.getRegion("notificationControls").show(this.notificationControlView);
			}
			if (this.currentNotificationView) {
				this.getRegion("notificationTable").show(this.currentNotificationView);
			}
		}, 
		serialize: function() {
            return {
				"isDashlet" : this.isDashlet,
				"dashletName" : this.dashletName
            };
		},
		showArchived : function() {
			// calls model.fetch (see notification.js) with getCurrent set to false
			if ($(this.ui.currentTab).hasClass("active")) {
				this.notificationCollection.filterQuery = "";
				this.notificationCollection.sortKey = "dateSent";
			}
			this.notificationCollection.fetch({getCurrent: false, context: this}).done( this.renderCollection );
		},
		showCurrent : function() {
			// calls model.fetch (see notification.js) with getCurrent set to true
			if ($(this.ui.archiveTab).hasClass("active")) {
				this.notificationCollection.filterQuery = "";
				this.notificationCollection.sortKey = "dateSent";
			}
			this.notificationCollection.fetch({getCurrent: true, context: this}).done( this.renderCollection );
		}
	});
	
	// CONTROLS VIEW - this contains the tabs / filtering / sorting logic for the notification view
	NotificationView.NotificationControlsView = Backbone.Marionette.ItemView.extend({
		template: "common/notificationControls",
		ui: {
			sortAttribute: "#sortAttr",
			sortButton: "#sortBtn",
			sortOrder: "#sortOrder",
			notificationFilter: "#notificationFilter"
		},
		events: {
			"click @ui.sortButton" : "toggleSortOrder",
			"change @ui.sortAttribute" : "updateSort",
			"keyup @ui.notificationFilter": "filterResults"
		},
		initialize: function() {		
			this.notifications = this.options.collection;
			this.numCurrentNotifications = this.notifications.length;
			this.sortAttributes = {};
			this.updateSortAttributes();
			this.listenTo(this.notifications, "remove sync", this.updateSortAttributes);
		},
		serialize : function () {
			return {
				"sortAttributes" : this.sortAttributes,
				"numCurrentNotifications" :this.numCurrentNotifications,
				"isCurrent": this.notifications.isCurrent,
				"numNotifications": this.notifications.length
			};
		},
		afterRender: function () {
			$(this.ui.notificationFilter).val(this.notifications.filterQuery);
			$(this.ui.sortAttribute).val(this.notifications.sortKey);
		},
		updateSort: function (ev) {
			// update the sort key, sort and re render the notification view
			var selectedAttr = ev.target.value;
			this.notifications.sortKey = selectedAttr;
			this.notifications.sort();
			this.triggerMethod("render:collection");
		},
		toggleSortOrder: function() {
			// flip the sort direction, sort the collection, then re render the notification view
			this.notifications.reverseSortDirection = !this.notifications.reverseSortDirection;
			// for some reason the marionette UI hash does not properly select this when 
			// there is a dashlet behind a modal for the view - for now just passing in the el 
			// to the jquery selector. note: this is bad - should be using this.ui
			$('#sortOrder', this.el).toggleClass("glyphicon-chevron-up glyphicon-chevron-down");
			this.notifications.sort();
			this.triggerMethod("render:collection");
		},
		filterResults: _.debounce(function() {
			// for some reason the marionette UI hash does not properly select this when 
			// there is a dashlet behind a modal for the view - for now just passing in the el 
			// to the jquery selector. note: this is bad - should be using this.ui
			this.filterQuery = $('#notificationFilter', this.el).val().toLowerCase();
			this.notifications.filterQuery = this.filterQuery;
			this.triggerMethod("render:collection");
		}, NotificationView.filterDebounceTime),
		updateSortAttributes: function () {
			this.sortAttributes = {};
			// we are only updating the notification count for current notifications
			if (this.notifications.isCurrent) {
				this.numCurrentNotifications = this.notifications.length;
			}

			this.notifications.each(function (notification) {
				var extraProps = notification.get("extraNotificationProps");
				// Add all extra properties to our sort attributes object - default values are already included in the select
				_.each(extraProps, function(extraProp) {
					this.sortAttributes[extraProp.ocName] = extraProp.label;
				}, this);
			}, this);

			this.render();
		}
	});

	// COLLECTION VIEW - this view is a collection of each notification view 
	// its main functionality is to handle the filtering logic
	NotificationView.CollectionView = Backbone.Marionette.CollectionView.extend({
		childView: Notification.View,
		manage: false,
		tagName: "tbody",
		initialize: function () {
			if (!this.collection.filterQuery) {
				this.collection.filterQuery = "";
			}
		},
		filter: function (child) {
			// using Marionettes built in filter, which handles rendering of the collection automatically 
			var attrsToSearch = child.pick("senderUserName","dateSent","message","attachedObjectName");

			_.each(child.get("extraNotificationProps"), function (extraProp) {
				attrsToSearch[extraProp.ocName] = extraProp.value;
			}, this);
			
			// using _.some helper - this will look through all the filterable attributes of the model
			// and render the view if any of its attribute values match the users filter
			return _.some(_.values(attrsToSearch), function(attr) {
				return !attr ? false : attr.toString().toLowerCase().indexOf(this.collection.filterQuery) !== -1;
			}, this);
		}
	});

	return NotificationView;

});
