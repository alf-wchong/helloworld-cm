// Action Service module
define([
	// Application.
	"app",
	"modules/common/action", 
	"modules/stage/folderactionseventmanager",
	"URIjs/URI",
	"modules/services/logstashservice",
	"modules/common/hpiconstants"
],

// Map dependencies from above array.
function(app, Action, FolderActionsEventManager, URI, LogstashService, HPIConstants) {
	'use strict';

	var ActionService = app.module();

	//Service model that handles action logic
	ActionService.ActionLauncher = Backbone.Model.extend({
		initialize: function(){
			this._stopListening();
			//initialize the uri without the window origin (e.g. http://edge2.tsgrp.com) and app.root (e.g. /hpi/)
			var newUri = window.location.href.replace(window.location.origin, "").substring(app.root.length);
			//if the application would always get inputs correctly, we wouldn't need this, but this is protecting us against
			//people configuring the app wrong (URI needs a leading slash)
			if (newUri[0] !== "/") {
				newUri = "/" + newUri;
			}
			this.uri = new URI(newUri);
			this.configuredAutoLaunch = { actionModel: null, config: null, canAutoLaunch: true};
			this.directLaunchAction = { id: this.getURIQueryParam(this.uri, "folderActionId"), actionModel: null, config: null };
			this.showDualPane = this.getURIQueryParam(this.uri, "showDualPane") === "true";
			this.launchedAction = { id: null, actionName: null };
			this.rsahHasLaunched = false;
		},
		getLaunchedActionId: function(){
			return this.launchedAction.id;
		},
		_startListening: function(){
			// When modal closed, launch autolaunch if no action previously fired, or trigger "click"
			FolderActionsEventManager.listenTo(app.modalActionHandler, 'hide', _.bind(this.hideModalActionHandler, this));

			// If previousActionClosed flag is true and neither docViewer pane is open, fire our autoLaunch
			FolderActionsEventManager.listenTo(app.rightSideActionHandler, 'hide', _.bind(this.hideRightSideActionHandler, this));

			// If docViewer is closed and not action is currently open, fire our autoLaunch
			FolderActionsEventManager.listenTo(app, 'pane1:manually:closed', _.bind(this.manuallyClosePane1, this));

			// Called when RSAH is the final remaining pane
			FolderActionsEventManager.listenTo(app, 'pane3:manually:closed', _.bind(this.launchActionHelper, this));

			// remove the docId from the url
			FolderActionsEventManager.listenTo(app, 'actionService:removeDocId', _.bind(this.removeDocId, this));

			// listener to update the uri on the action service model
			this.listenTo(app, 'actionService:updateURI', this.updateURI);
		},
		_stopListening: function(){
			FolderActionsEventManager.stopListening();
			this.stopListening();
		},
		hideModalActionHandler: function() {
			var docViewerPanesOpen = $("#pane1").is(':visible') || $("#pane2").is(':visible');
			if (!docViewerPanesOpen && !this.rsahHasLaunched){
				this.launchAction(this.configuredAutoLaunch.actionModel, this.configuredAutoLaunch.config);
			} else {
				FolderActionsEventManager.trigger("folderactions:action:click");
			}
			FolderActionsEventManager.trigger('autoLaunch');
		},
		hideRightSideActionHandler: function(previousActionClosed) {
			var docViewerPanesOpen = $("#pane1").is(':visible') || $("#pane2").is(':visible');
			if (previousActionClosed && !docViewerPanesOpen){
				this.launchActionHelper();
			}
		},
		manuallyClosePane1: function() {
			if (!$("#pane3").is(':visible')){
				this.launchActionHelper();
			}
		},
		launchActionHelper: function() {
			this.launchAction(this.configuredAutoLaunch.actionModel, this.configuredAutoLaunch.config);
			FolderActionsEventManager.trigger('autoLaunch');
		},
		removeDocId: function() {
			this.uri.href(window.location.href);
			var path = decodeURIComponent(this.uri.path().substring(app.root.length-1, this.uri.path().length));
			var indexOfBar = path.indexOf('|');
            if(indexOfBar !== -1) {
                path = path.substring(0, indexOfBar) + "?folderActionId=viewAllDocuments";
				Backbone.history.navigate(path, {replace: true});
				this.uri.href(path);
            }
		},
		//Helper method to retrieve a given uri query param, or null if not in url
		getURIQueryParam: function(uri, paramName) {
			return uri.getParameter(paramName);
		},
		updateUriHistory: function(uri) {
			//This function will update the URI with the actionId of the launched action 
			//as well as update the history with the updated actionId
			var directLaunchActionId = this.getURIQueryParam(uri, "folderActionId");
			//Update url if launchedAction id doesn't match uri's actionId
			if(this.launchedAction.id !== directLaunchActionId){
				uri.setSearch("folderActionId", this.launchedAction.id);
			}

			// remove the showDualPane param on launched action change
			if(this.launchedAction.id !== "viewAllDocuments") {
				uri.removeSearch("showDualPane");
				this.showDualPane = false;
			}
			
			var path = uri.path();
			//Get path minus the app.root
			if(path.indexOf(app.root) !== -1) {
				path = uri.path().substring(app.root.length - 1, uri.path().length);
			}

			//Either replaceState in history if autoLaunch or directLaunch
			//otherwise, pushState in history
			var replace = directLaunchActionId === null || directLaunchActionId === this.launchedAction.id;
			var newURI = path + "?" + uri.query();

			Backbone.history.navigate(newURI, {trigger: false, replace: replace});

			// update the model uri to the uri we navigated to
			this.updateURI(newURI);
			
			//Update page title with launchedAction's name
			var hyphenIndex = document.title.indexOf('-');
			if(hyphenIndex > -1) {
				document.title = document.title.substring(0, hyphenIndex - 1);
			} 
			document.title += " - " + this.launchedAction.actionName;
		},
		updateURI: function(newURI) {
			this.uri = new URI(newURI);
		},
		getAvailableActions: function(config, objectId) {
			//Takes config and objectId from requesting context (FolderActions, DocViewer)
			//Filters out applicable actions based on condition evaluators
			//Configures autoLaunch (if applicable) and triggers autoLaunch or directLaunch (if applicable)
			//Returns deferred that resolves with Action.Collection containing valid actions for context
			var deferred = $.Deferred();
			var actionCollection = new Action.Collection(config.get("actions").models);
			actionCollection.objectId = objectId;
			actionCollection.configs = [];
			actionCollection.fetch({
				success: _.bind(function(data) {
					// if the directLaunchAction.id (the url param for the action to launch) is not a valid actionId, reset the directLaunchAction.id
					var availableActionIds = _.map(data.models, function(action){
						return action.get('actionId');
					});
					if (!_.contains(availableActionIds, this.directLaunchAction.id)){
						this.directLaunchAction.id = null;
					}
					//Run actions through filter
					Action.filterActions(data, config);
					_.each(data.models, function(model){
						var actionsConfig = config.get("actions").findWhere({actionId : model.get("actionId")} );
						actionCollection.configs.push(actionsConfig);
						//If current actionModel's ID matches that of supplied directLaunch,
						//Set this actionModel as directLaunch's actionModel
						if(this.directLaunchAction.id === model.get("actionId")){
							this.directLaunchAction.actionModel = model;
							this.directLaunchAction.config = actionsConfig;
						}

						// Launch a dual pane docviewer and view all docs
						if (this.launchedAction.id === null && this.directLaunchAction.actionModel !== null && this.directLaunchAction.id === "viewAllDocuments" &&
							this.showDualPane && !_.isUndefined(app.context.document.get("objectId"))) {
								//Prevent other actions passing through this instance from being set as autoLaunch 
								this.configuredAutoLaunch.canAutoLaunch = false;
								//Set this actionModel as the autoLaunch action
								this.configuredAutoLaunch.actionModel = model;
								this.configuredAutoLaunch.config = actionsConfig;
								this._startListening();
								this.launchDualPane();
						} else {
							//Check if autoLaunch is enabled for this action and we have not configured auto launch yet
							if(actionsConfig.get("autoLaunch") === "true" && this.configuredAutoLaunch.canAutoLaunch){
								//Prevent other actions passing through this instance from being set as autoLaunch 
								this.configuredAutoLaunch.canAutoLaunch = false;
								//Set this actionModel as the autoLaunch action
								this.configuredAutoLaunch.actionModel = model;
								this.configuredAutoLaunch.config = actionsConfig;
								this._startListening();
								//Launch the autoLaunch action if objectId is not a document in docViewer, no directLaunch id was provided, and an autoLaunch action has been set 
								if(!app.context.document.get("objectId") && this.directLaunchAction.id === null && this.configuredAutoLaunch.actionModel !== null){
									this.launchAction(this.configuredAutoLaunch.actionModel, this.configuredAutoLaunch.config);
								}
							}
							//Launch directLaunch action if objectId is not a document in docViewer and a directLaunch action has been set
							if(!app.context.document.get("objectId") && this.directLaunchAction.actionModel !== null && this.launchedAction.id === null){
								this.launchAction(this.directLaunchAction.actionModel, this.directLaunchAction.config);	
							}
						}
					}, this);
					//Did we launch an action? Do we have autoLaunch enabled? If so, fire off autoLaunch
					//We must not have access to the directLaunch action in the url
					if(!app.context.document.get("objectId") && this.launchedAction.id === null && this.configuredAutoLaunch.actionModel !== null){
						this.launchAction(this.configuredAutoLaunch.actionModel, this.configuredAutoLaunch.config);		
					}

					//Once all actions have been processed, resolve deferred w/actionCollection
					deferred.resolve(actionCollection);
				}, this),
				error: _.bind(function() {
					app.log.error("Failed to get folder actions");
		            actionCollection.reset();
		        }, this),
		        global: false
			});

			return deferred.promise();
		},
		launchDualPane: function() {
			// open view all documents
			this.launchAction(this.directLaunchAction.actionModel, this.directLaunchAction.config, this.showDualPane);
			// open the doc
			app.trigger("stage.refresh.documentId2", {
				objectId: app.context.document.get("objectId"),
				context: "viewAllDocuments"
			}); 
			// make sure the left bar is closed
			app.trigger("toggleLeftBar", false);
			this.updateUriHistory(this.uri);
		},
		launchAction: function(action, config, withDualPane){
			//store and log the action init time
			action.set("startTime", Date.now());
			LogstashService.sendMetrics(
				new LogstashService.PerformanceLog({
					'eventTitle': HPIConstants.Logging.Events.LaunchAction + "-Init",
					'events' : {
						'action': action.get("name")
					}
				})
			);

			//Launch the given action with the appropriate handler
			app[config.get("handler")].trigger("show", {
				action: action,
				config: config,
				showDualPane: withDualPane
			});

			//Trigger FolderActions Layout listener to update Action views
			FolderActionsEventManager.trigger("folderactions:action:click");

			if(config.get("handler") === "rightSideActionHandler"){
				// If action is full pane, remove any doc id from the uri
				if (!withDualPane && config.get("paneSize") === "fullPane") {
					this.removeDocId();
				} else {
					// If action is right pane, ensure the doc id is in
					// uri if there's a document open in the docviewer
					this.uri.href(window.location.href);
				}
				this.rsahHasLaunched = true;
				//Store given actionId and name as the launchedAction
				this.launchedAction.id = config.get("actionId");
				this.launchedAction.actionName = config.get("label");
				//Update url and history
				this.updateUriHistory(this.uri);
			}
		},
		cleanup: function(){
			this._stopListening();
		}		
	});

	return ActionService;
});