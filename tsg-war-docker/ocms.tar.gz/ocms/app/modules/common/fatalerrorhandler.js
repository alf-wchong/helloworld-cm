define([
        "app"
    ],

    function(app) {
        var FatalErrorHandler =  {}; 

        FatalErrorHandler.View = Backbone.Layout.extend({
            template: "common/fatalerrorhandler",
            events:{
                'click #logoutBtn': 'logout',
                'click #adminBtn': 'adminPageLoad',
                "click #license-submit" : "submitLicense"

            },
            initialize: function(options) {
                var self = this;
                this.isUserAdmin = false;

                this.showLogout = app.enableSSO ? false: true;

                this.mode = (options.mode === undefined ? "" : options.mode);

                //take in the errorMessage off of options, if undefined localize generic error instead
                this.errorMessage = (options.errorMessage === undefined ? window.localize("generic.errorMessage") : options.errorMessage);
                
                //trac or config error, check to see if user is admin and display the passed-in message
                if(this.mode === "general") {
                    this.isAdmin(options);
                }
                //invalid license error, display license upload page
                else if(this.mode === "licenseError") {
                    this.licenseUploadError = false;
                }
                //if we can't connect to OC, nothing for a potential admin to do, so display message
                else if(this.mode === "connectError") {
                    this.showLogout = false;
                    self.render();
                }
            },
            submitLicense: function(evt) {
                //user clicked the submit button for the license page
                evt.preventDefault();
                //get the floating and text license from the form
                var floatingLicense = $("#login-license-floating").val();
                var textLicense = $("#login-license-text").val();
                
                var self = this;
                var submitUrl = app.serviceUrlRoot + "/license/validateLicense";
    
                //send license data to OC REST endpoint and get back success or failure
                Backbone.ajax({
                    url: submitUrl,
                    data: {
                        floatingLicense: floatingLicense, 
                        textLicense: textLicense,
                        isAdminUpload: false
                    },
                    type: "POST",
                    success: function() {
                        //refresh - navigate to login page
                        Backbone.history.navigate("");
                        app.routers.main.index(false, true);
                        
                    },
                    error: function() {
                        //display error message and allow for user to resubmit license 
                        self.licenseUploadError = true;
                        self.render();
                    },
                    async: false
                });
            },
            isAdmin: function(options) {
                var self = this;
                //if currentApplicationConfig is not undefined, this means that there are groups that 
                //populated and we can access them to tell if the user is an admin
                var adminGroupsFromAppConfig = app.context.currentApplicationConfig().get("adminGroups").pluck("name");
                if (adminGroupsFromAppConfig.length > 0) {
                    //if there are any intersections between the groups the user is in and the admin group
                    //return true for that user
                    self.isUserAdmin = !_.isEmpty(_.intersection(adminGroupsFromAppConfig, app.user.get("groupNames")));
                } else {
                    //once the groups have been collected, the inner if statement checks if it is not empty.
                    if (app.user.get("groupNames")) {
                        if (!_.isEmpty(app.user.get("groupNames"))){
                            //if there are groups check, if there is a default admin group
                            //base the isUserAdmin variable off of that default
                            self.isUserAdmin = options && _.contains(app.user.get("groupNames"), app.defaultAdminGroup);
                        } else{
                            //if there are no groups return false and do not allow the individual any further
                            self.isUserAdmin = false;
                        }
                    } else {
                        var dfd = $.Deferred();
                        $.when(app.user.getGroups(dfd)).done(function(){
                            if (!_.isEmpty(app.user.get("groupNames"))){
                                //if there are groups check, if there is a default admin group
                                //base the isUserAdmin variable off of that default
                                self.isUserAdmin = options && _.contains(app.user.get("groupNames"), app.defaultAdminGroup);
                            } else{
                                //if there are no groups return false and do not allow the individual any further
                                self.isUserAdmin = false;
                            }
                            //we need to render the page when the get groups is done, or else the
                            //page could render before the groups are collected
                            self.render();
                        });
                    }
                }
            }, 
            serialize: function() {
                return {
                    licenseMode: (this.mode === "licenseError"),
                    licenseError: this.licenseUploadError,
                    errorMessage: this.errorMessage,
                    isAdmin: this.isUserAdmin,
                    showLogout: this.showLogout
                };
            },
            logout: function() {
                Backbone.history.navigate("/logout", {trigger: true});
            },
            adminPageLoad: function(){
                Backbone.history.navigate("/admin", {trigger: true});
            }
        });
    return FatalErrorHandler;
    }
);