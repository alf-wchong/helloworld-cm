// Ocquery module
define([
	// Application.
	"app",
	"moment",
	"knockback",
	"knockout",

	"oc"
],

// Map dependencies from above array.
function (app, moment, kb, ko, OC) {

	// Create a new module.
	var Workflow = app.module();


	/////////////// WORKFLOW TASKS ///////////////
	Workflow.OCTask = Backbone.Model.extend({
		defaults: function(){
			return {
				"assignedDate": "",
				"assignee": "",
				"name": "",
				"id": "",
				"candidateGroups": [],
				"assigneeDisplayName": ""
			};
		},
		url: function () {
			return app.serviceUrlRoot + "/workflow/gettask?taskId=" + this.id;
		},
		idAttribute: "taskId"
	});
	//Task Model
	Workflow.TaskModel = Backbone.RelationalModel.extend({
		initialize: function (model, options) {
			app.log.warn("TaskModel is deprecated. Please use OCTask");
			var self = this;

			if (options && options.taskId) {
				self.id = options.taskId;
			}
		},
		url: function () {
			return app.serviceUrlRoot + "/workflow/gettask?taskId=" + this.id;
		}
	});

	//Unclaimed Task Group Model
	Workflow.UnclaimedTaskGroupModel = Backbone.RelationalModel.extend({
		relations: [
			{
				type: Backbone.HasMany,
				key: 'unclaimedTasks',
				relatedModel: Workflow.TaskModel
			}
		],
		defaults: function () {
			return {
				"group": "",
				"unclaimedTasks": new Workflow.TaskModel()
			};
		}
	});


	//Collection of individual and claimed tasks
	Workflow.UserTaskCollection = Backbone.Collection.extend({
		model: Workflow.TaskModel,
		initialize: function(models, options) {
			var self = this;
			this.attrToShow = (options && options.attrToShow ? options.attrToShow : "");

			//Grab application config date format chosen
			app.context.dateService.getDateFormat().done(function(dateFormat){
                self.dateFormat = dateFormat;
			});
		},
		url: function () {
			return app.serviceUrlRoot + "/workflow/gettasks?userLoginName=" + app.user.get("loginName");
		},
		parse: function (response) {
			var self = this;

			//The response is just a list of tasks. We need to parse their dates correctly
			var collection = [];

			_.each(response, function (task) {
				//Format the task assigned date
				task.assignedDate = task.assignedDate && Workflow.formatTaskDate(task.assignedDate, self.dateFormat);
				task.workflowDueDate = (task.workflowDueDate ? Workflow.formatTaskDate(task.workflowDueDate, self.dateFormat) : "");

				// Extending task to include attrToShow
				task.attrToShow = self.attrToShow;

				collection.push(task);				
			});

			return collection;
		}
	});

	//Collection of groups that unclaimed tasks are assigned to
	Workflow.UnclaimedTaskGroupCollection = Backbone.Collection.extend({
		model: Workflow.UnclaimedTaskGroupModel,
		initialize: function(models, options) {
			var self = this;
			this.attrToShow = (options && options.attrToShow ? options.attrToShow : "");

			//Grab application config date format chosen
			app.context.dateService.getDateFormat().done(function(dateFormat){
                self.dateFormat = dateFormat;
			});
		},
		url: function () {
			//Get unclaimed tasks
			return app.serviceUrlRoot + "/workflow/getunclaimedtasks?userLoginName=" + app.user.get("loginName");
		},
		parse: function (response) {
			var self = this;

			//The response is just a list of tasks. We need to 'sort' them into their respective groups.
			var collection = [];

			//Keep a running list of groups we've already created UnclaimedTaskGroupModel for.
			var existingGroupsNames = [];

			_.each(response, function (task) {
				//Format the assigned date
				task.assignedDate = Workflow.formatTaskDate(task.assignedDate, self.dateFormat);
				task.workflowDueDate = (task.workflowDueDate ? Workflow.formatTaskDate(task.workflowDueDate, self.dateFormat) : "");
				
				// Extending task to include attrToShow
				task.attrToShow = self.attrToShow;

				var unclaimedTaskGroup;

				//Loop over the candidate groups for the task.
				_.each(task.candidateGroups, function (groupName) {

					if ($.inArray(groupName, existingGroupsNames) === -1) {
						//Create a new UnclaimedTaskGroupModel for each group if one hasn't been created yet and add the task.
						existingGroupsNames.push(groupName);
						unclaimedTaskGroup = new Workflow.UnclaimedTaskGroupModel({ "group": groupName, "unclaimedTasks": [task] });
						collection.push(unclaimedTaskGroup);
					}
					else {
						//Get the existing group and add the task.
						unclaimedTaskGroup = _.find(collection, function (group) {
							return group.get("group") === groupName;
						});
						unclaimedTaskGroup.get("unclaimedTasks").push(task, {merge: true});
					}
				});
			});

			return collection;
		}
	});


	Workflow.DefinitionModel = Backbone.Model.extend({
	});

	Workflow.DefinitionCollection = Backbone.Collection.extend({
		model : Workflow.DefinitionModel,
		url : app.serviceUrlRoot + "/workflow/workflowDefinitions"
	});

	/************Workflow ViewModels **********************/

	//View Model for a task
	Workflow.TaskViewModel = kb.ViewModel.extend({
		constructor: function (model, options) {

			var self = this;

			kb.ViewModel.prototype.constructor.call(this, model, options);

			self.numPackageItems = ko.observable();
			self.packageItems = ko.observable();
			self.packageItemIds = [];
			self.displayName = ko.observable();

			//Get the number of package items for the task
			var count = null;
			$.ajax({
				url: app.serviceUrlRoot + "/workflow/getworkflowpackage?taskId=" + self.id(),
				global: false,
				success: function(response) {
					if ( response.packageItemIds !== undefined && response.packageItemIds !== null ) {
						self.packageItemIds = response.packageItemIds;
						count = response.packageItemIds.length;
						self.packageItems(response.packageItems);
						if( response.packageItems[0].properties[self.attrToShow()]){
							self.displayName = response.packageItems[0].properties[self.attrToShow()];
						} else{
							self.displayName = response.packageItems[0].properties[app.objectDisplayName];
						}
					}
				},
				complete: function () {
					self.numPackageItems(count);
				}
			});

			self.claimTask = function (callback) {
				//Make sure the task is pooled and unclaimed.
				if (self.pooled() && self.assignee() === null) {
					$.ajax({
						url: app.serviceUrlRoot + "/workflow/acquiretask?taskId=" + self.id(),
						success: function () {
							callback();
						}
					});
				}
			};

			self.unclaimTask = function (callback) {
				//Make sure the task is pooled and claimed.
				if (self.pooled() && self.assignee() !== null) {
					$.ajax({
						url: app.serviceUrlRoot + "/workflow/releasetask?taskId=" + self.id(),
						success: function () {
							callback();
						}
					});
				}
			};

			self.cancelTask = function(callback) {
				$.ajax({
					type: "POST",
					url: app.serviceUrlRoot + "/workflow/cancelworkflow?taskId=" + self.id(),
					success: function() {
						callback();
					}
				});
			};

			//Set task status, i.e. 'Not Started,' 'In Progress,' etc.
			self.setTaskStatus = function (status) {
				$.ajax({
					type: "POST",
					url: app.serviceUrlRoot + "/workflow/settaskstatus?taskId=" + self.id() + "&status=" + status,
					contentType: 'application/json'
				});
			};

			//NOTE: props needs to be a properly formatted JSON object of props you want to set on the task
			self.completeTask = function (props, callback) {

				var completeTaskUrl = app.serviceUrlRoot + "/workflow/completetask?taskId=" + self.id();
				var completeTaskData = JSON.stringify(props);

				$.ajax({
					type: "POST",
					url: completeTaskUrl,
					data: completeTaskData,
					contentType: 'application/json',
					success: function () {
						callback();
					}
				});
			};

			return self;
		}
	});

	//Unclaimed Task Group View Model
	Workflow.UnclaimedTaskGroupViewModel = kb.ViewModel.extend({
		constructor: function (model) {
			this.group = kb.observable(model, "group");

			//Specify the view model for the unclaimedTasks collection
			this.unclaimedTasks = kb.collectionObservable(model.get("unclaimedTasks"), { view_model: Workflow.TaskViewModel });
		}
	});

	/////////////// WORKFLOW PACKAGES ///////////////
	//Package Item Collection of OC objects
	Workflow.PackageItemCollection = Backbone.Collection.extend({
		initialize: function (models, options) {
			//set any options needed here
			if(options && options.taskId){
				this.taskId = options.taskId;
			}		
		},
		model: OC.OpenContentObject,
		url: function () {
			//Return the url to get all package items for the specified task
			return app.serviceUrlRoot + "/workflow/getworkflowpackage?taskId=" + this.taskId;
		},
		parse: function (response) {
			//Return only the package item objects.
			return response.packageItems;
		}
	});

	//View Model for a single package item (package item is an OpenContentObject)
	Workflow.PackageItemViewModel = kb.ViewModel.extend({
		constructor: function (model, options) {

			var self = this;

			//TODO: update to only creating observables for props we actually need
			kb.ViewModel.prototype.constructor.call(this, model, options);

			var props = model.get("properties");
			self.uuid = props.objectId.replace(props['sys_store-protocol'] + '://' + props['sys_store-identifier'] + '/', '');

			self.smallThumb = ko.observable();
			self.mediumThumb = ko.observable();
			self.largeThumb = ko.observable();

			model.getThumbnail("small", function (thumbUrl) {
				self.smallThumb(thumbUrl);
			});
			model.getThumbnail("medium", function (thumbUrl) {
				self.mediumThumb(thumbUrl);
			});
			model.getThumbnail("large", function (thumbUrl) {
				self.largeThumb(thumbUrl);
			});

			return self;
		}
	});


	Workflow.OCTaskCollection = Backbone.Collection.extend({
		model: Workflow.OCTask
	});

	Workflow.WorkflowInstanceSnapshotModel = Backbone.Model.extend({
		defaults: function () {
			return {
				"workflowInitiator": "",
				"workflowDefinitionId": "",
				"formKey": "",
				"formName": "",
				"title" : "",
				"workflowPackage" : new Workflow.PackageItemCollection(),
				"currentTasks" : new Workflow.OCTaskCollection()
			};
		},

		initialize: function(model){
			if(model){
				if(model.workflowPackage){
					this.set("workflowPackage", new Workflow.PackageItemCollection(model.workflowPackage));
				} else {
					this.set("workflowPackage", new Workflow.PackageItemCollection());
				}
				if(model.currentTasks){
					this.set("currentTasks", new Workflow.OCTaskCollection(model.currentTasks));
				} else {
					this.set("currentTasks", new Workflow.OCTaskCollection());
				}
			}
		}
	});

	Workflow.WorkflowInstanceSnapshotCollection = Backbone.Collection.extend({
		model: Workflow.WorkflowInstanceSnapshotModel,
		initialize: function(models, options) {
			var self = this;
			self.groupName = (options === undefined || options.groupName === undefined ? "" : options.groupName);
			self.numPerPage = ((options === undefined || options.numPerPage === undefined || isNaN(options.numPerPage)) ? -1 : options.numPerPage);
            self.attrToShow = (options === undefined || options.attrToShow === undefined ? "" : options.attrToShow);
			
			//Grab application config date format chosen
			app.context.dateService.getDateFormat().done(function(dateFormat){
                self.dateFormat = dateFormat;
			});
		},
		url: function () {
			if (this.groupName !== "") {
				return app.serviceUrlRoot + "/workflow/getWorkflowInstanceSnapshotsByGroup?groups=" + this.groupName; 
			} else {
				return app.serviceUrlRoot + "/workflow/getWorkflowInstanceSnapshot?userLoginName=" + app.user.get("loginName") + "&numPerPage=" + this.numPerPage;
			}
		},
		comparator:function(left,right) {
			var leftTaskCollection = left.get("currentTasks");
			var leftFirstTaskObject = leftTaskCollection.models[0];
			var leftDate= new Date(leftFirstTaskObject.get("assignedDate"));

			var rightTaskCollection = right.get("currentTasks");
			var rightFirstTaskObject = rightTaskCollection.models[0];
			var rightDate= new Date(rightFirstTaskObject.get("assignedDate"));

			// sort workflow objects in descending order based on assignedDate
			if(leftDate>rightDate) {
				return -1;
			} else {
				return 1;
			}
		},
		toJSONObjectArray: function() {
			var self = this;

			var snapshots = [];
			_.each(this.models, function(snapshot){
				//object we are going to put our attrs on
				var workflowObject = {};
				var taskCollection = snapshot.get("currentTasks");
				//just showing first task, need to figure out showing
				//multiple tasks in an elegant way
				var firstTaskObject = taskCollection.models[0];

				// If attrToShow is passed in, override formName with client chosen attribute value
				if(!_.isEmpty(self.attrToShow)) {
                    //Overwriting "formName" with title if there is one.
                    if (snapshot.get("workflowPackage").models[0].attributes.packageItems[0].properties[self.attrToShow]) {
                        workflowObject.formName = snapshot.get("workflowPackage").models[0].attributes.packageItems[0].properties[self.attrToShow];
                    }
				} else {
					workflowObject.formName=snapshot.get("formName");
				}
				
				workflowObject.formId=snapshot.get("workflowPackage").models[0].get("packageItems")[0].objectId;
				
				workflowObject.processName = firstTaskObject.get("processName");
				workflowObject.taskName=firstTaskObject.get("name");

				workflowObject.candidateGroups=firstTaskObject.get("candidateGroups");
				workflowObject.groupName = workflowObject.candidateGroups[0];

				// check if task is already assigned
				if (firstTaskObject.get("assigneeDisplayName")) {
					workflowObject.assignee = firstTaskObject.get("assigneeDisplayName");
				} else {
					workflowObject.assignee = "(Unassigned)";
				}

				if (firstTaskObject.get("assignedDate")) {
					var assignedDate = firstTaskObject.get("assignedDate");
					workflowObject.assignedDate = assignedDate ? moment(assignedDate).format(self.dateFormat) : "";
				}

				if (firstTaskObject.get("workflowDueDate")) {
					var workflowDueDate = firstTaskObject.get("workflowDueDate");
					workflowObject.workflowDueDate = workflowDueDate ? moment(workflowDueDate).format(self.dateFormat) : "";
				}

				snapshots.push(workflowObject);
			});
			return snapshots;
		}
	});

	/////////////// UTIL METHODS FOR WF ///////////////

	//We don't have any OTCs for dashboard items, so we'll have to do our formatting manually.
	Workflow.formatTaskDate = function (date, dateFormat) {
		return moment(date).format(dateFormat);
	};

	return Workflow;
});