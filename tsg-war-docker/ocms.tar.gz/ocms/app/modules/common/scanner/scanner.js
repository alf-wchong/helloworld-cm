// Scanner module
define([
	// Application.
	"app",
	"vendor/dynamsoft/dynamsoft.webtwain.config",
	"Dynamsoft"
],

// Map dependencies from above array.
function(app, DSC, DS) {
	"use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
	//get the config from the namespace. The action handler is responsible for this; //

	var Scanner = app.module();

	function ViewModel() {
		var self = this;

		var Dynamsoft = window.Dynamsoft;

		//Scanner functionality
		self.acquireImage = function() {	
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer'); 

			//Check whether the 'Duplex' and Show Advanced' checkbox options are checked(returns boolean value)
			var duplex=null;
		   	if(document.getElementById("duplexCheck-enable").checked){
		   		duplex = true;
		   	}else{
		   		duplex = false;
		   	}

		   	var showAdvanced=null;
		   	if(document.getElementById("advancedCheck-enable").checked){
		   		showAdvanced = true;
		   	}else{
		   		showAdvanced = false;
		   	}

			//Grab value from Color Mode dropdown
			var colorModeDropdown = document.getElementById("colorMode");
			var colorModeSelected = parseInt(colorModeDropdown.options[colorModeDropdown.selectedIndex].value, 10);
				
			//Grab value from Page Size dropdown
			var pageSizeDropdown = document.getElementById("pageSize");
			var pageSizeSelected = parseInt(pageSizeDropdown.options[pageSizeDropdown.selectedIndex].value, 10);
	
			//Initialize the scanner
			DWObject.IfDisableSourceAfterAcquire = true;
			DWObject.OpenSource();

			//Grab value from Select Soucre dropdown
			var sourceDropdown = document.getElementById("source");
			var sourceSelectedVALUE = parseInt(sourceDropdown.options[sourceDropdown.selectedIndex].value, 10);
			DWObject.SelectSourceByIndex(sourceSelectedVALUE);
			
			//Show advanced scanner UI only if Show Advanced checkbox is checked
			DWObject.IfShowUI = false;
			if (showAdvanced) {
				DWObject.IfShowUI = true;
			}
				
			//Enable duplex scanning only if Duplex checkbox is checked
			if (duplex) {
				DWObject.IfDuplexEnabled = true;
			}
				
			//Set color mode based on user selection
			DWObject.PixelType = colorModeSelected;

			//Set page size based on user selection
			DWObject.PageSize = pageSizeSelected;

			//Scan image into scanner
			DWObject.AcquireImage();
			DWObject.CloseSource();
			document.getElementById("doneScanning").disabled = false;


		};

		//Rotates the current image in 'Scanner Preview 90-degrees to the right; binded to 'Rotate Right' btn.
		self.rotateRight = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer');  
			DWObject.RotateRight(DWObject.CurrentImageIndexInBuffer);
		};
			
		//Rotates the current image in 'Scanner Preview' 90-degrees to the left; binded to 'Rotate Left' btn.
		self.rotateLeft = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer');  
			DWObject.RotateLeft(DWObject.CurrentImageIndexInBuffer);
		};
			
		//Rotates all images in 'Scanner Preview' 90-degrees to the right; binded to 'Rotate All' btn. 
		self.rotateAllImages = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer'); 
			var imagesInBuffer = DWObject.HowManyImagesInBuffer;
			for (var i = 0; i<=imagesInBuffer; i++) {
				DWObject.RotateRight(i);
			}
		};
			
		//Clears all images from the 'Scanner Preview'; binded to 'Clear All' btn.
		self.clearAllImages = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer'); 
			DWObject.RemoveAllImages();
		};
			
		//Clears the current page visible in 'Scanner Preview'; binded to 'Clear Page'
		self.clearCurrentImage = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer'); 
			DWObject.RemoveImage(DWObject.CurrentImageIndexInBuffer);
		};

		//Cancels the scanning process by closing the scanner interface.
		self.cancelScanning = function() {
			app.trigger("showDraggable");
			$('div.modal-footer').show();
			$('label.control-label.doctype').show();
			$('.docOps').show();
			$('button.btn.editPropertiesButton').show();

			$('.scanButton').removeAttr('disabled');
			$('.fileUploader').removeAttr('disabled');

			$('div.hpiScanner').hide();
			$('div.modal.hide.in').removeClass("scanner-modal");
			$('div.modal-body').removeClass("scanner-height");

			Dynamsoft.WebTwainEnv.DeleteDWTObject("dwtcontrolContainer");
		};

		//Base64Binary variable used to decode imageData into a Binary pdf
		var Base64Binary = {
	        _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	    
	        /* will return a  Uint8Array type */
	        decodeArrayBuffer: function(input) {
	            var bytes = (input.length/4) * 3;
	            var ab = new ArrayBuffer(bytes);
	            this.decode(input, ab);
	            
	            return ab;
	        },

	        removePaddingChars: function(input){
	            var lkey = this._keyStr.indexOf(input.charAt(input.length - 1));
	            if(lkey == 64){
	                return input.substring(0,input.length - 1);
	            }
	            return input;
	        },

	        decode: function (input, arrayBuffer) {
	            input = this.removePaddingChars(input);
	            input = this.removePaddingChars(input);

	            var bytes = parseInt((input.length / 4) * 3, 10);
	            
	            var uarray;
	            var chr1, chr2, chr3;
	            var enc1, enc2, enc3, enc4;
	            var i = 0;
	            var j = 0;
	            
	            if (arrayBuffer){
	                uarray = new Uint8Array(arrayBuffer);
	            }
	            else{
	                uarray = new Uint8Array(bytes);
	            }
	            
	            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
	            
	            for (i=0; i<bytes; i+=3) {  
	                enc1 = this._keyStr.indexOf(input.charAt(j++));
	                enc2 = this._keyStr.indexOf(input.charAt(j++));
	                enc3 = this._keyStr.indexOf(input.charAt(j++));
	                enc4 = this._keyStr.indexOf(input.charAt(j++));
	        
	                chr1 = (enc1 << 2) | (enc2 >> 4);
	                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
	                chr3 = ((enc3 & 3) << 6) | enc4;
	        
	                uarray[i] = chr1;           
	                if (enc3 != 64){
	                    uarray[i+1] = chr2;
	                }
	                if (enc4 != 64){
	                    uarray[i+2] = chr3;
	                }
	            }
	        
	            return uarray;  
	        }
	    };


		self.doneScanning = function() {
			var DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer'); 
            var imageIndex = DWObject.CurrentImageIndexInBuffer;

            //Checks to see if there is a scanned image before allowing the pdf renditioning to happen
			if(imageIndex > -1){
				document.getElementById("doneScanning").disabled = false;
			}else{
				document.getElementById("doneScanning").disabled = true;
				alert("You must have a scanned image or click cancel.");
			}

			//index array must contain the index of all pages to convert
			var arr = Array.apply(null, Array(imageIndex+1));
            var indexArray = arr.map(function (x, i) { return i });

			//Converts the scanned image into base 64
			//asyncSuccessFunc: Then converts base 64 to pdf blob
            DWObject.ConvertToBase64 (indexArray, 4, asyncSuccessFunc);
                function asyncSuccessFunc (result) {
                	var scannerIndex = 0;
                    var length=result.getLength();
                    var strImg = result.getData(0,length);

                    var bytes = (strImg.length / 4) * 3; //strImg is the base64 string
                    var _temp = new ArrayBuffer(bytes);
                    var _uint8_STR = Base64Binary.decode(strImg, _temp);

                     var _blobImg = new Blob([_uint8_STR], {'type' : "application/pdf"});
                     _blobImg.name = "scanned_document.pdf";

                    $('div.modal-body.well').show();
					$('div.modal-footer').show();
					$('label.control-label.doctype').show();
					$('#documentOptions').show();
					$('button.btn.editPropertiesButton').show();
					$('.docOps').show();

					$('.scanButton').removeAttr('disabled');
					$('.fileUploader').removeAttr('disabled');

					$('div.hpiScanner').hide();
					$('div.modal.hide.in').removeClass("scanner-modal");
					$('div.modal-body').removeClass("scanner-height");

					//Uninitialize WebTwain container.
					Dynamsoft.WebTwainEnv.DeleteDWTObject("dwtcontrolContainer");

					//pass image data over to the adddocuments action
					app.trigger("doneScanPressed", _blobImg, scannerIndex);

                }
		
		};
			
		//Resets modal CSS once add docs modal is hidden. Needed since scanner
		//requires resizing the modal.
		function resetModal() {
			$('div.modal.hide.scanner-modal').removeClass("scanner-modal");
		}
		$('div.modal.hide.in').bind("hidden", resetModal);
	
	}
	
	Scanner.View = Backbone.View.extend({
		template: "common/scanner/scanner",
		initialize: function() {
			//Instantiates the container object for images to be scanned into it
			var DWTObject; 
			Dynamsoft.WebTwainEnv.CreateDWTObject("dwtcontrolContainer", 
		  	function(NewDWTObject){ 
			    DWTObject = NewDWTObject;

				//To update and add sources dyanmically based on the drives that are installed on the browser.
				var sourceArray = [];
				var i = 0;
				var sourceCount = NewDWTObject.SourceCount;
				var sourceLength = document.getElementById("source").length;
				if( sourceCount !== sourceLength){
					//Detect connected sources and... 
					for ( i = 0; i < sourceCount; i++) {
						var src = NewDWTObject.GetSourceNameItems(i);
						sourceArray.push(src);
					}
									
					//..add them to the Source dropdown. 
					for (i = 0; i < sourceCount; i++) {
						 var x = document.getElementById("source");
						    var option = document.createElement("option");
						    option.text = sourceArray[i];
						    x.add(option);
					}
				}
			}, 
			function(errorString){ 
				DWTObject.errorString = errorString;
			});

			//Sets the scanner product key from hpi Admin
			Dynamsoft.WebTwainEnv.ProductKey= this.options.license;
			this.viewModel = new ViewModel();
		},
		afterRender: function() {
			//check to see if container already exists, and deletes any created containers so a new one can be regenerated
			var dynamsoftCheck = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer');
			if(dynamsoftCheck !== null){
				Dynamsoft.WebTwainEnv.DeleteDWTObject("dwtcontrolContainer");
			}

			kb.applyBindings(this.viewModel, this.$el[0]);

			$('div.modal.hide.in').addClass("scanner-modal");
			$('div.modal-body').addClass("scanner-height");
			$('div.modal-body.well').hide();
			$('div.modal-footer').hide();
			$('label.control-label.doctype').hide();
			$('.docOps').hide();
			$('button.btn.editPropertiesButton').hide();

			$('.scanButton').prop('disabled', true);
			$('.fileUploader').prop('disabled', true);
			$('#uploadFileControls').hide();

			

		}
	});

	return Scanner;
});


				 