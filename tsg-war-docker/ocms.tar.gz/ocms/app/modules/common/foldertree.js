define([
        "app",
        "oc",
        "modules/common/ocquery",
        "modules/tsg"
    ],
    function(app, OC, OCQuery, TSG) {
        // Create a new module.
        var FolderTree = app.module();

        FolderTree.Constants = {
            RelationTypes: {
                ExternalRelationTemplate: "externalRelationTemplate",
                QueryBasedTemplate: "queryBasedTemplate", 
                FolderTagsTemplate: "folderTagsTemplate"   
            },
            RelationNames: {
                Children: "children"
            }
        };

        // This sets the image for each of the related objects
        //    param - model - the model of the related objects
        //    param - config - the config used to build the query
        // returns the link to the file that should be used for the icon
        var getMimeTypeIcon = FolderTree._getMimeTypeIcon = function(model, configModel) {
            var iconImageLocation = "assets/css/styles/img/icons/unknown.svg";

            //sometimes, we lose the mimeType when we refesh by clicking another document on the
            //stage. if this is the case, regrab it from the properties if it is a document
            if (!model.get("mimeType") && model.get("properties").Document) {
                model.set("mimeType", model.get("properties").Document.mimetype);
            }
            var contentType = model.get("mimeType");

            // if mimetype is null it's a folder, if it matches get the image. If neither set to unknown
            if (configModel !== undefined && contentType === null && configModel.get("isContainer") === "true") {
                // if mimetype is null it's a folder
                iconImageLocation = "assets/css/styles/img/folder.svg";
            } else {
                var contentTypeConfig = app.context.getContentTypeConfigByMimiType(contentType);

                // if we've got a configuration set up for this mimeType, set the icon, otherwise we'll use the default
                if (contentTypeConfig) {
                    iconImageLocation = contentTypeConfig.iconPath;
                }
            }
            return iconImageLocation;
        };

        // This method responds to a clicked related object and loads it to the stage.
        //     param - model - the model of the related objects
        //     param - configModel - the model of the configured object
        //     param - resolver - the resolver used to handle url mapping ('stage-wizard', 'stage', 'detailview')
        //     param - resolverTrac - the trac to use for the link when clicked
        var linkClicked = FolderTree._linkClicked = function(model, configModel, resolver, resolverTrac) {
            // our URL either starts with 'details/' or 'Stage/'
            var url = (resolver === "detailview") ? "details/" : "Stage/";

            // if it is configured to us trac resolver, lets use stagesimple.
            if (resolverTrac === "Trac Resolver") {
                app.routers.main.stageSimple(model.get("objectId"), {'folderId' : model.parentFolderId});
                //we figured out what we want to do - so don't do
                //any of the rest of this logic
                return;
            }

            // set up the correct trac to move to (or not to move at all)
            var switchTracs = resolverTrac !== "Do not Switch Tracs" ? true : false;
            if (switchTracs) {
                url += resolverTrac + "/";
            } else {
                url += app.context.configName() + "/";
            }

            // if we want to stay on the stage
            if (resolver.match("stage")) {
                if (resolver.match("wizard")) { // resolver is stage-wizard
                    url += app.context.util.getWizardStageUrlIdPart(model.get("objectId"));
                } else { // resolver is just the stage
                    if (configModel && configModel.get("isContainer") === "true") {
                        // here we want to navigate to the URL so it's saved in the browser history and the back button works
                        // as expected
                        url += model.get("objectId");
                    } else { // a document
                        if (!switchTracs) {
                            // here we want to just trigger a refresh for the stage with the documentId so the related objects queries
                            // don't rerun since they're expensive
                            app.trigger("stage.refresh.documentId", model.get("objectId"));


                            return;
                        }
                        // containterID will be resolved by the stage so we only need to supply the object ID
                        url += "|" + model.get("objectId");
                    }
                }
                Backbone.history.navigate(url, { trigger: true });
            } else if (resolver === "detailview") { // we're moving to detail view
                url += encodeURIComponent(model.get("objectId")) + "/true";
                Backbone.history.navigate(url, { trigger: true });
            } else {
                app.log.error(window.localize("modules.common.folderTree.yourConfig") + resolver + window.localize("modules.common.folderTree.isInvalid"));
            }
        };

        // opens up dual pane view
        var dualPane = FolderTree._dualPane = function(model) {
            // create our options object to pass through
			var options = {
                objectId: model.id,
                context: this.context
            };
            app.trigger("stage.refresh.documentId2", options);
        };

        // if annotate button is clicked on result, annotation view is opened
        var annotate = FolderTree._annotate = function(model) {
            // open OA in a separate window / tab
            window.open(app.openAnnotateURL + "/login/external.htm?docId=" + model.id + "&username=" + app.user.get("loginName"));
        };

        // if download doc button is clicked (also called export doc)
        var exportDoc = FolderTree._exportDoc = function(model) {
            window.location = app.serviceUrlRoot + '/content/content?id=' + model.id + '&download=true';
        };

        var buildInfoBlock = FolderTree._buildInfoBlock = function(doc, attrArray, infoBlockObservable, typeOTC) {
            var type = typeOTC.get("ocName");

            _.each(attrArray, function(attr) {
                // this checks to make sure the property exists and is not an empty value
                var propValue = doc.get("properties")[attr.value];

                // 0 is a valid value so we can't just do if(!propValue)
                if (propValue !== undefined && propValue !== "" && propValue !== null) {
                    var attrModel = typeOTC.get("attrs").findWhere({ ocName: attr.value });

                    // if it's a date attribute, let's format it nicely
                    if (attrModel && attrModel.get("dataType") === "date") {
                        app.context.dateService.getFormattedDate(propValue).done(function(formattedDate) {
                            propValue = formattedDate;
                        });
                    }

                    // get the label for the attribute
                    app.context.configService.getLabels(type, attr.value).done(function(label) {
                        // since all results should be of type we can use this
                        // as a shortcut to get the label of the type for this related object
                        if (label === "Type") {
                            propValue = type;
                        }

                        infoBlockObservable(infoBlockObservable() + label + ": " + propValue + "\n");
                    });
                }
            }); // end loop over attributes to display for info block
        };

        // creates the info block for each related object
        var createInfoBlock = FolderTree._createInfoBlock = function(doc, attrArray, infoBlockObservable, typeOTC) {
            // if there's no model or no attributes specified for the info block then there's no information in the info block to make
            if (doc === undefined || attrArray === undefined || attrArray.length === 0) {
                infoBlockObservable("");
                return;
            }
            //oco should already have been formatted within OCQuery
            // get the current OTC so we can grab the configuration for the object type of the object we're building the info block for
            buildInfoBlock(doc, attrArray, infoBlockObservable, typeOTC);
        }; // end createInfoBlock

        // view model for each related object
        var getResultVM = FolderTree._getResultVM = function(options) {
            return kb.ViewModel.extend({
                constructor: function(model) {
                        kb.ViewModel.prototype.constructor.call(this, model);

                        var self = this;

                        // the OC properties for this related object
                        var relatedObjectProps = model.get("properties");

                        // set the display attribute for this related object - prefer the configured display attribute
                        // but if there's no value for that try to use an app-wide configured display attribute
                        if (relatedObjectProps[options.displayAttr]) {
                            self.resultLabel = relatedObjectProps[options.displayAttr];
                        } else {
                            self.resultLabel = relatedObjectProps[app.objectDisplayName];
                            if (!self.resultLabel) {
                                // if we don't have a value, reset it to the default
                                self.resultLabel = relatedObjectProps.objectName;
                            }
                        }

                        //Append additional property values to the label
                        if(options.additionalDisplayAttrs) {
                            _.each(options.additionalDisplayAttrs, function(attr) {
                                var labelSuffix = "";

                                //Add prefix
                                if(attr.prefixText) {
                                    labelSuffix += " " + attr.prefixText;
                                }

                                //Add property value
                                if(attr.propertyName && _.has(relatedObjectProps, attr.propertyName)) {
                                    var propVal = relatedObjectProps[attr.propertyName];

                                    //We do need to display the string value "0" so can't just check if(propertyVal)
                                    if(propVal !== undefined && propVal !== "" && propVal !== null) {
                                        labelSuffix += " " + relatedObjectProps[attr.propertyName];

                                        //If property is present/valid, add additional property suffix
                                        self.resultLabel += labelSuffix;
                                    }
                                }
                            });
                        }

                        // folder tags: to make fake tag folders not clickable
                        self.isFolderTag = function(objectId) {
                            return objectId.indexOf("#") !== -1;
                        };
                        self.canClickFolderLinks = ko.observable(true);

                        // whether or not this object is a container
                        self.isContainer = ko.observable(false);

                        // ICON CONTROL
                        self.isAnnotated = ko.observable(false);
                        self.icon = ko.observable(false);
                        self.showDual = ko.observable(false);
                        self.showExternalLaunch = ko.observable(false);
                        self.showExportDoc = ko.observable(false);
                        // the info block to display for this related object
                        self.infoBlock = ko.observable("");


                        // the type of this related object
                        self.relatedObjectType = model.get("objectType");

                        // the type config for this related object
                        var configModel;

                        // get the type configuration for this object type
                        app.context.configService.getAdminTypeConfig(self.relatedObjectType, function(confModel) {
                            configModel = confModel;

                            //bail if there is no OTC
                            if (!configModel) {
                                return;
                            }

                            // note whether or not this object is a container
                            if (configModel.get("isContainer") === "true") {
                                self.isContainer(true);
                            }

                            // create the info block for this object if the config is set to true in admin
                            if (options.showInfoBlock === "true" && !self.isContainer()) {
                                createInfoBlock(model, options.infoBlockAttrs, self.infoBlock, configModel);
                            }

                            // note whether this object can be annotated if the config is set to true in the admin
                            // and this is not a container (no annotations for folders)
                            if (options.showAnnotations === "true" && !self.isContainer()) {
                                TSG.services.ajaxService.isAnnotated({
                                    context: self,
                                    successCallback: function(result) {
                                        // result will be either true or false
                                        self.isAnnotated(result);
                                    },
                                    objectId: model.get("objectId"),
                                    isNotGlobal: true
                                });
                            }

                            // set the icon if the config is set to true in the admin
                            if (options.showMimeIcon === "true") {
                                self.icon(getMimeTypeIcon(model, configModel));
                            }

                            // allow dual screen mode if set to true in the admin and this is not a container
                            if (options.showDualScreen === "true" && !self.isContainer()) {
                                self.showDual(true);
                            }

                            // allow external launch if set to true in the admin and this is not a container
                            if (options.showExternalLaunch === "true" && !self.isContainer()) {
                                self.showExternalLaunch(true);
                            }

                            // allow exporting of the doc is set to true in the admin and this is not a container
                            if (options.showExportDoc === "true" && !self.isContainer()) {
                                self.showExportDoc(true);
                            }
                        }); // end getTypeConfig

                        // a related object was clicked
                        self.resultClicked = function() {
                            if (this.isFolderTag(model.get('objectId'))) {
                                this.expandContainerNode(this);
                            } else {
                               linkClicked(model, configModel, options.resolver, options.resolverTrac);

                                app.trigger("relatedObjectsClick");
                            }
                        };

                        // a related object was chosen to be shown in dual pane mode
                        self.openDual = function() {
                            dualPane(model);
                            //used to alter the filter fields in the View All Documents: Non-Bills/Bills page
                            $("#filterDocuments").removeClass("col-lg-4");
                            $("#viewAllDocsFilters").removeClass("col-lg-8");
                            $(".viewAllDocsIndividualFilters").removeClass("col-lg-4");
                        };

                        self.launchItem = function() {
                            window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(self.properties().objectName) + "?id=" + self.objectId() + "&overlay=true" + "&contentType[]=" + ["pdf", "txt", ".*"]);
                        };

                        // a related object was chosen to show annotations
                        self.startAnnotate = function() {
                            annotate(model);
                        };

                        // a related object was chosen to download / export
                        self.exportDoc = function() {
                            exportDoc(model);
                        };

                        // controls the showing of the child nodes or not
                        self.currentlyExpanded = ko.observable(false);

                        // controls the display of the + / - icon for a folder / folder tag that can be expanded on
                        self.expandClass = ko.computed(function() {
                            if (self.currentlyExpanded()) {
                                return "expandButton expanded";
                            } else {
                                return "expandButton closed";
                            }
                        });

                        // only want to run the query once so let's make a flag to indicate if it's run or not
                        self.hasExpandedOnce = false;

                        // a flag to start / stop the loading spinner
                        self.loading = ko.observable(false);

                        // the children collection to fetch
                        var children = new OCQuery.Collection([], {
                            mode: 'client'
                        });
                        self.childNodes = kb.collectionObservable(children, {
                            view_model: getResultVM(options)
                        });

                        // the function that is called when clicking on a + / - for a container / folder tag related object
                        self.expandContainerNode = function(clickedModel) {
                            // if it's currently expanded or if we've already expanded it once, we don't want to run the query again
                            if (!self.currentlyExpanded() && !self.hasExpandedOnce) {
                                // start the loading spinner
                                self.loading(true);

                                self.currentlyExpanded(true);

                                // we've now expanded once so set this flag so we don't run the query again later
                                self.hasExpandedOnce = true;

                                // get our collection to fetch depending on how the expand function was configured
                                var newCollection = options.expand(clickedModel.model().get("objectId"), options.sortAttr, options.sortOrder, options.otc, options.comparatorFunction);

                                // fetch our collection
                                newCollection.fetch({
                                    success: function(newModels) {
                                        // set the pageable collection to have the newly fetched models
                                        // we don't want any results that have a period as the first character of the objectName (hidden folders)
                                        children.fullCollection.reset(newModels.fullCollection.filter(function(resultObject) {
                                            //pass the objectId of the children collection to each object
                                            //for stage resolving
                                            if (newModels.id.indexOf("#") > 0) {
                                                resultObject.parentFolderId = newModels.id.substring(0, newModels.id.indexOf("#"));
                                            } else {
                                                resultObject.parentFolderId = newModels.id;
                                            }
                                            return resultObject.get("properties").objectName.indexOf(".") !== 0;
                                        }));

                                        // stop the loading spinner
                                        self.loading(false);
                                        children.setPageSize(children.fullCollection.length, { first: true });
                                    },
                                    global: false
                                });
                            } else {
                                // toggle the value of currently expanded
                                self.currentlyExpanded(!self.currentlyExpanded());
                            }
                        };
                    } // end constructor function
            }); // end kb extend
        }; // end getResultVM

        /**
         * Sets the id value on the query to either the document or container object id.
         * @param folderTreeViewModel the current folder tree view model
         */
        FolderTree._setQueryId = function (folderTreeViewModel) {
            // get the ID of either the current document or container in the stage for our query
            if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.FolderTagsTemplate || folderTreeViewModel.dependentOn !== "activeDocument") {
                folderTreeViewModel.query.id = app.context.container.get("objectId");
            } else {
                folderTreeViewModel.query.id = app.context.document.get("objectId");
            }
        };

        /**
         * Method to query for a configured relation
         * @param folderTreeViewModel the current folder tree view model
         * @param relationConfig the configuration model for the configured relation
         */
        FolderTree._queryRelated = function (folderTreeViewModel, relationConfig) {
            // assume this section should not be hidden
            folderTreeViewModel.hide(false);

            FolderTree._setQueryId(folderTreeViewModel);

            // if we've got an ID to run - we won't have an ID if this relation is concerned with documents in the stage and there is
            // no document in the stage
            if (folderTreeViewModel.query.id) {
                // indicate that we're loading the results
                folderTreeViewModel.loading(true);

                // if this is a query based relation we want to update the search parameters
                if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.QueryBasedTemplate) {
                    folderTreeViewModel.updateSearchParameters();

                    // if all the values for the criteria are empty then we don't need to run this query
                    if (folderTreeViewModel.query.allValuesNull) {
                        // we're not going to be doing a query, so reset our collection (since there can't be any matches),
                        // stop loading, resolve and return
                        folderTreeViewModel.query.reset();
                        folderTreeViewModel.loading(false);
                        //We need to make sure this is hidden if configured to do so, since the query won't be run if we are here
                        if (relationConfig.attributes.optionsHideEmptyRelations === "true") {
                            folderTreeViewModel.hide(true);
                        }

                        return $.Deferred().resolve().promise();
                    }
                } else if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.ExternalRelationTemplate) {
                    // set the external relation query url, and we'll let backbone encode the ids
                    folderTreeViewModel.query.url = app.serviceUrlRoot + "/" + relationConfig.get('externalRelationEndpoint') + "?folderId=" + app.context.container.get("objectId") + "&objectId=" + app.context.document.get("objectId");
                }

                // run the query
                var deferred = folderTreeViewModel.query.fetch({
                    //Override the app.ajaxSetup global variable and set to false
                    //to stop callbacks calling app.ajaxStart and app.ajaxStop
                    global: false,
                    success: _.partial(FolderTree._onQuerySuccess, folderTreeViewModel),
                    error: _.partial(FolderTree._onQueryError, folderTreeViewModel)
                });

                // return the promise object if we're doing the fetch so we can wait til the fetch is over to resolve
                return deferred.promise();
            } else {
                // this relation is not currently relevant so hide it (e.g. there is no document in the stage) and resolve
                folderTreeViewModel.hide(true);
                return $.Deferred().resolve().promise();
            }
        };
        
        /**
         * Method used when filtering a relation collection. Determines whether to include an OpenContentObject.
         * @param resultObject an object in the relation collection
         */
        FolderTree._shouldIncludeInRelationCollection = function (oco) {
            var shouldInclude = false;
            var folderTreeViewModel = this;
            var ocoProps = oco.get("properties");
	    
            // the ocoProps length check is needed to filter out invalid default values
            if (ocoProps && ocoProps.length != 0) {
                // object is hidden if the objectName has a period at the beginning
                var currentDocumentId = app.context.document.get("objectId");
                var isHiddenObject = ocoProps.objectName.indexOf(".") === 0;
                var isCurrentFolder = ocoProps.objectId === app.context.container.get("objectId");
                var isCurrentDocument = ocoProps.objectId === currentDocumentId;

                var isChildrenRelation = folderTreeViewModel.relationName === FolderTree.Constants.RelationNames.Children;
                var isFolderTagsTemplateRelation = folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.FolderTagsTemplate;
                var isExternalRelation = folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.ExternalRelationTemplate;

                // don't include hidden objects or the current folder
                shouldInclude = !isHiddenObject && !isCurrentFolder;

                // filter out the current document in stage if it exists and is NOT a children, folder tags or external relation relation
                if (currentDocumentId && !isChildrenRelation && !isFolderTagsTemplateRelation && !isExternalRelation) {
                    shouldInclude = shouldInclude && !isCurrentDocument;
                }
            }

            return shouldInclude;
        };

        /**
         * Success callback for a relation query
         * @param folderTreeViewModel the current folder tree view model
         * @param query the relation query object
         * @param collection the collection of related objects
         */
        FolderTree._onQuerySuccess = function (folderTreeViewModel, query, collection) {
            // done running the query
            folderTreeViewModel.loading(false);

            var shouldHideEmptyRelations = folderTreeViewModel.options.shouldHideEmptyRelations === "true";

            // Trigger that determines if we need to hide the Related Objects view panel
            // signals if the query produced no children results in the collection (ie. no Related Objects for that tree)
            // we only require results from one execution of the query
            if (collection.length === 0 && !folderTreeViewModel.queryHasExecuted) {
                // no related objects; check whether the relation section should always be visible
                if (shouldHideEmptyRelations) {
                    app.trigger("noRelatedObjects");
                }
            } else {
                var filteredCollection = folderTreeViewModel.query.fullCollection.filter(FolderTree._shouldIncludeInRelationCollection, folderTreeViewModel);
                folderTreeViewModel.query.fullCollection.reset(filteredCollection);
                folderTreeViewModel.query.setPageSize(folderTreeViewModel.options.displaySize, {
                    first: true
                });
            }

            // flag that we've executed the query already (so the clicks on + / - icons don't cause a query to run unnecessarily)
            folderTreeViewModel.queryHasExecuted = true;

            // if there are no children and the user wants to hide empty relations, hide the relation
            if ((!folderTreeViewModel.query || folderTreeViewModel.query.length <= 0) && shouldHideEmptyRelations) {
                folderTreeViewModel.hide(true);
            }

            //Reset each object in case we want to refresh the view, in which case those objects will requery
            ko.utils.arrayForEach(folderTreeViewModel.objects(), function (object) {
                if (object.hasExpandedOnce) {
                    object.hasExpandedOnce = false;
                }
                if (object.currentlyExpanded()) {
                    object.expandContainerNode(object);
                }
            });

            folderTreeViewModel.initializeShowMore();
        };

        /**
         * Error callback for a relation query
         * @param folderTreeViewModel the current folder tree view model
         */
        FolderTree._onQueryError = function (folderTreeViewModel) {
            folderTreeViewModel.loading(false);
            app.trigger("alert:error", {
                header: window.localize("modules.common.folderTree.relatedObjectsQueryFailure"),
                message: window.localize("modules.common.folderTree.thereWasAn")
            });
        };

        /**
         * Method to set the correct Query Model based on the relation configuration for the current 
         * folder tree view model
         * @param folderTreeViewModel the current folder tree view model
         * @param relationConfig the configuration model for the configured relation
         */
        FolderTree._setQuery = function (folderTreeViewModel, relationConfig) {
            // set the query type for the relation depending on the configuration
            if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.QueryBasedTemplate) {
                folderTreeViewModel.query = new OCQuery.Collection([], {
                    mode: "client",
                    comparator: FolderTree.getComparatorFunction(),
                    state: {
                        pageSize: 500,
                        firstPage: 0
                    }
                });
            } else if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.FolderTagsTemplate) {
                folderTreeViewModel.query = new OCQuery.ChildrenWithLabels([], {
                    comparator: FolderTree.getComparatorFunction()
                });
            } else if (folderTreeViewModel.relationType === FolderTree.Constants.RelationTypes.ExternalRelationTemplate) {
                folderTreeViewModel.query = new OC.PageableRelatedObjects([], {
                    comparator: FolderTree.getComparatorFunction()
                });
            } else if (relationConfig.get("relationName") !== FolderTree.Constants.RelationNames.Children) {
                // this is a relation based template and not a 'children' relation
                folderTreeViewModel.query = new OC.PageableRelatedObjects([], {
                    comparator: FolderTree.getComparatorFunction()
                });
                folderTreeViewModel.query.parentOrChild = relationConfig.get("relationDirection");
            } else { // this is a 'children' relation
                folderTreeViewModel.query = new OCQuery.Children([], {
                    comparator: FolderTree.getComparatorFunction()
                });
                folderTreeViewModel.query.relationName = FolderTree.Constants.RelationNames.Children;
                folderTreeViewModel.dependentOn = "container";
            }

            // set the relationName
            if (!folderTreeViewModel.query.relationName) {
                folderTreeViewModel.query.relationName = folderTreeViewModel.relationName;
            }

            // set the relationType
            if (!folderTreeViewModel.query.relationType) {
                folderTreeViewModel.query.relationType = folderTreeViewModel.relationType;
            }

            // set the sort attribute and order
            folderTreeViewModel.query.sortAttr = folderTreeViewModel.options.sortAttr;
            folderTreeViewModel.query.sortOrder = folderTreeViewModel.options.sortOrder;
            folderTreeViewModel.query.otc = folderTreeViewModel.options.otc;

            // set the page size
            folderTreeViewModel.query.setPageSize(folderTreeViewModel.options.displaySize, {
                first: true
            });
        };

        FolderTree.getComparatorFunction = function() {
            return function(left, right) {
                var sortOrder = 1;
                if (this.sortOrder === 'ascending') {
                    sortOrder = -1;
                }

                var leftSortAttrVal = left.get("properties")[this.sortAttr];
                var rightSortAttrVal = right.get("properties")[this.sortAttr];

                var attrVal1;
                var attrVal2;

                //we are going to check if these vals are a string, if so we need to make some toLowerCase
                //calls. if not, they are assumed to be date or plain old ints, and they are good to go
                if (typeof leftSortAttrVal === "string") {
                    // get the left and right sort attr values or default to object name if the left or right doesn't have a value for the property
                    attrVal1 = leftSortAttrVal ? leftSortAttrVal.toLowerCase() : left.get("properties").objectName.toLowerCase();
                    attrVal2 = rightSortAttrVal ? rightSortAttrVal.toLowerCase() : right.get("properties").objectName.toLowerCase();
                } else {
                    // get the left and right sort attr values or default to modified date if the left or right doesn't have a value for the property
                    attrVal1 = leftSortAttrVal ? leftSortAttrVal : left.get("properties").modifiedDate;
                    attrVal2 = rightSortAttrVal ? rightSortAttrVal : right.get("properties").modifiedDate;
                }

                // determine if the left and right are containers
                var leftIsContainer = false;
                var rightIsContainer = false;

                var leftConfig = this.otc.get('configs').findWhere({ ocName: left.get("objectType") });
                if (leftConfig && leftConfig.get("isContainer") === "true") {
                    leftIsContainer = true;
                }

                var rightConfig = this.otc.get('configs').findWhere({ ocName: right.get("objectType") });
                if (rightConfig && rightConfig.get("isContainer") === "true") {
                    rightIsContainer = true;
                }


                // if they are either both containers or both docs, sort by the sort attribute
                if ((leftIsContainer && rightIsContainer) || (!leftIsContainer && !rightIsContainer)) {
                    // To handle ascending/descending elegantly, we are going to multiply the return value by the sortOrder variable.
                    // If the sort is descending, we multiply by 1 (the default of this comparator), if it is ascending, we multiply by -1
                    if (attrVal1 < attrVal2) {
                        return (1 * sortOrder);
                    } else if (attrVal1 > attrVal2) {
                        return (-1 * sortOrder);
                    } else { // they are equal so it doesn't matter
                        return 0;
                    }
                } else if (leftIsContainer) { // if not, then we want to bring the container to the top
                    return -1;
                } else {
                    return 1;
                }
            };
        };

        FolderTree._applyExpandWithTags = function(relationConfig, options) {
            if (relationConfig.get("optionsExpandWithTags") === "true" || relationConfig.get("relationConfigType") === FolderTree.Constants.RelationTypes.FolderTagsTemplate) {
                // this is the function that runs with the plus on folders
                options.expand = function(objectId, sortAttr, sortOrder, otc) {
                    var ocChildren = new OCQuery.ChildrenWithLabels([], {
                        comparator: FolderTree.getComparatorFunction()
                    });
                    ocChildren.id = objectId;
                    ocChildren.sortAttr = sortAttr;
                    ocChildren.sortOrder = sortOrder;
                    ocChildren.otc = otc;
                    return ocChildren;
                };
            }
        };
        
        /**
         * Parses the given relation config and object type config into an options object
         * @param folderTreeViewModel - the current folder tree view model
         * @param relationConfig - the current relation config
         * @param OTC - the current ObjectTypeConfig
         */
        FolderTree._setFolderTreeViewModelOptions = function (folderTreeViewModel, relationConfig, OTC) {
            // initialize our options using the configured options or a default value
            folderTreeViewModel.options = {
                showInfoBlock: relationConfig.get("optionsShowInfoBlock") || "true", // creates info block for item in tree
                showAnnotations: relationConfig.get("optionsShowAnnotations") || "true", // shows if item was annotated or not
                showMimeIcon: relationConfig.get("optionsShowMimeIcon") || "true", // shows icon with mimetype
                showDualScreen: relationConfig.get("optionsShowDualScreen") || "true", // shows button to create dual screen view
                showExternalLaunch: relationConfig.get("optionsShowExternalLaunch") || "false",
                showExportDoc: relationConfig.get("optionsShowExportDoc") || "false", // default don't show button to export doc w/o loading it in the stage
                defaultOpen: relationConfig.get("optionsDefaultOpen") || "true", // default setting to have query loaded and displayed
                displaySize: relationConfig.get("optionsDisplaySize") ? parseInt(relationConfig.get("optionsDisplaySize"), 10) : 25, // default results that are shown
                displayAttr: relationConfig.get("displayAttr") || 'objectName', // default value to be displayed
                additionalDisplayAttrs: relationConfig.get("additionalDisplayAttrs") || [],
                resolver: relationConfig.get("resolver") || 'stage', // default resolver to use
                resolverTrac: relationConfig.get("resolverTrac") || 'Do not Switch Tracs', // default resolver trac to use
                infoBlockAttrs: relationConfig.get("infoBlock") || [], // set these if you want an infoblock
                sortAttr: relationConfig.get("sortAttr") || 'objectName',
                sortOrder: relationConfig.get("sortOrder") || 'ascending',
                otc: OTC,
                shouldHideEmptyRelations: relationConfig.get("optionsHideEmptyRelations") || "true",
                expand: folderTreeViewModel.expand,
                comparatorFunction: FolderTree.getComparatorFunction()
            };
        };
        
        FolderTree.ViewModel = function(relationConfig, OTC) {
            var self = this;
            
            // we will need docs that explain this takes
            // the model of the object that was clicked
            // and should return a collection of the children
            self.expand = function(objectId, sortAttr, sortOrder, otc, comparatorFunction) {
                // this is the function that runs with the plus on folders
                // by default this will be getChildren call
                var ocChildren = new OCQuery.Children([], {
                    comparator: comparatorFunction
                });
                ocChildren.id = objectId;
                ocChildren.sortAttr = sortAttr;
                ocChildren.sortOrder = sortOrder;
                ocChildren.otc = otc;
                return ocChildren;
            };

            FolderTree._setFolderTreeViewModelOptions(this, relationConfig, OTC);
                        
            // whether or not to show the spinner for a loading relation
            self.loading = ko.observable(false);

            // whether to display the relation section or not
            self.hide = ko.observable(false);

            // if the query has executed or not - this helps us tell if a click on the + / - icon should trigger a query fetch or not
            self.queryHasExecuted = false;

            // label of relation to be displayed
            self.label = relationConfig.get("label");

            // the label with any spaces replaced with "_" in order to be called by the bootstrap panel-collapse
            self.hiddenLabel = self.label.replace(/\s/g, "_");
            self.hiddenLabel = self.hiddenLabel.replace(/'/, '');
            self.hiddenLabel = self.hiddenLabel.replace(/\W/g, '');

            // panel-groups are open by default
            self.openAccordion = ko.observable("panel-collapse collapse in");
            self.openAccordionIcon = ko.observable("icon-minus");

            // if this should be closed by user configuration, close it
            if (self.options.defaultOpen === "false") {
                self.openAccordion("panel-collapse collapse");
                self.openAccordionIcon("icon-plus");
            }

            // this will be activeDocument or container depending if this is a document or container dependent relation
            self.dependentOn = relationConfig.get("criteria")[0].type;
            
            // the type of relation - query, relation based, folder tags, external relation
            self.relationType = relationConfig.get("relationConfigType");
            
            // the name of the relation
            self.relationName = relationConfig.get("relationName");

            // this is used to update the search parameters for a query based relation before the query is actually run
            self.updateSearchParameters = function() {
                // clear out the current search parameters
                self.query.searchParameters = [];

                // this is either all the criteria must match (AND) or any of the criteria can match (OR)
                var parameterLogic = relationConfig.get("parameterLogic") ? relationConfig.get("parameterLogic") : "OR";
                self.query.logic = [" " + parameterLogic + " "];

                // if all the values specified as criteria are NULL then we don't need to run the query so set a flag here
                self.query.allValuesNull = true;

                // build search parameters for the property criteria specified in the config
                _.each(relationConfig.get("criteria"), function(criteria) {
                    var value, properties;

                    // get the properties for either the document or container in the stage depending on the current
                    // criteria configuration
                    if (criteria.type === "activeDocument") {
                        properties = app.context.document.get("properties");
                    } else {
                        properties = app.context.container.get("properties");
                    }

                    // get the value of the criteria attribute
                    value = properties[criteria.value];

                    if (value) {
                        // we know ALL the values aren't NULL so we need to run the query
                        self.query.allValuesNull = false;

                        // build the search param for this property and add it to the query's list
                        var sp = {
                            paramName: criteria.attribute,
                            paramValue: value,
                            paramType: "property",
                            operator: criteria.operator,
                            termLogic: criteria.termLogic
                        };
                        self.query.searchParameters.push(sp);
                    }
                });

                // want a query parameter with the specified expected child type of the relation as well
                var sp2 = {
                    paramName: relationConfig.get("childType"),
                    paramValue: relationConfig.get("childType"),
                    paramType: "type"
                };
                self.query.searchParameters.push(sp2);
            };

            // set the query model for the relation depending on the configuration
            FolderTree._setQuery(self, relationConfig);
            // end build relation configuration

            // set the expand function based on the configuration
            FolderTree._applyExpandWithTags(relationConfig, self.options);

            // the query for results
            self.queryRelated = function() {
                return FolderTree._queryRelated(self, relationConfig);
            };

            // put the results of the query onto the folder tree.objects
            self.objects = kb.collectionObservable(self.query, {
                view_model: getResultVM(self.options)
            });

            // this is run when a + / - icon is clicked for a relation
            // we switch up the icon and if we haven't run the query yet (i.e. the stage was freshly loaded), run the query
            self.toggleRelation = function() {
                if (self.openAccordionIcon() === "icon-plus") {
                    self.openAccordionIcon("icon-minus");
                } else {
                    self.openAccordionIcon("icon-plus");
                }

                if (!self.queryHasExecuted) {
                    self.queryRelated();
                }
            };

            // hold the unfiltered collection
            var _unfilteredCollection;

            self.filterText = ko.observable("");

            // resets the collection based on a filter
            // waits 400 miliseconds before re-evaluating (waits for user to stop typing)
            self.activateFilter = ko.computed(function() {
                // if the filter is empty and we cached results, put them back
                if (self.filterText() === "" && _unfilteredCollection) {
                    return _unfilteredCollection;
                } else if (self.filterText() !== "") {
                    // copy the array
                    if (!_unfilteredCollection) {
                        _unfilteredCollection = self.query.fullCollection.models.slice(0);
                    }

                    // return the filtered collection based on what the user has typed already and what's being used to display the related objects
                    return _.filter(_unfilteredCollection, function(model) {
                        // only want entries that have some kind of value for what's being displayed
                        var filterVal = model.get("properties")[self.options.displayAttr];
                        if (filterVal) {
                            return filterVal.toString().toLowerCase().indexOf(self.filterText().toLowerCase()) !== -1;
                        } else {
                            return false;
                        }

                    });
                } else {
                    return null;
                }
            }).extend({ throttle: 400 });

            // calling reset within the activateFilter creates some sort of
            // loop where the activate just keeps running. Moving it out here fixes that
            self.activateFilter.subscribe(function(filteredCollection) {
                if (filteredCollection !== null) {
                    self.query.fullCollection.reset(filteredCollection);
                    if (self.query.state.pageSize < self.query.fullCollection.length) {
                        self.showMore(true);
                    }
                    if (self.query.state.pageSize >= self.query.fullCollection.length) {
                        self.showMore(false);
                    }
                    if (self.query.state.pageSize <= self.query.fullCollection.length) {
                        self.showLess(false);
                    } else {
                        self.showLess(true);
                    }
                }
            });

            self.showMore = ko.observable(false);
            self.showLess = ko.observable(false);

            self.initializeShowMore = function() {
                //check if showMore should start out visible
                if (self.query.fullCollection.length > 0 && self.query.state.pageSize < self.query.fullCollection.length) {
                    self.showMore(true);
                }

                if (self.query.state.pageSize < self.query.fullCollection.length) {
                    self.query.setPageSize(self.options.displaySize, { first: true });
                }
            };

            // show more results instead of the default 25
            self.showMoreResults = function() {
                if (self.query.state.pageSize < self.query.fullCollection.length) {
                    self.query.setPageSize(self.query.state.pageSize + self.options.displaySize, { first: true });
                }
                if (self.query.state.pageSize >= self.query.fullCollection.length) {
                    self.showMore(false);
                }
                if (self.query.state.pageSize > self.options.displaySize) {
                    self.showLess(true);
                }
            };

            // show fewer results instead of the default 25
            self.showFewerResults = function() {
                if (self.query.state.pageSize > self.options.displaySize) {
                    self.query.setPageSize(self.query.state.pageSize - self.options.displaySize, { first: true });
                }
                if (self.query.state.pageSize < self.query.fullCollection.length) {
                    self.showMore(true);
                }
                if (self.query.state.pageSize <= self.options.displaySize) {
                    self.showLess(false);
                }
            };
        }; // end FolderTree.ViewModel

        // Return the module for AMD compliance.
        return FolderTree;

    });
