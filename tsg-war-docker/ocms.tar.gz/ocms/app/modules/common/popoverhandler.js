// Modal Action Handler
// Responsible for Displaying Actions in a Bootstrap Modal Dialog

// ### Initial Setup
define([
    "app"
],

// Map dependencies from above array
function(app) {

    // Create a new module
    var PopoverHandler = app.module();

    // This, like any action handler, when instantiated will put an event watcher on app
    app.popoverHandler = _.extend({}, Backbone.Events);

    // ### Main View
    PopoverHandler.View = Backbone.Layout.extend({

        // Choose the template / classname of the created div and some basic DOM interactivity event handling
        template: "common/popoverhandler",
        className : "popover-wrapper",
        initialize: function() {
            var that = this;
            var moduleId = this.moduleId = "popoverHandler";

            //initialize the modal elements (updated in the afterRender)
            this.$popover = null;
            this.$popoverTitle = null;
            this.$popoverSubTitle = null;

            // Clear the contents within the modal
            that.clearPopover = function() {
                $("#modalIFrame").children().remove();
                // since we have styling applied to the error/message containers - we have to hide them as well as removing their contents
                $("#" + moduleId + "-error").empty().hide();
                $("#" + moduleId + "-message").empty().hide();
                $("#" + moduleId + "-content").children().hide();
                //hides any info that may be shown
                $("#" + moduleId + "-info").empty().hide();
                //hide any progressBar
                $("#" + moduleId + "-progressBar").hide();


            };

            // Fired when the modal is closed
            that.onPopoverHidden = function() {
                that.clearPopover();
                $("#modalIFrame").attr("src","about:blank");
                app[moduleId].trigger("hide");

                if (that.currentPopoverView && _.isFunction(that.currentPopoverView.onDismiss)) {
                    that.currentPopoverView.onDismiss();
                }
            };

            // Fired when the modal is shown
            that.onPopoverShow = function() {
                // no-op for now
            };

            // ## Module Listeners
            // This handler by nature is very event driven.  We can trigger events to show/hide the entire modal itself
            // messages contained within etc.

            // ### Listeners for Error Handling and Messaging
            // Basic listeners will replace the designated message areas on the dom with any relevant messages
            this.listenTo(app.popoverHandler, "showError", function(message, maintainModal){
                if(!maintainModal) {
                    that.clearPopover();
                }
                $("#" + moduleId + "-error").html(message).show();
            });

            this.listenTo(app.popoverHandler, "hideError", function(){
                $("#" + moduleId + "-error").hide();
            });

            this.listenTo(app.popoverHandler, "showMessage", function(message){
                    that.clearPopover();
                    $("#" + moduleId + "-message").html(message).show();
            });

            this.listenTo(app.popoverHandler, "showInfo", function(message){
                $("#" + moduleId + "-info").html(message).show();
                $("#" + moduleId + "-content").hide();
            });

            this.listenTo(app.popoverHandler, "hideInfo", function(){
                $("#" + moduleId + "-info").hide();
            });

            this.listenTo(app.popoverHandler, "showProgress", function(){
                $("#" + moduleId + "-progressBar").show();
            });

            this.listenTo(app.popoverHandler, "hideProgress", function(){
                $("#" + moduleId + "-progressBar").hide();
                //lets also make sure its at 0 for bothIds
                $("#" + moduleId + "-progressBar .progress-bar").width(0 + '%');
                $("#" + moduleId + "-progressBar .progress-bar").text(0 + '%');
            });

            this.listenTo(app.popoverHandler, "updateProgress", function(percent){
                $("#" + moduleId + "-progressBar .progress-bar").width(percent + '%');
                $("#" + moduleId + "-progressBar .progress-bar").text(percent + '%');
            });

            // show a loading indicator when we're setting up etc.
            this.listenTo(app.popoverHandler, "loading", function(showLoading){
                if(showLoading){
                    $("#" + moduleId + "-content").hide();
                    $("#" + moduleId + "-loader").show();
                }else{
                    $("#" + moduleId + "-content").show();
                    $("#" + moduleId + "-loader").hide();
                }
            });

            // ### Show Modal Listener
            // This handles much of the work needed to actually set up an actively displayed modal with an action
            this.listenTo( app.popoverHandler, "show", function(options){
                that.clearPopover();

                var title = options.title;
                var size = options.size ? options.size : "xl";

                that.currentPopoverView = options.view;

                // //Add our title to the modal -- retrieved from the action confiuration in config-details.xml
                that.$popoverTitle.html(window.localize(title));
                that.$popoverSubTitle.html(options.subTitle ? options.subTitle : "");

                
                if(size === "small"){
                    this.$popover.find(".popover-dialog").removeClass("popover-xl").removeClass("popover-lg").addClass("popover-sm");
                }
                else if(size === "xl"){
                    this.$popover.find(".modal-dialog").removeClass("popover-sm").removeClass("popover-lg").addClass("popover-xl");
                }
                else if(size === "max"){
                        var width,height;
                        width = $(window).width();
                        height = $('.popover-body').height();
                        this.$popover.css({"max-width": width, "width" : width, 'height': height });
                    //this.$popover.find(".popover-dialog").removeClass("popover-sm").removeClass("popover-lg").addClass("popover-xl");
                }
                else{
                    this.$popover.find(".popover-dialog").removeClass("popover-sm").removeClass("popover-xl").addClass("popover-lg");
                }

                that.$popover.modal("show");

            });

            // ### Hide Modal Listener
            // Responsible for cleaning up the modal when it's hidden
            this.listenTo( app.popoverHandler, "hide", function(confirmationMessage){
                //if confirmation exists, this will be true (truthy value)
                //if the action is complete, then don"t show the confirmation message
                if(confirmationMessage){
                    if(window.confirm(confirmationMessage)){
                        that.$popover.modal("hide");
                        //use the showPane booleans on the stage viewModel to correctly
                        //show what panes should be shown
                        app.trigger("stage.showPanes");
                        that.removeView("#" + moduleId + "-content");
                    }
                } else {
                    //This causes a redundant call to this method, but it also procs bs.modal's
                    //  hide event, which isn't proc'd when an action calls hide, while this function is.
                    //  Don't really know if this is what we want or what it would affect.
                    that.$popover.modal("hide");
                    //use the showPane booleans on the stage viewModel to correctly
                    //show what panes should be shown
                    app.trigger("stage.showPanes");
                    that.removeView("#" + moduleId + "-content");
                }

            });
        },
        afterRender: function() {
            var that = this;
            this.$popover = this.$(".popover");
            this.$popoverTitle = this.$(".modal-title");
            this.$popoverSubTitle = this.$(".modal-sub-title");

            that.$popover.modal({
                backdrop: false,
                keyboard: true,
                show: false
            });

            // bind some functions to some events so we can do cleanup etc when the modal is open or closed
            this.$popover.off("shown.bs.modal");
            this.$popover.off("hidden.bs.modal");
            this.$popover.on("shown.bs.modal", function() {
                that.setView("#" + that.moduleId + "-content", that.currentPopoverView).render();
                that.onPopoverShow();
            });
            this.$popover.on("hidden.bs.modal", that.onPopoverHidden);
        }
    });

    // Return the module for AMD compliance.
    return PopoverHandler;

});
