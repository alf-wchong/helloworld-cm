//Indexer module
define([
    // Application.
    "app",
    "module",
    "oc",
    "modules/indexer/indexer",
    "modules/externalEventsModule",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-util"
],

function(app, module, OC, Indexer, ExternalEventsModule, CATUtil) {

    // Create a new module.
    var IndexerSuggestionEnabled = app.module();
    //Currently alfresco specific and should be configurable to include other repos
    this.RELATION_NAME = "{http://www.tsgrp.com/model/hpi/1.0}childDocuments";

    IndexerSuggestionEnabled.Views.Layout = Indexer.Views.Layout.extend({
        template: "indexer/indexersuggestionenabled",
        className: 'indexer-view',
        model: Indexer.DocumentModel,

        events: {
            "click #indexer-save-and-next-btn": "saveAndNext",
            "click #indexer-save-and-exit-btn": "saveAndExit",
            "click #indexer-exit-btn": "safeExit",
            "click #indexer-ext-service-btn": "launchExtModal",
            "focus .form-control": "initiateIndexerAnnotation",
            "blur .form-control": "inputBoxDeselected",
            "click .slick-row": "gridRowClicked",
            "click #indexer-tableSelect-btn": "tableSelectModeOn"
        },
        cleanup: function() {
            if(this.subscription) {
                this.subscription.dispose();
            }
            Indexer.Views.Layout.prototype.cleanup.call(this);
        },
        startListening: function() {
            Indexer.Views.Layout.prototype.startListening.call(this);
            this.listenTo(this.indexerBus, "propertiesViewCreated", function() {
                if(this.propertiesView) {
                    this.subscribeOnceToPrimaryKeyChange();
                }
            });

        },
        processControlValueChanges: function(newValue, control) {

            //Don't override location data if it is supposed to be preserved or isn't enabled
            if(control.preserveLocationData()  || !this.positionDataEnabled) {
                return;
            }

            Indexer.Views.Layout.prototype.processControlValueChanges.call(this, newValue, control);

            //Remove any existing correction data for this attribute as well
            //NOTE: in the future if we're returing attr values in addition to locations, we'll want
            //to modify this cleanup to remove only locations.
            this.corrections = _.omit(this.corrections, control.id);
        },
        initializeSuggestionData: function() {
            var self = this;

            //Set suggestR specific variables here
            this.suggestions = {};
            this.acceptingCorrections = false;
            this.corrections = {};

            //Add document to suggestion engine DB
            this.addDocumentToSuggestionEngine()
            .done(function(suggestionDocId) {
                self.suggestionDocId = suggestionDocId;

                // Check if we already have a valid primary key and if so, we will
                // accept any corrections.
                if(self.fingerprintAttributeCollection && self.fingerprintAttributeCollection.at(0)) {
                    var primaryKeyOcAttrName = self.fingerprintAttributeCollection.at(0).get("attrOCName");

                    if(self.oco.get("properties")[primaryKeyOcAttrName]) {
                        self.acceptingCorrections = true;
                        self.primaryKey = self.oco.get("properties")[primaryKeyOcAttrName];
                    }
                }
            })
            .fail(function(errorResponse) {
                //This error is unrecoverable for suggestion mode
                var responseText = JSON.parse(errorResponse.responseText);
                var errorHeader = window.localize("indexer.indexer.addDocumentFailure");
                self.displayCustomErrorMessage(errorHeader, responseText.message);
            });
        },
        subscribeOnceToPrimaryKeyChange: function() {
            var self = this;

            if(this.fingerprintAttributeCollection && this.fingerprintAttributeCollection.at(0)) {

                //Find the primary key
                var primaryKeyControl = _.find(this.propertiesView.propertiesViewModel.controls(), function(value) {
                    // return the control with objectName as the id
                    return value.id === this.fingerprintAttributeCollection.at(0).get("attrOCName");
                }, this);

                if(!primaryKeyControl) {
                    return;
                }

                //Subscribe once to primary key value change
                self.subscription = primaryKeyControl.value.subscribe(_.debounce(function(newValue) {
                    self.subscription.dispose();
                    self.primaryKey = newValue;

                    if(self.primaryKey) {
                        self.generateSuggestionsWithPrimaryKey(self.primaryKey);
                    } else {
                        self.subscribeOnceToPrimaryKeyChange();
                    }
                }, 500));
            }
        },
        generateSuggestionsWithPrimaryKey: function(pkValue) {
            var self = this;

            self.updateDocumentPrimaryKey(pkValue)
            .then(function() {
                return self.getSuggestions();
            })
            .then(function(response) {
                var result = JSON.parse(decodeURIComponent(response));
                self.processTemplateSuggestionResults(result);
            })
            .fail(function(errorResponse) {
                var responseText = JSON.parse(errorResponse.responseText);
                app.trigger("alert:error", {
                    header: window.localize("indexer.indexer.suggestionFailure"),
                    message: responseText.message
                });
            })
            .always(function() {
                self.subscribeOnceToPrimaryKeyChange();
            });
        },
        getSuggestions: function() {
            var data = {
                'objectId': this.oco.get("objectId"),
                'suggestionDocumentId': this.suggestionDocId
            };
            return $.ajax({
                url: app.serviceUrlRoot + "/docAnalysis/getSuggestions",
                type: "POST",
                data: data
            });
        },
        getTableSuggestions: function(coords) {
            var data = JSON.stringify(CATUtil.captureCoordsToSuggestionCoords(coords, this.docHeight));
            var queryString = $.param({
                "objectId": this.oco.get('objectId'),
                "objectType": this.objectType,
                "primaryKey": this.primaryKey
            });

            $.ajax({
                url: app.serviceUrlRoot + '/docAnalysis/getTableExtractionMap?' + queryString,
                type: "POST",
                contentType: "application/json",
                context: this,
                data: data,
                success: function(tableExtractionMap) {
                    var jsonValuesMap = JSON.parse(tableExtractionMap);

                    // Merge jsonValuesMap with existing properties
                    var existingValues = this.propertiesView.propertiesViewModel.getValues();
                    var combinedValues =  _.extend({}, existingValues, jsonValuesMap);

                    // unsubscribe from primary key before updating props, so we don't trigger another change
                    this.subscription.dispose();

                    // set values on the form
                    this.propertiesView.propertiesViewModel.setValuesPreserveLocationData(combinedValues);

                    // resubscribe to the primary key
                    this.subscribeOnceToPrimaryKeyChange();
                },
                error: function(errorResponse) {
                    var responseText = JSON.parse(errorResponse.responseText);
                    app.trigger("alert:error", {
                        header: window.localize("indexer.indexer.extractTableFailure"),
                        message: responseText.message
                    });
                },
            });
        },
        processTemplateSuggestionResults: function(suggestionMap) {

            //Store attribute value types for use when returning feedback
            this.suggestions = {};
            this.acceptingCorrections = true;

            //Process results and map them to properties
            _.each(suggestionMap.suggestionModels, function(suggestionModel) {
                this.processAttributeSuggestion(suggestionModel, this.suggestions);
            }, this);

            //Get current property values
            var curValues = this.propertiesView.propertiesViewModel.getValues();

            //Don't set suggestions for any primary key attributes
            var primaryKeyNames = [];
            this.fingerprintAttributeCollection.each(function(attr) {
                primaryKeyNames.push(attr.get("attrOCName"));
            }, this);
            this.suggestions = _.omit(this.suggestions, primaryKeyNames);

            //Don't set suggestions for attributes that aren't on the form
            var controls = this.propertiesView.propertiesViewModel.controls();
            var formAttrs = [];
            _.each(controls, function(control) {
                formAttrs.push(control.id);
            });
            this.suggestions = _.pick(this.suggestions, formAttrs);

            //At this point all suggestions are valid and location metadata can be set
            this.storeAttributeLocations(this.suggestions);

            //Generate a map of attrOCName: textValue to store property values
            var suggestionText = {};
            _.each(this.suggestions, function(suggestion, attr) {
                if(suggestion.text) {
                    suggestionText[attr] = suggestion.text;
                }
            });

            //For values that appear to be string representations of dates, store the unix time instead
            var validDateFormats = module.config().acceptedDateFormats;
            _.each(suggestionText, function(suggestionValue, propertyId) {
                var curControl = _.findWhere(controls, {id: propertyId});
                if(curControl.controlType === "DateBox" && moment(suggestionValue, validDateFormats).isValid()) {
                    suggestionText[propertyId] = Number(new Date(suggestionValue));
                }
            });

            //Set properties that suggestion engine found
            var combinedValues =  _.extend({}, curValues, suggestionText, suggestionMap.tableData);
            this.propertiesView.propertiesViewModel.setValuesPreserveLocationData(combinedValues);
        },
        processAttributeSuggestion: function(suggestionModel, suggestionMap) {

            //Determine whether kv or zonal result should be used
            //This logic should move to SuggestR, where a more accurate
            //decision can be made.
            var attr = suggestionModel.attrOCName;
            var acceptedCoords, acceptedValue, suggestionType;

            //If no candidates are provided, do nothing
            if(!suggestionModel.zonalCandidate && !suggestionModel.kvCandidate) {
                return;

            //Else if only one candidate is provided, use that one
            } else if(suggestionModel.zonalCandidate && !suggestionModel.kvCandidate) {
                suggestionType = "zonal";
            } else if (suggestionModel.kvCandidate && !suggestionModel.zonalCandidate) {
                suggestionType = "keyValue";

            //Else if both are provided and at least one has text, use whichever one has text (tiebreaker goes to zonal)
            } else if(suggestionModel.zonalCandidate.text) {
                suggestionType = "zonal";
            } else if(suggestionModel.kvCandidate.text) {
                suggestionType = "keyValue";            
            
            //Else if both are provided and neither has text, set type to "both" with 
            //empty text and coordinates return. This allows the feedback loop to 
            //provide corrections for both types if the user makes a correction.
            } else {
                suggestionType = "both";
            }

            //Set other variables based on suggestionType
            switch(suggestionType) {
                case "zonal":
                    acceptedValue = suggestionModel.zonalCandidate.text;
                    acceptedCoords = suggestionModel.zonalCandidate.coordinatesModel;
                    break;
                case "keyValue":
                    acceptedValue = suggestionModel.kvCandidate.text;
                    acceptedCoords = suggestionModel.kvCandidate.coordinatesModel;
                    break;
                default:
                    acceptedValue = "";
                    acceptedCoords = "";
            }

            //Store accepted data
            suggestionMap[attr] = {
                text: acceptedValue,
                location: [CATUtil.suggestionCoordsToTSCoords(acceptedCoords, this.docHeight)],
                type: suggestionType
            };
        },
        storeAttributeLocations: function(suggestionMap) {
            if(this.positionDataEnabled) {
                
                //Create the positional metatdata map if it doesn't exist yet
                var ocoProps = this.oco.get("properties");
                var posProp = ocoProps[this.positionalAttr];
                if (!posProp) {
                    posProp = '{}';
                }
                posProp = JSON.parse(posProp);

                //Update the positional metadata for each attribute
                _.each(suggestionMap, function(suggestion, attr) {
                    if(suggestion.location && suggestion.text) {
                        posProp[attr] = suggestion.location;
                    }
                });
                
                //Save the stringified positional metadata map back to the oco
                ocoProps[this.positionalAttr] = JSON.stringify(posProp);
                this.oco.set("properties", ocoProps);
            }
        },
        fetchOcoSuccess: function() {
            var self = this;
            Indexer.Views.Layout.prototype.fetchOcoSuccess.call(this);

            //Suggestion engine specific stuff
            self.objectType = self.oco.get('objectType');

            //Get template config
            app.context.configService.getTemplateManagementConfig('default', function(templateConfig) {
                var objectTypeTemplateConfig = templateConfig.get('captureTemplateConfig').get('configuredTypes').findWhere({"objectType": self.objectType});
                var objectTypeTemplateCollection = objectTypeTemplateConfig.get("existingTemplates");
                self.fingerprintAttributeCollection = objectTypeTemplateCollection.at(0).get("fingerprintAttributes");
                
                // grab the template's oco
                var templateName = objectTypeTemplateCollection.at(0).get("templateFileName");
                CATUtil.searchForTemplate(templateName).done(function(templateModel) {
                    self.templateOco = templateModel;
                    self.initializeSuggestionData();
                })
                .fail(function(errorResponse) {
                    //This error is unrecoverable for suggestion mode
                    var responseText = JSON.parse(errorResponse.responseText);
                    var errorHeader = window.localize("indexer.indexer.fetchTemplateFailure");
                    self.displayCustomErrorMessage(errorHeader, responseText.message);
                });
            });

            //Get document height
            var queryString = $.param({
                "id": self.oco.get('properties').objectId,
                "lastModified": self.oco.get('properties').modifiedDate
            });
            $.ajax({
                url: app.serviceUrlRoot + "/annotation/getDocumentInfo?" + queryString,
                type: "GET"
            }).done(function(data) {
                self.docHeight = data.pages[0].height;
            }).fail(function(errorResponse) {
                var responseText = JSON.parse(errorResponse.responseText);
                var errorHeader = window.localize("indexer.indexer.fetchDocPropertiesFailure");
                self.displayCustomErrorMessage(errorHeader, responseText.message); 
            });
        },
        saveAndExit: function() {
            this.processCorrections();
            Indexer.Views.Layout.prototype.saveAndExit.call(this);
        },
        saveAndNext: function() {
            this.processCorrections();
            Indexer.Views.Layout.prototype.saveAndNext.call(this);
        },
        tableSelectModeOn: function() {
            if($('#indexer-tableSelect-btn').hasClass('active')) {
                this.tableSelectMode = false;
                $('#indexer-tableSelect-btn').removeClass('active');
            } else {
                this.tableSelectMode = true;
                $('#indexer-tableSelect-btn').addClass('active');
                ExternalEventsModule.intiateTableSelectMode.call(this, event, this.propertiesView.propertiesViewModel);
            }
        },
        processCorrections: function() {
            var self = this;

            //Check for any corrections
            if(this.acceptingCorrections) {

                //For each correction, figure out if zonal or kv should be updated
                var suggestionList = [];
                _.each(self.corrections, function(coords, attrOCName) {

                    //Coords is originally an array of textSelect rectangles, must be
                    //transformed to a single suggestion rectangle
                    coords = CATUtil.tsCoordsToSuggestionCoords(CATUtil.joinTSRectangles(coords), self.docHeight);
                    
                    //Send feedback to the suggestion engine based on the type determined
                    //when originally getting suggestions. If the attribute is new, send back
                    //zonal feedback.
                    var suggestionModel = {};
                    suggestionModel.attrOCName = attrOCName;
                    var candidateModel = {
                        coordinatesModel: coords
                    };
                    if(!_.has(self.suggestions, attrOCName) ||
                        self.suggestions[attrOCName].type === "zonal") {
                        suggestionModel.zonalCandidate = candidateModel;
                    } else if (self.suggestions[attrOCName].type === "keyValue") {
                        suggestionModel.kvCandidate = candidateModel;
                    } else if (self.suggestions[attrOCName].type === "both"){
                        suggestionModel.zonalCandidate = candidateModel;
                        suggestionModel.kvCandidate = candidateModel;
                    }
                    suggestionList.push(suggestionModel);
                });

                //Don't make call if nothing to update
                if(suggestionList.length === 0) {
                    return;
                }

                var suggestionCollection = {
                    documentId: self.suggestionDocId,
                    suggestionModels: suggestionList
                };

                var data = JSON.stringify(suggestionCollection);

                var queryString = $.param({
                    "objectId": self.oco.get("objectId")
                });

                //Update
                $.ajax({
                    url: app.serviceUrlRoot + '/docAnalysis/addSuggestionFeedback?' + queryString,
                    type: "PUT",
                    contentType: "application/json",
                    data: data
                });
            }
        },
        addDocumentToSuggestionEngine: function() {
            // Use the current SuggestR doc ID if it exists on the oco props, else add
			// document to suggestion engine DB.
            if(this.oco.get("properties").hpi_suggestrDocId) {
                return $.Deferred().resolve(this.oco.get("properties").hpi_suggestrDocId);
            } else {
                var suggestionTemplateId = this.templateOco.get("properties").tsgSuggestrTemplateId;
                var docId = this.oco.get("objectId");

                var queryString = $.param({
                    "suggestionTemplateId": suggestionTemplateId,
                    "objectId": docId,
                    "verified": false
                });

                //Add document behind the template to suggestion engine
                return $.ajax({
                    url: app.serviceUrlRoot + '/docAnalysis/addNewDocument?' + queryString,
                    type: "POST",
                    contentType: "application/json"
                });
            }
        },
        updateDocumentPrimaryKey: function(newPK) {

            //Reset correction map since any corrections for an old primary key are useless
            this.corrections = {};

            //Make ajax call to update suggestion engine backend
            var queryString = $.param({
                "suggestionDocumentId": this.suggestionDocId,
                "newPrimaryKey": newPK
            });

            return $.ajax({
                url: app.serviceUrlRoot + '/docAnalysis/updateDocumentPK?' + queryString,
                type: "PUT"
            });

        }
    });

    return IndexerSuggestionEnabled;

});