//Indexer module
define([
    // Application.
    "app",
    "oc",
    "handlebars",
    "slickgrid",
    "module",
    "modules/common/hpiconstants",
    "modules/common/ocquery",
    "modules/common/action",
    "modules/common/splitdocumentsview",
    "modules/common/propertiesview",
    "modules/services/exitservice",
    "modules/externalEventsModule"
],

function(app, OC, Handlebars, SlickGrid, module, HPIConstants, OCQuery, Action, SplitDocumentsView, PropertiesView, ExitService, ExternalEventsModule) {

    // Create a new module.
    var Indexer = app.module();
    //Currently alfresco specific and should be configurable to include other repos
    this.RELATION_NAME = "{http://www.tsgrp.com/model/hpi/1.0}childDocuments";

    //Indexer Model, represents a single document.
    Indexer.DocumentModel = Backbone.Model.extend({
        defaults: function() {
            return {
                objectId: "",
                formConfig: {},
                dashletConfig: null,
                indexOrSplit: window.localize("indexer.layout.indexing"),
                oaMode: "pageSelect",
                showParentDoc: true
            };
        }
    });
    //Map we use to get the values from the placeholders set in the indexer config
    Indexer.PlaceholderMap = {
        currentUser: function() {
            return app.user.get("displayName");
        },
        currentDate: function() {
            return Number(new Date());
        }

    };

    // Container View.
    Indexer.Views.Layout = Backbone.Layout.extend({
        template: "indexer/indexer", //NOTE: Refers to the indexer/indexer.html file 
        className: 'indexer-view',
        model: Indexer.DocumentModel, //NOTE: Defines the model for this view.

        events: {
            "click #indexer-save-and-next-btn": "saveAndNext",
            "click #indexer-save-and-exit-btn": "saveAndExit",
            "click #indexer-exit-btn": "safeExit",
            "click #indexer-ext-service-btn": "launchExtModal",
            "focus .form-control": "initiateIndexerAnnotation",
            "blur .form-control": "inputBoxDeselected",
            "click .slick-row": "gridRowClicked"
        },

        // NOTE: Used to perform startup operations when the view is initialized (but before it is rendered onto the DOM).
        initialize: function() {
            var self = this;

            this.config = this.options.config;

            app.idToUnlock = this.model.get("objectId");

            this.getRedirectLocation();

            this.options.canChangeType = this.config.get("changeTypeInIndexer");

            this.getTotalPages();
            this.options.autoSaveChanges = this.config.get("autoSaveInIndexer");

            this.indexerBus = _.extend({}, Backbone.Events); 

            self.startListening();

            //Use for the index/Split toggle button.
            Handlebars.registerHelper("setChecked", self.setChecked);

            if(this.options.oco) {
                this.oco = this.options.oco;
                self.fetchOcoSuccess();
            } else {
                this.oco = new OC.OpenContentObject({
                    objectId: this.model.get("objectId")
                });
                self.fetchInitialOco();
            }

            //Positional Data Objects
            this.positionalAttr = module.config().positionalAttribute || HPIConstants.hpiMetadataPositions;
        },
        afterRender: function() {
            var self = this;
            // Our view might not be initialized when we first render.   OH GOD TIMING ISSUES
            if (this.propertiesView) {
                this.setView(".properties-view-oulet", this.propertiesView).render();
            }
            if (this.selectedSplitsView) {
                this.setView(".subdocument-view-outlet", this.selectedSplitsView).render();
            }

            ExitService.register('indexing.unlock', function() {
                //save the user preferences if it exists - async code won't work here
                self.checkIn();
            });
        },
        // NOTE: Used to pass information into this View's template before it is rendered to the DOM. 
        serialize: function() {
            var queue = true;
            if (this.location === window.localize("indexer.layout.dashboard")) {
                queue = false;
            }
            return {
                docId: this.model.get("objectId"),
                formName: this.config.get("form"),
                oaURL: app.openAnnotateURL,
                oaUserName: app.user.get("loginName"),
                showError: this.errorMessage ? true : false,
                errorMessage: this.errorMessage,
                oaMode: (this.config.get("allowSplitPdf") ? "pageSelect" : "indexer"),
                showSubDocs: true,
                pageSelectButtonLabel: "Add Section",
                pageSelectEventName: "addSection",
                indexOrSplit: this.model.get("indexOrSplit"),
                queue: queue,
                tableSelectMode: this.tableSelectMode
            };
        },
        cleanup: function() {
            ExitService.deregister('indexing.unlock');
        },
        processControlValueChanges: function(newValue, control) {
            
            //Don't override location data if it is supposed to be preserved or isn't enabled
            if(control.preserveLocationData() || !this.positionDataEnabled) {
                return;
            }

            //Otherwise remove positional data from the changed attribute
            var ocoProps = this.oco.get("properties");
            var positionalData = JSON.parse(ocoProps[this.positionalAttr] || '{}');
            positionalData = _.omit(positionalData, control.id);
            ocoProps[this.positionalAttr] = JSON.stringify(positionalData);
        },
        getTotalPages: function() {
            var self = this;

            this.totalPages = [];
            //Get the total page count of the document we are currently indexing.
            $.ajax({
                url: app.serviceUrlRoot + '/pdf/pageCount?pdf=' + this.model.get('objectId'),
                type: "GET",
                success: function(pages) {
                    self.totalPages = _.range(1, pages + 1);
                },
                error: function() {
                    self.model.set("oaMode", "readOnly");
                }
            });
        },
        setChecked: function(value, currentValue) {
            if (value == currentValue) {
                return "checked = true";
            } else {
                return "";
            }
        },
        indexerFormIsValid: function(result) {
            //Checks whether the form has all required attrs filled out or not.
            this.isValid = result.isValid;
        },
        //Listen for when the the split doc needs to be previewed
        indexerSplitPDFPreviewRange: function(pageRange) {
            var objectId = this.model.get("objectId");
            //Opens the document in a new tab for the user to preview the document before/after selecting it
            window.open(app.serviceUrlRoot + "/content/getPDFSection?id=" + objectId + "&range=" + pageRange);
        },
        startListening: function(){
            //Checks whether the form has all required attrs filled out or not.
            this.listenTo(app, 'indexer:formIsValid', this.indexerFormIsValid);
            
            //Listen for when one of the split docs needs to be deleted.
            this.listenTo(app, "deleteSplitPages", this.deleteSplitPages);
            
            //Listen for when the the split doc needs to be previewed
            this.listenTo(app, "IndexerSplitPDF:previewRange", this.indexerSplitPDFPreviewRange);
            
            //When the form needs to be updated with a split doc's metadata.
            this.listenTo(app, "replacePropertiesView", this.replacePropertiesView);

            //When the form needs to be updated with a split doc's metadata.
            this.listenTo(app, "showNewPropertiesView", this.showNewPropertiesView);

            //When the form needs to have the parent doc's metadata in the form.
            this.listenTo(app, "showParentDocProperties", this.showParentDocProperties);

            //Listen for when the add section button in the iframe is clicked.
            this.listenTo(app.openAnnotate, 'addSection', this.addSection);
        },
        fetchLockSuccess: function(objectProperties) {
            var self = this;
            // We need to set the lockOwner on our properties to finish indexing and unlock the document 
            // when exiting without saving
            self.oco.get("properties").lockOwner = app.user.get("loginName");

            if (objectProperties.hpi_indexStatus !== "New") {
                //If the document index status is done, the document has been completed so the user cannot
                //edit the document and will see a message.
                if (objectProperties.hpi_indexStatus === "Done") {
                    app.idToUnlock = null;
                    app.trigger("alert:error", {
                        header: window.localize("indexer.layout.indexingWarning"),
                        message: window.localize("indexer.layout.finishedIndexing"),
                        confirm: function() {
                            // Lock the current document for indexing. 
                            $.ajax({
                                url: app.serviceUrlRoot + '/content/unlockDocument?id=' + self.model.get('objectId'),
                                type: "GET",
                                success: function() {
                                    self.navigateToDashboard();
                                    app.idToUnlock = null;
                                }
                            });
                        }
                    });
                } else if (objectProperties.hpi_indexStatus === undefined) {
                    app.trigger("alert:error", {
                        header: window.localize("indexer.layout.indexingWarning"),
                        message: window.localize("indexer.layout.noIndexStatus"),
                        confirm: function() {
                            // Lock the current document for indexing. 
                            $.ajax({
                                url: app.serviceUrlRoot + '/content/unlockDocument?id=' + self.model.get('objectId'),
                                type: "GET",
                                success: function() {
                                    self.navigateToDashboard();
                                    app.idToUnlock = null;
                                }
                            });
                        }
                    });
                } else if (objectProperties.hpi_indexStatus === "Indexing") {
                    self.initializeDocument();
                }
            }
            //If the index status is new, the user can enter the indexing screen and edit the properties.
            else {
                self.initializeDocument();
            }
        },
        fetchOcoSuccess: function() {
            var self = this;

            var objectProperties = self.oco.get("properties");

            //Check whether position data should be stored based on
            //configuration for the current document's object type
            this.positionDataEnabled = false;
            var typeConfig = this.config.get("types").findWhere({ocName: this.oco.get("objectType")});
            if(typeConfig) {
                this.positionDataEnabled = typeConfig.get("positionDataEnabled");
            }

            //If the currentUser is the one to have locked the document, they have the ability
            //to access and edit the document still. 
            if (objectProperties.lockOwner === app.user.get("loginName")) {
                self.initializeDocument();
            }
            //If the user doesn't currently have the lock, then the document needs to be checked out.
            else {
                // Lock the current document for indexing. 
                $.ajax({
                    url: app.serviceUrlRoot + '/content/lockDocument?id=' + self.model.get('objectId'),
                    type: "GET",
                    success: function() {
                        self.fetchLockSuccess(objectProperties);
                    },
                    error: function() {
                        self.displayErrorMessage(window.localize("indexer.layout.documentLocked"));
                    }

                });

            }
        },
        fetchInitialOco: function() {
            var self = this;

            self.oco.fetch({
                success: function() {
                    self.fetchOcoSuccess();
                },
                error: function() {
                    self.displayErrorMessage(window.localize("indexer.layout.noObjectId"));
                }
            });
        },
        initializeDocument: function() {
            var self = this;
            // we are saving the original properties of the oco before any of the pre-indexing property values are set
            // in case the user desides to exit the indexer without saving
            this.originalProperties = _.extend({},this.oco.get("properties"));

            if (this.options.canChangeType) {
                var typeSelectorView = new Indexer.Views.TypeSelector({
                    "formName": this.config.get("form")
                });
                self.$(".indexer-controls").hide();
                self.setView(".properties-type-selector", typeSelectorView).render();
            } else {
                this.pagesUsedInSplit = [];
                var objectProperties = this.oco.get("properties");
                // Double check if objectType is allowed for Form, if it is not, show an error.
                app.context.configService.getFormConfig(self.config.get('form'), function(formConfig) {
                    var correctType = false;
                    //Loop through all configured types and compare with the type of current document
                    //the .find() will exit the loop once it finds the correct type.
                    formConfig.get("configuredTypes").find(function(typeConfig) {
                        if (self.oco.get("objectType") === typeConfig.get('ocName')) {
                            correctType = true;
                            //Get the attributes that are configured on the form, they will
                            //be used to check if the attributes are repeating or not.
                            self.primaryFormAttrs = typeConfig.get("configuredAttrsPri");
                            self.secondaryFormAttrs = typeConfig.get("configuredAttrsSec");
                        }
                    });

                    if (!correctType) {
                        //If the type of current document is not configured to the form show an error and either 
                        //continue to the next doc in queue or go back to dashboard.
                        self.displayErrorMessage(window.localize("indexer.layout.wrongObjectType"));
                    }

                    //Grabbing the pre-indexing properties that have been configured
                    //in the indexer config and setting the configured value.
                    self.setConfiguredIndexerProperties("configuredPreIndexAttrs", objectProperties, true).done(function() {
                        //Set the properties just maually created above on the oco and save.
                        self.oco.set('properties', objectProperties);

                        self.oco.save({}, {
                            success: function() {

                                //If the oco saves successfully, retrieve the correct information needed for the form.
                                self.propertiesView = new PropertiesView.PropertyList({
                                    'objectType': self.oco.get("objectType"),
                                    'properties': _.clone(self.oco.get("properties")),
                                    'formName': self.config.get("form"),
                                    'enableRequired': true,
                                    'listener': 'indexer',
                                    'controlValueChangeHandler': _.bind(self.processControlValueChanges, self)
                                });

                                self.render();
                                self.indexerBus.trigger("propertiesViewCreated");
                            },
                            //If the oco does not save, throw and error and redirect to different page.
                            error: function() {
                                self.displayErrorMessage(window.localize("indexer.layout.propertiesNotSaved"));
                            }
                        });
                    });

                    //Note this Ajax call will execute before the oco properties above are saved.
                    //Getting the child documents of the parent doc that we are indexing.
                    $.ajax({
                        url: app.serviceUrlRoot + "/content/getChildRelations?id=" + self.oco.get("objectId") +
                            "&relationName=" + self.RELATION_NAME,
                        type: "GET",
                        success: function(childOcos) {
                            //If there are child docs consider this model to have started a split.
                            if (childOcos.length > 0) {
                                self.startSplit = true;
                                self.model.set("indexOrSplit", window.localize("indexer.layout.splitting"));
                            }

                            self.splitDocs = [];
                            //Build up Document models.
                            var documents = [];
                            var fullCollection = new OC.OpenContentObjectCollection(childOcos);
                            fullCollection.each(function(oco) {
                                self.splitDocs.push({
                                    oco: oco
                                });
                                //Get oco and the currently set relation name.
                                documents.push(new SplitDocumentsView.Section({
                                    'selectedRelation': self.RELATION_NAME,
                                    'oco': {
                                        properties: oco.get("properties"),
                                        objectId: oco.get("objectId"),
                                        objectType: oco.get("objectType")
                                    },
                                    'objectId': oco.get("objectId"),
                                    'objectName': oco.get("properties").objectName,
                                    'pageRange': oco.get("properties").hpi_pageRange,
                                    'title': oco.get("properties").title
                                }));

                                //For each child doc push the page number onto the pagesUsedInSplit array if it is not already on the array. 
                                //If it is we don't need to push it on the array
                                //because the page number is already accounted for.
                                _.each(oco.get("properties").hpi_pageRange, function(page) {
                                    if (_.indexOf(self.pagesUsedInSplit, page) === -1) {
                                        self.pagesUsedInSplit.push(page);
                                    }
                                });
                            });
                            //Check to see if the oco is valid by grabbing the required properties from the form
                            //and seeing if every property has a value for each oco.
                            var requiredProps = _.filter(formConfig.get("configuredTypes").models[0].get("configuredAttrsPri").models, function(model) {
                                return model.get("required") === true;
                            });

                            var requiredProp;
                            _.each(self.splitDocs, function(doc) {
                                doc.isValid = true;
                                var numOfReqProps = 0;
                                _.each(doc.oco.get("properties"), function(val, prop) {
                                    requiredProp = _.find(requiredProps, function(reqProp) {
                                        return reqProp.get("ocName") === prop;
                                    });
                                    if (requiredProp) {
                                        if (!val || val === "") {
                                            doc.isValid = false;
                                        }
                                        numOfReqProps++;
                                    }
                                });
                                if (numOfReqProps !== requiredProps.length) {
                                    doc.isValid = false;
                                }

                            });


                            //Creating the subview that is a table of the child docs.
                            self.selectedSplitsView = new SplitDocumentsView.SelectedSplitsView({
                                'sections': documents
                            });
                        },
                        error: function() {
                            app.log.debug(window.localize("indexer.layout.errorFetchingRelation"));
                        }
                    });
                });
            }
        },

        setConfiguredIndexerProperties: function(indexState, propertyCollection, parentDoc) {
            var self = this;
            var deferred = $.Deferred();
            this.form = self.config.get("types").findWhere({ocName: self.oco.get("objectType")});

            //Grabbing all the attributes for the current objectType to be use to set the configured values.
            app.context.configService.getAdminTypeConfig(self.oco.get("objectType"), function(objectType) {
                //Grabbing either the pre-index or post-index properties that need to be configured
                //based on whether we are auto-setting on initialize or on the save.
                self.form.get(indexState).each(function(configuredproperty) {
                    var ocName = configuredproperty.get('ocName');
                    var value, processValue;
                    // set the property value to the configured valid/invalid value
                    if (self.isValid) {
                        value = configuredproperty.get('validatedValue');
                        processValue = configuredproperty.get('processValidatedValue') === "true";
                    } else {
                        value = configuredproperty.get('value');
                        processValue = configuredproperty.get('processValue') === "true";
                    }

                    // if we have processValue set to true let's run our logic to put the value on the node. Otherwise do nothing
                    if (processValue) {
                        // if the value is blank we want to null out the value in the oco
                        if (!value) {
                            propertyCollection[ocName] = null;
                        } else {
                            //The regex that can read ${aPlaceholder}.
                            var placeHolderRegex = /\$\{(.*?)\}/;
                            //Grabbing all the attributes for the current objectType to be use to set the configured values.
                            var properties = objectType.get("attrs");
                            var keys = properties.pluck("ocName");
                            _.each(keys, function(key) {
                                //If one of the properties matches one of the attributes being configured then get the 
                                //strings that match our regex we are looking for.
                                if (key === ocName) {
                                    //If the property is configured on the form, find it and check if it is repeating.
                                    self.primaryFormAttrs.find(function(attr) {
                                        if (attr.get("ocName") === key) {
                                            if (attr.get("repeating")) {
                                                self.repeating = true;
                                            } else {
                                                self.repeating = false;
                                            }
                                        } else {
                                            self.secondaryFormAttrs.find(function(attr) {
                                                if (attr.get("ocName") === key) {
                                                    if (attr.get("repeating")) {
                                                        self.repeating = true;
                                                    } else {
                                                        self.repeating = false;
                                                    }
                                                }
                                            });
                                        }
                                    });
                                    var regexMatches = value.match(placeHolderRegex);
                                    if (regexMatches !== null) {
                                        _.each(regexMatches, function(match) {
                                            if (Indexer.PlaceholderMap[match]) {
                                                //We do not want the date to be turned into a string with the replace()
                                                //so if it is curretnDate set it directly on the value without using replace()
                                                if (match === "currentDate") {
                                                    value = Indexer.PlaceholderMap[match]();
                                                    //If the attribute is repeating and also undefined, create an empty array
                                                    //and push the value on the array. If not just set the value to the attribute.
                                                    if (self.repeating) {
                                                        if (propertyCollection[key] === undefined || propertyCollection[key] === null) {
                                                            propertyCollection[key] = [];
                                                        }
                                                        propertyCollection[key].push(value);
                                                    } else {
                                                        propertyCollection[key] = value;
                                                    }
                                                } else {
                                                    value = value.replace(placeHolderRegex, Indexer.PlaceholderMap[match]());
                                                    if (self.repeating) {
                                                        if (propertyCollection[key] === undefined || propertyCollection[key] === null) {
                                                            propertyCollection[key] = [];
                                                        }
                                                        propertyCollection[key].push(value);
                                                    } else {
                                                        propertyCollection[key] = value;
                                                    }
                                                }
                                            }
                                        });
                                    } else {
                                        if (parentDoc === true) {
                                            if (self.repeating) {
                                                if (propertyCollection[key] === undefined || propertyCollection[key] === null) {
                                                    propertyCollection[key] = [];
                                                }
                                                propertyCollection[key].push(value);
                                            } else {
                                                propertyCollection[key] = value;
                                            }
                                        }
                                        //Split ocos don't want to use the global variable self.valid because that is the parent doc's form
                                        //instead use the isValid attribute we added to that doc's oco when we added the section.
                                        else {                                        
                                            if (self.repeating) {
                                                if (propertyCollection[key] === undefined || propertyCollection[key] === null) {
                                                    propertyCollection[key] = [];
                                                }
                                                propertyCollection[key].push(value);
                                            } else {
                                                propertyCollection[key] = value;
                                            }
                                        }
                                    }
                                }
                            });
                        }
                    }
                });                            
                // we are done evaluating the properties we had configured
                deferred.resolve();
            });

            return deferred.promise();
        },

        saveAndNext: function() {
            var self = this;
            //Set the form back to the parent doc's properties.
            this.showParentDocProperties();
            //If the user has started to split the document then all page numbers
            //of the parent doc must be accounted for before the user can save and exit.
            //If they haven't started to split, they can save and exit.
            if (this.startSplit) {
                self.saveWithSplit();
            } else {
                self.saveWithoutSplit();
            }
        },

        saveAndExit: function() {
            var self = this;
            //Set the form back to the parent doc's properties.
            this.showParentDocProperties();

            //Set redirect location to dashboard.
            this.location = window.localize("indexer.layout.dashboard");
            //If the user has started to split the document then all page numbers
            //of the parent doc must be accounted for before the user can save and exit.
            //If they haven't started to split, they can save and exit.
            if (this.startSplit) {
                self.saveWithSplit();
            } else {
                self.saveWithoutSplit();
            }
        },
        safeExit: function() {
            var self = this;
            
            // we don't want to save any of the properties that may have been updated by pre-indexing or autosave properties
            // so we grab the properties when the document was initialized
            var finishIndexing = this.finishIndexingActionBuilder(this.originalProperties);

            // Lock the current document for indexing. 
            finishIndexing.execute({ 
                success: function() {
                    app.idToUnlock = null;
                    self.navigateToDashboard();
                }
            });
        },
        finishIndexingActionBuilder: function(properties) {
            var self = this;
            //Have to create a new object that has 'prop1' in front of it for the action
            //executer in OC.
            var wrappedPropertiesMap = {};
            $.each(properties, function(key, item) {
                wrappedPropertiesMap["prop-" + key] = item;
            });

            //When the user finishes indexing the document we want to make sure the document
            //is unlocked and the post autoset properties are set on the doc.
            var finishIndexing = new Action.Model({
                name: 'finishIndexing',
                parameters: {
                    newType: "",
                    objectId: self.model.get("objectId"),
                    properties: wrappedPropertiesMap,
                    isContainer: false,
                    hideFileExtensions: "false"
                }
            });

            return finishIndexing;
        },
        getTypeFormErrorMessage: function() {
            var self = this;

            // get the typeForm for the current oco
            var typeForm =  this.config.get("types").findWhere({ocName: this.oco.get("objectType")});

            // return the message associated with the correct typeForm
            return typeForm.get("messageIfInvalid");
        },
        //If user has started to split documents and want to save.
        saveWithSplit: function() {
            var self = this;
            //Unhighlight the rows of child documents and unselect the pages that are currently selected.
            app.trigger("unhighlightSplitRows");

            var pageCount = 0;
            var totalPages = this.totalPages.join().split(',');
            //Check to make sure that the pages that are being used in a split
            //match the totalPages of the parent document.
            _.each(totalPages, function(totalPage) {
                _.each(self.pagesUsedInSplit, function(usedPage) {
                    if (usedPage === totalPage) {
                        pageCount++;
                    }
                });
            });

            var invalidDocs = [];
            //Put all the split docs that are invalid onto an array.
            _.each(self.splitDocs, function(doc) {
                var properties = doc.oco.get("properties");
                if (doc.isValid === false) {
                    invalidDocs.push(properties.objectName);
                }
            });
            //If all pages are accounted for save and exit can happen
            if (this.totalPages.length === pageCount) {
                var postProperties = this.oco.get("properties");
                this.oco.fetch({
                    success: function() {
                        var properties = self.oco.get("properties");
                        //Set the properties just maually created above on the oco and save.
                        _.extend(properties, postProperties);
                        if (!_.isEmpty(invalidDocs)) {
                            // get the correct error messgae from the config based on the current type
                            var errorMessage = self.getTypeFormErrorMessage();
                            app.trigger("alert:confirmation", {
                                header: window.localize("indexer.layout.indexingWarning"),
                                message: errorMessage,
                                confirm: function() {
                                    self.optimisticReLocking(properties);
                                    self.removeView(".properties-view-oulet");
                                    self.removeView(".subdocument-view-outlet");
                                    app.openAnnotate.trigger("cleanup");
                                }
                            });
                        }
                        //If the form is completely filled out, check the document in and get next doc.
                        else {
                            self.optimisticReLocking(properties);
                        }
                    }
                });
            } else {
                //Check to see what pages are not used and put them in the message.
                var pagesNotUsed = [];
                _.each(totalPages, function(page) {
                    if (_.indexOf(self.pagesUsedInSplit, page) === -1) {
                        pagesNotUsed.push(page);
                    }
                });
                app.trigger("alert:error", {
                    header: window.localize("indexer.layout.splitPdfWarning"),
                    message: window.localize("indexer.layout.pagesNeedToBeUsed") + pagesNotUsed
                });
            }
        },
        //If the user is not splitting the parent document and is saving the parent doc.
        saveWithoutSplit: function() {
            var self = this;
            var postProperties = this.oco.get("properties");

            var objectTypeBeforeFetch = this.oco.get("objectType");

            this.oco.fetch({
                success: function() {
                    var properties = self.oco.get("properties");
                    //Set the properties just maually created above on the oco and save.
                    _.extend(properties, postProperties);

                    self.oco.set("objectType", objectTypeBeforeFetch);

                    if (self.isValid === false) {
                        // get the correct error messgae from the config based on the current type
                        var errorMessage = self.getTypeFormErrorMessage();
                        app.trigger("alert:confirmation", {
                            header: window.localize("indexer.layout.indexingWarning"),
                            message: errorMessage,
                            confirm: function() {
                                self.optimisticReLocking(properties);
                                self.removeView(".properties-view-oulet");
                                self.removeView(".subdocument-view-outlet");
                                app.openAnnotate.trigger("cleanup");
                            }
                        });
                    }
                    //If the form is completely filled out, check the document in and get next doc.
                    else {
                        self.optimisticReLocking(properties);
                    }
                }
            });
        },

        optimisticReLocking: function(properties) {
            var self = this;
            app.idToUnlock = null;
            //If the current user has the lock on the document, let the document
            //be checed back in and unlocked.
            if (properties.lockOwner === app.user.get("loginName")) {
                self.checkIn();

            } else {
                //If there is no lockowner then the document will be re-checked out and locked by the
                //current user so no one else can enter the document and then checked back in with all 
                //the changes the user made. 
                if (properties.lockOwner === undefined) {
                    // Lock the current document for indexing. 
                    $.ajax({
                        url: app.serviceUrlRoot + '/content/lockDocument?id=' + this.model.get('objectId'),
                        type: "GET",
                        success: function() {
                            self.checkIn();
                        }
                    });
                }
                //If someone else has locked the document, the user will be shown an alert letting them know that 
                //due to inactivity someone else took over the document and they will be sent back to the dashboard.
                else if (properties.lockOwner !== undefined && properties.lockOwner !== app.user.get("loginName")) {
                    app.trigger("alert:error", {
                        header: window.localize("indexer.layout.indexingWarning"),
                        message: window.localize("indexer.layout.lockedBySomeoneElse"),
                        confirm: function() {
                            self.navigateToDashboard();
                        }
                    });
                }
            }
        },

        checkIn: function() {
            var self = this;

            var pageCount = 0;
            if (this.startSplit) {
                var totalPages = this.totalPages.join().split(',');
                //Check to make sure that the pages that are being used in a split
                //match the totalPages of the parent document.
                _.each(totalPages, function(totalPage) {
                    _.each(self.pagesUsedInSplit, function(usedPage) {
                        if (usedPage === totalPage) {
                            pageCount++;
                        }
                    });
                });
            }
            //If the split hasn't started or if it has and all pages are accounted for then finish indexing the doc.
            if (!this.startSplit || (this.startSplit && this.totalPages.length === pageCount && this.model.get("showParentDoc"))) {
                if (!_.isEmpty(this.splitDocs)) {
                    var ocos = [];
                    var deferreds = [];
                    _.each(self.splitDocs, function(object) {
                        var oco = object.oco;
                        var properties = oco.get("properties");
                        // since setConfiguredIndexerProperties is an async call, we create a deferred for each splitDoc and add that to an array
                        // that way we can know when all of the async calls are done
                        var deferred = $.Deferred();
                        self.setConfiguredIndexerProperties("configuredPostIndexAttrs", properties, false, object.isValid).done(function () {
                            oco.set("properties", properties);
                            ocos.push(oco);      
                            // resolve the deferred for this splitDoc        
                            deferred.resolve();              
                        });
                        deferreds.push(deferred);
                    });
                    // will run when all deferreds are done
                    $.when.apply($, deferreds).then(function () {
                        var saveAllProps = new Action.Model({
                            name: 'bulkProperties',
                            parameters: {
                                objectIds: _.map(ocos, function(oco) {
                                    return oco.get("objectId");
                                }),
                                ocos: ocos,
                                hideFileExtensions: "false"
                            }
                        });
                        saveAllProps.execute({
                            success: function() {
                                app.log.debug(window.localize("indexer.layout.splitObjectsSaved"));
                            },
                            error: function(jqXHR, textStatus) {
                                app.log.error(window.localize("indexer.layout.splitObjectsNotSaved") + textStatus);
                            }
                        });
                    });
                }
                // this can run before the deferreds array is resolved and could cause some sychronicity issues / race conditions
                this.finishIndexingDoc().done(function() {
                    var postProperties = self.oco.get("properties");
                    var finishIndexing = self.finishIndexingActionBuilder(postProperties);

                    // Lock the current document for indexing. 
                    finishIndexing.execute({
                        success: function() {
                            if (self.location === window.localize("indexer.layout.nextDoc")) {
                                self.getNextQueueDoc();
                            } else {
                                self.navigateToDashboard();
                            }

                            app.idToUnlock = null;
                        },
                        error: function() {
                            self.displayErrorMessage(window.localize("indexer.unlockingError"));
                        }
                    });
                });
            } else {
                //If not set the parent doc to new.
                self.oco.get("properties").hpi_indexStatus = "New";
                var postProperties = this.oco.get("properties");
                var finishIndexing = self.finishIndexingActionBuilder(postProperties);

                // Lock the current document for indexing. 
                finishIndexing.execute({
                    success: function() {
                        if (self.location === window.localize("indexer.layout.nextDoc")) {
                            self.getNextQueueDoc();
                        } else {
                            self.navigateToDashboard();
                        }

                        app.idToUnlock = null;
                    },
                    error: function() {
                        self.displayErrorMessage(window.localize("indexer.unlockingError"));
                    }
                });
            }
        },

        closeWindow: function() {
            window.close();
        },

        navigateToDashboard: function() {

            //Cleanup OA before navigating away from indexer
            app.openAnnotate.trigger("cleanup");
            
            Backbone.history.navigate("dashboard", {
                trigger: true
            });
        },

        finishIndexingDoc: function() {
            var self = this;

            // setConfiguredIndexerProperties is an async function so we will have to wait for it to be done to execute our logic
            var deferred = $.Deferred();
            // Fetch the updated properties from our properties form combine them with 
            //  all the properties on the oco.
            var newProperties = this.propertiesView.getValues();
            //Auto set the post indexing attributes that were configured in the indexer config.
            this.setConfiguredIndexerProperties("configuredPostIndexAttrs", newProperties, true).done(function() {
                var oldProperties = self.oco.get('properties');

                // Extend overwrites the values of any keys that exist in newProperties and oldProperties,
                //  with the value in newProperties, which includes our auto-set 'indexFinishTime' property.
                _.extend(oldProperties, newProperties);

                // Update the properties and save them to the server.
                self.oco.set('properties', oldProperties);

                deferred.resolve();
            });
            return deferred.promise();
        },
        getNextQueueDocSuccess: function(queryResults) {
            // Will get the last result.  Sort accordingly!
            var self = this;
            var nextDoc = queryResults.shift();

            // Eventual consistency sux, and means we might get the same doc out of our queue.
            while (nextDoc && nextDoc.get('objectId') === self.model.get("objectId")) {
                nextDoc = queryResults.shift();
            }

            self.url = 'indexer/';
            if (nextDoc) {
                var nextDocId = nextDoc.get('objectId');
                self.url += self.config.get("name") + '/' + self.model.get('dashletConfig').get('dashletId') + '/queued/' + encodeURIComponent(nextDocId) + '/index';
            } else {
                self.url += encodeURIComponent(self.model.get("objectId")) + '/postIndexing';

                //Clean up OA since finished indexing documents
                app.openAnnotate.trigger("cleanup");
            }

            Backbone.history.navigate(self.url, {
                trigger: true,
                replace: true
            });
        },
        //Naviagtes to the next doc in the indexing queue.
        getNextQueueDoc: function() {
            var self = this;

            this.getQueryResults({
                success: function(queryResults) {
                    self.getNextQueueDocSuccess(queryResults);
                },
                error: function() {
                    //Gives an error if the system cannot retrieve the documents in the queue.
                    self.displayErrorMessage(window.localize("indexer.layout.queueQueryError"));
                }
            });
        },
        buildQuery: function(dSearchConfig) {
            // Get the mode that we're doing our paging in - server means we'll reach out to the server for new
            // results, client means we'll get all the results at once and move through them client-side.
            
            var self = this;
            var mode = dSearchConfig.get("enablePaging") ? "server" : "client";
            var query = new OCQuery.Collection([], {
                //Set our mode.
                mode: mode,
                state: {
                    // Default to a pagesize of 10 to start.
                    pageSize: 10,
                    // Default sorting to modified date.                  
                    sortKey: (dSearchConfig.get("sortAttribute") ? dSearchConfig.get("sortAttribute") : "modifiedDate"),
                    // the order to use for sorting, -1 for asc, 1 for desc
                    order: (dSearchConfig.get("sortOrder") ? dSearchConfig.get("sortOrder") : -1)
                }
            });

            // Build up our search parameters based on the criteria in the configuration.
            query.searchParameters = [];
            _.each(dSearchConfig.get("criteria"), function(item) {
                var value;
                if (item.isProximityOperator) {
                    value = self.buildProximitySearchValue(item.operator, item.proximityNumber, item.proximityTimeSpan);
                } else {
                    value = self._tokenResolve(item.value);
                }
                var sp = {
                    // The attribute we're searching on
                    paramName: item.attribute,
                    // The value of the attribute we're searching on
                    paramValue: value,
                    // This is a property we're searching on
                    paramType: "property",
                    operator: item.operator
                };
                query.searchParameters.push(sp);
            });

            // Add another search parameter for the type the user configured in the admin
            var sp = {
                paramName: dSearchConfig.get("type"),
                paramValue: dSearchConfig.get("type"),
                paramType: "type"
            };
            query.searchParameters.push(sp);
            
            return query;
        },
        getQueryResults: function(options) {
            var self = this;
            var dSearchConfig = this.model.get('dashletConfig');

            if (dSearchConfig) {
                //Build our query collection - this is a backbone pageable collection.
                var query = self.buildQuery(dSearchConfig);

                // Execute our query
                query.fetch({
                    success: options.success,
                    error: options.error
                });
            } else {
                //If the document is not part of the queue the user will be redirected to the dashboard instead of trying to fetch documents in the queue.
                self.navigateToDashboard();
            }
        },
        //wWnt to create the proper error message based on whether the document has the dashletConfig for the queue or not.
        getRedirectLocation: function() {
            var self = this;
            var dSearchConfig = this.model.get('dashletConfig');
            if (dSearchConfig) {
                self.location = window.localize("indexer.layout.nextDoc");
            } else {
                self.location = window.localize("indexer.layout.dashboard");
            }
        },
        //Provides and cleaner and efficient way of placing the error messages.
        displayErrorMessage: function(specificErrorMessage) {
            var self = this;
            this.getRedirectLocation();
            var errorMessage = specificErrorMessage + this.location;
            app.trigger("alert:error", {
                header: "Indexing Error",
                message: errorMessage,
                confirm: function() {
                    if (self.location === window.localize("indexer.layout.dashboard")) {
                        self.navigateToDashboard();
                    } else {
                        self.getNextQueueDoc();
                    }
                }
            });
            this.render();
        },
        displayCustomErrorMessage: function(errorHeader, errorMessage) {
            var self = this;
            this.getRedirectLocation();
            app.trigger("alert:error", {
                header: errorHeader,
                message: errorMessage,
                confirm: function() {
                    if (self.location === window.localize("indexer.layout.dashboard")) {
                        self.navigateToDashboard();
                    } else {
                        self.getNextQueueDoc();
                    }
                }
            });
        },
        // gGt the information from the selected input box and send a message to OA that we are going to use property indexing.
        initiateIndexerAnnotation: function(event) {
            if (this.options.autoSaveChanges) {
                if (!this.propertiesView) {
                    return;
                }
                // Fetch the updated properties from our properties form combine them with
                //  all the properties on the oco.
                var newProperties = this.propertiesView.getValues();
                var oldProperties = this.oco.get('properties');
                // Extend overwrites the values of any keys that exist in newProperties and oldProperties,
                //  with the value in newProperties, which includes our auto-set 'indexFinishTime' property
                _.extend(oldProperties, newProperties);
                // Update the properties and save them to the server.
                this.oco.set('properties', oldProperties);
                this.oco.save({}, {
                    global: false
                });
            }

            if (!this.hasBoxSelected && app.openAnnotate) {
                ExternalEventsModule.initiateIndexerAnnotation.call(this, event, this.propertiesView.propertiesViewModel, this.oco);
            }
        },

        // If we click of off an input box, we want to remove the information that we stored about it 
        //and stop our "finishIndexing" listener so it doesn't accidentally update the property.
        inputBoxDeselected: function() {
            app.trigger("blurInputBox");
        },

        addSection: function(selectedPages) {
            var self = this;
            var newProperties = this.propertiesView.getValues();
            var oldProperties = this.oco.get('properties');
            // Extend overwrites the values of any keys that exist in newProperties and oldProperties,
            //  with the value in newProperties, which includes our auto-set 'indexFinishTime' property
            _.extend(oldProperties, newProperties);
            this.oco.set('properties', oldProperties);
            this.oco.save({}, {
                global: false
            });

            //Deep copying the parent doc's properties to use to set on the new split documents.
            var ocoProperties = JSON.parse(JSON.stringify(this.oco.get("properties")));
            //The name of the split document is the original docs name + current date/time so the name is alwasys unique.
            var dotIndex = this.originalProperties.objectName.lastIndexOf(".");
            if (dotIndex == -1) {
                ocoProperties.objectName = this.originalProperties.objectName + Number(new Date());
            } else {
                ocoProperties.objectName = this.originalProperties.objectName.substring(0, dotIndex) + Number(new Date()) + this.originalProperties.objectName.substring(dotIndex);
            }
            ocoProperties.hpi_pageRange = [];
            //Add the pages of the new section to the oco.
            _.each(selectedPages, function(page) {
                ocoProperties.hpi_pageRange.push(page.toString());
            });
            //The new child docs should have their status be set to "new" rather than "indexing".
            //ocoProperties.hpi_indexStatus = "Split";
            ocoProperties.lockOwner = undefined;
            var pageRange = JSON.parse(JSON.stringify(selectedPages));

            var wrappedPropertiesMap = {};
            $.each(ocoProperties, function(key, item) {
                wrappedPropertiesMap["prop-" + key] = item;
            });
            //The new document being created in the repository.
            var splitPdf = new Action.Model({
                name: 'splitPdf',
                parameters: {
                    objectId: this.model.get("objectId"),
                    splits: [{
                        pageRange: pageRange.toString(),
                        oco: {
                            objectType: self.oco.get("objectType"),
                            objectName: ocoProperties.objectName,
                            properties: wrappedPropertiesMap
                        }
                    }]
                }
            });
            splitPdf.execute({
                success: function(data) {

                    app.openAnnotate.trigger("pageSelectionRequested", []);

                    //The first time a user starts to split a document startSplit is set to true.
                    if (!this.startSplit) {
                        self.startSplit = true;
                        $(".mode-header-label").text("Document " + window.localize("indexer.layout.splitting"));
                    }
                    //For each page in the split add to our pagesUsedInSplit array if they
                    //are not already there.
                    _.each(selectedPages, function(page) {
                        if (_.indexOf(self.pagesUsedInSplit, page.toString()) === -1) {
                            self.pagesUsedInSplit.push(page.toString());
                        }
                    });
                    var docName = _.keys(data.result)[0];
                    var newObjectId = data.result[docName].objectId;
                    //Check to see if the the split doc is completely filled out or not.
                    var isValid;
                    if (self.isValid === true) {
                        isValid = true;
                    } else {
                        isValid = false;
                    }
                    //Create new oco that we can store locally.
                    var newOco = new OC.OpenContentObject({
                        objectId: newObjectId
                    });
                    ocoProperties.objectId = newObjectId;

                    newOco.set("properties", ocoProperties);
                    newOco.set("objectType", self.oco.get("objectType"));


                    self.splitDocs.push({
                        oco: newOco,
                        isValid: isValid
                    });
                    //Create the subview or of the subview already exists add a new table row with the info of the new child doc.
                    if (self.selectedSplitsView) {
                        self.selectedSplitsView.addSection({
                            objectId: newObjectId,
                            objectType: self.oco.get("objectType"),
                            objectName: ocoProperties.objectName,
                            properties: ocoProperties
                        }, pageRange, null, isValid);
                    } else {
                        self.selectedSplitsView = new SplitDocumentsView.SelectedSplitsView({});
                        self.selectedSplitsView.addSection({
                            objectId: newObjectId,
                            objectType: self.oco.get("objectType"),
                            objectName: ocoProperties.objectName,
                            properties: ocoProperties
                        }, pageRange, null, isValid);
                    }

                },
                error: function() {
                    app.trigger("alert:error", {
                        header: window.localize("indexer.layout.splitPDFError"),
                        message: window.localize("indexer.layout.docNotAddedToRepo")
                    });
                }
            });
        },

        deleteSplitPages: function(deletedPages, name) {
            var self = this;
            //For each page in the sub document that is being deleted remove it from the
            //pagesUsedInSplit because they are no longer need to be used and need to be 
            //accounted for approriately. 
            _.each(deletedPages, function(page) {
                var index = _.indexOf(self.pagesUsedInSplit, page.toString());
                if (index !== -1) {
                    self.pagesUsedInSplit.splice(index, 1);
                }
            });

            var index = 0;
            _.each(this.splitDocs, function(doc) {
                if (doc.oco.get("properties").objectName === name) {
                    self.splitDocs.splice(index, 1);
                }
                index++;
            });
            //If there are no documents being split anymore, set the global variable back to
            //false so the user can save and exit normally.
            if (this.pagesUsedInSplit.length === 0) {
                self.startSplit = false;
                $(".mode-header-label").text("Document " + window.localize("indexer.layout.indexing"));
            }
        },
        //When a split document is selected show that doc's metadata in the form.
        replacePropertiesView: function(oco) {
            this.propertiesView = new PropertiesView.PropertyList({
                'objectType': oco.objectType,
                'properties': _.clone(oco.properties),
                'formName': this.config.get("form"),
                'enableValidation': true,
                'enableRequired': true,
                'listener': 'indexer',
                'controlValueChangeHandler': _.bind(this.processControlValueChanges, this)
            });

            this.model.set("showParentDoc", false);

            this.setView(".properties-view-oulet", this.propertiesView).render();
        },
        showTypePropertiesView: function(typeConfig) {
            //Get the attributes that are configured on the form, they will
            //be used to check if the attributes are repeating or not.
            this.primaryFormAttrs = typeConfig.get("configuredAttrsPri");
            this.secondaryFormAttrs = typeConfig.get("configuredAttrsSec");

            this.propertiesView = new PropertiesView.PropertyList({
                'objectType': typeConfig.get("ocName"),
                'properties': _.clone(this.oco.get('properties')),
                'formName': this.config.get("form"),
                'enableValidation': true,
                'enableRequired': true,
                'listener': 'indexer',
                'controlValueChangeHandler': _.bind(this.processControlValueChanges, this)
            });

            this.model.set("showParentDoc", true);

            this.setView(".properties-view-oulet", this.propertiesView).render();
        },
        showNewPropertiesView: function(options) {
            var self = this;
            this.oco.set("objectType", options.objectType);
            this.$(".indexer-controls").show();
            // Double check if objectType is allowed for Form, if it is not, show an error.
            app.context.configService.getFormConfig(self.config.get('form'), function(formConfig) {
                //Loop through all configured types and compare with the type of current document
                //the .find() will exit the loop once it finds the correct type.
                var typeConfig  = formConfig.get("configuredTypes").find(function(config) {
                    return self.oco.get("objectType") === config.get('ocName');
                });

                if (typeConfig) {
                    self.showTypePropertiesView(typeConfig);
                }
            });
        },
        //Put the metadata for the parent doc back into the form.
        showParentDocProperties: function() {

            if (!this.model.get("showParentDoc")) {
                this.propertiesView = new PropertiesView.PropertyList({
                    'objectType': this.oco.get("objectType"),
                    'properties': _.clone(this.oco.get("properties")),
                    'formName': this.config.get("form"),
                    'enableValidation': true,
                    'enableRequired': true,
                    'listener': 'indexer',
                    'controlValueChangeHandler': _.bind(this.processControlValueChanges, this)
                });

                this.setView(".properties-view-oulet", this.propertiesView).render();

                this.model.set("showParentDoc", true);
            }
        },

        // We want to resolve a token that a user used in a query criteria - currently only resolves dates
        // and user information.
        _tokenResolve: function(value) {
            if (value === '$date') {
                return new Date();
            } else if (value === "$user.loginName") {
                return app.user.get("loginName");
            } else if (value === "$user.displayName") {
                return app.user.get("displayName");
            } else {
                return value;
            }
        }

    });

    Indexer.Views.TypeSelector = Backbone.Layout.extend({
        template: "indexer/typeselector",
        events: {
            "change #indexer-availableTypes": "typeSelected"
        },
        initialize: function(options) {
            var self = this;
            this.formName = options.formName;
            this.availableTypes = [];
            app.context.configService.getFormConfig(this.formName, function(formConfig) {
                formConfig.get("configuredTypes").each(function(type) {
                    self.availableTypes.push({
                        "ocName": type.get("ocName"),
                        "label": type.get("label")
                    });
                });
                self.render();
            });
        },

        typeSelected: function() {
            var typeSelected = this.$("#indexer-availableTypes").val();

            var options = {
                "objectType": typeSelected
            };

            app.trigger("showNewPropertiesView", options);
        },

        serialize: function() {
            return {
                availableTypes: this.availableTypes
            };
        }
    });


    Indexer.Views.PostLayout = Backbone.Layout.extend({
        template: "indexer/postindexer", //NOTE: Refers to the indexer/indexer.html file 
        className: 'indexer-view',
        model: Indexer.DocumentModel,

        // NOTE: Used to pass information into this View's template before it is rendered to the DOM. 
        serialize: function() {
            return {
                docId: this.model.get("objectId")
            };
        }
    });

    return Indexer;

});