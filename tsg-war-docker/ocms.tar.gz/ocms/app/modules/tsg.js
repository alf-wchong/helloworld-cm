// Tsg module
define([
  // Application.
  "app",
  "modules/services/logstashservice",
  "modules/common/hpiconstants"
],

//This is to hold us over until the pieces get factored out
function(app, LogstashService, HPIConstants) {

  // Create a new module.
  //Making TSG global for legacy action code
  //TODO this should not be global
  var TSG = app.module();
  window.TSG = TSG;

    //****** OLD EVENT MANAGER *********//
    function EventManager () {
	    //holder for callback objects
	    var events = {};
	    //this will have the most recently supplied args incase we need them
	    var lastDataSupplied = {};
	    /**The register function adds a callback funtion to a list
	     *
	     * @param eventName - name of the callback object
	     * @param initalData -
	     */
	    this.register = function(eventName, callback, clearOtherCallbacks) {
			
			//optional param - default is false
			//Used to determine if array of callback functions should be cleared
			clearOtherCallbacks = (typeof clearOtherCallbacks === "undefined") ? false : clearOtherCallbacks;
	       
		   if(events[eventName] === undefined){
	            //create the callback memory will automatically call any callbacks
	            //added with the previous value (if the list has been fired)
				events[eventName] = $.Callbacks( 'memory' );
	       }
			
			//Clear out the callbacks and reinstantiate the array
			if(clearOtherCallbacks){
				events[eventName] = null;
				events[eventName] = $.Callbacks('memory');
			}
			
	        events[eventName].add(callback);
	    };
	
		//can be set on event manager object if you don't want to
		//have callbacks happen
		this.ignoreTriggers = false;
		
		//Remove all the callbacks for one event, passed in as a param
		this.removeSingleEventCallBacks = function(event){
			events[event] = null;
			events[event] = $.Callbacks('memory');
		};
		
		this.setIgnoreTriggers = function(val){
			this.ignoreTriggers = val;
		};
		
	    this.trigger = function(eventName, args) {
			//don't do anything if the triggers are being ignored
			if(this.ignoreTriggers){
				return;
			}
	
	        lastDataSupplied[eventName] = args;
	        if(events[eventName] === undefined){
	            //Fire anyway, someone may want to know about this later.
	            //TODO this might be useful, but also spammy. Can we enable debug only?
	            events[eventName] = $.Callbacks( 'memory' );
	        }else{
				
				events[eventName].fire(args);
	        }
	    };
	
		this.clearAllEvents = function(){
            /*jshint forin: false */
			for(var eventName in events){
				events[eventName] = null;
				events[eventName] = $.Callbacks('memory');
			}
		};
	    /*
	     * This function is useful if you want to register to an
	     * event that may or may not have been called. The call back will
	     * be tripped if the event has been called.
	     */
	    this.registerAndTrigger = function( eventName, callback) {
	        eventManager.register(eventName, callback);
	        if(events[eventName].fired()){
	            callback(lastDataSupplied[eventName]);
	        }
	    };

	    return this;
    }
    var eventManager = TSG.EventManager = new EventManager();
    TSG.getEventManager = function(){return new EventManager();};
    
    //*******END EVENTMANAGER******///
    
    //****OLD TSG.js *********///
     if(TSG.EventManager === undefined){
        return;
    }

    TSG.services = (function(){

        var ajaxURLs = {
            properties : app.serviceUrlRoot + "/content/properties",
            containerInfo : "services/containerInfo",
			moduleConfigs : "services/moduleConfigService",
			mockModuleConfigs : "services/mock/moduleConfigService",
			getChildren: app.serviceUrlRoot + "/content/getChildRelations",
            isAutoNumbered: app.serviceUrlRoot + "/aw-form/isAutoNumbered", //mock service
            content: "docStream.htm",
            getFolderActions: "services/actions/folderActions/valid",
            getDocumentActions: "services/actions/docActions/valid",
            getWizardActions: "services/actions/wizardActions/valid",
            getGeneralActions: "services/actions/general/valid",
            createViewAudit: app.serviceUrlRoot + "/audit/createViewAudit",
			getLockOwner : app.serviceUrlRoot + "/content/getLockOwner",
            getContentInfo: app.serviceUrlRoot + '/content/getContentInfo',
            isAnnotated : app.serviceUrlRoot + "/annotation/isAnnotated",
            executeAction: app.serviceUrlRoot + "/action/execute",
            getUserBeans : "services/repositoryService/getUserBeans",
            getPicklist : "services/picklistService/getPicklist",
            loadAddressBook: app.serviceUrlRoot + "/email/folderAddressBook"
        };

        return {
            //TODO centralize error handling here
            ajaxService : {
                getObjectProperties : function(objectId, callback, error){
                    if(error) {
                        return $.ajax({
                            url: ajaxURLs.properties, 
                            data: {
                                "id" : objectId
                            }, 
                            success: callback,
                            global:false,
                            error: error
                        });
                    } else {
                        return $.ajax({
                            url: ajaxURLs.properties, 
                            data: {
                                "id" : objectId
                            }, 
                            success: callback,
                            global:false
                        });
                    }
                },
                loadAddressBook : function(folderId, callback){
                    $.get(ajaxURLs.loadAddressBook, {"folderId" : folderId}, callback);

                },
                 getRelatableFolders : function(objectId, type, fuzzySearchObjectName, callback){
                    $.get(app.serviceUrlRoot + '/content/getRelatableFolders?objectId=' + objectId + '&type=' + type + '&fuzzySearchObjectName=' + fuzzySearchObjectName, {}, callback);
                },
                loadDocumentContent : function(documentId, callback){
                    $.get(ajaxURLs.content, {"docId" : documentId}, callback);
                },
                getContainerInfo : function(containerId, callback) {
                    $.get(ajaxURLs.containerInfo, {"id": containerId}, callback);
                },
                getRelatedObjects: function(context, objectId, relationName, type, callback){
                    var relationUrl = app.serviceUrlRoot;
                    var dataObj;
                    if(relationName === "children"){
                        relationUrl += "/content/getChildren";
                        dataObj = {"id": objectId};
                    }else if("child" === type){
                        relationUrl += "/content/getChildRelations";
                        dataObj = {"id": objectId, "relationName": relationName};
                    }else if("parent" === type){
                        relationUrl += "/content/getParentRelations";
                        dataObj = {"id": objectId, "relationName": relationName};
                    }else{
                        //TODO
                        throw "not yet implemented";
                        // $.get(ajaxURLs.getChildren, {"id": objectId, "relationName": relationName, "type": type}, callback);

                    }

                    var getRelatedObjectsInfo = {
                        context: context,
                        url: relationUrl,
                        data: dataObj,
                        success: callback
                    };
                    return $.ajax(getRelatedObjectsInfo);
                },
                getModuleConfig : function(moduleId, trac, callback) {
                    $.get(ajaxURLs.moduleConfigs + "/" + moduleId, {"trac":trac}, callback);
                },
                isAutoNumbered : function(pageSetName, callback) {
                    $.get(ajaxURLs.isAutoNumbered + "?pageSetName=" + pageSetName,  callback);
                },
                createViewAudit: function(documentId) {
                    var createViewAuditOptions = {
                        type: 'POST',
                        url: app.serviceUrlRoot + '/audit/createViewAudit',
                        data: {
                            objectId: documentId
                        }
                    };
                    $.ajax(createViewAuditOptions);
                },
				getMockModuleConfig : function(moduleId, trac, callback) {
                    $.get(ajaxURLs.mockModuleConfigs + "/" + moduleId, {"trac":trac}, callback);
                },
                getDocumentActions: function(documentId, objectType, callback){
                    $.get(ajaxURLs.getDocumentActions, {"objectId": documentId, "objectType":objectType}, callback);
                },
                getWizardActions: function(formId, objectType, callback){
                    $.get(ajaxURLs.getWizardActions, {"objectId": formId, "objectType":objectType}, callback);
                },
                getGeneralActions: function(trac, objectType, callback){
                    $.get(ajaxURLs.getGeneralActions, {"trac": trac}, callback);
                },
                getLockOwner: function(options){
                    var getLockOwnerOptions = {
                      context: options.context,
                      url: ajaxURLs.getLockOwner,
                      data: {"id": options.objectId},
                      success: options.successCallback,
					  error: options.errorCallback,
                      dataType: 'json',
					  // force this to default to true
                      global: !options.isNotGlobal
                    };
					return $.ajax(getLockOwnerOptions).promise();
                },
                getContentInfo: function(options) {
                    var getContentInfoOptions = {
                        context: options.context,
                        type: 'GET',
                        url: app.serviceUrlRoot + '/content/getContentInfo',
                        data: {
                            "ids[]": [options.objectId]
                        },
                        success: options.successCallback,
                        error: options.errorCallback,
                        global: !options.isNotGlobal
                    };
                    return $.ajax(getContentInfoOptions).promise();                
                },
                isAnnotated: function(options){
                    var isAnnotatedOptions = {
                      context: options.context,
                      url: ajaxURLs.isAnnotated,
                      data: {"id": options.objectId},
                      success: options.successCallback,
                      error: options.errorCallback,
                      global: !options.isNotGlobal
                    };
                    return $.ajax(isAnnotatedOptions).promise();
                },
                executeAction: function(id, action, callback, failCallback){
                    $.ajax({
                		type: "POST",
                		url: ajaxURLs.executeAction + "?id=" + id,
                		data: JSON.stringify(action),
                		success: callback,
                		error: failCallback,
                		contentType: "application/json"
                	});
                },
                getUserBeans: function(loginName, callback){
                    $.ajax({
                      url: ajaxURLs.getUserBeans,
                      data: {"loginName": loginName},
                      success: callback,
                      global:false
                    });
                },
                getPicklist : function(picklistName, targetObservableArray){
                	//TODO implement
                	targetObservableArray( ["apple", "apricot", "banana", "blueberry", "strawberry", "starfruit"] );
                	//$.get(ajaxURLs.getPicklist, {"picklistName": picklistName}, callback);
                },
                getParents : function(objectId, callback, errorCallback){
                    $.get(app.serviceUrlRoot + "/content/getParents", {"objectId": objectId}, callback).fail(function(jqXHR, textStatus, errorThrown) {
                        if(errorCallback) {
                            errorCallback(jqXHR, textStatus, errorThrown);
                        }
                    });
                }

            }

        };

    }());

	TSG.scrollToTop = function() {
		//Scroll to top of page.
		$('body').animate({
			scrollTop: 0
		}, 800);
	};

    // Replace the normal jQuery getScript function with one that supports
    // debugging and which references the script files as external resources
    // rather than inline.
    jQuery.extend({
        getScript: function(url, callback) {
            var head = document.getElementsByTagName("head")[0];
            var script = document.createElement("script");
            script.src = url;

            // Handle Script loading
            {
                var done = false;

                // Attach handlers for all browsers
                script.onload = script.onreadystatechange = function(){
                    if ( !done && (!this.readyState ||
                        this.readyState === "loaded" || this.readyState === "complete") ) {
                        done = true;
                        if (callback){
                            callback();
                        }

                        // Handle memory leak in IE
                        script.onload = script.onreadystatechange = null;
                    }
                };
            }

            head.appendChild(script);

            // We handle everything using the script element injection
            return undefined;
        }
    });
    

    //getting some config info:
    TSG.configuration = {
    		propertyConfig : {},
    		contentTypeConfigsByMimeType : [
                    {mimeType : "application/msword", iconPath : "assets/css/styles/img/icons/doc.svg"},
                    {mimeType : "application/vnd.ms-word.document.macroEnabled.12", iconPath : "assets/css/styles/img/icons/doc.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", iconPath : "assets/css/styles/img/icons/doc.svg"},
                    {mimeType : "application/vnd.ms-powerpoint.template.macroEnabled.12", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.presentationml.template", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.ms-powerpoint.slideshow.macroEnabled.12", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.presentationml.slideshow", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.ms-powerpoint", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.ms-powerpoint.presentation.macroEnabled.12", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.presentationml.presentation", iconPath : "assets/css/styles/img/icons/ppt.svg"},
                    {mimeType : "application/vnd.visio", iconPath : "assets/css/styles/img/icons/visio.svg"},
                    {mimeType : "application/vnd.ms-excel", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.ms-excel.sheet.binary.macroEnabled.12", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.ms-excel.sheet.macroEnabled.12", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.ms-excel.template.macroEnabled.12", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.ms-works", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.openxmlformats-officedocument.spreadsheetml.template", iconPath : "assets/css/styles/img/icons/xls.svg"},
                    {mimeType : "application/vnd.ms-outlook", iconPath : "assets/css/styles/img/icons/email.svg"},
                    {mimeType : "text/html", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "text/jhtml", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "text/phtml", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "text/shtml", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "multipart/related", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "text/plain", iconPath : "assets/css/styles/img/icons/txt.svg"},
                    {mimeType : "text/json", iconPath : "assets/css/styles/img/icons/txt.svg"},
                    {mimeType : "text/xml", iconPath : "assets/css/styles/img/icons/xml.svg"},
                    {mimeType : "text/x-vcard", iconPath : "assets/css/styles/img/icons/txt.svg"},
                    {mimeType : "image/gif", iconPath : "assets/css/styles/img/icons/gif.svg"},
                    {mimeType : "image/jp2", iconPath : "assets/css/styles/img/icons/jpeg.svg"},
                    {mimeType : "image/jpeg", iconPath : "assets/css/styles/img/icons/jpeg.svg"},
                    {mimeType : "image/vnd.ms-modi", iconPath : "assets/css/styles/img/icons/tif.svg"},
                    {mimeType : "image/png", iconPath : "assets/css/styles/img/icons/gif.svg"},
                    {mimeType : "image/tiff", iconPath : "assets/css/styles/img/icons/tif.svg"},
                    {mimeType : "application/illustrator", iconPath : "assets/css/styles/img/icons/illlustrator.svg"},
                    {mimeType : "application/pdf_props", iconPath : "assets/css/styles/img/icons/pdf.svg"},
                    {mimeType : "application/pdf_combo", iconPath : "assets/css/styles/img/icons/pdf.svg"},
                    {mimeType : "application/pdf", iconPath : "assets/css/styles/img/icons/pdf.svg"},
                    {mimeType : "text/pdf", iconPath : "assets/css/styles/img/icons/txt.svg"},
                    {mimeType : "application/photoshop", iconPath : "assets/css/styles/img/icons/ps.svg"},
                    {mimeType : "application/x-zip-compressed", iconPath : "assets/css/styles/img/icons/zip.svg"},
                    {mimeType : "application/octet-stream", iconPath : "assets/css/styles/img/icons/unknown.svg"},
                    {mimeType : "application/x-ms-wmz", iconPath : "assets/css/styles/img/icons/zip.svg"},
                    {mimeType : "application/rtf", iconPath : "assets/css/styles/img/icons/txt.svg"},
                    {mimeType : "application/x-url", iconPath : "assets/css/styles/img/icons/html.svg"},
                    {mimeType : "image/x-dwg", iconPath : "assets/css/styles/img/icons/cad.svg"}
            ],
    		picklistConfig : {}
    					
    };
   
   //allows for toggling of debugging logging
	TSG.debug = true;

    TSG.EventManager._OCMSClientErrorHelper = function() {
        app.trigger("alert:error", {
            header: window.localize("modules.tsg.error"),
            message: window.localize("modules.tsg.anUnexpected")
        });

        // Log the error event
        LogstashService.sendMetrics(
            new LogstashService.PerformanceLog({
                'eventTitle': HPIConstants.Logging.Events.OCMSClientError
            })
        );
    };
        
    /*
     * Error //TODO modal? or something more elegant....
     */
    TSG.EventManager.register("generic.error", TSG.EventManager._OCMSClientErrorHelper);

    //default our ajax requests to NOT CACHE anything!
    //this is necessary for proper retrieval of data in IE.
    if($.browser.msie || navigator.userAgent.match(/Trident/)) {
        app.log.debug("User-Client is IE - Disabling AJAX Caching...");
        $.ajaxSetup({
           cache: false
        });
    }
    $.ajaxSetup({
        error: function(jqXHR) {
            //ignore 401s
            if(jqXHR.status === 401){
                return;
            }
            TSG.EventManager.trigger("generic.error");
		}
    });
    
    //********END TSG.js**************//
    
    //***Property formatters *****///
    //this is where we can format/retrieve pretty versions of whatever we need to!
	TSG.propertyFormatters = {
			
		getFormatter : function( configVal ) { //returns formatter name if one is found, returns nothing if not.
			//we can expect stuff to come in as either 'propertyName' or as 'propertyName~formatterName'
			var formatter;
			if(configVal.indexOf("~") !== -1) {
    			//then we have a formatter to deal with.
    			formatter = configVal.split("~")[1];
    			if( typeof TSG.propertyFormatters[formatter] != 'function' ) {
                    app.trigger("alert:info", {
                        header: window.localize("generic.alert"),
                        message: window.localize("modules.tsg.formatterNot")  + formatter + window.localize("modules.tsg.notFormattingProperty")
                    });
    				return;
    			}
    			return formatter;
    		} else {
    			return;
    		}
		},
		
		getCleanPropertyName : function ( configVal ) {
			if( configVal.indexOf("~") !== -1 ) {
				return configVal.split("~")[0];//modifier as opposed to modifier~userName
			} else {
				return configVal;
			}
		},
		
		/**
		 * START ACTUAL PROPERTY FORMATTER FUNCTIONS
		 */
			
		date : function( origVal, targetObservable ) {
			//assume we get this in ISO format
			var d = new Date(origVal);
			targetObservable( d.getMonth() + 1 + '/' + d.getDate() + '/' + d.getFullYear() ); //months start at 0 in js.
		},
		
		euroDate : function( origVal, targetObservable ) {
			//assume we get this in ISO format
			var months = new Array(12);
			months[0] = "JAN";
			months[1] = "FEB";
			months[2] = "MAR";
			months[3] = "APR";
			months[4] = "MAY";
			months[5] = "JUN";
			months[6] = "JUL";
			months[7] = "AUG";
			months[8] = "SEP";
			months[9] = "OCT";
			months[10] = "NOV";
			months[11] = "DEC";
			
			var d= new Date(origVal);
			targetObservable(d.getDate() + '-' + months[d.getMonth()] + '-'  + d.getFullYear()); //months start at 0 in js.
		},
		
		userId : function( userId, targetObservable ) {
			TSG.services.ajaxService.getUserBeans(userId, function(data) {
				targetObservable( data.displayName );
			});
		}
	};
		/**
		 * END ACTUAL PROPERTY FORMATTER FUNCTIONS
		 */

  // Return the module for AMD compliance.
  return TSG;

});
