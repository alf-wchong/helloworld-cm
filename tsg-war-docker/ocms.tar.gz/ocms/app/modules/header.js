// Header module
define([
	 // Application.
	 "app",
	 "knockout",
	 "knockback",
	 "context",
	 "module",
	 "modules/hpiadmin/applicationconfig/applicationconfig",
	 "modules/common/action",
	 "modules/tour/searchtour",
	 "modules/tour/stagetour",
	 "modules/common/notificationview",
	 "modules/common/notification",
	 "modules/common/spinner",
	 "modules/services/localizationservice"
],

// Map dependencies from above array.
function(app, ko, kb, context, module, AppConfig, Action, SearchTour, StageTour, NotificationView, Notification, HPISpinner, LocalizationService) {

 // Create a new module.
 var Header = app.module();

Header.ViewModel = function() {
	 var self = this;
	 self.leftLinks = ko.observableArray([]);
	 self.rightLinks = ko.observableArray([]);
	 self.hasNotifications = ko.observable(false);
	 self.enableLogoLink = ko.observable(false);
	 self.notifications = [];
	 self.notificationsEnabled = ko.observable();
	 
	 self.continueTour = ko.observable();
	 self.searchTourClosed = ko.observable();
	 self.stageTourClosed = ko.observable();
		 
	 self.isUserAdmin = ko.observable(false);
 };

 var Link = Header.Link = function(options) {
	 var self = this;
	 self.active = ko.observable(options.active || false);
	 self.url = ko.observable(options.url);
	 self.label = ko.observable(options.label);
	 self.headerPageLink = options.pageLink || false;
	 self.isButton = options.isButton || false;	// if 'true' - will be presented as a bootstrap "button"
	 self.headerIcon = ko.observable("glyphicons glyphicons-" + options.icon);


	 //clickHandler is optional
	 if (!options.clickHandler) {
			 options.clickHandler = function() {
					 //this says if the link is clicked, just proceed as normal
					 app.trigger("closeTour");
					 return true;
			 };
	 }
	 self.clickHandler = options.clickHandler;

	 return self;

 };


 /**
 * This is a method for extension that is implemented in the extending
 * javascript file (see header-AbbVie.js for an example)
 *
 * @param leftLinks this is the observable array that can be used to add links to the left hand
 * side of the header
 * @param rightLinks this is the observable array that can be used to add links to the right hand
 * side of the header
 */
 Header.addCustomLinks = function() {
 //This is a method for extension and is therefore intentionally left blank
 };

 // Default View.
 Header.View = Backbone.View.extend({
	 template: "header",
	 events: {
		 "click .notify" : "showNotifications",
		 "click #header-logo" : "navigateToDefaultPath"
	 },
	 initialize: function () {
		// here for unit testing purposes only
		this.hideSignOut = app.enableSSO ? true : module.config().hideSignOut;
		this.hideUserPreferences = module.config().hideUserPreferences;
		this.hideUserInfo = module.config().hideUserInfo;
	},
	 showNotifications: function() {
		var self = this;
		this.notificationCollection = new Notification.Collection();
		this.notificationCollection.fetch({
			getCurrent: true,
			success: function () {
				app.trigger("alert:custom", {
					view : new NotificationView.Views.Layout({notifications: self.notificationCollection}),
					width : 900
				});
			}
		});
	 },

	 navigateToDefaultPath: function() {
		 if(app.context.currentApplicationConfig() && app.context.currentApplicationConfig().get("enableLogoLink") === "true") {
			 Backbone.history.navigate(app.context.currentApplicationConfig().get("defaultPath") || "/dashboard", {trigger: true});
		 }
	 },

	 afterRender: function() {

		 var self = this;
		 self.vm = new Header.ViewModel();

		 self.$('[data-toggle="tooltip"]').tooltip({
		 	'placement': 'bottom'});

		 $(window).resize(function() {
			 var navHeight = self.$("div.navbar").outerHeight();
			 $("div.full-content").css({ "marginTop" : navHeight+14 });
		 });

		 //Prevents filmstip thumbs from overlapping title when stacking
		 $(window).resize(function() {
			 var clearFixHeight = $( ".indexer-filmstrip" ).children(".clearfix").outerHeight();
			 $("div#content").css({ "marginTop" : clearFixHeight });
		 });

			app.log.debug(window.localize("modules.header.mainHeader"));

		 // if we already have a spinner we want to get rid of it before we re-add it (which removes it from the DOM and allows the spin
		 // library to do cleanup). If you get rid of the below line you'll run into an IE9 issue (try switching tracs from the search page).
		 HPISpinner.destroySpinner(this.spinner);

		 // find our DOM element to attach a spinner to
		 var spinElem = this.$("#app-loading")[0];
		 if(spinElem) {
			 // animate our loading indicator with spin.js (lighter weight than animated gif)
			 this.spinner = HPISpinner.createSpinner({
			 }, spinElem);
		 } else {
				app.log.error(window.localize("modules.header.cannot"));
		 }

		 //active the right link
		 //TODO is there a better way?
		 self.vm.leftLinks.subscribe(function(newLinks) {
			 $.each(newLinks, function(index, item) {
				 if (window.location.href.toLowerCase().indexOf(item.label().toLowerCase()) != -1) {
					 //if the url contains this links label, case insensitve;
					 item.active(true);
				 }
			 });
		 });

		 // Used to hold the header links before ordering
		 self.rawLeftLinks = ko.observableArray([]);

		 //setup some default links
		 app.context.configService.getApplicationConfig(function(config) {
			 //if we got an appconfig see if the user is in an admin group
			if (config && app.user) {
			        var acceptableGroups = config.get("adminGroups").pluck("name");
			        if (acceptableGroups.length > 0) {
			            app.user.getGroups().done(function() {
			                if (acceptableGroups.length < 1 || _.intersection(acceptableGroups, app.user.get("groupNames")).length > 0) {
			                    //show the admin link
			                    self.vm.rightLinks.push(new Link({
			                        url: "admin",
			                        label: window.localize("header.admin"),
			                        pageLink: true,
			                        isButton: true
								}));
								
								self.vm.isUserAdmin(true);
			                }
			            });
			        }
				 
				 // get configurable hardcoded header links
				 var configuredHeaderLinks = config.get("enabledHeaderLinks");
				 var iconsEnabled = config.get("headerIconsEnabled");
				 if( configuredHeaderLinks && configuredHeaderLinks.length > 0 ) {
					 _.each( configuredHeaderLinks, function(link) {

						 if( link === "Search" ) {
							 self.vm.leftLinks.push(new Link({
								 url: app.context.configName() ? "search/" + app.context.configName() : "search/" ,
								 label: window.localize("generic.search"),
								 pageLink: true,
								 icon: (iconsEnabled === 'true' && config.get("headerIcons"))? config.get("headerIcons").Search : ""
							 }));
						 } else if( link === "Dashboard" ) {
							 self.vm.leftLinks.push(new Link({
								 url: "dashboard",
								 label: window.localize("header.dashboard"),
								 pageLink: true,
								 icon: (iconsEnabled === 'true' && config.get("headerIcons"))? config.get("headerIcons").Dashboard : ""
							 }));
						 } else if( link === "Collections" ) {
							 self.vm.leftLinks.push(new Link({
								 url: "collections",
								 label: window.localize("header.collections"),
								 pageLink: true,
								 icon: (iconsEnabled === 'true' && config.get("headerIcons"))? config.get("headerIcons").Collections : ""
							 }));
						 }

					 } );
				 }


				 //Setup any header actions
				 var _actionConfigs = config.get("actions");
				 var _actions = [];
				 if(_actionConfigs) {
					 _actionConfigs.each(function(actionConfig) {
						 _actions.push(new Action.Model({actionId: actionConfig.actionId, ocActionId: actionConfig.get("ocActionId") || actionConfig.actionId}));
					 });
				 }

				 var renderCustomLinks = function(){
					 //Create the custom header links This is going in the success of action headers to make sure it goes after them.
					 var configuredCustomHeaders = config.get("customHeaders");

					 if(configuredCustomHeaders) {
						 app.user.getGroups().done(function() {
							_.each(configuredCustomHeaders, function(link) {
								if(!link.allowedGroups.length || _.intersection(app.user.get("groupNames"), link.allowedGroups).length) {
									// We will pass in this option to determine if we need to open a new window for this link or not.
									var openingMethod = link.newWindow ? '_blank' : '_self';

									// Push a new left link onto the existing ones.
									self.vm.leftLinks.push(new Link({
										url: link.url,
										label: window.localize(link.label),
										clickHandler: function(event) {
											window.open(event.url(), openingMethod);
										},
										pageLink: true,
										icon: iconsEnabled === 'true' ? link.icon : ''
									}));
								}
							 });
						 });
					 }
				 };


				 var actionCollection = new Action.Collection(_actions);
				 if (actionCollection.length > 0) {
					 actionCollection.fetch({
						 success: function(col) {
							 col.each(function(action) {
								 if (action.isValid()) {
									 var config = _actionConfigs.findWhere({actionId: action.get("actionId")});
									 if(self.vm.leftLinks !== null) {
										 self.vm.leftLinks.push(new Link({
											 label: window.localize(config.get("label")),
											 clickHandler: function() {
												 app[config.get("handler")].trigger("show", {action: action,config: config});
											 },
											 pageLink: false,
											 icon: iconsEnabled ==='true' ? config.get("icon") : ""
										 }));
									 }
								 }
							 });
							 renderCustomLinks();

						 },
						 error: function() {
								 app.log.error("Failed to resolve header actions");
								 renderCustomLinks();
						 },
						 global : false
					 });
				 }else{
					 renderCustomLinks();
				 }

			 }

			 if(config && config.get("enableLogoLink") === "true") {
				 self.vm.enableLogoLink(true);
			 }
			 
			 if (config){
				 self.vm.notificationsEnabled(config.get("enableHeaderNotifications"));
			 }

			 //enable headernotifications
			 if(config.get("enableHeaderNotifications") === true) {
				 //notification css not getting overridden by
				 //the knockout binding, so we added this jquery
				 $(".notifications").show();
				 self.stopListening(app, "refreshNotifications");
				 self.listenTo(app, "refreshNotifications", function() {
					 $.ajax({
						 url: app.serviceUrlRoot + "/notification/getNotifications",
						 data: {maxToReturn: 1, eventName: "hpi_notification"},
						 global: false,
						 success: function(data){
							 if(data.length > 0) {
								 self.vm.hasNotifications(true);
							 } else {
								 self.vm.hasNotifications(false);
							 }
						 }
					 });
				 });
				 app.trigger("refreshNotifications");
			 }

			 // Order Left links


		 }, function(error) {
			 app.log.debug(error);
		 });
		 
		 self.listenTo(app, "closeTour", function() {
			 
			 app.log.debug("removing/hiding search tour");
			 $(".popover.right").hide();
			 $(".popover.bottom").hide();
			 $(".popover.content").hide();
			 $(".popover.top").hide();
			 $(".popover.left").hide();
			 $(".tour-highlight").removeClass("tour-highlight");

			 // enable scrolling for the leftBar
			 $("#leftBar").unbind("mousewheel");
	     	
	     	// change configs to not have the tours pop up again
			if(SearchTour.ActiveTours && SearchTour.ActiveTours.length){
				app.trigger("searchTourClosed");
			}

			if(StageTour.ActiveTours && StageTour.ActiveTours.length){
				app.trigger("stageTourClosed");
			}

			 // clear arrays of any active tours
			 SearchTour.ActiveTours = [];
			 StageTour.ActiveTours = [];
			 StageTour.IsWizard = false;
	     StageTour.NoDocument = false;
		 });
		 

		 self.vm.userInfo = {
			 label: function() {
				 var username = "";
				 if(app.user && app.user.fetched) {
					 username = app.user.get("displayName");
				 }
				 else if(app.user && !(app.user.fetched)) {
						username = window.localize("modules.header.usernameNotLoaded");
				 }
				 else {
						username = window.localize("modules.header.notLoggedIn");
				 }
				 return window.localize("header.hello") + username;
			 },
			 logout: function() {
				 app.log.debug("requestlogoff");
				 //app.trigger("security:logoff");
				 app.trigger("closeTour");
				 Backbone.history.navigate("/logout", {trigger: true});
			 },
			 userPreferences: function(){
				 app.trigger("closeTour");
				 Backbone.history.navigate("/userpreferences", {trigger: true});
			 }
		 };

		 self.vm.startTour = function() {
			 // use for testing when hitting tour available button
		 };
		 
		 // toggle search tour user pref switch to off
		 self.listenTo(app, "searchTourClosed", function() {
			 app.context.currentUserPreferences().get("tours").search = false;
		 });
		 
		 // toggle stage tour user pref switch to off
		 self.listenTo(app, "stageTourClosed", function() {
			 app.context.currentUserPreferences().get("tours").stage = false;
		 });

		 //Call extension method
		 Header.addCustomLinks(self.vm.leftLinks, self.vm.rightLinks);

		 kb.applyBindings(self.vm, this.$el[0]);
	 },

	 serialize: function(){
	 	return{
	 		hideSignOut: this.hideSignOut || false,
	 		hideUserPreferences: this.hideUserPreferences || false,
			hideUserInfo: this.hideUserInfo || false,
			showLicenseError: app.licenseInfo ? app.licenseInfo.showLicenseError : false,
			remainingDays: app.licenseInfo ? app.licenseInfo.remainingDaysOnLicense : 0
	 	};
	 }
 });



 // Return the module for AMD compliance.
 return Header;

});
