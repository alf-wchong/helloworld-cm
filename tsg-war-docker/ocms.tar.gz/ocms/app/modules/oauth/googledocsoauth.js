define([
	"app",
	"googledocs"
],
function(app, GoogleDocs) {

	var GoogleDocsOAuth = app.module();

	// this is the view to display when a user is redirected back to HPI after authorizing HPI
	// to access their Google Docs
	GoogleDocsOAuth.Views.Layout = Backbone.Layout.extend({
		
		template: "oauth/googledocsoauth",
		
		initialize: function(options) {
			var self = this;

			// an error occured if the error option is present and it equals "access_denied"
			this.error = options.error && options.error === "access_denied";

			// the code is the authorization code that can be used to be exchanged for an access token
			// and refresh token
			this.code = options.code;

			// the state is the information that was passed through to this view when the user tried
			// to create the Google document originally - it contains the parentObjectId to create the document
			// in, the bean name of the object type for the new object and the type of the Google document to create
			this.state = options.state;

			// if there wasn't an error, then we want to go ahead and create
			// the Google document the user was trying to create in the first place
			if(!this.error) {
				// we need to complete our authentication server side which involves requesting an
				// access and refresh token pair from Google (exchanging the authorization code) and
				// persisting those credentials
				$.ajax({
					url: app.serviceUrlRoot + "/googledocs/completeAuthentication",
					method: "GET",
					data: {
						code: this.code
					},
					success: function(response) {
						// once we've completed authentication, let's execute the action the user was trying to perform
						if(self.state.action) {
							if(self.state.action === "create") {
								// let's create our Google document
								GoogleDocs.createGoogleDoc(self.state, true, function(createGoogleDocResult) {
									// only need to handle an error here since on success we'll change the
									// URL of this window
									if(createGoogleDocResult.result === "error") {
										self.setupAndDisplayError(createGoogleDocResult.errorMsg);
									}
								});
							} else if(self.state.action === "edit") {
								// let's do our editing of the Google document
								GoogleDocs.getEditingConditions(self.state, true, function(result) {
									// only need to handle an error here since on success we'll change the
									// URL of this window
									if(result.result === "error") {
										self.setupAndDisplayError(result.errorMsg);
									}
								});
							}
						} else { // no action was specified so let's show an error
							self.setupAndDisplayError(window.localize("modules.oauth.googleDocOauth.thereWasNoAction"));	
						}
					},
					error: function() {
						self.setupAndDisplayError(window.localize("modules.oauth.googleDocOauth.thereWasAnError"));
					}
				});
			} else {
				// we have an "access_denied" error so let's display a message to the user that they need to authorize
				// HPI to use their Google Docs account to proceed
				self.setupAndDisplayError(window.localize("modules.oauth.googleDocOauth.youMustAuthorize"));
			}
		},

		serialize: function() {
			return {
				error: this.error,
				errorMessage: this.errorMessage
			};
		},

		// called when an error occurs and a message should be shown to the user
		setupAndDisplayError: function(errorMessage) {
			// need to set the error flag to true so that when we render our error message is shown
			this.error = true;

			// the error message to display to the user
			this.errorMessage = errorMessage;

			// render so we can show the error message
			this.render();
		}

	});

	return GoogleDocsOAuth;
});