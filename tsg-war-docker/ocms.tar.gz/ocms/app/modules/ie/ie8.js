//ie8.js
// loads the respond.js and html5shiv dependencies for ie8 only via require.js
 
if($("html").hasClass("ie8")) { 
	require(["respond", "html5shiv"], function() {
		// noop	
	});
}