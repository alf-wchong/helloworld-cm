define([
	"app", 
	"oc"
],
function(app, OC) {

	// create a new module
	var RecentObjectsDashlet = app.module();

	RecentObjectsDashlet.RecentObjectModel = Backbone.Model.extend({
		defaults: function() { 
			return {
				containerId: "",
				containerName: "",
				documentId: "",
				documentName: "",
				trac: "",
				moduleId: ""
			};
		}
	});

	RecentObjectsDashlet.RecentObjectsCollection = Backbone.Collection.extend({
		model: RecentObjectsDashlet.RecentObjectModel 
	});

	RecentObjectsDashlet.Views.Layout = Backbone.Layout.extend({
		
		template: "dashboard/recentobjects",

		events: {
			"click a": "onClickRecentObject",
			"click th": "sortColumn"
		},

		className: "dashlet",
			
		initialize: function() {
			var self = this;
			this.viewModel = {};
			
			this.enableDraggability = this.options.enableDraggability;

			self.config = self.options.config;

			this.dashletName = self.config.get("dashletName");

			//get the recentObjects of the current user
			var recentObjectsDashlets = app.context.currentUserPreferences().get("recentObjectsDashlets");

			var unfetchedRecentObjects = recentObjectsDashlets[self.config.get("dashletId")];

			var ocNames = self.config.get("selectedAttributes");
			
			ocNames = _.pluck(ocNames, 'ocName');
			
			this.header = new Backbone.Collection();
			//header just contains the ocName - get the otc for this type
			app.context.configService.getAdminTypeConfig(self.config.get('selectedTypeForAttrs'), function(freshOTC){
				_.each(ocNames, function(ocName){
					if(freshOTC){
						var attribute = freshOTC.get('attrs').findWhere({'ocName': ocName});
						self.header.add(attribute);
					}
				});

				//create the array that will hold all of the recent objects
				self.recentObjects = [];

				var tempArray = [];
				var deferreds = [];
				self.removeIds = [];

				//for each of the recentObjects, add it to the deferreds array 
				_.each(unfetchedRecentObjects, function(recentObject) {
					deferreds.push(self.getOcosForRecentObjects(recentObject));
				});

				// get our dashboard config
				$.when.apply($, deferreds).then(function(){
					//remove the bad objectIds from cookie.recentObjects
					 _.each(self.removeIds, function(id){
					    var badId = unfetchedRecentObjects.indexOf(id);
					 	unfetchedRecentObjects.splice(badId, 1);
					});

					 //populate the tempArray with the correct order of recent objects
					 _.each(unfetchedRecentObjects, function(unfetchedRecentObject){
					     _.each(self.recentObjects, function(object){
					       	if(unfetchedRecentObject.recentObjectId === object.recentObjectId){
					      		tempArray.push(object);
					      	}
					 	});
					 });
					//replace the recent objects array with the order from the unfetched recent objects
					self.recentObjects = tempArray;	
					 
					//create the new dashlet view containing all of the user's recent objects
					self.viewModel.recentObjects = new RecentObjectsDashlet.RecentObjectsCollection(self.recentObjects);
					self.render();
				});
			});

		},

		getOcosForRecentObjects: function(recentObject){
			var self = this;
			var oco = new OC.OpenContentObject();
			oco.id = recentObject.recentObjectId;
			// the deferred to return when the ajax request for uploading this file is completed
			var deferred = $.Deferred();
			oco.fetch({
				global: false,
				success: function(){
					
					self.ocoSuccessCall(oco, deferred);

				},
				//if the file is no longer in repository, add it to a list and remove from cookie
				error: function(){
					self.removeIds.push(oco.id);
					deferred.resolve();
				}
			});	

			return deferred;
		},

		ocoSuccessCall: function(oco, deferred){
			var self = this;
			if(!oco.get("properties")) {
				oco.set("properties", []);
				_.each(self.header, function() {
					oco.get("properties").push("");
				});
		    }

			if (oco.get("properties").objectName ) {
				//format any dates on this recent object
				//retrieve name and creation date from the header.models
				var tempRecentObject = {
					recentObjectId: oco.id,
					properties: []
				};
				var props = oco.get("properties");
				_.each(self.header.models, function(model, index){
					
					var attrName = model.get("ocName");
					
					if(props[attrName]) {
						tempRecentObject.properties.push(props[attrName]);						
					} else {
						tempRecentObject.properties.push("");
					}

					//format if a date and value exists
					if(model.get('dataType') === 'date' && props[attrName]){
						app.context.dateService.getFormattedDate(props[attrName]).done(function(formattedDate) {
							tempRecentObject.properties[index] = formattedDate;
						});							
					}
				});

				
				self.recentObjects.push(tempRecentObject);
				
				
			}
			deferred.resolve();
		},

		afterRender: function(){
			if(this.enableDraggability){
				this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
			}
		},

		serialize: function() {
			return {
				dashletName: this.dashletName,
				recentObjects: this.recentObjects,
				header: this.header.pluck('label')
			};
		},

		onClickRecentObject: function (e) {
			app.routers.main.stageSimple(this.$(e.currentTarget).data("id"));
		},

		sortColumn: function(e) {
			var self = this;
			var index = $(e.currentTarget).data("id");
			var columnAttribute = this.header.models[index];
			var attributeName = columnAttribute.get("ocName");
			var dataType = columnAttribute.get("dataType");
			
			//give some sort of feedback to the user to show them which way they are sorting
			function dynamicSort(property, dataType, index) {
				if (self.sortProp !== property) {
					self.sortProp = property;
					self.sortAsc = true;
				}
				return function (a,b) {
					if (dataType === "date") {
						a[property] = new Date(a.properties[index]);
						b[property] = new Date(b.properties[index]);
					}
					if (self.sortAsc) {
						if (dataType === "date") {
							return (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
						} else {
							return (a.properties[index] < b.properties[index]) ? -1 : (a.properties[index] > b.properties[index]) ? 1 : 0;
						}
						
					} else {
						if (dataType === "date") {
							return (a[property] > b[property]) ? -1 : (a[property] < b[property]) ? 1 : 0;
						} else {
							return (a.properties[index] > b.properties[index]) ? -1 : (a.properties[index] < b.properties[index]) ? 1 : 0;
						}
					}
				};
			}

			this.recentObjects.sort(dynamicSort(attributeName, dataType, index));
			if (self.sortAsc) {
				self.sortAsc = false;
			} else {
				self.sortAsc = true;
			}

			this.render();
		}
	});

	return RecentObjectsDashlet;
});