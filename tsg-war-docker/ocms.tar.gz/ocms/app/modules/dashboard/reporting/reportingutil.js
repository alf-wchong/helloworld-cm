define([
	'app'
], function(app){

    var ReportingUtil = {};
    
    ReportingUtil.queryUtil = {};

    // Build up the date interval/date values for a proximity query and return on a JSON object
	ReportingUtil.queryUtil.buildProximityQuery = function(proximityDateNumber, proximityDateType, proximityDateTimeSpan){
        // for each interval, compute start and end date
        var proximityNumberAsInt = parseInt(proximityDateNumber, 10);
        var startDate = moment.utc().startOf('day');
        var endDate = moment.utc().endOf('day'); 

        if (proximityDateType === 'within') {
            startDate = startDate.subtract(proximityNumberAsInt, proximityDateTimeSpan);
            endDate = endDate.add(proximityNumberAsInt, proximityDateTimeSpan);
        } else if (proximityDateType === 'past') {
            startDate = startDate.subtract(proximityNumberAsInt, proximityDateTimeSpan);
        } else { 
            endDate = endDate.add(proximityNumberAsInt, proximityDateTimeSpan);
        }

        var startDateInterval = startDate.toDate().getTime();
        var endDateInterval = endDate.toDate().getTime();

        var jsonProximityValues = {
            'startDateInterval' : startDateInterval,
            'endDateInterval': endDateInterval,
            'startDate': startDate,
            'endDate' : endDate
        };

        return jsonProximityValues;
	};

	return ReportingUtil;
});