define([
    // Application.
    "app",
    "oc",
    "modules/common/ocquery",
    "modules/common/workflow",
    "modules/common/tracselector",
    "modules/dashboard/reporting/reportingproximitydateview",
    "modules/common/ocquery",
    "modules/common/jqplotutils",
    "modules/common/spinner",
    "modules/dashboard/reporting/reportingutil",
    "jqplot",
    "jqplotBarRenderer",
    "jqplotCanvasOverlay",
    "jqplotCategoryAxisRenderer",
    "jqplotCanvasTextRenderer",
    "jqplotCanvasAxisTickRenderer",
    "jqplotPieRenderer",
    "jqplotPointLabels"
],
function(app, oc, Query, Workflow, TracSelector, ProximityDateView, OCQuery, JQPlotUtils, HPISpinner, ReportingUtil) {
    "use strict";
    // Create a new module.
    var ReportingDashlet = app.module();

    ReportingDashlet.Views.Layout = Backbone.Layout.extend({
        template: "dashboard/reportingdashlet/reportingdashlet",
        className : "dashlet",
        events: {
            'click .executeRange' : 'execute',
            'click .reportingGetAllDocs' : 'navigateToAllDocsInSearch'
        },
        initialize: function(){
            var self = this;
            this.config = this.options.config;

            this.enableDraggability = this.options.enableDraggability;
            this.tabs = [];

            // graph configs
            this.graphType = this.config.get("graphType");

            this.proximityOperatorsList = ["LOGIC_LIKE_WITHIN", "LOGIC_LIKE_PAST", "LOGIC_LIKE_NEXT"];

            // the resulting OC Queries that are built up in the admin
            this.plotQueries = [];

            this.eventsObj = _.extend({}, Backbone.Events);

            // initialize the graph view
            this.reportingDashletGraph = new ReportingDashlet.ReportingDashletGraph({config: this.config});

            // take the admin configuration and translate to search parameters to send in an OC Query
            this.buildConfiguredQueries();

            this.terms = this.config.get("terms");
            // grab the labels from the term names
            this.seriesList = [];
             _.each(this.terms, function(term) {
                self.seriesList.push(term.termName);
            });

            var isActiveTab = false;
            this.proximityDateView = new ProximityDateView.View({config: this.config});
            isActiveTab=true;         
            this.tabs.push(this.generateTab("reportingDashlet", window.localize("dashboard.dashlets.reportingDashlet.proximityDateControl.reportingdashlet"), isActiveTab));

        },
        navigateToAllDocsInSearch: function () {
            var queryJSON = this.buildGetAllDocsQuery(this.queryExecuted.searchParameters);
            var objectType = queryJSON.objectType;
            var query = queryJSON.query;

            TracSelector.establishTracByObjectType(objectType, function(establishedTrac){
                var searchUrl = "search/" + establishedTrac + "/" + objectType + "/" + query;
                Backbone.history.navigate(searchUrl, {trigger: true});
            });
        },

        buildGetAllDocsQuery: function(searchParameters) {
            var objectType = "";
            var queryStringWithoutType = "";
            var objectTypePartOfQuery = "";
            _.each(searchParameters, function(searchParam){
                if(searchParam.paramType === "type") {
                    objectType = searchParam.paramValue;
                    objectTypePartOfQuery = "paramName=" + objectType + "&paramValue=" + objectType + "&paramType=type";
                } else if(searchParam.operator) {
                    var paramName = searchParam.paramName;
                    var paramValue = searchParam.paramValue;
                    var operator = searchParam.operator;
                    queryStringWithoutType += "/paramName=" + paramName + "&operator=" + operator + "&paramValue=" + paramValue + "&paramType=property";
                        
                } else if(this.config.get("dateRangeAttribute") === searchParam.paramName && this.config.get("enableDateRange") === "true"){
                    var dateRangeQueryJSON =  ReportingUtil.queryUtil.buildProximityQuery(this.proximityDateView.proximityDateNumber, this.proximityDateView.proximityDateType, this.proximityDateView.proximityDateTimeSpan);
                    var paramValueString = dateRangeQueryJSON.startDateInterval + "|" + dateRangeQueryJSON.endDateInterval + "$*prx*$" + this.proximityDateView.proximityDateType + "|" + this.proximityDateView.proximityDateNumber + "|" + this.proximityDateView.proximityDateTimeSpan; 

                    queryStringWithoutType += "/paramName=" + this.config.get("dateRangeAttribute") + "&paramValue=" + encodeURIComponent(paramValueString) + "&paramType=property";
                } else {
                    queryStringWithoutType += "/paramName=" + searchParam.paramName + "&paramValue=" + encodeURIComponent(searchParam.paramValue) + "&paramType=property";
                }
            }, this);

            var combinedQuery = objectTypePartOfQuery + queryStringWithoutType;
            var queryWithObjectType = {
                "query": combinedQuery,
                "objectType": objectType
            };

            return queryWithObjectType;
        },
        buildConfiguredQueries: function() {
            var terms = this.config.get("terms");
            var self = this;

            // we do not care about date range settings at this point. we generating the search params
            // that are property based and will append date parameters later if necessary
            _.each(terms, function(term) {
                var distinct = false;
                var distinctAttr = "";
                var query = new OCQuery.Collection([],{
                        mode: "client"
                    }); 
                query.searchParameters = [];
                _.each(term.criteria, function(criteria) {

                    // only create an actual search parameter if it's not a distinct query
                    if(criteria.operator === "LOGIC_DISTINCT") {
                        distinct = true;
                        distinctAttr = criteria.selectedAttribute;
                    }
					else if(_.indexOf(this.proximityOperatorsList, criteria.operator) != -1){
                        var paramOperator = "";
                        if(criteria.operator === "LOGIC_LIKE_WITHIN") {
                            paramOperator = "within";
                        } else if(criteria.operator === "LOGIC_LIKE_PAST") {
                            paramOperator = "past";
                        } else {
                            paramOperator = "next";
                        }
                        var paramValueJson = ReportingUtil.queryUtil.buildProximityQuery(criteria.proximityDateValue, paramOperator, criteria.proximityDateRange);
                        var paramValueString = paramValueJson.startDateInterval + "|" + paramValueJson.endDateInterval + "$*prx*$" + paramOperator + "|" + criteria.proximityDateValue + "|" + criteria.proximityDateRange; 
                        var proximityParameters = {
                            paramName: [criteria.selectedAttribute],

                            paramType: "property",

                            paramValue: paramValueString
                        };
                        query.searchParameters.push(proximityParameters);
                    } else {
                        var sp = {
                            // the attribute we're searching on
                            paramName: criteria.selectedAttribute,
                            // the value of the attribute we're searching on
                            paramValue: self._tokenResolve(criteria.value),
                            // this is a property we're searching on
                            paramType: "property",
                            operator: criteria.operator === "LOGIC_DISTINCT" ? "OPERATOR_EQUALS" : criteria.operator
                        };
                        query.searchParameters.push(sp);
                    }
                }, this);

                // add another search parameter for the type the user configured in the admin
                var sp = {
                    paramName: term.type,
                    paramValue: term.type,
                    paramType: "type"
                };
                query.searchParameters.push(sp);

                self.plotQueries.push({"query": query, "label": term.termName, "distinct": distinct, "distinctAttr": distinctAttr});
            }, this);
            
        },
        execute: function(){
            // if this is a date range/interval plot, we need to generate an OC query per 
            // each date range interval value
            if(this.config.get("enableDateRange") === "true") {
                this.dateRangeQueries = this.proximityDateView.buildProximitySearchParams();
                this.executeDateRangeQueries();
            }
            else {
                this.executeConfiguredQueries();
            }
        },
        executeConfiguredQueries: function () {
            var self = this;
            
            var deferreds = [];
            var resultsArray = [];
            var axisResults = [];
            var xAxisTicks = [];
            var isDistinct = false;
            var seriesLabels = [];


            // execute the configured queries and plot results, taking into consideration that if the chart is configured to 
            // plot all DISTINCT values, we are running a wildcard  search and sorting later
            _.each(this.plotQueries, function(plotQuery) {
                var deferred = $.Deferred();
                deferreds.push(deferred);

                self.queryExecuted = plotQuery.query;

                plotQuery.query.fetch({
                    success: function (results) {
                        // if we are doing a DISTINCT query, we need to sort the  results here
                        if(plotQuery.distinct) {
                            isDistinct = true;
                            var ocos = [];
                            results.fullCollection.each(function(oco){
                                ocos.push(_.extend({}, oco.get("properties"), {
                                    "distinctAttr": oco.get("properties")[plotQuery.distinctAttr]
                                }));
                            });
                            var distinctResults = _.countBy(ocos, function(oco) {
                                return oco.distinctAttr;
                            });

                            _.each(distinctResults, function(count, label) {
                                if(label !== undefined && label !== "" && label !== "undefined") {
                                    resultsArray.push({"label": label, "numResults": count});
                                }  
                            });
                        }
                        else {
                            if(plotQuery.label !== undefined && plotQuery.label !== "" && plotQuery.label !== "undefined") {
                                // otherwise, just push  all the term results
                                resultsArray.push({"label": plotQuery.label, "numResults": results.fullCollection == undefined ? 0 : results.length});
                            }
                        }
                        deferred.resolve();
                    }
                });
            }, self);
            
            // when finished running queries, format the results for jqplot
            $.when.apply($, deferreds).done(function() {
                //get the queries in order
                _.each(resultsArray, function(result) {
                    axisResults.push({ "label": result.label, "count": result.numResults });
                });
                var formattedResults = [];
                var xAxis = 1;
                _.each(axisResults, function(result) {
                     if(self.graphType === "pie") {
                        formattedResults.push([result.label, result.count]);
                    }
                    else {
                        formattedResults.push([xAxis, result.count]);
                    }
                    xAxis++;
                    xAxisTicks.push(result.label);
                    seriesLabels.push({"label": result.label});

                });

                self.reportingDashletGraph.labels = seriesLabels;
                self.reportingDashletGraph.xAxisTicks = _.uniq(xAxisTicks);
                self.reportingDashletGraph.isDistinct = isDistinct;

                self.reportingDashletGraph.plot([formattedResults]);
            });
        },
        executeDateRangeQueries: function () {
            var self = this;
            
            var deferreds = [];
            var orderedQueries = [];
            var resultsArray = [];
            var allDistinctResults = [];
            var seriesLabels = [];
            var xAxisTicks = [];
            var isDistinct = false;

            // for each configured query term and for each desired date range interval, generate a 
            // composite query that selects all content for that query term/date interval
            _.each(this.plotQueries, function(plotQuery) {
                var targetPlotQuery = plotQuery.query;
                _.each(self.dateRangeQueries, function(query) {
                    var compositeQuery = new OCQuery.Collection([], {});
                    var orderString = query.searchParameters[0].paramValue;

                    compositeQuery.searchParameters = [];
                    orderedQueries.push(orderString);
                   
                    // property-based parameters added to composite search params
                    _.each(targetPlotQuery.searchParameters, function(sp) {
                        compositeQuery.searchParameters.push(sp);
                    });

                    // date interval parameters added to composite search params
                     _.each(query.searchParameters, function(sp) {
                        compositeQuery.searchParameters.push(sp);
                    });


                    var deferred = $.Deferred();
                    deferreds.push(deferred);

                    self.queryExecuted = compositeQuery;

                    compositeQuery.fetch({
                        success: function (results) {
                            // if we are doing a DISTINCT query, we need to sort the  results here
                            if(plotQuery.distinct) {
                                isDistinct = true;
                                var ocos = [];
                                if(results.fullCollection !== undefined) {
                                    _.each(results.fullCollection.models, function(oco) {
                                    ocos.push(_.extend({}, oco.get("properties"), {
                                        "distinctAttr": oco.get("properties")[plotQuery.distinctAttr]
                                    }));
                                });
                                }
                                
                                var distinctResults = _.countBy(ocos, function(oco) {
                                    return oco.distinctAttr;
                                });

                                if(_.isEmpty(distinctResults)) {
                                    resultsArray.push({"series": "$placeholder$", "targetPlot": targetPlotQuery, "orderString": orderString, "count": results.fullCollection == undefined ? 0 : results.length});
                                }
                                else {
                                    _.each(distinctResults, function(count, label) {
                                        if(label !== undefined && label !== "" && label !== "undefined") {
                                            resultsArray.push({"series": label, "targetPlot": targetPlotQuery, "orderString": orderString, "count": count});
                                            allDistinctResults.push(label);
                                        }
                                    }); 
                                }

                                deferred.resolve();
                            }
                            else {
                                if(plotQuery.label !== undefined && plotQuery.label !== "" && plotQuery.label !== "undefined") {
                                    resultsArray.push({"series": plotQuery.label, "targetPlot": targetPlotQuery, "orderString": orderString, "count": results.fullCollection == undefined ? 0 : results.length});
                                }
                                deferred.resolve();
                            }
                        }
                    });
                }, self);
            });
            

            $.when.apply($, deferreds).done(function() {
                // formatted results array
                var formattedResults = [];

                if(isDistinct) {
                    allDistinctResults = _.uniq(allDistinctResults);
                    _.each(allDistinctResults, function(seriesVal) {
                        var formattedSeries = [];
                        seriesLabels.push({"label": seriesVal});
                        var xAxis = 1;

                         // these queries can come back in different orders, but we want to line up the results in date order
                        _.each(_.uniq(orderedQueries), function(query) {
                            var resultForQuery = _.find(resultsArray, function(result) {
                                return (result.orderString === query && result.series === seriesVal);
                            });

                            var dateTemp = query.substring(0, query.indexOf('|'));
                            var date = new Date(Number(dateTemp));
                            date = date.toLocaleDateString();

                            if(resultForQuery) {
                                if(self.graphType === "pie") {
                                    formattedSeries.push([seriesVal, resultForQuery.count]);
                                }
                                else {
                                    formattedSeries.push([xAxis, resultForQuery.count]);
                                }
                            }
                            else {
                                formattedSeries.push([xAxis, 0]);
                            }

                            xAxis++;     
                            xAxisTicks.push(date);
                            
                        });
                        formattedResults.push(formattedSeries);
                    });
                }

                else {

                    _.each(self.seriesList, function(seriesVal) {
                        var formattedSeries = [];
                        seriesLabels.push({"label": seriesVal});
                        var xAxis = 1;
                        // these queries can come back in different orders, but we want to line up the results in date order
                        _.each(_.uniq(orderedQueries), function(query) {
                            _.each(resultsArray, function(result){
                                if(query === result.orderString && result.series === seriesVal) {
                                    var dateTemp = query.substring(0, query.indexOf('|'));
                                    var date = new Date(Number(dateTemp));
                                    date = date.toLocaleDateString();

                                    if(self.graphType === "pie") {
                                        formattedSeries.push([seriesVal, result.count]);
                                    }
                                    else {
                                        formattedSeries.push([xAxis, result.count]);
                                    }
                                    xAxisTicks.push(date);
                                    xAxis++;
                                }
                            
                            });
                        });
                        formattedResults.push(formattedSeries);
                    });
                }
                self.reportingDashletGraph.labels = seriesLabels;
                self.reportingDashletGraph.dateRangeQueries = self.dateRangeQueries;
                self.reportingDashletGraph.xAxisTicks = _.uniq(xAxisTicks);
                self.reportingDashletGraph.isDistinct = isDistinct;
                self.reportingDashletGraph.plot(formattedResults);
            });

        },
        // we want to resolve a token that a user used in a query criteria - currently only resolves dates
        // and user information
        _tokenResolve: function(value) {
            if(value === '$date') {
                return new Date();
            } else if (value === "$user.loginName") {
                return app.user.get("loginName");
            } else if (value === "$user.displayName") {
                return app.user.get("displayName");
            } else {
                return value;
            }
        },
        // not currently being used, but if want to add multiple tabs like workflow reporting does you can use this function
        generateTab: function(tabId, tabName, isActive){
            var tab = {};
            tab.id = tabId;
            tab.name = tabName;
            tab.active = isActive;
            return tab;
        },
        afterRender: function(){
            if(this.enableDraggability){
                this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
            }
            this.setView(".reporting-dashlet-range-interval", this.proximityDateView, true).render();
            if(this.reportingDashletGraph) {
                this.setView("#reportingGraphViewDiv-" + this.cid, this.reportingDashletGraph, true).render();
            }
            this.execute();

        },
        serialize: function(){
            return {
                "tabs" : this.tabs,
                "dashletName": this.config.get("dashletName"),
                "enableDateRange": this.config.get("enableDateRange") === "true" ? true : false,
                "enableGetAllDocsButton": this.config.get("getAllDocsEnabled") === "true" ? true : false,
                "cid": this.cid
            };
        }
    });

    //Reporting Dashlet Graph View
    ReportingDashlet.ReportingDashletGraph = Backbone.Layout.extend({
        template: "dashboard/reportingdashlet/reportinggraph",
        events: {
            'jqplotDataClick .graph-container' : 'onGraphClick',
            'click .executeRange' : 'execute'
        },
        initialize: function() {
            this.config = this.options.config;
            this.seriesArray = [];
            this.seriesLabels = [];
            this.xAxisTicks = [];
            this.isDistinct = false;
            this.graphSettings = {};
            this.dateRangeQueries = [];
            this.labels = [];
            this.terms = this.config.get("terms");
            this.fetched = false;
            this.rendered = false;
            this.loadingResults = true;
            
        },
        onGraphClick: function(ev, seriesIndex, pointIndex, data) {
            var selectedTerm;
            // if we are dealing with an IS DISTINCT query, we will have to take extra steps
            // to format the search queries with  what is clicked
            if(this.isDistinct) {
                // use the first configured term
                selectedTerm = this.terms[0];

            }
            else {
                // otherwise, seriesIndex corresponds to the term result that was clicked,
                // so we will use it to determine which query term was clicked
                if(this.config.get("graphType") === "pie") {
                    selectedTerm = _.find(this.terms, function(term) {
                        return term.termName == data[0];
                    });
                }
                else {
                    if(this.config.get("enableDateRange") === "true") {
                        selectedTerm = this.terms[seriesIndex];
                    }
                    else {
                        selectedTerm = this.terms[pointIndex];
                    }
                }
            }

            // determine type and trac and query to run a search corresponding to the graph data clicked
            var objectType = selectedTerm.type;

            var query = this.formatQueryString(selectedTerm, seriesIndex, pointIndex);
            query = this._tokenResolve(query);
            TracSelector.establishTracByObjectType(objectType, function(establishedTrac){
                var searchUrl = "search/" + establishedTrac + "/" + objectType + "/" + query;
                Backbone.history.navigate(searchUrl, {trigger: true});
            });
        },

        formatQueryString: function(term, seriesIndex, pointIndex) {
            // usisng the configuration of the term that was clicked, construct the search url
            var objectType = term.type;
            var distinctParamAttr = "";
            var query = "paramName=" + objectType + "&paramValue=" + objectType + "&paramType=type";
            _.each(term.criteria, function(criterion) {
                if(criterion.operator !== "LOGIC_DISTINCT") {
                    var paramName = criterion.selectedAttribute;
                    var paramValue = criterion.value;
                    var operator = criterion.operator;
                    query = query + "/paramName=" + paramName + "&operator=" + operator + "&paramValue=" + paramValue + "&paramType=property";
                }
                else {
                    distinctParamAttr = criterion.selectedAttribute;
                }
            });

            if(this.isDistinct) {
                // add the value from the results
                var distinctParamValue = this.config.get("enableDateRange") === "false" ? this.labels[pointIndex].label : this.labels[seriesIndex].label;
                query = query + "/paramName=" + distinctParamAttr + "&operator=OPERATOR_EQUALS&paramValue=" + distinctParamValue + "&paramType=property";
            }

            // if date range enabled, scope query to the selected date range
            if(this.config.get("enableDateRange") === "true") {
                var dateRangeQuery = this.dateRangeQueries[pointIndex].searchParameters[0].paramValue;
                query = query + "/paramName=" + this.config.get("dateRangeAttribute") + "&paramValue=" + dateRangeQuery + "&paramType=property";
            }

            return query;
        },
        _tokenResolve: function(queryString) {
            if(queryString.includes('$date')) {
                var date = new Date();
                return queryString.replace("$date", date);
            } else if (queryString.includes("$user.loginName")) {
                return queryString.replace("$user.loginName", app.user.get("loginName"));
            } else if (queryString.includes("$user.displayName")) {
                return queryString.replace("$user.loginName", app.user.get("displayName"));
            } else {
                return queryString;
            }
        },
        getGraphSettings : function() {
            // Check to see if the configuration method was raw json. If so, we will just pass that to the chart.
            if(this.config.get("jsonConfig") !== "" && this.config.get("jsonConfig") !== undefined) {
                var configJson = JSON.parse(this.config.get("jsonConfig"));
                return JQPlotUtils.applyRenderers(configJson);

            }
         
            // Otherwise, grab the default configuration JSON for the chart type in our JQPLotUtils and parse in the configurations
            var graphType = this.config.get("graphType");
            return JQPlotUtils.applyGraphConfigurations(graphType, this.config, this.xAxisTicks, this.labels); 
            
        },

        plot: function(results) {
            this.fetched = true;
            this.results = results;
            if (this.spinner) {
                HPISpinner.destroySpinner(this.spinner);
            }
            this.render();
           
        },
        afterRender: function() {
            if (!this.fetched && !this.spinner) {
                this.spinner = HPISpinner.createSpinner({
                    color: '#666'
                }, this.$el.find("#resultsSpinner")[0]);
            }
            
            if (this.fetched) {
                 $.jqplot.config.enablePlugins = this.config.get("enableTrendLine") === "true" ? true : false;

                // clear out previous graph  from div
                $('#reportingGraphDiv-' + this.cid).empty();

                // get configs and plot
                this.plot1 = $.jqplot("reportingGraphDiv-" + this.cid, this.results, this.getGraphSettings());
            }
        },          
        serialize: function() {
            return {
                "cid" : this.cid
            };
        }
    });
    return ReportingDashlet;
});