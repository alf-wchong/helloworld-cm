// ProximityDateView contol module
define([
    "app",
    "handlebars",
    "modules/common/ocquery",
    "modules/dashboard/reporting/reportingutil",
],

function(app, Handlebars, OcQuery, ReportingUtil) {

    // Create a new module.
    var ProximityDateView = {};

    ProximityDateView.View = Backbone.Layout.extend({
        template: "dashboard/reportingdashlet/reportingproximitydatecontrols",
        events: {
            "click .executeRange" : "buildQuery"
        },
        initialize: function(options){
            var self = this;
            
            if(options){
                this.model = options.model;
                this.config = this.options.config;
            }


            this.proximityDateTypes = [{
                label: window.localize("generic.within"),
                value: "within",
                selected: false
            }, {
                label: window.localize("generic.past"),
                value: "past",
                selected: false
            }, {
                label: window.localize("generic.next"),
                value: "next",
                selected: false
            }];

            this.proximityDateIntervals = [{
                label: window.localize("generic.days"),
                value: "86400000",
                selected: false
            }, {
                label: window.localize("generic.weeks"),
                value: "604800000",
                selected: false
            }, {
                label: window.localize("generic.months"),
                value: "months",
                selected: false
            }];


            this.proximityDateTimeSpans = [{
                label: window.localize("generic.days"),
                value: "days",
                selected: false
            }, {
                label: window.localize("generic.weeks"),
                value: "weeks",
                selected: false
            }, {
                label: window.localize("generic.months"),
                value: "months",
                selected: false
            }];

            // initialize the proximity controls with the default values
             _.each(this.proximityDateTypes, function(option) {
                if(option.value === self.config.get("proximityDateType")) {
                    option.selected = true;
                }
            });
             _.each(this.proximityDateIntervals, function(option) {
                if(option.value === self.config.get("proximityDateInterval")) {
                    option.selected = true;
                }
            });
            _.each(this.proximityDateTimeSpans, function(option) {
                if(option.value === self.config.get("proximityDateTimeSpan")) {
                    option.selected = true;
                }
            });

            this.proximityDateType = this.config.get("proximityDateType");
            this.proximityDateInterval = this.config.get("proximityDateInterval");
            this.proximityDateTimeSpan = this.config.get("proximityDateTimeSpan");
            this.proximityDateNumber = this.config.get("proximityDateNumber");

        },
        getDaysinMonthInMilliseconds: function(month){
            var daysInMonth = new Date(month.getYear(), month.getMonth()+1, 0).getDate();
            return Number(daysInMonth) * 86400000;
        },
        getFirstDayOfMonth: function(month) {
            var firstDay = new Date(month.year(), month.month(), 1);
            return firstDay;
        },
        buildProximitySearchParams: function () {
            this.proximityDateType = !this.$('#proximityDateType').val() ? this.proximityDateType : this.$('#proximityDateType').val();
            this.proximityDateInterval = !this.$('#proximityInterval').val() ? this.proximityDateInterval : this.$('#proximityInterval').val();
            this.proximityDateNumber = !this.$('#proximityDateNumber').val() ? this.proximityDateNumber : this.$('#proximityDateNumber').val();
            this.proximityDateTimeSpan = !this.$('#proximityDateTimeSpan').val() ? this.proximityDateTimeSpan : this.$('#proximityDateTimeSpan').val();

            var value = '';

            var dateType = this.config.get("dateRangeAttribute");

            var arrayOfQueries = [];

            // we only want to compute the value if all of the values have been filled in
            if (!this.proximityDateType || !this.proximityDateNumber || !this.proximityDateTimeSpan || !this.proximityDateInterval) {
                return;
            }

            var jsonProximityValues = ReportingUtil.queryUtil.buildProximityQuery(this.proximityDateNumber, this.proximityDateType, this.proximityDateTimeSpan);
            var startDateInterval = jsonProximityValues.startDateInterval;
            var endDateInterval = jsonProximityValues.endDateInterval;
            var startDate = jsonProximityValues.startDate;
            var endDate = jsonProximityValues.endDate;

            var intervalPointer = 0;
            //monthWatch variable watches what month is being queued up
            var monthWatch = startDate;
            var intervalInMilliseconds = Number(this.proximityDateInterval);
            var firstDay = "";

            if (this.proximityDateInterval === 'months') {
                endDateInterval = this.getFirstDayOfMonth(endDate);
                for (var i = 0; intervalPointer < Number(endDateInterval); i++) {
                    //Have to get the # of milliseconds per month.  Some months have different days so using getDaysinMonthsInMilliseconds method to correctly retrieve # of milliseconds in a month.
                    firstDay = this.getFirstDayOfMonth(monthWatch);
                    intervalInMilliseconds = this.getDaysinMonthInMilliseconds(firstDay);
                    intervalPointer = Number(firstDay) + intervalInMilliseconds;
                    value = Number(firstDay) + '|' + intervalPointer;
                    monthWatch = monthWatch.add(1, 'months');

                    // need to tack on the actual user input parameters that way we will be able to repopulate from a different
                    // day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
                    var proximityParams = '$*prx*$' + this.proximityDateType + '|' + this.proximityDateNumber + '|' + this.proximityDateTimeSpan;

                    var sp = {
                        paramName: dateType,
                        paramValue: value + proximityParams,
                        paramType: "property"
                    };
                    var query = new OcQuery.Collection([], {});
                    query.searchParameters = [];

                    query.searchParameters.push(sp);
                    arrayOfQueries.push(query);
                    startDateInterval = Number(startDateInterval) + intervalInMilliseconds;
                }
            } else {
                for (var i = 0; intervalPointer < Number(endDateInterval); i++) {
                    //Have to get the # of milliseconds per month.  Some months have different days so using getDaysinMonthsInMilliseconds method to correctly retrieve # of milliseconds in a month.
                    intervalPointer = Number(startDateInterval) + intervalInMilliseconds - 1;
                    value = startDateInterval + '|' + intervalPointer;

                    // need to tack on the actual user input parameters that way we will be able to repopulate from a different
                    // day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
                    var proximityParams = '$*prx*$' + this.proximityDateType + '|' + this.proximityDateNumber + '|' + this.proximityDateTimeSpan;

                    var sp = {
                        paramName: dateType,
                        paramValue: value + proximityParams,
                        paramType: "property"
                    };
                    var query = new OcQuery.Collection([], {});
                    query.searchParameters = [];

                    query.searchParameters.push(sp);
                    arrayOfQueries.push(query);
                    startDateInterval = Number(startDateInterval) + intervalInMilliseconds;
                }
            }
            return arrayOfQueries;

        },
        beforeRender: function() {
            var self = this;
             _.each(this.proximityDateTypes, function(option) {
                if(option.value === self.config.get("proximityDateType")) {
                    option.selected = true;
                }
            });
             _.each(this.proximityDateIntervals, function(option) {
                if(option.label === self.config.get("proximityDateInterval")) {
                    option.selected = true;
                }
            });
            _.each(this.proximityDateTimeSpans, function(option) {
                if(option.value === self.config.get("proximityDateTimeSpan")) {
                    option.selected = true;
                }
            });
        },
        serialize: function(){
            return {
                "proximityDateNumber": this.config.get("proximityDateNumber"),
                "proximityDateTimeSpans": this.proximityDateTimeSpans,
                "proximityDateTypes": this.proximityDateTypes,
                "proximityDateIntervals": this.proximityDateIntervals
            };
        }
    });

    return ProximityDateView;
});