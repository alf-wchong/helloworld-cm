//Index Inbox module
define([
	// Application.
	"app",
	"moment",
	"modules/common/workflow",
	"jqplot",
	"jqplotBarRenderer",
	"jqplotCategoryAxisRenderer",
	"jqplotPointLabels"
],

function(app, moment, Workflow) {
	"use strict";
	// Create a new module.
	var WorkflowReportingDashlet = app.module();

	WorkflowReportingDashlet.Views.Layout = Backbone.Layout.extend({
		template: "dashboard/workflowreportingdashlet/workflowreportingdashlet",
		className : "dashlet",
		events: {
			"click .workflowTab": "tabClicked",
		},
		initialize: function(){
			this.config = this.options.config;
			this.enableDraggability = this.options.enableDraggability;
			this.tabs = [];

			if (this.config.get("numPerPage")) {
				//Parse the config to an int, with a radix of 10 (the base of the number- decimal)
				this.numPerPage = parseInt(this.config.get("numPerPage"), 10);
			}

			if (this.config.get("attrToShow")) {
				this.attrToShow = this.config.get("attrToShow");
			}

			if (this.config.get("selectedPicklist")){
				this.selectedPicklist = this.config.get("selectedPicklist");
			}


			//tab logic, for now we will assume if My Workflows is configured
			//that it will be the active tab
			//TODO: make the tab that is shown on load configurable
			var options = {
				numPerPage: this.numPerPage,
				attrToShow: this.attrToShow,
				selectedPicklist: this.selectedPicklist,
			};
			var options_myWorkflow = {
				numPerPage: this.numPerPage,
				attrToShow: this.attrToShow,
				selectedPicklist: this.selectedPicklist,
				loadAllOption : false,
				allSnapshotsLoaded : false,
			};

			// assume my workflows gets initialized to active
			if(this.config.get("showMyWorkflows")) {
				this.myWorkflowsView = new WorkflowReportingDashlet.MyWorkflowsView(options_myWorkflow);
				this.tabs.push(this.generateTab("myWorkflowsTab", window.localize("dashboard.myWorkflows"), true));
			}
			
			if(this.config.get("showWorkflowHistory")) {
				if (!this.config.get("showMyWorkflows") && !this.config.get("showGroupTasks")) {
					this.workflowHistoryView = new WorkflowReportingDashlet.WorkflowHistoryView();
				}
				this.tabs.push(this.generateTab("workflowHistoryTab", window.localize("dashboard.workflowHistory"), false));
			}

			if (this.config.get("showGroupTasks")) {
				var isGroupTasksActive = false;
				if (!this.config.get("showMyWorkflows") && !this.config.get("showWorkflowHistory")) {
					this.groupTasksView = new WorkflowReportingDashlet.GroupTasksView(options);
					isGroupTasksActive = true;
				}
				this.tabs.push(this.generateTab("groupTasksTab", window.localize("dashboard.groupTasks"), isGroupTasksActive));
			}
		},
		tabClicked: function(e){
			//get jquery representation of clicked html li
			var $el = $(e.currentTarget);
			var tabId = $el.attr("id");

			var options = {
				numPerPage: this.numPerPage,
				attrToShow: this.attrToShow,
				selectedPicklist: this.selectedPicklist,
			};

			if(!$el.hasClass("active")) {
				// Clear old view
				this.removeView("#subdashletDiv");
				
				// Set new tab view relevant to the tab selected
				this.setTabView(tabId, options);
			}
		},
		setTabView: function(tabId, options) {
			if (tabId === "myWorkflowsTab") {
				//if the view doesn't exist yet, create it
				if(!this.myWorkflowsView){
					this.myWorkflowsView = new WorkflowReportingDashlet.MyWorkflowsView(options);
				}
				this.setView("#subdashletDiv", this.myWorkflowsView, true).render();
			} else if(tabId === "workflowHistoryTab") {
				//if the view doesn't exist yet, create it
				if(!this.workflowHistoryView){
					this.workflowHistoryView = new WorkflowReportingDashlet.WorkflowHistoryView();
				}
				this.setView("#subdashletDiv", this.workflowHistoryView, true).render();
			} else if (tabId === "groupTasksTab") {
				//if the view doesn't exist yet, create it
				if (!this.groupTasksView) {
					this.groupTasksView = new WorkflowReportingDashlet.GroupTasksView(options);
				}
				this.setView("#subdashletDiv", this.groupTasksView, true).render();
			}

			// Clean up the active class then reset on appropriate tab
			$(".workflowTab").removeClass("active");
			$("#" + tabId).addClass("active");
		},
		generateTab: function(tabId, tabName, isActive){
			var tab = {};
			tab.id = tabId;
			tab.name = tabName;
			tab.active = isActive;
			return tab;
		},
		afterRender: function(){
			if(this.enableDraggability){
				this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
			}
			if(this.myWorkflowsView){
				this.setView("#subdashletDiv", this.myWorkflowsView, true).render();
			} else if(this.workflowHistoryView) {
				this.setView("#subdashletDiv", this.workflowHistoryView, true).render();
			} else if (this.groupTasksView) {
				this.setView("#subdashletDiv", this.groupTasksView, true).render();
			}
		},
		serialize: function(){
			
			return {
				"tabs" : this.tabs,
				"dashletName": this.config.get("dashletName")
			};

		}
	});

	//My Workflows View
	WorkflowReportingDashlet.MyWorkflowsView = Backbone.Layout.extend({
		template: "dashboard/workflowreportingdashlet/myworkflows",
		events: {
			//click event for our refresh icon goes here
			"click #workflowReportingRefresh" : "refreshDashlet",
			// when the user clicks the link column of the result, we want to direct them to the stage
			"click .myworkflow-result-link": "onResultClick",
			//loading options button
			"click .loadAllOptionBtn": "loadAllSnapshots"
		},
		initialize: function(options) {
			this.workflowInstances = [];
			this.numPerPage = options.numPerPage;
			this.attrToShow = options.attrToShow;

			this.workflowInstanceSnapshots = new Workflow.WorkflowInstanceSnapshotCollection([], {"numPerPage": this.numPerPage, "attrToShow": this.attrToShow});
			this.fetchSnapshots();
		},
		fetchSnapshots: function() {
		    var self = this;
            self.workflowInstanceSnapshots.fetch({
                success: function(){
                    self.workflowInstances = self.getJSONObjectArray();

                    if (!isNaN(self.numPerPage) && self.workflowInstanceSnapshots.length > 0 && self.workflowInstanceSnapshots.length >= self.numPerPage) {
                        self.showWithLoadAllSnapshotsButton();
                    }

                    self.render();
                }
            });
		},
		showWithLoadAllSnapshotsButton: function() {
			if (this.allSnapshotsLoaded === false) {
				this.loadAllOption = true;
                this.render();
            }
		},
		loadAllSnapshots: function() {
			//set new workflow snapshot options
			this.numPerPage = -1,
			this.attrToShow = this.attrToShow,

			//initialize the snapshot collection with the new options
			this.workflowInstanceSnapshots = new Workflow.WorkflowInstanceSnapshotCollection([], {"numPerPage": this.numPerPage, "attrToShow": this.attrToShow});
			this.fetchSnapshots();
			
			//update variables that the loadAllOption has been selected, no longer display button
			this.loadAllOption = false;
			this.allSnapshotsLoaded = true;
			
			this.render();
		},
		getJSONObjectArray: function(){
			var self = this;
			return self.workflowInstanceSnapshots.toJSONObjectArray();
		},
		// called when a user clicks the link column 
        onResultClick: function(event) {
            var objectId = event.target.name;

            app.routers.main.stageSimple(objectId);

        },
		serialize: function(){
			if(this.workflowInstanceSnapshots.models[0] && this.workflowInstanceSnapshots.models[0].get("formName") !== "" && (this.workflowInstanceSnapshots.length !== this.workflowInstances.length)){
				this.workflowInstances = this.getJSONObjectArray();
			}
			return{
				//here is where you will list the objects/properties you need for handlebars
				//in your template for example:
				"workflowInstances" : this.workflowInstances,
				loadAllOption : this.loadAllOption
			};
		},
		refreshDashlet: function() {
			var self = this;

			self.workflowInstanceSnapshots.fetch({
				success: function(){
					self.render();
				}
			});
		}
	});

	//Workflow History View
	WorkflowReportingDashlet.WorkflowHistoryView = Backbone.Layout.extend({
		template: "dashboard/workflowreportingdashlet/workflowhistory",
		events: {
			"change #wfHistoryDropdown" : "changeGraph"
		},
		initialize: function() {
			this.config = this.options.config;
		},
		changeGraph: function(e) {
			var $el = $(e.currentTarget);
			var val = $el.val();
			
			this.plot1.destroy();
			this.plot1 = $.jqplot("wfHistoryGraphDiv", this.getSeries(val), this.getGraphSettings(val));
		},
		getSeries : function(val) {
			var seriesArray = [];
			var started = [];
			var finished = [];
			var pending = [];
			if(val === "5months") {
				started = [24, 16, 9, 12, 12];
			    finished = [20, 17, 11, 9, 15];
			    pending = [15, 12, 6, 3, 7];
			} else if (val === "5days"){
				started = [10, 15, 9, 8, 16];
			    finished = [7, 14, 5, 11, 13];
			    pending = [0, 0, 0, 0, 32];
			}
			seriesArray = [started, finished, pending];	
			return seriesArray;
		},
		getGraphSettings : function(val) {
			var seriesLabels = [];
			var today = new Date();
			var ticks = [];
			if(val === "5months") {
				var calendar = ["January", "February", "March", "April", "May", "June", "July", "August", 
					"September", "October", "November", "December"];

			    var month = today.getMonth();
			    var m0 = new Date();
			    m0.setMonth(month - 1);
			    var m1 = new Date();
			    m1.setMonth(m0.getMonth() - 1);
			    var m2 = new Date();
			    m2.setMonth(m1.getMonth() - 1);
			    var m3 = new Date();
			    m3.setMonth(m2.getMonth() - 1);

			    ticks = [calendar[m3.getMonth()], calendar[m2.getMonth()], calendar[m1.getMonth()], 
			    	calendar[m0.getMonth()], calendar[month]];

			    seriesLabels = [
			    	{label:"Workflows Started"},
		            {label:"Workflows Finished"},
		            {label:"Average Workflows Pending"}
		        ];

			} else if (val === "5days") {
			    var d0 = new Date(today - 86400000);
			    var d1 = new Date(d0 - 86400000);
			    var d2 = new Date(d1 - 86400000);
			    var d3 = new Date(d2 - 86400000);

			    ticks = [d3.toDateString(), d2.toDateString(), d1.toDateString(), d0.toDateString(), 
			    	today.toDateString()];

			    seriesLabels = [
			    	{label:"Workflows Started"},
		            {label:"Workflows Finished"},
		            {label:"Workflows Pending"}
		        ];
			}

			var graphSettings = {
		        // The "seriesDefaults" option is an options object that will
		        // be applied to all series in the chart.
		        seriesDefaults: {
		            renderer:$.jqplot.BarRenderer,
		            rendererOptions: {fillToZero: true},
		            pointLabels: {
		            	show:true, 
		            	edgeTolerance:-10,
		            	hideZeros: true,
		            	ypadding: 0
		            }
		        },
		        // Custom labels for the series are specified with the "label"
		        // option on the series option.
		        series: seriesLabels,
		        // Show the legend and put it outside the grid, but inside the
		        // plot container, shrinking the grid to accomodate the legend.
		        legend: {
		            show: true,
		            placement: "outsideGrid",
		            showSwatches: true
		        },
		        axes: {
		            // Use a category axis on the x axis and use our custom ticks.
		            xaxis: {
		                renderer: $.jqplot.CategoryAxisRenderer,
		                ticks: ticks
		            },
		            // Pad the y axis just a little so bars can get close to, but
		            // not touch, the grid boundaries.  1.2 is the default padding.
		            yaxis: {
		                pad: 1.05,
		                min: 0
		            }
		        }
		    };
			return graphSettings;
		},
		afterRender: function() {
			//TODO figure out a better way to check if the graph is there or not
			
			if(!$.trim( $("#wfHistoryGraphDiv").html() ).length) {
			  	this.plot1 = $.jqplot("wfHistoryGraphDiv", this.getSeries("5days"),this.getGraphSettings("5days"));
			}
		}
	});

	/* G R O U P  T A S K S  V I E W */
	WorkflowReportingDashlet.GroupTasksView = Backbone.Layout.extend({
		template: "dashboard/workflowreportingdashlet/grouptasks",
		events: {
			"change #user-groups-dropdown" : "groupNameSelected",
			"click #group-tasks-refresh" : "fetchSnapshotsByGroup",
			// when the user clicks the link column of the result, we want to direct them to the stage
            "click .grouptasks-result-link": "onResultClick"
		},
		initialize: function(options) {
			var self = this;
			self.picklistDeleted = false;
			self.noGroupsAvailable = false;
			self.attrToShow = options.attrToShow;
			
			if(self.selectedPicklist){
				self.selectedPicklistConfig = app.context.currentPicklistConfig().get("picklists").findWhere({label: self.selectedPicklist});
				//if the selectedpicklist options are empty, the picklist has been deleted
				if(!self.selectedPicklistConfig){
					self.picklistDeleted = true;
					self.noGroupsAvailable = true;
					self.selectedPicklist = "";
				}
				else{
					self.selectedPicklist = options.selectedPicklist;
				}
			}

			if(!self.picklistDeleted){
				app.user.getGroups().done(function(){
					self.userGroups = this.get("groups");

					var picklistDeferred = $.Deferred();
					if (self.selectedPicklist){
						picklistDeferred = app.context.picklistService.getPicklist(self.selectedPicklist, function(picklistOptions) {
							//whatevers the first collection (after filter) is going to be the object that's returned.
							self.filteredGroups = _.filter(picklistOptions,function(option){
								return _.some(self.userGroups,function(group){
									return (option.value === group.authorityId);
								});
							});
						});
					} else {
						picklistDeferred.resolve();
					}

					$.when(picklistDeferred).done(function() {
						if ((_.isEmpty(self.filteredGroups) && self.selectedPicklist) || (_.isEmpty(self.userGroups) && !self.selectedPicklist)){
							self.noGroupsAvailable = true;
						} else if (!_.isEmpty(self.filteredGroups)) {
							self.noGroupsAvailable = false;
							// default to first group in list
							self.selectedGroupName = self.filteredGroups[0].value;
							self.getSnapshots(self.selectedGroupName);
						} else {
							self.noGroupsAvailable = false;
							// default to first group in list
							self.selectedGroupName = self.userGroups[0].authorityId;
							self.getSnapshots(self.selectedGroupName);
						}

						self.render();
					});
				});
			}
			
		},
		fetchSnapshotsByGroup: function() {
			var self = this;
			self.workflowInstanceSnapshotsByGroup.fetch({
				success: function() {
					self.error = false;
					self.snapshots = self.getJSONObjectArray();

					// render again if already rendered
					if (self.hasRendered) {
						self.render();
					}
				},
				error: function() {
					self.error = true;
					
					if (self.hasRendered) {
						self.render();
					}
				}
			});
		},
		getJSONObjectArray: function(){
			var self = this;
			return self.workflowInstanceSnapshotsByGroup.toJSONObjectArray();
		},
		groupNameSelected: function(event) {
			var self = this;
			self.selectedGroupName = event.currentTarget.value;
			$("#user-groups-dropdown").val(this.selectedGroupName);
			self.getSnapshots(this.selectedGroupName);
		},
		getSnapshots: function(groupName) {
			var self = this;
			// do not fetch if previously fetched
			if (self.workflowInstanceSnapshotsByGroup) {
				if (self.workflowInstanceSnapshotsByGroup.groupName === groupName) {
					return;
				}
			}

			self.workflowInstanceSnapshotsByGroup = new Workflow.WorkflowInstanceSnapshotCollection([], {"groupName" : groupName, "attrToShow": self.attrToShow});
			self.fetchSnapshotsByGroup();
		},
		// called when a user clicks the link column 
        onResultClick: function(event) {
            var objectId = event.target.name;

            app.routers.main.stageSimple(objectId);

        },
		afterRender: function() {
			this.hasRendered = true;
			if (!this.noGroupsAvailable){
				if (this.selectedGroupName) {
					this.$("#user-groups-dropdown").val(this.selectedGroupName);
				}
			}
		},
		serialize: function() {
			return {
				"filteredGroups": this.filteredGroups,
				"userGroups": this.userGroups,
				"selectedGroupName": this.selectedGroupName,
				"workflowInstancesByGroup" : this.snapshots,
				"error" : this.error,
				"noGroupsAvailable" : this.noGroupsAvailable,
				"picklistDeleted" : this.picklistDeleted
			};
		}
	});

	return WorkflowReportingDashlet;
});