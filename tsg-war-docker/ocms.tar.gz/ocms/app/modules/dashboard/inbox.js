define([
	"app",
	"module",
	"modules/common/workflow"
],
function(app, module, Workflow) {

	/**
	 * The workflow definition name of your notification workflow. This is used if you want to
	 * filter our notifications from the inbox tasks listed for the user. The default functionality
	 * is to filter out all notifications from the default HPI notification workflow template. NOTE:
	 * we're specifically checing for undefined below so that a client can override this to show all
	 * notifications by specifying their config "notificationWorkflowDefitionName" to be an empty string
	 * or null.
	 */
	var notificationWorkflowDefitionName = module.config().notificationWorkflowDefitionName !== undefined ? module.config().notificationWorkflowDefitionName : "hpiNotificationWorkflow";

	// create a new module for our inbox
	var Inbox = app.module();

	// the view model for our inbox tasks
	Inbox.ViewModel = function(model, options) {
		var self = this;

		self.model = model;

		self.packageItems = kb.collectionObservable(self.model, { view_model: Workflow.PackageItemViewModel });

		self.userTasks = kb.collectionObservable(options.userTasks, { view_model: Workflow.TaskViewModel });
		self.unclaimedTaskGroups = kb.collectionObservable(options.unclaimedTaskGroups, { view_model: Workflow.UnclaimedTaskGroupViewModel });
		self.indexerUrl = function() {
			return "indexer/" + app.context.configName() + "/";
		};
		self.stageUrl = function(id) {
			app.routers.main.stageSimple(id);
		};

		//TODO: move hardcoded out to app.js or a config
		self.startIndexTaskName = "cmhrinwf:startIndexingTask";
		self.indexTaskName = "cmhrinwf:indexingTask";
	};

	// the Backbone view for displaying our inbox tasks to the user
	Inbox.Views.Layout = Backbone.Layout.extend({
		template: "dashboard/inbox",
		className : "dashlet",
		initialize: function() {
			var self = this;
			this.config = this.options.config;

			this.name = "inbox";

			this.enableDraggability = this.options.enableDraggability;
			this.attrToShow = this.config.get("attrToShow");

			// these are for the user's tasks and tasks that the user can claim 
			this._userTasks = new Workflow.UserTaskCollection([], {attrToShow : this.attrToShow});
			this._unclaimedTaskGroups = new Workflow.UnclaimedTaskGroupCollection([], {attrToShow : this.attrToShow});

			// fetch our collections for the first time
			this.fetchCollections();

			this.viewModel = new Inbox.ViewModel(null, { 
				userTasks: this._userTasks, 
				unclaimedTaskGroups: this._unclaimedTaskGroups 
			});

			this.viewModel.inboxClaimTask = function(task) {
				task.claimTask(function() {
					self.fetchCollections();
				});
			};
			this.viewModel.inboxUnclaimTask = function(task) {
				task.unclaimTask(function() {
					self.fetchCollections();
				});
			};
			this.viewModel.beginIndexing = function(task) {
				task.completeTask(null, function() {
					//Task completed, refresh view.
					self.fetchCollections();
				});
			};
			this.viewModel.cancelTask = function(task) {
				task.cancelTask(function() {
					self.fetchCollections();
				});

			};
			this.viewModel.refreshInbox = function() {
				self.fetchCollections();
			};
		},

		/**
		 * Fetches the inbox collections.
		 */
		fetchCollections: function() {
			var self = this;

			self.activeTabId = null;

			// animate our refresh icon for our inbox
			this.$(".inbox-refresh-icon").addClass("icon-refresh-animate");

			// Get the currently active tab before fetching.
			if(self.$('.dashlet .nav-tabs li.active')[0]) {
				self.activeTabId = $('.dashlet .nav-tabs li.active')[0].id;
			}

			// fetch the tasks for our user
			this._userTasks.fetch({ global: false }).done(function() {
				// check if the user specified a workflow definition name for notifications - if so, we want
				// to filter out all tasks that are notifications from the inbox
				if(notificationWorkflowDefitionName) {
					// filter out all tasks that are not notifications for our user
					var userTasksWithoutNotifications = self._userTasks.filter(function(userTask) {
						return userTask.get("workflowDefinitionName") !== notificationWorkflowDefitionName;
					});

					// reset our collection with just the tasks that aren't notifications for our user
					self._userTasks.reset(userTasksWithoutNotifications);	
				}
			});

			// fetch all the unclaimed tasks that this user could claim
			this._unclaimedTaskGroups.fetch({ global: false }).done(function() {
				//Make the previously active tab active again after the fetch refreshes the view.
				//Highlight the first inbox tab if none are active.
				if (!self.activeTabId || $('#' + self.activeTabId).length === 0) {
					$('#tabMyTasksSimple').addClass('active');
					$($('#tabMyTasksSimple a').attr('data-target')).addClass('active');
				} else {
					//Maintain the active tab.
					$('#' + self.activeTabId).addClass('active');
					var paneId = $('#' + self.activeTabId).children('a').attr('data-target');
					$(paneId).addClass('active');
				}

				self.$(".inbox-refresh-icon").removeClass("icon-refresh-animate");
			});
		},

		afterRender: function() {
			var self = this;

			// Get the currently active tab before fetching.
			if(this.$('.nav-tabs li.active')[0]) {
				self.activeTabId = $('.nav-tabs li.active')[0].id;
			}

			if(this.enableDraggability){
				this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
			}

			//Add listener to refresh inbox.
			self.listenTo(app, "dashboard:refreshInbox", function() {
				self.fetchCollections();
			});

			//Load comment popovers
			$(".has-comment").popover( { trigger: "hover", title: "Description:" } );

			self.viewModel.userTasks.subscribe(function() { 
				self.$("#tabMyTasksSimple").find(".badge").fadeOut(500).fadeIn(500).fadeOut(500).fadeIn(500);
			});
			
			kb.applyBindings(self.viewModel, this.$el[0]);
		},
		serialize: function() {
			return {
				"dashletName": this.config.get("dashletName")
			};
		}

	});

	return Inbox;
});