define([
	"app"
],

function(app) {
	"use strict";

	var IFrameDashlet = app.module();

	IFrameDashlet.Views.Layout = Backbone.Layout.extend({
		template: "dashboard/iframedashlet",
		className: "dashlet",
		initialize: function() {
			this.config = this.options.config;
			this.enableDraggability = this.options.enableDraggability;
		},
		afterRender: function() {
			if (this.enableDraggability) {
				this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
			}
		},
		serialize: function() {
			return {
				"dashletName": this.config.get("dashletName"),
				"iframeSrc": this.config.get("iframeSrc"),
				"iframeHeight": this.config.get("iframeHeight")
			};
		}
	});

	return IFrameDashlet;
});