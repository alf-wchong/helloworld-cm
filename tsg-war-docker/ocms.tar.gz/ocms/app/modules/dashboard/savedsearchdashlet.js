define([
        "app",
        "modules/common/ocquery",
        "modules/common/spinner",
        "handlebars",
        "modules/common/action",
        "modules/hpiadmin/dashboardconfig/dashlets/savedsearchdashletactionconfig"
    ],
    function(app, Query, HPISpinner, Handlebars, Action, SavedSearchDashletActionConfig) {

        var SavedSearchDashlet = app.module();

        // this is the view for an individual result in our saved search results table
        SavedSearchDashlet.Views.ResultView = Backbone.Layout.extend({
            // each result is a table row
            tagName: "tr",

            template: "dashboard/savedsearchdashlet/resultview",

            events: {
                // when the user clicks the link column of the result, we want to direct them to the stage
                "click .savedsearch-result-link": "onResultClick",
                // Action Menu Click
                "click .savedsearch-actionMenu": "onActionMenuClick",
            },

            initialize: function(options) {
                var self = this;

                // store our config so we can display the proper attributes in the table to the user
                this.config = options.config;
                
                // make saved search dashletActionConfig a model
                if (!(this.config.get("dashletActionConfig") instanceof Backbone.Model)) {
                    this.config.set(
                        "dashletActionConfig",
                        new SavedSearchDashletActionConfig.Model(this.config.get("dashletActionConfig"))
                    );
                }

                // this is the model for this result
                this.queryResult = options.queryResult;

                // helper function for setting attributes and re-rendering if a model changes
                var _updateAttrs = function(model) {
                    // we're going to build an array of attributes to display to the user
                    self.attributes = [];

                    // loop over each of the configured attributes to display and get the value for this attribute on the model
                    _.each(self.config.get("selectedAttributes"), function(column) {
                        var attribute = {};

                        if (column instanceof Object) {
                            //check to see if the column is a repeating attribute or not
                            if (_.isArray(model.get("properties")[column.ocName])) {
                                //if the column is a repeating attr, set the value to the 
                                //last (most recent) item on the array
                                self.value = _.last(model.get("properties")[column.ocName]);
                            } else {
                                self.value = model.get("properties")[column.ocName];
                            }
                            attribute = {
                                // this is the link column if this current column is the one configured
                                isLink: self.config.get("isLink") === column.label,
                                name: column.label,
                                value: self.value,
                                cid: self.cid,
                                enableActionMenu: self.config.get("dashletActionConfig").get("actions").length > 0,
                                // objectName: model.get("properties").objectName.replace(/\s+/g, ''),
                            };
                        } else {
                            attribute = {
                                // this is the link column if this current column is the one configured
                                isLink: self.config.get("isLink") === column,
                                name: column,
                                value: model.get("properties")[column],
                                cid: self.cid,
                                enableActionMenu:  self.config.get("dashletActionConfig").get("actions").length > 0,
                                // objectName: model.get("properties").objectName.replace(/\s+/g, ''),
                            };
                        }
                        // add this attribute to the list of attributes to display
                        self.attributes.push(attribute);
                    });

                    // done getting all our values for the attributes to display, so render our view
                    self.render();
                };

                // format the values into human-friendly strings             
                self.queryResult.formatPropertiesReadOnly(options.objectTypeConfig);
                // we want to listen to any changes on the model's properties and rebuild the attributes we're displaying
                // if any do change
                self.queryResult.listenTo(self.queryResult, 'change:properties', _updateAttrs);

                // call our helper method to build our array of attributes for this result
                _updateAttrs(self.queryResult);
            },

            // called when a user clicks the link column of this result view
            onResultClick: function() {
                var self = this;

                // helper function to build the proper URL and navigate to the stage - takes the trac to navigate to as a parameter
                // and whether or not this object is a container
                var navigateToStage = function(tracToNavigateTo, isContainer) {
                    // get the objectId for the model they clicked on
                    var objectId = self.queryResult.get("properties").objectId;

                    // start our url with the stage and the trac to navigate to
                    var url;
                    if (tracToNavigateTo) {
                        url = "Stage/" + tracToNavigateTo + "/";

                        // add our proper objectId onto our URL depending on the type or if this is a container or not
                        if (isContainer === "wizard") {
                            url += objectId + "|" + objectId;
                        } else if (isContainer === "true") {
                            url += objectId;
                        } else {
                            // containterID will be resolved by the stage
                            url += "|" + objectId;
                        }
                        // navigate to the built URL and trigger our routing
                        Backbone.history.navigate(url, { trigger: true });
                    } else {
                        app.routers.main.stageSimple(objectId);
                    }
                };

                if (self.config.get('linkedIndexerConfig')) {
                    // get the objectId for the model they clicked on
                    var objectId = self.queryResult.get("properties").objectId;

                    var url = 'indexer/' + self.config.get('linkedIndexerConfig') + '/' + self.config.get("dashletId") + '/queued/' + encodeURIComponent(objectId) + '/index';
                    Backbone.history.navigate(url, { trigger: true });
                } else {
                    // if the user has a trac to go to configured, use that trac and get the OTC from that trac
                    if (self.config.get("tracResolver")) {
                        app.context.configService.getAdminOTC(function(otc) {
                            // get the configuration for the type of this result
                            var currentType = otc.get("configs").findWhere({ ocName: self.config.get("type") });

                            // navigate to the stage
                            navigateToStage(self.config.get("tracResolver"), currentType.get("isContainer"));
                        });
                    } else {
                        // assume that the current trac has the type you click
                        app.context.configService.getAdminTypeConfig(self.config.get("type"), function(configModel) {
                            // navigate to the stage
                            navigateToStage("", configModel.get("isContainer"));
                        });
                    }
                }
            },

            // ActionMenu Click
            onActionMenuClick: function() {
                var self = this;
                self.actions = [];

                if (self.actionMenuView) {
                    self.actionMenuView.remove();
                }

                _.each(self.config.get("dashletActionConfig").get("actions").models, function(configuredAction) {
                    self.actions.push(new Action.Model(configuredAction.attributes));
                });

                self.actionMenuView = new SavedSearchDashlet.Views.ActionMenu({
                    "config": self.config.get("dashletActionConfig"),
                    "folder": self.queryResult,
                    "actions": self.actions
                });

                self.setView(
                    "#actionButton-" + self.cid,
                    self.actionMenuView,
                    true
                ).render();
            },

            serialize: function() {
                return {
                    // the attributes are the attribute values to display to the user in our table
                    attributes: this.attributes
                };
            }
        });

        SavedSearchDashlet.Views.ResultsHeader = Backbone.Layout.extend({

            tagName: "tr",

            template: "dashboard/savedsearchdashlet/results-header",

            initialize: function(options) {
                // store our configuration object
                this.config = options.config;

                this.headers = [];
                var self = this;

                _.each(this.config.get("selectedAttributes"), function(column) {
                    // the label service calls here can come back in any order, thus we need to push a
                    // placeholder on the header array and then splice in the response from the label service
                    self.headers.push("Fetching...");
                    // put our column label in the proper place in our headers array
                    app.context.configService.getLabels(self.config.get("type"), column).done(function(label) {
                        //if our label is an object with ocName and Label
                        if (label instanceof Object) {
                            label = window.localize(label.label);
                            self.headers.splice(_.pluck(self.config.get("selectedAttributes"), 'ocName').indexOf(column.ocName), 1, label);
                            self.render();
                        } //if our label is just a string to handle old configs 
                        else {
                            label = window.localize(label);
                            self.headers.splice(self.config.get("selectedAttributes").indexOf(column), 1, label);
                            self.render();
                        }
                    });
                });
            },

            serialize: function() {
                var enableSorting = this.options.config.get("enableSorting");
                return {
                    enableSorting: enableSorting,
                    // the headers for our results table
                    headers: this.headers
                };
            }
        });

        // this is the view for the results table - it houses the results collection and builds a result view for each
        // model in the collection
        SavedSearchDashlet.Views.Results = Backbone.Layout.extend({

            template: "dashboard/savedsearchdashlet/results",

            events:{
                "click .savedSearch-resultView-sortColumn" : "sortColumn"
            },

            initialize: function(options) {
                // store our configuration object
                var self = this;
                self.config = options.config;

                self.eventsObj = options.eventsObj;

                // when we initiliaze this view, we are loading the query so let's set this to true so we can display
                // a loading spinner to the user
                self.loadingQuery = true;

                app.context.configService.getAdminTypeConfig(self.config.get("type"), function(objectTypeConfig) {
                    self.otc = objectTypeConfig;
                    self.setView(".savedsearch-query-results-header", new SavedSearchDashlet.Views.ResultsHeader({
                        config: self.config,
                        objectTypeConfig: self.otc
                    }));
                    if (self.loadingQuery && self.collection) {
                        // we're no longer loading our query so set this to false
                        self.loadingQuery = false;

                        // destroy the loading spinner since we're done loading the query
                        HPISpinner.destroySpinner(self.spinner);

                        self.render();
                    }
                });
                // listen for the results to be updated so we can update our collection and re-render
                self.listenTo(self.eventsObj, "savedsearchdashlet:updateresults", function(queryResults) {
                    if (!self.loadingQuery && self.collection) {
                        //Render because self.loadQuery is false and when you click the next or back button we still need to 
                        //render the view
                        self.render();
                    }
                    // set our collection to be the new, updated collection
                    self.collection = queryResults;
                    self.setView(".savedsearch-query-results-header", new SavedSearchDashlet.Views.ResultsHeader({
                        config: self.config,
                        objectTypeConfig: self.otc
                    }));

                    // we have no results to display if the full collection has 0 results - so we'll display
                    // a message to the user that there are no results
                    self.noSavedSearchResults = self.collection.models.length === 0;

                    // this get's called multiple times, so let's only deal with our spinner the first time
                    //if view is created then run this code 
                    if (self.loadingQuery && self.otc) {

                        // we're no longer loading our query so set this to false
                        self.loadingQuery = false;

                        // destroy the loading spinner since we're done loading the query
                        HPISpinner.destroySpinner(self.spinner);

                        // re-render our view, which causes our subviews to be built in the before render
                        self.render();
                    }
                }, self);
                if(self.sortAsc == undefined){
                    self.sortAsc = true;
                }
            },

            beforeRender: function() {
                this.removeView(".savedsearch-query-results");
                // we won't have a collection until the query comes back with results, so we have nothing to build up
                // until that query comes back
                if (this.collection) {
                    // loop over our collection and insert a new view for each result
                    this.collection.each(function(queryResult) {
                        this.insertView(".savedsearch-query-results", new SavedSearchDashlet.Views.ResultView({
                            config: this.config,
                            queryResult: queryResult,
                            objectTypeConfig: this.otc
                        }));
                    }, this);
                }
            },

            sortColumn: function(e) {
                var self = this;
                var index = $(e.currentTarget).data("id");
                var columnAttribute = self.config.get("selectedAttributes")[index];
                var columnAttrOcName = columnAttribute.ocName;
                
                // array of batches (collections) that will need to be sorted based off of the 
                // column attribute
                self.batchCollections = self.collection.fullCollection.models;
                self.batchState = self.collection.fullCollection.pageableCollection.state;
    
                self.filteredResults = _.sortBy(self.batchCollections, function(batch){
                    var batchProps = batch.get("properties");
                    //sortBy can't take null objects, this will return -1 for sorting purposes
                    if(batchProps[columnAttrOcName] === ""){
                        return -1;
                    }
                    if(columnAttrOcName.toLowerCase().includes("date")){
                        var structDate = new Date( batchProps[columnAttrOcName]);
                        var isoDate = structDate.toISOString();
                        return isoDate;        
                    }
                    return batchProps[columnAttrOcName];
                });
    
                if (self.sortAsc){
                    self.sortAsc = false;
                }else{
                    self.filteredResults.reverse();
                    self.sortAsc = true;
                }

                self.collection.fullCollection.models = self.filteredResults;
                
                self.eventsObj.trigger("savedsearchdashlet:updateresults", self.collection);
            },

            afterRender: function() {
                // if we're loading our query and we haven't already displayed a spinner, let's display a loading spinner to the user
                if (this.loadingQuery && this.$(".savedsearch-loading-spinner").children().length === 0) {
                    // find our DOM element to attach our loading spinner to
                    var spinElem = this.$(".savedsearch-loading-spinner")[0];

                    // create our loading spinner, make it a bit bigger than normal
                    this.spinner = HPISpinner.createSpinner({
                        lines: 13,
                        length: 5,
                        width: 3,
                        radius: 8
                    }, spinElem);
                }
            },

            serialize: function() {
                return {
                    // whether or not we're still loading the query - used to display a loading spinner to the user
                    loadingQuery: this.loadingQuery,
                    // whether or not we need to display a message to the user that there are no saved search results
                    noSavedSearchResults: this.noSavedSearchResults
                };
            }
        });

        // this is the view for the controls of the results
        SavedSearchDashlet.Views.ResultControls = Backbone.Layout.extend({

            template: "dashboard/savedsearchdashlet/resultcontrols",

            events: {
                // when a user clicks the previous button
                "click .savedsearch-prev": "previousPage",
                // when a user clicks the next button
                "click .savedsearch-next": "nextPage",
                // when a user chooses a specific page to jump to
                "change .savedsearch-page-select": "jumpToPage",
                // when a user chooses a different page size to display
                "change .savedsearch-num-results-per-page": "changePageSize",
                // when a user types into the filter box to filter the results
                "keyup .savedsearch-filter-results": "filterResults"
            },

            initialize: function(options) {
                var self = this;

                // Whether we will display Pagination controls
                this.paginationControls = false;

                // store our configuration for this view
                this.config = options.config;

                this.eventsObj = options.eventsObj;

                // set up our different page size options the user can choose from
                this.pageSizeOptions = [10, 25, 50, 100, 500];

                //Defaulting to 10
                this.currentPageSize = 10;

                // set our empty filter text
                this.filterText = "";

                // helper to select the current page that the user is viewing
                Handlebars.registerHelper("isPageSelected", function(currentPage, page) {
                    if (currentPage === page) {
                        return "selected";
                    }
                });

                // helper to select the current page size the user is using
                Handlebars.registerHelper("isPageSizeSelected", function(currentPageSize, pageSize) {
                    // we might not have our collection if the query hasn't finished running
                    if (self.collection && self.collection.state) {
                        if (currentPageSize === pageSize) {
                            return "selected";
                        }
                    }
                });

                // listen to the results being updated
                this.listenTo(this.eventsObj, "savedsearchdashlet:updateresults", function(queryResults) {
                    // set our collection to the new results
                    this.collection = queryResults;

                    // update our buttons - we pass false so we don't trigger another updateresults event
                    // this function is being called since the query is done fetching initially - not from user interaction
                    this._updateButtonsAndResults(this.collection.state.currentPage, false);
                }, this);
            },

            // method to go to the previous page of results
            previousPage: function() {
                // get the previous page of results for our collection
                this.collection.getPreviousPage();

                // let's update our buttons and trigger an event to update the results table as well
                this._updateButtonsAndResults(this.collection.state.currentPage, true);
            },

            // method to go to the next page of results
            nextPage: function() {
                // get the next page of results for our collection
                this.collection.getNextPage();

                // let's update our buttons and trigger an event to update the results table as well
                this._updateButtonsAndResults(this.collection.state.currentPage, true);
            },

            // method to update the button controls because of user interaction - takes an updateResults parameter
            // to specify if the updateresults event should be triggered
            _updateButtonsAndResults: function(newPage, updateResults) {
                // our current page is the new page
                this.currentPage = newPage;

                // check whether we have a previous page the user can go to
                this.hasPrevious = this.collection.hasPreviousPage();

                // check whether we have a next page the user can go to
                this.hasNext = this.collection.hasNextPage();

                // reset our array of pages that the user can jump to
                this.pages = [];
                for (var i = 1; i <= this.collection.state.totalPages; i++) {
                    this.pages.push({
                        page: i,
                        label: i + " " + window.localize("stage.outOf") + " " + this.collection.state.totalPages
                    });
                }

                if (this.pages && this.pages.length !== 0) {
                    this.paginationControls = true;
                }

                // if the calling function needs to trigger the results to be updated, let's trigger that event
                if (updateResults) {
                    this.eventsObj.trigger("savedsearchdashlet:updateresults", this.collection);
                }

                //Backbone Pagination doesn't get this correct.  I'd rather do this than
                //change 3rd party library.
                if (this.pages && this.currentPage < this.pages.length) {
                    this.hasNext = true;
                }

                // render our view so the buttons can be updated (and the select dropdowns)
                this.render();
            },

            // method to jump to a specific page instead of just going to the next or previous one
            jumpToPage: function(event) {
                // parse the value of the option that the user chose
                var newPage = parseInt($(event.target).find("option:selected").val(), 10);

                // if we have at least one model
                if (this.collection.models.length > 0) {
                    // let's get the page the user selected to go to
                    this.collection.getPage(newPage);

                    // let's update our buttons and trigger an event to update the results table as well
                    this._updateButtonsAndResults(newPage, true);
                }
            },

            // method to change the page size based on what the user selected from the available drop down options
            changePageSize: function(event) {
                // get the page size option the user selected to change the page size to
                this.currentPageSize = parseInt($(event.target).find("option:selected").val(), 10);

                // if the page size the user selected is not the current page size, let's update our page size
                if (this.currentPageSize !== this.collection.state.pageSize) {
                    app.log.debug("Page Size changed to: " + this.currentPageSize);

                    // set our page size to the page size the user requested
                    this.collection.setPageSize(this.currentPageSize);

                    // let's go back to the first page of results when the page size is changed
                    this.collection.getPage(1);

                    // let's update our buttons and trigger an event to update the results table as well
                    this._updateButtonsAndResults(this.collection.state.currentPage, true);
                }
            },

            // method to filter the results based on what a user types in - we want to only run this function
            // after 400 milliseconds have passed since the user last typed a key
            _filterResults: function(event) {
                var self = this;

                // get the value of what the user typed in and make it lower case
                this.filterText = $(event.target).val();
                var filterQuery = this.filterText.toLowerCase();


                var filteredResults;

                // if we don't have any filter text and we do have an unfiltered collection, let's set the results
                // back to the unfiltered collection - will happen if a user types something and then deletes everything typed
                if (!filterQuery && this.unfilteredCollection) {
                    filteredResults = this.unfilteredCollection;
                    //check to see if the collection is a "no results" query, passing a blank array 
                    //so that noSavedSearchResults will be true.
                    if (this.collection.length === 1 && this.collection.fullCollection.models["0"].attributes.searchParameters) {
                        filteredResults = [];
                    }
                } else { // we have at least some text to filter on
                    // if we don't yet have an unfiltered collection, let's save that
                    if (!this.unfilteredCollection) {
                        this.unfilteredCollection = self.collection.fullCollection.models.slice(0);
                    }

                    // filter our collection based on what the user typed
                    filteredResults = _.filter(this.unfilteredCollection, function(model) {
                        // this model hasn't yet passed the filter test
                        var found = false;

                        // loop over our selected attributes, see if the model has a value for that attribute and if the value
                        // passes the filter test
                        for (var i = 0; i < self.config.get("selectedAttributes").length; i++) {
                            // get our attribute that we're currently looking at
                            var attr = self.config.get("selectedAttributes")[i];

                            // get the value of this attribute for the current model
                            // if this is an object, we're using the new configs so get ocName off of attr, otherwise can just grab attr
                            var modelAttrVal;
                            if (attr instanceof Object) {
                                modelAttrVal = model.get("properties")[attr.ocName];
                            } else {
                                modelAttrVal = model.get("properties")[attr];
                            }

                            // make sure this model has a value for it and if so if its string value contains the filter text
                            // the user has typed in so far
                            if (modelAttrVal && modelAttrVal.toString().toLowerCase().indexOf(filterQuery) !== -1) {
                                found = true;

                                // don't need to keep checking attributes since we found at least one that has the filter text
                                break;
                            }
                        }

                        return found;
                    });
                }

                // now that we've got our filtered results, let's reset our collection to be these filtered results
                // NOTE: we need to grab the first page before we reset the full collection otherwise if we try filtering
                // from a page other than the first, it won't work
                this.collection.reset(filteredResults);

                // update our buttons and trigger the event that the results have been updated
                this._updateButtonsAndResults(this.collection.state.currentPage, true);
            },
            filterResults: _.debounce(function(event) {
                this._filterResults(event);
            }, 400),

            afterRender: function() {
                // once we're done rendering, if we have some filter text, we want to put it back in to the filter box
                // input and focus on that box and we need to put the cursor at the end so the user can keep typing - the
                // following is a simple way to do so that works cross browser (without using a bigger library)
                if (this.filterText) {
                    // find our filter input box on the page and focus on it
                    var filterInputBox = this.$(".savedsearch-filter-results");
                    filterInputBox.focus().val("").blur().focus().val(this.filterText);
                }

                if (this.collection) {
                    this.collection.setPageSize(this.currentPageSize);
                }

            },

            serialize: function() {
                return {
                    // whether or not we want to show our pagination controls (whether we have results)
                    paginationControls: this.paginationControls,
                    // these are the pages the user can choose to jump to
                    pages: this.pages,
                    // this is whether or not we should enable or disable the previous button
                    hasPrevious: this.hasPrevious,
                    // this is whether or not we should enable or disable the next button
                    hasNext: this.hasNext,
                    // this is the list of options the user can choose to change the page size to
                    pageSizeOptions: this.pageSizeOptions,
                    // this is the page of the results that we are currently viewing
                    currentPage: this.currentPage,
                    // this is the number of results on the page that we have currently selected
                    currentPageSize: this.currentPageSize
                };
            }
        });

        // this is our main view for the saved search dashlet
        SavedSearchDashlet.Views.Layout = Backbone.Layout.extend({

            template: "dashboard/savedsearchdashlet/savedsearchdashlet",

            // give our dashlet a class so we can style it
            className: "dashlet",

            events: {
                "click #refreshSavedSearch": "refreshResults"
            },

            initialize: function() {
                var self = this;

                // store our configuration
                this.config = this.options.config;

                // store whether or not we should enable this dashlet to be dragged
                this.enableDraggability = this.options.enableDraggability;

                this.eventsObj = _.extend({}, Backbone.Events);

                this.resultControls = new SavedSearchDashlet.Views.ResultControls({
                    config: this.config,
                    eventsObj: this.eventsObj
                });

                this.results = new SavedSearchDashlet.Views.Results({
                    config: this.config,
                    eventsObj: this.eventsObj
                });

                this.refreshResults();
            },
            buildQuery: function() {
                var self = this;

                    // build our query collection - this is a backbone pageable collection
                self.query = new Query.Collection([], {
                        // set our mode
                    mode: self.mode,
                        state: {
                            // default to a pagesize of 10 to start
                            pageSize: 10,
                            // default sorting to modified date
                            sortKey: (self.config.get("sortAttribute") ? self.config.get("sortAttribute") : "modifiedDate"),
                            // the order to use for sorting, -1 for asc, 1 for desc, 0 means no client side sorting is done
                            order: (self.config.get("sortOrder") ? self.config.get("sortOrder") : -1)
                        }
                    });

                // this ensures that when the collection is reset that it maintains its' sorted order
                self.query.fullCollection.comparator = undefined;

                // build up our search parameters based on the criteria in the configuration
                self.query.searchParameters = [];
                _.each(self.config.get("criteria"), function(item) {
                    var value;
                    if (item.isProximityOperator) {
                        value = self.buildProximitySearchValue(item.operator, item.proximityNumber, item.proximityTimeSpan);
                    } else {
                        value = self._tokenResolve(item.value);
                    }
                    var sp = {
                        // the attribute we're searching on
                        paramName: item.attribute,
                        // the value of the attribute we're searching on
                        paramValue: value,
                        // this is a property we're searching on
                        paramType: "property",
                        operator: item.operator
                    };
                    self.query.searchParameters.push(sp);
                });

                // add another search parameter for the type the user configured in the admin
                var sp = {
                    paramName: self.config.get("type"),
                    paramValue: self.config.get("type"),
                    paramType: "type"
                };
                self.query.searchParameters.push(sp);

            },
            refreshResults: function() {
                var self = this;

                // get the mode that we're doing our paging in - server means we'll reach out to the server for new
                // results, client means we'll get all the results at once and move through them client-side
                self.mode = self.config.get("enablePaging") ? "server" : "client";

                self.buildQuery();

                // execute our query
                self.query.fetch({
                    success: function(queryResults) {
                        // once the query has successfully run, let's trigger the event to update our results
                        self.eventsObj.trigger("savedsearchdashlet:updateresults", queryResults);

                    },
                    error: function() {
                        // if an error occured, let's show an error message to the user
                        app.trigger("alert:error", {
                            header: window.localize("modules.dashboard.savedSearchDashlet.errorLoading"),
                            message: window.localize("modules.dashboard.savedSearchDashlet.thereWas")
                        });
                    },
                    // don't want to trigger any global ajaxStart or ajaxStop event handlers
                    global: false
                });
            },

            buildProximitySearchValue: function(proximityType, proximityNumber, proximityTimeSpan) {
                if (!proximityType || !proximityNumber || !proximityTimeSpan) {
                    app.log.warn('Invalid parameters in saved search dashlet for proximity search');
                    return;
                }

                var proximityNumberAsInt = parseInt(proximityNumber, 10);
                var startDate = moment().startOf('day');
                var endDate = moment().startOf('day');

                if (proximityType.toLowerCase() === 'within') {
                    startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
                    endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
                } else if (proximityType.toLowerCase() === 'past') {
                    startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
                } else { // next
                    endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
                }

                var value = startDate.toDate().getTime() + '|' + endDate.toDate().getTime();

                // need to tack on the actual user input parameters that way we will be able to repopulate from a different
                // day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
                var proximityParams = '$*prx*$' + proximityType + '|' + proximityNumber + '|' + proximityTimeSpan;

                return value + proximityParams;
            },

            // we want to resolve a token that a user used in a query criteria - currently only resolves dates
            // and user information
            _tokenResolve: function(value) {
                if (value === '$date') {
                    return new Date();
                } else if (value === "$user.loginName") {
                    return app.user.get("loginName");
                } else if (value === "$user.displayName") {
                    return app.user.get("displayName");
                } else {
                    return value;
                }
            },

            serialize: function() {
                return {
                    // want to pass the dashletName so we can display the name of this SavedSearchDashlet to the user
                    dashletName: this.config.get("dashletName")
                };
            },

            beforeRender: function() {
                // set our view for the result controls
                this.setView(".savedsearch-result-controls", this.resultControls);

                // set our view for the results table
                this.setView(".savedsearch-results", this.results);
            },

            afterRender: function() {
                // if the user has dashlet drag-and-drop configured, let's find our dashlet header and make sure the mouse
                // changes to indicate to the user that they can drag-and-drop
                if (this.enableDraggability) {
                    this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
                }
            }
        });

        SavedSearchDashlet.Views.ActionMenu = Backbone.View.extend({
            template: "dashboard/savedsearchdashlet/savedsearchdashlet-actionMenu",
            events: {
                "click #actionMenu": "launchAction"
            },
            initialize: function (options) {
                this.rightClickMenuOptions = [];
                this.config = options.config;
                this.displayStreamableOption = options.displayStreamableOption;
                this.targetObjectId = options.folder.id;
                this.selectedActions = options.actions;

                this._buildActionCollection();

                this.actionCollection.fetch({
                    global: false,
                    success: _.bind(this._collectionFetchSuccessCallback, this),
                    error: function () {
                        app.log.error("Failed to get document actions");
                    }
                });
            },

            _buildActionCollection: function(){
                var that = this;
                //create actioncollection
                var _actions = [];
                this.selectedIds = [];
                _.each(this.selectedActions, function (configuredAction) {
                    _actions.push(new Action.Model({
                        actionId: configuredAction.actionId,
                        parameters: {}, label: configuredAction.get("label"),
                        icon: configuredAction.get("icon"),
                        handler: "modal",
                        ocActionId: configuredAction.get("ocActionId") || configuredAction.actionId 
                    }));
                    that.selectedIds.push(that.targetObjectId);
                });

                this.actionCollection = new Action.Collection(_actions, { objectIds: this.selectedIds }); //  these will all be group actions, so no objectId!
            },

            _collectionFetchSuccessCallback: function(data){
                var that = this;

                //Filter out the actions that the user does not have permission to execute
                Action.filterActions(data);
                //For each action, add it to the rightClickMenuOptionsConfigured collection
                //to display in the right click menu
                if (_.size(this.actionCollection.models) !== 0) {

                    that.actionCollection.objectId = that.folder.get("properties").objectId;
                    that.actionCollection.objectName = that.folder.get("properties").objectName;

                    _.each(this.actionCollection.models, function (action) {
                        if (!action.get("actionId")) {
                            action.set("actionId", action.get("ocActionId"));
                        }

                        actionData = that.config.get("actions").findWhere({actionId : action.get("actionId")} );

                        var actionOption = {
                            "id": action.get("actionId"),
                            "name": actionData.get("label")
                        };

                        that.rightClickMenuOptions.push(actionOption);
                    });
                }
                else if (!this.displayStreamableOption) {
                    var actionOption = {
                        "id": 0,
                        "name": "No Actions Available"
                    };
                    this.rightClickMenuOptions.push(actionOption);
                }

                //Call render so the rightClickMenuOptionsConfigured collection is sent to the front end
                //after the actions have been added
                this.render();

            },
            launchAction: function(e) {
                var attrs = $(e.target.attributes.data);
                var objectId = this.actionCollection.objectId;
                var that = this;
                if(attrs.val()==="streamDocument") {
                    //if you click context menu and document is streamable, open content in new window
                    var url = app.serviceUrlRoot + "/content/content?id=" + encodeURIComponent(objectId) + "&contentType[]="+ ["pdf","txt",".*"];
                    window.open(url);
                } else {
                    //Action was selected in the menu, figure out which action and execute it
                    var continueSearch = true;
                    var modelIndex = 0;
                    var restoreStickyHeaders = function() {
                        //restore sticky bar if there
                        $('.slick-header.sticky').css('z-index', 1050);
                    };
                    this._setUpAction = function(){
                        that.actionCollection.at(modelIndex).get("parameters").objectId = objectId;
                        var aConfig = null;
                        if(!that.options.multipleSelected){
                            aConfig = that.options.config.get("actions").findWhere({actionId : that.actionCollection.at(modelIndex).get("actionId")} );
                        }

                        //hide sticky bar if there
                        $('.slick-header.sticky').css('z-index', 10);

                        app["modalActionHandler"].trigger("show", {action: that.actionCollection.at(modelIndex), config: aConfig }); 

                        app.once(["modalActionHandler"], "hide", restoreStickyHeaders);
                    };
                    while(continueSearch === true){
                        if(attrs.val() === "0") {
                            continueSearch = false;
                        }
                        else if(that.actionCollection.at(modelIndex).get("actionId") === attrs.val()){
                            this._setUpAction();
                            continueSearch = false;
                        }
                        modelIndex++;
                    }
                };
                while (continueSearch === true) {
                    if (attrs.val() === "0") {
                        continueSearch = false;
                    } else if (this.actionCollection.at(modelIndex).get("actionId") === attrs.val()) {
                        this._setUpAction(attrs.val(), modelIndex);
                        continueSearch = false;
                    }
                    modelIndex++;
                }
            },
            serialize: function () {
                return {
                    "rightClickMenuOptions": this.rightClickMenuOptions
                };
            }
        });

        return SavedSearchDashlet;
    });