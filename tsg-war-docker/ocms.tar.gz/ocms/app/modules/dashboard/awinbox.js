
//Index Inbox module
define([
	// Application.
	"app",
	"modules/common/awworkflow",
	"handlebars",
	"modules/common/spinner"
],

function(app, AWWorkflow, Handlebars, HPISpinner) {

	// Create a new module.
	var AWInbox = app.module();
	AWInbox.PAGE_SIZE_OPTIONS = [10, 25, 50, 100, 500];

	//Default view model
	AWInbox.ViewModel = function() {
		this.genURL = function(psiId) {
			// assuming wizard is the only trac that we want to view PSIs on
			return "Stage/wizard/" + psiId + "%2BCURRENT%7C" + psiId + "%2BCURRENT";
		};
	};

	//View for the Inbox Tabs
	AWInbox.Views.Layout = Backbone.Layout.extend({
		template: "dashboard/awinbox",
		className : "dashlet",
		events: {
			"click .awInboxTab": "switchActiveCollection",
			"click .awinbox-resultView-sortColumn": "sortColumn",
			"click .showWorkflowDocsLink": "getWorkflowDocObjectIds",
			"click .aw-dashlet-refresh": "refreshResults"
		},
		initialize: function() {
			var self = this;

			this.config = this.options.config;
			this.enableSorting = true;
			this.inboxName = this.config.get("dashletName");
			this.showUserTasks = this.config.get("showUserTasks");
			this.showGroupTasks = this.config.get("showGroupTasks");
			this.eventsObj = _.extend({}, Backbone.Events);
			this.enableDraggability = this.options.enableDraggability;
			this.loadingQuery = true;
			this.isUserTabActive = true;

			//Get user and unclaimed tasks
			this.tasks = new AWWorkflow.AWTasksModel();
			this.tasks.userTasks.state.pageSize = AWInbox.PAGE_SIZE_OPTIONS[0];
			this.tasks.groupTasks.state.pageSize = AWInbox.PAGE_SIZE_OPTIONS[0];
			this.userTasks = this.tasks.userTasks;
			this.groupTasks = this.tasks.groupTasks;
			
			//Listen for the results to be updated so we can update our collection and re-render
			self.listenTo(self.eventsObj, "awinbox:updateresults", function(queryResults) {
				if(!self.loadingQuery && self.activeCollection) {
					//Render because self.loadQuery is false and when you click the next or back button we still need to 
					//render the view
					self.render();
				}
				//Set our collection to be the new, updated collection if it's being filtered it comes at a different scope
				//better way would just be to give the initial scope for the first updateresults from the task based on if 
				//it's in the my tasks or group tasks
				if(queryResults.models) {
					if (this.isUserTabActive) {
						self.userTasks.models = queryResults.models;
					} else {
						self.groupTasks.models = queryResults.models;
					}
				}

				//This get's called multiple times, so let's only deal with our spinner the first time
				//If view is created then run this code 
				if(self.loadingQuery) {
					//We're no longer loading our query so set this to false
					self.loadingQuery = false;
					//Destroy the loading spinner since we're done loading the query
					HPISpinner.destroySpinner(self.spinner);
					//Re-render our view, which causes our subviews to be built in the before render
					self.render();
				}
			}, self);

			//Grab the collections for the first time.
			self.refreshResults();

			self.viewModel = new AWInbox.ViewModel({ tasks: self.tasks }, this.config);

			this.resultControls = new AWInbox.Views.ResultControls({
				config: this.config,
				eventsObj: this.eventsObj

			});
		  

						
		},
		switchActiveCollection: function(event) {
			if($(event.currentTarget).attr("id") === "tabMyTasks") {
				this.activeCollection = this.userTasks;
				this.isUserTabActive = true;
			} else {
				this.activeCollection = this.groupTasks;
				this.isUserTabActive = false;
			}
		},
		getWorkflowDocObjectIds: function(event) {
			var formId = event.currentTarget.id;
			$.ajax({
				url: app.serviceUrlRoot + "/aw-workflow/getListOfWFDocsProps?formId=" + formId,
				context : this,
				success: function(result) {
					var formName = "";
					for (var i = 0; i < this.activeCollection.fullCollection.models.length; i++) {
						if (this.activeCollection.fullCollection.models[i].attributes.psiId === formId) {
							formName = this.activeCollection.fullCollection.models[i].attributes.psiName;
						}
					}
					this.addHtml(_.pluck(_.pluck(result,'properties'), 'documentNumber'), formName);
				},
				global: false
			});
		},
		addHtml: function(result, formName) {
			var html = "";
			if(result.length === 0) {
				html = "<p>" + window.localize("dashboard.awinBox.noWorkflowDocuments") + "</p>";
			} else {
				html += "<ul id=\"awinbox_workflows\">";
				//The form name will be the same for all of the workflow documents, so we can use index 0.
				for(var i = 0; i < result.length; i++) {
					html += "<li>" + result[i] + "</li>";
				}
				html += "</ul>";
			}
			
			$("." + formName).replaceWith(html);
		},
		sortColumn: function(e) {

			var columnAttrOcName = $(e.currentTarget).data("id");
			
			this.activeCollection.state.order = (this.activeCollection.state.order === -1) ? 1 : -1;
			this.activeCollection.setSorting(columnAttrOcName, this.activeCollection.state.order);
			this.activeCollection.fullCollection.sort();
			
			this.eventsObj.trigger("awinbox:updateresults", this.activeCollection);

		},
		beforeRender: function() {
			this.setView(".awinbox-result-controls", this.resultControls);
		},
		refreshResults: function() {
			var self = this;

			// animate our refresh icon for our inbox
			this.$(".aw-inbox-refresh-icon").addClass("icon-refresh-animate");

			self.tasks.fetch({
				success: function(queryResults) {
					//Once the query has successfully run, let's trigger the event to update our results
					self.userTasks = queryResults.get("userTasks");
					self.groupTasks = queryResults.get("groupTasks");
					self.userTasksLength = self.userTasks.fullCollection.length;
					self.groupTasksLength = self.groupTasks.fullCollection.length;
					if($("#tabMyTasks").hasClass("active")){
						self.activeCollection = self.userTasks;
					} else {
						self.activeCollection = self.groupTasks;				
					}
					//if check for which type of task is going then send that along, for right now we're always going to just send user tasks
					self.eventsObj.trigger("awinbox:updateresults", self.activeCollection);

				},
				error: function() {
					app.trigger("alert:error", {
						header: window.localize("modules.dashboard.savedSearchDashlet.errorLoading"),
						message: window.localize("modules.dashboard.savedSearchDashlet.thereWas")
					});
				},
				//Don't want to trigger any global ajaxStart or ajaxStop event handlers
				global: false
			});
			this.$(".aw-inbox-refresh-icon").removeClass("icon-refresh-animate");
		},
		afterRender: function() {
			if(this.enableDraggability) {
				this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
			}

		},
		serialize: function() {
			return {
				isUserTabActive: this.isUserTabActive,
				enableSorting: this.enableSorting,
				userTasks: this.userTasks.models,
				userTasksLength : this.userTasksLength,
				groupTasks: this.groupTasks.models,
				groupTasksLength : this.groupTasksLength,
				inboxName : this.inboxName,
				showUserTasks : this.showUserTasks,
				showGroupTasks : this.showGroupTasks
			};
		}
	});

	//View for the Wizard Inbox Result Controls (Filtering, Pagination, Sorting)
	AWInbox.Views.ResultControls = Backbone.Layout.extend({
		template: "dashboard/awinboxdashlet/awinboxresultcontrols/awinboxresultscontrol",
		events: {
			"click .awinbox-prev": "previousPage",
			"click .awinbox-next": "nextPage",
			"change .awinbox-page-select": "jumpToPage",
			"change .awinbox-num-results-per-page": "changePageSize",
			"keyup .awinbox-filter-results": "filterResults",
		},
		initialize: function(options) {
			var self = this;

			//Whether or not to show the pagination controls
			this.paginationControls = true;
			this.config = options.config;
			this.eventsObj = options.eventsObj;


			//Listen to the results being updated
			this.listenTo(this.eventsObj, "awinbox:updateresults", function(queryResults) {
				//Set our collection to the new results
				this.collection = queryResults;
				//Update our buttons - we pass false so we don't trigger another updateresults event
				//This function is being called since the query is done fetching initially - not from user interaction
				this._updateButtonsAndResults(this.collection.state.currentPage, false);
			}, this);
			
			//Set up our different page size options the user can choose from
			this.pageSizeOptions = AWInbox.PAGE_SIZE_OPTIONS;

			//Defaulting to 10
			this.currentPageSize = AWInbox.PAGE_SIZE_OPTIONS[0];

			//Set our empty filter text
			this.filterText = "";

			//Helper to select the current page that the user is viewing
			Handlebars.registerHelper("isPageSelected", function(currentPage, page) {
				if(currentPage === page) {
					return "selected";
				}
			});

			//Helper to select the current page size the user is using
			Handlebars.registerHelper("isPageSizeSelected", function(currentPageSize, pageSize) {
				// we might not have our collection if the query hasn't finished running
				if(self.collection && self.collection.state) {
					if(currentPageSize === pageSize) {
						return "selected";
					}
				}
			});

		},

		//Method to go to the previous page of results
		previousPage: function() {
			//Get the previous page of results for our collection
			this.collection.getPreviousPage();

			//Let's update our buttons and trigger an event to update the results table as well
			this._updateButtonsAndResults(this.collection.state.currentPage, true);
		},
		//Method to go to the next page of results
		nextPage: function() {
			//Get the next page of results for our collection
			this.collection.getNextPage();

			//Let's update our buttons and trigger an event to update the results table as well
			this._updateButtonsAndResults(this.collection.state.currentPage, true);
		},
		//Method to update the button controls because of user interaction - takes an updateResults parameter
		//to specify if the updateresults event should be triggered
		_updateButtonsAndResults: function(newPage, updateResults) {
			//Our current page is the new page account of the zero index offset
			this.currentPage = newPage + 1;

			//Check whether we have a previous page the user can go to
			this.hasPrevious = this.collection.hasPreviousPage();

			//Check whether we have a next page the user can go to
			this.hasNext = this.collection.hasNextPage();

			 //On first load sometimes it doesn't have the right total page count so if it starts with 1 lets make sure it's actually 1
			 if(this.collection.state.totalPages === 1) {
				this.collection.state.totalPages = Math.ceil(this.collection.models.length/this.currentPageSize);
			}

			//Reset our array of pages that the user can jump to
			this.pages = [];
			for (var i = 1; i <= this.collection.state.totalPages; i++) {
				this.pages.push({
					page: i,
					label: i + " " + window.localize("stage.outOf") + " " + this.collection.state.totalPages
				});
			}

			if(this.pages && this.pages.length !== 0) {
				this.paginationControls = true;
			}

			//If the calling function needs to trigger the results to be updated, let's trigger that event
			if(updateResults) {
				this.eventsObj.trigger("awinbox:updateresults", this.collection);
			}

			//Backbone Pagination doesn't get this correct.  I'd rather do this than change 3rd party library.
			if(this.pages && this.currentPage < this.pages.length) {
				this.hasNext = true;
			}

			//Render our view so the buttons can be updated (and the select dropdowns)
			this.render();
		},
		//Method to jump to a specific page instead of just going to the next or previous one
		jumpToPage: function(event) {
			//Parse the value of the option that the user chose
			var newPage = parseInt($(event.target).find("option:selected").val(), 10) - 1;

			//If we have at least one model
			if(this.collection.models.length > 0) {
				//Let's get the page the user selected to go to
				this.collection.getPage(newPage);

				//Let's update our buttons and trigger an event to update the results table as well
				this._updateButtonsAndResults(newPage, true);
			}
		},
		//Method to change the page size based on what the user selected from the available drop down options
		changePageSize: function(event) {
			//Get the page size option the user selected to change the page size to
			this.currentPageSize = parseInt($(event.target).find("option:selected").val(), 10);

			//If the page size the user selected is not the current page size, let's update our page size
			if(this.currentPageSize !== this.collection.state.pageSize) {
				app.log.debug("Page Size changed to: " + this.currentPageSize);

				//Set our page size to the page size the user requested
				this.collection.setPageSize(this.currentPageSize);

				//Let's go back to the first page of results when the page size is changed
				this.collection.getPage(0);

				//Let's update our buttons and trigger an event to update the results table as well
				this._updateButtonsAndResults(this.collection.state.currentPage, true);
			}
		},
		//Method to filter the results based on what a user types in - we want to only run this function
		//after 400 milliseconds have passed since the user last typed a key
		_filterResults: function(event) {
			var self = this;

			//Get the value of what the user typed in and make it lower case
			this.filterText = $(event.target).val();
			var filterQuery = this.filterText.toLowerCase();


			var filteredResults;

			//If we don't have any filter text and we do have an unfiltered collection, let's set the results
			//back to the unfiltered collection - will happen if a user types something and then deletes everything typed
			if(!filterQuery && this.unfilteredCollection) {
				filteredResults = this.unfilteredCollection;
			} else { //We have at least some text to filter on
				//If we don't yet have an unfiltered collection, let's save that
				if(!this.unfilteredCollection) {
					this.unfilteredCollection = self.collection.fullCollection.models;
				}

				//Filter our collection based on what the user typed
				filteredResults = _.filter(this.unfilteredCollection, function(model) {
					//This model hasn't yet passed the filter test
					var found = false;
					var headers = ["psiName","roleName","assignedDate"];
					//Loop over our selected attributes, see if the model has a value for that attribute and if the value
					//passes the filter test
					for (var i = 0; i < headers.length/*header length*/; i++) {
						//Get our attribute that we're currently looking at
						var attr = headers[i];

						//Get the value of this attribute for the current model
						//If this is an object, we're using the new configs so get ocName off of attr, otherwise can just grab attr
						var modelAttrVal;
						if(attr instanceof Object) {
							modelAttrVal = model.attributes[attr];
						} else {
							modelAttrVal = model.attributes[attr];
						}

						//Make sure this model has a value for it and if so if its string value contains the filter text
						//the user has typed in so far
						if(modelAttrVal && modelAttrVal.toString().toLowerCase().indexOf(filterQuery) !== -1) {
							found = true;
							//Don't need to keep checking attributes since we found at least one that has the filter text
							break;
						}
					}

					return found;
				});
			}

			//Now that we've got our filtered results, let's reset our collection to be these filtered results
			//NOTE: we need to grab the first page before we reset the full collection otherwise if we try filtering
			//from a page other than the first, it won't work
			this.collection.fullCollection.reset(filteredResults);

			//Update our buttons and trigger the event that the results have been updated
			this._updateButtonsAndResults(this.collection.state.currentPage, true);
		},
		filterResults: _.debounce(function(event) {
			this._filterResults(event);
		}, 400),
		afterRender: function() {
			//Once we're done rendering, if we have some filter text, we want to put it back in to the filter box
			//input and focus on that box and we need to put the cursor at the end so the user can keep typing - the
			//following is a simple way to do so that works cross browser (without using a bigger library)
			if(this.filterText) {
				//Find our filter input box on the page and focus on it
				var filterInputBox = this.$(".awinbox-filter-results");
				filterInputBox.focus().val("").blur().focus().val(this.filterText);
			}

			if(this.collection) {
				this.collection.setPageSize(this.currentPageSize);
			}

		},
		serialize: function() {
			return {
				// whether or not we want to show our pagination controls (whether we have results)
				paginationControls: this.paginationControls,
				// these are the pages the user can choose to jump to
				pages: this.pages,
				// this is whether or not we should enable or disable the previous button
				hasPrevious: this.hasPrevious,
				// this is whether or not we should enable or disable the next button
				hasNext: this.hasNext,
				// this is the list of options the user can choose to change the page size to
				pageSizeOptions: this.pageSizeOptions,
				// this is the page of the results that we are currently viewing
				currentPage: this.currentPage,
				// this is the number of results on the page that we have currently selected
				currentPageSize: this.currentPageSize
			};
		}
	});

	return AWInbox;
});