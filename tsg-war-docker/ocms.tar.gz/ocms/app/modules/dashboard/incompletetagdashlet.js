/* global $ */
//Index Inbox module
define([
        // Application.
        "app",
        "modules/common/workflow",
        "modules/common/tracselector",
        "jqplot",
        "jqplotBarRenderer",
        "jqplotCategoryAxisRenderer",
        "jqplotCanvasTextRenderer",
        "jqplotCanvasAxisTickRenderer",
        "jqplotPointLabels"
    ],

    function(app, Workflow, TracSelector) {
        "use strict";
        // Create a new module.
        var IncompleteTagDashlet = app.module();

        IncompleteTagDashlet.Views.Layout = Backbone.Layout.extend({
            template: "dashboard/incompletetagdashlet",
            className: "dashlet",
            initialize: function() {
                this.config = this.options.config;
                this.enableDraggability = this.options.enableDraggability;
                this.tabs = [];

                var isActiveTab = false;

                this.IncompleteTagsView = new IncompleteTagDashlet.IncompleteTagsView({ config: this.config });
                isActiveTab = true;

                this.tabs.push(this.generateTab("incompleteTagDashlet", window.localize("Incomplete Documents"), isActiveTab));

            },
            // not currently being used, but if want to add multiple tabs like workflow reporting does you can use this function
            generateTab: function(tabId, tabName, isActive) {
                var tab = {};
                tab.id = tabId;
                tab.name = tabName;
                tab.active = isActive;
                return tab;
            },
            afterRender: function() {
                if (this.enableDraggability) {
                    this.$(".dashlet-header").css("cursor", "move").css("pointer", "move");
                }
                if (this.IncompleteTagsView) {
                    this.setView("#subdashletDiv", this.IncompleteTagsView, true).render();
                }
            },
            serialize: function() {

                return {
                    "tabs": this.tabs,
                    "dashletName": this.config.get("dashletName")
                };

            }
        });

        //Workflow History View
        IncompleteTagDashlet.IncompleteTagsView = Backbone.Layout.extend({
            template: "dashboard/incompletetaggraph",
            events: {
                'jqplotDataClick .graph-container': 'onBarClick'
            },
            initialize: function(options) {
                this.config = this.options.config;
                this.seriesArray = [];
                this.seriesLabels = [];
                this.graphSettings = {};
            },
            // build search url based on the doc type of the clicked bar and navigate to search url
            onBarClick: function(ev, seriesIndex, pointIndex, data) {
                var docType = this.seriesTicks[pointIndex];
                var self = this;
                var remainingRequiredDocs = app.remainingRequiredDocs || "remainingRequiredTags";
                var paramName = remainingRequiredDocs;

                var query = "paramName=" + paramName + "&operator=OPERATOR_EQUALS&paramValue=" + docType +
                    "&paramType=property/paramName=" + this.config.get('type') +
                    "&paramValue=" + this.config.get('type') + "&paramType=type";

                TracSelector.establishTracByObjectType(this.config.get('type'), function(establishedTrac) {
                    var searchUrl = "search/" + establishedTrac + "/" + self.config.get('type') + "?" + query;
                    Backbone.history.navigate(searchUrl, { trigger: true });
                });
            },
            getSeriesArray: function() {
                var self = this;
                var url = '/hpi/getIncompleteTags';
                if (!this.config.get('type')) {
                    app.log.error(window.localize("modules.dashboard.incompleteTagDashlet.incompleteTag"));
                    return;
                }
                url += '?type=' + this.config.get('type');
                $.ajax({
                    url: app.serviceUrlRoot + url,
                    type: 'GET',
                    dataType: "json",
                    success: function(documentsMap) {
                        // documentsMap returns as a single object that isnt easy to sort
                        // this converts it to an array of objects so it is easily sortable
                        var docMapsSortable = [];
                        _.each(_.keys(documentsMap), function(key) {
                            docMapsSortable.push({ label: key, count: documentsMap[key] });
                        });

                        var docMapsSorted = _.sortBy(docMapsSortable, function(item) {
                            // the '-' makes it sort from high to low
                            return -item.count;
                        });

                        // limit the number of results shown based on the configs
                        if (self.config.has('numberResultsToShow') && self.config.get('numberResultsToShow') !== 'all') {
                            docMapsSorted = _.first(docMapsSorted, self.config.get('numberResultsToShow'));
                        }

                        var docValues = _.pluck(docMapsSorted, 'count');
                        self.seriesTicks = _.pluck(docMapsSorted, 'label');

                        if (docValues.length === 0) {
                            self.$("#allTagsComplete").show();
                        } else {
                            self.$("#allTagsComplete").hide();
                        }

                        self.seriesArray.resolve(docValues);
                    }
                });

            },
            getGraphSettings: function(val) {

                var graphSettings = {
                    // The "seriesDefaults" option is an options object that will
                    // be applied to all series in the chart.
                    seriesDefaults: {
                        renderer: $.jqplot.BarRenderer,
                        rendererOptions: {
                            fillToZero: true,
                            varyBarColor: true
                        },
                        pointLabels: {
                            show: true,
                            edgeTolerance: -10,
                            hideZeros: true,
                            ypadding: 0
                        }
                    },

                    // Show the legend and put it outside the grid, but inside the
                    // plot container, shrinking the grid to accomodate the legend.
                    legend: {
                        show: false
                    },
                    axes: {
                        // Use a category axis on the x axis and use our custom ticks.
                        xaxis: {
                            renderer: $.jqplot.CategoryAxisRenderer,
                            tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                            tickOptions: {
                                angle: -20
                            },
                            ticks: this.seriesTicks
                        },
                        // Pad the y axis just a little so bars can get close to, but
                        // not touch, the grid boundaries.  1.2 is the default padding.
                        yaxis: {
                            pad: 1.05,
                            min: 0
                        }
                    }
                };
                return graphSettings;
            },
            afterRender: function() {
                var self = this;
                //TODO figure out a better way to check if the graph is there or not
                this.seriesArray = $.Deferred();
                this.getSeriesArray();
                $.when(this.seriesArray).done(function(foundSeries) {
                    if (!$.trim($("#incompleteTagGraphDiv").html()).length) {
                        if (foundSeries.length < 1) {
                            app.log.warn(window.localize("modules.dashboard.incompleteTagDashlet.imcompleteTagNoResults"));
                            return;
                        }
                        self.plot1 = $.jqplot("incompleteTagGraphDiv-" + self.cid, [foundSeries], self.getGraphSettings());
                    }
                });
            },
            serialize: function() {
                return {
                    cid: this.cid
                };
            }
        });

        return IncompleteTagDashlet;
    });