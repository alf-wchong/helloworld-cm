//Index Inbox module
define([
	// Application.
	"app",

	//Submodules
	"inbox",
	"modules/dashboard/awinbox",
	"modules/dashboard/savedsearchdashlet",
	"modules/dashboard/recentobjects",
	"modules/dashboard/reporting/reportingdashlet",
	"workflowreportingdashlet",
	"incompletetagdashlet",
	"iframedashlet",
	"modules/common/notificationview",
	"module"
],

	function(app, Inbox, AWInbox, SavedSearch, RecentObjects, Reporting, WorkflowReporting, IncompleteTagDashlet, IFrameDashlet, NotificationsDashlet, module) {

		// Create a new module.
		var Dashboard = app.module();

		Dashboard.availableDashlets = {
			"SavedSearchDashlet" : SavedSearch,
			"AWInboxDashlet" : AWInbox,
			"InboxDashlet" : Inbox,
			"RecentObjectsDashlet" : RecentObjects,
			"ReportingDashlet" : Reporting,
			"WorkflowReportingDashlet" : WorkflowReporting,
			"IncompleteTagDashlet" : IncompleteTagDashlet,
			"IFrameDashlet" : IFrameDashlet,
			"NotificationDashlet" : NotificationsDashlet
		};

		// Default View.
		Dashboard.Views.Layout = Backbone.Layout.extend({
			template: "dashboard/dashboard",
			className : "dashboard",
			initialize: function() {
				var that = this;
				that.name = "dashboard";
				that.config = that.options.config;
				that.tabs = that.options.config.get("tabs"); // tabs []

				// that.numberOfColumns = that.config.get("numberOfColumns");
				that.currentTabColNum;
				
				that.visibleDashlets = [];
				that.currentTab = "";
				that.allowedDashlets = [];
			},
			events: {
				"click #navTabs li": "filterDashlets"
			},
			filterDashlets: function(evt) {
				var that = this;
				var dashletCounter = 0;

				// Find out current tab name first
				that.currentTab = that.getCurrentTab(evt, that.tabs);

				// Find out current tab col number first
				that.currentTabColNum = that.getCurrentTabColNum(evt, that.tabs);

				// First things first, loop through the dashboard config and figure out what dashlets you can and cannot see based on groups

				that.allowedDashlets = that.buildAllowedDashletsArray(new Backbone.Collection(_.findWhere(that.config.get("tabs"), {"tabId" : that.currentTab}).selectedDashlets));
				//helper function that returns the count of configs on userPreferences and checks for the configs
				//having new ids
				var concurrencyCheck = that.configToUserPrefConcurrencyCheck(that.allowedDashlets);

				// Setup col class in dom based on currentTabColNum
				that.setDashColClass();

				//now check to see if we even have a user preferences dashletObject OR if the dashletObject we
				//do have still contains the right amount of allowed dashlets OR if dashletIds have been changed. 
				//if one of these things is true, rebuild all of your allowed dashlets for the user
				if(!app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab] || concurrencyCheck.dashletCount !== that.allowedDashlets.length || 
						concurrencyCheck.idCheck) {
							
					var newDashletOrder = {};
					_.each(that.allowedDashlets, function(dashletConfigId){
						var currentColumn = (dashletCounter%that.currentTabColNum)+1;

						if(newDashletOrder["column"+currentColumn]) {
							newDashletOrder["column"+currentColumn].push(dashletConfigId);
						} else {
							newDashletOrder["column"+currentColumn] = [dashletConfigId];
						}
						dashletCounter++;
					});

					if (dashletCounter === 0) {
						$('#dashletContainer-helperMessage').show();
					} else {
						$('#dashletContainer-helperMessage').hide();
					}

					this.updateDashletOrderPreference(that.currentTab, newDashletOrder);
				}

				var columnNumberToID = {
					"1" : "#dash-col-1",
					"2" : "#dash-col-2",
					"3" : "#dash-col-3",
					"4" : "#dash-col-4"
				};

				//now we are ensure that the user preferences object is correct, go through all of the keys in the dashletOrder (which are the columnNames,
				//besides the _id which gets added to all config objects in HPI)
				_.each(_.without(_.keys(app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab]), "_id").sort(), function(currentColumnId, index) {
					var dashletsInColumn = app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab][currentColumnId];
					_.each(dashletsInColumn, function(dashletId) {
						var dashletConfig = that.config.get("dashlets").findWhere({ dashletId : dashletId }),
							dashletType = dashletConfig.get("dashletType"),
							dashletModule = Dashboard.availableDashlets[dashletType],
							//so a user could set something up on a column that could chnage to be non-existant through
							//configuration. if the column number from the userPrefernces is bigger than the number of columns
							//total, throw the dashlet on the first column
							columnNumber = index+1 > that.currentTabColNum ? 1 : index+1;

						//here we only want to display dashlets that a user has group access to. If no groups are specified, all users can see the dashlet
						that.insertDashlet(columnNumberToID[columnNumber], dashletModule, dashletConfig);
					});
				});
			},
			getCurrentTabColNum: function(evt, tabs) {
				var colNum;

				if (evt === undefined && tabs && tabs.length > 1 && tabs[0].tabColNum !== undefined && tabs[0].tabColNum !== "" ) {
					// first tab after page loaded
					colNum = tabs[0].tabColNum;
				} else if (evt !== undefined && evt.srcElement.dataset.tabcolnum !== undefined && evt.srcElement.dataset.tabcolnum !== "") {
					// get tab id from clicked element data attr
					colNum = evt.srcElement.dataset.tabcolnum;
			   	} else {
					// no tab is set
					colNum = this.config.get("numberOfColumns");
				}
				
				colNum = parseInt(colNum);

				return colNum;
			},
			getCurrentTab: function(evt, tabs) {
				var ct;
				
				if (evt === undefined && tabs && tabs.length > 0) {
					// first tab after page loaded
					ct = tabs[0].tabId;
				} else if (evt !== undefined && evt.srcElement.id !== undefined) {
					// get tab id from clicked element
					ct = evt.srcElement.id;
			   	} else {
					// no tab is set
					ct = "baseTab";
				}
				
				return ct;
			},
			buildAllowedDashletsArray: function(configDashletsArray) {
				var _allowedDashlets = [];
				var self = this;
				var dashletPreferences = app.context.currentUserPreferences().get("dashletVisibilities");
				configDashletsArray.each(function(dashletConfig) {
					// The selected dashlets array that gets passed in here, only has dashletId and dashletName, so we want to grab the updated dashlet model
					// that has all the properties we need
					var fullDashletConfig = self.config.get("dashlets").findWhere({ dashletId : dashletConfig.get('dashletId') });

					// intersection of user's group and dashlet allowed groups
					var matchedGroups = [];
					matchedGroups = _.intersection(app.user.get("groupNames"), fullDashletConfig.get("allowedGroups"));

					var dashletUserPreferencesVisibility = self.isDashletSelectedToShowInUserPrefs(fullDashletConfig, dashletPreferences);

					// dashletUserPreferencesVisibility is dependent on what the user has configured in their user preferences
					// if matchedGroups > 0 --> user would be able to see the dashlet
					// if matchedGroups === 0 && allowedGroups > 0 --> user would not be able to see the dashlet
					// if matchedGroups === 0 && allowedGroups === 0 --> user would be able to see the dashlet
					if(dashletUserPreferencesVisibility && (matchedGroups && matchedGroups.length > 0 || fullDashletConfig.get("allowedGroups").length == 0)) {
						_allowedDashlets.push(fullDashletConfig.get("dashletId"));
					}
				});

				return _allowedDashlets;
			},
			isDashletSelectedToShowInUserPrefs: function(fullDashletConfig, dashletPreferences) {
				var dashletSwitchObject;
				
				// go through all the dashlet preferences and check to see if our dashletId already has preferences configured, if it does use that
				_.each(dashletPreferences, function(dashletSwitchArray){
					if(dashletSwitchArray.dashletId === fullDashletConfig.get("dashletId")) {
						dashletSwitchObject = dashletSwitchArray;
					}
				});
				
				var dashletUserPreferencesVisibility;

				// Using the already set preferences to get the visibility of the dashlet
				if(dashletSwitchObject) {
					dashletUserPreferencesVisibility = dashletSwitchObject.dashletVisibility;
				} else {
					// If not user preferences have ever been set up for the dashboard before, create a new array
					// Happens for a user that does not have user prefs already
					if(!dashletPreferences) {
						dashletPreferences = [];
					}

					// Push the new preferences for the dashletId on to the preferences 
					// Whether newly created or the existing ones we always want to add a dashlet that doesn't currently have configuration and make it visible
					dashletPreferences.push({
						dashletId: fullDashletConfig.get("dashletId"),
						dashletVisibility: true
					});
					
					app.context.currentUserPreferences().set("dashletVisibilities", dashletPreferences);

					dashletUserPreferencesVisibility = true;
				}

				return dashletUserPreferencesVisibility;
			},
			insertDashlet: function(columnName, dashletModule, dashletConfig) {
				//this was really bizarre, but since recent objects dashlets dealt with lots of deffereds, its after render would
				//be triggered last, regardless of when it was inserted. now we create an explicit div for each dashlet and manually
				//set, not inset, the dashlets into their respective divs
				this.$el.find(columnName).append("<div id=\"" + dashletConfig.get("dashletId") +"\">");
				
				var newDashlet = new dashletModule.Views.Layout({config : dashletConfig, enableDraggability: this.config.get("enableDraggability")});
				
				this.visibleDashlets.push( newDashlet );
				
				this.setView("#" + dashletConfig.get("dashletId"), newDashlet , true).render();	
			},
			//Get all of the columns that are being used in the dashboard currently and pull all ids in order
			setDashletOrder: function() {
				var that = this,
					allColumns = [];

				//loop through all of the columns of the dashboard and save them in an array
				for(var i=1; i <= that.currentTabColNum; i++) {
					allColumns.push(this.$el.find("#dash-col-" + i)[0]);
				}

				//now loop through each column's children, which are the dashlets, and save their id's on the userPreferences
				//doing this looping here and not in the for loop above for linting purposes
				var newDashletOrder = {};
				_.each(allColumns, function(currentColumn, index) {
					var currentColumnIds = [];
					_.each(currentColumn.children, function(dashlet) {
						currentColumnIds.push(dashlet.id);
					});
					newDashletOrder["column"+(index+1)] = currentColumnIds;
				});

				this.updateDashletOrderPreference(that.currentTab, newDashletOrder);
			},
			// a helper function to update dashlet orders
			updateDashletOrderPreference: function (dashletName, newDashletOrder) {
				var prefix = "dashletOrder_";
				// grab all of the dashlet order objects
				var dashletPreferences = app.context.currentUserPreferences().get("allDashletOrders");
				// create/update the respective dashlet order and save it back on the config
				dashletPreferences[prefix+dashletName] = newDashletOrder;
				app.context.currentUserPreferences().set("allDashletOrders", dashletPreferences);
			},
			configToUserPrefConcurrencyCheck: function(allowedDashlets) {
				var that = this,
					dashletCount = 0,
					allUserPrefIds = [],
					idCheck = false;

				_.each(_.without(_.keys(app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab]), "_id"), function(currentColumnId, index) {
					dashletCount += app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab][currentColumnId].length;
					allUserPrefIds = _.union(allUserPrefIds, app.context.currentUserPreferences().get("allDashletOrders")["dashletOrder_" + that.currentTab][currentColumnId]);
				});

				var differenceOfIds = _.difference(allUserPrefIds, allowedDashlets);
				if (differenceOfIds.length > 0) {
					idCheck = true;
				}

				return {
					dashletCount : dashletCount,
					idCheck :idCheck
				};
			},
			setDashColClass: function() {
				// Clear up all dash-col first
				$('#dash-col-1, #dash-col-2, #dash-col-3, #dash-col-4').empty();
				$(".dashboardColumn").removeClass(function (index, className) {
					return (className.match (/(^|\s)col-md-\S+/g) || []).join(' ');
				});

				// set up number of columns on the html side.
				switch (this.currentTabColNum) {
					case 1:
						$("#dash-col-1").addClass("col-md-12").show();
						$("#dash-col-2").hide();
						$("#dash-col-3").hide();
						$("#dash-col-4").hide();
						break;
					case 2:
						$("#dash-col-1").addClass("col-md-6").show();
						$("#dash-col-2").addClass("col-md-6").show();
						$("#dash-col-3").hide();
						$("#dash-col-4").hide();
						break;
					case 3:
						$("#dash-col-1").addClass("col-md-4").show();
						$("#dash-col-2").addClass("col-md-4").show();
						$("#dash-col-3").addClass("col-md-4").show();
						$("#dash-col-4").hide();
						break;
					case 4:
						$("#dash-col-1").addClass("col-md-3").show();
						$("#dash-col-2").addClass("col-md-3").show();
						$("#dash-col-3").addClass("col-md-3").show();
						$("#dash-col-4").addClass("col-md-3").show();
						break;
				}
			},
			//go through array and call render for each dashlet
			afterRender: function() {
				var that = this;
				if ( this.rendered ) {
					app.log.warn(window.localize("modules.dashboard.dashboard.errorThis"));
				}
				else {
					this.rendered = true;
				}

				//we will need the user's groups in the filter function, so go ahead
				//and make the call now and only call filter when it is done,
				//the groups are stored on the global app.user var
				app.user.getGroups().done(function() {
					app.log.debug(app.user.get("groupNames"));
					that.filterDashlets();
				});

				if(that.config.get("enableDraggability")){
					$(".dashboardColumn").sortable({
						handle: ".dashlet-header",
						connectWith: ".dashboardColumn",
						placeholder: "dashlet-placeholder ui-corner-all",
						stop: function() {
							//calls setDashletOrder once a dashlet stops moving
							that.setDashletOrder();
						}
					});
				}

				// Add active css class into the 1st navTabs item when page loaded
				$("#navTabs li:first-child").addClass("active");
			},
			serialize: function() {
				return { 
					"dashboardTitle" : module.config().dashboardTitle || "Dashboard",
					// "tabs" : this.config.get('tabs') || [],
					"tabs" : this.tabs || [],
					"emailProxyConfigured" : app.context.currentUserPreferences().get("workflowProxy").enabled,
					"proxiedUserName" : app.context.currentUserPreferences().get("workflowProxy").delegatedDisplayName,
					"onlyOneTab" : (this.tabs && this.tabs.length === 1) ? true : false 
				};
			}
		});

		// Return the module for AMD compliance.
		return Dashboard;

	});
