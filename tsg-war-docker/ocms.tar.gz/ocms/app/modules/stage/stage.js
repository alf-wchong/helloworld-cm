// Stage module
define([
    // Application.
    "app",
    "knockout",
    "knockback",
    "handlebars",
    "oc",
    //config objects from admin
    "modules/hpiadmin/preferences/userpreferences",
    "modules/hpiadmin/stageconfig/stageconfig",
    "modules/stage/stageinfo",
    "modules/stage/workflowinfo",
    "relatedObjects",
    "modules/stage/folderactions",
    "modules/stage/docviewer",
    //one day I hope to not need this, everything should be in a more descriptive module
    "modules/tsg",
    "modules/common/rightsideactionhandler",
    "modules/common/scanner/scanner",
    "modules/formsupport",
    "URIjs/URI",
    "tsgUtils",
    //these just need to be referenced so they are imported in time
    "jqueryUI"
],

// Map dependencies from above array.
function(app, ko, kb, Handlebars, OC, UserPreferences, Stageconfig, Stageinfo, WorkflowInfo, Relatedobjects, FolderActions, Docviewer, TSG, Rightsideactionhandler, Scanner, Formsupport, URI, tsgUtils ) {

      // Create a new module.
      var Stage = app.module();
      TSG.formSupport = Formsupport;

      Stage.eventHandlers = {
          
          _onObjectModified : function(args){
              var old = args.oldOco;
              var current = args.newOco;

              //check if is it a container or a doc
              var isContainer = app.context.container.get('objectId') === old.get("objectId") ? true : false;
              var isDocument = app.context.document.get('objectId') === old.get("objectId") ? true : false;

              // if we are updating both a container and an objectId then call refreshIds with both new ids
              if (old.get("objectId") !== current.get("objectId") && args.updatedContainer) {
                app.trigger("stage.refresh.bothIds", args.updatedContainer, current.get("objectId") );
              
              //if the objectId changed (document versioned) refresh all (or if the new id is the container and document)
              } else if(old.get("objectId") !== current.get("objectId") || (isContainer && isDocument)){
                  var newDoc = true; //true means same id just refresh
                  var newContainer = true;
                  if(isContainer){
                      newContainer = current.get("objectId");
                  }
                  if(isDocument){
                      newDoc = current.get("objectId");
                  }
                  app.trigger("stage.refresh.bothIds", newContainer, newDoc );
              }else if(isContainer){
                  app.trigger("stage.refresh.containerId", current.get("objectId"));
              }else if(isDocument){
                  app.trigger("stage.refresh.documentId", current.get("objectId"));
              }else{
                  //some other object changed, presumably something in related objects
                  //refresh container
                  app.trigger("stage.refresh.containerId", true);
              }

          },
         _onObjectDeleted : function(args){
              var docId = args.id;
              var isDocument = app.context.document.get('objectId') === docId ? true : false;

              //if the id matches with the document
              if(isDocument){
                  //clear document observable on the action, and refresh container
                  app.trigger("stage.refresh.bothIds", true, undefined);
              }
              else{ //if the id does not match the app.context.document
                  app.trigger("stage.refresh.containerId", true);
              } 
          }
      };

      /*Explicitly labeled a constructor for clarity
      *
      * The view model also functions as a initialization function for the stage
      * in that it is instantiated by the router, so any subscritions, event triggers
      * or 'init' behaviors can be placed here.
      */
      Stage.ViewModelConstructor = function(trac, containerId, documentId, stageConfig){
          var self = this;
          self.trac = ko.observable(trac);
          self.documentId = ko.observable(documentId);
          self.documentId2 = ko.observable();
          self.containerId = ko.observable(containerId);
          //Stageconfig has all the module configs in it.
          self.stageConfig = stageConfig;

          //one day we will phase out observables here to make clean up easier
          self.bbDocument = app.context.document.set("objectId", documentId);
          self.bbContainer = app.context.container.set("objectId", containerId);
          self.foundDoc = $.Deferred();
          self.fetchedProps = $.Deferred();
          self.foundCollection = $.Deferred();
          self.hasPermissions = $.Deferred();

          self.showPane1 = ko.observable(true);
          self.showPane2 = ko.observable(false);
          self.showPane3 = ko.observable(false);
  
          self.showPane1.subscribe(function(){
              self.paneManipulation();
          });
  
          self.showPane2.subscribe(function(){
              self.paneManipulation();
          });
  
          self.showPane3.subscribe(function(){
              self.paneManipulation();
          });

          //check to see if we want to increase the renditioning priority of each document in the container
          self.elevateFolderPriority = stageConfig.get("elevateFolderPriority") ? stageConfig.get("elevateFolderPriority") : "false";

          if (self.elevateFolderPriority === "true" || self.elevateFolderPriority === true) {
              $.ajax({
                  url: app.serviceUrlRoot + "/prioritizeRenditioning",
                  data: {
                      containerId: containerId
                  },
                  global: false
              });
          }     

          //computed function for correctly showing panes in the stage
          //pane1 - the active document pane
          //pane2 - the dual view pane
          //pane3 - the rightSideActionHandler pane

          /* removed the computed function and instead just kick off the paneManipulation 
          through the subscribe calls whenever pane1, pane2, pane3 are modified.
          Deals with timing issues that could occur as a result of race conditions 
          associated with changing panes */

          self.paneManipulation = function() {
              var pane1 = self.showPane1();
              var pane2 = self.showPane2();
              var pane3 = self.showPane3();

              if (pane1 && pane2 && pane3) {
                  $('#pane1').addClass("col-md-4").removeClass("col-md-6").removeClass("col-md-12").show();
                  $('#pane2').addClass("col-md-4").removeClass("col-md-6").removeClass("col-md-12").show();
                  $('#pane3').addClass("col-md-4").removeClass("col-md-6").removeClass("col-md-12").show();
              } else if (pane1 && pane2 && !pane3) {
                  $('#pane1').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
                  $('#pane2').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
                  $('#pane3').hide();
              } else if (pane1 && !pane2 && pane3) {
                  $('#pane1').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
                  $('#pane2').hide();
                  $('#pane3').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
              } else if (pane1 && !pane2 && !pane3) {
                  $('#pane1').addClass("col-md-12").removeClass("col-md-6").removeClass("col-md-4").show();
                  $('#pane2').hide();
                  $('#pane3').hide();
              } else if (!pane1 && pane2 && pane3) {
                  $('#pane1').hide();
                  $('#pane2').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
                  $('#pane3').addClass("col-md-6").removeClass("col-md-4").removeClass("col-md-12").show();
              } else if (!pane1 && pane2 && !pane3) {
                  $('#pane1').hide();
                  $('#pane2').addClass("col-md-12").removeClass("col-md-6").removeClass("col-md-4").show();
                  $('#pane3').hide();
              } else if (!pane1 && !pane2 && pane3) {
                  $('#pane1').hide();
                  $('#pane2').hide();
                  $('#pane3').addClass("col-md-12").removeClass("col-md-6").removeClass("col-md-4").show();
              } else {
                  $('#pane1').hide();
                  $('#pane2').hide();
                  $('#pane3').hide();
              }
              app.trigger("stage.windowResizePanes");
          };
          
          //TODO this should actually be a backbone model of a repo object
          self.container = ko.observable();
          self.activeDocument = ko.observable();
          self.staticDocument = ko.observable();
          self.document2 = ko.observable();        
          /**document 1 **/
          self.getDocumentProperties = function(newValue) {
              if(newValue){
                self.fetchedProps = TSG.services.ajaxService.getObjectProperties(newValue, function(data){
                      self.activeDocument(data);
                  }, function() {//this can happen if the object isn't found.
                      app.log.warn(window.localize("modules.stage.stage.errorWhile"));
                  });            
              }
              else
              {
                  self.activeDocument(null);
                  self.fetchedProps.resolve(true);
              }
          };
          self.documentId.subscribe(function(newId){
              app.trigger('refreshWFInfo', newId);
              self.bbDocument.set("objectId", newId);
              if(newId){
                  self.getDocumentProperties(newId);
                  self.bbDocument.fetch();
              }
          });
          self.foundDoc.done(function(docFound) {
              self.foundCollection.done(function(foundCol) {
                  if(docFound && foundCol && self.documentId() !== undefined && self.documentId() !== ""){
                      self.getDocumentProperties(self.documentId());
                  }
              });

          });

          /**end document 1 **/
          
          /**document 2 **/
          self.getDocument2Properties = function(newValue) {
              if(newValue === "" || newValue === undefined){
                  //hide the second pane
                  app.trigger("toggleDualPane", false);
              }else {
                  TSG.services.ajaxService.getObjectProperties(newValue, function(data){
                      self.staticDocument(data);
                      app.trigger("toggleDualPane", true);
                  });
              }
          };
          self.documentId2.subscribe(self.getDocument2Properties);
          self.getDocument2Properties(self.documentId2());
   
          /**end document 2 **/
          
          /*This Function loads the containerId into docId if documentId is blank and the trac is configured 
           *to allow it.
           */
          self.getContainerProperties = function(newValue) {
              self.bbContainer.set("objectId", newValue).fetch({
                  global: false
              });
              TSG.services.ajaxService.getObjectProperties(newValue, function(data){
                  self.container(data);
                  
                  //TODOWe'll need this for wizard probably, this allowed us to load a doc as the container and document
                  /**if(TSG.configuration.propertyConfig !== undefined && ( documentId() === undefined || documentId().length < 1)){
                      var oConfig = TSG.configuration.propertyConfig[TSG.stage.model.trac()][data.objectType];
                      if(oConfig === undefined){
                          for(var k in TSG.configuration.propertyConfig[TSG.stage.model.trac()]){
                              oConfig = TSG.configuration.propertyConfig[TSG.stage.model.trac()][k];
                              break;
                          }
                      }
                      if(oConfig !== undefined){
                          var loadTo = oConfig.configs.loadsTo;
                          if(loadTo !== undefined){
                              if("both" === loadTo){
                                  TSG.stage.model.documentId(data.objectId);
                              }
                          }
                      }
                  }**/
              }, function() {
                  app.log.warn(window.localize("modules.stage.stage.unableToGet"));
              });
              
          };
          
          self.containerId.subscribe(self.getContainerProperties);
          if(self.containerId() !== undefined && self.containerId() !== ""){
              self.getContainerProperties(self.containerId());
          }
          /**
              This is the function where we fetch the documents,
              setup our listeners for the fetches, and then 
              validate the user's permissions.
          */
          self.setupCalls = function()  {
              self.collectionErrorMessage = function() {
                  self.errorMessage(self.foundCollection);
              };
              self.docErrorMessage = function() {
                  self.errorMessage(self.foundDoc);
              };

              self.errorMessage = function(deferred) {
                  app.log.warn(window.localize("modules.stage.stage.unableToFetch"));
                  app.trigger("alert:error", {
                      header: self.stageConfig.get("docErrorHelpLabel"),
                      message: self.stageConfig.get("docErrorHelpText"),
                      confirm: function() {
                          Backbone.history.navigate("/dashboard", {trigger : true});
                      },
                      confirmLabel: window.localize("return.dashboard")
                  });
                  deferred.resolve(false);
              };


              self.bbContainer.fetch({
                      global: false,
                      statusCode: {
                          "403": function() {
                              self.foundCollection.resolve(true);
                          },
                          "404":self.collectionErrorMessage
                      },
                      success: function() {
                          self.foundCollection.resolve(true);
                      }
              });
              if(documentId){
                  self.bbDocument.fetch({
                      global: false,
                      statusCode: {
                          "403": function() {
                              self.foundDoc.resolve(true);
                              self.hasPermissions.resolve(false);
                          },
                          "404": self.docErrorMessage
                      },
                      success: function() {
                          self.foundDoc.resolve(true);
                      }

                  });
              } else {
                  //if no doc, we can just pretend one exists to resolve anyone waiting on the call
                  //as the doc is in fact our folder
                  self.foundDoc.resolve(true);
                  self.fetchedProps.resolve(true);
              }
              $.when(self.foundDoc, self.foundCollection).done(function(docExists, folderExists) {
                  if(!docExists || !folderExists || self.hasPermissions.state() === "resolved") {
                      return;//do nothing if any of these are true - it means we don't need to check permissions in stage
                  }
                  if(documentId) {
                      self.readPermission = $.ajax({
                          url: app.serviceUrlRoot + "/canReadObject",
                          data: {objectId: documentId},
                          global: false,
                          success: function(val) {
                              self.hasPermissions.resolve(val);
                          }
                      });
                  } else {
                      self.readPermission = $.ajax ({
                          url: app.serviceUrlRoot + "/canReadObject",
                          data: {objectId: containerId},
                          global: false,
                          success: function(val) {
                              self.hasPermissions.resolve(val);
                              if(!val) {//if we don't have READ permissions on the folder
                                  app.trigger("alert:error", {
                                      header: self.stageConfig.get("docPermissionHelpLabel"),
                                      message: self.stageConfig.get("docPermissionHelpText"),
                                      confirm: function() {
                                          window.history.back();
                                      },
                                      confirmLabel: window.localize("403.confirm.message")
                                  });
                              }
                          }
                      });
                  }
              });
          };
    };
    
    /* 
    * Default View. There is no HTML associated with this view, it is assumed to already be operating within the 
    * stagelayout template.
    *
    * This view sets up to update the config when the trac changes.
    * 
    */
    Stage.Views.Layout = Backbone.Layout.extend({
      template: "stage/stage",
      events: {
          "click #expander" : "expanderClick", 
          "click #tracInfo" : "showStageInfo"
      },
      initialize: function(){
          var tracConfig = app.context.tracConfigs.findWhere({name : app.context.configName()});
          var that = this;

          //initialize the uri without the window origin (e.g. http://edge2.tsgrp.com) and app.root (e.g. /ocms/)
          this.uri = new URI(tsgUtils.getUrlForUri(app.root.length));

          this.hideLeftBar = this.uri.getParameter("hideLeftBar") === "true";

          app.context.configService.getStageConfigByName(tracConfig.get("StageConfig"), function (stageConfig) {
            that.options.viewModel = new Stage.ViewModelConstructor(that.options.trac, that.options.containerId, that.options.documentId, stageConfig);

            // Setting up second dual pane docviewer here so we can listen for it's close event
            that.dualPaneDoc2 = new Docviewer.Views.Layout({
                documentId: that.options.viewModel.documentId2,
                stageViewModel: that.options.viewModel,
                moduleId: "2"
            });

            // Setup all listeners for that module.
            that.setupListeners();

            //setup subviews passing along the viewModel
            that.options.viewModel.setupCalls();

            //setViews
            that.setViews({
                "#expander": new Stage.Views.Toggle({ stageViewModel: that.options.viewModel }),
                "#tracInfo": new Stage.Views.TracInfo({ stageViewModel: that.options.viewModel }),
                "#stageInfo": new Stageinfo.View({ stageViewModel: that.options.viewModel }),
                "#folderActions": new FolderActions.Views.Layout({ stageViewModel: that.options.viewModel }),
                "#relatedObjects": new Relatedobjects.View({ stageViewModel: that.options.viewModel }),
                "#docViewerOutlet": new Docviewer.Views.Layout({
                    documentId: that.options.viewModel.documentId,
                    stageViewModel: that.options.viewModel
                }),
                "#docViewer2Outlet": that.dualPaneDoc2,
                "#rightSideActionHandler": new Rightsideactionhandler.View()
            });

            if (that.options.viewModel.stageConfig.get("workflowInfoConfig").get("enabled")) {
                that.setView("#workflowInfo", new WorkflowInfo.View({ options: that.options }));
            }

            app.context.util.renderSubViews(that);
        });
      },
      setupListeners: function() {
        var self = this;
        var viewModel = this.options.viewModel;

        this.listenTo(this.dualPaneDoc2, "docviewer:closeDoc2", this.hideDoc2);

        this.listenTo(app, "stage:resizePanes", viewModel.paneManipulation);
        //append some listeners here
        this.listenTo(app, 'action:object-modified', Stage.eventHandlers._onObjectModified);
        this.listenTo(app, 'action:object-deleted', Stage.eventHandlers._onObjectDeleted);

        /***Functions to control stage panes***/
        /** 
         * Will toggle the pane if no argument is provided.
         * Else true=show false=hide 
         */
        this.listenTo(app, "toggleLeftBar", this.toggleLeftBar, this);
        
        /** 
         * Will toggle the pane if no argument is provided.
         * Else true=show false=hide 
         */
        this.listenTo(app, "toggleDualPane", function(show){
            if (show) {
                app.trigger("stage.refresh.showPane1", true);
                app.trigger("stage.refresh.showPane2", true);
                app.trigger("stage.refresh.showPane3", false);
                //if the window is a large screen then hide the left bar
                if(window.innerWidth > 991){
                    app.trigger("toggleLeftBar", false);
                }
            } else {
                app.trigger("stage.refresh.showPane1", true);
                app.trigger("stage.refresh.showPane2", false);
                app.trigger("stage.refresh.showPane3", false);
                app.trigger("toggleLeftBar", true);
            }
        });
        
        this.listenTo(app, "toggleRSAH", this.toggleRSAH);

        this.listenTo(app, "newRSAHSubviewInserted", function(options){
            self.rsahOptions = options;
        });
        
        /**Controls the Left Bar when on a smaller screen**/
        this.listenTo(app, "toggleStageInfo", function(){
            if($("#stageInfo").is(":visible")){
                $('#stageInfo').hide();
                //reset the margin so all of the leftBar is even
                $("#objects-actions-sidenav").css("margin-top", "0px");
                //make the trac info icon the correct one
                $('#tracExpandIcon').switchClass("glyphicon-chevron-up", "glyphicon-chevron-down");
            }
            else{
                $('#stageInfo').show();
                if(window.innerWidth < 992 && window.innerWidth > 767){
                    $("#objects-actions-sidenav").css("margin-top", "0px");
                }
                $('#tracExpandIcon').switchClass("glyphicon-chevron-down", "glyphicon-chevron-up");
            }
        });
        
        /*****END STAGE PANE CONTROL FUNCTIONS************/
        
        //listener for updating the stage's containerId
        this.listenTo(app, "stage.refresh.containerId", function(containerId) {
            if(containerId === true){
                viewModel.containerId.valueHasMutated();
            }
            else if (viewModel.containerId() === containerId) {
                viewModel.containerId.valueHasMutated();
            } else {
                viewModel.containerId(containerId);
                Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId(), {replace: true} );
                app.trigger('folder.actions.refresh');
            }
        });
        
        //listener for updating the stage's documentId
        this.listenTo(app, "stage.refresh.documentId", this.refreshDocumentId);

        this.listenTo(app.openAnnotate, "objectIdUpdated", this.refreshDocumentId);
        
        //listener for updating the stage's documentId and containerId
        this.listenTo(app, "stage.refresh.bothIds", this.refreshBothIds);

        //listener for updating the stage's documentId2, used for dual pane mode
        this.listenTo(app, "stage.refresh.documentId2", this.refreshDualPane, this);

        //listener for updating the stage's showPane1 boolean
        //this boolean controls whether or not pane1 (the activeDocument pane) is hidden or shown
        this.listenTo(app, "stage.refresh.showPane1", this.showPane1, this);

        //listener for updating the stage's showPane2 boolean
        //this boolean controls whether or not pane2 (the staticDocument pane) is hidden or shown
        //this is the dual view pane
        this.listenTo(app, "stage.refresh.showPane2", this.showPane2, this);

        //listener for updating the stage's showPane3 boolean
        //this boolean controls whether or not pane3 (the rightSideActionHandler pane) is
        //hidden or shown
        this.listenTo(app, "stage.refresh.showPane3", this.showPane3, this);

        //listener for hiding all panes used by the stage in the rightBar div
        this.listenTo(app, "stage.hideAllPanes", function() {
            $('#pane1').hide();
            $('#pane2').hide();
            $('#pane3').hide();
        });

        //listener for running run the computed method for showing panes based on
        //the pane observable booleans. we get the computed logic to run by claiming
        //an observable it pays attention to has mutated.
        this.listenTo(app, "stage.showPanes", function() {
            viewModel.showPane1.valueHasMutated();
        });

        this.listenTo(app, "stage.windowResizePanes", this.windowResizePanes, this);
      },

        refreshBothIds: function (containerId, documentId) {
            var viewModel = this.options.viewModel;
            if (containerId === true || viewModel.containerId() === containerId) {
                viewModel.containerId.valueHasMutated();
            } else {
                viewModel.containerId(containerId);
                Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId(), { replace: true });
                app.trigger('folder.actions.refresh');
            }

            if (documentId === true || viewModel.documentId() === documentId) {
                viewModel.documentId.valueHasMutated();
            } else {
                viewModel.documentId(documentId);
                if (documentId === undefined) {
                    // set the second dual pane to undefined as well
                    // this will ensure it's cleanup method is ran
                    viewModel.documentId2(documentId);
                    Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId(), { replace: true });
                    //Since we are setting the url to only the containerId, we should not be showing the first or second pane
                    viewModel.showPane2(false);
                    viewModel.showPane1(false);
                }
                else {
                    Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId() + "|" + viewModel.documentId(), { replace: true });
                }
            }
        },

        // handles the toggling of the right side action handler
        toggleRSAH: function (showRSAH, paneSize, directLaunchDualPane) {
            var viewModel = this.options.viewModel;
            var showPane1 = true;
            var showPane3 = true;
            var toggleLeftBar = true;
            // passing in undefined to cleanup our pane 2 document since we're hiding it
            viewModel.documentId2(undefined);
            if (showRSAH) {
                if (paneSize === "rightPane") {                    
                    var largeScreenMinWidth = 991;
                    if (window.innerWidth > largeScreenMinWidth) {
                        toggleLeftBar = false;
                    }
                } else {
                    // clean up pane 1
                    if (!directLaunchDualPane) {
                        // passing in undefined to clean up our pane 1 document since we're hiding that pane
                        viewModel.documentId(undefined);
                    }
                    showPane1 = false;
                }
            } else {
                if(!viewModel.showPane1()) {
                    // Pane 1 is hidden but we're about to show it; need to create the docviewer content view and update the url if we have a documentId
                    // valueHasMutated will trigger the docviewer showDocument method
                    if(viewModel.documentId()) {
                        Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId() + "|" + viewModel.documentId(), {replace: true} );
                    }
                    viewModel.documentId.valueHasMutated();
                }
                showPane3 = false;
            }

            app.trigger("stage.refresh.showPane1", showPane1);
            app.trigger("stage.refresh.showPane2", false); // Always hiding it.
            app.trigger("stage.refresh.showPane3", showPane3);
            app.trigger("toggleLeftBar", toggleLeftBar);
        },

        refreshDocumentId: function(documentId) {
            var viewModel = this.options.viewModel;
            if(documentId === true){
                viewModel.documentId.valueHasMutated();
            } else if (documentId === "") {
                viewModel.documentId(undefined);
            } else {
                // Signal that the pane is already showing so toggleRSAH doesn't trigger launchDocViewer again
                app.trigger("stage.refresh.showPane1", true);
                Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId() + "|" + documentId, {replace: true} );
                if(viewModel.documentId() === documentId) {
                    viewModel.documentId.valueHasMutated();
                } else {
                    viewModel.documentId(documentId);
                    UserPreferences.pushRecentObjects();
                }
            }
        },

      refreshDualPane: function(options) {
          var viewModel = this.options.viewModel;
          //if documentId = false or showPane1 = false
          if(!viewModel.documentId() || !viewModel.showPane1()) { 
              // trigger the pane 1 docviewer to show this document
              if(viewModel.documentId() === options.objectId) {
                  viewModel.documentId.valueHasMutated();
              } else {
                //make documentId = documentId2 so it will occupy pane 1 (left side)
                viewModel.documentId(options.objectId);
              }

              viewModel.showPane1(true); 
              Backbone.history.navigate("Stage/" + viewModel.trac() + "/" + viewModel.containerId() + "|" + viewModel.documentId(), {replace: true} );
          } else if (viewModel.documentId2() === options.objectId) { //if documentId2 exists
              viewModel.documentId2.valueHasMutated(); 
          } else { 
              viewModel.documentId2(options.objectId); 
              this.context = options.context;
          } 
      }, 
      windowResizePanes: function() {
          if($(".myGrid").length > 0) {
            app.trigger("tableview:columnHeaderResize");
         }
      },
      toggleLeftBar: function(show) {
        if(show === undefined){
            var currentClass = $('#leftBar').attr("class");
            if(currentClass === 'col-md-3 col-sm-12 col-xs-12 span-hide-leftbar'){
                $('#leftBar').removeClass("span-hide-leftbar", function() {
                    $(this).children().show();
                });
                $('#leftBar').show();
                this.stageInfoSmallScreen();
                $('#rightBar').removeClass("span-wide-rightbar");
                $('#expander span').switchClass("glyphicon-chevron-right", "glyphicon-chevron-left");
            }else{
                $('#leftBar').addClass("span-hide-leftbar").children().hide();
                $('#rightBar').addClass("span-wide-rightbar");
                $('#expander span').switchClass("glyphicon-chevron-left", "glyphicon-chevron-right");
                $('#leftBar').hide();
            }

            

        }else{
            if(show){
                $('#leftBar').removeClass("span-hide-leftbar", function() {
                    $(this).children().show();
                });
                $('#leftBar').show();
                this.stageInfoSmallScreen();
                $('#rightBar').removeClass("span-wide-rightbar");
                $('#expander span').switchClass("glyphicon-chevron-right", "glyphicon-chevron-left");
            }else{
                $('#leftBar').addClass("span-hide-leftbar").children().hide();
                $('#leftBar').hide();
                $('#rightBar').addClass("span-wide-rightbar");
                $('#expander span').switchClass("glyphicon-chevron-left", "glyphicon-chevron-right");
            }
        }

        app.trigger("tableview:columnHeaderResize");
    },
    stageInfoSmallScreen : function() {
        //if the window is a small screen then hide the leftBar dropdown content which is now on the top
        if(window.innerWidth < 992){
            $("#stageInfo").hide();
            //make the trac info icon the correct one
            $('#tracExpandIcon').removeClass("glyphicon-chevron-up");
            $('#tracExpandIcon').addClass("glyphicon-chevron-down");
            //reset the margin so all of the leftBar is even
            $("#objects-actions-sidenav").css("margin-top", "0px");
        }
    },
    showPane1: function(show) {
        if (this.options.viewModel.showPane1() === show) {
            this.options.viewModel.showPane1.valueHasMutated();
        } else {
            this.options.viewModel.showPane1(show);
        }
    },
    showPane2: function(show) {
        if (this.options.viewModel.showPane2() === show) {
            this.options.viewModel.showPane2.valueHasMutated();
        } else {
            this.options.viewModel.showPane2(show);
            app.trigger("stage:pane2Toggled");
        }
    },
    showPane3: function(show){
        if (this.options.viewModel.showPane3() === show) {
            this.options.viewModel.showPane3.valueHasMutated();
        } else {
            this.options.viewModel.showPane3(show);
            app.trigger("stage:pane3Toggled");
        }
    },
    hideDoc2 : function() {
        // null checks are good
        // We are making sure that our most recent right side action is what launched the second doc. This check prevents modals and folder items from launching the action
        if (this.rsahOptions && this.rsahOptions.rsahAction && this.context === this.rsahOptions.rsahAction.get("name")){
            var config = this.rsahOptions.rsahConfig;
            app[config.get("handler")].trigger("show", {
            action: this.rsahOptions.rsahAction, 
            config: config,
            oldView: this.rsahOptions.rsahView,
            reuseView: true 
            });
        } else {
            app.trigger("stage.refresh.showPane2", false);
            app.trigger("toggleDualPane");
        }
    },
    expanderClick : function() {
        app.trigger("closeTour");
        app.trigger("toggleLeftBar");
    },
    showStageInfo : function() {
        app.trigger("toggleStageInfo");
    },
    afterRender: function() {
        var self = this;
        // Accordion Icons
        this.options.viewModel.relatedIcon = ko.observable("glyphicon glyphicon-chevron-up");
        this.options.viewModel.actionIcon = ko.observable("glyphicon glyphicon-chevron-down");
        this.options.viewModel.toggleRelatedIcon = function() {
            if (self.options.viewModel.relatedIcon() === "glyphicon glyphicon-chevron-up") {
                self.options.viewModel.relatedIcon("glyphicon glyphicon-chevron-down");
            } else {
                self.options.viewModel.relatedIcon("glyphicon glyphicon-chevron-up");
            }
        };
        this.options.viewModel.toggleActionIcon = function() {
            if (self.options.viewModel.actionIcon() === "glyphicon glyphicon-chevron-up") {
                self.options.viewModel.actionIcon("glyphicon glyphicon-chevron-down");
            } else {
                self.options.viewModel.actionIcon("glyphicon glyphicon-chevron-up");
            }
        };

        if(this.options.message && this.options.message !== null && this.options.message !== '') {
            app.trigger("alert:info", { header : 'Alert', message : this.options.message, isConfirmation : true });

        }

        if(this.hideLeftBar) {
          // call toggleLeftBar with false so that the leftBar collapses
          this.toggleLeftBar(false);

          // only want to hide left bar on initial render not for subsequent render calls so set to false
          this.hideLeftBar = false;
        }
        //if the window is loaded in a small screen then hide the leftBar dropdown content which is now on the top
        if(window.innerWidth < 992){
            if($("#stageInfo").is(":visible")){
                $("#stageInfo").hide();
            }
        }

        this.$('[data-toggle="tooltip"]').tooltip({
       'placement': 'bottom'});

        //override hook
        this.postRender();
    },
    postRender: function(){
        //hotspot function for post render actions taken by custom stages
    }
});
    
    /**
    * This tiny view is small piece to add a header with the current trac.
    */
    Stage.Views.TracInfo = Backbone.Layout.extend({
      template: function(){
          return "<div class=\"tracName\" data-bind='text: label'></div><span class=\"pull-right\"><span id=\"tracExpandIcon\" class=\"glyphicon glyphicon-chevron-down\"></span></span>";
      },
      initialize: function(){

          this.viewModel = {
              label: ko.computed(function() {
                  var tracLabel = this.options.stageViewModel.stageConfig.get("label");
                  var tracDisplayName = tracLabel;
                  if(!tracLabel) {
                      tracLabel = this.options.stageViewModel.trac();
                      
                      app.context.configService.getTracConfigs(function(tracConfigs) {
                        var tracs = tracConfigs.models;
                        // finds the trac currently displayed 
                        var currentTracConfig = _.filter(tracs, function(trac){
                          return trac.get("name") === tracLabel;
                        });
                        
                        if (currentTracConfig[0]){
                          tracDisplayName = currentTracConfig[0].get("displayName");
                  }
                      });
                  }
                  return tracDisplayName;
              }, this)
          };
      }, 
      afterRender : function(){
          
          if(this.options.stageViewModel.stageConfig.get('docViewerConfig').get("noleftpane") === "true"){
              $("#expander").hide();
              $("#leftBar").remove();
              $("#rightBar").removeClass("col-md-9");
              $("#rightBar").addClass("col-md-12");
          }
          kb.applyBindings(this.viewModel, this.$el[0] );

          //this is setting the size of the left
          var offset = this.offset = $("#leftBar").offset();
          if(this.offset === undefined){
              this.offset = {top: 60};
          }
          // if the license expiring soon banner is showing - we need 30 more px of header space
          if (app.licenseInfo && app.licenseInfo.showLicenseError) {
              this.offset.top = this.offset.top + 30;
          }
          if(window.innerWidth > 991){
              $("#leftBar").height($(window).height() - this.offset.top);
          }
          else {
              $("#leftBar").css("height", "auto");
          } 

          $(window).resize(function() {
             setTimeout(function(){ 
                 app.trigger("stage.windowResizePanes");
             }, 200);
             // After we're resized the panes, we need to make sure that the leftBar is the same height as the rightBar
             // so the window doesnt display the scrollbar.
             //this should only happen for the large view
             if(window.innerWidth > 991){
                  $("#leftBar").height($(window).height() - offset.top);
             }
             else {
                  $("#leftBar").css("height", "auto");
             }
          });
          this.postRender();
      },
      postRender: function(){
          
          //hotspot function for post render actions taken by custom stages
      }
    });

    /**
    * This small view enables the toggling of panes and sidebars
    */
    Stage.Views.Toggle = Backbone.Layout.extend({
      template: function(){
          return "<span data-bind='click: toggleLeftBar' class='glyphicon glyphicon-chevron-left'></i>";
      } 
    });

    // Return the module for AMD compliance.
    return Stage;
});