define([
	'app'
], function(app){

	var FolderActionsEventManager = _.extend({}, Backbone.Events);
    
    return FolderActionsEventManager;
});
