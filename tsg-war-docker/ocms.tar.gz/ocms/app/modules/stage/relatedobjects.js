define([
	"app",
	"foldertree"
],
function(app, FolderTree) {
	'use strict';
	
	// Create a new module.
	var RelatedObjects = app.module();

	// main view model 
	RelatedObjects.RelatedObjectsViewModel = function(config, view) {
		var self = this;

		// array of configured relations
		self.relationViewModels = ko.observableArray();

		// whether to show the related objects panel 
		self.showRelatedObjectsPanel = ko.observable(false);

		// this is an observable to hide / show the related objects sections
		self.showRelatedObjectsSections = ko.observable(false);

		// toggles the icon for the main related object accordion
		self.expandIcon = ko.observable("glyphicon glyphicon-chevron-up");
		self.toggleExpandIcon = function () {
			if(self.expandIcon() === "glyphicon glyphicon-chevron-up") {
				self.expandIcon("glyphicon glyphicon-chevron-down");
			} else {
				self.expandIcon("glyphicon glyphicon-chevron-up");
			}
		};

		// these are maps of the different configured relationships to their index in the config, for convenience
		// put on viewmodel for unit testing purposes
		var _containerRelations = self._containerRelations = {};
		var _docRelations = self._docRelations = {};
		
		// resets our relations by requerying all relations
		self.reset = function() {
			var atLeastOneRelatedObjectToShow = false;
			var defs = [];

			// our doc relations
			_.each(_docRelations, function(docRelationVM) {
				defs.push(docRelationVM.queryRelated().done(function(result){
					docRelationVM.reValidate();
					if(result && result.length > 0) {
						atLeastOneRelatedObjectToShow = true;
					}
				}));
			});
			// our container relations
			_.each(_containerRelations, function(containerRelationVM) {
				defs.push(containerRelationVM.queryRelated().done(function(result){
					containerRelationVM.reValidate();
					if(result && result.length > 0) {
						atLeastOneRelatedObjectToShow = true;
					}
				}));
			});

			// wait for all fetches to be done so we can see if we can hide the panel (not at least one relation to show)
			// or if we need to show (there is at least one relation to show)
			$.when.apply(null, defs).done(function () {
				if(atLeastOneRelatedObjectToShow) {
					self.showRelatedObjectsPanel(true);
				}
			}, self);
		};

		// set up the initial relation view models
		self.initialize = function() {
			// resolvedRelatedObjecstSections is the number of relationConfigs that have finished being resolved
			// relatedObjectsSectionsToResolve is the total number of relationConfigs
			var resolvedRelatedObjectsSections = 0, relatedObjectsSectionsToResolve = config.models.length;
			app.context.configService.getAdminOTC(function(OTC){
				// check if any configured relation has hide empty relations configured to false
				// need to show related objects panel if someone has configured not to hide empty relations
				var atLeastOneRelationAlwaysVisible = _.some(config.models, function(relationConfig) {
					return relationConfig.get("optionsHideEmptyRelations") && relationConfig.get("optionsHideEmptyRelations") !== "true";
				});
				self.showRelatedObjectsPanel(atLeastOneRelationAlwaysVisible);

				// create a relation view model for each relation configured from the admin
				$.each(config.models, function(index, relationConfig) {
					// create the relation view model
					var relationVM = new FolderTree.ViewModel(relationConfig, OTC);
					
					// the type of this relation (whether its dependent on the current document or folder in the stage)
					var criteria = relationConfig.get("criteria");

					// cache this model in the right map so we only have to refresh the appropriate relations when the 
					// current document or folder in the stage changes
					if(criteria[0].type === "activeDocument") {
						_docRelations[index] = relationVM;
					} else {
						_containerRelations[index] = relationVM;
					}

					relationVM.label = window.localize(relationVM.label);
						
					// add the view model to the sub view models
					self.relationViewModels.push(relationVM);

					// we want to do an initial fetch on the relation's query if they want the default to be open or if they choose
					// to hide empty relations because how else would we know if it's empty?
					if(relationConfig.get("optionsDefaultOpen") && relationConfig.get("optionsDefaultOpen") === "true" ||
						relationConfig.get("optionsHideEmptyRelations") && relationConfig.get("optionsHideEmptyRelations") === "true") {
						relationVM.queryRelated().always(function() {
							resolvedRelatedObjectsSections++;
							// if all the relatedObjectsSections have finished resolving we want to show the related objects part of the stage
							// otherwise we could have a weird visual effect where relations disappear after they've been added
							if(resolvedRelatedObjectsSections === relatedObjectsSectionsToResolve) {
								self.showRelatedObjectsSections(true);
							}
							
							// does relation have any related objects?
							if(relationVM && relationVM.query.length > 0) {
								self.showRelatedObjectsPanel(true);
							}
						});
						relationVM.reValidate = function() {
							// does relation have any related objects?
							if(relationVM && relationVM.query.length > 0) {
								self.showRelatedObjectsPanel(true);
							}
							if(atLeastOneRelationAlwaysVisible) {
								self.showRelatedObjectsPanel(true);
							} else {
								self.showRelatedObjectsPanel(false);
							}
						};
					} else { // didn't want to query when the stage was loaded
						resolvedRelatedObjectsSections++;
						// if all the relatedObjectsSections have finished resolving we want to show the related objects part of the stage
						// otherwise we could have a weird visual effect where relations disappear after they've been added
						if(resolvedRelatedObjectsSections === relatedObjectsSectionsToResolve) {
							self.showRelatedObjectsSections(true);
						}
					}
				});
			});
		};
		
		// initialize our relations when we've confirmed we have READ permissions
		view.options.stageViewModel.hasPermissions.done(function(hasPermissions) {
			if(hasPermissions) {
				self.initialize();
			}
		});

	};

	RelatedObjects.View = Backbone.Layout.extend({
		template: "stage/relatedobjects",
		initialize: function() {
			var config = this.options.stageViewModel.stageConfig.get("relatedObjectsConfig");
				
			// add the relations
			this.viewModel = new RelatedObjects.RelatedObjectsViewModel(config.get("relationTypes"), this);

			// tracks trees without related objects
			this.totalNumEmptyHiddenRelatedObjects = 0;

			// collapse the Related Object section for smaller screens
			this.viewModel.notCollapsed = ko.observable(true);
			if(window.innerWidth < 992){
				this.viewModel.notCollapsed = ko.observable(false);
				//make the related objects expand icon the correct one
                this.viewModel.expandIcon("glyphicon glyphicon-chevron-down");
			}
			
			this._startListening();
		},
		_startListening: function() {
			// listens for a container to change in order to refresh the view
			this.listenTo(app.context.container, 'sync', function() {
				this.viewModel.reset('container');
			});

			// listen for bulk upload to be done uploading docs
			this.listenTo(app, 'stage.container.childrenChanged', function() {
				this.viewModel.reset('container');
			});

			// listens for a document to change in order to refresh the view
			this.listenTo(app.context.document, 'sync', function() {
				this.viewModel.reset('document');
			});

			// listens for the number of relatedObject children to show or hide the panel
			this.listenTo(app, 'noRelatedObjects', function() {
				this.totalNumEmptyHiddenRelatedObjects += 1;
				// compares the number of trees that have signaled they contain no related objects to the number of trees in the view model
				if (this.totalNumEmptyHiddenRelatedObjects === this.viewModel.relationViewModels().length) {
					$("#relatedObjects").hide();
				}
			});

			//when the window is resized then reformat the leftBar
			this.listenTo(app, "stage.windowResizePanes", function() {
                //if on a large screen then show the trac info
                if(window.innerWidth > 991) {
                	this.viewModel.notCollapsed(true);
                	//ensure that the pane is visible and overrides the bootstrap height of 0
                	$('#collapseRelated').height('auto');
                	//make the folder actions expand icon the correct one
                	this.viewModel.expandIcon("glyphicon glyphicon-chevron-up");
                }
                //if on a small screen then collapse the leftBar
                else {
                	//collapse the related objects section
					this.viewModel.notCollapsed(false);
			     	//make the related objects expand icon the correct one
                	this.viewModel.expandIcon("glyphicon glyphicon-chevron-down");
                	//if the folder action is open in the medium or small screen and the window is resized to a medium or small 
                	//screen then this ensures that the pane will remove the 'in' class to collapse the pane
                	$("#collapseRelated").removeClass("in");
                }
	    	});
		},
		cleanup: function() {
			this.stopListening();
		},
		afterRender: function() {
			ko.applyBindings(this.viewModel, this.$el[0]);
		}
	});
	
	return RelatedObjects;
});