// ContentViewer module
define([
    // Application.
    "app",
    "modules/tsg",
    "oc",
    "modules/common/hpiconstants",
    "modules/common/spinner",
    "setrendition",
    "modules/services/logstashservice",
    "modules/stage/documentViewers/pdfViewer",
    "modules/stage/documentViewers/videoViewer",
    "modules/stage/documentViewers/legacyPdfViewer",
    "modules/stage/documentViewers/imageViewer",
    "modules/stage/documentViewers/htmlViewer",
    "modules/stage/documentViewers/downloadViewer",
    "modules/stage/documentViewers/OAViewer",
    "modules/stage/documentViewers/oaVideoAnnotationViewer",
    "modules/stage/documentViewers/xmlViewer"
],
// Map dependencies from above array.
function(app, TSG, OC, HPIConstants, HPISpinner, SetRendition, LogstashService,
    PDFViewer, VideoViewer, LegacyPDFViewer, ImageViewer, HTMLViewer, DownloadViewer, OAViewer, 
    OAVideoAnnotationViewer, XMLViewer) {
    "use strict";

    // Create a new module.
    var ContentViewer = app.module();
    
    // Container for document viewers
    ContentViewer.Views.Layout = Backbone.Layout.extend({
        template: "stage/contentviewer",
        className: "fullHeight",
        //tagName: null,
        initialize: function(options) {
            // used to calculate the load duration in fireViewDocumentLogstashEvent
            this.viewDocumentStartTime = Date.now();
            this.docName = options.docName;
            this.documentId = options.documentId;
            this.moduleId = options.moduleId;
            this.isNewTabDocViewer = options.isNewTabDocViewer == true;
            this.viewModel = options.viewModel;
            this.config = options.config;
            this.checkedForRendition = false;
            this.availableViewers = [];

            this.availableViewers = this.getConfiguredViewersByPriority();
            this.getMimetype();
        },
        setViewerIfConfigured: function (viewerObj, viewerName) {
            if ((this.config.get(viewerName) === "true")) {
                this.availableViewers.push(viewerObj);
            }
        },
        getConfiguredViewersByPriority: function() {
            var ViewerMap = {};
            ViewerMap[HPIConstants.ContentViewer.PDFViewer] = PDFViewer;
            ViewerMap[HPIConstants.ContentViewer.VideoViewer] = VideoViewer;
            ViewerMap[HPIConstants.ContentViewer.ImageViewer] = ImageViewer;
            ViewerMap[HPIConstants.ContentViewer.HTMLViewer] = HTMLViewer;
            ViewerMap[HPIConstants.ContentViewer.LegacyViewer] = LegacyPDFViewer;
            ViewerMap[HPIConstants.ContentViewer.OAViewer] = OAViewer;
            ViewerMap[HPIConstants.ContentViewer.VAViewer] = OAVideoAnnotationViewer;
            ViewerMap[HPIConstants.ContentViewer.XMLViewer] = XMLViewer;
            _.each(ViewerMap, this.setViewerIfConfigured, this);

            // sorting by the priority attribute on each of the available viewers
            return _.sortBy(this.availableViewers, 'priority');
        },
        handleMimetypeFailed: function() {
            this.mimetypeFailed = true;
            this.render();
        },
        getViewerByObjectType: function(ocoObjectType) {
            return _.find(this.availableViewers, function(viewer) {
                return _.contains(viewer.acceptedObjectTypes, ocoObjectType);
            });
        },
        findViewerByMimetype: function(documentContentInfo) {
            var self = this;
            var deferred = $.Deferred();
            this.currentMimetypes = documentContentInfo.mimeTypes;
            var selectedViewer;

            if(_.contains(documentContentInfo.mimeTypes, HPIConstants.ContentViewer.ImageMimetype)) {
                selectedViewer = _.find(this.availableViewers, function(viewer) {
                    if (_.contains(viewer.mimeTypes, HPIConstants.ContentViewer.ImageMimetype)) {
                        self.mimeType = HPIConstants.ContentViewer.ImageMimetype;
                        self.documentSize = documentContentInfo.contentSizes[_.indexOf(documentContentInfo.mimeTypes, HPIConstants.ContentViewer.ImageMimetype)];
                        deferred.resolveWith(self);
                        return viewer;
                    }
                });
            } else {
                selectedViewer = _.find(this.availableViewers, function(viewer) {
                    // Find all viewers the mimetype(s) have in common
                    var mimetypes = _.intersection(viewer.mimeTypes, documentContentInfo.mimeTypes);
                    if (mimetypes.length > 0) {
                        // Select the first because we set the order based on priority
                        self.mimeType = mimetypes[0];
                        self.documentSize = documentContentInfo.contentSizes[_.indexOf(documentContentInfo.mimeTypes, mimetypes[0])];
                        deferred.resolveWith(self);
                        return viewer;
                    }
                });
            }

            // Try to match viewer by object type if we couldn't match by mimetype
            if(!selectedViewer) {
                this.ocObject = new OC.OpenContentObject({
                    'objectId': this.documentId
                });
                this.ocObject.fetch().done(function(docOcoData){
                    // When this network call finishes, we need to ensure
                    // the viewer is set on the view before resolving 
                    self.viewer = self.getViewerByObjectType(docOcoData.objectType);
                    selectedViewer = self.viewer;
                    deferred.resolveWith(self);
                });
            }

            this.viewer = selectedViewer;
            return deferred;
        },
        checkForRendition: function() {
            // if we don't have a viewer and haven't checked for renditioning
            if (!this.viewer && !this.checkedForRendition) {
                this.renditionFoundDeferred = $.Deferred();
                // once we have a rendition, start process of finding and displaying a viewer again
                this.renditionFoundDeferred.done(this.getMimetype);

                if (this.config.get('viewTimeRendition') === 'true') {
                    // kick off the document's rendition
                    SetRendition.Service.execute({
                        parameters: {
                            asyncRendition: true,
                            objectId: this.documentId,
                            mimeType: this.currentMimetypes[0]
                        },
                        context: this,
                        successFunction: this.checkRenditioningStatus
                    });
                } else {
                    this.checkRenditioningStatus();
                }
            } else {
                this.createAndRenderContentViewer();
            }
        },
        determineViewer: function(objectContentInfo) {
            this.findViewerByMimetype(objectContentInfo[0]).done(this.checkForRendition);
        },
        getMimetype: function() {
            TSG.services.ajaxService.getContentInfo({
                isNotGlobal: true,
                objectId: this.documentId,
                successCallback: this.determineViewer,
                errorCallback: this.handleMimetypeFailed,
                context: this
            });
        },
        createAndRenderContentViewer: function() {
            // if no mimetype is found, default to download viewer
            if(!this.viewer) {
                this.viewer = DownloadViewer;
            }

            // Initialize the specific type of viewer that this file gets matched with
            this.displayDocument = new this.viewer.Views.Viewer({
                documentId: this.documentId,
                moduleId: this.moduleId,
                mimeType: this.mimeType,
                docName: this.docName,
                isNewTabDocViewer: this.isNewTabDocViewer,
                hideOpenFileBtn: this.config.get("hideOpenFileBtn"),
                hideDownloadBtn: this.config.get("hideDownloadBtn"),
                hidePrintBtn: this.config.get("hidePrintBtn"),
                hideBookmarkBtn: this.config.get("hideBookmarkBtn"),
                hideDocumentPropertiesBtn: this.config.get("hideDocumentPropertiesBtn"),
                oaviewerMode: this.config.get("oaviewerMode"),
                openAnnotateSearchValue: window.localStorage.getItem('openAnnotateSearchValue') || ""
            });

            this.setView("#docviewer-content", this.displayDocument).render();
            this.fireViewDocumentLogstashEvent();
        },
        checkRenditioningStatus: function() {
            this.checkedForRendition = true;
            app.log.debug("Checking if doc is renditioning");
            //TODO move to services
            $.ajax({
                context: this,
                url: app.serviceUrlRoot + "/isRenditioning",
                global: false,
                data: {
                    objectId: this.documentId
                },
                success: this.isRenditioningSuccessCallback,
                error: this.isRenditioningErrorCallback
            });
        },
        isRenditioningSuccessCallback: function(isRenditioning) {
            if (isRenditioning.value) {
                var renditioningCheckPeriod = this.config.get("renditioningCheckPeriod");
                app.log.debug("Content still renditioning; checking again in " + renditioningCheckPeriod + "ms");
                if (!this.isRenditioning) {
                    this.isRenditioning = true;
                    // show our renditioning placeholder text and spinner
                    this.render();
                }
                
                _.delay(_.bind(this.checkRenditioningStatus, this), renditioningCheckPeriod);
            } else {
                app.log.debug("Done renditioning; checking for potential viewers");
                this.isRenditioning = false;
                // resolving our deferred which will call getMimetype again, and then select and render the proper viewer
                this.renditionFoundDeferred.resolveWith(this);

                // Will refresh action bar if in stage mode but not in new tab
                if (this.viewModel && !this.isNewTabDocViewer) {
                    
                    // Make sure that the doc being renditioned is the reason the redaction button isn't showing up.
                    this.viewModel.filterActionFactory(this.documentId);
                }
            }
        },
        isRenditioningErrorCallback: function() {
            // our call failed, just show the DownloadViewer
            this.isRenditioning = false;
            this.createAndRenderContentViewer();
        },
        fireViewDocumentLogstashEvent: function() {
            var viewDocumentCompletionTime = Date.now();
            LogstashService.sendMetrics(
                new LogstashService.PerformanceLog({
                    'eventTitle': HPIConstants.Logging.Events.ViewDocument,
                    'events': {
                        'eventDuration': viewDocumentCompletionTime - this.viewDocumentStartTime,
                        'documentSize': this.documentSize,
                        'mimeType': this.mimeType
                    },
                    'objectId': this.documentId
                })
            );
        },
        serialize: function() {
            return {
                cid: this.cid,
                isRenditioning: this.isRenditioning,
                mimetypeFailed: this.mimetypeFailed
            };
        },
        afterRender: function() {
            if (this.isRenditioning) {
                // find our DOM element to attach our loading spinner to
                var spinElem = this.$("#renditioningSpinner-" + this.cid)[0];

                // create our loading spinner, make it a bit bigger than normal
                this.spinner = HPISpinner.createSpinner({
                    lines: 13,
                    length: 5,
                    width: 3,
                    radius: 8
                }, spinElem);
            } else {
                // destroy the loading spinner since we're done loading the query
                HPISpinner.destroySpinner(this.spinner);
            }
        },
        cleanup: function() {
            if(this.displayDocument) {
                this.displayDocument.remove();
            }
        }
    });

    return ContentViewer;
});