// Stageinfo module
define([
    // Application.
    "app",
    "knockout",
    "knockback",
    "module",
    "modules/stage/searchresulttraversal"
],

// Map dependencies from above array.
function(app, ko, kb, module, SearchResultTraversal) {

    // Create a new module.
    var Stageinfo = app.module();

    function currentFolderOrDocProps(visibleProps, objectType, self, properties, array) {
        var oldStageInfoConfig = _.findWhere(visibleProps, {objectType : objectType}),
            newStageInfoConfig = _.find(visibleProps, function(model) {
                return model.ocName === objectType;});

        var allowedProperties;
       
        if(!oldStageInfoConfig && !newStageInfoConfig){
            app.log.debug("StageInfo does not know of type: " + objectType);
            allowedProperties = ["objectName", "modifiedDate", "createdDate"];
        } else if (oldStageInfoConfig){
            allowedProperties = oldStageInfoConfig.attrs;
        } else {
            allowedProperties = _.pluck(newStageInfoConfig.configuredAttrs, "ocName");
        }

        if(self.typeConfig().get("isContainer") === "false"){
            self.enableDocView(true);
        }

        _.each(properties, function(value, key){
            var label;
            if( _.indexOf(allowedProperties, key) !== -1){
            //we want to ensure that the attrs are there, and the one that we
            //need is configured
                if(!self.typeConfig().get("attrs") || 
                    !self.typeConfig().get("attrs").findWhere({ocName : key})) {
                    label = key;
                }else{
                    label = self.typeConfig().get("attrs").findWhere({ocName : key}).get('label');
                }
            array.push({"name": window.localize(label), "value": value, "key" : key});   
            }
        });
        array = _.sortBy(array, function(obj) {
            return _.indexOf(allowedProperties, obj.key);
        }); 
        return array;
    }

    /*Stage info is a box for displaying property value pairs
     * @param props array of key/value pairs
     */
    Stageinfo.StageInfoViewModel = function(config){

        var self = this;
        var title = config.label || config.get("label");
        self.title = ko.observable(title);
        self.properties = ko.observable([]);
        self.objectType = ko.observable();
        self.enableDocView = ko.observable(false);
        self.showLinkText = app.context.configName() === "wizard" ? true : false;
        self.linkText = module.config().linkText || "View Document";
        self.typeConfig = ko.observable();
        self.linkClick = function() {
            // refresh on the "Form ID" which is the current Container ID
            app.trigger("stage.refresh.documentId", app.context.container.get("objectId"));
        };
        
        self.filteredProps = ko.computed(function(){
            //filter out props that aren't relevant
            var array = [];
            var objectType = self.objectType();
            var properties = self.properties();
            var webserviceresult = []; //array to be passed back to knockout

            //once the object is fetched and the otc is fetched go!
            var visibleProps = config.visibleProperties || config.get("visibleProperties");
            //check if webservice config exists
            var isWebPropsConfigured = $(config).attr("webProperties") || $(config.attributes).attr("webProperties");
            if (isWebPropsConfigured){
                var webProps = config.webProperties || config.get("webProperties");
                var isWebService = webProps.objectType;
                //contains webservice object when configured to webservice, else empty
                if (isWebService){
                    //full url to specified endpoint
                    var webserviceurl = webProps.properties.webServiceUrl; 

                    $.ajax({
                        url: app.serviceUrlRoot + "/content/propertiesExternal",
                        type: "GET",
                        data: {webServiceUrl: webserviceurl},
                        async: false,
                        success: function(result){
                            var jsonResult = JSON.parse(result);
                            _.each(jsonResult, function(value, key) {
                                array.push(
                                    {
                                        name: window.localize(key), 
                                        value:value
                                    }
                                    );
                            });
                            webserviceresult = array;
                        }
                    }); 
                    return webserviceresult;    //json returned from endpoint
                }
            
                //folder or document stageInfo configured
                else if(objectType && self.typeConfig()){
                    array = currentFolderOrDocProps(visibleProps, objectType, self, properties, array);
                    return array;               
                }
            }
            //web services is not configured. get folder or document stageInfo
            else if(objectType && self.typeConfig()){
                array = currentFolderOrDocProps(visibleProps, objectType, self, properties, array);
                return array;
            }
        });
    };
    // Default View.
    Stageinfo.View = Backbone.Layout.extend({
        template: "stage/stageinfo",
        initialize: function() {
            var config;
            this.oco;
            var that = this;
            var stageViewModel = this.options.stageViewModel;
            
            config = stageViewModel.stageConfig.get("stageInfoConfig");

            this.visibleProperties = config.get('visibleProperties');

            var observable = config.observable || config.get("observable");

            if(observable === undefined){
                app.log.debug(window.localize("modules.stage.stageInfo.stageInfoSetup"));
            }else if (observable === "container" ){
                this.oco = stageViewModel.bbContainer;
            }else{
                if(observable !== "webservice"){
                    config.webProperties = {};
                }
                this.oco = stageViewModel.bbDocument;
            }

            that.viewModel = new Stageinfo.StageInfoViewModel(config);
    
            if(this.oco.get("objectType")){
                this.oco.getFormattedProperties().done(function(formattedProps){
                    that.viewModel.properties( formattedProps );
                    that.viewModel.objectType(that.oco.get("objectType"));

                    app.context.configService.getAdminTypeConfig(that.oco.get("objectType"), function(typeConfig){
                        that.viewModel.typeConfig(typeConfig);
                    });
                });
            }

            this.setupListeners();
        },
        setupListeners: function() {
            var that = this;

            //broken out of initialization.
            //any time the oco changes, clone it and format the props to send to the vm.
            
            this.listenTo(this.oco, 'sync', function(){ 
                that.oco.getFormattedProperties().done(function(formattedProps){
                    if (!kb.wasReleased(that.viewModel))
                    {
                        that.viewModel.properties(formattedProps);

                        var otcDef = app.context.configService.getAdminTypeConfig(that.oco.get("objectType"), function(typeConfig){
                            that.viewModel.typeConfig(typeConfig);
                        });

                        otcDef.done(that.setFormattedTabTitle(that.visibleProperties));
                    }
                });
            });
        },
        setFormattedTabTitle: function(visibleProperties){
            var that = this;
            // pull in object Type
            that.viewModel.objectType(that.oco.get("objectType"));
            // get the current type obj off of the visible Properties array 
            var typeObj = _.findWhere(visibleProperties, {"objectType": that.viewModel.objectType()});
            // if the tabTitlePattern is null or undefined, skip this
            // and put the "OpenContent Management Suite" on the tab
            if(typeObj && !_.isEmpty(typeObj.tabTitlePattern)){
                // take the tab title being passed back and parse it for configured attrs (returned in array)
                that.configuredAttrs = app.context.util.parsePatternForAttributes(typeObj.tabTitlePattern);
                // parse the same pattern and split off the "$" so that we can compare attrs to configured attrs
                that.fullTextArray = typeObj.tabTitlePattern.split("$");
                that.finishedToken = "";
                // for each string segment in the pattern do this logic to check if configured attr
                _.each(that.fullTextArray, function(propertyName){
                    // check for the index of the attr in the configured attrs
                    var containsAttr = that.configuredAttrs.indexOf(propertyName);
                    // if that attr is in the configured attr array
                    if (containsAttr > -1){
                        // check if that property is populated; if not, do nothing
                        if(that.oco.get('properties')[propertyName]){
                            // if populated, find the type of the attr in the typeConfige
                            var propertyObj = that.viewModel.typeConfig().get('attrs').findWhere({ocName: propertyName});
                            if(propertyObj.get("dataType") === "date"){
                                // if that attr is a date, format that date then put it on the finished token
                                var unformattedDate = that.oco.get('properties')[propertyName];
                                app.context.dateService.getFormattedDate(unformattedDate).done(function(formattedDate) {
                                    that.finishedToken += formattedDate;
                                });
                                
                            } else{
                                // if not a date, put that property on the finished token
                                that.finishedToken += that.oco.get('properties')[propertyName];
                            }
                        }
                    } else {
                        // if attr is not configured, put the string on the end
                        that.finishedToken += propertyName;
                    }
                });
                //addition for tab information
                $("title").text(that.finishedToken);
            
            }
        },

        afterRender: function(){
            if(this.stageViewModel.stageConfig.get("searchResultTraversalConfig").get("enabled")){
                this.setView("#searchresulttraversal-outlet", new SearchResultTraversal.View()).render();
            }           
            
            kb.applyBindings(this.viewModel, this.$el[0] );
        }
    });

    // Return the module for AMD compliance.
    return Stageinfo;
});