// DocViewer module
define([
    // Application.
    "app",
    "knockout",
    "knockback",
    "modules/tsg",
    "modules/common/action",
    "modules/hpiadmin/stageconfig/docviewerconfig",
    "modules/stage/contentviewer",
    "modules/services/logstashservice",
    "modules/common/hpiconstants"
],
// Map dependencies from above array.
function(app, ko, kb, TSG, Action, DVC, ContentViewer, LogstashService, HPIConstants) {
    "use strict";

    // Create a new module.
    var DocViewer = app.module();
    DocViewer.resizeHeaderThrottleTime = 700;
    DocViewer.vent = _.extend({}, Backbone.Events);

    /*Stage info is a box for displaying property value pairs
     * @param props array of key/value pairs
     */
    DocViewer.DocViewModel = function(documentId, documentStatus, moduleId, config) {
        var self = this;
        self.config = config;
        self.moduleId = moduleId;
        self.documentId = documentId; //already an observable
        self.currentDocument = ko.computed(function() {
            return "docStream.htm?docId=" + self.documentId();
        });

        self.lockVisible = ko.observable(false);
        self.lockHide = ko.observable(true);
        self.keyVisible = ko.observable(false);
        self.isAnnotated = ko.observable(false);
        self.hideExternalLaunch = !config.get('externalLaunchConfig');
        self.currentUser = ko.observable();
        self.lockOwner = ko.observable();

        self.arrowLaunchesDocViewer = config.get("launchDocViewerFromArrow") === "true" ? true : false;
        self.arrowLaunchesPrintView = config.get("launchPrintView") === "true" ? true : false;

        // status panel - found in docStatus
        self.documentStatus = documentStatus;
        
        self.attrToShow = ko.computed(function() { 
            if(self.documentStatus() !== null && self.documentStatus() !== undefined) { 
                return self.documentStatus().properties[config.get('attrToShow')] ? self.documentStatus().properties[config.get('attrToShow')] : self.documentStatus().properties.objectName;
            } else {
                return false;
            }
        });

        self.documentName = ko.computed(function() {
            if (self.documentStatus() !== null && self.documentStatus() !== undefined) {
                return self.documentStatus().properties[app.objectDisplayName] ? self.documentStatus().properties[app.objectDisplayName] : self.documentStatus().properties.objectName;
            } else {
                return false;
            }
        });

        /**
        Generate tooltips for the status icons
        - contains a helper function that takes in an observable and gives us a printed "is" / "is not"
        - returns an object with properties that contain the different tooltip types
        **/
        self.tooltip = ko.computed(function() {

            var verboseState = function(type) {
                    var isOrNot = type ? "is " : "is not ";
                    return isOrNot;
                },

                tooltips = {
                    locked: window.localize("modules.stage.docViewer.thisItem") + verboseState(self.lockVisible()) + window.localize("modules.stage.docViewer.locked"),
                    lockOwner: window.localize("modules.stage.docViewer.thisItem") + verboseState(self.keyVisible()) + window.localize("modules.stage.docViewer.lockedByYou"),
                    isAnnotated: window.localize("modules.stage.docViewer.thisItem") + verboseState(self.isAnnotated()) + window.localize("modules.stage.docViewer.annotated"),
                    externalLaunch: window.localize("stage.docviewer.launchNewWindow")
                };

            // if the lock is owned by someone, add the lock owner's name to the tooltip
            if (self.lockVisible()) {
                tooltips.locked += (" by " + self.lockOwner());
            }

            return tooltips;
        });

        self.showAnnotation = function() {
            if (self.isAnnotated()) {
                self.launchDocViewerFromArrow();
            }
        };

        self.launchDocViewerFromArrow = function() {

            var url = app.DocViewerURL +"/"+ app.context.configName() + "/"+ self.documentName() +"?id="+ encodeURIComponent(self.documentId());
             window.open(url);
        };

        self.launchItemExternally = function() {
            // log open in new window event
            LogstashService.sendMetrics(
                new LogstashService.PerformanceLog({
                    'eventTitle': HPIConstants.Logging.Events.OpenInNewWindow,
                    'objectId': self.documentId()
                })
            );
            
            if (self.arrowLaunchesDocViewer) {
                self.launchDocViewerFromArrow();
            } else {
                if (!self.hideExternalLaunch) {
                    // grab the filename and attach to the url so IE can attach the correct filename when downloading from the default IE pdf viewer
                    // and replace all but the last period with underscores - the last perioid will be for the extenion, dont want to change that
                    var fileNameNoExtension = self.documentName().slice(0, self.documentName().lastIndexOf('.'));
                    var fileExtension = self.documentName().slice(self.documentName().lastIndexOf('.'), self.documentName().length);
                    // repalce any periods in the name with underscores
                    fileNameNoExtension = fileNameNoExtension.replace(/\./g, '_');
                    var fileNameForUrl = fileNameNoExtension + fileExtension;
                    
                    var url = app.serviceUrlRoot + "/content/content/" + window.encodeURI(fileNameForUrl) +
                            "?id=" + self.documentId() + "&overlay=true" + "&contentType[]=" + ["pdf", "txt", ".*"] + "&inline=true" + "&download=true";

                    if (self.arrowLaunchesPrintView) {
                        window.open(url).print();
                    } else {
                        window.open(url);
                    }
                }
            }

        };

        var _actions = [];
        _.each(config.get("actions").models, function(act) {
            _actions.push(new Action.Model({
                actionId: act.actionId,
                ocActionId: act.get("ocActionId") || act.actionId
            }));
        });

        var actionCollection = self.actionCollection = new Action.Collection();

        self.actionsLoading = ko.observable(false);

        // used to display a message that no actions are available
        self.noActionsAvailable = ko.observable(false);

        self.filterActionFactory = function(id) {
            // reset the actions and don't try to check for new ones.
            if (!id || id === '') {
                actionCollection.reset();
            } else {
                // if there aren't any configured actions
                if (_actions.length === 0) {
                    // display a message that no actions are available
                    self.noActionsAvailable(true);
                } else { // there are actions configured
                    self.actionsLoading(true);
                    //need to kill all listeners on the actionCollection
                    actionCollection.off();
                    actionCollection.reset(_actions);
                    actionCollection.objectId = id;
                    if(self.actions && self.actions().length !== 0){
                      self.actions.destroyAll();
                    }
                    actionCollection.fetch({
                        success: function(data) {
                            Action.filterActions(data, config);
                            self.determineVisibleActions(actionCollection);
                            self.actions = kb.collectionObservable(actionCollection, {view_model : self.SimpleLittleActionViewModel, auto_compact:true});
                            self.actionsLoading(false);
                        },
                        error: function() {
                            app.log.error(window.localize("modules.stage.docViewer.failedTo"));
                            actionCollection.reset();
                        },
                        global: false
                    });
                }
            }
        };

        // Takes a list of actions, and determines which actions will be visible on the docviewer and which ones will be in a dropdown
        // actionCollection - the list of filtered actions for a document
        self.determineVisibleActions = function(actionCollection){
            // Only need to do this logic if we have actions configured
            if (actionCollection.length > 0){
                var dropdownCollection, iconActionCollection; 
                if(window.innerWidth > HPIConstants.WindowSize.Small){

                    var availableWidth = $("#action-container-" + this.moduleId).width();
                    var visibleActionIcons = Math.floor(availableWidth / 50 );

                    if (visibleActionIcons  < actionCollection.length){
                        // Drop down takes the space for two icons.
                        visibleActionIcons -= 2;
                        dropdownCollection = new Action.Collection(actionCollection.slice(visibleActionIcons));
                        iconActionCollection = new Action.Collection(actionCollection.slice(0, visibleActionIcons));
                    } else {
                        iconActionCollection = actionCollection;
                    }
                } else {
                    // If on a small screen size then all actions are in the drop down.
                    dropdownCollection = actionCollection;
                    iconActionCollection = new Action.Collection();
                }
                // Create our options param to pass on
                var options = {
                    actions: iconActionCollection,
                    dropdownActions: dropdownCollection, 
                    config: self.config
                };
                DocViewer.vent.trigger("stage.documentViewer.actionsloaded"+ this.moduleId, options);
                return options;
            }
        };

        self.documentId.subscribe(function(newVal) {
            self.filterActionFactory(newVal);
        });

        if (self.documentId()) {
            self.filterActionFactory(self.documentId());
        }

        self.SimpleLittleActionViewModel = kb.ViewModel.extend({
            constructor: function(model) {
                //call super but don't create any observable except id
                kb.ViewModel.prototype.constructor.call(this, model, {
                    keys: ["actionId", "id"]
                });
                var aConfig = config.get("actions").findWhere({
                    actionId: model.get("actionId")
                });

                var iconClass = "glyphicons ";
                if (aConfig.get("icon") !== "") {
                    iconClass += "glyphicons-" + aConfig.get("icon");
                } else {
                    iconClass += "glyphicons-chevron-right";
                }
                this.icon = ko.observable(iconClass);
                this.label = ko.observable(window.localize(aConfig.get("label")));
                this.id = ko.observable(aConfig.get("actionId"));
            }
        });
        self.actions = kb.collectionObservable(actionCollection, {
            view_model: self.SimpleLittleActionViewModel,
            auto_compact:true
        });

        return self;
    };

    DocViewer.Views.ActionView = Backbone.Layout.extend({
        initialize: function(options) {
            this.moduleId = options.moduleId;
        },
        // Get the action config for a given action
        // action - the action that was clicked
        getActionConfig: function(action){
            return this.config.get("actions").findWhere({
                actionId: action.get("name")
            });
        },

        // An action icon was clicked
        // evt - the click event on an action
        actionClicked: function(evt){
            // get which action was clicked
            var action = _.find(this.actions.models, function(action){
                return action.get("name") === $(evt.target).attr("value");
            });

            // get the configuration for the action
            var aConfig = this.getActionConfig(action);
        
            app[aConfig.get("handler")].trigger("show", {
                action: action,
                config: aConfig
            });

            app.trigger("docActionClicked");
            app.trigger("closeTour");
        }
    });

    // View to for all the action icons that will be visible
    DocViewer.Views.ActionsList = DocViewer.Views.ActionView.extend({
        template: "stage/actionslist",
        tagName: 'span',

        events: {
            "click .action-button-holder" : 'actionClicked'
        },

        afterRender: function(){
            this.$('[data-toggle="tooltip"]').tooltip();
        },

        serialize: function(){
            var self = this;
            // array that we will use to populate our actions
            var actions =[];
            _.each(this.actions.models, function(action){
                // get the icon and name of each action from their config
                var aConfig = self.getActionConfig(action);
                // null checks are good
                if (aConfig){
                    actions.push({
                        name: action.get("name"),
                        icon: aConfig.get("icon"),
                        label: aConfig.get("label")
                    });
                }
            });

            return {
                actions: JSON.parse(JSON.stringify(actions)),
                moduleId: this.moduleId
            };
        }
    });

    // Dropdown for actions that would expand on to a second line
    DocViewer.Views.ActionDropdown = DocViewer.Views.ActionView.extend({
        template: "stage/actionsdropdown",
        className: "action-bar-nest",
        events: {
            "click .actiondropdownitem": "actionClicked"
        },
        serialize: function(){
            var self = this;

            // array that we will use to populate our actions
            var actions =[];

            // get the icon and name of each action from their config
            _.each(this.actions.models, function(action){
                var aConfig = self.getActionConfig(action);
                // null checks are good
                if (aConfig){
                    // push our new action
                    actions.push({
                        name: action.get("name"),
                        icon: aConfig.get("icon"),
                        label:aConfig.get("label")
                    });
                }
            });

            return {
                actions: JSON.parse(JSON.stringify(actions)),
                moduleId: this.moduleId
            };
        }
    });

    // Parent DocViewer Layout
    // Children Action View and ContentViewer
    DocViewer.Views.Layout = Backbone.Layout.extend({
        template: "stage/docviewer",
        events: {
            "click #close-doc-viewer": "closeDocViewer",
            "click #externalLaunchArrowIcon": "launchItemExternally"
        },
        initialize: function() {
            var self = this;
            this.stageViewModel = this.options.stageViewModel;
            this.config = this.stageViewModel.stageConfig.get("docViewerConfig");
            this.moduleId = this.options.moduleId || 0;
            this.documentId = this.stageViewModel.documentId;
            this.documentStatus = this.stageViewModel.activeDocument;
            this.isDualPaneDocument = this.moduleId !== 0;
            this.docInfoPaneDiv = '#document-info-outlet-' + this.moduleId;
            if (this.isDualPaneDocument) {
                this.documentId = this.stageViewModel.documentId2;
                this.documentStatus = this.stageViewModel.staticDocument;
            }
            // these are the content types the Stage should expect to receive at any point
            this.viewModel = new DocViewer.DocViewModel(this.documentId, this.documentStatus, this.moduleId, this.config);
            this.viewModel.currentUser = app.user.get("loginName");

            // Listen for when the user resizes the window
            // debounced to avoid multiple rapid calls
            $(window).resize(_.debounce(function() {
                if(self.documentInfoPane) {
                    self.createDocInfo(self.associations);
                }
                self.recalculateVisibleButtons();
            }, 50));

            this.viewModel.documentId.subscribe(_.bind(this.launchDocViewer, this));

            this.resizeHeader = _.throttle(this._resizeHeaderLogic, DocViewer.resizeHeaderThrottleTime);
            // Get date format and time format from admin app config for document info pane
            app.context.dateService.getDatetimeTimezoneFormat().done(_.bind(function(dateTimeFormat) {
                this.dateFormat = dateTimeFormat.dateFormat;
                this.timeFormat = dateTimeFormat.timeFormat;
            }, this));
        },
        launchDocViewer: function() {
            var self = this;
            this.stageViewModel.foundDoc.done(function(hasDoc) {
                self.stageViewModel.hasPermissions.done(function(hasPermissions) {
                    if (!self.documentId()) {
                        self.cleanUpDocViewer();
                    } else if (!hasPermissions) {
                        self.showNoPermissionsMessage();
                    } else if (hasDoc) {
                        self.showDocument();
                        self.showDocumentInfo();
                    }
                });
            });
        },
        cleanUpDocViewer: function() {
            this.viewModel.lockVisible(false);
            this.viewModel.keyVisible(false);
            this.$el.find(".tsg-viewer").hide();
            // remove any existing docviewer and execute its cleanup function
            if(this.contentViewer) {
                this.removeView('.content-holder');
            }
        },
        showNoPermissionsMessage: function() {
            this.permissionsHeader = this.stageViewModel.stageConfig.get("docPermissionHelpLabel");
            this.permissionsMessage = this.stageViewModel.stageConfig.get("docPermissionHelpText");
            var htmlString = "<h4>" + this.permissionsHeader + "</h4>";
            htmlString += "<div>" + this.permissionsMessage + "</div>";
            $("#permissionsOutlet-" + this.moduleId).html(htmlString);
            $(".content-holder").hide();  
            $(".header-container").hide();
        },
        showDocument: function() {
            TSG.services.ajaxService.getLockOwner({
                context: this,
                isNotGlobal: true,
                successCallback: this.setLockOwnerIcons,
                objectId: this.documentId()
            });
            TSG.services.ajaxService.isAnnotated({
                context: this,
                isNotGlobal: true,
                successCallback: this.createContentViewer,
                objectId: this.documentId()
            });
            
            if (this.config.get("auditView") == "true") {
                this.sendAudit();
            }
        },
        // breaking out function for unit testing purposes
        sendAudit: function() {
            var auditOpts = {
                type: 'POST',
                context: this,
                url: app.serviceUrlRoot + '/audit/createViewAudit',
                data: {
                    objectId: this.documentId,
                    ticket: app.ticket
                }
            };
            $.ajax(auditOpts);
        },
        showDocumentInfo: function() {
            if (this.config.get("enableDocumentInfo")) {
                var self = this;
                var propertiesFromDoc = [];
                            
                this.stageViewModel.fetchedProps.done(function () {
                    // Get the current document 
                    var doc;
                    if (!self.stageViewModel.activeDocument()) {
                        return; // no need to waste time trying to render a nonexistent doc
                    } else if (self.stageViewModel.staticDocument()) {
                        doc = self.stageViewModel.staticDocument();
                    } else {
                        doc = self.stageViewModel.activeDocument();
                    }

                    var passedChecks = true;
                    if (self.config.get("displayAttributes")) {
                        // Check if the otc matches the configured one
                        if (self.config.get("selectedOTC") === doc.objectType) {
                            // Check if the properties match the ones set up in admin if enabled
                            _.each(self.config.get("propertiesToShow"), function(property) {
                                var formattedValue;
                                var docValue = doc.properties[property.attrValue];
                                if(docValue && property.attrDataType === HPIConstants.DataTypes.Date) {
                                    if (property.attrFilter === HPIConstants.Filter.Date) {
                                        formattedValue = moment(docValue).format(self.dateFormat);
                                    } else if (property.attrFilter === HPIConstants.Filter.Datetime) {
                                        formattedValue = moment(docValue).format(self.dateFormat + " " + self.timeFormat);
                                    }
                                } else {
                                    formattedValue = docValue ? docValue : "";
                                }

                                propertiesFromDoc.push({
                                    "key": property.attrValue,
                                    "value": formattedValue,
                                    "displayLabel": property.attrName
                                });
                            });
                        } else {
                            passedChecks = false;
                        }

                        self.propertiesFromDoc = propertiesFromDoc;
                    }

                    // If additional restrictions is enabled
                    if (self.config.get("enableAdditionalRestrictions") && passedChecks) {
                        var selectedPicklist = self.config.get("columnPicklist");
                        app.context.picklistService.getPicklist(selectedPicklist, function(picklistOptions) {
                            _.each(picklistOptions, function(option) {
                                //Need to check properties on the doc (mimetype, nativeSize, etc) or actual properties
                                if (passedChecks && doc[option.label] === option.value) {
                                    passedChecks = true;
                                } else if (passedChecks && doc.properties[option.label] === option.value) {
                                    passedChecks = true;
                                } else {
                                    passedChecks = false;
                                }
                            });
                        });
                    }
                     
                    // If the document didn't successfully pass through the checks, we don't want to show the doc info pane
                    if (passedChecks) {
                        if (self.config.get("displayAssociations")) {
                            TSG.services.ajaxService.getRelatedObjects(
                                self,
                                self.documentId(),
                                self.config.get("associationName"),
                                "child",
                                self.createDocInfo
                            );
                        } else {
                            self.createDocInfo();
                        }
                    } else {
                        self.$(this.docInfoPaneDiv).hide();
                    }
                });
            }
        },
        createDocInfo: function(associations) {
            this.associations = associations;
            if(this.documentInfoPane) {
                this.documentInfoPane.remove();
            }

            this.documentInfoPane = new DocViewer.Views.DocumentInfoPane({
                moduleId: this.moduleId,
                properties: this.propertiesFromDoc,
                associations: associations
            });

            this.resizeDocInfoView();
        },
        resizeDocInfoView: function(){
            // in mobile if we don't have associations see if we should display doc info inline
            if(window.innerWidth <= HPIConstants.WindowSize.Small && (!this.associations || this.associations.length === 0 )) {
                var valueLengths = 0;
                _.each(this.documentInfoPane.properties, function(val){
                    if(_.isArray(val.value)) {
                        valueLengths += val.value.length;
                    } else {
                        valueLengths++;
                    }
                });
                // if less than 2 show the docInfo inline otherwise pop it out into the outlet
                if(valueLengths < 2) {
                    this.docInfoPaneDiv = '#document-info-outlet-inline-' + this.moduleId;
                } else {
                    this.docInfoPaneDiv = '#document-info-outlet-' + this.moduleId;
                }
            } else {
                this.docInfoPaneDiv = '#document-info-outlet-' + this.moduleId; 
            }
            this.setView(this.docInfoPaneDiv, this.documentInfoPane).render();
        },
        setLockOwnerIcons: function(lockOwner) {
            var isLockVisible = false;
            var isLockHidden = false;
            var isKeyVisible = false;
            if (lockOwner && lockOwner.loginName !== null) {
                if (lockOwner.loginName === this.viewModel.currentUser) {
                    isLockHidden = true;
                    isKeyVisible = true;
                } else {
                    isLockVisible = true;
                    this.viewModel.lockOwner(lockOwner.displayName);
                }
            }

            this.viewModel.lockVisible(isLockVisible);
            this.viewModel.lockHide(isLockHidden);
            this.viewModel.keyVisible(isKeyVisible);
        },
        createContentViewer: function(isAnnotated) {
            var self = this;
            this.viewModel.isAnnotated(isAnnotated);
            this.stageViewModel.fetchedProps.done(function () {
                if (!self.stageViewModel.activeDocument()) {
                    return; // no need to waste time trying to render a nonexistent doc
                }

                var docName = self.stageViewModel.activeDocument().properties.objectName;
                if (self.stageViewModel.staticDocument()) {
                    docName = self.stageViewModel.staticDocument().properties.objectName;
                }

                // Initialization of separate module that holds the content
                self.contentViewer = new ContentViewer.Views.Layout({
                    docName: docName,
                    documentId: self.documentId(),
                    moduleId: self.moduleId,
                    viewModel: self.viewModel,
                    config: self.config
                });

                self.$el.find(".tsg-viewer").show();
                // render the content viewer on the DOM
                self.setView('.content-holder', self.contentViewer).render();
            });
        },
        launchItemExternally: function(){
            this.viewModel.launchItemExternally();
        },
        closeDocViewer: function() {
            // remove the viewer from the DOM and allow its cleanup method to run
            if(this.contentViewer) {
                this.removeView('.content-holder');
            }

            if(this.isDualPaneDocument) {
                // tell our parent view (stage layout)
                // to close the second docviewer dual pane
                this.trigger("docviewer:closeDoc2");
            } else {
                // fire this first event so the re-launch event listener can listen to when the user closes the docviewer and would normally just see an empty stage
                app.trigger("actionService:removeDocId");
                app.trigger("pane1:manually:closed");
                app.trigger("stage.refresh.showPane1", false);
                app.trigger("tableview:columnHeaderResize");
                if (window.innerWidth > 991) {
                    app.trigger("toggleLeftBar", true);
                }
            }
        },
        serialize: function() {
            //this lets us load two docviewers at once
            return {
                moduleId: this.moduleId,
                hideExternalLaunch: this.viewModel.hideExternalLaunch,
                externalLaunchMessage: this.config.get('externalLaunchMessage'),
                tooltip: this.viewModel.tooltip()
            };
        },
        adjustHeaderClasses: function(){
            if(this.docInfoPaneDiv === "#document-info-outlet-inline-" + this.moduleId) {
                $("#menu-" + this.moduleId).switchClass("col-sm-10", "col-sm-6");
                $("#menu-" + this.moduleId).switchClass("col-xs-10", "col-xs-6");
                $(this.docInfoPaneDiv).addClass("col-sm-4");
                $(this.docInfoPaneDiv).addClass("col-xs-4");
            }
        },
        // recalculates the number of visible action buttons            
        recalculateVisibleButtons: function(){
            this.viewModel.determineVisibleActions(this.viewModel.actionCollection);
        },
        // an event on the page has caused the docviewer size to change, so update the header accordingly
        // options.actions - a collection of actions that will appear in the list as icons
        // options.dropdownActions - a collection of actions that will appear in the dropdown
        // options.config - a config object for the actions
        _resizeHeaderLogic: function(options) {
            // set our normal, icon list view
            if (this.actionListView){
                this.actionListView.actions = options.actions;
                this.actionListView.render();
            } else {
                this.actionListView = new DocViewer.Views.ActionsList({
                    actions: options.actions,
                    config: options.config,
                    moduleId: this.moduleId
                });
                this.setView("#actions-list-"+this.moduleId, this.actionListView).render();
            }

            if (options.dropdownActions && options.dropdownActions.length > 0) {
                if (this.actionDropdownView){
                    this.actionDropdownView.actions = options.dropdownActions;
                } else {
                    this.actionDropdownView = new DocViewer.Views.ActionDropdown({
                        actions: options.dropdownActions,
                        config: options.config,
                        moduleId: this.moduleId
                    });
                }
                this.setView(".action-dropdown-"+this.moduleId, this.actionDropdownView).render();

                this.adjustHeaderClasses();   
            } else {
                this.adjustHeaderClasses();   
                // if there was a dropdown view, remove it. This code gets hit when resizing to a larger menu
                if (this.actionDropdownView) {
                    this.actionDropdownView.remove();
                }
            }
        },
        registerActiveListeners: function(){
            this.stopListening();
            // once the actions are loaded, resize the header
            this.listenTo(DocViewer.vent, "stage.documentViewer.actionsloaded"+this.moduleId, this.resizeHeader);

            // listen to anything that could change the size of the contentViewer
            this.listenTo(app, "stage:toggleLeftBarFinish", this.recalculateVisibleButtons);
            this.listenTo(app, "stage:pane2Toggled stage:pane3Toggled", this.recalculateVisibleButtons);
            this.listenTo(DocViewer.vent, "recalculateVisibleButtons-"+this.moduleId,this.recalculateVisibleButtons);

            app.listenTo(app, "launchTour", function() {
                app.trigger("stageRendered", "noDocument");
            });
        },
        afterRender: function() {

            if (app.licenseInfo && app.licenseInfo.showLicenseError) {
                $('#content').css('margin-top', 90);
                $('.tsg-viewer').css("height","calc(100vh - 90px)");
            }

            this.registerActiveListeners();

            if (this.viewModel.documentId() === "" || this.viewModel.documentId() === undefined) {
                this.$el.find(".tsg-viewer").hide();
            } else {
                // only launch DocViewer if we don't already have the viewer determined or we already determined the doc is still rendering
                this.launchDocViewer();
            }

            // launches tour for wizard docs
            if ($("#docView-0").is(":visible") && $("#docView-0").length) {
                app.trigger("stageRendered", "wizard");
            } else {
                app.trigger("stageRendered", "noDocument");
            }

            kb.applyBindings(this.viewModel, this.$el[0]);
            this.$(".icon").tooltip({
                placement: "top"
            });

            app.trigger("stage.windowResizePanes");

            // Filling the rest of the pane with the actual viewer where the header is 90px
            var headerDocInfoHeight = 90 + $(this.docInfoPaneDiv).height();
            $('#docviewerRow-' + this.moduleId).height("calc(100% - " + headerDocInfoHeight + "px)");

            this.$('[data-toggle="tooltip"]').tooltip();
        }
    });

    DocViewer.Views.DocumentInfoPane = Backbone.Layout.extend({
        template: "stage/documentinfopane",
        className: "documentinfopane",

        events: {
            "click .associated-document": "launchAssociatedDocument",
            "click #association-list-toggle": "toggleAssociationDisplay"
        },

        initialize: function(options) {
            this.moduleId = options.moduleId;
            this.properties = options.properties;
            this.associations = options.associations;

            //For each association get the icon that corresponds to its type
            if (this.associations && this.associations.length > 0) {
                _.each(this.associations, function(obj) {
                    obj.mimetypeIcon = this.getMimetypeIcon(obj.mimeType);
                }, this);
            } else if (this.properties.length == 0) {
                // if both associations and properties are empty, hide the div
                $(this.docInfoPaneDiv).hide();
            }
        },
        getMimetypeIcon: function(mimetype) {
            var mimetypeIcon = "";
            
            if (mimetype.indexOf("audio/mpeg") !== -1) {
                mimetypeIcon = "<span class='mimetype-icon glyphicon glyphicon-music' style='height: 15px'></span>";
            } else if (mimetype.indexOf("video/mp4") !== -1) {
                mimetypeIcon = "<span class='mimetype-icon glyphicon glyphicon-facetime-video' style='height: 15px'></span>";
            }
            
            if (mimetypeIcon === "") {
                var iconImageLocation = "assets/css/styles/img/icons/unknown.svg";
                var contentTypeConfig = app.context.getContentTypeConfigByMimiType(mimetype);

                if (contentTypeConfig) {
                    iconImageLocation = contentTypeConfig.iconPath;
                }

                mimetypeIcon = "<img src='" + iconImageLocation + "' " + "class='mimetype-icon' style='height: 15px'/>";
            }
            
            return mimetypeIcon;
        },
        launchAssociatedDocument: function(event) {
            var dualPaneObjectId = this.$(event.target).attr('dualPaneObjectId');
            app.trigger("stage.refresh.documentId2", {
                objectId: dualPaneObjectId
            });
        },
        toggleAssociationDisplay: function() {
            if(this.$("span.glyphicon").hasClass('glyphicon-chevron-up')){
				this.$("span.glyphicon").removeClass('glyphicon-chevron-up');
				this.$("span.glyphicon").addClass('glyphicon-chevron-down');
			} else {
				this.$("span.glyphicon").removeClass('glyphicon-chevron-down');
				this.$("span.glyphicon").addClass('glyphicon-chevron-up');	
			}
        },
        serialize: function() {
            return {
                properties: this.properties,
                associations: this.associations,
                showProperties: this.properties.length > 0,
                showAssociations: this.associations && this.associations.length > 0
            };
        },
        afterRender: function() { 
            DocViewer.vent.trigger("recalculateVisibleButtons-"+this.moduleId);
            this.$('[data-toggle="tooltip"]').tooltip();
        }
    });

    // Return the module for AMD compliance.
    return DocViewer;
});