define([
        "app",
        "oc",
        "modules/tsg",
        "modules/common/workflowutil"
    ],
    function(app, OC, TSG, WorkflowUtil) {
        'use strict';

        // Create a new module.
        var WorkflowInfo = app.module();
        
        //The View
        WorkflowInfo.View = Backbone.Layout.extend({
            template: "stage/workflowinfo",
            events: {
                'click #workflowInfoToggle': "toggleClicked",
                'click #tasksToggle': "toggleClicked",
                'click #individualTaskToggle': "toggleClicked",
                'click #processToggle': "toggleClicked"

            },
            initialize: function(config) {
                var self = this;
                this.options = config.options;
                
                //Grab application config date format chosen
                app.context.dateService.getDateFormat().done(function(dateFormat){
                    self.dateFormat = dateFormat;
                });

                //Getting the docId from the options
                this.docId = this.options.documentId;
                
                //Listener to update the props when the stage doc changes.
                this.listenTo(app, "refreshWFInfo", function(newDocId) {
                    self.docId = newDocId;
                    this.getProps().done(function() {
                        self.render();
                    });
                });
                //If we are just looking at a folder we don't need to do any work.
                if (this.docId) {   
                    //Kick off the crux of the action.
                    this.getProps().done(function() {
                        self.render();
                    });
                }
            },
            getProps: function() {
                var self = this;
                var resultDef = $.Deferred();
                //clear out values
                this.tasks = [];
                this.workflowDueDate = "";
                this.workflow = "";
                this.initiator = "";
                this.startDate = "";
                
                WorkflowUtil.getTasks(this.docId).done(function(wfTasks) {
                    var deferreds = [];
                    if(wfTasks.length > 0) {
                        self.wfExists = true;
                        //loop through each task to get information specifc to the task
                        _.each(wfTasks, function(taskInfo) {
                            var taskName ={};
                            var individualTask = {};
                        
                            //grab the general values from the task
                            self.workflow = taskInfo.processName;
                            //Calling helper method to go from username --> pretty name.
                            if(!self.initiator) {
                                var def = $.Deferred();
                                deferreds.push(def);
                                self.renderAndSetUserName(taskInfo.initiator).done(function(result) {
                                    self.initiator = result;
                                    def.resolve();
                                });
                            }

                            //Formatting the dates
                            self.startDate = moment(taskInfo.assignedDate).format(self.dateFormat).toString();
                            var workflowDueDate = taskInfo.workflowDueDate;
                            if (workflowDueDate) {
                                self.workflowDueDate = moment(workflowDueDate).format(self.dateFormat).toString();
                            }

                            //indivualTask will contain the information specific to each task
                            individualTask.taskId = taskInfo.id;
    
                            if (taskInfo.assignee) {
                                var def2 = $.Deferred();
                                deferreds.push(def2);
                                self.renderAndSetUserName(taskInfo.assignee).done(function(result) {
                                    individualTask.assignee = result;
                                    def2.resolve();
                                });
                            } 
                            if (taskInfo.candidateGroups.length > 0) {
                                individualTask.groupAssignee = taskInfo.candidateGroups[0];
                            } 
                            //check if the task's taskName we are looping through right now has been added to the the tasks array yet
                            var taskNameExists = _.find(self.tasks, function(task) {
                                return task.name === taskInfo.name;
                            });
                            //if the taskName has not been added we want to add it to the tasks array along with an array that contains
                            //all the individual tasks with that has that taskName
                            //if the taskName does exist in the array we want to add the current task to the array of tasks for this taskName
                            if(taskNameExists) {
                                 _.each(self.tasks, function(task) {
                                    if(task.name === taskInfo.name) {
                                        task.individualTasks.push(individualTask);
                                    }
                               });
                            } else {
                                taskName.name = taskInfo.name;
                                taskName.individualTasks = [];
                                taskName.individualTasks.push(individualTask);

                                self.tasks.push(taskName);
                            }
                        });
                        //get all the proccessIds and corresponding workflow definitions for the current workflow
                        self.getProcessInstances();
                    }
                     //There is no workflow on the document.  We can just re-render the view, which hides the section.
                    else {
                        //No wf exists.
                        self.wfExists = false;
                        resultDef.resolve("");
                    }  

                    $.when.apply(self, deferreds).done(function(){
                        resultDef.resolve(self.tasks);
                    }); 
                });
                //Returning our promise.
                return resultDef.promise();
                
            },

            getProcessInstances: function() {
                var self = this;
                 $.ajax({
                    url: app.serviceUrlRoot + "/workflow/getWorkflowInstanceInfo?objectId=" + self.docId,
                    success: function(wfInstances) {
                        self.wfProcesses = wfInstances;
                        self.render();
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showError", window.localize("modules.common.workflowUtil.failedToRetrieve"));
                    }
                }); 
            },
            //Function handling the UI of the collapsable panel and arrow direction.
            toggleClicked: function(evt) {
                var arrow = "";
                if(evt.currentTarget.id === "workflowInfoToggle") {
                    arrow = $("#workflowInfoArrow");
                } else if(evt.currentTarget.id === "tasksToggle") {
                    arrow = $("#tasksArrow");
                } else if(evt.currentTarget.id === "individualTaskToggle") {
                    arrow = $("#individualTaskArrow");
                } else if(evt.currentTarget.id === "processToggle") {
                    arrow = $("#processArrow");
                }


                if (arrow.hasClass('glyphicon-chevron-up')) {
                    arrow.addClass('glyphicon-chevron-down');
                    arrow.removeClass('glyphicon-chevron-up');
                } else {
                    arrow.addClass('glyphicon-chevron-up');
                    arrow.removeClass('glyphicon-chevron-down');
                }
            },
            //Function that gets the displayname from a username and sets it to the specified, desired property.
            renderAndSetUserName: function(userName) {
                var deferred = new $.Deferred();
                app.context.filterService.getUserDisplayName(userName, function(fullName) {
                    deferred.resolve(fullName);
                });

                return deferred.promise();
            },
            serialize: function() {
                return {
                    tasks: this.tasks,
                    workflow: this.workflow,
                    initiator: this.initiator,
                    startDate: this.startDate,
                    workflowDueDate: this.workflowDueDate,
                    wfExists: this.wfExists,
                    wfProcesses: this.wfProcesses
                };
            }
        });

        return WorkflowInfo;

    });