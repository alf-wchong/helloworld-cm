// OAVideoAnnotationViewer module
define([
    // Application.
    "app",
    'module',
    "videoJS"
  ],
  // Map dependencies from above array.
  function (app) {
    "use strict";

    var OAVideoAnnotationViewer = app.module();
    OAVideoAnnotationViewer.priority = 4;
    OAVideoAnnotationViewer.mimeTypes = ['video/mp4', 'audio/mpeg'];
    OAVideoAnnotationViewer.acceptedObjectTypes = [];

    // Default View.
    OAVideoAnnotationViewer.Views.Viewer = Backbone.Layout.extend({
      template: "stage/documentViewers/oaVideoAnnotationViewer",
      className: "fullHeight",
      initialize: function (options) {
        this.documentId = options.documentId;

        /**
         * !NOTE: Below VAR is used for DEVELOPMENT only.
         */
        // var contentHostname = "http://localhost:4200";

        /**
         * !NOTE: Below VAR is used for PRODUCTION only.
         */
        var contentHostname = app.openAnnotateVideoURL;

        /**
         * OAV <iframe> URL
         */
        this.contentURL = contentHostname + "/#/login" +
                            "?docName=" + options.docName +
                            "&docId=" + options.documentId +
                            "&username=" + app.user.get("loginName");
      },
      serialize: function () {
        return {
          contentURL: this.contentURL
        };
      }
    });

    return OAVideoAnnotationViewer;
  });