define([
  // Application.
  "app"
],
// Map dependencies from above array.
function(app) {
  "use strict";

  // Create a new module.
  var NewTabViewer = app.module();
  NewTabViewer.acceptedObjectTypes = [];
   
	// Default View.
  NewTabViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/newTabView",
    initialize: function(options){
      this.documentId = options.documentId;

      this.tabName = options.tabName;

      this.tabName = this.tabName.replace("/", "_");
      this.tabName = this.tabName.replace("\\", "_");

      document.title = options.tabName;

      this.contentURL = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(this.tabName) + "?id=" +
                  encodeURIComponent(this.documentId) + "&overlay=true" + "&contentType[]=" + ["pdf","txt","png","jpg",".*"];

      //Add in additional properties from config
      if(this.overlayParamMap) {
        this.contentURL += "&" + $.param({
          overlayParameters: JSON.stringify(this.overlayParamMap)
        });
      }
   },
    serialize: function(){
      return {    
        contentURL : this.contentURL
      };
    }
  });
  // Return the module for AMD compliance.
  return NewTabViewer;
});