// Docviewer module
define([
	// Application.
	"app",
	'module',
	"videoJS"
],
// Map dependencies from above array.
function (app, module, videojs) {
	"use strict";

	// Create a new module.
	var VideoViewer = app.module();
	VideoViewer.priority = 2;
	VideoViewer.mimeTypes = module.config().supportedAudioAndVideoTypes || ['video/mp4', 'audio/x-wav', 'audio/mpeg', 'audio/wav'];
	VideoViewer.acceptedObjectTypes = [];
	var audioList = ['audio/x-wav', 'audio/mpeg', 'audio/wav', 'audio/aac'];

	// Default View.
	VideoViewer.Views.Viewer = Backbone.Layout.extend({
		template: "stage/documentViewers/videoViewer",
		className: "fullHeight",
		initialize: function(options) {
			this.documentId = options.documentId; //already an observable
			this.contentURL = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(options.docName) + "?id=" +
							this.documentId + "&overlay=true" + "&contentType[]=" + ["mp3", "mp4",".*"] + "&presignedUrl=true";
			this.mimeType = options.mimeType;

			if (_.contains(audioList, this.mimeType)) {
				this.type = 'audio';
			} else {
				this.type = 'video';
			}

			this.startListening();
		},
		startListening: function() {
			// if the pane containing the video player is closed or hidden, pause the video player
			this.listenTo(app, "stage.refresh.showPane1 stage.hideAllPanes", function (show) {
				if (!show && app.videoPlayer) {
					app.videoPlayer.pause();
				}
			});
		},
		_stopListening: function() {
			this.stopListening(app);
		},
		serialize: function() {
			return {
				contentURL: this.contentURL,
				mimeType: this.mimeType,
				type: this.type
			};
		},
		afterRender: function() {
			if (app.videoPlayer) {
				app.videoPlayer.dispose();
			}

			// default techOrder to use html5 first, unless the the browser is ie9 then we have to use flash for video
			var techOrder = ['html5', 'flash'];
			if (this.type === 'video' && $.browser.msie && parseInt && $.browser.version === '9.0') {
				techOrder = ['flash'];
			}
			
			this.createNewVideoPlayer(techOrder);
		},
		createNewVideoPlayer: function(techOrder) {
			videojs.options.flash.swf = 'assets/videojs5/video-js.swf';
			app.videoPlayer = videojs('docViewerVideo', {
				techOrder: techOrder
			});
		},
		cleanup: function() {
			this._stopListening();
		}
	});

	// Return the module for AMD compliance.
	return VideoViewer;
});
