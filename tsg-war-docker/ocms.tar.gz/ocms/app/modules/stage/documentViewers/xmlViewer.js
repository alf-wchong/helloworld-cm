define([
  "app",
  "modules/common/spinner",
  "simpleXML" // JQuery Plugin for displaying XML
],
function(app, HPISpinner) {
  "use strict";

  // Create a new module.
  var XMLViewer = app.module();
  XMLViewer.priority = 5;
  XMLViewer.mimeTypes = ['application/xml'];
  XMLViewer.acceptedObjectTypes = [];
   
  XMLViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/xmlViewer",
    className: "fullHeight",
    initialize: function(options) {
      this.contentURL = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(options.docName) + "?id=" +
                        options.documentId + "&overlay=false" + "&contentType[]=" + ["xml", ".*"];
      $.ajax({
          url: this.contentURL,
          type: "GET",
          context: this,
          success: function(response) {
            var serializer = new XMLSerializer();
            this.xmlString = serializer.serializeToString(response);
            this.render();
          },
          global: false
      });
    },
    afterRender: function() {
      if(this.xmlString) {
        HPISpinner.destroySpinner(this.spinner);
        this.$("#xmlContent").simpleXML({xmlString: this.xmlString});
      } else {
        this.spinner = HPISpinner.createSpinner({
            color: '#000'
        },  this.$("#xmlContent")[0]);
      }
    }
  });

  return XMLViewer;
});