// Docviewer module
define([
  // Application.
  'app',
  'modules/common/hpiconstants',
],
// Map dependencies from above array.
function(app, HPIConstants) {
  "use strict";

  // Create a new module.
  var OAViewer = app.module();
  OAViewer.priority = 4;
  OAViewer.mimeTypes = ['application/pdf','image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
  OAViewer.acceptedObjectTypes = [HPIConstants.ObjectTypes.Collection];
  
  // Default View.
  OAViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/OAViewer",
    className: "fullHeight",
    initialize: function(options) {
      this.documentId = options.documentId;
      this.contentURL = app.openAnnotateURL + "/login/external.htm?docId=" + this.documentId +
        "&parentId=" + app.context.container.get('objectId') +
        "&username=" + app.user.get("loginName") +
        "&mode=" + options.oaviewerMode +
        "&startupSearch=" + options.openAnnotateSearchValue;
    },
    serialize: function() {
      return {
        contentURL: this.contentURL
      };
    },
    cleanup: function() {
      // triggering a cleanup if iframe is destroyed - this was previously called from tableview ,
      // however we could possibly run into issues where the iframe wasn't removed from the DOM 
      if(app.openAnnotate) {
        // In IE, if the user switches OA modes, the iframe reloads and we lose the reference to it
        // this try catch prevents the user from encountering an error that causes unexpected HPI behavior
        try {
          app.openAnnotate.trigger("cleanup", this.documentId);
        } catch(error) {
          app.log.error('Attempt to clean up instance of OpenAnnotate iframe failed for content with id: ' +  this.documentId);
        }
      }
    }
  });
  // Return the module for AMD compliance.
  return OAViewer;
});
