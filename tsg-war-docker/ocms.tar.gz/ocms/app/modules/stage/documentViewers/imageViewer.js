 // ImageViewer module
 define([
         "app",
         "fabricJS",
         "modules/common/spinner"
     ],
     function(app, fabric, HPISpinner) {

         "use strict";

         // Create a new module.
         var ImageViewer = app.module();
         ImageViewer.priority = 1;
         ImageViewer.mimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
         ImageViewer.acceptedObjectTypes = [];

         // Default View.
         ImageViewer.Views.Viewer = Backbone.Layout.extend({
             template: "stage/documentViewers/docviewer-image",

             className: "docviewer-img-outlet stageContain fullHeight",

             events: {
                 "click #rotate90": "rotate90",
                 "click #rotate90reverse": "rotate90reverse",
                 "click #zoomIn": "zoom",
                 "click #zoomOut": "zoom",
                 "click #actualSize": "fullScreen",
                 "click #canvasSize": "canvasSize",
                 "click #brightness": "brightness",
                 "click #sharpen": "sharpen",
                 "click #contrast": "contrast",
                 "click #pan": "setPan",
                 "click #reset": "reset",
                 "click #export": "exportImage",
                 "change #brightness-value": "brightnessValue",
                 "change #contrast-value": "contrastValue",
                 "click #launchImageModal": "resetImageModal"
             },
             initialize: function(options) {
                 var self = this;
                 this.objectId = options.documentId;
                 //Generate a large random number to try and remove cache
                 var randomNumber = Math.floor(Math.random() * 90000) + 10000;
                 this.contentUrl = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(options.docName) + "?id=" + options.documentId + '&rand=' + randomNumber;
                 this.loaded = false;
                 this.actionClicked = "";
                 this.panning = false;
                 this.imageLoadedTop = 0;
                 this.startPositionX = 0;
                 this.startPositionY = 0;

                 // set image viewer's height and width
                 this.calculateHeightAndWidth();
                
                 var defaultFSParams = {
                     topMargin: 40,
                     sideMargins: 40,
                     bottomMargin: 20,
                     showImageTitle: false
                 };

                 var contentImage = new Image();
                 contentImage.onload = function() {
                     self.loaded = true;
                     self.imageTrueWidth = this.width;
                     self.imageTrueHeight = this.height;
                     self.calculateHeightAndWidth();
                     self.render();
                 };

                 contentImage.src = this.contentUrl;

                 this.fullscreenParams = _.extend(defaultFSParams, options.fullscreenParams);
             },
             calculateHeightAndWidth: function() {
                // we may not know the toolbar or rightBar values initially
                var imageToolBarHeight = $('.imageToolBar').height();
                imageToolBarHeight = imageToolBarHeight === null ? 36 : imageToolBarHeight;

                var rightBarOffset, topOffset;
                // In Stage (rightBar contains the viewer panes and right side action handler)
                if($("#rightBar").length > 0) {
                    rightBarOffset = $("#rightBar").offset();
                    topOffset = _.isUndefined(rightBarOffset) ? 60 : rightBarOffset.top;
                    this.height = $(window).innerHeight() - topOffset - $(".navbar").height();
                    this.displayHeight = this.height - imageToolBarHeight - $("#tsg-viewer-0 .header-container").height();
                // In New Tab
				} else {
                    // Still have to account for the imageToolBar.
                    this.displayHeight = $("#outerContainer").height() - imageToolBarHeight;
                }

                // Will always use this for the maxwidth regardless whether opened in new tab or not.
                this.displayMaxWidth = $("#outerContainer").width();
             },
             dataURItoBlob: function(dataURI) {
                 // convert base64/URLEncoded data component to raw binary data held in a string
                 var byteString;
                 if (dataURI.split(',')[0].indexOf('base64') >= 0) {
                     byteString = atob(dataURI.split(',')[1]);
                 }
                 /* jshint ignore:start */
                 else {

                     byteString = unescape(dataURI.split(',')[1]);

                 }
                 /* jshint ignore:end */

                 // separate out the mime component
                 var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

                 // write the bytes of the string to a typed array
                 var ia = new Uint8Array(byteString.length);
                 for (var i = 0; i < byteString.length; i++) {
                     ia[i] = byteString.charCodeAt(i);
                 }

                 return new Blob([ia], {
                     type: mimeString
                 });
             },
			// resets image modal on open
             resetImageModal: function() {
                $("#exportImage-error").hide();
                $("#exportImage-versionError").hide();
                $("#exportImage-success").hide();
                $("#exportImage-processing").hide();
                $("#export").prop("disabled", false);
                $("#imgSaveModalFooter").show();
                $("#imgSaveModalBody").show();
             },
             exportImage: function(evt) {
                 var self = this;
                 if (!fabric.Canvas.supports('toDataURL')) {
                     alert('This browser doesn\'t provide means to serialize canvas to an image');
                     $("#exportImage-error").show();
                 } else {
                     $("#imgSaveModalFooter").hide();
                     $("#imgSaveModalBody").hide();
                     $("#exportImage-processing").show("fast", function() {
                         $("#export").prop("disabled", true);
                         var img = self.myCanvasFull.getObjects()[0];
                         img.applyFilters(function() {
                             self.myCanvasFull.add(img);
                             self.myCanvasFull.renderAll.bind(self.myCanvasFull);
                             var mimetype = self.options.mimeType;
                             var format = mimetype.substr(mimetype.indexOf('/') + 1, mimetype.length);
                             var url = self.myCanvasFull.item(0).toDataURL({
                                 "format": format
                             });
                             var xhr = new XMLHttpRequest();
                             xhr.open("POST", app.serviceUrlRoot + '/action/executeWithAttachment');
                             xhr.onreadystatechange = function(d) {
                                 if (xhr.readyState === 4) {
                                    var xhrResp = JSON.parse(xhr.response);
                                     // for some reason, OC is returning a 202: Accepted
                                     $("#exportImage-processing").hide();
                                     if (xhr.status >= 200 && xhr.status <= 202) {
                                         //success
                                         $("#exportImage-success").show();
                                         $("#exportImage-error").hide();
                                         $("#exportImage-versionError").hide();
                                    //TODO: Should not check condidition like this.
                                     } else if (xhrResp.message.indexOf("One or more conditions for uploadImageAsNewVersion was invaild:")>-1){
                                         //VersionError
                                         $("#exportImage-success").hide();
                                         $("#exportImage-error").hide();
                                         $("#exportImage-versionError").show();
                                     } else {
                                         //failure
                                         $("#exportImage-success").hide();
                                         $("#exportImage-error").show();
                                         $("#exportImage-versionError").hide();
                                     }
                                 }
                             };

                             var blob = self.dataURItoBlob(url);
                             var fd = new FormData();
                             fd.append("canvasImage", blob);

                             // construct our action parameter for our upload request
                             var action = new Backbone.Model({
                                 name: 'uploadImageAsNewVersion',
                                 parameters: {
                                     objectId: evt.srcElement.attributes.objectId.value,
                                     mimeType: app.context.document.attributes.mimeType
                                 }
                             });

                             fd.append("action", JSON.stringify(action));

                             // send our request
                             xhr.send(fd);
                         });
                     });
                 }

             },
             resizeImage: function() {
                 if (this.loaded) {
                     this.calculateHeightAndWidth();

                     var dx = this.displayMaxWidth - this.myCanvas.getWidth();
                     var dy = this.displayHeight - this.myCanvas.getHeight();

                     if (dx !== 0 || dy !== 0) {
                         // resize fabric "lower canvas" that has our image
                         $("#imageViewer" + this.cid).css({
                             "width": this.displayMaxWidth,
                             "height": this.displayHeight
                         });

                         if (this.myCanvas.getObjects()[0]) {
                             // resize fabric "upper canvas" 
                             this.myCanvas.setWidth(this.displayMaxWidth);
                             this.myCanvas.setHeight(this.displayHeight);
                             this.scaleTo('w');

                             // When only the imageviewer in pane1 is displayed, we need to scale by height too
                             if($("#leftBar").css('display') === 'none' && $("#pane2").css('display') === 'none' && $("#pane3").css('display') === 'none') {
                                 this.scaleTo('h');
                             }
                         }
                     }
                 }
            },
             serialize: function() {
                 return {
                     contentUrl: this.contentUrl,
                     displayHeight: this.displayHeight,
                     displayMaxWidth: this.displayMaxWidth,
                     imageTrueWidth: this.imageTrueWidth,
                     imageTrueHeight: this.imageTrueHeight,
                     cid: this.cid,
                     objectId: this.objectId
                 };
             },
             afterRender: function() {
                 var self = this;
                 this.spinner = $("#spinner" + this.cid);
                 this.myCanvas = this.__canvas = window.can = new fabric.Canvas("imageViewer" + this.cid);
                 this.myCanvasFull = this.__canvasFull = new fabric.Canvas("imageViewerFull" + this.cid);
                 this.docView = $("#docView-" + this.moduleId);

                 fabric.Image.fromURL(this.contentUrl, function(img) {
                     img.setWidth(img.width);
                     img.setHeight(img.height);
                     img.selectable = false;
                     img.lockRotation = true;
                     img.lockScalingFlip = true;
                     img.lockScalingX = true;
                     img.lockScalingY = true;
                     img.lockSkewingX = true;
                     img.lockSkewingY = true;
                     img.hasControls = false;
                     img.hasBorders = false;
                     img.filters.push(new fabric.Image.filters.Brightness({
                         brightness: 0
                     }));
                     img.filters.push(new fabric.Image.filters.Contrast({
                         contrast: 0
                     }));
                     self.myCanvas.add(img);
                     //We don't actually know if this is DocView-0 or 2
                     //This will be the content holder.
                     self.myCanvas.height = self.displayHeight;
                     self.myCanvas.width = self.displayMaxWidth;
                     self.canvasSize();
                     img.center();
                     // resize image to fix sizing issue in IE11 and Edge
                     self.resizeImage();
                 });

                 fabric.Image.fromURL(this.contentUrl, function(imgFull) {
                     imgFull.setWidth(imgFull.width);
                     imgFull.setHeight(imgFull.height);
                     imgFull.selectable = false;
                     imgFull.filters.push(new fabric.Image.filters.Brightness({
                         brightness: 0
                     }));
                     imgFull.filters.push(new fabric.Image.filters.Contrast({
                         contrast: 0
                     }));
                     self.myCanvasFull.add(imgFull);
                     imgFull.center();
                 });

                 this.myCanvas.on('after:render', function(evt) {
                     $(this.wrapperEl.previousElementSibling).hide();
                 });

                 this.myCanvasFull.on('after:render', function(evt) {
                     $(this.wrapperEl.previousElementSibling).hide();
                 });

                 this.myCanvasFull.on('object:added', function(evt) {
                     if (self.myCanvas.getObjects()[0] && self.myCanvas.getObjects()[0].getTop() < 0) {
                         self.myCanvas.viewportCenterObject(self.myCanvas.getObjects()[0]);
                     }
                 });

                 this.listenTo(app, "stage.windowResizePanes toggleLeftBar", this.resizeImage);

                 this.loadSpinner();
                 
                 this.resizeImage();
            },
             rotate90: function(evt) {
                 this.actionClicked = evt.target.id;
                 this.__canvas.defaultCursor = "default";
                 var objects = this.__canvas.getObjects();
                 if (objects) {
                     for (var i in objects) {
                         if (objects[i]) {
                             objects[i].selectable = false;
                             objects[i].setAngle(objects[i].getAngle() + 90);
                         }
                     }
                 }
                 this.__canvas.renderAll();

                 var objectsFull = this.__canvasFull.getObjects();
                 if (objectsFull) {
                     for (var j in objectsFull) {
                         if (objectsFull[j]) {
                             objectsFull[j].setWidth(this.imageTrueWidth);
                             objectsFull[j].setHeight(this.imageTrueHeight);
                             objectsFull[j].setAngle(objectsFull[j].getAngle() + 90);
                         }
                     }
                 }

                 var temp = this.imageTrueWidth;
                 this.imageTrueWidth = this.imageTrueHeight;
                 this.imageTrueHeight = temp;

                 this.__canvasFull.setHeight(this.imageTrueHeight);
                 this.__canvasFull.setWidth(this.imageTrueWidth);
             },
             rotate90reverse: function(evt) {
                 this.actionClicked = evt.target.id;
                 this.__canvas.defaultCursor = "default";
                 var objects = this.__canvas.getObjects();
                 if (objects) {
                     for (var i in objects) {
                         if (objects[i]) {
                             objects[i].selectable = false;
                             objects[i].setAngle(objects[i].getAngle() - 90);
                         }
                     }
                 }
                 this.__canvas.renderAll();

                 var objectsFull = this.__canvasFull.getObjects();
                 if (objectsFull) {
                     for (var j in objectsFull) {
                         if (objectsFull[j]) {
                             objectsFull[j].setAngle(objectsFull[j].getAngle() - 90);
                         }

                     }
                 }

                 var temp = this.imageTrueWidth;
                 this.imageTrueWidth = this.imageTrueHeight;
                 this.imageTrueHeight = temp;

                 this.__canvasFull.setHeight(this.imageTrueHeight);
                 this.__canvasFull.setWidth(this.imageTrueWidth);
             },
             zoom: function(evt) {
                 var canvas = this.__canvas;
                 var center = canvas.getCenter(),
                     point = {
                         x: center.left,
                         y: center.top
                     };
                 if (evt.target.id.indexOf("zoomIn") > -1) {
                     canvas.zoomToPoint(point, canvas.getZoom() * 1.1);
                 } else if (evt.target.id.indexOf("zoomOut") > -1) {
                     canvas.zoomToPoint(point, canvas.getZoom() / 1.1);
                 }

                 this.__canvas.renderAll();
             },
             setPan: function(evt) {
                 var canvas = this.__canvas;
                 this.actionClicked = evt.target.id;
                 canvas.defaultCursor = "move";
                 var objects = canvas.getObjects();
                 if (objects) {
                     objects[0].selectable = true;
                 }

                 this.__canvas.renderAll();
             },
             scaleTo: function(scaleTo) {
                this.__canvas.defaultCursor = "default";
                this.__canvas.setZoom(1);
                var objects = this.__canvas.getObjects();

                if (objects) {
                    var canvasObj = objects[0];
                    canvasObj.selectable = false;

                    if(scaleTo === "h") {
                       canvasObj.scaleToHeight(this.__canvas.getHeight(), false);                        
                    } else if(scaleTo === "w") {
                       canvasObj.scaleToWidth(this.__canvas.getWidth(), false);                     
                    }
                    
                    this.__canvas.viewportCenterObject(canvasObj);
                }
                
                this.__canvas.renderAll();
             },
             canvasSize: function () {
                // When only the imageviewer in pane1 is displayed, we need to scale by height too
                if($("#leftBar").css('display') === 'none' && $("#pane2").css('display') === 'none' && $("#pane3").css('display') === 'none') {
                    this.scaleTo('h');
                } else {
                    this.scaleTo("w");
                }
             },
             brightness: function(evt) {
                 this.actionClicked = evt.target.id;
                 this.__canvas.defaultCursor = "default";
                 if (this.$("#brightness-value").css('display') === 'none' || this.$("#brightness-value").css('display') === "") {
                     if (this.$("#contrast-value").css('display') === 'block') {
                         this.$("#contrast-value").css('display', 'none');
                     }
                     this.$("#brightness-value").css('display', 'block');
                 } else {
                     this.$("#brightness-value").css('display', 'none');
                 }
             },
             brightnessValue: function(evt) {
                 var self = this;
                 self.spinner.show(0, function() {
                     var canvas = self.__canvas;
                     self.actionClicked = evt.target.id;
                     var objects = canvas.getObjects();
                     if (objects) {
                         for (var i in objects) {
                             if (objects[i]) {
                                 objects[i].filters[0].brightness = parseInt(evt.target.value, 10);
                                 /* jshint ignore:start */
                                 _.defer(function() {
                                     objects[i].applyFilters(canvas.renderAll.bind(canvas));
                                 });
                                 /* jshint ignore:end */
                             }
                         }
                     }
                     var canvasFull = self.__canvasFull;
                     var objectsFull = canvasFull.getObjects();
                     if (objectsFull) {
                         for (var j in objectsFull) {
                             if (objectsFull[j]) {
                                 objectsFull[j].filters[0].brightness = parseInt(evt.target.value, 10);
                             }
                         }
                     }
                 });

             },
             contrast: function(evt) {
                 this.actionClicked = evt.target.id;
                 this.__canvas.defaultCursor = "default";
                 if (this.$("#contrast-value").css('display') === 'none' || this.$("#contrast-value").css('display') === "") {
                     if (this.$("#brightness-value").css('display') === 'block') {
                         this.$("#brightness-value").css('display', 'none');
                     }
                     this.$("#contrast-value").css('display', 'block');
                 } else {
                     this.$("#contrast-value").css('display', 'none');
                 }
             },
             contrastValue: function(evt) {
                 var self = this;
                 self.spinner.show(0, function() {
                     var canvas = self.__canvas;
                     self.actionClicked = evt.target.id;
                     var objects = canvas.getObjects();
                     if (objects) {
                         for (var i in objects) {
                             if (objects[i]) {
                                 objects[i].filters[1].contrast = parseInt(evt.target.value, 10);
                                 /* jshint ignore:start */
                                 _.defer(function() {
                                     objects[i].applyFilters(canvas.renderAll.bind(canvas));
                                 });
                                 /* jshint ignore:end */
                             }
                         }
                     }
                     var canvasFull = self.__canvasFull;
                     var objectsFull = canvasFull.getObjects();
                     if (objectsFull) {
                         for (var j in objectsFull) {
                             if (objectsFull[j]) {
                                 objectsFull[j].filters[1].contrast = parseInt(evt.target.value, 10);
                             }

                         }
                     }
                 });
             },
             loadSpinner: function() {
                 if (this.Loader) {
                     HPISpinner.destroySpinner(this.Loader);
                 }

                 this.Loader = HPISpinner.createSpinner({
                     color: '#FFFFFF',
                     lines: 12,
                     length: 17,
                     width: 13,
                     radius: 30
                 }, $("#spinner" + this.cid)[0]);
             },
             sharpen: function(evt) {
                 var self = this;
                 self.spinner.show(0, function() {
                     self.actionClicked = evt.target.id;
                     self.__canvas.defaultCursor = "default";
                     var canvas = self.__canvas;
                     var objects = canvas.getObjects();
                     var filter = new fabric.Image.filters.Convolute({
                         matrix: [0, -1, 0, -1, 5, -1,
                             0, -1, 0
                         ]
                     });

                     if (objects) {
                         for (var i in objects) {
                             if (objects[i]) {
                                 objects[i].selectable = false;
                                 if (objects[i].filters.length === 3) {
                                     objects[i].filters.pop();
                                 } else {

                                     objects[i].filters.push(filter);
                                 }
                                 /* jshint ignore:start */
                                 _.defer(function() {
                                     objects[i].applyFilters(canvas.renderAll.bind(canvas));
                                 });
                                 /* jshint ignore:end */
                             }

                         }
                     }
                     var canvasFull = self.__canvasFull;
                     var objectsFull = canvasFull.getObjects();
                     if (objectsFull) {
                         for (var j in objectsFull) {
                             if (objectsFull[j]) {
                                 if (objectsFull[j].filters.length === 3) {
                                     objectsFull[j].filters.pop();
                                 } else {
                                     objectsFull[j].filters.push(filter);
                                 }
                             }

                         }
                     }
                     //This will disallow the the sharpen button to be clicked twice.
                     self.$('#sharpen').prop('disabled', true);
                 });
             },
             reset: function(evt) {
                 var self = this;
                 this.actionClicked = evt.target.id;
                 this.__canvas.defaultCursor = "default";
                 var canvas = this.__canvas;
                 var canvasFull = this.__canvasFull;
                 canvas.setZoom(1);
                 var objects = canvas.getObjects();
                 if (objects) {
                     var image = objects[0];
                     canvas.remove(image);
                     canvasFull.remove(canvasFull.getObjects()[0]);
                     fabric.Image.fromURL(this.contentUrl, function(img) {
                         img.setWidth(img.width);
                         img.setHeight(img.height);
                         img.selectable = false;
                         img.lockRotation = true;
                         img.lockScalingFlip = true;
                         img.lockScalingX = true;
                         img.lockScalingY = true;
                         img.lockSkewingX = true;
                         img.lockSkewingY = true;
                         img.hasControls = false;
                         img.hasBorders = false;
                         img.filters.push(new fabric.Image.filters.Brightness({
                             brightness: 0
                         }));
                         img.filters.push(new fabric.Image.filters.Contrast({
                             contrast: 0
                         }));
                         self.myCanvas.add(img);
                         self.myCanvas.height = self.displayHeight;
                         self.myCanvas.width = self.docView.width();
                         self.canvasSize();
                         img.viewportCenter();
                     });
                     fabric.Image.fromURL(this.contentUrl, function(imgFull) {
                         imgFull.setWidth(imgFull.width);
                         imgFull.setHeight(imgFull.height);
                         imgFull.selectable = false;
                         imgFull.filters.push(new fabric.Image.filters.Brightness({
                             brightness: 0
                         }));
                         imgFull.filters.push(new fabric.Image.filters.Contrast({
                             contrast: 0
                         }));
                         canvasFull.add(imgFull);
                         imgFull.center();
                     });
                 }
                 //Re-Enable the sharpen button
                 this.$('#sharpen').prop('disabled', false);
                 canvas.renderAll();
             }
         });

         // Return the module for AMD compliance.
         return ImageViewer;
     });