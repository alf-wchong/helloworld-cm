// Docviewer module
define([
  // Application.
  "app"
],
// Map dependencies from above array.
function(app) {
  "use strict";

  // Create a new module.
  var HtmlViewer = app.module();
  HtmlViewer.priority = 5;
  HtmlViewer.mimeTypes = ['text/html'];
  HtmlViewer.acceptedObjectTypes = [];
   
	// Default View.
    HtmlViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/htmlViewer",
    className: "fullHeight",
    initialize: function(options){
      this.documentId = options.documentId;
    },
    afterRender: function(){
      $.ajax({
        url: app.serviceUrlRoot + "/content/content/" + encodeURIComponent(this.docName) + "?id=" + this.documentId + "&overlay=true&contentType[]=" + ["html",".*"],
        success: this.renderDocument,
        context: this
      });
    },
    renderDocument: function(html){
      if($("#htmlFileDocViewerContentDiv").has("style").length > 0){
        $("#htmlFileDocViewerContentDiv").children("style").remove();
      }

      // Adding class here instead of above to avoid awkward white bar
      // while file is loading.
      $("#htmlFileDocViewerContentDiv").addClass("docViewerHtmlFileBody");
      
      // Will parse the HTML and remove any script tags to avoid scripts being
      // exectuted.
      html = $.parseHTML(html);

      // This will grab the html code and add it to the content div.
      $("#htmlFileDocViewerContentDiv").html(html);
      $("#htmlFileDocViewerContentDiv").append("<div class='clearFix'></div>");
    }
  });
  // Return the module for AMD compliance.
  return HtmlViewer;
});