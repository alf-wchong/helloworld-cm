// Docviewer module
define([
  // Application.
  "app"
],
// Map dependencies from above array.
function(app) {
  "use strict";

  // Create a new module.
  var DownloadViewer = app.module();
  DownloadViewer.priority = 7;
  DownloadViewer.mimeTypes = ['application/pdf', 'image/tiff', 'image/jpeg', 'image/png', 'image/gif', 'text/plain', 'text/html', 'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-word.document.macroEnabled.12', 'application/vnd.ms-word.document.macroEnabled.12', 
  'application/vnd.ms-outlook', 'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.ms-powerpoint.template.macroEnabled.12',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel.sheet.macroEnabled.12', 'audio/mpeg', 'video/mp4', 'video/webm', 'video/ogg', 'image/vnd.dwg', 'text/xml', 'application/octet-stream'];
  DownloadViewer.acceptedObjectTypes = [];
   
	// Default View.
    DownloadViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/downloadViewer",
    initialize: function(options){
      this.documentId = options.documentId;
      this.contentURL = app.serviceUrlRoot + '/content/content?id=' + this.documentId + '&download=true';
    },
    serialize: function(){
      return {    
        contentURL : this.contentURL
      };
    },
  });
  // Return the module for AMD compliance.
  return DownloadViewer;
});