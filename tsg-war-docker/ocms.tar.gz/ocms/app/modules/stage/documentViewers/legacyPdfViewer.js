// Docviewer module
define([
  // Application.
  "app"
],
// Map dependencies from above array.
function(app) {
  "use strict";

  // Create a new module.
  var LegacyPdfViewer = app.module();
  LegacyPdfViewer.priority = 6;
  LegacyPdfViewer.mimeTypes = ['application/pdf', 'video/mp4', 'image/gif', 'image/jpeg', 'image/png', 'text/plain'];
  LegacyPdfViewer.acceptedObjectTypes = [];
   
	// Default View.
    LegacyPdfViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/legacyPdfViewer",
    className: "fullHeight",
    initialize: function(options){
      this.documentId = options.documentId; //already an observable
      this.contentURL = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(this.docName) + "?id=" +
          this.documentId + "&overlay=true" + "&contentType[]=" + ["pdf", ".*"];
    },
    serialize: function(){
      return {    
        contentURL : this.contentURL,
      };
    },
  });
  // Return the module for AMD compliance.
  return LegacyPdfViewer;

});