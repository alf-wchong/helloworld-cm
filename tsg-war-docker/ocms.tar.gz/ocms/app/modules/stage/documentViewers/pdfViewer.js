// Docviewer module
define([
  // Application.
  "app"
],
// Map dependencies from above array.
function(app) {
  "use strict";

  // Create a new module.
  var PdfViewer = app.module();
  PdfViewer.priority = 3;
  PdfViewer.mimeTypes = ['application/pdf'];
  PdfViewer.acceptedObjectTypes = [];
   
  // Default View.
  PdfViewer.Views.Viewer = Backbone.Layout.extend({
    template: "stage/documentViewers/pdfViewer",
    className: "fullHeight",
    initialize: function(options){
      this.documentId = options.documentId; //already an observable
      this.showAnnotations = options.showAnnotations;
      this.hideOpenFileBtn = options.hideOpenFileBtn;
      this.hideDownloadBtn = options.hideDownloadBtn;
      this.hidePrintBtn = options.hidePrintBtn;
      this.hideDocumentPropertiesBtn = options.hideDocumentPropertiesBtn;

      var docName = this.options.docName.replace(/\//g, '_');
      docName = docName.replace(/\\/g, "_");
      this.contentURL = encodeURIComponent(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(docName) + "?id=" +
                    this.documentId + "&overlay=true" + "&contentType" + encodeURIComponent("[]") + "=" + ["pdf",".*"]);
      if(this.options.docName.indexOf(".pdf") === -1){
        this.contentURL += encodeURIComponent(".pdf");
      }
      this.contentURL += "&hideOpenFileBtn=" + this.hideOpenFileBtn;
      this.contentURL += "&hideDownloadBtn=" + this.hideDownloadBtn;
      this.contentURL += "&hidePrintBtn=" + this.hidePrintBtn;
      this.contentURL += "&hideBookmarkBtn=" + this.hideBookmarkBtn;
      this.contentURL += "&hideDocumentPropertiesBtn=" + this.hideDocumentPropertiesBtn;
    },
    serialize: function(){
        return {
          contentURL : this.contentURL,
          root: app.root
        };
    },
  });

  // Return the module for AMD compliance.
  return PdfViewer;
});