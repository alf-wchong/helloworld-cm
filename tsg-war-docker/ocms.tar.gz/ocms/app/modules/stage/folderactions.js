// Actionmenus module
define([
	// Application.
	"app",
	"modules/common/action", 
	"modules/common/actionservice", 
	"modules/stage/folderactionseventmanager"
],

// Map dependencies from above array.
function(app, Action, ActionService, FolderActionsEventManager) {
	'use strict';

	var FolderActions = app.module();

	//Main layout of FolderAction View
	FolderActions.Views.Layout = Backbone.Layout.extend({
		template: "stage/folderactions",
		events: {
			"click #collapseActionHeader" : "toggleActionHeader"
		},
		initialize: function() {
			this.config = this.options.stageViewModel.stageConfig.get("folderActionConfig");
			this.rendered = false;
			this.loading = true;
			this.actionLauncher = new ActionService.ActionLauncher();
			this.previousView = "";
		},
		refreshActionViews: function(){
			this.actionLauncher = new ActionService.ActionLauncher();
			this.buildActionViews();
		},
		buildActionViews: function(){
			this.actionGroups = [];
			this.actionGroupDeferreds = [];
			//Iterate over all configured action groups
			_.each(this.config.get("actionGroups").models, function(actionGroup, index){
				//Create actionGroup object with extended props in the actionGroups array, adding a new
				//prop called 'evaluate' which will store the 'getAvailableActions' deferred
				this.actionGroups[index] = _.extend({}, actionGroup.attributes, {
					evaluate: this.actionLauncher.getAvailableActions(actionGroup, this.options.stageViewModel.containerId())
				});
				//Set returned deferred on our actionGroupDeferreds array for later evaluation
				this.actionGroupDeferreds.push(this.actionGroups[index].evaluate);
				//Once a single deferred is resolved, set filterd actions on actionGroup object in array
				//and iterate over each action returned to create the action views
				$.when(this.actionGroups[index].evaluate).done($.proxy(function(filteredActions){
					this.removeView("#action-outlet-" + this.actionGroups[index].idLabel);
					this.actionGroups[index].actions = filteredActions; 
					_.each(this.actionGroups[index].actions.models, _.bind(function(action, actionIdx){
						var actionView = new FolderActions.Views.Action({model: action, config: this.actionGroups[index].actions.configs[actionIdx], actionLauncher: this.actionLauncher});
						//If idLabel prop to refrence when creating the view has spaces, replace with _ 
						this.actionGroups[index].idLabel = this.actionGroups[index].label.replace(/ /g,"_");
						this.insertView("#action-outlet-" + this.actionGroups[index].idLabel, actionView);
					}, this));
				}, this));
			}, this);

			// Once all actionGroup deferreds resolve, fire a Layout rerender (if Layout is already rendered)
			$.when.apply($, this.actionGroupDeferreds).then($.proxy(function() {
				if(this.rendered){
					this.loading  = false;
					this.render();
				}
		    }, this));
		},
		_startListening: function() {
			this._stopListening();
			//When the window is resized, toggle leftSide bar
			this.listenTo(app, "stage.windowResizePanes", _.bind(function(){
				this.resizeLeftSidePanes(false);
			}, this));

			//Listens for "action click" (either via direct click, autoLaunch, or directLaunch)
			//to and clears CSS from the actions by removing 'activeFolder' class
        	this.listenTo(FolderActionsEventManager,  "folderactions:action:click",this.folderActionClickTrigger);

			//Refetch and render folder action views
			//Listens for execution of an action and trigger refresh and render of actions
        	this.listenTo(app, "action:execute", function(){
				this.loading = true;
				this.buildActionViews();	
			});

			this.listenTo(app, 'folder.actions.refresh',this.refreshActionViews);
		},
		folderActionClickTrigger: function() {
			_.each(this.$("#collapseActions").find(".list-group-item"), function(actionElement){
				$(actionElement).removeClass('activeFolder');	
			}, this);
		},
		resizeLeftSidePanes: function(renderTriggered){
			//if on a large screen then expand leftbar
            if(window.innerWidth > 991){
            	$("#objects-actions-sidenav").css("margin-top", "0px");
            	$('#stageInfo').show();
            	//If this view was previously small (or has never been resized), or we triggering this in afterRender
            	//Toggle the folder actions view
            	if((this.previousView === "small" || this.previousView === "") || renderTriggered){
            		$('#collapseActions').height('auto');
            		this.$("#collapseActions").addClass('in');
            		this.$("span.glyphicon").removeClass('glyphicon-chevron-down');
					this.$("span.glyphicon").addClass('glyphicon-chevron-up');
	            	this.previousView = "large";
            	}
            } else {
            	//if on a smaller screen then collapse the leftBar
            	app.trigger("toggleLeftBar", true);
            	//If this view was previously large (or has never been resized), or we triggering this in afterRender
            	//Toggle the folder actions view
            	if((this.previousView === "large" || this.previousView === "") || renderTriggered){
            		this.$("#collapseActions").removeClass('in');
            		this.$("span.glyphicon").removeClass('glyphicon-chevron-up');
					this.$("span.glyphicon").addClass('glyphicon-chevron-down');
            		this.previousView = "small";
            	}
            }
		},
		_stopListening: function(){
			this.stopListening();
		},
		cleanup: function() {
			this._stopListening();
		},
		toggleActionHeader: function(){ 
			if(this.$("span.glyphicon").hasClass('glyphicon-chevron-up')){
				this.$("span.glyphicon").removeClass('glyphicon-chevron-up');
				this.$("span.glyphicon").addClass('glyphicon-chevron-down');
			} else {
				this.$("span.glyphicon").removeClass('glyphicon-chevron-down');
				this.$("span.glyphicon").addClass('glyphicon-chevron-up');	
			}
		},
		serialize: function() {
			return {
				actionGroups: this.actionGroups,
				hasActionGroups: _.size(this.actionGroups) > 0,
				loading: this.loading
			};	
		},
		afterRender: function() {
			//Loop over actionGroups, generate action views, render
			if(!this.rendered){
				this.buildActionViews();
			}
		 	this.resizeLeftSidePanes(true);
			this.rendered = true;
		    this._startListening();	
		}
	});

	// Views for each individual action
	FolderActions.Views.Action = Backbone.Layout.extend({
		template: 'stage/folderactionviews',
		events: {
			"click .list-group-item" : "launchAction"
		},
		initialize: function(options){
			this.actionModel = options.model;
			this.actionConfig = options.config;
			this.actionLauncher = options.actionLauncher;
		},
		launchAction: function(){
			// Tell ActionLauncher to launch this actionmodel
			this.actionLauncher.launchAction(this.actionModel, this.actionConfig);
			this.makeLaunchedActionActive();
		},
		_startListening: function(){
			// Listen for ActionLauncher to autoLaunch a configured action. Make autoLaunched action 'active'
			this.listenTo(FolderActionsEventManager, 'autoLaunch', function(){
				this.makeLaunchedActionActive();
			});
		},
		_stopListening: function(){
			this.stopListening();
		},
		cleanup: function(){
			this._stopListening();
		},
		makeLaunchedActionActive: function(){
			//If this actionModel is the action that is currently launched, 
			//add the 'activeFolder' class for CSS changes
			if(this.model.get("actionId") === this.actionLauncher.getLaunchedActionId()){
				this.$(".list-group-item").addClass('activeFolder');
			}
		},
		afterRender: function(){
			this.makeLaunchedActionActive();
			this._startListening();
		},
		serialize: function() {
			return {
				action: this.actionConfig
			};
		}	
	}); 

	return FolderActions;
});