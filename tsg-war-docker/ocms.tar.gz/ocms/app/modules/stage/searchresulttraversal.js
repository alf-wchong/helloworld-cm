// Header module
define([
        // Application.
        "app"
    ],

    // Map dependencies from above array.
    function(app) {

        // Create a new module.
        var SearchResultTraversal = app.module();

        SearchResultTraversal.latestResults = [];
        SearchResultTraversal.currentPlaceInResults = -1;

        SearchResultTraversal.View = Backbone.Layout.extend({
            template: "stage/searchresulttraversal",
            events: {
                'click #nextResult': "nextDocument",
                'click #lastResult': "previousDocument",
                'blur #currentDocInput': "inputBlur",
                'keyup #currentDocInput': "checkEnter"
            },
            initialize: function() {
                if (window.localStorage.getItem('latestResults')) {
                    SearchResultTraversal.latestResults = JSON.parse(window.localStorage.getItem('latestResults'));
                    if (app.context.document.get('objectId')) {
                        SearchResultTraversal.currentPlaceInResults = SearchResultTraversal.latestResults.indexOf(app.context.document.get('objectId'));
                    } else {
                        SearchResultTraversal.currentPlaceInResults = SearchResultTraversal.latestResults.indexOf(app.context.container.get('objectId'));
                    }
                }
            },
            nextDocument: function() {
                if (SearchResultTraversal.currentPlaceInResults === SearchResultTraversal.latestResults.length) {
                    return;
                }

                // Adding one to the currentPlaceInResults index
                SearchResultTraversal.currentPlaceInResults += 1;
                // Navigating to the object
                this.navigateToObject(SearchResultTraversal.currentPlaceInResults);
            },
            previousDocument: function() {
                //This is incremented when we serialize, making it the first document in the list
                if (SearchResultTraversal.currentPlaceInResults === 0) {
                    return;
                }

                // Subtracting one to the currentPlaceInResults index
                SearchResultTraversal.currentPlaceInResults -= 1;
                // Navigating to the object
                this.navigateToObject(SearchResultTraversal.currentPlaceInResults);
            },
            checkEnter: function(evt) {
                // If the enter keycode, pass on to inputBlur
                if (evt.keyCode === 13) {
                    this.inputBlur(evt);
                }
            },
            inputBlur: function(evt) {
                // NOTE: The second parameter here is optional, yet good practice.  The 10 represents decimal.
                // 16 would be hexadecimal, etc.
                // Subtract 1 to make it 0 based index instead of the 1 based index the textBox has
                var indexChosen = parseInt(evt.target.value, 10) - 1;

                // Checking if the current indexChosen is a valid number, ie is it greater than or equal to
                // zero and is it less than the length of the results. If true, it is a valid, in range choice
                // If a value outside of the range is selected, don't change the number.
                if (indexChosen >= 0 && indexChosen < SearchResultTraversal.latestResults.length) {
                    // Valid value chosen
                    //If it's the same, just stay.
                    if (indexChosen !== SearchResultTraversal.currentPlaceInResults) {
                        // indexChosen is valid, setting currentPlaceInResults to indexChosen
                        SearchResultTraversal.currentPlaceInResults = indexChosen;
                        this.navigateToObject(indexChosen);
                    }
                } else {
                    // Invalid value chosen
                    // Convert currentPlaceInResults back to a 1 based index, convert it to a string and set it
                    // to the currentDocInput
                    $('#currentDocInput').val((SearchResultTraversal.currentPlaceInResults + 1).toString());
                }
            },
            navigateToObject: function(currentPlaceInResults) {
                // Grab the objectId out of latestResults
                var objectId = SearchResultTraversal.latestResults[currentPlaceInResults];
                // Determine the trac
                var trac = app.context.configName();
                // Navigate to the doc using stageSimple
                app.routers.main.stageSimple(objectId, {'trac':trac});
            },
            serialize: function() {
                return {
                    // currentDocNumber is a 1 based index, it is equal to currentPlaceInResults (which is 0 based) + 1
                    currentDocNumber: SearchResultTraversal.currentPlaceInResults + 1,
                    // totalNumberOfDocs is just the length of the latestResults 
                    totalNumberOfDocs: SearchResultTraversal.latestResults.length,
                    // if the currentPlaceInResults is 0 (because 0 is the first index), disable the back button
                    disableBack: SearchResultTraversal.currentPlaceInResults === 0,
                    // if the currentPlaceInResults + 1 is greater than the length of latestResults, it's out of bounds
                    // and needs to be disabled
                    disableNext: SearchResultTraversal.currentPlaceInResults + 1 === SearchResultTraversal.latestResults.length,
                    // if latestResults is greater than 1 and there is a currentPlaceInResults that is valid (greater than -1)
                    // resultsExist is true
                    resultsExist: (SearchResultTraversal.latestResults.length > 1 && SearchResultTraversal.currentPlaceInResults > -1) ? true : false
                };
            }
        });

        // Return the module for AMD compliance.
        return SearchResultTraversal;

    });