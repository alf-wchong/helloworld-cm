define([
    "app",
    'oc',
    "modules/hpiadmin/hpiadmin-switcher",
    "modules/hpiadmin/hpiadmin",
    "modules/common/tossacross"
],

function(app, OC, Switcher, Hpiadmin, TossAcross) {

    var aclConfig = app.module();
    aclConfig.Model = Hpiadmin.Config.extend({
        type: "aclConfig",
        defaults: {
            type: "aclConfig"
        }
    });

    aclConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/aclconfig/aclconfig",
        className: "aclConfig",
        initialize: function(options) {
            var self = this;
            this.aclsView = new aclConfig.Acls();
            this.setView('#groups-outlet', this.aclsView);
         
            this.listenTo(app, "addAcl", function(aclToAdd){
                $.ajax({type: "POST", url: app.serviceUrlRoot + "/security/createAcl?aclName=" + aclToAdd, 
                    success: function(results){
                        self.aclsView.populateAcls();
                        app.trigger("alert:close");
                    },
                    error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to add the acl. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    }    
                });
            });
            //Passes groupName to User's outlet to display Users for selected Group
            this.listenTo(this.aclsView, "acl-selected", function(acl){
                this.setView('#permissions-outlet', new aclConfig.Permissions({"acl": acl})).render();
            });           
    }});

 aclConfig.Acls = Backbone.Layout.extend({
        template: "hpiadmin/aclconfig/acls",
        events: {
            'click #new-acl-button': 'onClickAdd',
            "keyup .acls-filter": "filterResults",
            'click .list-group-item': 'onClickAcl'
        },
        initialize: function(options) {
            this.acls = [];
            this.populateAcls();
        },
        populateAcls: function() {
            var self = this;

            $.ajax(
            {
                url: app.serviceUrlRoot + "/security/getAcls", 
                type: "GET",
                contentType: "application/json",
                success: function(result) {
                    self.acls = [];
                    _.each(result,function(acl){
                        self.acls.push({
                            "aclName": acl.aclName,
                            "id": acl.aclId,
                            "userPermissions": acl.userPermissions,
                            "groupPermissions": acl.groupPermissions
                        });
                    });
                    self.filteredAcls = self.acls;
                    self.render();
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app.trigger("alert:error", {
                        message: "An unexpected error occured when trying to find the ACL's. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                    });
                },
                global: true    
            }); 
        },
        onClickAcl: function(options){
            var self =this;
            $('.list-group-item').removeClass('acl-active');
            $(options.currentTarget).addClass('acl-active');
            var aclName = options.currentTarget.innerText;
            var index = _.findWhere(this.acls,{aclName: aclName});
            self.trigger("acl-selected", index);   
        },

        onClickAdd: function(options) {
            var addAcl = new aclConfig.AddAclView(this.acls);
            app.trigger('alert:custom', {
                view: addAcl
            }); 
        },
        filterResults: _.debounce(function(event) {
            var self = this;
            self.filterText = $(event.target).val().toLowerCase();
            var unfilteredAcls = this.acls;
                this.filteredAcls = _.filter(unfilteredAcls, function(model) {
                    return model.aclName.toLowerCase().indexOf(self.filterText) === 0;
                });
            self.render();
        }, 400),
        afterRender: function() {
            if(this.filterText) {
                var filterInputBox = this.$(".acls-filter");
                filterInputBox.val(this.filterText).focus();
            }

            var newHeight = window.innerHeight - this.$('.groups-collection').offset().top - 
                            parseInt(this.$('.groups-collection').css('padding-top'),10) - 
                            parseInt(this.$('.groups-collection').css('margin-top'),10) -
                            parseInt(this.$('.groups-collection').css('border-top'),10);
            var paddingHeight = parseInt(this.$('.groups-collection').css('padding-top'),10) + parseInt(this.$('.groups-collection').css('padding-bottom'),10);
            var marginHeight = parseInt(this.$('.groups-collection').css('margin-top'),10) + parseInt(this.$('.groups-collection').css('margin-bottom'),10);
            var borderHeight = parseInt(this.$('.groups-collection').css('border-top'),10) + parseInt(this.$('.groups-collection').css('border-bottom'),10);
            newHeight = newHeight - borderHeight - marginHeight - paddingHeight;
            this.$('.groups-collection').height(newHeight);
        },
        serialize: function() {
            return {
                "acls": this.filteredAcls
            };
        }
    });

 aclConfig.AddAclView = Backbone.Layout.extend({
        template: "hpiadmin/aclconfig/addAcl",
        events: {
            'keyup #new-config-aclName': 'update', 
            'click #new-config-acl-save': 'addAcl'
        },

        initialize: function(options) {
            this.options = options;
            this.currentAcls = this.options;
            this.query = "";
            this.checkAclName();
        },

        update: _.debounce(function(event) {
            this.inputText = this.$(event.currentTarget).val();
            this.checkAclName();
        }),

        checkAclName: function() {
            var self =this;
            var filteredAcls = _.filter(self.currentAcls, function(checkAcl){
                return self.inputText === checkAcl.aclName;
            });

            if (filteredAcls.length > 0){
                $('#new-config-acl-save').attr("disabled", true);
                this.$('.group-error-message-output').text('ACL ' + self.inputText + " already exists");
            }
            else if(self.inputText ==="" ){
                $('#new-config-acl-save').attr("disabled", true);
                this.$('.group-error-message-output').text("Please enter a ACL Name");
            }
            else{
                $('#new-config-acl-save').attr("disabled", false);
                this.$('.group-error-message-output').text('');            
            }
        },

        addAcl: function(){
            var aclName = $('#new-config-aclName').val();
            app.trigger("addAcl", aclName);
        }
    });

    aclConfig.Permissions =  Backbone.Layout.extend({
        template: "hpiadmin/aclconfig/permissions", 
        events: {
            'click #add-permissions-button': 'onClickAddPermissions',
            'click .remove-permission-button': 'onClickRemovePermission',
            'change .permissionSelector': 'updatePermissions',
            'click #save-permissions': 'savePermissions'
        },
        initialize: function(options) {
            this.options = options;
            this.acl = options.acl;
            
            this.listenTo(app, "addGroups", function(userPermissions,groupPermissions)
            {
                this.acl.userPermissions = userPermissions;
                this.acl.groupPermissions = groupPermissions;
                this.render();
            });
        },
        savePermissions: function(){
            var self= this;
            var data = {
                "userPermissions": this.acl.userPermissions,
                "groupPermissions": this.acl.groupPermissions
            };
            $.ajax({
                type: "POST", 
                url: app.serviceUrlRoot + "/security/updateAcl?aclId=" + this.acl.id,
                contentType: "application/json",
                data: JSON.stringify(data),    
                success: function(results){
                    self.render();
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app.trigger("alert:error", {
                        message: "An unexpected error occured when trying to update the ACL. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                    });
                }    
            });
        },
        updatePermissions: function(event){
            var selectedIndex = event.target.selectedIndex;
            this.acl.groupPermissions[event.target.id] = selectedIndex + 1;
        },
        onClickAddPermissions: function(event) {
            var addAcl = new aclConfig.AddGroupUserView({
                "aclName": this.acl.aclName,
                "existingGroupPermissions": this.acl.groupPermissions,
                "existingUserPermissions": this.acl.userPermissions
            });

            app.trigger('alert:custom', {
                view: addAcl,
                width: 900
            });
        },
        onClickRemovePermission: function(event) {
            var currentId = event.currentTarget.id;
            _.each(this.acl.groupPermissions, function(value, index, groupPermissions){
                if("remove-"+ index === currentId){
                    delete groupPermissions[index];
                }
            });
            this.render();
        },
        afterRender:function(){
            for(var key in this.acl.groupPermissions){
                if (this.acl.groupPermissions.hasOwnProperty(key)) {
                    //Writting the selector in this format to handle any group names that have
                    //special JQuery selector characters
                    $("[id='" + key + "']")[0].selectedIndex = this.acl.groupPermissions[key] - 1;
                }
            }

            var newHeight = window.innerHeight - this.$('.groups-collection').offset().top - 
                            parseInt(this.$('.groups-collection').css('padding-top'),10) - 
                            parseInt(this.$('.groups-collection').css('margin-top'),10) -
                            parseInt(this.$('.groups-collection').css('border-top'),10);
            var paddingHeight = parseInt(this.$('.groups-collection').css('padding-top'),10) + parseInt(this.$('.groups-collection').css('padding-bottom'),10);
            var marginHeight = parseInt(this.$('.groups-collection').css('margin-top'),10) + parseInt(this.$('.groups-collection').css('margin-bottom'),10);
            var borderHeight = parseInt(this.$('.groups-collection').css('border-top'),10) + parseInt(this.$('.groups-collection').css('border-bottom'),10);
            newHeight = newHeight - borderHeight - marginHeight - paddingHeight;

            this.$('.groups-collection').height(newHeight);
        },
        serialize: function() {
            return {
                "aclName": this.acl.aclName,
                "groupPermissions": this.acl.groupPermissions
            };
        }
    }); 

    aclConfig.AddGroupUserView = Backbone.Layout.extend({
        template: "hpiadmin/aclconfig/addgroupuser",
        events: {
            'click #add-groups': 'addGroups',
            'keyup .filter-permissions': 'filterResults'
        },
        initialize: function(options) {
            this.options = options;
            this.aclName = this.options.aclName;

            this.existingGroupPermissions = this.options.existingGroupPermissions;
            this.existingUserPermissions = this.options.existingUserPermissions;
            this.sourcePermissions = new Backbone.Collection();
            this.targetPermissions = new Backbone.Collection();

            this.targetPermissions.on("change add remove", this.checkTarget, this);
            this.getGroups();
            this.checkTarget();
            this.populateTossAcross(this.sourcePermissions, this.targetPermissions);
        },
        checkTarget: function(){
            if(this.targetPermissions.length > 0) {
                this.$('#add-groups').removeClass('disabled');
            }
            else {
                this.$('#add-groups').addClass('disabled');
            }
        },
        populateTossAcross: function(sourcePermissions, targetPermissions){
           var attributesTossAcross = new TossAcross.Layout({
                srcCollection: {
                    title: 'Available Groups',
                    clickAcross: true,
                    labelAttr: 'displayName',
                    collection: sourcePermissions
                },
                targetCollections: [{
                    title: 'Groups To Add',
                    labelAttr: 'displayName',
                    clickAcross: true,
                    collection: targetPermissions
                }]
            });

            // Set view and render
            this.setView("#users-tossacross-outlet", attributesTossAcross).render();
        },
        getGroups: function(event){
            var self = this;
             var requestObj = {
                "authorityType": "group"
            };
            $.ajax({
                url: app.serviceUrlRoot + "/authorities/search", 
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                    success: function (result) {
                        var permissions = new Backbone.Collection();
                        var existingSelectedPermissions = self.targetPermissions.pluck("displayName"); 
                        _.filter(result, function(group) {
                            if(!self.existingGroupPermissions.hasOwnProperty(group.authorityId) && !self.existingUserPermissions.hasOwnProperty(group.authorityId) &&
                                !_.contains(existingSelectedPermissions, group.authorityId)) {
                                    permissions.push({
                                        "displayName" : group.displayName,
                                        "id": group.authorityId
                                    });
                                }
                        });
                        self.sourcePermissions = permissions;
                        self.unfilteredPermissions = self.sourcePermissions.models;
                        self.populateTossAcross(self.sourcePermissions, self.targetPermissions);
                    },
                     error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to search for groups. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    },
                global : false
            });
        },
         filterResults: _.debounce(function(event) {
            var self = this;
            self.filterText = $(event.target).val().toLowerCase();
            var filteredPermissionModels = _.filter(self.unfilteredPermissions, function(model) {
                if(_.findWhere(self.targetPermissions.models,model)){
                    return false;
                }else{
                    return model.id.toLowerCase().indexOf(self.filterText) === 0;
                }
            });
             this.sourcePermissions.models = filteredPermissionModels;
            self.populateTossAcross(this.sourcePermissions,self.targetPermissions);
        }, 400),
        addGroups: function() {
            var self = this;
            var permissionsToAdd= this.targetPermissions.pluck("id");
            _.each(permissionsToAdd, function(val){
                self.existingGroupPermissions[val]= 1;
            });
            app.trigger('addGroups', self.existingUserPermissions, this.existingGroupPermissions);

        }
    });

    return aclConfig;
});     