// Typeattributes module
define([
	// Application.
	"app",

	"modules/hpiadmin/otc/objecttypeconfig"
],

// Map dependencies from above array.
function(app, Otc) {

	// Create a new module.
	var Typeattributes = app.module();

	//Submodel
	Typeattributes.Model = Backbone.RelationalModel.extend({
			defaults : function() {
				return {
					"objectType" : "",
					"attrs" : []
				};
			}
	});
	
	// Default Collection.
	Typeattributes.Collection = Backbone.Collection.extend({
		model: Typeattributes.Model
	});

	Typeattributes.ViewModel = function(collection, options) {
			
		var self = this;

		self.attributesVisible = ko.observable(false);
		self.configuredTypes = kb.collectionObservable(collection);

		//grab our potential type names from the top level config, and use the config
		//service to get their full set of attributes
		self.potentialTypes = ko.observableArray();

		app.context.configService.getAdminOTC(function(otc) {
			otc.get("configs").each(function(config) {
				//push all available configs onto the potential types array
				self.potentialTypes.push(config);
			});
		});

		//this computed variable determines which types have been configured 
		self.filteredConfigTypes = ko.computed(function() {
			var typesToShow = [];

			//look at each type in the OTConfig we pulled down above
			_.each(self.potentialTypes(), function(potentialType) {
				//the map call flattens the configuredTypes collectionObservable into
				//an array of strings which are the configured objectTypes
				//then see if the current potentialType's object Type is a part of the array
				//if it is, we do not push it to the types to show array
				if(! _.contains(_.map(self.configuredTypes(), 
						function(viewModel){ return viewModel.objectType(); }), 
						potentialType.get("ocName")) ) {
					typesToShow.push(potentialType);
				}
			});

			return typesToShow;
		}, self);

		self.selectedType = ko.observable();

		// when a type is selected... lets grab the possible attributes
		self.potentialAttrs = ko.observableArray();
		self.selectedType.subscribe(function(selectedType) {
			self.potentialAttrs.removeAll();
			if (selectedType) {
				app.context.configService.getAdminTypeConfig(selectedType.get("ocName"), function(typeConfig) {
					typeConfig.get("attrs").each(function(attr) { 
						self.potentialAttrs.push(attr.get("ocName"));
					});
				});
			}
		});

		self.selectedAttrs = ko.observableArray();

		self.addType = function() {

			var typeAttributes = new Typeattributes.Model({
				objectType : self.selectedType().get("ocName"),
				attrs : _.clone(self.selectedAttrs())
			});

			self.selectedAttrs.removeAll();

			collection.add(typeAttributes);
		};

		self.deleteType = function(typeAttributesVM) {

			var type = typeAttributesVM.model();

			collection.remove(type);
		};

		self.showAttrs = function() {
			if (self.attributesVisible()) {
				self.attributesVisible(false);
			} else {
				self.attributesVisible(true);
			}
		};
	};

	// Default View.
	Typeattributes.Views.Layout = Backbone.Layout.extend({
		//className: "modal hide fade",
		template: "hpiadmin/typeattributes",

		initialize: function() {
			this.viewModel = new Typeattributes.ViewModel(this.collection, this.options);
		},

		afterRender: function() {

			kb.applyBindings(this.viewModel, this.$el[0]);
		}
	});

	// Return the module for AMD compliance.
	return Typeattributes;

});
