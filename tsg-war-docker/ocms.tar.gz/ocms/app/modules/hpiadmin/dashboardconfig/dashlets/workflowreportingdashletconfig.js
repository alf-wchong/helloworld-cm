define(['app',
		'modules/hpiadmin/dashboardconfig/basedashconfig'
], function(app, BaseDashConfig){

	var WorkflowReportingDashletConfig = app.module();

	WorkflowReportingDashletConfig.Model = BaseDashConfig.DashletModel.extend({
		defaults: function() {
			return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
				{
					dashletType: "WorkflowReportingDashlet",
					showMyWorkflows: "",
					showWorkflowHistory: "",
					showGroupTasks: "",
					allowUserVisibilityControl: false
			});
		}
	});

	WorkflowReportingDashletConfig.View = BaseDashConfig.ConfigView.extend({
		template: "hpiadmin/dashboardconfig/dashlets/workflowreportingdashletconfig",
		events: {
			"click .dashlet-toggle": "toggleDashlet",
			"click .dashlet-delete" : "dashletDelete",
			"change #dashletName" : "setDashletName",
			"change #dashletId" : "setDashletId",
			"change #picklistGroups" : "getSelectedPickList",
			"change #wfreportingDisableUserVisibilityControl": "setUserPreferencesControl"
		},
		initialize: function(options){
			var self = this;

			//this is important to setup the security view in the core dashlet view
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);
			
			this.individualDashlet = options.individualDashlet || null;

			this.dashletType = options.dashletType || null;
			// the text to display to inform the user what kind of dashlet this is
			this.dashletDisplayType = "Workflow Reporting";
			this.showMyWorkflows = kb.observable(this.individualDashlet, "showMyWorkflows");
			this.showWorkflowHistory = kb.observable(this.individualDashlet, "showWorkflowHistory");
			this.showGroupTasks = kb.observable(this.individualDashlet, "showGroupTasks");
			this.attrToShow = kb.observable(this.individualDashlet, "attrToShow");
			this.numPerPage = kb.observable(this.individualDashlet, "numPerPage");
			
            this.allowUserVisibilityControl = kb.observable(this.individualDashlet, "allowUserVisibilityControl");

			
			if(this.numPerPage() === undefined || this.numPerPage() === null) {
				this.numPerPage(20);
			}

			if(this.attrToShow() === undefined || this.attrToShow() === null) {
				this.attrToShow("");
			}
			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 

			//start with a blank element
			this.availablePicklists = [""];
			this.selectedPicklist = "";

			$.when(app.context.configService.getPicklistServices()).done(function(){
				_.each(app.context.currentPicklistConfig().get("picklists").models, function(picklist){
					self.availablePicklists.push(picklist.get('label'));
				});
			});

		},
		toggleDashlet: function(event) {
			if(this.contentVisibility) {
               this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function() {
			this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#wfreportingDisableUserVisibilityControl").is(":checked"));
		},
		getSelectedPickList: function(event){
			this.options.individualDashlet.set("selectedPicklist",event.target.value);
			this.selectedPicklist = event.target.value;
			this.render();
		},
		setDashletId: function() {
			this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
        serialize: function() { 
            return { 
                "controlChevron": this.iconChevron,
                "controlVisibility" : this.contentVisibility,
                "dashletId" : this.options.individualDashlet.get("dashletId"),
				"dashletName" : this.options.individualDashlet.get("dashletName"),
				"availablePicklists" : this.availablePicklists,
				"selectedPicklist" : this.options.individualDashlet.get("selectedPicklist"),
				"visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl"),
            };
        }
	});

	return WorkflowReportingDashletConfig;
});