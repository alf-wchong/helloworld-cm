define(['app',
		'modules/hpiadmin/dashboardconfig/basedashconfig'
], function(app, BaseDashConfig){

	var IncompleteTagDashlet = app.module();

	IncompleteTagDashlet.Model = BaseDashConfig.DashletModel.extend({
		defaults: function() {
			return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
				{
					dashletType: "IncompleteTagDashlet",
					showMyWorkflows: "",
					showWorkflowHistory: "",
					allowUserVisibilityControl: false
			});
		}
	});

	IncompleteTagDashlet.View = BaseDashConfig.ConfigView.extend({
		template: "hpiadmin/dashboardconfig/dashlets/incompletetagdashletconfig",
		events: {
			"click .dashlet-toggle": "toggleDashlet",
			"click .dashlet-delete" : "dashletDelete",
			"change #dashletName" : "setDashletName",
			"change #dashletId" : "setDashletId",
			'change #selectedType' : 'setType',
			'change #numResultsToShow' : 'setNumberOfResults',
			"change #incompleteTagDisableUserVisibilityControl": "setUserPreferencesControl"
		},
		initialize: function(options){

			//this is important to setup the security view in the core dashlet view
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);
			
			var self = this;
			self.dashletType = options.dashletType || null;
			// the text to display to inform the user what kind of dashlet this is
			self.dashletDisplayType = "Incomplete Tags";
			self.individualDashlet = options.individualDashlet || null;
			self.showMyWorkflows = kb.observable(self.individualDashlet, "showMyWorkflows");
			self.showWorkflowHistory = kb.observable(self.individualDashlet, "showWorkflowHistory");
			self.allowUserVisibilityControl = kb.observable(self.individualDashlet, "allowUserVisibilityControl");

			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 
		},
		toggleDashlet: function(event) {
			if(this.contentVisibility) {
               this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function() {
			this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
		setDashletId: function() {
			this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#incompleteTagDisableUserVisibilityControl").is(":checked"));
		},
		setType: function(event) {
			var value = this.$(event.currentTarget).attr('value');
			this.individualDashlet.set('type', value);
		},
		setNumberOfResults: function(event) {
			var value = this.$(event.currentTarget).attr('value');
			this.individualDashlet.set('numberResultsToShow', value);
		},
		getTypes: function() {
			var self = this;
			self.types = [];
			app.context.configService.getAdminOTC(function(freshOTC){
				_.each(freshOTC.get('configs').models, function(typeConfig){
					var selected = '';
					if (typeConfig.get('ocName') === self.individualDashlet.get('type')){
						selected = 'selected';
					}
					self.types.push({ocName: typeConfig.get("ocName"), label: typeConfig.get("label"), selected: selected});
				});
			});
		},
		getResultsToShowDropDownOptions: function(){
			var numResultsToShow = this.options.individualDashlet.get("numberResultsToShow");
			var options = [];
			var i = 5;
			for(i; i<11; i++){
				var selected = '';
				if(i == numResultsToShow){
					selected = 'selected';
				}
				options.push({ value: i, label: i, selected: selected});
			}

			return options;
		},
		beforeRender: function() {
			this.getTypes();	
		},
        serialize: function() { 
            return { 
				"controlChevron": this.iconChevron,
				"visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl"),
                "controlVisibility" : this.contentVisibility,
                "dashletId" : this.options.individualDashlet.get("dashletId"),
                "dashletName" : this.options.individualDashlet.get("dashletName"),
								"types" : this.types,
								"numberResultsToShowOptions" : this.getResultsToShowDropDownOptions()
            };
        }
	});

	return IncompleteTagDashlet;
});
