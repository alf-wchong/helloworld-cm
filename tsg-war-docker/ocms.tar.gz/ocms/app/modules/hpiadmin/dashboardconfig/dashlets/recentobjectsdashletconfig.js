define(['app',
		'modules/hpiadmin/otc/objecttypeconfig',
		'modules/hpiadmin/dashboardconfig/basedashconfig',
		'modules/common/tossacross'
], function(app, OTC, BaseDashConfig, TossAcross){

	var RecentObjectsDashletConfig = app.module();

	//util method for transforming primitive collections into full-fledged backbone.collections
	var convertToCollection = function(array){
		//return if collection is already a backbone collection
		if(array instanceof Backbone.Collection){
			return array;
		}else{ //otherwise, convert the primitive array to a backbone collection
			return new Backbone.Collection(array);
		}
	};

	RecentObjectsDashletConfig.Model = BaseDashConfig.DashletModel.extend({
		defaults: function() {
			return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
				{
					dashletType: "RecentObjectsDashlet",
					objectType: "",
					numberOfObjects: "",
					objectName: "",
					allowUserVisibilityControl: false
			});
		}
	});

	RecentObjectsDashletConfig.View = BaseDashConfig.ConfigView.extend({
		template: "hpiadmin/dashboardconfig/dashlets/recentobjectsdashletconfig",
		events: {
			'change .parentObjectTypes' : 'changeParentObjectType',
			'change .recentobjects-objectTypes' : 'changeSelectedObjectTypeForAttrs',
			'change #dashletName' : 'setDashletName',
			'change #dashletId' : 'setDashletId',
			'click .dashlet-delete' : 'dashletDelete',
			"click .dashlet-toggle": "toggleDashlet",
			"change #recentObjectDisableUserVisibilityControl": "setUserPreferencesControl"
		},
		initialize: function(options){
			var self = this;

			//this is important to setup the security view in the core dashlet view
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

			var individualDashlet = this.individualDashlet = options.individualDashlet || null;
			var dashletType = this.dashletType = options.dashletType || null;
			this.tracName = options.tracName || null;

			self.templateName = dashletType;
			// the text to display to inform the user what kind of dashlet this is
			self.dashletDisplayType = "Recent Objects";
			self.parentObjectType = kb.observable(individualDashlet, "parentObjectType");
			self.numberOfObjects = kb.observable(individualDashlet, "numberOfObjects");
			self.allowUserVisibilityControl = kb.observable(individualDashlet, "allowUserVisibilityControl");

			//listen for this to change - get adminOTC, update views accordingly
			self.selectedTypeForAttrs = individualDashlet.get('selectedTypeForAttrs');
			
			self.availableAttrs = new Backbone.Collection();

			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 
		},
		buildAttrsTossAcross: function(){
			var self = this;
			var recentobjectstossacross = '.recentobjects-attributes-tossacross';

			self.targetCollection = convertToCollection(self.individualDashlet.get("selectedAttributes"));
			self.listenTo(self.targetCollection, 'all', function(){
				//keep collection in sync
				//convert models to just the string types
				//collecting ocName / label from the selected attributes collection and mapping to an array
				var mappedTargetCollection = _.map(self.targetCollection.models, function(model) {
					return {
						label: model.attributes.label,
						ocName: model.attributes.ocName
					};
				});
				
				self.individualDashlet.set('selectedAttributes', mappedTargetCollection);
			});

			//if object type has changed, get a new tossacross view
			self.removeView(recentobjectstossacross);
			//build toss across widget
			self.attributesTossAcross = new TossAcross.Layout({
			    srcCollection: {
			        title: window.localize("modules.hpiAdmin.dashboardConfig.dashlet.recentObjectDashletConfig.availableAttrs"),
			        filter: true,
			        labelAttr: 'label',
			        valueAttr: 'ocName',
			        collection: self.availableAttrs
			    },
			    targetCollections: [
			        {
			            title: window.localize("modules.hpiAdmin.dashboardConfig.dashlet.recentObjectDashletConfig.selectedAttributes"),
			            labelAttr: 'label',
			            valueAttr: 'ocName',
			            collection: self.targetCollection
			        }
			    ]
			});
			//tossacross is just a backbone view
			self.setView(recentobjectstossacross, self.attributesTossAcross).render();
		},
		toggleDashlet: function(event) {
			if(this.contentVisibility) {
               this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function() {
			this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
		setDashletId: function() {
			this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#recentObjectDisableUserVisibilityControl").is(":checked"));
		},
		changeParentObjectType: function(e){
			this.render();
			this.changeSelectedObjectTypeForAttrs(e);
		},
		changeSelectedObjectTypeForAttrs: function(e){
			var self = this;
			//set to the ocName, nopt the label
			var value = this.$(e.currentTarget).attr('value');

			if(value !== this.selectedTypeForAttrs || this.selectedTypeForAttrs === ''){
				this.selectedTypeForAttrs = value;
				this.individualDashlet.set('selectedTypeForAttrs', this.selectedTypeForAttrs);
				//nuke selected attributes
				this.individualDashlet.set("selectedAttributes", []);
				//clear selected types - get attributes specific to new type
				//get all types, avalible types, then build the toss across
				this.updateAvailableAttributes().done(function(){
					self.buildAttrsTossAcross();
				});
			}
		},
		updateObjectTypes: function(){
			var self = this;
			var deferred = $.Deferred();
			//populate types for dropdown
			app.context.configService.getAdminOTC(function(freshOTC){
				self.objectTypes = self.objectTypes ? self.objectTypes.reset() : new Backbone.Collection();
				freshOTC.get("configs").each(function(typeConfig){
					//check whether the parent type is a folder or document
					if(self.parentObjectType() === "Folder") {
						if(typeConfig.get('isContainer') === 'true'){
							self.objectTypes.add({name: typeConfig.get("ocName"), label: typeConfig.get("label")});
						}
					}
					else {
						if(typeConfig.get('isContainer') === 'false'){
							self.objectTypes.add({name: typeConfig.get("ocName"), label: typeConfig.get("label")});
						}
					}
				}, this);
				//render object types
				var objectTypesOutlet = this.$('.recentobjects-objectTypes');
				objectTypesOutlet.empty();
				objectTypesOutlet.append($("<option></option>")
		        		   .attr("disabled", "disabled")
		        		   .attr("selected", "selected"));
				//render object types
				self.objectTypes.each(function(type){
					objectTypesOutlet.append($("<option></option>")
									.attr('value', type.get('name'))
			        				.text(type.get('label'))); 
				});

				//select the configured type if there is one
				objectTypesOutlet.val(self.selectedTypeForAttrs);
				deferred.resolve();
			}, this);
			return deferred.promise();
		},
		updateAvailableAttributes: function(){
			var self = this;
			var deferred = $.Deferred();
			//clear old attrs
			self.availableAttrs = self.availableAttrs ? self.availableAttrs.reset() : new Backbone.Collection();
			//careful here, send the ocName, not the label
			var ocName = this.selectedTypeForAttrs;
			app.context.configService.getTypeAttrs(ocName, function(attributes) {
				//update all attributes
				var tempAttrs = _.map(attributes, function(attribute) {
					return {'ocName' : attribute.ocName, 'label' : attribute.label};
				});
				var temporarySelectedAttrs = convertToCollection(self.individualDashlet.get("selectedAttributes"));
				temporarySelectedAttrs = temporarySelectedAttrs.pluck('ocName');

				_.each(tempAttrs, function(attr) {
					if(!_.contains(temporarySelectedAttrs, attr.ocName)) {
						self.availableAttrs.add(attr);
					}
				});

				deferred.resolve();
			}, this);
			return deferred.promise();
		},
		afterRender: function(){
			//don't break the parent afterRender
			BaseDashConfig.ConfigView.prototype.afterRender.apply(this, {});
			var self = this;
			
			//build object types
			this.updateObjectTypes().done(function(){
				if(self.selectedTypeForAttrs){
					self.updateAvailableAttributes().done(function(){
						self.buildAttrsTossAcross();
					});
				}
			});
		},
		serialize: function() { 
            return { 
                "controlChevron": this.iconChevron,
                "controlVisibility" : this.contentVisibility,
                "dashletId" : this.options.individualDashlet.get("dashletId"),
				"dashletName" : this.options.individualDashlet.get("dashletName"),
				"visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl")
            };
        }
	});
	return RecentObjectsDashletConfig;

});