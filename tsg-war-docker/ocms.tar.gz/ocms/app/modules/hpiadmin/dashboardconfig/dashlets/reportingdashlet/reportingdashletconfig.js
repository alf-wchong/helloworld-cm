define(['app',
        'modules/hpiadmin/otc/objecttypeconfig',
        'modules/hpiadmin/dashboardconfig/basedashconfig',
        'modules/common/tossacross',
        'modules/hpiadmin/dashboardconfig/dashlets/reportingdashlet/reportingqueryconfig'
], function(app, OTC, BaseDashConfig, TossAcross, ReportingQueryConfig){

    var ReportingDashletConfig = app.module();

    ReportingDashletConfig.Model = BaseDashConfig.DashletModel.extend({
        defaults: function() {
            return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
                {
                    dashletType: "ReportingDashlet",
                    isLink: "",
                    terms: new ReportingQueryConfig.Collection(),
                    selectedInfoBlockAttributes: [],
                    graphTitle: "",
                    graphType: "bar",
                    enableDateRange: true,
                    getAllDocsEnabled: false,
                    proximityDateNumber: "",
                    proximityDateTimeSpan: "",
                    proximityDateType: "",
                    proximityDateInterval: "",
                    showLegend: true,
                    referenceLineVal: "",
                    enableTrendLine: false,
                    varyColors: false,
                    stackedSeries: true,
                    xAxisLabel: "",
                    yAxisLabel: "",
                    jsonConfig: "",
                    allowUserVisibilityControl: false

            });
        },
        initialize: function(options){
            if(options && options.terms){
                this.set("terms", new ReportingQueryConfig.Collection(options.terms));
            } else {
                this.set("terms", new ReportingQueryConfig.Collection());
            }
        },
        parseResponse: function(response){
            if(this.id){
                //just want the id
                response = _.pick(response, 'id');
            } else if(response){
                if(response.terms){
                    this.set("terms", new ReportingDashletConfig.Collection(response.terms));
                    delete response.bulkIndexerConfig;
                }
            }
            return response;
        }
    });

    ReportingDashletConfig.View = BaseDashConfig.ConfigView.extend({
        template: "hpiadmin/dashboardconfig/dashlets/reportingdashlet/reportingdashletconfig",
        events: {
            "click .dashlet-header-toggle": "toggleDashlet",
            "click .dashlet-delete": "dashletDelete",
            "change #dashletName": "setDashletName",
            'change #dashletId' : 'setDashletId',
            "change #reportingDisableUserVisibilityControl": "setUserPreferencesControl"
        },
        initialize: function(options) {
            var self = this;

            //this is important to setup the security view in the core dashlet view
            BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

            var individualDashlet = this.individualDashlet = options.individualDashlet || null;
            var dashletType = this.dashletType = options.dashletType || null;

            self.templateName = dashletType;
            // the text to display to inform the user what kind of dashlet this is
            self.dashletDisplayType = "Reporting";
            self.criteria = kb.observable(individualDashlet, "criteria");
            self.terms = kb.observable(individualDashlet, "terms");

            this.iconChevron = "glyphicon glyphicon-chevron-down";
            this.contentVisibility = true; 
            this.infoBlockVisibility = false;

            self.allowUserVisibilityControl = kb.observable(individualDashlet, "allowUserVisibilityControl");

            // default to manual field config
            self.configurationMode = kb.observable(individualDashlet, "configurationMode");

            // graph configs
            self.graphTitle = kb.observable(individualDashlet, "graphTitle");
            self.graphType = kb.observable(individualDashlet, "graphType");
            self.enableDateRange = kb.observable(individualDashlet, "enableDateRange");
            self.getAllDocsEnabled = kb.observable(individualDashlet, "getAllDocsEnabled");

            self.dateRangeAttribute = kb.observable(individualDashlet, "dateRangeAttribute");
            self.proximityDateNumber = kb.observable(individualDashlet, "proximityDateNumber");
            self.proximityDateTimeSpan = kb.observable(individualDashlet, "proximityDateTimeSpan");
            self.proximityDateType = kb.observable(individualDashlet, "proximityDateType");
            self.proximityDateInterval = kb.observable(individualDashlet, "proximityDateInterval");
            self.showLegend = kb.observable(individualDashlet, "showLegend");
            self.referenceLineVal = kb.observable(individualDashlet, "referenceLineVal");
            self.enableTrendLine = kb.observable(individualDashlet, "enableTrendLine");
            self.stackedSeries = kb.observable(individualDashlet, "stackedSeries");
            
            self.varyColors = kb.observable(individualDashlet, "varyColors");
            self.xAxisLabel = kb.observable(individualDashlet, "xAxisLabel");
            self.yAxisLabel = kb.observable(individualDashlet, "yAxisLabel");
            

            // for when we paste an entire JSON configuration for a chart instead of confiugring components
            self.jsonConfig = kb.observable(individualDashlet, "jsonConfig");

            this.availableDateAttrs = ko.observableArray(); 

            this.reportingQueryConfigView = new ReportingQueryConfig.View({individualDashlet: this.individualDashlet});
            this.getAvailableDateAttrs();

            // listen for changing object types in any of the terms, as this means we will need to re-evaluate the 
            this.listenTo(this.reportingQueryConfigView, 'reportingdashletconfig:evaluteDateAttrs', function(){
                this.getAvailableDateAttrs();
            }, this);

            this.contentVisibility = false;
        },
        toggleDashlet: function(event) {

            if(this.$(".dashlet-content").hasClass("hidden")) {
                this.$(".dashlet-content").removeClass("hidden");
                this.iconChevron = "glyphicon glyphicon-chevron-down";
            }
            else {
                this.$(".dashlet-content").addClass("hidden");
                this.iconChevron = "glyphicon glyphicon-chevron-up";
            }
        },
        getAvailableDateAttrs: function(event) {
            var self = this;  
            //update all attributes - clear any existing ones
            self.availableDateAttrs.removeAll(); 
            //when we initialize this dropdown, we want to force the user to make a selection, so add
            //in a blank value at the top on the dropdown
            self.availableDateAttrs.push({ 'ocName': '' });
            _.each(this.options.individualDashlet.get("terms").models, function(term) {
                var objectType = term.get("type");
                if(objectType) {
                    app.context.configService.getTypeAttrs(objectType, function(attributes) {
                        _.each(attributes, function(attr){
                            self.availableDateAttrs.push({
                                'ocName': attr.ocName
                            });
                        });

                    }, this);
                }
            });
        },
        dashletDelete: function(event){
            // we want to stop the propagation - otherwise our toggle will get called
            event.stopPropagation();
            app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
        },
        setDashletName: function () {
            this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
            this.dashletName = this.$("#dashletName").val();
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setDashletId: function () {
            this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setUserPreferencesControl: function() {
            this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#reportingDisableUserVisibilityControl").is(":checked"));
		},
        beforeRender: function() {
            this.setViews({
                "#reporting-query-config-outlet": this.reportingQueryConfigView
            });
        },
        afterRender: function(){
            //don't break the parent afterRender
            BaseDashConfig.ConfigView.prototype.afterRender.apply(this, {});
            
        },
        serialize: function(){
            return {
                // tracs: this.tracNames,
                "controlChevron": this.iconChevron,
                "controlVisibility" : this.contentVisibility,
                "controlInfoBlockVisibility" : this.infoBlockVisibility,
                "cid": this.cid,
                "dashletId": this.options.individualDashlet.get("dashletId"),
                "dashletName": this.options.individualDashlet.get("dashletName"),
                "visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl")
            };
        }
    });

    return ReportingDashletConfig;
});