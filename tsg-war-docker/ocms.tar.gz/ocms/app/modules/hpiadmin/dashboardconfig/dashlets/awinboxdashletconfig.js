define(['app',
	'modules/hpiadmin/dashboardconfig/basedashconfig'
], function(app, BaseDashConfig){

	var AWInboxDashletConfig = app.module();

	AWInboxDashletConfig.Model = BaseDashConfig.DashletModel.extend({
		defaults: function() {
			return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
				{
					dashletType: "AWInboxDashlet",
					inboxName: "",
					showUserTasks: "",
					showGroupTasks: "",
					allowUserVisibilityControl: false
			});
		}
	});

	AWInboxDashletConfig.View = BaseDashConfig.ConfigView.extend({
		template: "hpiadmin/dashboardconfig/dashlets/awinboxdashletconfig",
		events: {
			"click .dashlet-toggle": "toggleDashlet",
			"click .dashlet-delete" : "dashletDelete",
			"change #dashletName" : "setDashletName",
			"change #dashletId" : "setDashletId",
			"change #awDisableUserVisibilityControl": "setUserPreferencesControl"
		},
		
		initialize: function(options){
			var self = this;

			//this is important to setup the security view in the core dashlet view
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

			var individualDashlet = this.individualDashlet = options.individualDashlet || null;
			var dashletType = this.dashletType = options.dashletType || null;

			self.templateName = dashletType;
			// the text to display to inform the user what kind of dashlet this is
			self.dashletDisplayType = "Active Wizard Inbox";
			self.inboxName = kb.observable(individualDashlet, "inboxName");
			self.showUserTasks = kb.observable(individualDashlet, "showUserTasks");
			self.showGroupTasks = kb.observable(individualDashlet, "showGroupTasks");
			self.allowUserVisibilityControl = kb.observable(individualDashlet, "allowUserVisibilityControl");

			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 
		},
		toggleDashlet: function(event) {
			if(this.contentVisibility) {
               this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function() {
			this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
		setDashletId: function() {
			this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#awDisableUserVisibilityControl").is(":checked"));
		},
        serialize: function() { 
            return { 
                "controlChevron": this.iconChevron,
                "controlVisibility" : this.contentVisibility,
                "dashletId" : this.options.individualDashlet.get("dashletId"),
				"dashletName" : this.options.individualDashlet.get("dashletName"),
				"visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl"),
            };
        }
	});

	return AWInboxDashletConfig;
});