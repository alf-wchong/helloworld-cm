// this is here to allow dashboardconfig to usee a default daslet config w/o causing a circular dep
define([
	'app',
	'modules/hpiadmin/dashboardconfig/basedashconfig'
],
function(app, BaseDashConfig) {

	var DefaultDashlet = app.module();

	DefaultDashlet.Model = BaseDashConfig.DashletModel.extend({});

	DefaultDashlet.View = BaseDashConfig.ConfigView.extend({
		initialize: function(options) {
			// we want to call our parent dashboard config view so we get all the common functionality (e.g., security groups)
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

			// the text to display to inform the user what kind of dashlet this is - we'll default to the dashlet type
			this.dashletDisplayType = this.options.dashletType;
		}
	});

	return DefaultDashlet;
});