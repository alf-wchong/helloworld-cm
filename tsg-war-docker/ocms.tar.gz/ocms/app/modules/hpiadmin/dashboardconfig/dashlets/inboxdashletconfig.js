define(['app',
    'modules/hpiadmin/dashboardconfig/basedashconfig'
], function (app, BaseDashConfig) {

    var InboxDashletConfig = app.module();

    InboxDashletConfig.Model = BaseDashConfig.DashletModel.extend({
        defaults: function () {
            return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(),
                {
                    dashletType: "InboxDashlet",
                    allowUserVisibilityControl: false
                });
        }
    });

    InboxDashletConfig.View = BaseDashConfig.ConfigView.extend({
        template: "hpiadmin/dashboardconfig/dashlets/inboxdashletconfig",
        events: {
            "click .dashlet-toggle": "toggleDashlet",
            "click .dashlet-delete": "dashletDelete",
            "change #dashletName": "setDashletName",
            "change #dashletId": "setDashletId",
            "change #inboxDisableUserVisibilityControl": "setUserPreferencesControl"
        },
        initialize: function (options) {

            //this is important to setup the security view in the core dashlet view
            BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

            this.individualDashlet = options.individualDashlet || null;

            this.dashletType = options.dashletType || null;
            // the text to display to inform the user what kind of dashlet this is
            this.dashletDisplayType = "Inbox";
            //this.showMyWorkflows = kb.observable(this.individualDashlet, "showMyWorkflows");
            //this.showWorkflowHistory = kb.observable(this.individualDashlet, "showWorkflowHistory");
            //this.showGroupTasks = kb.observable(this.individualDashlet, "showGroupTasks");
            this.attrToShow = kb.observable(this.individualDashlet, "attrToShow");
            this.allowUserVisibilityControl = kb.observable(this.individualDashlet, "allowUserVisibilityControl");
            //this.numPerPage = kb.observable(this.individualDashlet, "numPerPage");

            if (this.attrToShow() === undefined || this.attrToShow() === null) {
                this.attrToShow("");
            }
            this.iconChevron = "glyphicon glyphicon-chevron-down";
            this.contentVisibility = false;
        },
        toggleDashlet: function (event) {
            if (this.contentVisibility) {
                this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
        },
        dashletDelete: function (event) {
            // we want to stop the propagation - otherwise our toggle will get called
            event.stopPropagation();
            app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
        },
        setDashletName: function () {
            this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
            this.dashletName = this.$("#dashletName").val();
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setDashletId: function () {
            this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#inboxDisableUserVisibilityControl").is(":checked"));
		},
        serialize: function () {
            return {
                "controlChevron": this.iconChevron,
                "controlVisibility": this.contentVisibility,
                "dashletId": this.options.individualDashlet.get("dashletId"),
                "dashletName": this.options.individualDashlet.get("dashletName"),
                "visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl")
            };
        }
    });

    return InboxDashletConfig;
});