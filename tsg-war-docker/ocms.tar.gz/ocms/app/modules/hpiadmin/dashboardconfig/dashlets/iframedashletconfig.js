define([
	'app',
	'modules/hpiadmin/dashboardconfig/basedashconfig'
], 
function(app, BaseDashConfig){

	var IFrameDashlet = app.module();

	IFrameDashlet.Model = BaseDashConfig.DashletModel.extend({
		defaults: function() {
			return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(), {
				dashletType: "IFrameDashlet",
				iframeSrc: "",
				iframeHeight: "",
				allowUserVisibilityControl: false
			});
		}
	});

	IFrameDashlet.View = BaseDashConfig.ConfigView.extend({
		template: "hpiadmin/dashboardconfig/dashlets/iframedashletconfig",
		events: {
			"click .dashlet-toggle": "toggleDashlet",
			"click .dashlet-delete" : "dashletDelete",
			"change #dashletName" : "setDashletName",
			"change #dashletId" : "setDashletId",
			"change #iframeSrc" : "setIFrameSrc",
			"change #iframeHeight" : "setIFrameHeight",
			"change #iframeDisableUserVisibilityControl": "setUserPreferencesControl"
		},
		initialize: function(options){

			//this is important to setup the security view in the core dashlet view
			BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);
			
			this.dashletType = options.dashletType || null;
			// the text to display to inform the user what kind of dashlet this is
			this.dashletDisplayType = "IFrame";
			this.individualDashlet = options.individualDashlet || null;

			this.iframeSrc = this.individualDashlet.iframeSrc || "";
			this.iframeHeight = this.individualDashlet.iframeHeight || 0;
			this.allowUserVisibilityControl = kb.observable(this.individualDashlet, "allowUserVisibilityControl");

			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 
		},
		toggleDashlet: function(event) {
			if(this.contentVisibility) {
				this.iconChevron = "glyphicon glyphicon-chevron-down";
				this.contentVisibility = false;
			} else { // this dashlet content is not visible right now, so let's show it
				this.iconChevron = "glyphicon glyphicon-chevron-up";
				this.contentVisibility = true;
			}
			this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function() {
			this.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setDashletId: function() {
			this.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
		},
		setUserPreferencesControl: function() {
			this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#iframeDisableUserVisibilityControl").is(":checked"));
		},
		setIFrameSrc: function() {
			this.individualDashlet.set("iframeSrc", this.$("#iframeSrc").val());
		},
		setIFrameHeight: function() {
			this.individualDashlet.set("iframeHeight", this.$("#iframeHeight").val());
		},
		serialize: function() { 
			return { 
				"controlChevron": this.iconChevron,
				"controlVisibility" : this.contentVisibility,
				"dashletId" : this.individualDashlet.get("dashletId"),
				"dashletName" : this.individualDashlet.get("dashletName"),
				"iframeSrc" : this.individualDashlet.get("iframeSrc"),
				"iframeHeight" : this.individualDashlet.get("iframeHeight"),
				"visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl")
			};
		}
	});

	return IFrameDashlet;
});