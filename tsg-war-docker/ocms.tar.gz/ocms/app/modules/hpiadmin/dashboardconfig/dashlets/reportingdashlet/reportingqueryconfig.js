define(['app',
        'handlebars',
        'modules/hpiadmin/otc/objecttypeconfig',
        'modules/hpiadmin/dashboardconfig/basedashconfig',
        'modules/common/tossacross'
], function(app, handlebars, OTC, BaseDashConfig, TossAcross){

    var ReportingQueryConfig = app.module();

    //Submodels
    ReportingQueryConfig.TermModel = Backbone.Model.extend({
        defaults : function() {
            return {
                type: "",
                criteria: [],
                termName: ""
            };
        }
    });

    //Collection of models
    ReportingQueryConfig.Collection = Backbone.Collection.extend({
        model: ReportingQueryConfig.TermModel
       
    });

    ReportingQueryConfig.View = Backbone.Layout.extend({
        template: "hpiadmin/dashboardconfig/dashlets/reportingdashlet/reportingqueryconfig",
        events: {
            "click .add-term" : "addTerm",
            "click .remove-term" : "deleteTerm"
        },
        initialize: function(options){
            var self = this;
            this.individualDashlet = this.options.individualDashlet || null;
            this.objectTypes = this.options.objectTypes;

            this.terms = this.individualDashlet.get("terms");
            this.termViews = [];
            this.ui = {}; 
            this.terms = kb.observable(this.options.individualDashlet, "terms");

            app.listenTo(app, "reportingQueryConfig:termDelete", function (cid) {
                self.getViews('#term-configs-outlet').each(function (termView) {
                    if (termView.term.cid === cid) {
                        // removes term from the view
                        termView.remove();
                        var modelToRemove = self.options.individualDashlet.get("terms").get(cid);
                        self.options.individualDashlet.get("terms").remove(modelToRemove);
                        // Additionally, re-evaluate the list of attributes that can be selected for date range
                        self.trigger("reportingdashletconfig:evaluteDateAttrs");
                    }
                });
            });

            this.addAllTerms();
            
        },
        addAllTerms: function() {
            var views = [];
            var self = this;
            _.each(this.options.individualDashlet.get("terms"), function(term, index) {
                var view = new ReportingQueryConfig.QueryTerm({parentView: self, individualDashlet: self.options.individualDashlet, 
                                                                index: index, objectTypes: this.objectTypes});
                views.push(view);
            });
            
            this.remove("#term-configs-outlet");

            //insert the views in order based on the ordinal
            this.insertViews({
                "#term-configs-outlet": views
            });

            this.termViews = views;
            
        },
        addTerm: function(){
            var newTerm = new ReportingQueryConfig.TermModel();
            this.options.individualDashlet.get("terms").add(newTerm);
            var newTermView = new ReportingQueryConfig.QueryTerm({parentView: this, individualDashlet: this.options.individualDashlet,
                                                                  index: this.options.individualDashlet.get("terms").length-1,
                                                                  objectTypes: this.objectTypes});
            this.insertView("#term-configs-outlet", newTermView).render();
        },
        afterRender: function() {
            this.ui.content = this.$(".hpi-section-content");
            this.ui.term = this.$(".hpi-section-term");
        }
    });

    ReportingQueryConfig.QueryTerm = Backbone.Layout.extend({
        template: "hpiadmin/dashboardconfig/dashlets/reportingdashlet/queryterm",
        events: {
            "click .add-criteria" : "addCriteria",
            "click .remove-criteria" : "removeCriteria",
            'change .reporting-criteria-attr' : 'changeCriteria',
            "change .searchCriteriaOp" : "changeOperator",
            "change .searchCriteriaValue" : "changeCriteriaValue",
            "change .proximityDateValue": "changeProximityDateValue",
            "change .proximityDateRange": "changeProximityDateRange",
            "click .hpi-term-header": "toggleTermVisibility",
            "change .reporting-objectTypes" : "changeObjectType",
            "change .term-name" : "setTermName",
            "click .term-delete" : "deleteTerm"
        },
        initialize: function(options){
            var self =  this;
            if(!(this.options.individualDashlet.get("terms") instanceof Backbone.Collection)) {
                this.options.individualDashlet.set("terms", new ReportingQueryConfig.Collection(this.options.individualDashlet.get("terms")));
            }
            this.terms = this.options.individualDashlet.get("terms");
            this.termIndex = this.options.index;

            // Resolve object type
            this.selectedType = this.options.individualDashlet.get("terms").models[this.termIndex].get("type");
            this.objectTypes = [];

            app.context.configService.getAdminOTC(function(otc){
                otc.get("configs").each(function(typeConfig){
                    self.objectTypes.push({name: typeConfig.get("ocName"), label: typeConfig.get("label")});
                });
            }).done(function(){
                self.getAvailableAttributes().done(self.render());
            });

            this.hidden = true;
            this.renderFirstTime = false;

            this.term = this.terms.models[this.termIndex];
            this.termCid = this.term.cid;

            this.criteria = this.term.get("criteria");
            this.operators = [
                {"value" : "LOGIC_LIKE", "label" : window.localize("dashBoardConfig.dashlets.savedSearchDashletConfig.isLike")},
                {"value" : "OPERATOR_EQUALS", "label" : window.localize("dashBoardConfig.dashlets.savedSearchDashletConfig.isEqual")},
                {"value" : "OPERATOR_NOT_EQUALS", "label" : window.localize("dashBoardConfig.dashlets.savedSearchDashletConfig.notEqual")},
                {"value" : "LOGIC_DISTINCT", "label" : window.localize("dashBoardConfig.dashlets.reportingDashletConfig.operatorDistinct")},
                {"value" : "LOGIC_LIKE_WITHIN", "label" : window.localize("dashBoardConfig.dashlets.reportingDashletConfig.operatorWithin")},
                {"value" : "LOGIC_LIKE_PAST", "label" : window.localize("dashBoardConfig.dashlets.reportingDashletConfig.operatorPast")},
                {"value" : "LOGIC_LIKE_NEXT", "label" : window.localize("dashBoardConfig.dashlets.reportingDashletConfig.operatorNext")}
            ];

            this.proximityOperatorsList = ["LOGIC_LIKE_WITHIN", "LOGIC_LIKE_PAST", "LOGIC_LIKE_NEXT"];

            this.termName = this.term.get("termName");

            this.allAttrs = new Backbone.Collection();
            this.availableInfoBlockAttrs = new Backbone.Collection();

            // This helper determines what value should be selected for the object type dropdown
            handlebars.registerHelper("rq-selectedType", function(options) {
                if (options.hash.selectedObjType === options.hash.currentOption.name) {
                    return "selected";
                } else {
                    return "";
                }
            });

            // This helper determines what value should be selected in each of the search criteria attribute
            handlebars.registerHelper("rq-selectedAttr", function(options) {
                if (options.hash.selectedAttr === options.hash.currentOption.get("ocName")) {
                    return "selected";
                } else {
                    return "";
                }
            });

            // This helper determines what value should be selected for each of the searhc criteria operator
            handlebars.registerHelper("rq-selectedOperator", function(options) {
                if (options.hash.selectedOperator === options.hash.currentOption.value) {
                    return "selected";
                } else {
                    return "";
                }
            });

             // This helper determines what value should be selected for each of the searhc criteria value
            handlebars.registerHelper("rq-criteriaVal", function(options) {
                if (options.hash.criteriaVal === options.hash.currentOption.value) {
                    return "selected";
                } else {
                    return "";
                }
            });
            this.ui = {};
            this.ui.content = this.$('.hpi-collapsable');

        },
        
        afterRender: function () {
            // performing to ensure values persist for proxmity dates when we render on an add/remove
            _.each(this.criteria, function(criteria, index){
                this.setValueFieldAfterRender(criteria.operator, index);
                this.setDefaultProximityRange(criteria, index);
            }, this);
        },
        setValueFieldAfterRender: function(operator, index) {
            if(_.indexOf(this.proximityOperatorsList, operator) != -1) {
                if(this.$el.find("#searchProximityDateContainer-value-" + index).hasClass("hidden")) {
                    $(this.$el).find("#searchProximityDateContainer-value-" + index).removeClass("hidden");
                    $(this.$el).find("#reporting-criteria-value-" + index).addClass("hidden");
                }
            } else {
                if($(this.$el).find("#reporting-criteria-value-" + index).hasClass("hidden")) {
                    $(this.$el).find("#reporting-criteria-value-" + index).removeClass("hidden");
                    $(this.$el).find("#searchProximityDateContainer-value-" + index).addClass("hidden");
                }
            }
        },
        setDefaultProximityRange: function(criteria, index) {
            // If we had a proximityDateRange(within, past, before) before, set it on the proximity date range field
            if(criteria.proximityDateRange) {
                $(this.$el).find("#searchProximityDateRange-value-" + index).val(criteria.proximityDateRange);
            }
        },
        //Hide and show the form on toggle
        toggleTermVisibility: function(event) {
            if(this.hidden === true) {
                this.hidden = false;
            }
            else {
                this.hidden = true;
            }
            this.render();
        },
        setTermName: function(event) {
            this.termName = this.$(".term-name").val();
            this.options.individualDashlet.get("terms").get(this.termCid).set("termName", this.termName);

            this.render();
        },  
        addCriteria: function(){
            var array = this.criteria.splice(0);
            array.push({operator:"LOGIC_LIKE", value:"", selectedAttribute: "", isDistinctOperator: false});
            this.criteria = array;
            this.options.individualDashlet.get("terms").get(this.termCid).set("criteria", this.criteria);
            this.render();
        },
        removeCriteria: function(){
            var array = this.criteria.splice(0);
            array.pop();         
            this.criteria = array;

            this.options.individualDashlet.get("terms").get(this.termCid).set("criteria", this.criteria);
            this.render();
        },
        changeCriteria: function(e){
            var index = Number(this.$(e.currentTarget).attr('id').replace('reporting-criteria-attr-', ''));
            var criteriaAttr = this.$(e.currentTarget).val();
            this.criteria[index].selectedAttribute = criteriaAttr;
            this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].selectedAttribute = criteriaAttr;
        },
        changeOperator: function(e) {
            var index = Number(this.$(e.currentTarget).attr('id').replace('reporting-criteria-operator-', ''));
            var operator = this.$(e.currentTarget).val();
            this.criteria[index].operator = operator;
            this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].operator = operator;
             if (operator === 'LOGIC_DISTINCT') {
                this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].isDistinctOperator = true;
             }
             else {
                this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].isDistinctOperator = false;
             }

             this.setValueField(operator, index, e);
        },
        changeCriteriaValue: function(e) {
            //get id and update the correct criteria
            var index = Number(this.$(e.currentTarget).attr('id').replace('reporting-criteria-value-', ''));
            var value = this.$(e.currentTarget).val();
            this.criteria[index].value = value;
            this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].value = value;
        },
        changeProximityDateValue: function(e) {
            //get id and update the correct criteria
            var index = Number(this.$(e.currentTarget).attr('id').replace('searchProximityDate-value-', ''));
            var value = this.$(e.currentTarget).find("#proximityDateNumber").val()
            this.criteria[index].proximityDateValue = value;
            this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].proximityDateValue = value;
        },
        changeProximityDateRange: function(e) {
            //get id and update the correct criteria
            var index = Number(this.$(e.currentTarget).attr('id').replace('searchProximityDateRange-value-', ''));
            var value = this.$(e.currentTarget).val();
            this.criteria[index].proximityDateRange = value;
            this.options.individualDashlet.get("terms").get(this.termCid).get("criteria")[index].proximityDateRange = value;
        },
        changeObjectType: function(e){
            var self = this;
            //set to the ocName, nopt the label
            var value = this.$(e.currentTarget).attr('value');
            this.options.individualDashlet.get("terms").get(this.termCid).set("type", value);
            this.selectedType = value;
            _.each(this.criteria, function(criteria) {
                criteria.selectedAttribute = "";
            });

            //clear selected types - get attributes specific to new type
            //get all types, avalible types, then build the toss across
            this.getAvailableAttributes().done(function() {  
                // Additionally, re-evaluate the list of attributes that can be selected for date range
                self.parentView.trigger("reportingdashletconfig:evaluteDateAttrs");
                self.render();
            });
        },
        setValueField: function(operator, index, e) {
            if(_.indexOf(this.proximityOperatorsList, operator) != -1) {
                this.switchValueFieldToProximityDate(index, e);
            } else {
                this.switchValueFieldToTextBox(index, e);
            }
        },
        switchValueFieldToTextBox: function(index, e) {
            if(e) {
                if($(e.currentTarget.parentElement.parentElement).find("#reporting-criteria-value-" + index).hasClass("hidden")) {
                    $(e.currentTarget.parentElement.parentElement).find("#reporting-criteria-value-" + index).removeClass("hidden");
                    $(e.currentTarget.parentElement.parentElement).find("#searchProximityDateContainer-value-" + index).addClass("hidden");
                }
            } else {
                if($("#reporting-criteria-value-" + index).hasClass("hidden")) {
                    $("#reporting-criteria-value-" + index).removeClass("hidden");
                    $("#searchProximityDateContainer-value-" + index).addClass("hidden");
                }
            }
        },
        switchValueFieldToProximityDate: function(index, e) {
            if(e) {
                if($(e.currentTarget.parentElement.parentElement).find("#searchProximityDateContainer-value-" + index).hasClass("hidden")) {
                    $(e.currentTarget.parentElement.parentElement).find("#searchProximityDateContainer-value-" + index).removeClass("hidden");
                    $(e.currentTarget.parentElement.parentElement).find("#reporting-criteria-value-" + index).addClass("hidden");
                }
            } else {
                if($("#searchProximityDateContainer-value-" + index).hasClass("hidden")) {
                    $("#searchProximityDateContainer-value-" + index).removeClass("hidden");
                    $("#reporting-criteria-value-" + index).addClass("hidden");
                }
            }
        },
        getAvailableAttributes: function() {
            var self = this;
            var deferred = $.Deferred();
            // careful here, send the ocName, not the label
            var ocName = this.selectedType;
            if(ocName !== undefined && ocName.length !== 0) {
                app.context.configService.getTypeAttrs(ocName, function(attributes) {
                    //update all attributes - sclear any existing ones
                    self.allAttrs = self.allAttrs ? self.allAttrs.reset() : new Backbone.Collection();
                    _.each(attributes, function(attr){
                        self.allAttrs.add({
                            'ocName': attr.ocName
                        });
                    });
                    deferred.resolve();
                }, this);
            }
            return deferred.promise();
        },
        deleteTerm:  function(event) {
            // we want to stop the propagation - otherwise our toggle will get called
            event.stopPropagation();
            app.trigger("reportingQueryConfig:termDelete", this.termCid);          
        },
       
        serialize: function(){
            return {
                    criteria: this.criteria,
                    allAttrs: this.allAttrs.models,
                    type: this.type,
                    termName: this.termName,
                    hidden: this.hidden,
                    cid: this.cid,
                    objectTypes: this.objectTypes,
                    selectedObjType: this.selectedType,
                    operators: this.operators
                };
        }

    });


    return ReportingQueryConfig;
});