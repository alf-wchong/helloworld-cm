define(['app',
    'handlebars',
    'modules/hpiadmin/otc/objecttypeconfig',
    'modules/hpiadmin/dashboardconfig/basedashconfig',
    'modules/common/tossacross',
    "modules/hpiadmin/actionconfig/hpiactionconfig",
    "modules/hpiadmin/applicationconfig/applicationconfig",
"modules/hpiadmin/dashboardconfig/dashlets/savedsearchdashletactionconfig"
], function(app, Handlebars, OTC, BaseDashConfig, TossAcross, ActionConfig, AppConfig, SavedSearchDashletActionConfig) {

    var SavedSearchDashletConfig = app.module();

    //util method for transforming primitive collections into full-fledged backbone.collections
    var convertToCollection = function(array) {
        //return if collection is already a backbone collection
        if (array instanceof Backbone.Collection) {
            return array;
        } else { //otherwise, convert the primitive array to a backbone collection
            return new Backbone.Collection(array);
        }
    };

    SavedSearchDashletConfig.Model = BaseDashConfig.DashletModel.extend({
        defaults: function() {
            return _.extend({}, BaseDashConfig.DashletModel.prototype.defaults(), {
                dashletType: "SavedSearchDashlet",
                isLink: "",
                tracResolver: "",
                directToIndexer: false,
                type: "",
                criteria: [],
                selectedAttributes: [],
                enableSorting: false,
                sortAttribute: "modifiedDate",
                sortOrder: -1, // -1 is ascending, 1 is descending
                linkedIndexerConfig: "",
                allowUserVisibilityControl: false
            });
        },
        initialize: function(options) {
            // ActionMenu
    		if (options && options.dashletActionConfig) {
    		    this.set("dashletActionConfig", new SavedSearchDashletActionConfig.Model(options.dashletActionConfig));
    		} else {
    		    this.set("dashletActionConfig", new SavedSearchDashletActionConfig.Model());
    		}
    	},
        sync: function(method, model, options) {
            //OC and the rest of HPI expect
            //the configured types to be an array of strings
            if (model.get("selectedAttributes") instanceof Backbone.Collection) {
                model.set('selectedAttributes', model.get("selectedAttributes"));
            }
            //call original save
            return Backbone.sync(method, model, options);
        }
    });

    SavedSearchDashletConfig.View = BaseDashConfig.ConfigView.extend({
        template: "hpiadmin/dashboardconfig/dashlets/savedsearchdashletconfig",
        events: {
            'change .savedsearch-linkedAttr': 'linkedAttr',
            'change .savedsearch-sortAttr': 'sortAttr',
            'change .savedsearch-linkedIndexer' : 'changeLinkedIndexer',
            "click .dashlet-toggle": "toggleDashlet",
            "click .dashlet-delete": "dashletDelete",
            'change .savedsearch-objectTypes': 'changeObjectType',
            'change .savedsearch-criteria-attr': 'changeCriteria',
            'change #dashletName': 'setDashletName',
            'change #dashletId': 'setDashletId',
            'change .searchCriteriaOp': 'changeOperator',
            'change .proximityNumber': 'changeProximityNumber',
            'change .proximityTimeSpan': 'changeProximityTimeSpan',
            'click .add-actions-button' : 'addActions',
            "click .radioValueChange": "changeSortOrder",
            "change #savedSearchDisableUserVisibilityControl": "setUserPreferencesControl"
        },
        initialize: function(options) {
            var self = this;
            Handlebars.registerHelper("setChecked", function(value, currentValue) {
                if (value == currentValue) {
                    return "checked = true";
                } else {
                    return "";
                }
            });

            //this is important to setup the security view in the core dashlet view
            BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);

            var individualDashlet = this.individualDashlet = options.individualDashlet || null;
            var dashletType = this.dashletType = options.dashletType || null;

            self.templateName = dashletType;

            self.allowUserVisibilityControl = kb.observable(individualDashlet, "allowUserVisibilityControl");

            // the text to display to inform the user what kind of dashlet this is
            self.dashletDisplayType = "Saved Search";
            self.criteria = kb.observable(individualDashlet, "criteria");
            self.enablePaging = kb.observable(individualDashlet, "enablePaging");
            self.allAttributes = ko.observableArray();
            self.isLink = kb.observable(individualDashlet, "isLink");
            self.enableSorting = ko.observable();
            self.directToIndexer = kb.observable(individualDashlet, "directToIndexer");
            self.tracResolver = kb.observable(individualDashlet, "tracResolver");

            // ActionMenu
            self.actionConfig = kb.observable(individualDashlet, "actionConfig");

            //listen for this to change - get adminOTC, update views accordingly
            self.selectedType = individualDashlet.get('type');

            self.sortAttribute = individualDashlet.get("sortAttribute") ? individualDashlet.get("sortAttribute") : "modifiedDate";
            self.sortOrder = individualDashlet.get("sortOrder") ? individualDashlet.get("sortOrder") : -1;

            self.linkedIndexerConfig = individualDashlet.get("linkedIndexerConfig") ? individualDashlet.get("linkedIndexerConfig") : "";

            //this drives the picklist for criteria
            self.allAttrs = new Backbone.Collection();
            self.availableAttrs = new Backbone.Collection();

            self.iconChevron = "glyphicon glyphicon-chevron-down";
            self.contentVisibility = false;

            // ActionMenu
            self.renderPrevent = false;
    		
    		//this enables column sorting in the saved search dashlet
            if (self.options.individualDashlet.get("enableSorting")) 
            { 
                self.enableSorting("true"); 
            } else 
                { self.enableSorting("false"); 
            }
            self.enableSorting.subscribe(function(boolString) {
                if (boolString === "true") {
                    self.options.individualDashlet.set("enableSorting", true);
                } else {
                    self.options.individualDashlet.set("enableSorting", false);
                }
            });

        },
        toggleDashlet: function(event) {
            // if the dashlet content is visible, we want to hide it
            if (this.contentVisibility) {
                this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
        },
        dashletDelete: function(event) {
            // we want to stop the propagation - otherwise our toggle will get called
            event.stopPropagation();
            app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
        },
        setDashletName: function() {
            this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
            this.dashletName = this.$("#dashletName").val();
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setDashletId: function() {
            this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
            this.iconChevron = "glyphicon glyphicon-chevron-up";
            this.render();
        },
        setUserPreferencesControl: function() {
            this.options.individualDashlet.set("allowUserVisibilityControl", this.$("#savedSearchDisableUserVisibilityControl").is(":checked"));
		},
        changeOperator: function(e) {
            if (!this.$(e.currentTarget).attr('id')) {
                return;
            }
            var index = Number(this.$(e.currentTarget).attr('id').replace('searchCriteriaOp-', ''));
            var newOperator = this.$(e.currentTarget).attr('value');
            if (newOperator.toLowerCase() === 'within' ||
                newOperator.toLowerCase() === 'past' ||
                newOperator.toLowerCase() === 'next') {
                this.criteria()[index].isProximityOperator = true;
            } else {
                this.criteria()[index].isProximityOperator = false;
            }

            this.render();
        },
        changeProximityNumber: function(e) {
            if (!this.$(e.currentTarget).attr('id')) {
                return;
            }
            var index = Number(this.$(e.currentTarget).attr('id').replace('proximityNumber-', ''));
            var newProxNumber = this.$(e.currentTarget).attr('value');
            this.criteria()[index].proximityNumber = newProxNumber;
        },
        changeProximityTimeSpan: function(e) {
            if (!this.$(e.currentTarget).attr('id')) {
                return;
            }
            var index = Number(this.$(e.currentTarget).attr('id').replace('proximityTimeSpan-', ''));
            var newProxTimeSpan = this.$(e.currentTarget).attr('value');
            this.criteria()[index].proximityTimeSpan = newProxTimeSpan;
        },
        buildAttrsTossAcross: function() {
            var self = this;
            var ui = {
                savedsearchtossacross: '.savedsearch-attributes-tossacross'
            };

            self.targetCollection = convertToCollection(self.individualDashlet.get("selectedAttributes"));
            self.listenTo(self.targetCollection, 'add remove reset', function() {
                //keep collection in sync
                //convert models to just the string types
                var minifiedCollection = self.targetCollection.map(function(model) {
                    return { ocName: model.get("ocName"), label: model.get("label") };
                });
                self.individualDashlet.set('selectedAttributes', minifiedCollection);

                //trigger re-render for link attrs
                self.updateSelectedAttrs();
            });

            //if object type has changed, get a new tossacross view
            self.removeView(ui.savedsearchtossacross);
            //build toss across widget
            self.attributesTossAcross = new TossAcross.Layout({
                srcCollection: {
                    title: window.localize("modules.hpiAdmin.dashboardConfig.dashlet.recentObjectDashletConfig.availableAttrs"),
                    filter: true,
                    labelAttr: 'label',
                    valueAttr: 'ocName',
                    collection: self.availableAttrs
                },
                targetCollections: [{
                    title: window.localize("modules.hpiAdmin.dashboardConfig.dashlet.recentObjectDashletConfig.selectedAttributes"),
                    labelAttr: 'label',
                    valueAttr: 'ocName',
                    collection: self.targetCollection
                }]
            });

            //tossacross is just a backbone view
            self.setView(ui.savedsearchtossacross, self.attributesTossAcross).render();
        },
        changeObjectType: function(e) {
            var self = this;
            //set to the ocName, nopt the label
            var value = this.$(e.currentTarget).attr('value');

            if (value !== this.selectedType || this.selectedType === '') {
                this.selectedType = value;
                this.individualDashlet.set('type', this.selectedType);
                //nuke selected attributes
                this.individualDashlet.set("selectedAttributes", new Backbone.Collection());
                //clear selected types - get attributes specific to new type
                //get all types, avalible types, then build the toss across
                this.updateAllAttributes().done(function() {
                    self.updateSelectedAttrs();
                    self.updateSortAttrs();
                    self.buildAttrsTossAcross();
                });
            }
        },
        linkedAttr: function(e) {
            var linkedAttr = this.$(e.currentTarget).val();
            this.isLink(linkedAttr);
        },
        sortAttr: function(e) {
            this.individualDashlet.set("sortAttribute", $(e.target).val());
        },
        changeLinkedIndexer: function(e) {
            this.individualDashlet.set("linkedIndexerConfig", $(e.target).val());
        },
        changeSortOrder: function(e) {
            var target = "input[id='" + $(e.target).attr("for") + "']";
            this.individualDashlet.set("sortOrder", parseInt($(target).val()));
        },
        addCriteria: function() {
            var array = this.individualDashlet.get("criteria").splice(0);
            array.push({ attribute: "", operator: "", value: "", isProximityOperator: false, proximityNumber: "", proximityTimeSpan: "" });
            this.criteria(array);

            this.renderCriteriaAttrs();
        },
        removeCriteria: function() {
            var array2 = this.individualDashlet.get("criteria").splice(0);
            array2.pop();
            this.criteria(array2);

            this.renderCriteriaAttrs();
        },
        changeCriteria: function(e) {
            //get id and update the correct criteria
            var index = Number(this.$(e.currentTarget).attr('id').replace('savedsearch-criteria-attr-', ''));
            var criteriaAttr = this.$(e.currentTarget).val();
            this.criteria()[index].attribute = criteriaAttr;
        },
        renderCriteriaAttrs: function() {
            //render criteria attributes
            var self = this;
            var criteriaAttrs = this.$('.savedsearch-criteria-attr');
            criteriaAttrs.empty();
            criteriaAttrs.append($("<option></option>")
                .attr("disabled", "disabled")
                .attr("selected", "selected"));
            //render object types
            this.allAttrs.each(function(type) {
                criteriaAttrs.append($("<option></option>")
                    .attr('value', type.get('ocName'))
                    .text(type.get('label')));
            });

            //ko seems to not like the deferreds
            //set selected criteria to the config's attribute manually
            _.each(criteriaAttrs, function(el, index) {
                this.$(el).val(self.criteria()[index].attribute);
            }, this);
        },
        updateSelectedAttrs: function() {
            this.$('.attrControls').removeClass('hidden');
            var selectLinkedAttrs = this.$('.savedsearch-linkedAttr');
            selectLinkedAttrs.empty();
            selectLinkedAttrs.append($("<option></option>")
                .attr("disabled", "disabled")
                .attr("selected", "selected"));
            //update the linked attrs list w/o re-rendering the whole page
            _.each(this.individualDashlet.get('selectedAttributes'), function(attr) {
                selectLinkedAttrs.append($("<option></option>")
                    .text(attr.label));
            });
            //maintain the selected value
            selectLinkedAttrs.val(this.isLink());
        },
        updateSortAttrs: function() {
            this.$('.attrControls').removeClass('hidden');
            var selectSortAttrs = this.$('.savedsearch-sortAttr');
            selectSortAttrs.empty();
            selectSortAttrs.append($("<option></option>").attr("disabled", "disabled").attr("selected", "selected"));
            //update the sort attrs list w/o re-rendering the whole page
            this.allAttrs.each(function(attr) {     
                selectSortAttrs.append($("<option></option>").text(attr.get("label")).attr("value",attr.get("ocName")));
            }, this); 
            //maintain the sort value
            selectSortAttrs.val(this.individualDashlet.get("sortAttribute"));
        },
    	// builds a dropdown with a selectable empty option at the top
    	// iterates through the indexerConfigs and appedns an option for each config
        updateLinkedIndexer: function() {
            var selectLinkedIndexer = this.$('.savedsearch-linkedIndexer');
            selectLinkedIndexer.empty();
            selectLinkedIndexer.append($("<option></option>").attr("selected", "selected"));
            //update the indexConfigs list w/o re-rendering the whole page
            _.each(this.indexerConfigs, function(config) {
                selectLinkedIndexer.append($("<option></option>").text(config).attr("value",config));
            });
            
            selectLinkedIndexer.val(this.individualDashlet.get("linkedIndexerConfig"));
        },
        updateSortOrder: function() {
            var self = this;
            var selectSortOrder = null;
            if(this.sortOrder === 1){
                selectSortOrder = $("#descendingSortOrder");
            }else{
                selectSortOrder = $("#ascendingSortOrder");
            }
            selectSortOrder.prop("checked", true);
        },
        updateObjectTypes: function() {
            var self = this;
            var deferred = $.Deferred();
            //populate types for dropdown
            app.context.configService.getAdminOTC(function(freshOTC) {
                self.objectTypes = self.objectTypes ? self.objectTypes.reset() : new Backbone.Collection();
                freshOTC.get("configs").each(function(typeConfig) {
                    self.objectTypes.add({ name: typeConfig.get("ocName"), label: typeConfig.get("label") });
                }, this);
                //render object types
                var objectTypesOutlet = self.$('.savedsearch-objectTypes');
                objectTypesOutlet.empty();
                objectTypesOutlet.append($("<option></option>")
                    .attr("disabled", "disabled")
                    .attr("selected", "selected"));
                //render object types
                self.objectTypes.each(function(type) {
                    objectTypesOutlet.append(
                        $("<option></option>")
                        .attr('value', type.get('name'))
                        .text(type.get('label'))
                    );
                });

                //select the configured type if there is one
                objectTypesOutlet.val(self.selectedType);
                deferred.resolve();
            }, this);
            return deferred.promise();
        },
        updateAllAttributes: function() {
            var self = this;
            var deferred = $.Deferred();
            //careful here, send the ocName, not the label
            var ocName = this.selectedType;
            app.context.configService.getAdminTypeConfig(ocName, function(otc) {
                //update all attributes - clear any existing ones
                self.allAttrs = self.allAttrs ? self.allAttrs.reset() : new Backbone.Collection();
                self.allAttrs.reset(otc.get("attrs").models);
                self.updateAvailableAttributes();
                deferred.resolve();
            }, this);
            return deferred.promise();
        },
        updateIndexerConfigs: function() {
            var self = this;
            var deferred = $.Deferred();

            // Fetch all the names of the indexer configs
            app.context.configService.getIndexerConfigNames(function(names) {
                self.indexerConfigs = names;
                deferred.resolve();
            }, this);

            return deferred.promise();  
        },
        updateAvailableAttributes: function() {
            var self = this;
            this.availableAttrs = this.availableAttrs ? this.availableAttrs.reset() : new Backbone.Collection();
            var tempSelectedAttrs = self.individualDashlet.get("selectedAttributes");
            var tempSelectedAttributes = [];
            var newSelectedAttrs = [];
            //is this an array of strings?
            if (tempSelectedAttrs && _.isString(tempSelectedAttrs[0])) {
                //yes it is, lets convert this old config
                newSelectedAttrs = _.map(tempSelectedAttrs, function(attr) {
                    var attributeWithLabel = _.find(self.allAttrs.models, function(fullAttr) {
                        return fullAttr.get("ocName") === attr;
                    });
                    return { ocName: attr, label: attributeWithLabel.get("label") };
                });
            } else {
                //It isn't an array of strings, but let's ensure it's a backbone collection
                newSelectedAttrs = convertToCollection(self.individualDashlet.get("selectedAttributes"));
                newSelectedAttrs = _.map(newSelectedAttrs.models, function(model) {
                    return { 'ocName': model.get('ocName'), 'label': model.get('label') };
                });
            }
            tempSelectedAttributes = _.pluck(newSelectedAttrs, 'ocName');
            this.allAttrs.each(function(attr) {
                if ($.inArray(attr.get('ocName'), tempSelectedAttributes) === -1) {
                    this.availableAttrs.add(attr);
                }
            }, this);
        },
        // Action Menu
        addActions: function() {
			if (!(this.options.individualDashlet.get("dashletActionConfig") instanceof Backbone.Model)) {
				this.options.individualDashlet.set(
                    "dashletActionConfig",
                    new SavedSearchDashletActionConfig.Model(this.options.individualDashlet.get("dashletActionConfig"))
                );
            }

			this.setView("#dashlet-action-config-outlet", new SavedSearchDashletActionConfig.Views.Layout({
    			model : this.options.individualDashlet.get("dashletActionConfig"), 
    			tracName : this.options.tracName
    		})).render();
    	},
        afterRender: function() {
            //don't break the parent afterRender
            BaseDashConfig.ConfigView.prototype.afterRender.apply(this, {});
            var self = this;

            // ActionMenu
            this.renderPrevent = true;

            //build object types
            this.updateObjectTypes().done(function() {
                if (self.selectedType) {
                    self.updateAllAttributes().done(function() {
                        self.updateIndexerConfigs().done(function() {
                            //all attributes retrieved for this type
                            //render tossacross
                            self.renderCriteriaAttrs();
                            self.buildAttrsTossAcross();
                            self.updateSelectedAttrs();
                            self.updateSortAttrs();
                            self.updateSortOrder();
                            self.updateLinkedIndexer();             
                    	});
                    });
                }
            });
        },
        serialize: function() {
            return {
                sortOrder: this.individualDashlet.get("sortOrder"),
               // sortAttribute: this.individualDashlet.get("sortAttribute"),
                tracs: this.tracNames,
                "controlChevron": this.iconChevron,
                "controlVisibility": this.contentVisibility,
                "dashletId": this.options.individualDashlet.get("dashletId"),
                "dashletName": this.options.individualDashlet.get("dashletName"),
                "visibilityControlChecked": this.options.individualDashlet.get("allowUserVisibilityControl"),
                sortAttribute: this.individualDashlet.get("sortAttribute"),
                linkedIndexerConfig: this.individualDashlet.get("linkedIndexerConfig")
            };
        }
    });

    return SavedSearchDashletConfig;
});