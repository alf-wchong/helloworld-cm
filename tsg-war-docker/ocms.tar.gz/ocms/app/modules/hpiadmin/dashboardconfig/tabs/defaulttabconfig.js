// this is here to allow dashboardconfig to usee a default daslet config w/o causing a circular dep
define([
	'app',
	'modules/hpiadmin/dashboardconfig/basedashconfig'
],
function(app, BaseDashConfig) {

	var DefaultTab = app.module();

	DefaultTab.Model = BaseDashConfig.TabModel.extend({});

	DefaultTab.View = BaseDashConfig.ConfigView.extend({
		initialize: function(options) {
			// we want to call our parent dashboard config view so we get all the common functionality (e.g., security groups)
			 BaseDashConfig.ConfigView.prototype.initialize.apply(this, options);
		}
	});

	return DefaultTab;
});