define([
	"app",
	"modules/common/tossacross"
],
function(app, TossAcross) {
	"use strict"; 

	// Create a new module.
	var BaseDashConfig = app.module();

	BaseDashConfig.Groups = Backbone.Model.extend({
		url: function(){
			return app.serviceUrlRoot + "/groups";
		}
	});

	BaseDashConfig.Group = Backbone.Model.extend({
		defaults: {
			'groupName' : '',
			'displayName': ''
		},
		initialize: function(options){
			this.set('groupName', options.groupName);
			this.set('displayName', options.displayName || options.groupName);
		}
	});

	BaseDashConfig.GroupCollection = Backbone.Collection.extend({
		model: BaseDashConfig.Group
	});

	BaseDashConfig.Groups.View = Backbone.Layout.extend({
		template: "hpiadmin/dashboardconfig/groups-tossacross",
		model: BaseDashConfig.Groups,
		initialize: function(options){
			this.model = options.model || null;

			this.groups = new BaseDashConfig.Groups();
			this.restrictedGroups = [];
			this.getGroups().done($.proxy(function(){
				this.fetched = true;
				this.renderGroups();
			}, this));
		},
		getGroups: function(){
			var self = this;
			return this.groups.fetch({
				success: function(model){
					self.groupBeans = new Backbone.Collection();
					_.each(model.attributes, function(group){
						//We don't want any undefined groups.
						if(group.authorityId){
							self.groupBeans.add({
								'groupName' : group.authorityId,
								'displayName': group.displayName
							});
						}
					});
					self.restrictedGroups = self.groupBeans.pluck('groupName');
					//remove any groups configured for this dashlet
					var allowedGroups = self.model.get('allowedGroups');
					var allowedGroupsNames = [];
					//Setting 'allowedGroups' to be just an array of strings (the groupNames) for consistency.
					_.each(allowedGroups, function(group){
						if(group.groupName){
							allowedGroupsNames.push(group.groupName);
						}else{
							allowedGroupsNames.push(group);
						}
					});
					self.model.set('allowedGroups', allowedGroupsNames);
					self.restrictedGroups = _.reject(self.restrictedGroups, function(group){
						var allow = false;
						_.each(self.model.get('allowedGroups'), function(allowedGroupName){
							if(allowedGroupName === group){
								allow = true;
								return;
							}
						});
						return allow;
					});
				},
				error: function(xhr, status){
					app.log.debug(window.localize("modules.hpiAdmin.dashboardConfig.baseDashConfig.failedToGet"));
				}
			});
		},
		// use this function to insert the fetched groups on the DOM elements - ONLY CALL THIS IF THE DOM ELEMENTS HAVE BEEN RENDERED
		renderGroups: function() {
			this.allowedGroupsCollection = new BaseDashConfig.GroupCollection();
			if(this.model.has('allowedGroups')){
				_.each(this.model.get('allowedGroups'), function(groupName){
					var groupBean = this.groupBeans.findWhere({'groupName': groupName});
					if(groupBean){
						this.allowedGroupsCollection.add(groupBean.attributes);
					}
				}, this);
			}

			this.deniedGroupsCollection = new BaseDashConfig.GroupCollection();
			_.each(this.restrictedGroups, function(groupName){
				var groupBean = this.groupBeans.findWhere({'groupName': groupName});
				if(groupBean){
					this.deniedGroupsCollection.add(groupBean.attributes);
				}
			}, this);

			this.listenTo(this.allowedGroupsCollection, 'add remove reset', function(){
				this.model.set('allowedGroups', this.allowedGroupsCollection.pluck('groupName'));
			}, this);

			this.typesTossAcross = new TossAcross.Layout({
				clickAcross: true,
				srcCollection: {
					title: window.localize("modules.hpiAdmin.dashboardConfig.baseDashConfig.deniedGroups"),
					filter: true,
					labelAttr: 'displayName',
					collection: this.deniedGroupsCollection
				},
				targetCollections: [
					{
						title: window.localize("modules.hpiAdmin.dashboardConfig.baseDashConfig.allowedGroup"),
						labelAttr: 'displayName',
						collection: this.allowedGroupsCollection
					}
				]
			});

			this.setView('.toss-across', this.typesTossAcross).render();
		},
		afterRender: function() {
			if(this.fetched){
				this.renderGroups();
			}
		}
	});

	BaseDashConfig.DashletModel = Backbone.Model.extend({
		// this should be a function otherwise every instance will share this defaults object (if it's an object instead)
		defaults: function() {
			return {
				dashletName: "",
				dashletType: "",
				dashletId: "",
				allowedGroups: [],
				displayTabs: ["baseTab"],
				ordinal: 0	
			};
		}
	});

	BaseDashConfig.TabModel = Backbone.Model.extend({
		// this should be a function otherwise every instance will share this defaults object (if it's an object instead)
		defaults: function() {
			return {
				tabName: "",
				tabId: "",
				tabColNum: ""
			};
		}
	});

	BaseDashConfig.ConfigView = Backbone.Layout.extend({
		template: "hpiadmin/dashboardconfig/dashlets/dashletconfig",


		defaults: {
			individualDashlet: null,
			tracName: '',
			dashletType: ''
		},

		events: {
			"click .dashlet-toggle": "toggleDashlet",
			"change #dashletName" : "setDashletName",
			"change #dashletId" : "setDashletId",
			"click .dashlet-delete" : "dashletDelete"
		},
		
		initialize: function() {
			//setup security view
			this.groups = new BaseDashConfig.Groups.View({
				model: this.options.individualDashlet
			});

			// the dashlet name so we can display it to the user - not an observable because at the moment it can't change
			this.dashletName = this.options.individualDashlet.get("dashletName");

			this.iconChevron = "glyphicon glyphicon-chevron-down";
			this.contentVisibility = false; 
		},
		// this is called when the user clicks the dashlet header to expand or contract the dashlet
		toggleDashlet: function(event) {
			// if the dashlet content is visible, we want to hide it
			if(this.contentVisibility) {
               this.iconChevron = "glyphicon glyphicon-chevron-down";
                this.contentVisibility = false;
            } else { // this dashlet content is not visible right now, so let's show it
                this.iconChevron = "glyphicon glyphicon-chevron-up";
                this.contentVisibility = true;
            }
            this.render();
		},
		dashletDelete: function(event){
			// we want to stop the propagation - otherwise our toggle will get called
			event.stopPropagation();
			app.trigger("dashBoardConfig:dashletDelete", this.dashletName);
		},
		setDashletName: function(event) {
			this.options.individualDashlet.set("dashletName", this.$("#dashletName").val());
			this.dashletName = this.$("#dashletName").val();
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
		setDashletId: function() {
			this.options.individualDashlet.set("dashletId", this.$("#dashletId").val());
			this.iconChevron = "glyphicon glyphicon-chevron-up";
			this.render();
        },
		// expose the security groups fetch
		fetchGroups: function() {
			return this.groups.getGroups();
		},
		afterRender: function(){
			// set the dashlet security view and render it
			this.setView('.groups', this.groups).render();
			kb.applyBindings(this, this.$el[0]);

			self.$('[data-toggle="tooltip"]').tooltip();
		},

		serialize: function() { 
            return { 
                "controlChevron": this.iconChevron,
                "controlVisibility" : this.contentVisibility,
                "dashletId" : this.options.individualDashlet.get("dashletId"),
                "dashletName" : this.options.individualDashlet.get("dashletName")
            };
        }
	});

	return BaseDashConfig;
});