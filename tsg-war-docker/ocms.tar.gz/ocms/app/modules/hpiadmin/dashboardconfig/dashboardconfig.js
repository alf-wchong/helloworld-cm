define([
	"app",
	"modules/hpiadmin/hpiadmin",
	"modules/hpiadmin/dashboardconfig/basedashconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/defaultdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/recentobjectsdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/savedsearchdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/awinboxdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/inboxdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/reportingdashlet/reportingdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/workflowreportingdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/incompletetagdashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/iframedashletconfig",
	"modules/hpiadmin/dashboardconfig/dashlets/notificationsdashletconfig",
	"modules/common/tossacross",
	"modules/hpiadmin/dashboardconfig/tabs/defaulttabconfig"
],
function(app, Hpiadmin, BaseDashConfig, DefaultDashlet, RecentObjectsDashlet, SavedSearchDashlet, AWInboxDashlet, InboxDashlet, ReportingDashlet, WorkflowReportingDashlet, IncompleteTagDashlet, IFrameDashlet, NotificationsDashlet, TossAcross, TabModel) {
	
	"use strict"; 

	var DashConfig = app.module();

	DashConfig.DashletModelCollection = Backbone.Collection.extend({
		model: BaseDashConfig.DashletModel
	});

	DashConfig.GroupCollection = Backbone.Collection.extend({
		model: DashConfig.Group
	});

	DashConfig.Views.Tab = {};
	DashConfig.Views.Tab.Create = {};

	DashConfig.Model = Hpiadmin.Config.extend({
		type: "DashboardConfig",
		
		defaults: {
			type: "DashboardConfig",
			enableDraggability: false,
			numberOfColumns: 2
		},
		
		// in case we are ever just creating a dashconfig model - like in unit tests...
		initialize: function(options) {
			if(options && options.dashlets) {
				this.set("dashlets", new DashConfig.DashletModelCollection(options.dashlets));
			} else {
				this.set("dashlets", new DashConfig.DashletModelCollection());
			}
		},
		parseResponse: function(response){
			if(this.id) {
				//just want the id
				response = _.pick(response, 'id');
			} else if(response && response.dashlets) {
				this.set("dashlets", new DashConfig.DashletModelCollection(response.dashlets));
				delete response.dashlets;
			} else {
				this.set("dashlets", new DashConfig.DashletModelCollection());
			}

			return response;
		}
	});

	// this is the create modal view for creating a new dashlet
	DashConfig.Views.Create = Backbone.Layout.extend({
		template: "hpiadmin/dashboardconfig/dashconfig-new",

		events: {
			// we want to set the name on every (debounced) keyup so we can validate it to enable / disable the create button
			"keyup #new-dashlet-name" : "setDashletName",
			// we want to set the name on every (debounced) keyup so we can validate it to enable / disable the create button
			"keyup #new-dashlet-id" : "setDashletId",
			// we want to set the type so we can validate if this new dashlet is ready to be created
			"change #new-dashlet-type" : "setDashletType",
			// button click on the new dashlet button
			"click #new-dashlet-save" : "createDashlet"
		},

		initialize: function(options) { 
			// let's make a clean model for this new dashlet
			this.model = new BaseDashConfig.DashletModel();

			//all of the dashlets that are already condifured
			this.dashletModels = this.options.dashletModels;

			// this will hold our UI DOM elements so we can store references to them here
			this.ui = {};
		},

		// this function validates the dashlet name and dashlet type to see if we can enable / disable the create button
		validate: function() {

			var dashletIds = this.dashletModels.pluck("dashletId");

			//see if if the dashletId typed in is already in use
    		var dashletIdNotUnique = _.contains(dashletIds, this.model.get("dashletId"));

			// if we don't have a name or we don't have a type we need to disable the create button
			if(!this.model.get("dashletName") || !this.model.get("dashletType") || dashletIdNotUnique) {
				this.ui.savebutton.prop("disabled", true);
				//if the id is already being used show a validaiton message
				if(dashletIdNotUnique) {
					$(".dashletIdValidation").show();
				}
				else {
					$(".dashletIdValidation").hide();
				}
				return false;	
			}

			// at this point the dashlet is in a valid state so we can enable the create button
			this.ui.savebutton.prop("disabled", false);
			$(".dashletIdValidation").hide();
			return true;
		},

		// this method is debounced so we don't call it EVERY keystroke but rather we wait til they stop typing a bit
		setDashletName: _.debounce(function() { 
			this.model.set("dashletName", this.ui.newDashletName.val());
			this.validate();
		}, 300),

		// this method is debounced so we don't call it EVERY keystroke but rather we wait til they stop typing a bit
		setDashletId: _.debounce(function() { 
			this.model.set("dashletId", this.ui.newDashletId.val());
			this.validate();
		}, 300),

		setDashletType: function() {
			this.model.set("dashletType", this.ui.newDashletType.val());
			this.validate();
		},

		createDashlet: function() { 
			this.trigger("dashlet:create", this.model);
			app.trigger("alert:close");
		},

		afterRender: function() { 
			// store references to our DOM elements
			this.ui.newDashletName = this.$("#new-dashlet-name");
			this.ui.newDashletId = this.$("#new-dashlet-id");
			this.ui.newDashletType = this.$("#new-dashlet-type");
			this.ui.savebutton = this.$("#new-dashlet-save");
			this.validate();
		}
	});

	// Dashboard Tabs
	DashConfig.Views.Tab.Create = Backbone.Layout.extend({
		template: "hpiadmin/dashboardconfig/dashconfig-newTab",

		events: {
			// we want to set the name on every (debounced) keyup so we can validate it to enable / disable the create button
			"change #new-tab-name": "setTabName",
			"change #new-tab-colNum": "setTabColNum",
			// button click on the new dashlet button
			"click #new-tab-save": "createTab"
		},

		initialize: function () {
			// let's make a clean model for this new dashlet
			this.model = new BaseDashConfig.TabModel();

			// this will hold our UI DOM elements so we can store references to them here
			this.ui = {};
		},

		// this function validates the dashlet name and dashlet type to see if we can enable / disable the create button
		validate: function () {
			// if we don't have a name or we don't have a type we need to disable the create button
			if (!this.model.get("tabName") || !this.model.get("tabColNum") ) {
				this.ui.savebutton.prop("disabled", true);
				return false;
			}

			// at this point the dashlet is in a valid state so we can enable the create button
			this.ui.savebutton.prop("disabled", false);
			return true;
		},

		// this method is debounced so we don't call it EVERY keystroke but rather we wait til they stop typing a bit
		setTabName: _.debounce(function () {
			this.model.set("tabName", this.ui.newTabName.val());
			this.validate();
		}, 300),

		setTabColNum: _.debounce(function () {
			var self = this;

			if ( this.ui.newTabColNum.val() === "1" || this.ui.newTabColNum.val() === "2" ||
				this.ui.newTabColNum.val() === "3" || this.ui.newTabColNum.val() === "4" ) {
				this.model.set("tabColNum", this.ui.newTabColNum.val());
			} else {
				this.model.set("tabColNum", 2);
			}
			this.validate();
		}, 300),

		createTab: function () {
			this.trigger("tab:create", this.model);
			app.trigger("alert:close");
		},

		afterRender: function () {
			// store references to our DOM elements
			this.ui.newTabName = this.$("#new-tab-name");
			this.ui.newTabColNum = this.$("#new-tab-colNum");
			this.ui.savebutton = this.$("#new-tab-save");
			this.validate();
		}
	});

	DashConfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/dashboardconfig/dashconfig-mainlayout",

		events: {
			"click #dashlet-add-new" : "createNewDashlet",
			"click #dashboard-save" : "saveDashlets",
			"change #enableDragging": "enableDragging",
			"change #numberOfColumns": "numberOfColumns",
			"click #tab-add-new": "createNewTab",
			"click #navTabs li": "addTabsTossacross",
			"click #delete-tab": "deleteTab",
			"click #dashboardtab-save": "saveTab",
			"click .dashTab": "updateCurrentTab"
		},

		defaults: {
			configViews: {
				'SavedSearchDashlet' : SavedSearchDashlet.View,
				'AWInboxDashlet' : AWInboxDashlet.View,
				'InboxDashlet' : InboxDashlet.View,
				'RecentObjectsDashlet' : RecentObjectsDashlet.View,
				'ReportingDashlet' : ReportingDashlet.View,
				'WorkflowReportingDashlet' : WorkflowReportingDashlet.View,
				'IncompleteTagDashlet': IncompleteTagDashlet.View,
				'IFrameDashlet' : IFrameDashlet.View,
				'NotificationDashlet' : NotificationsDashlet.View
			}
		},

		serialize: function () {
				return { 
					tabs: this.tabModels,
					atLeastOneDashletIsConfigured: this.dashletModels && this.dashletModels.length > 0
				};
		},

		initialize: function(options){
			var self = this;
			this.options = _.defaults({}, this.defaults, options);

			// get our dashlet models already configured
			this.dashletModels = this.options.model.get("dashlets");
			this.tabModels = this.options.model.get("tabs") || [];

				// we have no configured tabs, add in the default one
				if(this.tabModels.length < 1) {
					var model = new BaseDashConfig.TabModel({
						"tabColNum": 2,
						"tabName" : "Home",
						"tabId": "baseTab"
					});
					// add our new dashlet model to our list of models
					this.currentTab = model.get("tabId");
					this.tabModels.push(model.attributes);
					this.options.model.set("tabs", this.tabModels);
				}

			this.ui = {};
			this.enableDraggability = this.options.model.get("enableDraggability");

			this.availableDashlets = new BaseDashConfig.GroupCollection();
			this.selectedDashlets = new BaseDashConfig.GroupCollection();
			this.currentTab = "";

			app.listenTo(app,"dashBoardConfig:dashletDelete", function(event){
				self.deleteDashlet(event);
			});
		},

		// this function builds up all the views for the dashlets and sets them as sub-views of this view
		addAllDashlets: function() {
			// clear out our outlet for the new dashlet views
			this.remove("#dashlet-configs-outlet");
			
			// loop over each model and build an appropriate view for it
			this.dashletModels.each(function(dashletModel) {
				var dashletType = dashletModel.get("dashletType");

				var dashletView;
				if(this.options.configViews[dashletType]) {
					dashletView = new this.options.configViews[dashletType]({
						individualDashlet: dashletModel,
						// this is really not being used anymore - in the previous iteration this was always
						// being passed in as undefined - we think it may have been for the vision of trac
						// specific dashboards
						tracName: "default",
						dashletType: dashletType
					});
				} else {
					dashletView = new DefaultDashlet.View({
						individualDashlet: dashletModel,
						// this is really not being used anymore - in the previous iteration this was always
						// being passed in as undefined - we think it may have been for the vision of trac
						// specific dashboards
						tracName: "default",
						dashletType: dashletType
					});
				}

				// insert the dashlets in order based on the ordinal
				this.insertView("#dashlet-configs-outlet", dashletView);
			}, this);
		},

		// this is called when the user clicks the button to add a new dashlet
		createNewDashlet: function() {
			// let's create our modal dashlet create view and show it to the user
			var view = new DashConfig.Views.Create({
				dashletModels: this.dashletModels
			});
			app.trigger("alert:custom", { view: view });

			// when the user has clicked the create button on the modal, this will run
			this.listenTo(view, "dashlet:create", function(newDashlet) {
				// we've got our name and type so let's create an appropriate model
				var dashletType = newDashlet.get("dashletType");
				var dashletName =  newDashlet.get("dashletName");
				var dashletId = newDashlet.get("dashletId");	//## - kevin

				var newDashletModel;
				if(dashletType === "SavedSearchDashlet") {
					newDashletModel = new SavedSearchDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});	
				} else if(dashletType === "AWInboxDashlet") {
					newDashletModel = new  AWInboxDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} else if(dashletType === "InboxDashlet") {
					newDashletModel = new  InboxDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} 
				else if(dashletType === "RecentObjectsDashlet") {
					newDashletModel = new RecentObjectsDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} 
				else if(dashletType === "ReportingDashlet") {
					newDashletModel = new ReportingDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				}
				else if(dashletType === "WorkflowReportingDashlet") {
					newDashletModel = new WorkflowReportingDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} else if(dashletType === "IncompleteTagDashlet") {
					newDashletModel = new IncompleteTagDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} else if(dashletType === "IFrameDashlet") {
					newDashletModel = new IFrameDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} else if(dashletType === "NotificationDashlet") {
					newDashletModel = new NotificationsDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				} else {
					newDashletModel = new DefaultDashlet.Model({
						dashletType: dashletType,
						dashletName: dashletName,
						dashletId: dashletId,
						displayTabs: ["baseTab"]
					});
				}

				if(newDashletModel) {
					// add our new dashlet model to our list of models and render this view (which will create a 
					// view for each model we have in the dashletModels array)
					this.dashletModels.push(newDashletModel);	
					this.render();
				}
			}, this);
		},

		enableDragging: function() {
			
			if($("#enableDragging").attr('checked')) {
				this.options.model.set("enableDraggability",true);
			}
			else {
				this.options.model.set("enableDraggability",false);
			}
		},

		numberOfColumns: function(numberOfColumnsDiv) {
			this.options.model.set("numberOfColumns", parseInt(numberOfColumnsDiv.target.value,10));
		},

		// this is triggered when the user clicks the save button for the dashboard config
		saveDashlets: function() {
			// set our dashlets on our dashboard config model to be our current collections of dashlet models
			this.options.model.set("dashlets", this.dashletModels);

			// trigger our save operation on the dashboard config model
			this.options.model.save({}, {
				success: function() {
					app.trigger("modelSaveOrDestroy");
					Backbone.history.navigate("admin/DashboardConfig", { replace: true, trigger:true });
					app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
				}
			});
		},

		reorderTab: function(data) {
			var newTabAry = Array.from(data);
			var tabAry = Array.from(this.tabModels);
			this.tabModels = [];
			
			_.each(newTabAry, function(newTab){
				this.tabModels.push(_.find(tabAry, function (oldTab) {
					return oldTab.tabId === newTab.getElementsByClassName("dashTab").item("a").id;
				}));
			}, this);
			this.options.model.set("tabs", this.tabModels);
		},

		// this is called when the user clicks the delete button for an individual dashlet
		deleteDashlet: function(dashletName) {
			// find the view in our list of views that has this dashletName as its name
			var self = this;
			this.getViews('#dashlet-configs-outlet').each(function(dashletView) {
				if(dashletView.dashletName === dashletName){
					//removes dashlet from the view
					dashletView.remove();
					var model = self.dashletModels.findWhere({ dashletName: dashletName });
					//removes dashlet from the other storage location, the model
					self.dashletModels.remove(model);
				}
			});
		},
		
		// this is called when the user drops a dashlet into a new position in the order of dashlets
		updateSort: function(dashletName, position) {

			// find the model that represents this dashlet
			var model = this.dashletModels.findWhere({ dashletName: dashletName });

			// remove the current model so we can re-add it with the updated ordinal
			this.dashletModels.remove(model);

			// update the ordinals on each model
			this.dashletModels.each(function(model, index) {
				var ordinal = index;
				if(index >= position) {
					ordinal += 1;
				}
				model.set('ordinal', ordinal);
			});            

			// add the model back with it's new ordinal
			model.set('ordinal', position);
			this.dashletModels.add(model, { at: position });
		},

		createNewTab: function () {
			this.changeTabName();
			this.changeColumnNumber();
			var view = new DashConfig.Views.Tab.Create();
			app.trigger("alert:custom", { view: view });

			// when the user has clicked the create button on the modal, this will run
			this.listenTo(view, "tab:create", function (newDashlet) {
				var date = new Date();
				var tabId = date.getTime();
				var tabName = newDashlet.get("tabName");
				var tabColNum = newDashlet.get("tabColNum");

				var newTabModel = new TabModel.Model({
					tabId: tabId.toString(),
					tabName: tabName,
					tabColNum: tabColNum
				});

				if (newTabModel) {
					// add our new dashlet model to our list of models and render this view (which will create a 
					// view for each model we have in the dashletModels array)
					this.currentTab = newTabModel.get("tabId");
					this.tabModels.push(newTabModel.attributes);
					this.options.model.set("tabs", this.tabModels);
					this.saveDashlets();
					this.render();
				}
			}, this);
		},

		changeTabName: function () {
				_.each(this.tabModels, function(tab){
					if(tab.updateName && this.currentTab !== tab.tabId)
					{
						tab.tabName = tab.updateName;
						tab.updateName = "";
					}
					
					if($("#modifyTabName").val() && this.currentTab === tab.tabId)
					{
						tab.tabName = $("#modifyTabName").val();
					}
				},this);
		},

		changeColumnNumber: function () {
				_.each(this.tabModels, function(tab){
					if(tab.updateCol && this.currentTab !== tab.tabId)
					{
						tab.tabColNum = tab.updateCol;
						tab.updateCol = "";
					}
					
					if($("#modifyNumCol").val() && this.currentTab === tab.tabId)
					{
						tab.tabColNum = $("#modifyNumCol").val();
					}
				},this);
		}, 

		updateCurrentTab: function(tab) {
			if($("#modifyTabName").val()){
				_.each(this.tabModels, function(tab){
					if(this.currentTab === tab.tabId)
					{
						tab.updateName = $("#modifyTabName").val();
					}
				}, this)
			}

			if($("#modifyNumCol").val()){
				_.each(this.tabModels, function(tab){
					if(this.currentTab === tab.tabId)
					{
						tab.updateCol = $("#modifyNumCol").val();
					}
				}, this)
			}

			$("#modifyTabName").val("");
			$("#modifyNumCol").val("");

			this.currentTab = $(tab.currentTarget).attr("id");
		},

		deleteTab: function () {
			this.changeTabName();
			this.changeColumnNumber();
			var self = this;
			var tabIndex;

			_.each(this.tabModels, function (tab, index) {
				if (tab.tabId == self.currentTab) {
					self.tabModels.splice(index, 1);
				}
			});

			_.each(this.dashletModels.models, function (dashlet) {
				tabIndex = -1;
				if (_.contains(dashlet.get("displayTabs"), self.currentTab) || _.contains(dashlet.get("displayTabs"), "")) {
					tabIndex = dashlet.get("displayTabs").indexOf(self.currentTab);
					dashlet.get("displayTabs").splice(tabIndex, 1);
				}
			});
			this.currentTab = "";
			this.saveDashlets();
			this.render();
		},

		saveTab: function(){
			this.changeTabName();
			this.changeColumnNumber();
			this.saveDashlets();
			this.render();
		},

		addTabsTossacross: function (evt) {
			var self = this;

			if (evt === undefined && this.tabModels.length > 0) {
				if(this.currentTab == "") {
					this.currentTab = this.tabModels[0].tabId;
				}
			} else if (evt !== undefined && evt.srcElement.id !== undefined) {
				this.currentTab = evt.srcElement.id;
			} else {
				this.currentTab = "baseTab";
			}

				var numberOfDashletsConfigured = this.options.model.get("dashlets").models.length;
				var currentTabModel = _.findWhere(this.tabModels, {tabId: this.currentTab});

				if(currentTabModel.selectedDashlets instanceof Backbone.Collection === false) {
					var newCollection = new Backbone.Collection();
					// We are now going to strip each dashlet in the collection down to dashletId and dashletName
					// Before we were storing the whole models, but the models were not updating on changes so most of the information was stale
					// and did not line up with the correct full dashlet models causing confusion

					_.each(currentTabModel.selectedDashlets, function(individualDashlet){
						var dashletModel = new Backbone.Model({
							dashletId: individualDashlet.dashletId,
							dashletName: individualDashlet.dashletName
						});
						newCollection.add(dashletModel);
					}, this);
					currentTabModel.selectedDashlets = newCollection;
				}

				// we are clearing this out since we loop through each of the dashlets below.
				// if the dashlet is already in 'selectedDashlets' we won't add again
				// otherwise, we will just add to the 'availableDashlets'
				currentTabModel.availableDashlets = new Backbone.Collection();

				if((currentTabModel.availableDashlets.length + currentTabModel.selectedDashlets.length) !== numberOfDashletsConfigured) {
					_.each(this.options.model.get("dashlets").models, function (dashlet) {
						if(currentTabModel.availableDashlets.pluck("dashletId").indexOf(dashlet.get("dashletId")) === -1 && currentTabModel.selectedDashlets.pluck("dashletId").indexOf(dashlet.get("dashletId")) === -1){
							// Doing the same thing with dashletId and dashletName as for selectedDashlet, as the same issue was occurring
							var dashletModel = new Backbone.Model({
								dashletId: dashlet.get('dashletId'),
								dashletName: dashlet.get('dashletName')
							});
							currentTabModel.availableDashlets.add(dashletModel);
						}
					});
				}

				this.typesTossAcross = new TossAcross.Layout({
					clickAcross: true,
					srcCollection: {
						title: 'Available Dashlets',
						filter: true,
						labelAttr: 'dashletName',
						collection: currentTabModel.availableDashlets
					},
					targetCollections: [{
						title: 'Enabled Dashlets',
						labelAttr: 'dashletName',
						collection: currentTabModel.selectedDashlets
					}]
				});

			this.setView('.tabs-toss-across', this.typesTossAcross).render();
		},

		// before we render this view, let's create a sub-view for each of our dashlet models we currently have
		beforeRender: function() {
			this.addAllDashlets();
		},

		afterRender: function() {
			var self = this;

			this.addTabsTossacross();

			// we're done rendering so we can now set up the dashlets to be sortable
			this.ui.configs = this.$('#dashlet-configs-outlet');
			this.ui.configs.sortable({
				handle: ".dashlet-toggle",
				update: function(event, ui) {
					var dashletName = ui.item.find(".dashletName").text();
					self.updateSort(dashletName, ui.item.index());
				}
			});
			this.ui.configs.disableSelection();
			
			this.ui.dashTabs = this.$("#navTabs");
			this.ui.dashTabs.sortable({
				update: function(event, ui) {
					self.reorderTab(event.target.children);
				}
			});
		
		
		
			// we now know the sub-views have rendered as well so let's fetch their groups and render them
			this.getViews('#dashlet-configs-outlet').each(function(dashletView) {
				// fetch the dashlet's groups and render them
				dashletView.fetchGroups().done(function() {
					dashletView.groups.renderGroups();
				});
			});

			this.listenTo(this.availableDashlets, 'remove', function (evt) {
				if (_.contains(evt.get("displayTabs"), self.currentTab)) {
					var index = evt.get("displayTabs").indexOf(self.currentTab);
					evt.get("displayTabs").splice(index, 1);
				} else {
					evt.attributes.displayTabs.push(self.currentTab);
				}
			}, this);

			this.$('#enableDragging').attr('checked',this.enableDraggability);
			this.$("#col-option-"+this.options.model.attributes.numberOfColumns).attr("selected","selected");

			if (this.currentTab == "") {
				$("#navTabs li:first-child").addClass("active");
			} else {
				$("[id='" + this.currentTab + "']").parent().addClass("active");
			}
			
		}
	});
	
	return DashConfig;
});