define([
    "app",
    "knockback"
], 
function(app, kb){

    var SendNotificationConfig  = app.module();

    SendNotificationConfig.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/sendnotificationconfig",

        initialize: function () {
            var viewModel = this.options.viewModel;
            var model = viewModel.model();

            viewModel.maxMessageLength = kb.observable(model, "maxMessageLength");
            viewModel.notificationEmailSubject = kb.observable(model, "notificationEmailSubject");
            viewModel.eventName = kb.observable(model, "eventName");
            viewModel.attrToShow = kb.observable(model, "attrToShow");
            viewModel.selectedFormName = kb.observable(model, "selectedFormName");

            var selectedPlaceholder = viewModel.selectedFormName();

            viewModel.formNames = ko.observableArray();
            
            // get all of the available workflow forms
            app.context.configService.getAdHocFormConfigNames(function(formConfigNames) {
                viewModel.formNames(formConfigNames);
                viewModel.selectedFormName(selectedPlaceholder);
            });

            viewModel.resolverMode = kb.observable(model, "resolverMode");
            //Defaulting resolverMode to "Stage"
            if (!viewModel.resolverMode()) {
                viewModel.resolverMode("Stage");
            }
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    return SendNotificationConfig;
});