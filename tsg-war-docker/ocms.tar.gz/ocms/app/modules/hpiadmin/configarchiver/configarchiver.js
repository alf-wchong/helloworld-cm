define([
    "app",
    "modules/hpiadmin/hpiadmin",
    "modules/common/spinner",
    "modules/common/downloadutils",
    "jqueryDownload"
],
//map dependencies 
function(app, Hpiadmin, HPISpinner, downloadUtils) {

    "use strict";

    var ConfigArchiver = app.module();

    ConfigArchiver.Model = Hpiadmin.Config.extend({
        type: "ConfigArchiver",
        defaults: {
            type: "ConfigArchiver"
        }
    });

    ConfigArchiver.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/configarchiver/configarchiver-layout",

        events: {
            'click .export-header' : 'toggleExportVisibility',
            'click .import-header' : 'toggleImportVisibility'
        },
        initialize: function() {
            // let's make a clean model for this new dashlet
            this.defaultModel = new ConfigArchiver.Model();

            // get our dashlet models already configured
            this.dashletModels = this.options.model.get("developerModels");

            // this will hold our UI DOM elements so we can store references to them here
            this.ui = {};   
        },
        toggleExportVisibility: function() {
            this.ui.exportUpDownIndicator.toggleClass("glyphicon-chevron-up glyphicon-chevron-down"); 
            this.$('#toggleExport').collapse('toggle');        
        },
        toggleImportVisibility: function() {
            this.ui.importUpDownIndicator.toggleClass("glyphicon-chevron-up glyphicon-chevron-down"); 
            this.$('#toggleImport').collapse('toggle');    
        },
        beforeRender: function(){
            this.renderViews();
        },
        afterRender: function() {

            this.ui.exportUpDownIndicator = this.$(".exportHideTracBtn");
            this.ui.importUpDownIndicator = this.$(".importHideTracBtn");        
        },
        renderViews: function() {
            var exportView = new ConfigArchiver.Views.ExportConfigs({
                model: this.defaultModel
            });
            var importView = new ConfigArchiver.Views.ImportConfigs({
                model: this.defaultModel
            });

            // insert the dashlets in order based on the ordinal
            this.insertView(".export-configs-outlet", exportView);

            this.insertView(".import-configs-outlet", importView);
        }

    });

    ConfigArchiver.Views.ExportConfigs = Backbone.Layout.extend({
        template: "hpiadmin/configarchiver/configarchiver-export",

        events: {
            'click #exportBtn' : 'submitForm',       
            'click #enable' : 'enableUserPref', 
            'click #disable' : 'disableUserPref' 
        },      
        enableUserPref: function() {

            this.userPref = true;
        },
        disableUserPref: function() {

            this.userPref = false;
        },
        //submit form to OC
        submitForm: function() {
            var self = this;

            self.spinner = HPISpinner.createSpinner({
                color: '#666'
            }, this.$el.find(".progressSpinner")[0]);

            app.trigger("alert:info", {
                header: window.localize("modules.hpiAdmin.configArchiver.exportingConfigs"), 
                message: window.localize("modules.hpiAdmin.configArchiver.exportMessage")
            });

            var data = {
                name: "configArchiver"
            };

            downloadUtils.asyncDownload(app.serviceUrlRoot + "/configs/exportConfigs?userPref="+this.userPref+"&appId="+app.appId, data); 
            setTimeout(function(){ HPISpinner.destroySpinner(self.spinner); }, 4000); 
        },
        initialize: function() {
             
           this.ui = {};
           this.userPref = false;
           this.exportName = "";
        }
    });

    ConfigArchiver.Views.ImportConfigs = Backbone.Layout.extend({
        template: "hpiadmin/configarchiver/configarchiver-import",

        events: {
            'click #importBtn' : 'importConfigs',
            'click .clearDocButton' : 'clearConfigs'
        }, 
        initialize: function(){

            // UI elements
            this.ui = {};
            this.ui.hideError = true;
            this.ui.hideImportBtn = true;
            this.ui.hideClearBtn = true;
            this.ui.initialText = true;
            this.ui.hideSelect = false;
            this.ui.hideFileName = true;
            
            this.configFile = {};
            this.configFileName = {};

            this.fileUploadElement = ".dropZone";
            this.selectUploadElement = ".fileuploader-input";
            
        },
        // after we render
        afterRender: function() {

            var self = this;

            //html5 drag and drop file upload for browsers that support it
            this.$(self.fileUploadElement).bind('dragenter dragover', function(e) { 
                e.preventDefault();
                $(this).css({
                    'border': '3px dashed #e83a00'
                });
            });

            this.$(self.fileUploadElement).bind('dragleave drop', function(e) {
                e.preventDefault();
                $(this).css({
                    'border': '2px dashed #c0c0c0'
                });
            });

            //dropzone file 
            this.$(self.fileUploadElement).fileupload({
                add: function(e, data) {
                   self._configFile(data);
                },
                dropZone: $(self.fileUploadElement)
            });

            //select documents file 
             this.$(this.selectUploadElement).fileupload({
                add: function(e, data) { 
                    self._configFile(data);                
                }, 
                dropZone: $(self.selectUploadElement)
            }); 

        },
        _configFile: function (file) {
            var self = this;
                 
            this.configFile = file.files[0];
            this.configFileName = file.files[0].name;  
            var fileExtension = this.configFileName.substring(this.configFileName.lastIndexOf(".")+1);

            this.ui.initialText = false;
            this.ui.hideFileName = false;
            this.ui.hideClearBtn = false;
            this.ui.hideSelect = true;

            if(fileExtension === "zip") {
               this.ui.hideImportBtn = false;            
            } else {
               this.ui.hideError = false;         
            }
            self.render();
        },

        importConfigs: function () {
            
            $("#dropZoneFile").css('background-color', '#c0c0c0');
            $('#importBtn').prop('disabled', true);
            $('.clearDocButton').prop('disabled', true);

            this.spinner = HPISpinner.createSpinner({
                color: '#666'
            }, this.$el.find(".progressSpinner")[0]);

            var fileName = this.configFileName;

            var fd = new FormData();
            fd.append('data', this.configFile, this.configFileName);

            $.ajax({            
                method: "POST",     
                url: app.serviceUrlRoot + "/configs/importConfigsWithFileObject?appId="+fileName,
                data: fd,
                context: this,

				//Form data objects need these set to false. Form data objects handle their own serialization
				//with the toString() methdod, which will be called when the ajax request is formed (outside jquery).
				processData: false,
				contentType: false,
                success: function (data){
                    var foldersAdded = data["Folders added"];
                    var docsAdded = data["Documents added"];  
                    var docsVersioned = data["Documents versioned"]; 

                    HPISpinner.destroySpinner(this.spinner);
                    this.clearConfigs();


                    //Could probably create an info view in the future for better formatting
                    app.trigger("alert:info", {
                        header: window.localize("modules.hpiAdmin.configArchiver.importSuccess"), 
                        message: 
                            window.localize("modules.hpiAdmin.configArchiver.importSuccessMessage") + window.localize("modules.hpiAdmin.configArchiver.foldersAdded") + foldersAdded + ' ' + window.localize("modules.hpiAdmin.configArchiver.docsAdded") + docsAdded + ' ' + window.localize("modules.hpiAdmin.configArchiver.docsVersioned") + docsVersioned + '.'
                    });        
                },
                error : function(data) {

                    HPISpinner.destroySpinner(self.spinner);
                    this.clearConfigs();

                    app.trigger("alert:error", {
                        header: window.localize("modules.hpiAdmin.configArchiver.importError"), 
                        message: window.localize("modules.hpiAdmin.configArchiver.importErrorMessage") + data.responseText 
                    });
                },
                global:false
            }); 
        },

        clearConfigs: function () {
            this.initialize();
            this.render();
        },
        serialize : function() {
            return {
                'hideError' : this.ui.hideError,
                'hideImportBtn' : this.ui.hideImportBtn,
                'initialText' : this.ui.initialText,
                'hideSelect' : this.ui.hideSelect,
                'hideFileName' : this.ui.hideFileName,
                'hideClearBtn' : this.ui.hideClearBtn,
                'fileName' : this.configFileName
            };
        }
    });
    return ConfigArchiver;
});



