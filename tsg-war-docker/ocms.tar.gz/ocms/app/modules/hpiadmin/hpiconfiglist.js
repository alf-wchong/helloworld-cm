define([
	"app",
	"modules/hpiadmin/hpiadmin-switcher",
	"modules/hpiadmin/stageconfig/stageconfig",
	"modules/hpiadmin/searchconfig/searchconfig",
	"modules/hpiadmin/indexerconfig/indexerconfig",
	"modules/common/spinner"
],  
// this is a container for adding generic controls and other functionality to each admin config without replicating views
function(app, Switcher, StageConfig, SearchConfig, IndexerConfig, HPISpinner) {
	"use strict";

	var HPIConfigList = app.module();

	HPIConfigList.View = Backbone.Layout.extend({
		template : "hpiadmin/hpiconfiglist",
		className : "hpiConfig",
		events: {
			"click #new-config-button" : "createConfig",
			"click .dropdown-menu li a" : "selectedConfig"
		},
		initialize : function(){
			this.config = this.options.config || null; //parent config that this list belongs to
			this.configClass = this.options.configClass || null; //config model
			this.configType = this.options.configType || null; //name of this config
			//based on the configClass, we can get the selected config
			this.configName = this.config.get(this.configType);
			// ui element object for storage
			this.ui = {};
		},
		selectedConfig: function(e){
			//update value on the model
			this.configName = this.$(e.currentTarget).text();
			this.config.set(this.configType, this.configName);
			this.updateDropdown();
		},
		createConfig: function(e) { 
			// todo: if you needed a custom view (creator) for a particular config type, you could check for the existence of a this.configClass.[yourview], and then inject it as the subview if needed
			// try to stick to convention and make it a standardized "NewConfig" view name though

			var view = new Switcher.Views.NewConfig({ configType: this.configClass });
			app.trigger("alert:custom", { view: view });
		},
		populateDropdown: function() { 
			var self = this;

			// clear existing html and hide the dropdown
			self.ui.dropdown.ul.html("");
			self.ui.dropdown.hide();

			// create our loading spinner
			var spinner = HPISpinner.createSpinner({
				lines: 9, // The number of lines to draw
				length: 4, // The length of each line
				width: 2, // The line thickness
				radius: 5, // The radius of the inner circle
				trail: 25, // Afterglow percentage
				shadow: true // Whether to render a shadow
			}, self.ui.spinner[0]);

			// get the list of available config names
			var configCollection = new this.configClass.Collection();
			configCollection.fetch({
				success: function(models){
					//don't keep a record of this call in the store
					models.each(function(model){
						var active = null;
						// determine if we should highlight the current config in the menu dropdown
						if(self.config.id && self.configName === model.get("name")) { 
							active = "active";
						}
						self.ui.dropdown.find("ul").append("<li class='"+ active +"'><a>" + model.get("name") + "</a></li>");
					});

					// stop the loading spinner
					HPISpinner.destroySpinner(spinner);
					// hide the div that contains the spinner
					self.ui.spinner.hide();

					// show the now populated dropdown
					self.ui.dropdown.show();

					self.updateDropdown();    
				}
			});  
		},
		updateDropdown: function(){
			// set the dropdown title to the name of the current config (or "Please Choose a Config" if none)
			if(this.configName) {
				this.ui.dropdown.btn.find("span#current-config").html(this.configName); 
			} 
		},
		afterRender: function(){
			// set ui elements
			this.ui.dropdown = this.$("#config-dropdown");
			this.ui.dropdown.btn = this.ui.dropdown.find("a.dropdown-toggle");
			this.ui.dropdown.ul = this.ui.dropdown.find("ul");
			this.ui.spinner = this.$(".spinner");
			
			// call helper functions after render
			this.populateDropdown();
		}
	});

	return HPIConfigList;
});