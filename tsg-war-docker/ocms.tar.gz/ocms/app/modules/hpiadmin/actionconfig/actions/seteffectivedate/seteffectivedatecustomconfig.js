define([
  // Application.
  "app",
  "modules/common/tossacross"
],

// Map dependencies from above array.
function(app, TossAcross) {
     "use strict";

     var SetEffectiveDateCustomConfig = {};

     //When action is configured for the first time, these are the ocNames of object types to set by default
     var defaultEnabledDocTypes = ['Controlled Document', 'Contract Document', 'Quality Document'];
     var defaultEnabledFormTypes = ['Page Set Instance'];

     SetEffectiveDateCustomConfig.View = Backbone.Layout.extend({
          template: "hpiadmin/actions/customconfig/seteffectivedate/seteffectivedateconfig",
          initialize: function(){
               var self = this;
               this.viewModel = self.options.viewModel;
               this.model = this.viewModel.model();

               //Find all configured object types and then create toss across views
               this.objectTypesConfigured = $.Deferred();
               app.context.configService.getAdminOTC(function (config){
                    self.objectTypes = config.get("configs");
                    self.initializeModelVars();
                    self.setUpTossAcrossViews();
                    self.objectTypesConfigured.resolve();
               });
          },
          initializeModelVars: function(){

               //If this is a new model, initialize with default values
               if(!this.model.get('enabledDocTypes')){

                    this.model.set('enabledDocTypes', new Backbone.Collection([]));

                    //Each of these items in the array are ocNames of object types we want to use by default
                    _.each(defaultEnabledDocTypes, function(ocName) {
                         var model = this.objectTypes.findWhere({
                              ocName: ocName
                         });

                         if(model) {
                              this.model.get('enabledDocTypes').push({
                                   label: model.get('label'),
                                   ocName: model.get('ocName')
                              });
                         }
                    }, this);
               } 

               //Also parse this collection if it isn't in collection form
               else if(!(this.model.get('enabledDocTypes') instanceof Backbone.Collection)){
                    this.model.set('enabledDocTypes', new Backbone.Collection(this.model.get('enabledDocTypes')));
               }

               if(!this.model.get('enabledFormTypes')){
                    this.model.set('enabledFormTypes', new Backbone.Collection([]));
                    _.each(defaultEnabledFormTypes, function(ocName) {
                         var model = this.objectTypes.findWhere({
                              ocName: ocName
                         });

                         if(model) {
                              this.model.get('enabledFormTypes').push({
                                   label: model.get('label'),
                                   ocName: model.get('ocName')
                              });
                         }
                    }, this);
               } else if(!(this.model.get('enabledFormTypes') instanceof Backbone.Collection)){
                    this.model.set('enabledFormTypes', new Backbone.Collection(this.model.get('enabledFormTypes')));
               }
          },
          setUpTossAcrossViews: function() {

               //Doc Types Toss Across
               this.docTypeTossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: false,
                    srcCollection: {
                         title: window.localize("modules.common.tossAcross.availableObjectTypes"),
                         filter: true,
                         labelAttr: 'label',
                         collection: this.objectTypes
                    },
                    targetCollections: [
                         {
                              title: window.localize("modules.common.tossAcross.selectedObjectTypes"),
                              labelAttr: 'label',
                              filter: true,
                              collection: this.model.get('enabledDocTypes')
                         }
                    ]
               });

               //Form Types Toss Across
               this.formTypeTossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: false,
                    srcCollection: {
                         title: window.localize("modules.common.tossAcross.availableObjectTypes"),
                         filter: true,
                         labelAttr: 'label',
                         collection: this.objectTypes
                    },
                    targetCollections: [
                         {
                              title: window.localize("modules.common.tossAcross.selectedObjectTypes"),
                              labelAttr: 'label',
                              filter: true,
                              collection: this.model.get('enabledFormTypes')
                         }
                    ]
               });
          },
          initializeSubViews: function() {
               var self = this;
               $.when(this.objectTypesConfigured).done(function() {
                    self.setView('.docTypeTossAcross', self.docTypeTossAcross).render();
                    self.setView('.formTypeTossAcross', self.formTypeTossAcross).render();
               });
          },
          afterRender: function(){
               kb.applyBindings(this.options.viewModel, this.$el[0]);
               this.initializeSubViews();
          }
     });

     return SetEffectiveDateCustomConfig;
});
