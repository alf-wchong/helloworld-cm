define([
    'app',
    'modules/common/hpiconstants',
    'modules/hpiadmin/adminUtil',
    'modules/hpiadmin/common/iosswitch',
    'modules/hpiadmin/common/admindropdown'
], function(app, HPIConstants, AdminUtil, iOSSwitch, AdminDropdown) {
	'use strict';
    var DatabaseTableViewConfig = {};

    DatabaseTableViewConfig.View = Backbone.Layout.extend({
        id: 'databaseConfigView',
        template: 'hpiadmin/actions/customconfig/databasetableview/databasetableviewconfig',
        events: {
            'change .databaseConfig-form': '_formChanged',
            'change #databaseConfig-queryUserId': 'render'
        },
        initialize: function() {
            $.when(this.getAvailablePicklists()).done(_.bind(function() {
                this.setChildViews();
                this.render();
            }, this));
        },
        getAvailablePicklists: function() {
            var getAvailablePicklistDeferred = $.Deferred();
            this.availablePicklists = [];
            $.when(app.context.configService.getPicklistServices()).done(_.bind(function() {
                _.each(app.context.currentPicklistConfig().get('picklists').models, _.bind(function(picklist){
                    this.availablePicklists.push({
                        displayValue: picklist.get('label'),
                        value: picklist.get('label')
                    });
                }, this));
                getAvailablePicklistDeferred.resolve();
            }, this));
            return getAvailablePicklistDeferred.promise();
        },
        setChildViews: function() {
            this.setIOSSwitches();

            this.columnPairsPicklistSelector = new AdminDropdown.View({
                model: this.viewModel.model(),
                configModelKey: 'columnPicklist',
                title: window.localize('customConfig.databaseTableViewConfig.columns.columnPairs.title'),
                configDescription: window.localize('customConfig.databaseTableViewConfig.columns.columnPairs.info'),
                optionObjects: this.availablePicklists
            });

            this.setViews({
                "#databaseConfig-columnSelect": this.columnPairsPicklistSelector
            });
        },
        setIOSSwitches: function() {
            this.sortableColumnsIOSSwitch = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: 'areColumnsSortable',
                switchTitle: window.localize('customConfig.databaseTableViewConfig.columns.sortable.title'),
                configDescription:  window.localize('customConfig.databaseTableViewConfig.columns.sortable.info'),
            });

            this.queryUserIdIOSSwitch = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: 'queryOnUserId',
                switchTitle: window.localize('customConfig.databaseTableViewConfig.query.userId.title'),
                configDescription:  window.localize('customConfig.databaseTableViewConfig.query.userId.info'),
            });

            this.setViews({
                '#databaseConfig-sortableColumns': this.sortableColumnsIOSSwitch,
                '#databaseConfig-queryUserId': this.queryUserIdIOSSwitch,
            });
        },
        serialize: function() {
            return {
                showQueryUserIdConfigs: this.viewModel.model().get('queryOnUserId'),
                userIdQueryParam: this.viewModel.model().get('userIdQueryParam')
            };
        },
        _formChanged: function (event) {
            var value =  $(event.target).val();
            var modelKey = event.target.attributes.for.value; // returns the form's for attribute
            this.viewModel.model().set(modelKey, value);
            this.render();
        }
    });

    return DatabaseTableViewConfig;
});