define([
  // Application.
  "app",
  "modules/common/hpiconstants",
  "modules/hpiadmin/actionconfig/actions/managerelations/managerelationscustomconfig"
],

// Map dependencies from above array.
function(app, HPIConstants, ManageRelationsCustomConfig) {
     "use strict";

     var ManageAdHocDocumentCustomConfig = {};

     var baseDefaults = new Backbone.Model({
          relationNames: [],

          //Confirm that this object type is ok
          searchObjectType: HPIConstants.ObjectTypes.AttachedDocument,
          searchResultAttrs: [{
               value: 'title'
          }, {
               value: 'creationDate'
          }, {
               value: 'creator'
          }]
     });

     var repositoryDefaults = new Backbone.Model({
          repoNames: [{
               displayValue: '',
               value: ''
          }, {
               displayValue: 'Alfresco',
               value: 'alf'
          }, {
               displayValue: 'Documentum',
               value: 'dctm'
          }, {
               displayValue: 'HBase',
               value: 'hbase'
          }],
          alf: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw:supportingDocument']
          }),
          dctm: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw_rel_supporting_document']
          }),
          hbase: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw_rel_supporting_document']
          })
     });

     ManageAdHocDocumentCustomConfig.View = ManageRelationsCustomConfig.View.extend({
          initialize: function() {
               //Override the defaults object and set enabled subviews
               this.options.baseDefaults = baseDefaults;
               this.options.repositoryDefaults = repositoryDefaults;
               this.options.allowMultipleRelations = false;
               this.options.showSearchLimit = false;
               this.options.showSearchSubview = false;

               //Call super method
               ManageRelationsCustomConfig.View.prototype.initialize.call(this);
          }
     });

     return ManageAdHocDocumentCustomConfig;
});
