define([
    "app",
    "modules/hpiadmin/common/iosswitch",
    "modules/common/hpiconstants",
], function(app, iOSSwitch, HPIConstants) {
    "use strict";

    var DownloadDocumentCustomConfigView = {};

    // acting as a ViewModel for an individual pattern of an objectType
    DownloadDocumentCustomConfigView.TypePatternViewModel = function(options) {
        var self = this;

        // typePattern server data that needs to be updated when a type pattern's pattern changes
        self.typePatternServerData = options.typePatternServerData;

        // the value of the objectType
        self.objectType = options.objectType;
        
        // the display label of the objectType on the admin screen
        self.typeLabel = ko.observable();
        if(options.typeLabel) {
            self.typeLabel(options.typeLabel);    
        } else { // if the label isn't passed in (when we get the data from the server), fetch the type label
            app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
                self.typeLabel(typeLabel);
            });
        }

        // the different attributes the obejctType has  that can be used to populate the objectType's pattern
        self.attrs = ko.observableArray([]);

        // this fetches all the available attributes for a user to use in the pattern for a type
        app.context.configService.getAdminOTC(function(objectTypeConfig) {
            var config = objectTypeConfig.get("configs").findWhere({ ocName : self.objectType });
            config.get("attrs").each(function(attr) {
                self.attrs.push({
                    "label": attr.get("label"),
                    "value": attr.get("ocName")
                });
            }); 
        });

        // the currently selected attribute of the objectType
        self.selectedAttr = ko.observable("");
        // the pattern that is displayed on the admin screen with placeholders to the user
        self.computedPattern = ko.observable("");
        if(options.pattern) { // the pattern will be set if we get data back from the server
            self.computedPattern(options.pattern);
        }

        // this adds the selected attribute to the type's current pattern string
        // this is triggered when the user clicks the "Add to Pattern" button in the admin
        self.addComputedAttrToPattern = function() {
            if(self.selectedAttr() !== "") { // if there's actually an attribute selected to add
                if(self.computedPattern() !== "") { // append the selected attr to the existing pattern
                    var newPattern = self.computedPattern() + "$" + self.selectedAttr() + "$";
                    self.computedPattern(newPattern);
                } else { // the pattern is empty so set it with the selected attr
                    self.computedPattern("$" + self.selectedAttr() + "$");
                }
            }
        };

        // every time the observable's value changes, update that type pattern's pattern in the server data map
        self.computedPattern.subscribe(function (newValue) {
            self.typePatternServerData[self.objectType] = newValue;
        });
    };

    DownloadDocumentCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/downloaddocumentconfig",
        initialize: function () {
            var self = this;
            var viewModel = self.options.viewModel;

            // M I M E   T Y P E S //
            var MimeType = function(label, type) {
                return {
                    label: label,
                    type: type
                };
            };
            //list of rendition types
            viewModel.mimeTypeList = ko.observableArray([
                new MimeType("Native", "*"),
                new MimeType("PDF", "application/pdf")
            ]);

            viewModel.selectedRenditions = ko.observable([]);

            //seed rendition type to be Native
            viewModel.model().set("selectedRenditions", [viewModel.mimeTypeList()[0]]);

            viewModel.selectedRenditions.subscribe(function (newValues) {
                viewModel.model().set("selectedRenditions", newValues);
            });

            // this is the array of types that the user has configured for the current trac that
            // is sent / received by the server
            self.typePatternServerData = viewModel.model().get("typePatterns") || {};
            // this is an array for displaying the currently configured types to the user on the admin screen
            viewModel.typePatternViewModels = ko.observableArray([]);

            // used to display list of document types that user can configure based on current trac
            viewModel.availableDocumentTypesInConfig = ko.observableArray([]);

            //is the note directly related to the folder or document?
            viewModel.enableDocumentNoteRelation = kb.observable(viewModel.model(), "enableDocumentNoteRelation");

            // fetch a list of available types the user can choose to configure for this trac
            app.context.configService.getAdminOTC(function(config) {
                config.get("configs").each(function(typeConfig) {
                    if (typeConfig.get("isContainer") === "false") { // can't download a container
                        viewModel.availableDocumentTypesInConfig.push({
                            "label": typeConfig.get("label"),
                            "value": typeConfig.get("ocName")
                        });
                    }
                });
            });

            // if the user already has types configured
            if(viewModel.model().get("typePatterns")) {
                // grab the already configured types
                var oldTypePatterns = viewModel.model().get("typePatterns");
                // we are copying over the currently configured types so we can build up the inidividual view models for each one
                // this is essentially what knockback collection observable does, but it doesn't really work well in this situation
                _.each(oldTypePatterns, function(pattern, objectType) {
                    if(objectType !== "_id") { // an extra key with "_id" is sent in the obejct to the server, skip this
                        var newTypePattern = new DownloadDocumentCustomConfigView.TypePatternViewModel({ objectType: objectType, pattern: pattern, typePatternServerData: self.typePatternServerData, trac: self.options.trac });
                    
                        viewModel.typePatternViewModels.push(newTypePattern);    
                    }
                });
            } else { // we need to set the empty object on the model
                viewModel.model().set("typePatterns", self.typePatternServerData);    
            }            

            // this is the currently selected type that the user wants to configure
            viewModel.selectedType = ko.observable();
            viewModel.selectedType.subscribe(function(newSelectedType) {
                // this will be undefined when you reject a value from the availableDocumentTypesInConfig below, which causes
                // this subscription to fire again since it changes to the optionsCaption value
                if(newSelectedType) {
                    var objectType = newSelectedType.value;

                    var typePattern = new DownloadDocumentCustomConfigView.TypePatternViewModel({ typeLabel: newSelectedType.label, objectType: objectType, typePatternServerData: self.typePatternServerData, trac: self.options.trac });

                    // enter an entry into the map of type patterns that gets sent back to the server
                    // with an initially empty pattern string
                    self.typePatternServerData[objectType] = "";
                    // add an entry to the observable array that holds our type patterns
                    viewModel.typePatternViewModels.push(typePattern);

                    // remove the doc type from the list of available doc types to configure
                    viewModel.availableDocumentTypesInConfig(_.reject(viewModel.availableDocumentTypesInConfig(), function(availableDocType) {
                        return availableDocType.value === newSelectedType.value;
                    }));    
                }
            });

            viewModel.removeTypePattern = function(typePattern) {
                // remove the entry from the data that gets sent back to the server
                delete self.typePatternServerData[typePattern.objectType];
                // remove the entry from the observable array
                viewModel.typePatternViewModels.remove(typePattern);

                // add the type being removed back into the list of available types to configure
                viewModel.availableDocumentTypesInConfig.push({
                    // typeLabel is an observable, objectType is not
                    "label": typePattern.typeLabel(),
                    "value": typePattern.objectType
                });
            };
            
            //whether or not to create a Folder Note after document upload
            if(!viewModel.folderNotes){
                viewModel.folderNotes = false;
            }
            viewModel.folderNotes = kb.observable(viewModel.model(), "folderNotes");
            
            if(viewModel.folderNotes() === "false" ) {
                viewModel.folderNoteType(false);
            }

            // selected folder note type from the admin
            viewModel.folderNoteObjectType = kb.observable(viewModel.model(),"folderNoteObjectType");
            if (!viewModel.folderNoteObjectType()){
                viewModel.folderNoteObjectType("HPI Note");
            }
            // note type to apply to all folder notes
            viewModel.folderNoteType = kb.observable(viewModel.model(),"folderNoteType");
            if (!viewModel.folderNoteType()) {
                viewModel.folderNoteType("Folder Note");
            }
            //selected folder note relationship from admin
           viewModel.folderNoteRelationship = kb.observable(viewModel.model(),"folderNoteRelationship");

        },
        afterRender: function () {
            ko.applyBindings(this.options.viewModel, this.$el[0]);

            this.directDownloadConfigView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "directDownloadSwitch",
                switchTitle: window.localize("generic.action.customConfig.directDownload"),
                configDescription: window.localize("generic.action.customConfig.directDownloadInfo")
            });

            this.setViews({
                "#directDownloadSwitch": this.directDownloadConfigView
            }).renderViews();
        }
    });

    return DownloadDocumentCustomConfigView;
});