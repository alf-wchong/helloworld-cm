define([
    "app",
    "modules/common/tossacross",
    "modules/hpiadmin/common/iosswitch"
    
], function(app, TossAcross, iOSSwitch) {
	"use strict";
    var CompleteTaskConfig = {};

	CompleteTaskConfig.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/completetaskconfig",
		events:{
			'change .ctc-documentTypeInputGroup': 'documentTypeSelected',
			'change .ctc-documentAttributeTypeInputGroup': 'documentAttributeSelected',
			'change .ctc-attr-value-input-listener': 'saveCriteriaFilterForm',
			'change .ctc-adHocFormDropDown-listener': 'saveCriteriaFilterForm',
			'change #ctc-bypassWorkflowConfig': 'afterRender',
			'change #ctc-integrateFolderNotes': 'afterRender',
			'change .ctc-folderNoteObjectTypeInput': "setFolderNoteObjectTypeSelected",
			'change .ctc-folderNoteTypeInput': "setFolderNoteTypeSelected",
			'change .ctc-folderNoteRelationshipInput': 'setFolderNoteRelationshipSelected',
			'change .ctc-attrToShow': 'setAttrToShowSelected',
			'click .ctc-removeCriteriaButton': 'removeCriteriaFilterForm',
			'click .ctc-addCriteria': 'populateCriteriaFilterForm'
		},
		initialize: function () {
            this.viewModel = this.options.viewModel;
            this.model = this.viewModel.model();

            this.viewModel.availableDocumentTypesInConfig = new Backbone.Collection();
            this.viewModel.availableDocumentAttributes = new Backbone.Collection();

            this.deferredArray = [];
			this.getAdminTypeDeferred = $.Deferred();
			this.otcDeferred = $.Deferred();
			this.getAdHocFormsDeferred = $.Deferred();
			this.deferredArray.push(this.otcDeferred);
			this.deferredArray.push(this.getAdminTypeDeferred);
			this.deferredArray.push(this.getAdHocFormsDeferred);
            
            // Helper function to consolidate all the ios switch creation in one place
            this.createIOSSwitches();

            // Populate the selected document types attributes into the available name attributes collection
			app.context.configService.getAdminOTC(_.bind(this.buildUpAttributesFromAdminOTC, this));

			// Grab all the available ad hoc forms here then resolve its deferred
			this.getAvailableAdHocForms();

			// Simple helper function to set the attribute to show from the config model if it exists on its div
        	this.getAttrToShowSelected();
        },
        createIOSSwitches: function(){
            this.bypassWorkflowConfig = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "bypassWorkflowConfig",
                switchTitle: window.localize("customConfig.completeTaskConfig.bypassWorkflowConfigSwitchTitle"),
                configDescription: window.localize("customConfig.completeTaskConfig.bypassWorkflowConfigSwitchDescription"),
            });

            this.auditEvent = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "auditEvent",
                switchTitle: window.localize("customConfig.completeTaskConfig.auditCompleteTask"),
                configDescription: window.localize("generic.action.customConfig.auditGlyphiconTitle")
            });

            this.integrateFolderNotes = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "integrateFolderNotes",
                switchTitle: window.localize("generic.action.customConfig.integrateWithDocumentNotes"),
                configDescription: window.localize("generic.action.customConfig.shouldDocumentNoteBeCreated")
            });

            this.folderNoteRequired = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "folderNoteRequired",
                switchTitle: window.localize("generic.action.customConfig.isDocumentNoteRequired")
            });

            // set byPass switch view
            this.setViews({
                "#ctc-bypassWorkflowConfig": this.bypassWorkflowConfig,
                "#ctc-auditEvent": this.auditEvent,
                "#ctc-integrateFolderNotes": this.integrateFolderNotes,
                "#ctc-folderNoteRequired": this.folderNoteRequired
            });
        },
        buildUpAttributesFromAdminOTC: function(config){
			var self = this;
			config.get("configs").each(function (typeConfig) {
                if (typeConfig.get("isContainer") === "false") {
                    self.viewModel.availableDocumentTypesInConfig.push({
                        "label": typeConfig.get("label"),
                        "value": typeConfig.get("ocName")
					});
                }
			});

			// If failed to get configs just display empty dropdown, however this should never happen
			if (this.viewModel.availableDocumentTypesInConfig.models.length > 0){
				this.selectedDocumentType = this.viewModel.availableDocumentTypesInConfig.models[0].attributes.value;
				if (this.model.get("selectedDocumentType")){
					this.selectedDocumentType = this.model.get("selectedDocumentType");
				}

				app.context.configService.getAdminTypeConfig(this.selectedDocumentType, _.bind(this.populateAvailableDocumentAttributes, this));
			}

			this.otcDeferred.resolve();
		},
		setFolderNoteObjectTypeSelected: function(){
			this.model.set("folderNoteObjectType", this.$('.ctc-folderNoteObjectTypeInput').val());
		},
		getFolderNoteObjectTypeSelected: function(){
			this.$('.ctc-folderNoteObjectTypeInput').val(this.model.get("folderNoteObjectType"));
		},
		setFolderNoteTypeSelected: function(){
			this.model.set("folderNoteType", this.$('.ctc-folderNoteTypeInput').val());
		},
		getFolderNoteTypeSelected: function(){
			this.$('.ctc-folderNoteTypeInput').val(this.model.get("folderNoteType"));
		},
		setFolderNoteRelationshipSelected: function(){
			this.model.set("folderNoteRelationship", this.$('.ctc-folderNoteRelationshipInput').val());
		},
		getFolderNoteRelationshipSelected: function(){
			this.$('.ctc-folderNoteRelationshipInput').val(this.model.get("folderNoteRelationship"));
		},
		setAttrToShowSelected: function(){
			this.model.set("attrToShow", this.$('.ctc-attrToShow').val());
		},
		getAttrToShowSelected: function(){
			this.$('.ctc-attrToShow').val(this.model.get("attrToShow"));
		},
        documentTypeSelected: function(e){
        	var self = this;
			this.selectedDocumentType = this.$(e.target).val();
			this.viewModel.availableDocumentAttributes.reset();
			this.selectedDocumentAttribute = "";
			this.model.set("selectedDocumentAttribute", "");
			this.model.set("completeTaskConfigMap", {});

			_.each(this.viewModel.availableDocumentTypesInConfig.models, function(attr) {
				if (self.selectedDocumentType === attr.attributes.label){
					self.selectedDocumentType = attr.attributes.value;
				}
			});
			
			this.model.set("selectedDocumentType", this.selectedDocumentType);
			app.context.configService.getAdminTypeConfig(this.selectedDocumentType, _.bind(this.populateAvailableDocumentAttributes, this));

		},
		documentAttributeSelected: function(e){
			var self = this;
			this.selectedDocumentAttribute = this.$(e.target).val();
			_.each(this.viewModel.availableDocumentAttributes.models, function(attr) {
				if (self.selectedDocumentAttribute === attr.attributes.attrName){
					self.selectedDocumentAttribute = attr.attributes.attrValue;
				}
			});

			this.model.set("selectedDocumentAttribute", this.selectedDocumentAttribute);
			this.model.set("completeTaskConfigMap", {});
			this.render();

		},
		populateAvailableDocumentAttributes: function(typeConfig){
			if (typeConfig){
				_.each(typeConfig.get("attrs").models, function(attr) {
					this.viewModel.availableDocumentAttributes.push({
						'attrName': attr.get("label"),
						'attrValue': attr.get("ocName")
					});
				}, this);

			}else{
				this.viewModel.availableDocumentAttributes.reset();
				this.selectedDocumentAttribute = "";
				this.model.set("selectedDocumentAttribute", "");
				
			}
			this.getAdminTypeDeferred.resolve();
			this.render();
		},
		renderDocumentType: function(){
			var self = this;
			var docTypeGroup = this.$('.ctc-documentTypeInputGroup');
			docTypeGroup.empty();
			_.each(this.viewModel.availableDocumentTypesInConfig.models, function(attr) {
				if (self.model.get("selectedDocumentType") === attr.attributes.value){
					docTypeGroup.append($("<option selected>" + attr.attributes.label + "</option>"));
				}else{
					docTypeGroup.append($("<option>" + attr.attributes.label + "</option>"));
				}
			});
			
		},
        renderDocumentAttributeType: function(){
			var self = this;
			var docTypeGroup = this.$('.ctc-documentAttributeTypeInputGroup');
			docTypeGroup.empty();
			_.each(this.viewModel.availableDocumentAttributes.models, function(attr) {
				if (self.model.get("selectedDocumentAttribute") === attr.attributes.attrValue){
					docTypeGroup.append($("<option selected>" + attr.attributes.attrName + "</option>"));
				}else{
					docTypeGroup.append($("<option>" + attr.attributes.attrName + "</option>"));
				}
			});
			
		},
		saveCriteriaFilterForm: function(e){

			var criteriaPos = e.currentTarget.id.split("-")[1];

			// grab & save filter property name
			var attrValueCriteria = $("." + "ctc-attr-value-" + criteriaPos).val();
			
			// grab & save picklist selected property
			var adHocForm = $("." + "ctc-adHocFormDropDown-" + criteriaPos).val();

			var criteriaMap = {
				"criteriaSectionId": e.currentTarget.id,
				"adHocFormValue": adHocForm,
				"attributeValueCriteria": attrValueCriteria
			};

			if (_.isEmpty(this.model.get("completeTaskConfigMap"))){
				var completeTaskConfigMap = {
					"objectType": this.selectedDocumentType,
					"attrSelected": this.selectedDocumentAttribute,
					"criteria": [criteriaMap]
				};
				this.model.set("completeTaskConfigMap", completeTaskConfigMap);

			}else{
				var existingCriteriaFilters = this.model.get("completeTaskConfigMap");
				if (_.contains(_.pluck(existingCriteriaFilters.criteria, "criteriaSectionId"), criteriaMap.criteriaSectionId)){
					var updatedCriteriaList = [];
					_.each(existingCriteriaFilters.criteria, function(element){
						if (element.criteriaSectionId !== criteriaMap.criteriaSectionId){
							updatedCriteriaList.push(element);
						}else{
							updatedCriteriaList.push(criteriaMap);
						}
					});
					existingCriteriaFilters.criteria = updatedCriteriaList;
					this.model.set("completeTaskConfigMap", existingCriteriaFilters);
				}else{
					existingCriteriaFilters.criteria.push(criteriaMap);
					this.model.set("completeTaskConfigMap", existingCriteriaFilters);
					
				}
			}

		},
		removeCriteriaFilterForm: function(e){
			$("." + e.currentTarget.id).remove();
			var updatedCriteriaList = [];
			var updatedCompleteTaskConfigMap = this.model.get("completeTaskConfigMap");
			_.each(updatedCompleteTaskConfigMap.criteria, function(model){
				if (model.criteriaSectionId !== e.currentTarget.id){
					updatedCriteriaList.push(model);
				}
			});
			updatedCompleteTaskConfigMap.criteria = updatedCriteriaList;
			this.model.set("completeTaskConfigMap", updatedCompleteTaskConfigMap);
		},
		loadSavedCriteriaFilterForms: function(){
			if (this.model.get("completeTaskConfigMap")){
				_.each(this.model.get("completeTaskConfigMap").criteria, function(model){
					this.populateCriteriaFilterForm(model.criteriaSectionId, model.attributeValueCriteria, model.adHocFormValue, true);
				}, this);
			}
		},
		populateCriteriaFilterForm: function(innerCriteriaSectionId, attributeValueCriteria, adHocFormSelectedValue, onLoad){

			var criteriaFilterSectionDiv = $(".ctc-criteriaFilterSection")[0];

			var innerCriteriaFilterSectionDiv = document.createElement("div");
			var criteriaPos = 0;
			var newCriteriaAdded = false;

			if (innerCriteriaSectionId && onLoad){
				innerCriteriaFilterSectionDiv.className = innerCriteriaSectionId;
				criteriaPos = innerCriteriaSectionId.split("-")[1];
			}else{
				criteriaPos = $(".ctc-criteriaFilterSection")[0].children.length + 1;
				innerCriteriaFilterSectionDiv.className = "criteriaSection-" + criteriaPos;
                newCriteriaAdded = true;
			}

			// Check to see if div already exists with the classname, if so we don't want to duplicate it
			if ($("." + innerCriteriaFilterSectionDiv.className).length == 0){
				// add filter property name div
				var filterPropDiv = this.createCriteriaFilterFormSection("input", window.localize("customConfig.completeTaskConfig.attributeCriteriaValue"), "complete-task-config-margin-top-25", criteriaPos, attributeValueCriteria);
				innerCriteriaFilterSectionDiv.appendChild(filterPropDiv);
				
				// add picklist property div
				var picklistDiv = this.createCriteriaFilterFormSection("select", window.localize("customConfig.completeTaskConfig.addHocForm"), "complete-task-config-margin-top-5", criteriaPos, adHocFormSelectedValue);
				innerCriteriaFilterSectionDiv.appendChild(picklistDiv);

				var buttonOuterDiv = this.createCriteriaFilterFormSectionButtons(criteriaPos);
				innerCriteriaFilterSectionDiv.appendChild(buttonOuterDiv);

				criteriaFilterSectionDiv.appendChild(innerCriteriaFilterSectionDiv);

				if (newCriteriaAdded){
					this.renderCriteriaAdHocDropdown();
				}
			}
			
		},
		createCriteriaFilterFormSectionButtons: function(criteriaPos){
			var buttonOuterDiv = document.createElement("div");
			buttonOuterDiv.className = "col-md-12";

			// add remove button
			var removeButtonElement = document.createElement("a");
			removeButtonElement.className = "ctc-removeCriteriaButton complete-task-config-margin-top-10 complete-task-config-margin-left-10 btn btn-danger";
			removeButtonElement.id = "criteriaSection-" + criteriaPos;
			removeButtonElement.innerHTML = window.localize("customConfig.completeTaskConfig.removeCriteria");

			var removeButtonSpan = document.createElement("span");
			removeButtonSpan.className = "glyphicon glyphicon-minus-sign white";

			removeButtonElement.appendChild(removeButtonSpan);
			buttonOuterDiv.appendChild(removeButtonElement);

			return buttonOuterDiv;

		},
		createCriteriaFilterFormSection: function(valueElementType, label, customCssClass, criteriaPos, value){
			var propOuterDiv = document.createElement('div');
			propOuterDiv.className = customCssClass + " col-md-12";

			var propNameDiv = document.createElement("div");
			propNameDiv.className = "col-md-4";

			var propLabelElement = document.createElement("label");
			propLabelElement.innerHTML = label + ': ';

			var propValueElementDiv = document.createElement("div");
			propValueElementDiv.className = "col-md-8";

			var propElement;
			if (valueElementType === "input"){
				propElement = document.createElement('input');
				propElement.className = "ctc-attr-value-input-listener " + "ctc-attr-value-" + criteriaPos + " form-control";
				propElement.id = "criteriaSection-" + criteriaPos;
				propElement.type = "text";

			}else if (valueElementType === "select"){
				propElement = document.createElement("select");
				propElement.className = "ctc-adHocFormDropDown-listener " + "ctc-adHocFormDropDown-" + criteriaPos + " form-control";
				propElement.id = "criteriaSection-" + criteriaPos;
				
			}

			if (propElement && value){
				propElement.value = value;
			}
			
			propNameDiv.appendChild(propLabelElement);
			propValueElementDiv.appendChild(propElement);

			propOuterDiv.appendChild(propNameDiv);
			propOuterDiv.appendChild(propValueElementDiv);

			return propOuterDiv;
		},
		getAvailableAdHocForms: function(){
			var self = this;
			//start with a blank element
   			this.availableAdHocForms = [""];
			app.context.configService.getAdHocFormConfigNames(function (formConfigNames) {
                self.availableAdHocForms = formConfigNames.length !== 0 ? formConfigNames : undefined;
                self.getAdHocFormsDeferred.resolve();
            });
 			
		},
		renderCriteriaAdHocDropdown: function(){
			var self = this;
			var queryUrlElements = this.$('.ctc-adHocFormDropDown-listener');
			var pos = 0;
			_.each(queryUrlElements, function(element){
				// check if value already exists in this map b/c we don't want to empty or do this again
				if (self.model.get("completeTaskConfigMap") && self.model.get("completeTaskConfigMap").criteria 
					&& self.model.get("completeTaskConfigMap").criteria[pos] && self.model.get("completeTaskConfigMap").criteria[pos].adHocFormValue){
					_.each(self.availableAdHocForms, function(attr) {
						if (attr && self.model.get("completeTaskConfigMap").criteria[pos].adHocFormValue === attr){
							$(element).append($("<option selected>" + attr + "</option>"));
						}else{
							$(element).append($("<option>" + attr + "</option>"));
						}
					});
				}else{
					$(element).empty();

					_.each(self.availableAdHocForms, function(attr) {
						if (attr){
							$(element).append($("<option>" + attr + "</option>"));
						}
					});
				}
				pos += 1;
			});
			
		},
        afterRender: function () {
        	if (this.model.attributes.bypassWorkflowConfig){
        		this.$('.ctc-byPassWorkflowConfigContainer').show();
        		var self = this;
				$.when.apply($, this.deferredArray).then(function(){
					self.renderDocumentType();
					self.renderDocumentAttributeType();
					self.loadSavedCriteriaFilterForms();
					self.renderCriteriaAdHocDropdown();
				});

        	}else{
        		this.$('.ctc-byPassWorkflowConfigContainer').hide();
        		this.viewModel.availableDocumentAttributes.reset();
				this.selectedDocumentAttribute = "";
				this.selectedDocumentType = "";
				this.model.set("selectedDocumentAttribute", "");
				this.model.set("completeTaskConfigMap", {});
				this.model.set("selectedDocumentType", "");
        	}

        	if (this.model.attributes.integrateFolderNotes){
        		this.$('.ctc-integrateFolderNotes').show();

        		// Set the default values for note object type and note type
				this.model.set("folderNoteObjectType", "HPI Note");
				this.model.set("folderNoteType", "Workflow Note");
			
	            this.getFolderNoteObjectTypeSelected();
	        	this.getFolderNoteTypeSelected();
	        	this.getFolderNoteRelationshipSelected();

        	}else{
        		this.$('.ctc-integrateFolderNotes').hide();
        		this.model.set("folderNoteObjectType", "");
				this.model.set("folderNoteType", "");
				this.model.set("folderNoteRelationship", "");
        	}
        }
	});

	return CompleteTaskConfig;
});