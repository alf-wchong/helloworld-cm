define([
  // Application.
  "app",
  "modules/hpiadmin/adminUtil",
  "modules/common/tossacross",
  'modules/hpiadmin/common/admindropdown'
],

// Map dependencies from above array.
function(app, AdminUtil, TossAcross, AdminDropdown) {
     "use strict";

     var ManageRelationsCustomConfig = {};

     var baseDefaults = new Backbone.Model({
          relationNames: [],
          searchObjectType: 'Document',
          searchAttribute: 'objectName',
          searchCriteria: [],
          searchResultLimit: 25,
          searchResultAttrs: [{
               value: 'objectName'
          }, {
               value: 'creator'
          }],
          searchResultConditions: []
     });

     var repositoryDefaults = new Backbone.Model({
          repoNames: [{
               displayValue: '',
               value: ''
          }, {
               displayValue: 'Alfresco',
               value: 'alf'
          }, {
               displayValue: 'Documentum',
               value: 'dctm'
          }, {
               displayValue: 'HBase',
               value: 'hbase'
          }],
          alf: _.extend({}, baseDefaults.attributes),
          dctm: _.extend({}, baseDefaults.attributes),
          hbase: _.extend({}, baseDefaults.attributes)
     });

     ManageRelationsCustomConfig.View = Backbone.Layout.extend({
          template: "hpiadmin/actions/customconfig/managerelations/managerelationsconfig",
          events: {
               "click .admin_ui_subsectionToggle": "toggleSubsection"
          },
          toggleSubsection: function(e) {
               AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
          },
          initialize: function(){
               this.viewModel = this.options.viewModel;
               this.model = this.viewModel.model();
               this.eventBus = this.options.eventBus = _.extend({}, Backbone.Events);

               //Set the defaults object and enabled subviews
               if(!_.has(this.options, 'baseDefaults')) {
                    this.options.baseDefaults = baseDefaults;
               }
               this.baseDefaults = this.options.baseDefaults;

               if(!_.has(this.options, 'repositoryDefaults')) {
                    this.options.repositoryDefaults = repositoryDefaults;
               }

               if(!_.has(this.options, 'showSearchSubview')) {
                    this.options.showSearchSubview = true;
               }

               this.repositoryDefaults = this.options.repositoryDefaults;          

               //Set default model values here, and also make sure that collections are parsed
               if(!this.model.get('searchObjectType')) {
                    this.model.set('searchObjectType', this.baseDefaults.get('searchObjectType'));
               }
               this.viewModel.searchCriteriaAttributes = ko.observableArray([]);

               this.startListening();
               this.configureObjectTypes();
               this.createSubViews();
          },
          startListening: function() {
               this.listenTo(this.model, 'change:searchObjectType', this.configureObjectTypes);
               this.listenTo(this.eventBus, 'configureDefaultsRequested', this.setDefaults);
          },
          setDefaults: function(repoToSet) {
               var self = this;

               this.stopListening();

               if(repoToSet) {
                    this.model.set('relationNames', this.repositoryDefaults.get(repoToSet).relationNames);
                    this.model.set('searchObjectType', this.repositoryDefaults.get(repoToSet).searchObjectType);
                    this.model.set('searchAttribute', this.repositoryDefaults.get(repoToSet).searchAttribute);
                    this.model.set('searchResultLimit', this.repositoryDefaults.get(repoToSet).searchResultLimit);
                    this.model.set('searchResultConditions', new Backbone.Collection(this.repositoryDefaults.get(repoToSet).searchResultConditions));
                    this.configureObjectTypes();

                    $.when(this.objectTypesConfigured).done(function() {
                         var defaultSearchCriteria = [];
                         _.each(self.repositoryDefaults.get(repoToSet).searchCriteria, function(entry) {
                              if(_.findWhere(self.options.typeAttrs, {value: entry.attrName})) {
                                   defaultSearchCriteria.push({
                                        attrName: entry.attrName,
                                        attrValue: entry.attrValue
                                   });
                              }
                         });
                         self.model.set('searchCriteria', defaultSearchCriteria);

                         var defaultSearchResultAttrs = [];
                         _.each(self.repositoryDefaults.get(repoToSet).searchResultAttrs, function(entry) {
                              if(_.findWhere(self.options.typeAttrs, {value: entry.value})) {
                                   defaultSearchResultAttrs.push({
                                        value: entry.value
                                   });
                              }
                         });
                         self.model.set('searchResultAttrs', new Backbone.Collection(defaultSearchResultAttrs));

                         self.createSubViews();
                         self.initializeSubViews();
                    });
               }

               this.startListening();
          },
          configureObjectTypes: function() {
               var self = this;
               this.objectTypesConfigured = $.Deferred();
               app.context.configService.getAdminOTC(function (config){

                    //Populate OT dropdown
                    self.options.objectTypes = config.get('configs').map(function(model) {
                         return {
                             displayValue: model.get('label'),
                             value: model.get('ocName') 
                         };
                    });
                    app.context.util.prependEmptyEntryToArray(self.options.objectTypes);

                    //For selected OT, populate attribute dropdown
                    var selectedObjectTypeConfig = config.get('configs').findWhere({
                         ocName: self.model.get('searchObjectType')
                    });

                    self.viewModel.searchCriteriaAttributes.removeAll();
                    self.options.typeAttrs = [];

                    //Only parse attributes and alert subviews when the new object type has configs (only scenario where this isn't the case is when the default object type isn't present)
                    if(selectedObjectTypeConfig !== undefined) {

                         selectedObjectTypeConfig.get('attrs').each(function(model) {
                              self.viewModel.searchCriteriaAttributes.push({
                                   displayValue: model.get('label'),
                                   value: model.get('ocName')
                              });
                         });

                         self.options.typeAttrs = _.clone(self.viewModel.searchCriteriaAttributes());
                         self.eventBus.trigger('objectTypeUpdated', self.model.get('searchObjectType'), self.viewModel.searchCriteriaAttributes());
                    }
                    app.context.util.prependEmptyEntryToArray(self.viewModel.searchCriteriaAttributes());

                    self.objectTypesConfigured.resolve();
               });
          },
          createSubViews: function() {
               var self = this;
               $.when(this.objectTypesConfigured).done(function() {
                    self.commonView = new ManageRelationsCustomConfig.CommonSubView(self.options);
                    self.searchResultView = new ManageRelationsCustomConfig.SearchResultsSubView(self.options);

                    if(self.options.showSearchSubview) {
                         self.searchView = new ManageRelationsCustomConfig.SearchSubView(self.options);
                    }
               });
          },
          initializeSubViews: function() {
               var self = this;
               $.when(this.objectTypesConfigured).done(function() {
                    //Set up ManageRelations view
                    self.setView('.commonConfigSection', self.commonView).render();

                    //Set up search result view
                    self.setView('.searchResultConfigSection', self.searchResultView).render();

                    //Set up search view
                    if(self.options.showSearchSubview) {
                         self.setView('.searchConfigSection', self.searchView).render();
                    }
               });

          },
          serialize: function() {
               return {
                    showSearchSubview: this.options.showSearchSubview
               };
          },
          afterRender: function(){
               this.initializeSubViews();
               kb.applyBindings(this.options.viewModel, this.$el[0]);
          }
     });

     ManageRelationsCustomConfig.CommonSubView = Backbone.Layout.extend({
          template: "hpiadmin/actions/customconfig/managerelations/managerelationscommonconfig",
          initialize: function(){
               this.viewModel = this.options.viewModel;
               this.model = this.viewModel.model();
               this.eventBus = this.options.eventBus;
               this.setDefaultsModel = new Backbone.Model();
               this.viewModel.setDefaults = _.bind(this.defaultsRequestedHandler, this);

               this.createSubViews();
          },
          defaultsRequestedHandler: function() {
               this.eventBus.trigger('configureDefaultsRequested', this.setDefaultsModel.get('repositoryName'));
          },
          createSubViews: function() {
               this.relationView = new ManageRelationsCustomConfig.RelationView(this.options);
               this.defaultsDropdown = new AdminDropdown.View({
                    model: this.setDefaultsModel,
                    configModelKey: 'repositoryName',
                    title: window.localize('customConfig.manageWorkflowDocuments.defaultRepoTitle'),
                    configDescription: window.localize('customConfig.manageWorkflowDocuments.defaultRepoDesc'),
                    optionObjects: this.options.repositoryDefaults.get('repoNames'),
                    titleIsHeaderTag: true
               });
          },
          initializeSubViews: function() {
               this.setView('.relationView', this.relationView).render();
               this.setView('.defaultsDropdown', this.defaultsDropdown).render();
          },
          afterRender: function(){
               this.initializeSubViews();
               kb.applyBindings(this.options.viewModel, this.$el[0]);
          }
     });

     //Admin Config View
     ManageRelationsCustomConfig.RelationView = Backbone.Layout.extend({
          template: "hpiadmin/actions/customconfig/managerelations/managerelationsrelationconfig",
          events:{
               "change .twoWayRelation": "selectedRelationType"
          },
          initialize: function(){
               var viewModel = this.options.viewModel;
               viewModel.relationNames = ko.observableArray(viewModel.model().get("relationNames") || []);
               viewModel.twoWayRelation = ko.observableArray();
               viewModel.currentRelationName = ko.observable();

               if(!_.has(this.options, 'allowMultipleRelations')) {
                    this.options.allowMultipleRelations = true;
               }

               if(this.options.allowMultipleRelations) {
                    viewModel.addRelation = function(){
                         viewModel.relationNames.push(viewModel.currentRelationName());
                         viewModel.currentRelationName("");
                         viewModel.model().set("relationNames", viewModel.relationNames());
                    };

                    viewModel.removeRelation = function(){
                         viewModel.relationNames.remove(this.toString());
                         viewModel.model().set("relationNames", viewModel.relationNames());
                    };
               }

               else {
                    if(viewModel.relationNames().length === 1) {
                         viewModel.currentRelationName(viewModel.relationNames()[0]);
                    }
                    viewModel.currentRelationName.subscribe(function(newValue) {
                         viewModel.model().set("relationNames", [newValue]);
                    });
               }
          },
          selectedRelationType: function(e){
               this.twoWayRelation = $(e.currentTarget).attr("value");
               this.viewModel.model().set("twoWayRelation", this.twoWayRelation);
               this.render();
          },
          serialize: function() {
               return {
                    allowMultipleRelations: this.options.allowMultipleRelations
               };
          },
          afterRender: function(){
               kb.applyBindings(this.options.viewModel, this.$el[0]);
          }
     });

     //Search Config Subview
     ManageRelationsCustomConfig.SearchSubView = Backbone.Layout.extend({
          template: 'hpiadmin/actions/customconfig/managerelations/managerelationssearchconfig',
          initialize: function() {
               var self = this;
               this.viewModel = this.options.viewModel;
               this.model = this.viewModel.model();
               this.eventBus = this.options.eventBus;

               if(!this.model.get('searchAttribute')) {
                    this.model.set('searchAttribute', this.options.baseDefaults.get('searchAttribute'));
               }

               //Difference between get/has is that get() allows an empty array, has doesn't.
               //We're allowing an empty array of search criteria, but if no value is present for
               //this key at all, we'll set default values.
               if(!this.model.has('searchCriteria')) {
                    var defaultSearchCriteria = [];
                    _.each(this.options.baseDefaults.get('searchCriteria'), function(attr) {
                         if(_.findWhere(self.options.typeAttrs, {value: attr.attrName})) {
                              defaultSearchCriteria.push(attr);
                         }
                    });
                    this.model.set('searchCriteria', defaultSearchCriteria);
               }

               //Set up listeners
               this.startListening();

               //Set up view model
               this.initializeViewModel();

               //Create subviews
               this.createSubViews();
          },
          initializeViewModel: function() {
               var self = this;

               //Set up everything needed to display the search criteria configuration, done in knockout
               this.viewModel.searchCriteria = ko.observableArray(this.viewModel.model().get('searchCriteria') || []);
               this.viewModel.searchCriteria.subscribe(function(newCriteria) {
                    self.model.set('searchCriteria', newCriteria);
               });
               this.viewModel.addDisplayCriteria = function() {
                    self.viewModel.searchCriteria.push({
                         attrName: "",
                         attrValue: ""
                    });
               };
               this.viewModel.removeDisplayCriteria = function() {
                    self.viewModel.searchCriteria.pop();
               };

          },
          startListening: function() {
               this.listenTo(this.eventBus, 'objectTypeUpdated', _.bind(this.objectTypeChangeHandler, this));
          },
          objectTypeChangeHandler: function() {
               this.resetSearchCriteria();

               //If this dropdown element has been created, reset its options
               if(this.searchAttributeDropdown) {
                    this.searchAttributeDropdown.changeOptionObjects(this.viewModel.searchCriteriaAttributes());
               }
          },
          createSubViews: function() {

               //Object Type Dropdown & Related Attribute Dropdown
               this.objectTypeDropdown = new AdminDropdown.View({
                    model: this.model,
                    configModelKey: 'searchObjectType',
                    title: window.localize('customConfig.manageWorkflowDocuments.objectTypeHeader'),
                    configDescription: window.localize('customConfig.manageWorkflowDocuments.objectTypeDesc'),
                    optionObjects: this.options.objectTypes,
                    titleIsHeaderTag: true
               });

               this.searchAttributeDropdown = new AdminDropdown.View({
                    model: this.model,
                    configModelKey: 'searchAttribute',
                    title: window.localize('customConfig.manageWorkflowDocuments.SearchAttributeHeader'),
                    configDescription: window.localize('customConfig.manageWorkflowDocuments.SearchAttributeDesc'),
                    optionObjects: this.viewModel.searchCriteriaAttributes(),
                    titleIsHeaderTag: true
               });
          },
          initializeSubViews: function() {
               this.setView('.objectTypeDropdown', this.objectTypeDropdown).render();
               this.setView('.searchAttributeDropdown', this.searchAttributeDropdown).render();
          },
          resetSearchCriteria: function() {
               this.viewModel.searchCriteria.removeAll();
          },
          afterRender: function() {
               this.initializeSubViews();
               kb.applyBindings(this.options.viewModel, this.$el[0]);
          }

     });

     ManageRelationsCustomConfig.SearchResultsSubView = Backbone.Layout.extend({
          template: 'hpiadmin/actions/customconfig/managerelations/managerelationssearchresultsconfig',
          initialize: function() {
               this.viewModel = this.options.viewModel;
               this.model = this.viewModel.model();
               this.eventBus = this.options.eventBus;

               //Check whether subviews should be enabled or not, and set default values if not configured
               if(!_.has(this.options, 'showConditions')) {
                    this.options.showConditions = false;
               }

               if(!_.has(this.options, 'showSearchLimit')) {
                    this.options.showSearchLimit = true;
               }

               //Set up model default values
               if(!this.model.get('searchResultLimit')) {
                    this.model.set('searchResultLimit', this.options.baseDefaults.get('searchResultLimit'));
               }
               
               if(!this.model.has('searchResultAttrs')){
                    this.model.set('searchResultAttrs', new Backbone.Collection(this.options.baseDefaults.get('searchResultAttrs')));
               } 

               //Also parse this collection if it isn't in collection form
               else if(!(this.model.get('searchResultAttrs') instanceof Backbone.Collection)){
                    this.model.set('searchResultAttrs', new Backbone.Collection(this.model.get('searchResultAttrs')));
               }

               if(!this.model.has('searchResultConditions')){
                    this.model.set('searchResultConditions', new Backbone.Collection(this.options.baseDefaults.get('searchResultConditions')));
               } 
               else if(!(this.model.get('searchResultConditions') instanceof Backbone.Collection)){
                    this.model.set('searchResultConditions', new Backbone.Collection(this.model.get('searchResultConditions')));
               }

               //Listen to events
               this.startListening();

               //Configure conditions
               if(this.options.showConditions) {
                    this.configureConditions();
               }

               //Load search result attributes
               this.resetSearchResultAttributes();

               //Create subviews
               this.createSubViews();
          },
          startListening: function() {
               this.listenTo(this.eventBus, 'objectTypeUpdated', _.bind(this.objectTypeChangeHandler, this));
          },
          configureConditions: function() {
               var self = this;
               this.conditionDeferred = $.Deferred();

               app.context.util.loadConditionDefinitions().done(function(conditions) {
                    self.conditions = new Backbone.Collection(conditions);
                    self.conditionDeferred.resolve();
               });
          },
          createSubViews: function() {
               var self = this;

               if(this.options.showSearchLimit) {
                    this.limitResultsDropdown = new AdminDropdown.View({
                         model: this.model,
                         configModelKey: 'searchResultLimit',
                         title: window.localize('customConfig.manageWorkflowDocuments.searchResultHeader'),
                         configDescription: window.localize('customConfig.manageWorkflowDocuments.searchResultDesc'),
                         optionObjects: [{
                              displayValue: "",
                              value: -1
                         }, {
                              displayValue: "10",
                              value: 10
                         }, {
                              displayValue: "25",
                              value: 25
                         }, {
                              displayValue: "50",
                              value: 50
                         }, {
                              displayValue: "100",
                              value: 100
                         }],
                         titleIsHeaderTag: true
                    });
               }

               if(this.options.showConditions) {
                    $.when(this.conditionDeferred).done(function() {
                         self.conditionTossAcross = new TossAcross.Layout({
                              clickAcross: true,
                              enableAddRemove: false,
                              fullscreen: true,
                              srcCollection: {
                                   title: window.localize("modules.common.tossAcross.availableConditions"),
                                   filter: true,
                                   labelAttr: 'name',
                                   collection: self.conditions
                              },
                              targetCollections: [
                                   {
                                        title: window.localize("modules.common.tossAcross.selectedConditions"),
                                        labelAttr: 'name',
                                        filter: true,
                                        collection: self.model.get('searchResultConditions')
                                   }
                              ]
                         });
                    });
               }

               this.createAttributeTossAcross();
          },
          createAttributeTossAcross: function() {
               this.searchResultAttrTossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: false,
                    srcCollection: {
                         title: window.localize("modules.common.tossAcross.availableAttributes"),
                         filter: true,
                         labelAttr: 'displayValue',
                         collection: new Backbone.Collection(this.options.typeAttrs)
                    },
                    targetCollections: [
                         {
                              title: window.localize("modules.common.tossAcross.selectedAttributes"),
                              labelAttr: 'displayValue',
                              filter: true,
                              collection: this.model.get('searchResultAttrs')
                         }
                    ]
               });
          },
          initializeSubViews: function() {
               var self = this;

               if(this.options.showSearchLimit) {
                    this.setView('.limitResultsDropdown', this.limitResultsDropdown).render();
               }

               if(this.options.showConditions) {
                    $.when(this.conditionDeferred).done(function() {
                         self.setView('.conditionTossAcross', self.conditionTossAcross).render();
                    });
               }

               this.initializeAttributeTossAcross();
          },
          initializeAttributeTossAcross: function() {
               this.setView('.searchResultAttrTossAcross', this.searchResultAttrTossAcross).render();
          },
          objectTypeChangeHandler: function() {
               //Clear any configured search result attributes
               this.resetSearchResultAttributes();

               //Recreate and rerender the toss across view. Currently the toss across view does not
               //support updating the source collection, and we don't want to rerender the entire view
               //either because that will briefly reposition the screen.
               this.createAttributeTossAcross();
               this.initializeAttributeTossAcross();
          },
          resetSearchResultAttributes: function() {
               var self = this;

               var newCollection = new Backbone.Collection([]);
               this.model.get('searchResultAttrs').each(function(model) {
                    var newModel = _.findWhere(self.options.typeAttrs, {
                         value: model.get('value')
                    });
                    if(newModel) {
                         newCollection.push({
                              value: newModel.value,
                              displayValue: newModel.displayValue
                         });
                    }
               });
               this.model.set('searchResultAttrs', newCollection);
          },
          serialize: function() {
               return {
                    showConditions: this.options.showConditions,
                    showSearchLimit: this.options.showSearchLimit
               };
          },
          afterRender: function() {
               this.initializeSubViews();
               kb.applyBindings(this.options.viewModel, this.$el[0]);
          }
     });

     return ManageRelationsCustomConfig;
});
