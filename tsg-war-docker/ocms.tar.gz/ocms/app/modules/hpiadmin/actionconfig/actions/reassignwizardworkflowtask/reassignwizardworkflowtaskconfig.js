define([
    "app",
    "module",
    "modules/hpiadmin/common/iosswitch"

], function(app, module, iOSSwitch) {
    "use strict";

    var ReassignWizardWorkflowTaskCustomConfigView = {};

    ReassignWizardWorkflowTaskCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/reassignwizardworkflowtaskconfig",

        initialize: function () {
            var viewModel = this.options.viewModel;

            viewModel.groupName = kb.observable(viewModel.model(), "groupName");
            var reassignFutureApprover = module.config().reassignFutureApprover === undefined ? true : module.config().reassignFutureApprover;

            //default set the the case sensitive required to true
            if (!viewModel.model().caseSensitiveRequired) {
                viewModel.model().caseSensitiveRequired = true;
            }

            //default set the the case sensitive required to true
            if (!viewModel.model().futureTaskEnabled) {
                viewModel.model().futureTaskEnabled = false;
            }
            
            this.enableCaseSensitiveRequired = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "caseSensitiveRequired",
                switchTitle: window.localize("generic.action.customConfig.groupNameCaseSensitiveTitle"),
                configDescription: window.localize("generic.action.customConfig.caseSensitiveGlyphiconTitle")
            });

            if (reassignFutureApprover){
                this.futureTaskEnabled = new iOSSwitch.View({
                    model: this.viewModel.model(),
                    configModelKey: "futureTaskEnabled",
                    switchTitle: "Do you want future task reassignment enabled?",
                    configDescription: window.localize("generic.action.customConfig.futureTaskReassignedExplanation")
                });

                this.setViews({
                    "#caseSensitiveRequired": this.enableCaseSensitiveRequired,
                    "#futureTaskEnabled": this.futureTaskEnabled
                });
            }

            this.setViews({
                "#caseSensitiveRequired": this.enableCaseSensitiveRequired
            });
           
            
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });
    
    return ReassignWizardWorkflowTaskCustomConfigView;

});