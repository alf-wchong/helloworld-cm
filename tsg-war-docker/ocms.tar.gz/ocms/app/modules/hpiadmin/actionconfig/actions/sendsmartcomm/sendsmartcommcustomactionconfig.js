define([
    "app",
	"modules/common/tossacross",
	"modules/hpiadmin/common/iosswitch",
	"modules/common/hpiconstants",
	'modules/hpiadmin/adminUtil'
], function(app, TossAcross, iOSSwitch, HPIConstants, AdminUtil) {
	"use strict";
    var SendSmartcommCustomConfigView = {};

    SendSmartcommCustomConfigView.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendsmartcommemail/sendsmartcommemailconfig",
		events: {
			"click .admin_ui_subsectionToggle" : "toggleSubsection",
			"click .radioValueChange": "updateSliderProperty",
			"change .inputValueChange": "updateInputProperty",
			"change #cloudSendSwitch": "render",
			"change #restrictInternalBasedOnAttachmentSizeSwitch" : "render",
			"change #restrictInternalBasedOnFileExtensionSwitch" : "render", 
			"change #restrictInternalBasedOnEmailDomainSwitch" : "render"
		},
		initialize: function(){
			this.setupViewModel();
			this.setupDefaults();
			this.populatePotentialAttributes();
			this.populatePotentialAttributesSmartComm();
		},
		setupViewModel: function() {
			var self = this;
			var viewModel = this.options.viewModel;

			//check if folderTags already exists
			if(!viewModel.model().get('folderTags')){
				viewModel.model().set('folderTags', []);
			}
			viewModel.model().set('folderTags', viewModel.model().get('folderTags'));

			/***** smartcomm configs ***********/

			viewModel.smartCommProjectId = kb.observable(viewModel.model(),"smartCommProjectId");
			viewModel.smartCommDataModelId = kb.observable(viewModel.model(),"smartCommDataModelId");
			viewModel.smartCommBatchConfigResId = kb.observable(viewModel.model(),"smartCommBatchConfigResId");
			viewModel.smartCommUseExtranet = kb.observable(viewModel.model(), "smartCommUseExtranet");

			this.viewModel.selectedFolderTypeSmartComm = kb.observable(this.viewModel.model(), 'selectedFolderTypeSmartComm');
			this.viewModel.selectedFolderTypeSmartComm.subscribe(function(){
				// Clear the stuff that was already populated upon a change and before rebuilding.
				self.viewModel.potentialAttributesSmartComm.reset();
				self.viewModel.selectedAttributesSmartComm.reset();

				self.populatePotentialAttributesSmartComm();
				self.buildAttributeTossAcrossSmartComm();
			});
			this.viewModel.potentialAttributesSmartComm = new Backbone.Collection();
			this.viewModel.selectedAttributesSmartComm = new Backbone.Collection();

			// Listener that controls any movements to the attributes selected to display for an object type
			this.stopListening(this.viewModel.selectedAttributesSmartComm, 'add remove reset');
			this.listenTo(this.viewModel.selectedAttributesSmartComm, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedAttributesSmartComm.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("smartCommAttrsToDisplay", _.extend([], newObjectProps));
			}, this);
			
			// check if there are any previously saved selected attributes 
			if(this.viewModel.model().get("smartCommAttrsToDisplay")){
				_.each(this.viewModel.model().get("smartCommAttrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedAttributesSmartComm.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedAttributesSmartComm.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("smartCommAttrsToDisplay", {});
			}

			/***** smartcomm configs ***********/

			viewModel.allowEmailTemplates = kb.observable(viewModel.model(), 'allowEmailTemplates');

			viewModel.emailStorageLocation = kb.observable(viewModel.model(), "emailStorageLocation");
			viewModel.emailObjectType = kb.observable(viewModel.model(), "emailObjectType");
			viewModel.emailRelationship = kb.observable(viewModel.model(), "emailRelationship");
			viewModel.integrateFolderNotes = kb.observable(viewModel.model(), 'integrateFolderNotes');
			viewModel.alwaysCreateNoteOnSend = kb.observable(viewModel.model(), 'alwaysCreateNoteOnSend');
			viewModel.noteObjectType = kb.observable(viewModel.model(), "noteObjectType");
			viewModel.noteType = kb.observable(viewModel.model(), "noteType");
			viewModel.noteRelationship = kb.observable(viewModel.model(), "noteRelationship");
			viewModel.validateAttachments = kb.observable(viewModel.model(), 'validateAttachments');
			viewModel.collectionAttachmentsTab = kb.observable(viewModel.model(), 'collectionAttachmentsTab');
			viewModel.exportWithAnnotationsToAttachments = kb.observable(viewModel.model(), "exportWithAnnotationsToAttachments");
			viewModel.hideAvailableDocsTab = kb.observable(viewModel.model(), "hideAvailableDocsTab");
			viewModel.hasClientCondition = kb.observable(viewModel.model(), 'hasClientCondition');
			viewModel.shareFileClientId = kb.observable(viewModel.model(), 'shareFileClientId');
			viewModel.shareFileClientSecret = kb.observable(viewModel.model(), 'shareFileClientSecret');
			viewModel.shareFileRedirectUri = kb.observable(viewModel.model(), 'shareFileRedirectUri');
			viewModel.cloudSendMode = kb.observable(viewModel.model(), 'cloudSendMode');
			viewModel.internalSendEmailAttachmentSize = kb.observable(viewModel.model(), 'internalSendEmailAttachmentSize');
			viewModel.maxLength = kb.observable(viewModel.model(), 'maxLength');

			viewModel.availablePickListsInConfig = ko.observableArray([]);
			viewModel.selectedFileExtensions = kb.observable(viewModel.model(), 'selectedFileExtensions');
			viewModel.selectedEmailDomains = kb.observable(viewModel.model(), 'selectedEmailDomains');
			$.when(app.context.configService.getPicklistServices()).done(_.bind(function(){
				_.each(app.context.currentPicklistConfig().get("picklists").models, _.bind(function(picklist){
					this.viewModel.availablePickListsInConfig.push({"label": picklist.get("label")});
				}, this));
				// asynchronous, so re-render when we know we can populate the dropdown
				this.render();
            }, this));

			// get the available document and folder types for display
			this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
			this.viewModel.availableFolderTypesInConfigSmartComm = ko.observableArray([]);
			this.availableFolderTypeConfigs = new Backbone.Collection();
			this.fetchAvailableFolderTypesDeferred = $.Deferred();

			app.context.configService.getAdminOTC(function(config) {
				config.get("configs").each(function (typeConfig) {
					if (typeConfig.get("isContainer") === "false") {
						self.viewModel.availableDocumentTypesInConfig.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					} else if(typeConfig.get("isContainer") === "true") {
						self.availableFolderTypeConfigs.add(typeConfig);
						self.viewModel.availableFolderTypesInConfigSmartComm.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					}
				}, this);
				self.fetchAvailableFolderTypesDeferred.resolveWith(self);
			});
			
			this.viewModel.selectedDocumentType = kb.observable(this.viewModel.model(), 'selectedDocumentType');
			this.viewModel.selectedDocumentType.subscribe(function(){
				// Clear the stuff that was already populated upon a change and before rebuilding.
				self.viewModel.potentialAttributes.reset();
				self.viewModel.selectedAttributes.reset();

				self.populatePotentialAttributes();
				self.buildAttributeTossAcross();
			});
			
			var keyConstants = _.keys(HPIConstants.CHARCODES);

 			// set up the models for the tossacross
			this.viewModel.potentialEnterKeys = new Backbone.Collection();
			this.viewModel.selectedEnterKeys = new Backbone.Collection(); 
			var oldSelected = this.viewModel.model().get('selectedEnterKeys') ? this.viewModel.model().get('selectedEnterKeys') : [HPIConstants.CHARCODES.Enter];
			_.each(keyConstants, _.bind(function(key){
				if (oldSelected.indexOf(HPIConstants.CHARCODES[key]) > -1){
					this.viewModel.selectedEnterKeys.push({
						'attrName': key.toString(),
						'attrValue': HPIConstants.CHARCODES[key]
					});
				}else{
					this.viewModel.potentialEnterKeys.push({
						'attrName': key.toString(),
						'attrValue': HPIConstants.CHARCODES[key]
					}); 
				}
			}, this));

			this.buildEnterKeyTossAcross();  

			// Listeners for pulling updates from tossacross into the model used in the actual code
			this.stopListening(this.viewModel.selectedEnterKeys, 'add remove reset');
			this.listenTo(this.viewModel.selectedEnterKeys, 'add remove reset', function(){
				var newSelectedEnterKeys = []; 
				_.each(this.viewModel.selectedEnterKeys.models, function(model){
					newSelectedEnterKeys.push(model.get('attrValue'));
				});
				self.viewModel.model().set("selectedEnterKeys", newSelectedEnterKeys);
			});

					
			this.viewModel.potentialAttributes = new Backbone.Collection();
			this.viewModel.selectedAttributes = new Backbone.Collection();
			
			// Listener that controls any movements to the attributes selected to display for an object type
			this.stopListening(this.viewModel.selectedAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("attrsToDisplay", _.extend([], newObjectProps));
			}, this);
			
			// check if there are any previously saved selectd attributes 
			if(this.viewModel.model().get("attrsToDisplay")){
				_.each(this.viewModel.model().get("attrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("attrsToDisplay", {});
			}
		},
		setupDefaults: function() {
			var viewModel = this.options.viewModel;
			

			if (viewModel.smartCommUseExtranet() === null){
				viewModel.smartCommUseExtranet(false);
			}

			// default hideAvailableDocsTab to false
			if (viewModel.hideAvailableDocsTab() === null){
				viewModel.hideAvailableDocsTab("false");
			}
			
			// default subject maxLength to 225
			if (viewModel.model().get('maxLength') === null) {
				viewModel.maxLength("225");
			}

			if(viewModel.allowEmailTemplates() === null){
				viewModel.allowEmailTemplates("true");
			}

			if(!viewModel.model().get('shouldValidateTotalAttachmentsSize')) {
				viewModel.model().set('shouldValidateTotalAttachmentsSize', "false");
			}

			if(!viewModel.model().get('maxTotalAttachmentsSize')) {
				viewModel.model().set('maxTotalAttachmentsSize', 5);
			}

			if (!viewModel.model().get('validateMaxNumberOfAttachments')) {
				viewModel.model().set('validateMaxNumberOfAttachments', "false");
			}

			if (!viewModel.model().get('maxNumberOfAttachments')) {
				viewModel.model().set('maxNumberOfAttachments', 3);
			}

			if(!viewModel.model().get('enableBCCControl')) {
				viewModel.model().set('enableBCCControl', 'true');
			}

			if (!viewModel.model().get('hasMaxBodyLength')) {
				viewModel.model().set('hasMaxBodyLength', "false");
			}

			if(!viewModel.model().get('hideNoResultMessage')) {
				viewModel.model().set('hideNoResultMessage', "false");
			}

			if(viewModel.emailObjectType() === null){
				viewModel.emailObjectType("HPIEmailMessage");
			}

			if(viewModel.emailStorageLocation() === null){
				viewModel.emailStorageLocation("");
			}
			//default folder notes integration to true
			if(viewModel.integrateFolderNotes() === null){
				viewModel.integrateFolderNotes("true");
			}
			// Default alwaysCreateNoteOnSend to true
			if(viewModel.alwaysCreateNoteOnSend() === null){
				viewModel.alwaysCreateNoteOnSend("true");
			}
			//default to HPI Note
			if(viewModel.noteObjectType() === null){
				viewModel.noteObjectType("HPI Note");
			}
			//default to Correspondence
			if(viewModel.noteType() === null){
				viewModel.noteType("Correspondence");
			}

			//default to hpi_folder_note --> alfresco default
			if(viewModel.noteRelationship() === null){
				viewModel.noteRelationship("hpi:folder_note");
			}
			//default validateAttachments to false
			if(viewModel.validateAttachments() === null){
				viewModel.validateAttachments("false");
			}
			//default collection attachments tab to true
			if(viewModel.collectionAttachmentsTab() === null){
				viewModel.collectionAttachmentsTab("true");
			}
			//default to alfresco relationship name
			if(viewModel.emailRelationship() === null){
				viewModel.emailRelationship("hpi:emailed");
			}

			//default to false
			if(viewModel.exportWithAnnotationsToAttachments() === null) {
				viewModel.exportWithAnnotationsToAttachments("false");
			}

			// default to disabled
			if (viewModel.model().get('cloudSendMode') === null) {
				viewModel.cloudSendMode("disabled");
			}

			if (viewModel.model().get('internalSendEmailAttachmentSize') === undefined){
				viewModel.internalSendEmailAttachmentSize('5');
			}

			viewModel.integrateFolderNotes.subscribe(function(newVal){
				if(newVal === "false"){
					//reset to defaults
					viewModel.noteObjectType("HPI Note");
					viewModel.noteType("Correspondence");
				}
			});

			viewModel.folderTags = ko.observableArray(viewModel.model().get('folderTags'));
			viewModel.folderTags.subscribe(function(tags) {
				viewModel.model().set('folderTags', tags);
			});

			viewModel.hideAvailableDocsTab.subscribe(_.bind(this.updateAttachmentSizeValidationDisplay, this));
			viewModel.collectionAttachmentsTab.subscribe(_.bind(this.updateAttachmentSizeValidationDisplay, this));

			this.displayTotalAttachmentSizeConfig = this.viewModel.hideAvailableDocsTab() === "true" && this.viewModel.collectionAttachmentsTab() !== "true";

			// defualt to no client condition
			if (viewModel.hasClientCondition() === null){
				viewModel.hasClientCondition("false");
			}

			viewModel.repeatingPlaceholder = ko.observable();
			//repeating values need two extra functions for adding and removing from value
			viewModel.addValue = function() {
				//don't add anything if it already exists in value, make sure that
				//only whitespace is not entered, and ensure the value is properly
				//trimmed when added to the array
				if (_.indexOf(viewModel.folderTags(), viewModel.repeatingPlaceholder()) < 0 &&
						viewModel.repeatingPlaceholder() &&
						viewModel.repeatingPlaceholder().trim() !== "") {
					viewModel.folderTags.push(viewModel.repeatingPlaceholder().trim());
				}
				viewModel.repeatingPlaceholder("");
			};

			viewModel.removeValue = function(item) {
				viewModel.folderTags.remove(item);
			};
		},
		createSubViews: function() {
			this.buildAttributeTossAcross();
			this.buildAttributeTossAcrossSmartComm();
			this.buildEnterKeyTossAcross();

			this.enableExtranetLinkConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "smartCommUseExtranet",
				switchTitle: window.localize("customConfig.sendSmartcomm.extranetLink"),
				configDescription: window.localize("customConfig.sendSmartcomm.extranetLink.infoText")
			});

			this.enableUploadAttachmentsActionConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "enableUploadAttachmentsAction",
				switchTitle: window.localize("customConfig.sendEmailConfig.uploadAttachmentsAction.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.uploadAttachmentsAction.info")
			});

			this.hideNoResultMessageConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "hideNoResultMessage",
				switchTitle: window.localize("customConfig.sendEmailConfig.hideNoResultMessage.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.hideNoResultMessage.info")
			});

			this.enableSelectAttachmentVersionConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "enableSelectAttachmentVersion",
				switchTitle: window.localize("customConfig.sendEmailConfig.selectAttachmentVersionAction.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.selectAttachmentVersionAction.info")
			});

			this.restrictInternalBasedOnAttachmentSizeConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnAttachmentSize",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictAttachmentSizeSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictAttachmentSizeSwitchDescription")
			});

			this.restrictInternalBasedOnFileExtensionConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnFileExtension",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictAttachmentExtensionSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictAttachmentExtensionSwitchDescription")
			});

			this.restrictInternalBasedOnEmailDomainConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnEmailDomain",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictEmailDomainSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictEmailDomainSwitchDescription")
			});

			this.fetchAvailableFolderTypesDeferred.done(this.createSubjectPrefixView);
		},
		setAndRenderSubViews: function() {
			this.setViews({
				"#enableExtranetLink": this.enableExtranetLinkConfigView,
				"#uploadActionSwitch": this.enableUploadAttachmentsActionConfigView,
				"#hideNoResultMessageSwitch": this.hideNoResultMessageConfigView,
				"#selectAttachmentVersionSwitch": this.enableSelectAttachmentVersionConfigView,
				"#restrictInternalBasedOnAttachmentSizeSwitch" : this.restrictInternalBasedOnAttachmentSizeConfigView,
				"#restrictInternalBasedOnFileExtensionSwitch" : this.restrictInternalBasedOnFileExtensionConfigView,
				"#restrictInternalBasedOnEmailDomainSwitch" : this.restrictInternalBasedOnEmailDomainConfigView,
				'#subjectPrefixView': this.subjectPrefixView
			}).renderViews();
		},

		createSubjectPrefixView: function() {
			this.subjectPrefixView = new SendSmartcommCustomConfigView.SubjectPrefixConfig({
				viewModel: this.viewModel,
				availableFolderTypes: this.availableFolderTypeConfigs
			});
		},
		updateAttachmentSizeValidationDisplay: function() {
			// attachment size validation is only available if the available docs and collection tabs are hidden
			// TODO once this validation is implemented for these configurations, this logic should be removed..
			var displayShowAttachmentSize = this.viewModel.hideAvailableDocsTab() === "true" && this.viewModel.collectionAttachmentsTab() !== "true";
			// only change the value of the config if hide available docs or collection tabs are configured to show
			if(!displayShowAttachmentSize) {
				this.viewModel.model().set("shouldValidateTotalAttachmentsSize", displayShowAttachmentSize.toString());
			}
			this.displayTotalAttachmentSizeConfig = displayShowAttachmentSize;
			// render to hide/show the shouldValidateTotalAttachmentsSize config control
			this.render();
		},
		updateInputProperty: function(event) {
			var currentTarget =  $(event.currentTarget);
			var key = currentTarget.attr("data-key");
			var value = currentTarget.val();

			// if the input is a number input we'll have to parse it
			if (currentTarget.attr('type') === 'number') {
				// for now, assuming this will always be an int
				value = parseInt(value, 10);
			}
			this.viewModel.model().set(key, value);
		},
		updateSliderProperty: function(event) {
			var modelProperty = $(event.target).attr("data-prop");
			var target = "input[id='" + $(event.target).attr("for") + "']";
			this.viewModel.model().set(modelProperty, $(target).val());
			// render will update whether the slider is checked
			// and display any dependent config fields
			this.render();
		},
		populatePotentialAttributes: function(){
			var self = this;
			this.viewModel.potentialAttributes.reset();
			
			if (this.viewModel.selectedDocumentType()){
				//Getting all potential attributes from the OTC
				app.context.configService.getAdminTypeConfig(this.viewModel.selectedDocumentType(), function(typeConfig){
					_.each(typeConfig.get("attrs").models, function(attr) {
						if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("attrsToDisplay"), 'attrValue')) === -1 ) {
							self.viewModel.potentialAttributes.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
						}
					});
				});
			}

		},
		buildAttributeTossAcross: function(){
			this.populatePotentialAttributes();
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.potentialAttributes
				},
				targetCollections: [
					{
						title: 'Selected Attribute',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedAttributes
					}
				]
			});
			
			this.setView("#attributesTossAcross", tossAcross).render();
		},
		populatePotentialAttributesSmartComm: function(){
			var self = this;
			this.viewModel.potentialAttributesSmartComm.reset();
			
			if (this.viewModel.selectedFolderTypeSmartComm()){
				//Getting all potential attributes from the OTC
				app.context.configService.getAdminTypeConfig(this.viewModel.selectedFolderTypeSmartComm(), function(typeConfig){
					_.each(typeConfig.get("attrs").models, function(attr) {
						if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("smartCommAttrsToDisplay"), 'attrValue')) === -1 ) {
							self.viewModel.potentialAttributesSmartComm.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
						}
					});
				});
			}
		},
		buildAttributeTossAcrossSmartComm: function(){
			this.populatePotentialAttributesSmartComm();
			var tossAcrossSmartComm = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.potentialAttributesSmartComm
				},
				targetCollections: [
					{
						title: 'Selected Attribute',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedAttributesSmartComm
					}
				]
			});
			
			this.setView("#attributesTossAcrossSmartComm", tossAcrossSmartComm).render();
		},
		buildEnterKeyTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Keys',
					filter: true,
					labelAttr: 'attrName', 
					collection: this.viewModel.potentialEnterKeys
				}, 
				targetCollections: [
					{
						title: 'Selected Keys',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedEnterKeys
					}
				]
			});

			this.setView("#enterKeysTossAcross", tossAcross).render();
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
			this.createSubViews();
			// don't render the subviews until they've all been created
			this.fetchAvailableFolderTypesDeferred.done(this.setAndRenderSubViews);
		},
		serialize: function() {
			return {
				displayTotalAttachmentSizeConfig: this.displayTotalAttachmentSizeConfig,
				shouldValidateTotalAttachmentsSize: this.viewModel.model().get('shouldValidateTotalAttachmentsSize') === "true",
				maxTotalAttachmentsSize: this.viewModel.model().get('maxTotalAttachmentsSize'),
				validateMaxNumberOfAttachments: this.viewModel.model().get('validateMaxNumberOfAttachments') === "true",
				maxNumberOfAttachments: this.viewModel.model().get('maxNumberOfAttachments'),
				enableBCCControl: this.viewModel.model().get('enableBCCControl') === "true",
				hasMaxBodyLength: this.viewModel.model().get('hasMaxBodyLength') === "true",
				maxBodyCharacters: this.viewModel.model().get('maxBodyCharacters'),
				collectionActionConfig: this.collectionActionConfig,
				dependentCloudSend: this.viewModel.model().get('cloudSendMode') === "dependent",
				restrictInternalBasedOnAttachmentSize: this.viewModel.model().get('restrictInternalBasedOnAttachmentSize'),
				restrictInternalBasedOnFileExtension: this.viewModel.model().get('restrictInternalBasedOnFileExtension'), 
				restrictInternalBasedOnEmailDomain: this.viewModel.model().get('restrictInternalBasedOnEmailDomain')
			};
		},
		toggleSubsection: function(e) {
                AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
        },
    });

    SendSmartcommCustomConfigView.SubjectPrefixPatternConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendsmartcommemail/sendsmartcommemailsubjectprefixpatternconfig",
		events: {
			"click #addToPatternBtn": "addPropertyToPattern",
			"change #folderTypeAttrs": "updatedSelectedFolderAttr",
			"change #subjectPrefixPattern": "updateSubjectPrefixPattern",
			"click #save-subject-prefix-btn": "updateModelWithPrefix"
		},

		initialize: function(options) {
			this.selectedFolderType = options.selectedFolderType;
			this.selectedFolderTypeName = this.selectedFolderType.get('ocName');
			this.viewModel = options.viewModel;
			this.existingSubjectPrefixes = options.configuredSubjectPrefixes;
			this.subjectPrefixConfigModel = this.existingSubjectPrefixes.get(this.selectedFolderTypeName);
			if(this.subjectPrefixConfigModel) {
				// when we open the subject prefix modal, this may not be an object on legacy configs
				if(!(this.subjectPrefixConfigModel instanceof Backbone.Model)) {
					this.subjectPrefixConfigModel = new Backbone.Model(this.subjectPrefixConfigModel);
				}
			} else {
				this.subjectPrefixConfigModel = new Backbone.Model({
					isSubjectPrefixEditable: true,
					pattern: ""
				});
			}
			
			this.isSubjectEditable = this.subjectPrefixConfigModel.get('isSubjectPrefixEditable');
			this.subjectPrefixPattern = this.subjectPrefixConfigModel.get("pattern");
			if(this.selectedFolderType.get('attrs')) {
				var firstAttr = this.selectedFolderType.get('attrs').first();
				if(firstAttr) {
					this.selectedFolderAttr = firstAttr.get('ocName');
				}
			}
		},

		updatedSelectedFolderAttr: function(event) {
			this.selectedFolderAttr = $(event.target).val();
		},

		updateSubjectPrefixPattern: function(event) {
			this.subjectPrefixPattern = $(event.target).val();
		},

		addPropertyToPattern: function() {
			if(this.selectedFolderAttr) {
				var attrStr = "$" + this.selectedFolderAttr + "$";
				this.subjectPrefixPattern = this.subjectPrefixPattern + attrStr;
				this.$("#subjectPrefixPattern").val(this.subjectPrefixPattern);
				this.$("#subjectPrefixPattern").focus();
			}
		},

		updateModelWithPrefix: function() {
			this.subjectPrefixConfigModel.set("pattern", this.subjectPrefixPattern);
			this.existingSubjectPrefixes.set(this.selectedFolderTypeName, this.subjectPrefixConfigModel.toJSON());
			this.viewModel.model().set('subjectPrefixes', this.existingSubjectPrefixes);
		},

		createAndSetSubViews: function() {
			this.isSubjectPrefixEditableConfigView = new iOSSwitch.View({
				model: this.subjectPrefixConfigModel,
				configModelKey: "isSubjectPrefixEditable",
				switchTitle: window.localize("customConfig.sendEmailConfig.isSubjectPrefixEditable.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.isSubjectPrefixEditable.info")
			});

			this.setView("#isSubjectPrefixEditableSwitch", this.isSubjectPrefixEditableConfigView);
		},

		beforeRender: function() {
			this.createAndSetSubViews();
		},

		serialize: function() {
			return {
				folderTypeProps: this.selectedFolderType.get('attrs').toJSON(),
				subjectPrefixPattern: this.subjectPrefixPattern
			};
		}
	});

	SendSmartcommCustomConfigView.SubjectPrefixConfig = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendsmartcommemail/sendsmartcommemailsubjectprefixconfig",
		events: {
			"click .addSendEmailSubjectPrefix": "launchSubjectPrefixModal",
			"click .addSubjectPrefix": "selectFolderType",
			"click .removeSendEmailSubjectPrefix": "removeSubjectPrefix"
		},
		initialize: function(options) {
			this.viewModel = options.viewModel;
			this.availableFolderTypes = options.availableFolderTypes;
			this.configuredSubjectPrefixes = this.viewModel.model().get('subjectPrefixes');
			if(this.configuredSubjectPrefixes) {
				//if we're coming into this action view for the first time, configuredSubjectPrefixes will just be an object
				if(!(this.configuredSubjectPrefixes instanceof Backbone.Model)) {
					this.configuredSubjectPrefixes = new Backbone.Model(this.configuredSubjectPrefixes);
				} 
				var configuredOcNames = this.configuredSubjectPrefixes.keys();
				this.selectedFolderTypes = new Backbone.Collection(this.availableFolderTypes.filter(function(folderType) {
					return _.contains(configuredOcNames, folderType.get('ocName'));
				}));

				// remove all the configured folder types from available folder types
				this.availableFolderTypes = new Backbone.Collection(this.availableFolderTypes.reject(function(folderType) {
					return _.contains(configuredOcNames, folderType.get('ocName'));
				}));
			} else {
				this.selectedFolderTypes = new Backbone.Collection();
				this.configuredSubjectPrefixes = new Backbone.Model();
				this.viewModel.model().set('subjectPrefixes', this.configuredSubjectPrefixes);
			}
			this.selectedFolderTypes.comparator = "label";
			this.availableFolderTypes.comparator = "label";
		},
		launchSubjectPrefixModal: function(event) {
			var selectedFolderType = $(event.target).attr("data-value");
			this.subjectPrefixPatternConfigView = new SendSmartcommCustomConfigView.SubjectPrefixPatternConfigView({
				selectedFolderType: this.selectedFolderTypes.findWhere({ocName: selectedFolderType}),
				viewModel: this.viewModel,
				configuredSubjectPrefixes: this.configuredSubjectPrefixes
			});
			app.trigger('alert:custom', {
                view: this.subjectPrefixPatternConfigView
			});
		},
		removeSubjectPrefix: function(event) {
			var ocName = $(event.target).attr("data-value");
			var selectedFolderType = this.selectedFolderTypes.findWhere({ocName: ocName});
			this.availableFolderTypes.add(selectedFolderType);
			this.selectedFolderTypes.remove(selectedFolderType);
			if(this.configuredSubjectPrefixes) {
				this.configuredSubjectPrefixes.unset(ocName);
				this.viewModel.model().set('subjectPrefixes', this.configuredSubjectPrefixes);
			}
			this.render();
		},
		selectFolderType: function(event) {
			var ocName = $(event.target).val();
			var selectedFolderType = this.availableFolderTypes.findWhere({ocName: ocName});
			this.availableFolderTypes.remove(selectedFolderType);
			this.selectedFolderTypes.add(selectedFolderType);
			this.render();
		},
		serialize: function() {
			return {
				availableFolderTypes: this.availableFolderTypes.toJSON(),
				selectedFolderTypes: this.selectedFolderTypes.toJSON(),
				showSelectedFolderTypes: this.selectedFolderTypes && this.selectedFolderTypes.length > 0
			};
		}
	});
    
    return SendSmartcommCustomConfigView;
});