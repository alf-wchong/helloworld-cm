define([
    "app",
    "modules/hpiadmin/common/iosswitch"

], function(app, iOSSwitch) {
    "use strict";

    var DelegateWizardWorkflowTaskCustomConfigView = {};

    DelegateWizardWorkflowTaskCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/delegatewizardworkflowtaskconfig",

        initialize: function () {
            var viewModel = this.options.viewModel;

            viewModel.groupName = kb.observable(viewModel.model(), "groupName");

            //default set the the case sensitive required to true
            if (!viewModel.model().caseSensitiveRequired) {
                viewModel.model().caseSensitiveRequired = true;
            }

             this.enableCaseSensitiveRequired = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "caseSensitiveRequired",
                switchTitle: window.localize("generic.action.customConfig.groupNameCaseSensitiveTitle"),
                configDescription: window.localize("generic.action.customConfig.caseSensitiveGlyphiconTitle")
            });

            this.setViews({
                "#caseSensitiveRequired": this.enableCaseSensitiveRequired
            });
            
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    return DelegateWizardWorkflowTaskCustomConfigView;

});