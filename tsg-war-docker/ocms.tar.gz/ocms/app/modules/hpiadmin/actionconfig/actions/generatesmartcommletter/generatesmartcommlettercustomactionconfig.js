define([
    "app",
	'modules/hpiadmin/actionconfig/actions/sendsmartcomm/sendsmartcommcustomactionconfig'
], 

function(app, SendSmartcommCustomConfigView) {
	"use strict";
    var GenerateSmartcommLetterCustomConfigView = {};

    GenerateSmartcommLetterCustomConfigView.View = SendSmartcommCustomConfigView.View.extend({
		template: "hpiadmin/actions/customconfig/generatesmartcommletterconfig",
		setupViewModel: function() {
			GenerateSmartcommLetterCustomConfigView.View.__super__.setupViewModel.apply(this);

			this.viewModel.potentialForms = ko.observableArray();
			this.viewModel.form = kb.observable(this.viewModel.model(), "form");
			// Storing the current form value to then set once all potential forms are retrieved 
			this.formSubscribePlaceholder = this.viewModel.form();

			var self = this;
			app.context.configService.getFormConfigNames(function(formConfigNames) {
				self.viewModel.potentialForms(formConfigNames);
				self.viewModel.form(self.formSubscribePlaceholder);
				//since the form value is bound from the potentialForms observable,
				//this context call will come back after the form has been gathered
				//from the config. this resets the form to the right value.
			});
		}
	});
    
    return GenerateSmartcommLetterCustomConfigView;
});