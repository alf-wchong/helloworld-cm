define([
    "app",
    "modules/hpiadmin/common/iosswitch"
    
], function(app, iOSSwitch) {
	"use strict";
    var ObsoleteDocumentConfig = {};

	ObsoleteDocumentConfig.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/obsoletedocumentconfig",
        initialize: function(){
            this.viewModel = this.options.viewModel;

            this.sigPageConfirmation = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "sigPagesUsed",
                switchTitle: window.localize("customConfig.obsoleteDocument.sig.title"),
                configDescription: window.localize("customConfig.obsoleteDocument.sig.desc"),
                onLabel: window.localize("generic.yes"),
                trueVal: true,
                offLabel: window.localize("generic.no"),
                defaultSwitchValue: false,
                falseVal: false,
                customClass: "switch-200w"
            });

             this.requireAuth = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "requireAuthentication",
                switchTitle: window.localize("customConfig.obsoleteDocument.req.auth"),
                configDescription: window.localize("customConfig.obsoleteDocument.req.auth.desc"),
                onLabel: window.localize("generic.yes"),
                trueVal: true,
                offLabel: window.localize("generic.no"),
                defaultSwitchValue: true,
                falseVal: false,
                customClass: "switch-200w"
            });

            // set email switch view
            this.setViews({
                "#sigPageConfirmation": this.sigPageConfirmation,
                "#requireAuth": this.requireAuth
            });
        }
	});

	return ObsoleteDocumentConfig;
});