define([
    "app",
    "modules/hpiadmin/common/iosswitch",
    "modules/common/hpiconstants",
    'modules/hpiadmin/adminUtil',
    "modules/common/tossacross",
    "modules/hpiadmin/searchconfig/emailtemplatesconfig"
], function(app, iOSSwitch, HPIConstants, AdminUtil, TossAcross, EmailTemplatesConfig) {
    "use strict";

     var ACTPDFSendEmailCustomConfig = {};

     ACTPDFSendEmailCustomConfig.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/advancedcombinetopdfsendemailconfig",
        events: {
            "click #computedBookmarkAttr-button": "updateComputedBookmarkPattern",
            "click .admin_ui_subsectionToggle" : "toggleSubsection",
            "click #open-templates-config-modal" : "openTemplatesConfigModal",
			"click .radioValueChange": "updateSliderProperty",
			"change .inputValueChange": "updateInputProperty",
			"change #cloudSendSwitch": "render",
			"change #restrictInternalBasedOnFileExtensionSwitch" : "render", 
			"change #restrictInternalBasedOnEmailDomainSwitch" : "render"
        },
        initialize: function() {
            //Creates drag and drop for the user to select the attributes to configure for this action.
            this.viewModel = this.options.viewModel;
            this.model = this.viewModel.model();

            // send email specific set up
            this.setupViewModel();
			this.setupDefaults();
			this.populatePotentialAttributes();

            //Grab the search config and available document types off of the options
            //The trac option is the same as the search config name. When configuring search configs they arent associated with a trac
            //this is just a poorly named variable. This variable should be updated at some point
            this.currentSearchConfig = this.options.trac;
            this.availableObjectTypes = this.options.availableObjectTypes;

            this.viewModel.potentialForms = ko.observableArray();
            this.viewModel.form = kb.observable(this.model, "form");
            //Sotring the current form value to then set once all potential forms are retrieved 
            this.formSubscribePlaceholder = this.viewModel.form();

            var self = this;
            app.context.configService.getFormConfigNames(function(formConfigNames) {
                self.viewModel.potentialForms(formConfigNames);
                self.viewModel.form(self.formSubscribePlaceholder);
                //since the form value is bound from the potentialForms observable,
                //this context call will come back after the form has been gathered
                //from the config. this resets the form to the right value.
            });

            //A default path to upload documents to if contextLessUpload is true. This default value will be used if an object type
            //we are trying to upload does not have a custom path. Its default value is nothing
            this.viewModel.containerPath = kb.observable(this.model, "containerPath");

            //This observable will contain all available document types that do not have custom path defined for them
            this.viewModel.objectTypesWithoutPathConfig = ko.observableArray([]);
            //The value chosen from the objectTypesWithoutPathConfig drop down
            this.viewModel.selectedObjectTypeWithoutPathConfig = ko.observable();
            // An array of AdvancedCombineToPDF.TypePathViewModel that indicate a objectType to custom path relationship
            this.viewModel.typePathViewModels = ko.observableArray([]);
            //An object indicating the objectType to custom path relationship. Gets populated by the typePathViewModels
            this.viewModel.typePathServerData = this.model.get("customTypePaths") ? this.model.get("customTypePaths") : {};

            // this allows a user to delete a path configuration for a selected object type. Need to bind it so it
            //keeps context
            this.viewModel.deleteTypePath = _.bind(this.deleteTypePath,this);

            $.when(this.setCurrentConfigSelection()).done(_.bind(this.setCurrentConfigSelectionCallBack, this));
        },
        setupViewModel: function() {
			var self = this;
			var viewModel = this.options.viewModel;

			//check if folderTags already exists
			if(!viewModel.model().get('folderTags')){
				viewModel.model().set('folderTags', []);
			}
			viewModel.model().set('folderTags', viewModel.model().get('folderTags'));

			viewModel.maxLength = kb.observable(viewModel.model(), "maxLength");
			viewModel.bodyFormat = kb.observable(viewModel.model(), "bodyFormat");
			viewModel.emailStorageLocation = kb.observable(viewModel.model(), "emailStorageLocation");
			viewModel.emailObjectType = kb.observable(viewModel.model(), "emailObjectType");
			viewModel.emailRelationship = kb.observable(viewModel.model(), "emailRelationship");
			viewModel.integrateFolderNotes = kb.observable(viewModel.model(), 'integrateFolderNotes');
			viewModel.alwaysCreateNoteOnSend = kb.observable(viewModel.model(), 'alwaysCreateNoteOnSend');
			viewModel.noteObjectType = kb.observable(viewModel.model(), "noteObjectType");
			viewModel.noteType = kb.observable(viewModel.model(), "noteType");
			viewModel.noteRelationship = kb.observable(viewModel.model(), "noteRelationship");
			viewModel.exportWithAnnotationsToAttachments = kb.observable(viewModel.model(), "exportWithAnnotationsToAttachments");
			viewModel.hasClientCondition = kb.observable(viewModel.model(), 'hasClientCondition');
			viewModel.shareFileClientId = kb.observable(viewModel.model(), 'shareFileClientId');
			viewModel.shareFileClientSecret = kb.observable(viewModel.model(), 'shareFileClientSecret');
			viewModel.shareFileRedirectUri = kb.observable(viewModel.model(), 'shareFileRedirectUri');
			viewModel.allowEmailTemplates = kb.observable(viewModel.model(), 'allowEmailTemplates');
			viewModel.cloudSendMode = kb.observable(viewModel.model(), 'cloudSendMode');
			viewModel.internalSendEmailAttachmentSize = kb.observable(viewModel.model(), 'internalSendEmailAttachmentSize');

			viewModel.availablePickListsInConfig = ko.observableArray([]);
			viewModel.selectedFileExtensions = kb.observable(viewModel.model(), 'selectedFileExtensions');
			viewModel.selectedEmailDomains = kb.observable(viewModel.model(), 'selectedEmailDomains');
			$.when(app.context.configService.getPicklistServices()).done(_.bind(function(){
				_.each(app.context.currentPicklistConfig().get("picklists").models, _.bind(function(picklist){
					this.viewModel.availablePickListsInConfig.push({"label": picklist.get("label")});
				}, this));
				// asynchronous, so re-render when we know we can populate the dropdown
				this.render();
            }, this));

			// get the available document and folder types for display
			this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
			this.availableFolderTypeConfigs = new Backbone.Collection();
			this.fetchAvailableFolderTypesDeferred = $.Deferred();

			app.context.configService.getAdminOTC(function(config) {
				config.get("configs").each(function (typeConfig) {
					if (typeConfig.get("isContainer") === "false") {
						self.viewModel.availableDocumentTypesInConfig.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					} else if(typeConfig.get("isContainer") === "true") {
						self.availableFolderTypeConfigs.add(typeConfig);
					}
				}, this);
				self.fetchAvailableFolderTypesDeferred.resolveWith(self);
			});
			
			this.viewModel.selectedDocumentType = kb.observable(this.viewModel.model(), 'selectedDocumentType');
			this.viewModel.selectedDocumentType.subscribe(function(){
				// Clear the stuff that was already populated upon a change and before rebuilding.
				self.viewModel.potentialAttributes.reset();
				self.viewModel.selectedAttributes.reset();

				self.populatePotentialAttributes();
				self.buildAttributeTossAcross();
			});
			
			var keyConstants = _.keys(HPIConstants.CHARCODES);

 			// set up the models for the tossacross
			this.viewModel.potentialEnterKeys = new Backbone.Collection();
			this.viewModel.selectedEnterKeys = new Backbone.Collection(); 
			var oldSelected = this.viewModel.model().get('selectedEnterKeys') ? this.viewModel.model().get('selectedEnterKeys') : [HPIConstants.CHARCODES.Enter];
			_.each(keyConstants, _.bind(function(key){
				if (oldSelected.indexOf(HPIConstants.CHARCODES[key]) > -1){
					this.viewModel.selectedEnterKeys.push({
						'attrName': key.toString(),
						'attrValue': HPIConstants.CHARCODES[key]
					});
				}else{
					this.viewModel.potentialEnterKeys.push({
						'attrName': key.toString(),
						'attrValue': HPIConstants.CHARCODES[key]
					}); 
				}
			}, this));

			this.buildEnterKeyTossAcross();  

			// Listeners for pulling updates from tossacross into the model used in the actual code
			this.stopListening(this.viewModel.selectedEnterKeys, 'add remove reset');
			this.listenTo(this.viewModel.selectedEnterKeys, 'add remove reset', function(){
				var newSelectedEnterKeys = []; 
				_.each(this.viewModel.selectedEnterKeys.models, function(model){
					newSelectedEnterKeys.push(model.get('attrValue'));
				});
				self.viewModel.model().set("selectedEnterKeys", newSelectedEnterKeys);
			});

					
			this.viewModel.potentialAttributes = new Backbone.Collection();
			this.viewModel.selectedAttributes = new Backbone.Collection();
			
			// Listener that controls any movements to the attributes selected to display for an object type
			this.stopListening(this.viewModel.selectedAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("attrsToDisplay", _.extend([], newObjectProps));
			}, this);
			
			// check if there are any previously saved selectd attributes 
			if(this.viewModel.model().get("attrsToDisplay")){
				_.each(this.viewModel.model().get("attrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("attrsToDisplay", {});
			}
		},
		setupDefaults: function() {
			var viewModel = this.options.viewModel;

			
            //If enabled, allows the admin to define a custom path to upload a combined document to. If not set
            //default the value to false
            this.viewModel.contextLessUpload = kb.observable(this.model, "contextLessUpload");
            if (!this.viewModel.contextLessUpload()) {
                this.viewModel.contextLessUpload('false');
            }

            // If enabled, allows the user to select the version of documents to include in the combined pdf
            // default the value to false
            this.viewModel.showSelectVersionColumn = kb.observable(this.model, "showSelectVersionColumn");
            if (!this.viewModel.showSelectVersionColumn()) {
                this.viewModel.showSelectVersionColumn("false");
            }

			//The title of the index page for the generated combined PDF. If not set then default the value to "Generated Combined PDF Index"
			this.viewModel.indexTitle = kb.observable(this.model, "indexTitle");
			if (!this.viewModel.indexTitle()) {
				this.viewModel.indexTitle("Generated Combined PDF Index");
			}

			//The poll timeout for the progress bar. If not set, default to 1000 ms (1 second)
			this.viewModel.progressBarPollTimeout = kb.observable(this.model, "progressBarPollTimeout");
			if (!this.viewModel.progressBarPollTimeout()) {
				this.viewModel.progressBarPollTimeout("1000");
			}


			//The available document types in the currentSearchConfig
			this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
			//The selected document type from the drop down containing the availableDocumentTypesInConfig array
			this.viewModel.selectedDocumentType = kb.observable(this.model ,"selectedDocumentType");
			//All attributes in the selectedDocumentType
			this.viewModel.allAttributes = ko.observableArray([]);
			//The selected attribute from the allAttributes drop down (AKA: The attribute to add to the bookmark Pattern)
			this.viewModel.selectedBookmarkAttribute = ko.observable(this.model, "selectedBookmarkAttribute");
			//The computed bookmark value to display in the bookmark Column
			this.viewModel.computedBookmarkPattern = kb.observable(this.model, "computedBookmarkPattern");

			// show default name. If not set the default the value to true
			this.viewModel.showDefaultName = kb.observable(this.model, "showDefaultName");
			if (!this.viewModel.showDefaultName()) {
				this.viewModel.showDefaultName("true");
			}

			//show bookmark column. If not set then default the value to false
			this.viewModel.showBookmarkColumn = kb.observable(this.model,"showBookmarkColumn");
			if (!this.viewModel.showBookmarkColumn()) {
				this.viewModel.showBookmarkColumn("false");
			}

			//Allow Renditionable documents to be combined. If not set then default the value to false;
			this.viewModel.allowRenditionable = kb.observable(this.model, 'allowRenditionable');
			if (!this.viewModel.allowRenditionable()) {
				this.viewModel.allowRenditionable('false');
			}

			//Should the user be able to combine documents with their annotations? If not set then default the value to false
			this.viewModel.exportWithAnnotationsToAttachments = kb.observable(this.model, "exportWithAnnotationsToAttachments");
			if (!this.viewModel.exportWithAnnotationsToAttachments()) {
				this.viewModel.exportWithAnnotationsToAttachments("false");
			}

			//Allow the user to choose which pages in a document to combined. If not set then default the value to false
			this.viewModel.enableSelectedPages = kb.observable(this.model, "enableSelectedPages");
			if (!this.viewModel.enableSelectedPages()) {
				this.viewModel.enableSelectedPages("false");
			}

			// PDF size limit
			this.viewModel.limitCombinedPdfSize = kb.observable(this.model, 'limitCombinedPdfSize');
			if (!this.viewModel.limitCombinedPdfSize()) {
				this.viewModel.limitCombinedPdfSize(5);
			}

			//When combinding a document, should a folder note be created? If not set then default the value false 
			this.viewModel.folderNotes = kb.observable(this.model, "folderNotes");
			if (!this.viewModel.folderNotes()) {
				this.viewModel.folderNotes("false");
			}

			//The Folder Note Object Type. If not set then default the value to "HPI NOTE"
			this.viewModel.folderNoteObjectType = kb.observable(this.model, "folderNoteObjectType");
			if (!this.viewModel.folderNoteObjectType()) {
				this.viewModel.folderNoteObjectType("HPI Note");
			}

			// The note type to apply to all folder notes. If not set then default the value to "Audit Trail"
			this.viewModel.folderNoteType = kb.observable(this.model, "folderNoteType");
			if (!this.viewModel.folderNoteType()) {
				this.viewModel.folderNoteType("Audit Trail");
			}

			//Selected folder note relationship from admin. By default will be set to the localization of generic.action.customConfig.hpiFolderNoteAlf
			this.viewModel.folderNoteRelationship = kb.observable(this.model, "folderNoteRelationship");

			//Should the uploaded document inherit the properties from the folder it is in? If not set then default the value to false
			this.viewModel.inheritFolderAttributes = kb.observable(this.model, "inheritFolderAttributes");
			if (!this.viewModel.inheritFolderAttributes()) {
				this.viewModel.inheritFolderAttributes('false');
			}

			// default subject maxLength to 225
			if (!viewModel.model().get('maxLength')) {
				viewModel.maxLength("225");
			}

			//default email body is HTML
			if(viewModel.bodyFormat() === null){
				viewModel.bodyFormat("html");
			}

			if(!viewModel.model().get('enableBCCControl')) {
				viewModel.model().set('enableBCCControl', 'true');
			}

			if (!viewModel.model().get('hasMaxBodyLength')) {
				viewModel.model().set('hasMaxBodyLength', "false");
			}
      
			if (!viewModel.model().get('maxBodyCharacters')) {
				viewModel.model().set('maxBodyCharacters', 8000);
			}

			/*
			if(!viewModel.model().get('hideNoResultMessage')) {
				viewModel.model().set('hideNoResultMessage', "false");
			}
			*/

			if(viewModel.emailObjectType() === null){
				viewModel.emailObjectType("HPIEmailMessage");
			}

			if(viewModel.emailStorageLocation() === null){
				viewModel.emailStorageLocation("Correspondence");
			}
			//default folder notes integration to false
			if(viewModel.integrateFolderNotes() === null){
				viewModel.integrateFolderNotes("false");
			}
			// Default alwaysCreateNoteOnSend to true
			if(viewModel.alwaysCreateNoteOnSend() === null){
				viewModel.alwaysCreateNoteOnSend("true");
			}
			//default to HPI Note
			if(viewModel.noteObjectType() === null){
				viewModel.noteObjectType("HPI Note");
			}
			//default to Correspondence
			if(viewModel.noteType() === null){
				viewModel.noteType("Correspondence");
			}

			//default to hpi_folder_note --> documentum default
			if(viewModel.noteRelationship() === null){
				viewModel.noteRelationship("hpi_folder_note");
			}
			//default to dctm relationship name
			if(viewModel.emailRelationship() === null){
				viewModel.emailRelationship("hpi_emailed");
			}

			//default to false
			if(viewModel.exportWithAnnotationsToAttachments() === null) {
				viewModel.exportWithAnnotationsToAttachments("false");
			}

			// default to disabled
			if (viewModel.model().get('cloudSendMode') === null) {
				viewModel.cloudSendMode("disabled");
			}

			if (viewModel.model().get('internalSendEmailAttachmentSize') === undefined){
				viewModel.internalSendEmailAttachmentSize('5');
			}

			viewModel.integrateFolderNotes.subscribe(function(newVal){
				if(newVal === "false"){
					//reset to defaults
					viewModel.noteObjectType("HPI Note");
					viewModel.noteType("Correspondence");
				}
			});

			viewModel.folderTags = ko.observableArray(viewModel.model().get('folderTags'));

			viewModel.folderTags.subscribe(function(tags) {
				viewModel.model().set('folderTags', tags);
			});

			// defualt to no client condition
			if (viewModel.hasClientCondition() === null){
				viewModel.hasClientCondition("false");
			}

			if(viewModel.allowEmailTemplates() === null){
				viewModel.allowEmailTemplates("false");
			}

			viewModel.repeatingPlaceholder = ko.observable();
			//repeating values need two extra functions for adding and removing from value
			viewModel.addValue = function() {
				//don't add anything if it already exists in value, make sure that
				//only whitespace is not entered, and ensure the value is properly
				//trimmed when added to the array
				if (_.indexOf(viewModel.folderTags(), viewModel.repeatingPlaceholder()) < 0 &&
						viewModel.repeatingPlaceholder() &&
						viewModel.repeatingPlaceholder().trim() !== "") {
					viewModel.folderTags.push(viewModel.repeatingPlaceholder().trim());
				}
				viewModel.repeatingPlaceholder("");
			};

			viewModel.removeValue = function(item) {
				viewModel.folderTags.remove(item);
			};
        },
        populatePotentialAttributes: function(){
			var self = this;
			this.viewModel.potentialAttributes.reset();
			
			if (this.viewModel.selectedDocumentType()){
				//Getting all potential attributes from the OTC
				app.context.configService.getAdminTypeConfig(this.viewModel.selectedDocumentType(), function(typeConfig){
					_.each(typeConfig.get("attrs").models, function(attr) {
						if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("attrsToDisplay"), 'attrValue')) === -1 ) {
							self.viewModel.potentialAttributes.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
						}
					});
				});
			}

        },
        createSubViews: function() {
			this.buildAttributeTossAcross();
			this.buildEnterKeyTossAcross();
			this.enableUploadAttachmentsActionConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "enableUploadAttachmentsAction",
				switchTitle: window.localize("customConfig.sendEmailConfig.uploadAttachmentsAction.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.uploadAttachmentsAction.info")
			});

			this.hideNoResultMessageConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "hideNoResultMessage",
				switchTitle: window.localize("customConfig.sendEmailConfig.hideNoResultMessage.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.hideNoResultMessage.info")
			});

			this.restrictInternalBasedOnAttachmentSizeConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnAttachmentSize",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictAttachmentSizeSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictAttachmentSizeSwitchDescription")
			});

			this.restrictInternalBasedOnFileExtensionConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnFileExtension",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictAttachmentExtensionSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictAttachmentExtensionSwitchDescription")
			});

			this.restrictInternalBasedOnEmailDomainConfigView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "restrictInternalBasedOnEmailDomain",
				switchTitle: window.localize("customConfig.sendEmailConfig.restrictEmailDomainSwitchTitle"),
				configDescription: window.localize("customConfig.sendEmailConfig.restrictEmailDomainSwitchDescription")
			});

			this.fetchAvailableFolderTypesDeferred.done(this.createSubjectPrefixView);
        },
        setAndRenderSubViews: function() {
			this.setViews({
				"#uploadActionSwitch": this.enableUploadAttachmentsActionConfigView,
				"#hideNoResultMessageSwitch": this.hideNoResultMessageConfigView,
				"#restrictInternalBasedOnAttachmentSizeSwitch" : this.restrictInternalBasedOnAttachmentSizeConfigView,
				"#restrictInternalBasedOnFileExtensionSwitch" : this.restrictInternalBasedOnFileExtensionConfigView,
				"#restrictInternalBasedOnEmailDomainSwitch" : this.restrictInternalBasedOnEmailDomainConfigView,
				'#subjectPrefixView': this.subjectPrefixView
			}).renderViews();
        },
        createSubjectPrefixView: function() {
			this.subjectPrefixView = new ACTPDFSendEmailCustomConfig.SubjectPrefixConfig({
				viewModel: this.viewModel,
				availableFolderTypes: this.availableFolderTypeConfigs
			});
        },
		updateInputProperty: function(event) {
			var currentTarget =  $(event.currentTarget);
			var key = currentTarget.attr("data-key");
			var value = currentTarget.val();

			// if the input is a number input we'll have to parse it
			if (currentTarget.attr('type') === 'number') {
				// for now, assuming this will always be an int
				value = parseInt(value, 10);
			}
			this.viewModel.model().set(key, value);
		},
		updateSliderProperty: function(event) {
			var modelProperty = $(event.target).attr("data-prop");
			var target = "input[id='" + $(event.target).attr("for") + "']";
			this.viewModel.model().set(modelProperty, $(target).val());
			// render will update whether the slider is checked
			// and display any dependent config fields
			this.render();
        },
        buildAttributeTossAcross: function(){
			this.populatePotentialAttributes();
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.potentialAttributes
				},
				targetCollections: [
					{
						title: 'Selected Attribute',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedAttributes
					}
				]
			});
			
			this.setView("#attributesTossAcross", tossAcross).render();
		},
		buildEnterKeyTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Keys',
					filter: true,
					labelAttr: 'attrName', 
					collection: this.viewModel.potentialEnterKeys
				}, 
				targetCollections: [
					{
						title: 'Selected Keys',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedEnterKeys
					}
				]
			});

			this.setView("#enterKeysTossAcross", tossAcross).render();
		},
		openTemplatesConfigModal: function(){
			this.templatesConfigLayout = new EmailTemplatesConfig.Layout();
			app.trigger('alert:custom', {
                view: this.templatesConfigLayout
            });
        },
        
        // Advanced Combine to PDF portion of configs
        setCurrentConfigSelection: function(){
            var self = this;
            //A deferred that waits for all object types to be fetched before resolving
            var fetchedAllObjectTypesDeferred = $.Deferred();
            //If currentSearchConfig isnt on the model then set it
            if(!this.model.get("currentSearchConfig")){
                this.model.set('currentSearchConfig',this.currentSearchConfig);
            }

            var deferreds = [];
            _.each(this.availableObjectTypes, function(objectType){
                var deferred = $.Deferred();
                deferreds.push(deferred.promise());
                app.context.configService.getAdminTypeConfig(objectType, function(typeConfig) {
                    self.viewModel.availableDocumentTypesInConfig.push({
                        "label": typeConfig.get("label"),
                        "value": typeConfig.get("ocName")
                    });
                    deferred.resolve();
                });
            });
            $.when(deferreds).done(function() {
                //If the selectedDocumentType isnt on the model then use the first one from the list
                if(!self.model.get("selectedDocumentType")){
                    self.model.set("selectedDocumentType", self.viewModel.availableDocumentTypesInConfig()[0].value);
                }
                fetchedAllObjectTypesDeferred.resolve();
            });
            return fetchedAllObjectTypesDeferred;
        },
        setCurrentConfigSelectionCallBack: function(){
            //Need to call the onSelectDocumnetType manually to pass in the true variable. This prevents us from removing the 
            //computed bookmark pattern
            this.onSelectDocumentType(this.model.get("selectedDocumentType"), true);
            this.setUpSubscribes();
            //Need to call updatePathViews to have the custom path elements appear
            this.updatePathViews(this.formSubscribePlaceholder);
            this.render();
        },
        setUpSubscribes: function(){
            this.viewModel.form.subscribe(_.bind(this.updatePathViews, this));
            this.viewModel.selectedObjectTypeWithoutPathConfig.subscribe(_.bind(this.onSelectObjectTypeForCustomPath, this));
            this.viewModel.selectedDocumentType.subscribe(_.bind(this.onSelectDocumentType, this));
        },
        onSelectDocumentType: function(selectedDocument, isInitializing){
            var self = this;
            if (!isInitializing){
                self.viewModel.computedBookmarkPattern(null);
            }
            if (selectedDocument) {
                //Getting all potential attributes from the OTC
                app.context.configService.getAdminTypeConfig(selectedDocument, function(typeConfig) {
                    self.viewModel.allAttributes([]);
                    _.each(typeConfig.get("attrs").models, function(attr) {
                        self.viewModel.allAttributes.push({
                            'label': attr.get("label"),
                            'value': attr.get("ocName")
                        });
                    });
                    self.model.set("selectedDocumentType", selectedDocument);
                });
            }
        },
        updateComputedBookmarkPattern: function() {
            var tempFullPattern;
            if (this.viewModel.computedBookmarkPattern() !== null) {
                tempFullPattern = this.viewModel.computedBookmarkPattern() + "$" + this.viewModel.selectedBookmarkAttribute() + "$";
            } else {
                tempFullPattern = "$" + this.viewModel.selectedBookmarkAttribute() + "$";
            }
            this.viewModel.computedBookmarkPattern(tempFullPattern);
        },
        updatePathViews: function(newFormName) {
            var self = this;
            if (newFormName) {
                app.context.configService.getFormConfig(newFormName, function(formConfig) {
                    self.viewModel.objectTypesWithoutPathConfig.removeAll();
                    formConfig.get("configuredTypes").each(function(type) {
                        self.viewModel.objectTypesWithoutPathConfig.push({ label: type.get('label'), value: type.get('ocName') });
                    });
                    self.viewModel.objectTypesWithoutPathConfig(_.sortBy(self.viewModel.objectTypesWithoutPathConfig(), 'label'));

                    self.viewModel.typePathViewModels.removeAll();
                    _.each(_.keys(self.viewModel.typePathServerData[newFormName]), function(typeKey) {
                        if (typeKey.indexOf("_id") === -1) {
                            // skip the limit types key and the _id key
                            self.viewModel.typePathViewModels.push(new ACTPDFSendEmailCustomConfig.TypePathViewModel({ 
                                objectType: typeKey,
                                path: self.viewModel.typePathServerData[newFormName][typeKey],
                                typePathServerData: self.viewModel.typePathServerData,
                                formName: newFormName,
                                model: self.model
                            }));
                            self.viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(self.viewModel.objectTypesWithoutPathConfig(), { "value": typeKey }));
                        }
                    });
                });
            }
        },
        onSelectObjectTypeForCustomPath: function(objectType){
            if (objectType) { // will be undefined if the caption is chosen
                this.viewModel.typePathViewModels.push(new ACTPDFSendEmailCustomConfig.TypePathViewModel({ 
                    objectType: objectType,
                    path: "",
                    typePathServerData: this.viewModel.typePathServerData,
                    formName: this.viewModel.form(),
                    model: this.model 
                }));
                this.viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(this.viewModel.objectTypesWithoutPathConfig(), { "value": objectType }));
            }
        },
        deleteTypePath: function(typePath) {
            this.viewModel.typePathViewModels.remove(typePath);
            if (this.viewModel.typePathServerData[this.viewModel.form()] && this.viewModel.typePathServerData[this.viewModel.form()][typePath.objectType]) {
                delete this.viewModel.typePathServerData[this.viewModel.form()][typePath.objectType];
            }
            this.viewModel.objectTypesWithoutPathConfig.push({
                "label": typePath.typeLabel,
                "value": typePath.objectType
            });
            this.viewModel.objectTypesWithoutPathConfig(_.sortBy(this.viewModel.objectTypesWithoutPathConfig(), 'label'));
        },
        toggleSubsection: function(e) {
                AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);

            this.enableLimitCombinedPdfSizeView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "enableLimitCombinedPdfSize",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.limitCombinedPdfSize"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.limitCombinedPdfSize.info")
            });

            this.showIndexPageCheckboxView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "showIndexPageCheckbox",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.showCheckbox.header"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.showCheckbox.info")
            });

            this.defaultValueForShowIndexPageCheckboxView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "defaultValueForShowIndexPageCheckbox",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.checkboxDefaultValue.header"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.checkboxDefaultValue.info")
            });

            //send email views
            this.createSubViews();
            this.fetchAvailableFolderTypesDeferred.done(this.setAndRenderSubViews);

            this.setViews({
                "#enableLimitCombinedPdfSize": this.enableLimitCombinedPdfSizeView,
                "#showIndexPageCheckbox": this.showIndexPageCheckboxView,
                "#defaultValueForShowIndexPageCheckbox": this.defaultValueForShowIndexPageCheckboxView
            }).renderViews();
        },

        serialize: function() {
			return {
				enableBCCControl: this.viewModel.model().get('enableBCCControl') === "true",
				hasMaxBodyLength: this.viewModel.model().get('hasMaxBodyLength') === "true",
				maxBodyCharacters: this.viewModel.model().get('maxBodyCharacters'),
				collectionActionConfig: this.collectionActionConfig,
				dependentCloudSend: this.viewModel.model().get('cloudSendMode') === "dependent",
				restrictInternalBasedOnAttachmentSize: this.viewModel.model().get('restrictInternalBasedOnAttachmentSize'),
				restrictInternalBasedOnFileExtension: this.viewModel.model().get('restrictInternalBasedOnFileExtension'), 
				restrictInternalBasedOnEmailDomain: this.viewModel.model().get('restrictInternalBasedOnEmailDomain')
			};
		}
    });

    // this represents a view model for a path configuration for an object type
    ACTPDFSendEmailCustomConfig.TypePathViewModel = function(options) {
        var self = this;

        self.model = options.model;
        // the value of the objectType
        self.objectType = options.objectType;

        // the server data with trac configurations
        self.typePathServerData = options.typePathServerData;

        self.typeLabel = ko.observable("");
        app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
            self.typeLabel(typeLabel);
        });

        // the path that is displayed on the admin screen
        self.computedPath = ko.observable("");
        if (options.path) { // the path will be set if we get data back from the server
            self.computedPath(options.path);
        }

        // every time the observable's value changes, update that object type's path in the server data map
        self.computedPath.subscribe(function(newValue) {
            if (!self.typePathServerData[options.formName]) {
                self.typePathServerData[options.formName] = {};
            }
            self.typePathServerData[options.formName][self.objectType] = newValue;
            self.model.set("customTypePaths", self.typePathServerData);
        });
    };

    ACTPDFSendEmailCustomConfig.SubjectPrefixPatternConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendemail/sendemailsubjectprefixpatternconfig",
		events: {
			"click #addToPatternBtn": "addPropertyToPattern",
			"change #folderTypeAttrs": "updatedSelectedFolderAttr",
			"change #subjectPrefixPattern": "updateSubjectPrefixPattern",
			"click #save-subject-prefix-btn": "updateModelWithPrefix"
		},

		initialize: function(options) {
			this.selectedFolderType = options.selectedFolderType;
			this.selectedFolderTypeName = this.selectedFolderType.get('ocName');
			this.viewModel = options.viewModel;
			this.existingSubjectPrefixes = options.configuredSubjectPrefixes;
			this.subjectPrefixConfigModel = this.existingSubjectPrefixes.get(this.selectedFolderTypeName);
			if(this.subjectPrefixConfigModel) {
				// when we open the subject prefix modal, this may not be an object on legacy configs
				if(!(this.subjectPrefixConfigModel instanceof Backbone.Model)) {
					this.subjectPrefixConfigModel = new Backbone.Model(this.subjectPrefixConfigModel);
				}
			} else {
				this.subjectPrefixConfigModel = new Backbone.Model({
					isSubjectPrefixEditable: true,
					pattern: ""
				});
			}
			
			this.isSubjectEditable = this.subjectPrefixConfigModel.get('isSubjectPrefixEditable');
			this.subjectPrefixPattern = this.subjectPrefixConfigModel.get("pattern");
			if(this.selectedFolderType.get('attrs')) {
				var firstAttr = this.selectedFolderType.get('attrs').first();
				if(firstAttr) {
					this.selectedFolderAttr = firstAttr.get('ocName');
				}
			}
		},

		updatedSelectedFolderAttr: function(event) {
			this.selectedFolderAttr = $(event.target).val();
		},

		updateSubjectPrefixPattern: function(event) {
			this.subjectPrefixPattern = $(event.target).val();
		},

		addPropertyToPattern: function() {
			if(this.selectedFolderAttr) {
				var attrStr = "$" + this.selectedFolderAttr + "$";
				this.subjectPrefixPattern = this.subjectPrefixPattern + attrStr;
				this.$("#subjectPrefixPattern").val(this.subjectPrefixPattern);
				this.$("#subjectPrefixPattern").focus();
			}
		},

		updateModelWithPrefix: function() {
			this.subjectPrefixConfigModel.set("pattern", this.subjectPrefixPattern);
			this.existingSubjectPrefixes.set(this.selectedFolderTypeName, this.subjectPrefixConfigModel.toJSON());
			this.viewModel.model().set('subjectPrefixes', this.existingSubjectPrefixes);
		},

		createAndSetSubViews: function() {
			this.isSubjectPrefixEditableConfigView = new iOSSwitch.View({
				model: this.subjectPrefixConfigModel,
				configModelKey: "isSubjectPrefixEditable",
				switchTitle: window.localize("customConfig.sendEmailConfig.isSubjectPrefixEditable.title"),
				configDescription: window.localize("customConfig.sendEmailConfig.isSubjectPrefixEditable.info")
			});

			this.setView("#isSubjectPrefixEditableSwitch", this.isSubjectPrefixEditableConfigView);
		},

		beforeRender: function() {
			this.createAndSetSubViews();
		},

		serialize: function() {
			return {
				folderTypeProps: this.selectedFolderType.get('attrs').toJSON(),
				subjectPrefixPattern: this.subjectPrefixPattern
			};
		}
	});

	ACTPDFSendEmailCustomConfig.SubjectPrefixConfig = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendemail/sendemailsubjectprefixconfig",
		events: {
			"click .addSendEmailSubjectPrefix": "launchSubjectPrefixModal",
			"click .addSubjectPrefix": "selectFolderType",
			"click .removeSendEmailSubjectPrefix": "removeSubjectPrefix"
		},
		initialize: function(options) {
			this.viewModel = options.viewModel;
			this.availableFolderTypes = options.availableFolderTypes;
			this.configuredSubjectPrefixes = this.viewModel.model().get('subjectPrefixes');
			if(this.configuredSubjectPrefixes) {
				//if we're coming into this action view for the first time, configuredSubjectPrefixes will just be an object
				if(!(this.configuredSubjectPrefixes instanceof Backbone.Model)) {
					this.configuredSubjectPrefixes = new Backbone.Model(this.configuredSubjectPrefixes);
				} 
				var configuredOcNames = this.configuredSubjectPrefixes.keys();
				this.selectedFolderTypes = new Backbone.Collection(this.availableFolderTypes.filter(function(folderType) {
					return _.contains(configuredOcNames, folderType.get('ocName'));
				}));

				// remove all the configured folder types from available folder types
				this.availableFolderTypes = new Backbone.Collection(this.availableFolderTypes.reject(function(folderType) {
					return _.contains(configuredOcNames, folderType.get('ocName'));
				}));
			} else {
				this.selectedFolderTypes = new Backbone.Collection();
				this.configuredSubjectPrefixes = new Backbone.Model();
				this.viewModel.model().set('subjectPrefixes', this.configuredSubjectPrefixes);
			}
			this.selectedFolderTypes.comparator = "label";
			this.availableFolderTypes.comparator = "label";
		},
		launchSubjectPrefixModal: function(event) {
			var selectedFolderType = $(event.target).attr("data-value");
			this.subjectPrefixPatternConfigView = new ACTPDFSendEmailCustomConfig.SubjectPrefixPatternConfigView({
				selectedFolderType: this.selectedFolderTypes.findWhere({ocName: selectedFolderType}),
				viewModel: this.viewModel,
				configuredSubjectPrefixes: this.configuredSubjectPrefixes
			});
			app.trigger('alert:custom', {
                view: this.subjectPrefixPatternConfigView
			});
		},
		removeSubjectPrefix: function() {
			var ocName = $(event.target).attr("data-value");
			var selectedFolderType = this.selectedFolderTypes.findWhere({ocName: ocName});
			this.availableFolderTypes.add(selectedFolderType);
			this.selectedFolderTypes.remove(selectedFolderType);
			if(this.configuredSubjectPrefixes) {
				this.configuredSubjectPrefixes.unset(ocName);
				this.viewModel.model().set('subjectPrefixes', this.configuredSubjectPrefixes);
			}
			this.render();
		},
		selectFolderType: function(event) {
			var ocName = $(event.target).val();
			var selectedFolderType = this.availableFolderTypes.findWhere({ocName: ocName});
			this.availableFolderTypes.remove(selectedFolderType);
			this.selectedFolderTypes.add(selectedFolderType);
			this.render();
		},
		serialize: function() {
			return {
				availableFolderTypes: this.availableFolderTypes.toJSON(),
				selectedFolderTypes: this.selectedFolderTypes.toJSON(),
				showSelectedFolderTypes: this.selectedFolderTypes && this.selectedFolderTypes.length > 0
			};
		}
	});

    return ACTPDFSendEmailCustomConfig;
});