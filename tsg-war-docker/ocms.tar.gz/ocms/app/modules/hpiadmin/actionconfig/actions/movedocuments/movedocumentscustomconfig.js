define([
	"app",
	"modules/hpiadmin/adminUtil",
	"modules/common/tossacross",
	"modules/hpiadmin/common/iosswitch"

], function(app, AdminUtil, TossAcross, IOSSwitch) {
	"use strict";

    var MoveDocumentsCustomConfigView = {};

	MoveDocumentsCustomConfigView.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/movedocuments/movedocumentsconfig",
		events: {
			"click .admin_ui_subsectionToggle": "toggleSubsection"
		},
		toggleSubsection: function(e) {
			AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
		},
		initialize: function(options){
			// cache a reference to the viewModel and model to reference on the view
			this.viewModel = options.viewModel;
			this.model = this.viewModel.model();
			// For purposes of keeping timing correctly
			this.initializeDefArr = [];

			// Establish observables used throughout this config
			this.initializeModelVars();

			// Initialize options that concern the main folder type, such as the attribute to query on, and the columns to be
			// displayed in the results table
			this.initializeDefArr.push(this.initializeFolderTypeSelection());

			if(this.viewModel.selectedFolderType()){
				this.initializeFolderAttributeSelections();
			}
		},
		initializeModelVars: function(){
			// Variables concerning the folder type that governs the query for the action
			this.viewModel.availableFolderTypes = ko.observableArray([]);
			this.viewModel.selectedFolderType = kb.observable(this.model, 'selectedFolderType');
			this.viewModel.selectedFolderType.subscribe(this._folderTypeChanged, this);

			// Attribute to query on in the action
			this.viewModel.potentialAttrsToSearchOn = ko.observableArray([]);
			this.viewModel.attrToSearchOn = kb.observable(this.model, 'attrToSearchOn'); // will save ocName and label here

			// Variable to determine if object type should be shown or hidden in the results table
			this.viewModel.showfolderPath = ko.observable(this.model, 'displayFolderPath');

			// Holds the selected attribute models used to display columns on the table
			if(!this.model.get('tableDisplayAttrs')){
				this.model.set('tableDisplayAttrs', new Backbone.Collection());
			} 
			// it could be a simpley array that we need to turn into a collection
			else if(!(this.model.get('tableDisplayAttrs') instanceof Backbone.Collection)){
				this.model.set('tableDisplayAttrs', new Backbone.Collection(this.model.get('tableDisplayAttrs')));
			}
		},
		initializeFolderTypeSelection: function(){
			var self = this;
			var otcDeff = $.Deferred();

			app.context.configService.getAdminOTC(function(otc){
				// Find all folders for the admin to choose a type
				_.each(otc.get('configs').where({isContainer: 'true'}), function(type){
					self.viewModel.availableFolderTypes.push(type.attributes);	
				});
				otcDeff.resolve();
			});
			return otcDeff;
		},
		initializeFolderAttributeSelections: function(){
			this.initializeDefArr.push(this._populateSelectedTypeAttrs());
		},
		_folderTypeChanged: function(){
			// Reset variables of interest here.
			this.viewModel.attrToSearchOn('');
			this.model.set('attrToSearchOn', '');
			this.model.get('tableDisplayAttrs').reset();

			this._populateSelectedTypeAttrs().done(this.setupTossAcross);
		},
		_populateSelectedTypeAttrs: function(){
			var self = this;
			var folderAttrsDef = $.Deferred();

			app.context.configService.getTypeAttrs(this.viewModel.selectedFolderType(), function(attrs){
				var sorted = _.sortBy(attrs, 'label'); //should sort on Label values
				self.viewModel.potentialAttrsToSearchOn(sorted);
				folderAttrsDef.resolveWith(self);
			});
			return folderAttrsDef;
		},
		createSubViews: function(){
			this.setupTossAcross();
			this.setupDisplayFolderPathSwitch();
		},
		setupTossAcross: function(){
			this.tossAcross = new TossAcross.Layout({
				clickAcross: true,
				enableAddRemove: false,
				srcCollection: {
					title: window.localize("modules.common.tossAcross.availableAttributes"),
					filter: true,
					labelAttr: 'label',
					collection: new Backbone.Collection(this.viewModel.potentialAttrsToSearchOn())
				},
				targetCollections: [
					{
						title: window.localize("modules.common.tossAcross.selectedAttributes"),
						labelAttr: 'label',
						filter: true,
						collection: this.model.get('tableDisplayAttrs')
					}
				]
			});

			this.setView('#moveDocs-tossAcross', this.tossAcross).render();
		},
		setupDisplayFolderPathSwitch: function(){
			this.displayFolderPathSwitchView = new IOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: 'displayFolderPath',
				switchTitle: window.localize('customConfig.moveDocuments.displayFolderPathTitle'),
				configDescription: window.localize('customConfig.moveDocuments.displayFolderPathDesc')
			});

			this.setView('#moveDocs-showFldrPath-ioswitch', this.displayFolderPathSwitchView).render();
		},
		afterRender: function(){
			var self = this;

			$.when.apply($, this.initializeDefArr).then(function(){
				self.createSubViews();
				kb.applyBindings(self.viewModel, self.$el[0]);
			});
		}
	});
    
    return MoveDocumentsCustomConfigView;
});