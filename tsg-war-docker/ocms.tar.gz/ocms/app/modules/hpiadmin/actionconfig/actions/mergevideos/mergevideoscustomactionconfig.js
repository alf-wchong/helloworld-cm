define([
    "app",
    "modules/common/hpiconstants",
    "advancedcombinetopdf",
    "modules/common/tossacross"


], function(app, HPIConstants, AdvancedCombineToPDF, TossAcross) {
    "use strict";

     var MergeVideosCustomConfigView = {};

     MergeVideosCustomConfigView.View = AdvancedCombineToPDF.CustomConfigView.extend({
        template: "hpiadmin/actions/customconfig/mergevideosconfig",
        initialize: function () {
            var self = this;
            MergeVideosCustomConfigView.View.__super__.initialize.apply(this, arguments);
            this.viewModel.potentialFileTypes = new Backbone.Collection();
            this.viewModel.selectedFileTypes = new Backbone.Collection();
            this.buildFileTypesCollections();
            this.buildFileTypesTossAcross();
            this.stopListening(this.viewModel.selectedFileTypes, 'add remove reset');
            this.listenTo(this.viewModel.selectedFileTypes, 'add remove reset', function(){
                var newSelectedFileTypes = []; 
                _.each(this.viewModel.selectedFileTypes.models, function(model){
                    newSelectedFileTypes.push(model.get('attrValue'));
                });
                self.viewModel.model().set("selectedFileTypes", newSelectedFileTypes);
            });
        },
        buildFileTypesCollections: function(){
            var oldSelectedFileTypes = this.viewModel.model().get('selectedFileTypes') ?  this.viewModel.model().get('selectedFileTypes') : ['mp4'];
            _.each(HPIConstants.MimeTypeMapping, _.bind(function(fileType, mimeType) {
                if (oldSelectedFileTypes.indexOf(mimeType) > -1) {
                    this.viewModel.selectedFileTypes.push({
                        'attrName': fileType,
                        'attrValue': mimeType
                    });
                } else {
                    this.viewModel.potentialFileTypes.push({
                        'attrName': fileType,
                        'attrValue': mimeType
                    });
                }
            }, this));
        },
        buildFileTypesTossAcross: function() {
            var tossAcross = new TossAcross.Layout({
                clickAcross: true,
                enableAddRemove: false,
                srcCollection: {
                    title: 'Available File Types',
                    filter: true,
                    labelAttr: 'attrName', 
                    collection: this.viewModel.potentialFileTypes
                }, 
                targetCollections: [{
                    title: 'Selected File Types',
                    labelAttr: 'attrName',
                    collection: this.viewModel.selectedFileTypes
                }]
            });

            this.setView("#allowedFileTypesTossAcross", tossAcross).render();
        },
        afterRender: function(){
            this.buildFileTypesTossAcross();
            MergeVideosCustomConfigView.View.__super__.afterRender.apply(this, arguments);
        }
    });

    return MergeVideosCustomConfigView;
});