define([
    "app",
    "modules/hpiadmin/common/iosswitch",
    "modules/common/hpiconstants",
    'modules/hpiadmin/adminUtil'
], function(app, iOSSwitch, HPIConstants, AdminUtil) {
    "use strict";

     var AdvancedCombineToPdfCustomConfigView = {};

     AdvancedCombineToPdfCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/advancedcombinetopdfconfig",
        events: {
            "click #computedBookmarkAttr-button": "updateComputedBookmarkPattern",
            "click .admin_ui_subsectionToggle" : "toggleSubsection",
        },
        initialize: function() {
            //Creates drag and drop for the user to select the attributes to configure for this action.
            this.viewModel = this.options.viewModel;
            this.model = this.viewModel.model();

            //Grab the search config and available document types off of the options
            //The trac option is the same as the search config name. When configuring search configs they arent associated with a trac
            //this is just a poorly named variable. This variable should be updated at some point
            this.currentSearchConfig = this.options.trac;
            this.availableObjectTypes = this.options.availableObjectTypes;

            //The title of the index page for the generated combined PDF. If not set then default the value to "Generated Combined PDF Index"
            this.viewModel.indexTitle = kb.observable(this.model, "indexTitle");
            if (!this.viewModel.indexTitle()) {
                this.viewModel.indexTitle("Generated Combined PDF Index");
            }

            //The poll timeout for the progress bar. If not set, default to 1000 ms (1 second)
            this.viewModel.progressBarPollTimeout = kb.observable(this.model, "progressBarPollTimeout");
            if (!this.viewModel.progressBarPollTimeout()) {
                this.viewModel.progressBarPollTimeout("1000");
            }


            //The available document types in the currentSearchConfig
            this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
            //The selected document type from the drop down containing the availableDocumentTypesInConfig array
            this.viewModel.selectedDocumentType = kb.observable(this.model ,"selectedDocumentType");
            //All attributes in the selectedDocumentType
            this.viewModel.allAttributes = ko.observableArray([]);
            //The selected attribute from the allAttributes drop down (AKA: The attribute to add to the bookmark Pattern)
            this.viewModel.selectedBookmarkAttribute = ko.observable(this.model, "selectedBookmarkAttribute");
            //The computed bookmark value to display in the bookmark Column
            this.viewModel.computedBookmarkPattern = kb.observable(this.model, "computedBookmarkPattern");

            // show default name. If not set the default the value to true
            this.viewModel.showDefaultName = kb.observable(this.model, "showDefaultName");
            if (!this.viewModel.showDefaultName()) {
                this.viewModel.showDefaultName("true");
            }

            //show bookmark column. If not set then default the value to false
            this.viewModel.showBookmarkColumn = kb.observable(this.model,"showBookmarkColumn");
            if (!this.viewModel.showBookmarkColumn()) {
                this.viewModel.showBookmarkColumn("false");
            }

            //Allow Renditionable documents to be combined. If not set then default the value to false;
            this.viewModel.allowRenditionable = kb.observable(this.model, 'allowRenditionable');
            if (!this.viewModel.allowRenditionable()) {
                this.viewModel.allowRenditionable('false');
            }

            //Should the user be able to combine documents with their annotations? If not set then default the value to false
            this.viewModel.exportWithAnnotationsToAttachments = kb.observable(this.model, "exportWithAnnotationsToAttachments");
            if (!this.viewModel.exportWithAnnotationsToAttachments()) {
                this.viewModel.exportWithAnnotationsToAttachments("false");
            }

            //Allow the user to choose which pages in a document to combined. If not set then default the value to false
            this.viewModel.enableSelectedPages = kb.observable(this.model, "enableSelectedPages");
            if (!this.viewModel.enableSelectedPages()) {
                this.viewModel.enableSelectedPages("false");
            }

            // PDF size limit
            this.viewModel.limitCombinedPdfSize = kb.observable(this.model, 'limitCombinedPdfSize');
            if (!this.viewModel.limitCombinedPdfSize()) {
                this.viewModel.limitCombinedPdfSize(5);
            }

            //When combinding a document, should a folder note be created? If not set then default the value false 
            this.viewModel.folderNotes = kb.observable(this.model, "folderNotes");
            if (!this.viewModel.folderNotes()) {
                this.viewModel.folderNotes("false");
            }

            //The Folder Note Object Type. If not set then default the value to "HPI NOTE"
            this.viewModel.folderNoteObjectType = kb.observable(this.model, "folderNoteObjectType");
            if (!this.viewModel.folderNoteObjectType()) {
                this.viewModel.folderNoteObjectType("HPI Note");
            }

            // The note type to apply to all folder notes. If not set then default the value to "Audit Trail"
            this.viewModel.folderNoteType = kb.observable(this.model, "folderNoteType");
            if (!this.viewModel.folderNoteType()) {
                this.viewModel.folderNoteType("Audit Trail");
            }

            //Selected folder note relationship from admin. By default will be set to the localization of generic.action.customConfig.hpiFolderNoteAlf
            this.viewModel.folderNoteRelationship = kb.observable(this.model, "folderNoteRelationship");

            //Should this document be downloaded or saved to the repo? If not set then default the value to false
            this.viewModel.saveToRepo = kb.observable(this.model, "saveToRepo");
            if (!this.viewModel.saveToRepo()) {
                this.viewModel.saveToRepo("false");
            }

            //Should the uploaded document inherit the properties from the folder it is in? If not set then default the value to false
            this.viewModel.inheritFolderAttributes = kb.observable(this.model, "inheritFolderAttributes");
            if (!this.viewModel.inheritFolderAttributes()) {
                this.viewModel.inheritFolderAttributes('false');
            }

            this.viewModel.asyncDownloadEnabled = kb.observable(this.model,"asyncDownloadEnabled");
            // default to false
            if (!this.viewModel.asyncDownloadEnabled()) {
                this.viewModel.asyncDownloadEnabled("false");
            }

            this.viewModel.potentialForms = ko.observableArray();
            this.viewModel.form = kb.observable(this.model, "form");
            //Sotring the current form value to then set once all potential forms are retrieved 
            this.formSubscribePlaceholder = this.viewModel.form();

            var self = this;
            app.context.configService.getFormConfigNames(function(formConfigNames) {
                self.viewModel.potentialForms(formConfigNames);
                self.viewModel.form(self.formSubscribePlaceholder);
                //since the form value is bound from the potentialForms observable,
                //this context call will come back after the form has been gathered
                //from the config. this resets the form to the right value.
            });

            //If enabled, allows the admin to define a custom path to upload a combined document to. If not set
            //default the value to false
            this.viewModel.contextLessUpload = kb.observable(this.model, "contextLessUpload");
            if (!this.viewModel.contextLessUpload()) {
                this.viewModel.contextLessUpload('false');
            }

            // If enabled, allows the user to select the version of documents to include in the combined pdf
            // default the value to false
            this.viewModel.showSelectVersionColumn = kb.observable(this.model, "showSelectVersionColumn");
            if (!this.viewModel.showSelectVersionColumn()) {
                this.viewModel.showSelectVersionColumn("false");
            }

            //A default path to upload documents to if contextLessUpload is true. This default value will be used if an object type
            //we are trying to upload does not have a custom path. Its default value is nothing
            this.viewModel.containerPath = kb.observable(this.model, "containerPath");

            //This observable will contain all available document types that do not have custom path defined for them
            this.viewModel.objectTypesWithoutPathConfig = ko.observableArray([]);
            //The value chosen from the objectTypesWithoutPathConfig drop down
            this.viewModel.selectedObjectTypeWithoutPathConfig = ko.observable();
            // An array of AdvancedCombineToPDF.TypePathViewModel that indicate a objectType to custom path relationship
            this.viewModel.typePathViewModels = ko.observableArray([]);
            //An object indicating the objectType to custom path relationship. Gets populated by the typePathViewModels
            this.viewModel.typePathServerData = this.model.get("customTypePaths") ? this.model.get("customTypePaths") : {};

            // this allows a user to delete a path configuration for a selected object type. Need to bind it so it
            //keeps context
            this.viewModel.deleteTypePath = _.bind(this.deleteTypePath,this);

            $.when(this.setCurrentConfigSelection()).done(_.bind(this.setCurrentConfigSelectionCallBack, this));
        },
        setCurrentConfigSelection: function(){
            var self = this;
            //A deferred that waits for all object types to be fetched before resolving
            var fetchedAllObjectTypesDeferred = $.Deferred();
            //If currentSearchConfig isnt on the model then set it
            if(!this.model.get("currentSearchConfig")){
                this.model.set('currentSearchConfig',this.currentSearchConfig);
            }

            var deferreds = [];
            _.each(this.availableObjectTypes, function(objectType){
                var deferred = $.Deferred();
                deferreds.push(deferred.promise());
                app.context.configService.getAdminTypeConfig(objectType, function(typeConfig) {
                    self.viewModel.availableDocumentTypesInConfig.push({
                        "label": typeConfig.get("label"),
                        "value": typeConfig.get("ocName")
                    });
                    deferred.resolve();
                });
            });
            $.when(deferreds).done(function() {
                //If the selectedDocumentType isnt on the model then use the first one from the list
                if(!self.model.get("selectedDocumentType")){
                    self.model.set("selectedDocumentType", self.viewModel.availableDocumentTypesInConfig()[0].value);
                }
                fetchedAllObjectTypesDeferred.resolve();
            });
            return fetchedAllObjectTypesDeferred;
        },
        setCurrentConfigSelectionCallBack: function(){
            //Need to call the onSelectDocumnetType manually to pass in the true variable. This prevents us from removing the 
            //computed bookmark pattern
            this.onSelectDocumentType(this.model.get("selectedDocumentType"), true);
            this.setUpSubscribes();
            //Need to call updatePathViews to have the custom path elements appear
            this.updatePathViews(this.formSubscribePlaceholder);
            this.render();
        },
        setUpSubscribes: function(){
            this.viewModel.form.subscribe(_.bind(this.updatePathViews, this));
            this.viewModel.selectedObjectTypeWithoutPathConfig.subscribe(_.bind(this.onSelectObjectTypeForCustomPath, this));
            this.viewModel.selectedDocumentType.subscribe(_.bind(this.onSelectDocumentType, this));
        },
        onSelectDocumentType: function(selectedDocument, isInitializing){
            var self = this;
            if (!isInitializing){
                self.viewModel.computedBookmarkPattern(null);
            }
            if (selectedDocument) {
                //Getting all potential attributes from the OTC
                app.context.configService.getAdminTypeConfig(selectedDocument, function(typeConfig) {
                    self.viewModel.allAttributes([]);
                    _.each(typeConfig.get("attrs").models, function(attr) {
                        self.viewModel.allAttributes.push({
                            'label': attr.get("label"),
                            'value': attr.get("ocName")
                        });
                    });
                    self.model.set("selectedDocumentType", selectedDocument);
                });
            }
        },
        updateComputedBookmarkPattern: function() {
            var tempFullPattern;
            if (this.viewModel.computedBookmarkPattern() !== null) {
                tempFullPattern = this.viewModel.computedBookmarkPattern() + "$" + this.viewModel.selectedBookmarkAttribute() + "$";
            } else {
                tempFullPattern = "$" + this.viewModel.selectedBookmarkAttribute() + "$";
            }
            this.viewModel.computedBookmarkPattern(tempFullPattern);
        },
        updatePathViews: function(newFormName) {
            var self = this;
            if (newFormName) {
                app.context.configService.getFormConfig(newFormName, function(formConfig) {
                    self.viewModel.objectTypesWithoutPathConfig.removeAll();
                    formConfig.get("configuredTypes").each(function(type) {
                        self.viewModel.objectTypesWithoutPathConfig.push({ label: type.get('label'), value: type.get('ocName') });
                    });
                    self.viewModel.objectTypesWithoutPathConfig(_.sortBy(self.viewModel.objectTypesWithoutPathConfig(), 'label'));

                    self.viewModel.typePathViewModels.removeAll();
                    _.each(_.keys(self.viewModel.typePathServerData[newFormName]), function(typeKey) {
                        if (typeKey.indexOf("_id") === -1) {
                            // skip the limit types key and the _id key
                            self.viewModel.typePathViewModels.push(new AdvancedCombineToPdfCustomConfigView.TypePathViewModel({ 
                                objectType: typeKey,
                                path: self.viewModel.typePathServerData[newFormName][typeKey],
                                typePathServerData: self.viewModel.typePathServerData,
                                formName: newFormName,
                                model: self.model
                            }));
                            self.viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(self.viewModel.objectTypesWithoutPathConfig(), { "value": typeKey }));
                        }
                    });
                });
            }
        },
        onSelectObjectTypeForCustomPath: function(objectType){
            if (objectType) { // will be undefined if the caption is chosen
                this.viewModel.typePathViewModels.push(new AdvancedCombineToPdfCustomConfigView.TypePathViewModel({ 
                    objectType: objectType,
                    path: "",
                    typePathServerData: this.viewModel.typePathServerData,
                    formName: this.viewModel.form(),
                    model: this.model 
                }));
                this.viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(this.viewModel.objectTypesWithoutPathConfig(), { "value": objectType }));
            }
        },
        deleteTypePath: function(typePath) {
            this.viewModel.typePathViewModels.remove(typePath);
            if (this.viewModel.typePathServerData[this.viewModel.form()] && this.viewModel.typePathServerData[this.viewModel.form()][typePath.objectType]) {
                delete this.viewModel.typePathServerData[this.viewModel.form()][typePath.objectType];
            }
            this.viewModel.objectTypesWithoutPathConfig.push({
                "label": typePath.typeLabel,
                "value": typePath.objectType
            });
            this.viewModel.objectTypesWithoutPathConfig(_.sortBy(this.viewModel.objectTypesWithoutPathConfig(), 'label'));
        },
        toggleSubsection: function(e) {
                AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);

            this.enableLimitCombinedPdfSizeView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "enableLimitCombinedPdfSize",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.limitCombinedPdfSize"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.limitCombinedPdfSize.info")
            });

            this.showIndexPageCheckboxView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "showIndexPageCheckbox",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.showCheckbox.header"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.showCheckbox.info")
            });

            this.defaultValueForShowIndexPageCheckboxView = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "defaultValueForShowIndexPageCheckbox",
                switchTitle: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.checkboxDefaultValue.header"),
                configDescription: window.localize("customConfig.advancedCombineToPdfConfig.indexPage.checkboxDefaultValue.info")
            });

            this.setViews({
                "#enableLimitCombinedPdfSize": this.enableLimitCombinedPdfSizeView,
                "#showIndexPageCheckbox": this.showIndexPageCheckboxView,
                "#defaultValueForShowIndexPageCheckbox": this.defaultValueForShowIndexPageCheckboxView
            }).renderViews();
        }
    });

    // this represents a view model for a path configuration for an object type
    AdvancedCombineToPdfCustomConfigView.TypePathViewModel = function(options) {
        var self = this;

        self.model = options.model;
        // the value of the objectType
        self.objectType = options.objectType;

        // the server data with trac configurations
        self.typePathServerData = options.typePathServerData;

        self.typeLabel = ko.observable("");
        app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
            self.typeLabel(typeLabel);
        });

        // the path that is displayed on the admin screen
        self.computedPath = ko.observable("");
        if (options.path) { // the path will be set if we get data back from the server
            self.computedPath(options.path);
        }

        // every time the observable's value changes, update that object type's path in the server data map
        self.computedPath.subscribe(function(newValue) {
            if (!self.typePathServerData[options.formName]) {
                self.typePathServerData[options.formName] = {};
            }
            self.typePathServerData[options.formName][self.objectType] = newValue;
            self.model.set("customTypePaths", self.typePathServerData);
        });
    };

    return AdvancedCombineToPdfCustomConfigView;
});