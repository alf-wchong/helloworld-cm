define([
    "app",
    "modules/common/tossacross",
    "modules/hpiadmin/common/iosswitch"
    
], function(app, TossAcross, iOSSwitch) {
	"use strict";
    var GenerateWorkflowReportConfig = {};

	GenerateWorkflowReportConfig.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/generateworkflowreportconfig",
		events:{
			'change #reportFileNamePrefix' : 'getFileNamePrefix',
			'change #assigneeTypeaheadDropdownLimit' : 'getAssigneeDropdownLimit',
			'change .documentTypeInputGroup': 'documentTypeSelected',
			'click .addTypeahead': 'populateTypeaheadFilterForm'
		},
		initialize: function(){
			this.viewModel = this.options.viewModel;
			this.model = this.viewModel.model();
			this.viewModel.availableNameAttributes = new Backbone.Collection();
			this.viewModel.selectedNameAttributes = new Backbone.Collection();
			this.viewModel.availableDocumentTypesInConfig = new Backbone.Collection();
			this.setupListeners();

			this.deferredArray = [];
			this.getAdminTypeDeferred = $.Deferred();
			this.otcDeferred = $.Deferred();
			this.deferredArray.push(this.otcDeferred);
			this.deferredArray.push(this.getAdminTypeDeferred);

			// build the switch to pick email or download
            this.emailReportEnabled = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "emailReportEnabled",
                switchTitle: window.localize("customConfig.generateworkflowreport.download.email.title"),
                configDescription: window.localize("customConfig.generateworkflowreport.download.email.description"),
                onLabel: window.localize("customConfig.generateworkflowreport.download.email.switch.email.label"),
                trueVal: true,
                offLabel: window.localize("customConfig.generateworkflowreport.download.email.switch.download.label"),
                defaultSwitchValue: false,
                falseVal: false,
                customClass: "switch-200w"
            });

            // set email switch view
            this.setViews({
                "#emailReportEnabled": this.emailReportEnabled
            });

            // populate the selected document types attributes into the available name attributes collection
			app.context.configService.getAdminOTC(_.bind(this.buildUpAttributesFromAdminOTC, this));

			// populate the user attributes into the available name attributes collection
			this.populateUserPropsIntoPicklist();

			// populate the activiti attributes into the available name attributes collection
			this.populateActivitiPropsIntoPicklist();

			// check to see if there are any previously saved attributes and load then into collection
			this.loadPreviouslySavedAttributes();
			
		},
		buildUpAttributesFromAdminOTC: function(config){
			var self = this;
			config.get("configs").each(function (typeConfig) {
                if (typeConfig.get("isContainer") === "false") {
                    self.viewModel.availableDocumentTypesInConfig.push({
                        "label": typeConfig.get("label"),
                        "value": typeConfig.get("ocName")
					});
                }
			});

			// If failed to get configs just display empty dropdown, however this should never happen
			if (this.viewModel.availableDocumentTypesInConfig.models.length > 0){
				this.selectedDocumentType = this.viewModel.availableDocumentTypesInConfig.models[0].attributes.value;
				if (this.model.get("selectedDocumentType")){
					this.selectedDocumentType = this.model.get("selectedDocumentType");
				}
				app.context.configService.getAdminTypeConfig(this.selectedDocumentType, _.bind(this.populateDocPropsIntoPicklist, this));
			}

			this.otcDeferred.resolve();
		},
		populateActivitiPropsIntoPicklist: function(){
			// build up what activiti attributes are allowed that the user can pick from in the picklist
			var activitiAttributes = {
				"assignee": "Task Assignee",
				"startTime": "Task Start Time",
				"endTime": "Task End Time",
				"owner": "Task Owner",
				"processInstanceId": "Task Process Instance Id",
				"taskName": "Task Name",
				"taskduedate": "Task Due Date",
				"description": "Task Description",
				"executionId": "Task Execution Id",
				"category": "Task Category",
				"taskDefinitionKey": "Task Definition Key"

			};

			_.each(_.keys(activitiAttributes), function(attr) {
				var existingProps = _.pluck(this.model.get("nameAttrsToDisplay"), 'attrValue');
				if (!_.contains(existingProps, "activiti-" + attr)) {
					this.viewModel.availableNameAttributes.push({
						'attrName': activitiAttributes[attr],
						'attrValue': "activiti-" + attr
					});
				}
			}, this);
		},
		populateUserPropsIntoPicklist: function(){
			// build up what user attributes are allowed that the user can pick from in the picklist
			var allowedUserAttrs = {
				"displayName": "User Display Name",
				"emailAddress": "User Email Address",
				"groupNames": "User's Group Name",
				"loginName": "User Login Name"
			};

			_.each(_.keys(allowedUserAttrs), function(attr) {
				var existingProps = _.pluck(this.model.get("nameAttrsToDisplay"), 'attrValue');
				if (!_.contains(existingProps, "user-" + attr)) {
					this.viewModel.availableNameAttributes.push({
						'attrName': allowedUserAttrs[attr],
						'attrValue': "user-" + attr
					});
				}
			}, this);
			
		},
		populateDocPropsIntoPicklist: function(typeConfig){
			if (typeConfig){
				_.each(typeConfig.get("attrs").models, function(attr) {
					var existingDocumentProps = _.pluck(this.model.get("nameAttrsToDisplay"), 'attrValue');
					if (!_.contains(existingDocumentProps, "doc-" + attr.get("ocName"))) {

						var docAttrLabel = attr.get("label");
						if (docAttrLabel.indexOf("Document") === -1 || docAttrLabel.indexOf("Documents") !== -1){
							docAttrLabel = "Document " + docAttrLabel;
						}

						this.viewModel.availableNameAttributes.push({
							'attrName': docAttrLabel,
							'attrValue': "doc-" + attr.get("ocName")
						});
					}
				}, this);
			}
			this.getAdminTypeDeferred.resolve();	
		},
		loadPreviouslySavedAttributes: function(){
			// check if there are any previously saved selectd attributes 
			if(this.model.get("nameAttrsToDisplay")){
				_.each(this.model.get("nameAttrsToDisplay"), function(attr){				
					if(!attr.attributes){
						this.viewModel.selectedNameAttributes.push({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});

					}else{
						this.viewModel.selectedNameAttributes.push({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				}, this);
				
			} else {
				this.model.set("nameAttrsToDisplay", {});
			}
		},
		getFileNamePrefix: function(){
			this.model.set("fileNamePrefix", this.$('#reportFileNamePrefix').val());
		},
		setFileNamePrefix: function(){
			this.$('#reportFileNamePrefix').val(this.model.get("fileNamePrefix"));
		},
		getAssigneeDropdownLimit: function(){
			this.model.set("assigneeTypeaheadDropdownLimit", this.$('#assigneeTypeaheadDropdownLimit').val());
		},
		setAssigneeDropdownLimit: function(){
			this.$('#assigneeTypeaheadDropdownLimit').val(this.model.get("assigneeTypeaheadDropdownLimit"));
		},
		setupListeners: function(){
			this.stopListening(this.viewModel.selectedNameAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedNameAttributes, 'add remove reset', _.bind(this.listenToSelectedNameAttributes, this));
		},
		listenToSelectedNameAttributes: function(){
			var newObjectProps = [];
			_.each(this.viewModel.selectedNameAttributes.models, function(model){
				if (model.attrName){
					newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
				} else {
					newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
				}
			});
			this.model.set("nameAttrsToDisplay", _.extend([], newObjectProps));
		},
		buildNameTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: window.localize("modules.common.tossAcross.availableAttributes"),
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.availableNameAttributes
				},
				targetCollections: [
					{
						title: window.localize("modules.common.tossAcross.selectedAttributes"),
						labelAttr: 'attrName',
						collection: this.viewModel.selectedNameAttributes
					}
				]
			});
			
			this.setView(".toss-across-outlet", tossAcross).render();
		},
		documentTypeSelected: function(e){
			var self = this;
			this.selectedDocumentType = this.$(e.target).val();
			_.each(this.viewModel.availableDocumentTypesInConfig.models, function(attr) {
				if (self.selectedDocumentType === attr.attributes.label){
					self.selectedDocumentType = attr.attributes.value;
				}
			});
			this.model.set("selectedDocumentType", this.selectedDocumentType);

			this.viewModel.selectedNameAttributes.reset();
			this.viewModel.availableNameAttributes.reset();
			this.model.set("selectedNameAttributes", _.extend([], this.viewModel.selectedNameAttributes));

			app.context.configService.getAdminTypeConfig(this.selectedDocumentType, _.bind(this.populateDocPropsIntoPicklist, this));

			this.populateUserPropsIntoPicklist();
			this.populateActivitiPropsIntoPicklist();
			this.buildNameTossAcross();	 
		},
		renderDocumentType: function(){
			var self = this;
			var docTypeGroup = this.$('.documentTypeInputGroup');
			docTypeGroup.empty();
			_.each(this.viewModel.availableDocumentTypesInConfig.models, function(attr) {
				if (self.selectedDocumentType === attr.attributes.label){
					docTypeGroup.append($("<option selected>" + attr.attributes.label + "</option>"));
				}else{
					docTypeGroup.append($("<option>" + attr.attributes.label + "</option>"));
				}
			});
			
		},
		afterRender: function(){
			// when all deferreds have been resolved call necessary functions
			var self = this;
			$.when.apply($, this.deferredArray).then(function(){
				self.buildNameTossAcross();
				self.renderDocumentType();
				self.setFileNamePrefix();
				self.setAssigneeDropdownLimit();
			});
		}
	});

	return GenerateWorkflowReportConfig;
});