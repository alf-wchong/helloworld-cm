define([
    "app",
    "knockout"
], function(app, kb) {
	"use strict";

	var ManageLegalHoldCustomConfigView = {};

	ManageLegalHoldCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/managelegalholdconfig",
        events: {
            "change #form-name-select": "updateFormName",
            "change #oc-name-select": "updateOcAttrName",
        },
        initialize: function(){
        
            var self = this;
            this.model = this.viewModel.model();

            app.context.configService.getFormConfigNames(function(formConfigNames) {
                self.formNames = formConfigNames;
                self.ocNames = [];
                 // grab the adminOTC so we can populate our document types
                
                if(!self.model.get("formName")) {
                    self.model.set("formName", self.formNames[0]);
                }

                app.context.configService.getFormConfig(self.model.get("formName"), function(formConfig) {
                    var config = formConfig;
                    _.each(config.get("configuredTypes").models, function(configuredTypes){
                        _.each(configuredTypes.get("configuredAttrsPri").models, function(configuredAttrPri){
                            self.ocNames.push(configuredAttrPri.get("ocName"));
                        });
                    });

                    if(!self.model.get("ocName")) {
                        self.model.set("ocName", self.ocNames[0]);
                    }
                    self.render();

                });
            });
        },

        updateFormName: function() {
            var newFormName = this.$('#form-name-select').val();
            this.model.set("formName", newFormName);

            var self = this;
            app.context.configService.getFormConfig(self.model.get("formName"), function(formConfig) {
                var config = formConfig;
                self.ocNames = [];

                _.each(config.get("configuredTypes").models, function(configuredTypes){
                    _.each(configuredTypes.get("configuredAttrsPri").models, function(configuredAttrPri){
                        self.ocNames.push(configuredAttrPri.get("ocName"));
                    });
                });

                self.ocName=self.ocNames[0];
                self.model.set("ocName", self.ocNames[0]);
                self.render();
            });
        },
        
        updateOcAttrName: function() {
            var newOcAttrName = this.$('#oc-name-select').val();
            this.model.set("ocName", newOcAttrName);
        },
        
        serialize: function() {
            return {
                formNames: this.formNames,
                formName: this.model.get("formName"),
                ocNames: this.ocNames,
                ocName: this.ocName
            };
        },
        
        afterRender:function(){
            kb.applyBindings(this.viewModel, this.$el[0]);
        }
    });

    return ManageLegalHoldCustomConfigView;
});