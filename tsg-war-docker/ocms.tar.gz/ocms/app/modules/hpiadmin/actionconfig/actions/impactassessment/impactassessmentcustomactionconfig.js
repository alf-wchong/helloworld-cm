define([
    "app",
    "modules/common/tossacross"
    
], function(app, TossAcross) {
	"use strict";
    var ImpactAssessmentCustomActionConfigView = {};

	ImpactAssessmentCustomActionConfigView.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/impactassessmentconfig",
		events:{
			'change .getimpactassessment-object-type' : 'docTypeSelected',
			'change .getquery-criteria-attr' : 'queryAttrs',
			'change .getColumnCriteria-attr' : 'saveColAttrs',
			'change .getSearchCriteria-attr' : 'searchAttrs',
			'click .removeQueryCriteria' : 'removeQueryCriteria',
			'click .removeCols' : 'removeCols',
			'click #addQueryCriteria' : 'addQueryCriteria',
			'click #addCols' : 'addCols'
		},
		initialize: function(){
			var self = this;
			var viewModel = this.options.viewModel;
			var model = viewModel.model();
 
			this.viewModel.allAttributesForOTC = new Backbone.Collection();
			this.viewModel.allAttributesForOTC.comparator = 'attrName';
			this.viewModel.availableNameAttributes = new Backbone.Collection();
			this.viewModel.selectedNameAttributes = new Backbone.Collection();
			this.viewModel.selectedDocumentType = kb.observable(model, "selectedDocumentType");
			this.viewModel.queryCriteria = kb.observable(model, "queryCriteria");
			this.viewModel.columnCriteria = kb.observable(model, "columnCriteria");
			this.viewModel.searchCriteria = kb.observable(model, "searchCriteria");
			
			this.setupListeners();

			this.deferredArray = [];
			this.otcDeferred = $.Deferred();
			this.getAdminTypeDeferred = $.Deferred();
			this.deferredArray.push(this.otcDeferred);
			this.deferredArray.push(this.getAdminTypeDeferred);

			viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
			viewModel.availableQueryCriteria = ko.observableArray([]);
			viewModel.availableSearchCriteria = ko.observableArray([]);
			
			app.context.configService.getAdminOTC(function (config) {
                config.get("configs").each(function (typeConfig) {
                    if (typeConfig.get("isContainer") === "false") {
                        viewModel.availableDocumentTypesInConfig.push({
                            "label": typeConfig.get("label"),
                            "value": typeConfig.get("ocName")
						});
                    }
				});
				//if any of the variables on the model are empty/not set or configured yet, set to the first value
				//or set an empty value to avoid null error
				if(_.isEmpty(model.get("selectedDocumentType"))) { 
					if(viewModel.availableDocumentTypesInConfig().length > 0){
						viewModel.selectedDocumentType(viewModel.availableDocumentTypesInConfig()[0].value);
					}
				}

				if(_.isEmpty(model.get("queryCriteria"))){
					viewModel.queryCriteria([{attribute: "", value:""}]);
				}

				if(_.isEmpty(model.get("columnCriteria"))){
					viewModel.columnCriteria([{attribute: "", value:""}]);
				}

				if(_.isEmpty(model.get("searchCriteria"))){
					viewModel.searchCriteria([{attribute: "", value:""}]);
				}
				// Careful here, send the ocName, not the label.
				var ocName = viewModel.selectedDocumentType();
				app.context.configService.getAdminTypeConfig(ocName, function(typeConfig) {
					_.each(typeConfig.get("attrs").models, function(attr) {
						if (!_.findWhere(_.pluck(self.viewModel.model().get("nameAttrsToDisplay"), 'attrValue')) ,  attr.get("ocName")) {
							self.viewModel.availableNameAttributes.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
							self.viewModel.allAttributesForOTC.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
						}
					});
					self.getAdminTypeDeferred.resolve();			
				});
				
				self.otcDeferred.resolve();
            });

			// check if there are any previously saved selectd attributes 
			if(this.viewModel.model().get("nameAttrsToDisplay")){
				_.each(this.viewModel.model().get("nameAttrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedNameAttributes.push({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});

						
					}else{
						self.viewModel.selectedNameAttributes.push({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
				
			} else {
				this.viewModel.model().set("nameAttrsToDisplay", {});
			}
		},
		setupListeners: function(){

			this.stopListening(this.viewModel.selectedNameAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedNameAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(this.viewModel.selectedNameAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				this.viewModel.model().set("nameAttrsToDisplay", _.extend([], newObjectProps));
			}, this);
		},

		renderQueryCriteriaAttrs: function(){
			  // Get the attributes that are set to on this configuration model.
			  var queryCriteriaAttrs = this.$('.getquery-criteria-attr');
			  // Update all criteria attributes - clear any existing ones.
			  queryCriteriaAttrs.empty();
			  queryCriteriaAttrs.append($("<option></option>")
						 .attr("disabled", "disabled")
						 .attr("selected", "selected"));
			  // Render object types using all the attributes that were extracted from our selected object type.
			  
			  this.viewModel.allAttributesForOTC.each(function(type){
				queryCriteriaAttrs.append($("<option></option>")
								  .attr('value', type.get('attrValue'))
								  .text(type.get('attrName'))); 
			  });

			  // Loop through each of the criteria combinations that are on the DOM and that should match our observable.
			  // Set each criteria's currently selected attribute value on the DOM.
			  _.each(queryCriteriaAttrs, function(el, index){
				  this.$(el).val(this.viewModel.model().get("queryCriteria")[index].attribute);
			  }, this);
		},

		renderColumnCriteria: function(){
			var columnCriteriaAttrs = this.$('.getColumnCriteria-attr');
			_.each(columnCriteriaAttrs, function(el, index){
				this.$(el).val(this.viewModel.model().get("columnCriteria")[index].attribute);
			}, this);
		},

		renderSearchCriteria: function(){
			  // Get the attributes that are set to on this configuration model.
			  var searchAttrs = this.$('.getSearchCriteria-attr');
			  // Update all criteria attributes - clear any existing ones.
			  searchAttrs.empty();
			  searchAttrs.append($("<option></option>")
						 .attr("disabled", "disabled")
						 .attr("selected", "selected"));
			  // Render object types using all the attributes that were extracted from our selected object type.
			  this.viewModel.allAttributesForOTC.each(function(type){
				searchAttrs.append($("<option></option>")
								  .attr('value', type.get('attrValue'))
								  .text(type.get('attrName'))); 
			  });
  
			  // Loop through each of the criteria combinations that are on the DOM and that should match our observable.
			  // Set each criteria's currently selected attribute value on the DOM.
			  _.each(searchAttrs, function(el, index){
				  this.$(el).val(this.viewModel.model().get("searchCriteria")[index].attribute);
			  }, this);
		},

		docTypeSelected: function(){
			var ocName = this.viewModel.selectedDocumentType();
			this.viewModel.model().set("selectedDocumentType", ocName);

			this.viewModel.selectedNameAttributes.reset();
			this.viewModel.availableNameAttributes.reset();
			this.viewModel.allAttributesForOTC.reset();
			this.viewModel.model().set("selectedNameAttributes", _.extend([], this.viewModel.selectedNameAttributes));

            // Reset criteria attributes after a type change to an empty criteria.
			this.viewModel.queryCriteria([{attribute: "", value:""}]);
			this.viewModel.columnCriteria([{attribute: "", value:""}]);
			this.viewModel.searchCriteria([{attribute: "", value:""}]);

			this.changeObjectType();
		},

		changeObjectType: function () {
			var self = this;
			
			var ocName = this.viewModel.selectedDocumentType();
			app.context.configService.getAdminTypeConfig(ocName, function(typeConfig) {
				_.each(typeConfig.get("attrs").models, function(attr) {
					if (!_.findWhere(_.pluck(self.viewModel.model().get("nameAttrsToDisplay"), 'attrValue')) ,  attr.get("ocName")) {
						self.viewModel.availableNameAttributes.push({
							'attrName': attr.get("label"),
							'attrValue': attr.get("ocName")
						});
						self.viewModel.allAttributesForOTC.push({
							'attrName': attr.get("label"),
							'attrValue': attr.get("ocName")
						});
					}
				});
			});
			

			this.buildNameTossAcross();
			this.renderQueryCriteriaAttrs();
			this.renderColumnCriteria();
			this.renderSearchCriteria();   

        },
		buildNameTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: window.localize("modules.common.tossAcross.availableAttributes"),
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.availableNameAttributes
				},
				targetCollections: [
					{
						title: window.localize("modules.common.tossAcross.selectedAttributes"),
						labelAttr: 'attrName',
						collection: this.viewModel.selectedNameAttributes
					}
				]
			});
			
			this.setView(".toss-across-outlet", tossAcross).render();
		},
		
        queryAttrs: function(e){
            //Get id and update the correct criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('getquery-criteria-attr-', ''));
            var criteriaAttr = this.$(e.currentTarget).val();
            this.viewModel.queryCriteria()[index].attribute = criteriaAttr;
		},

		saveColAttrs: function(e){
            //Get id and update the correct criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('getColumnCriteria-attr-', ''));
            var columnAttr = this.$(e.currentTarget).val();
            this.viewModel.columnCriteria()[index].attribute = columnAttr;
		},

		searchAttrs: function(e){
            //Get id and update the correct criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('getSearchCriteria-attr-', ''));
            var searchAttr = this.$(e.currentTarget).val();
            this.viewModel.searchCriteria()[index].attribute = searchAttr;
		},

		removeQueryCriteria: function(e) {
            // Get id and remove this criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('remove-query-', ''));

            var removeArray = [];
            // Remove the item at the specified index.
            removeArray = this.viewModel.queryCriteria().splice(0);
            removeArray.splice(index, 1);

            this.viewModel.queryCriteria(removeArray);
            this.renderQueryCriteriaAttrs(); 
		},
		addQueryCriteria: function() {
            var addArray = [];
            addArray = this.viewModel.queryCriteria().splice(0);
            addArray.push({attribute: "", value:""});
            this.viewModel.queryCriteria(addArray);
            this.renderQueryCriteriaAttrs(); 
        },
		
		addCols: function(){
            var addColArray = [];
            addColArray = this.viewModel.columnCriteria().splice(0);
            addColArray.push({attribute: "", value:""});
			this.viewModel.columnCriteria(addColArray);
			this.renderColumnCriteria();
		},

		removeCols: function(e){
            // Get id and remove this criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('remove-cols-', ''));
            var removeColArray = [];
            // Remove the item at the specified index.
            removeColArray = this.viewModel.columnCriteria().splice(0);
            removeColArray.splice(index, 1);
			this.viewModel.columnCriteria(removeColArray);
			this.renderColumnCriteria();

			
		},
		afterRender: function(){
			// when all deferreds have been resolved call necessary functions
			var self = this;
			$.when.apply($, this.deferredArray).then(function(){
				ko.applyBindings(self.options.viewModel, self.$el[0]);
				self.viewModel.allAttributesForOTC.sort();
				self.buildNameTossAcross();
				self.renderQueryCriteriaAttrs();
				self.renderColumnCriteria();
				self.renderSearchCriteria();		
			});
			
		}
	});

	return ImpactAssessmentCustomActionConfigView;
});