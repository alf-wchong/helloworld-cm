define(["app"], function (app) {
    "use strict";
    var SendToKiraCustomConfigView = app.module();
    
    SendToKiraCustomConfigView.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/sendtokiraconfig",
        events: {
            "click #add-project": "addProject",
            "click .remove-project": "removeProject",
            "keyup #project-number": "checkLengthAndExistence"
        },
        initialize: function () {

            // if we don't have 'configuredProjects' yet, we should instantiate it
            if (!this.viewModel.configuredProjects) {
                this.viewModel.configuredProjects = kb.observable(this.viewModel.model(), 'configuredProjects');
                this.viewModel.configuredProjects([]);
            }
        },

        addProject: function () {

            // the project number in the input
            var projectNumber = $("#project-number").val().trim();

            // for some reason, kb and ko were acting weird and only updating the DOM for every other
            // project that was added (knockback.js line 1233 would evaluate differently in these 2 cases)
            // without diving into the "magic" of kb/ko, setting the var to an empty array first seems to work
            var arr = this.viewModel.configuredProjects();
            arr.push({
                "projectNumber": projectNumber
            });
            this.viewModel.configuredProjects([]);
            this.viewModel.configuredProjects(arr);

            // clearing out the input after the project is added
            $("#project-number").val("");
        },

        removeProject: function (e) {

            // getting the value of the project
            var projectToRemove = $(e.currentTarget).attr('projectNumber');

            // updating the value of the config (probably a better way to do this)
            this.viewModel.configuredProjects(_.reject(this.viewModel.configuredProjects(), function (project) {
                return project.projectNumber === projectToRemove;
            }));
        },

        // making sure that the add button is disabled if there is no input, or if the current input is already 
        // a configured project
        checkLengthAndExistence: function () {
            if ($("#project-number").val().length > 0 && !_.findWhere(this.viewModel.configuredProjects(), {
                projectNumber: $("#project-number").val()
            })) {
                $("#add-project").attr("disabled", false);
            } else {
                $("#add-project").attr("disabled", true);
            }
        },

        afterRender: function () {
            kb.applyBindings(this.viewModel, this.$el[0]);
        }
    });

    return SendToKiraCustomConfigView;
});