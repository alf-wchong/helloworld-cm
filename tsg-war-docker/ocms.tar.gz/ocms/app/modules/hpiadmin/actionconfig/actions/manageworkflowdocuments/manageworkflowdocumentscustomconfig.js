define([
  // Application.
  "app",
  "modules/hpiadmin/actionconfig/actions/managerelations/managerelationscustomconfig"
],

// Map dependencies from above array.
function(app, ManageRelationsCustomConfig) {
     "use strict";

     var ManageWorkflowDocumentsCustomConfig = {};

     var baseDefaults = new Backbone.Model({
          relationNames: [],
          searchObjectType: 'Quality Document',
          searchAttribute: 'documentNumber',
          searchCriteria: [{
               attrName: 'aw_status',
               attrValue: 'Draft'
          }],
          searchResultLimit: 25,
          searchResultAttrs: [{
               value: 'documentNumber'
          }, {
               value: 'title'
          }, {
               value: 'aw_status'
          }, {
               value: 'versionLabel'
          }],
          searchResultConditions: [{
               name: 'condition-isqualitydraftlifecyclestate-conditionevaluator'
          }, {
               name: 'condition-isworkflowdocnotalreadyattached-conditionevaluator'
          }, {
               name: 'condition-isobjectlatest-conditionevaluator'
          }]
     });

     var repositoryDefaults = new Backbone.Model({
          repoNames: [{
               displayValue: '',
               value: ''
          }, {
               displayValue: 'Alfresco',
               value: 'alf'
          }, {
               displayValue: 'Documentum',
               value: 'dctm'
          }, {
               displayValue: 'HBase',
               value: 'hbase'
          }],
          alf: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw:workflowDocument'],
               searchCriteria: [{
                    attrName: 'aw_status',
                    attrValue: 'Draft'
               }, {
                    attrName: 'cvn_isLatestVersion',
                    attrValue: 'True'
               }]
          }),
          dctm: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw_rel_workflow_document'],
               searchObjectType: 'Controlled Document',
               searchCriteria: [{
                    attrName: 'aw_status',
                    attrValue: 'Draft'
               }, {
                    attrName: 'versionLabel',
                    attrValue: 'Latest'
               }]
          }),
          hbase: _.extend({}, baseDefaults.attributes, {
               relationNames: ['aw_rel_workflow_document'],
               searchObjectType: 'Controlled Document',
               searchCriteria: [{
                    attrName: 'aw_status',
                    attrValue: 'Draft'
               }, {
                    attrName: 'latest',
                    attrValue: 'True'  
               }]
          })
     });

     ManageWorkflowDocumentsCustomConfig.View = ManageRelationsCustomConfig.View.extend({
          initialize: function() {
               //Override the defaults object and set enabled subviews
               this.options.baseDefaults = baseDefaults;
               this.options.repositoryDefaults = repositoryDefaults;
               this.options.showConditions = true;
               this.options.allowMultipleRelations = false;

               //Call super method
               ManageRelationsCustomConfig.View.prototype.initialize.call(this);
          }
     });

     return ManageWorkflowDocumentsCustomConfig;
});
