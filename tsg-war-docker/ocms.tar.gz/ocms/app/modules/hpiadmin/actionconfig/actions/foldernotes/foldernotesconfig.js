define([
    "app",
    "modules/hpiadmin/common/iosswitch",
    "modules/actions/actionmodules",
    "modules/common/tossacross"
], function(app, iOSSwitch, actionModules, TossAcross) {
    "use strict";

    var FolderNotesCustomConfigView = {};

    FolderNotesCustomConfigView.View = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/foldernotesconfig",
        initialize: function () {
            this.viewModel = this.options.viewModel;

            this.setupViewModel();
            this.setupDefaults();

            var adminDeferred = this.getAdminOTC();
            var formDeferred = this.getFormConfig();
            var tossAcrossDeferred = this.setupTossAcross();

            this._startListening();

            // when all deferreds are completed, create and render the subviews
            $.when(adminDeferred, formDeferred, tossAcrossDeferred).done($.proxy(function() {
                 this.createAndRenderSubViews();
            }, this));
        },
        setupViewModel: function () {
            this.extraParams = actionModules.getDynamicParams(this.options.viewModel.actionId());
            this.viewModel.isDocumentNotes = ko.observable(this.extraParams.isDocumentNotes.toString());

            this.viewModel.form = kb.observable(this.viewModel.model(), "form");
            this.viewModel.noteObjectType = kb.observable(this.viewModel.model(), 'noteObjectType');
            this.viewModel.noteRelationship = kb.observable(this.viewModel.model(), "noteRelationship");
            this.viewModel.canCreate = kb.observable(this.viewModel.model(), "canCreate");
            this.viewModel.noteVisibility = kb.observable(this.viewModel.model(), 'noteVisibility');
            this.viewModel.noteEditable = kb.observable(this.viewModel.model(), 'noteEditable');
            this.viewModel.enableDocNotes = kb.observable(this.viewModel.model(), "enableDocNotes");
            this.viewModel.hideDocList = kb.observable(this.viewModel.model(), "hideDocList");
            this.viewModel.docIndicatorAttribute = kb.observable(this.viewModel.model(), "docIndicatorAttribute");
            this.viewModel.creationDateTime = kb.observable(this.viewModel.model(), 'creationDateTime');
            this.viewModel.exportNotesExcel = kb.observable(this.viewModel.model(), "exportNotesExcel");
            this.viewModel.singleNotePdf = kb.observable(this.viewModel.model(), "singleNotePdf");
            this.viewModel.customNoteStorage = kb.observable(this.viewModel.model(), "customNoteStorage");
            this.viewModel.customNoteStoragePath = kb.observable(this.viewModel.model(), "customNoteStoragePath");
            this.viewModel.customNoteStorageWithType = kb.observable(this.viewModel.model(), "customNoteStorageWithType");
            this.viewModel.attrToShow = kb.observable(this.viewModel.model(), "attrToShow");
            this.viewModel.authorDisplayName = kb.observable(this.viewModel.model(), "authorDisplayName");

            this.viewModel.typeOptions = ko.observable();
            this.viewModel.selectedType = ko.observable();
            this.viewModel.typeOptions = ko.observable();
            this.viewModel.typeAttributes = ko.observable();

            this.formSubscribePlaceholder = this.viewModel.form();
            this.viewModel.potentialForms = ko.observableArray();

            this.viewModel.availableAttributes = new Backbone.Collection();
            this.viewModel.selectedAttributes = new Backbone.Collection();
        },
        setupDefaults: function() {
            //default note object type to HPI Note
            if (this.viewModel.noteObjectType() === null) {
                this.viewModel.noteObjectType("HPI Note");
            }
            if (this.viewModel.noteRelationship() === null) {
                this.viewModel.noteRelationship("hpi_folder_note");
            }
            if (this.viewModel.canCreate() === null) {
                this.viewModel.canCreate("true");
            }
            if (this.viewModel.noteVisibility() === null) {
                this.viewModel.noteVisibility("false");
            }
            if (this.viewModel.noteEditable() === null) {
                this.viewModel.noteEditable("true");
            }
            if (this.viewModel.enableDocNotes() === null) {
                this.viewModel.enableDocNotes(this.extraParams.isDocumentNotes.toString());
            }
            if (this.viewModel.hideDocList() === null) {
                this.viewModel.hideDocList("false");
            }
            if (this.viewModel.creationDateTime() === null) {
                this.viewModel.creationDateTime("false");
            }
            if (this.viewModel.exportNotesExcel() === null) {
                this.viewModel.exportNotesExcel("false");
            }
            if (this.viewModel.singleNotePdf() === null) {
                this.viewModel.singleNotePdf("false");
            }
            if(this.viewModel.customNoteStorage() === null){
                this.viewModel.customNoteStorage("false");
            }
            if(this.viewModel.customNoteStorageWithType() === null){
                this.viewModel.customNoteStorageWithType("false");
            }
            if(this.viewModel.authorDisplayName() === null){
                this.viewModel.authorDisplayName(true);
            }
        },
        getAdminOTC: function() {
            var self = this;
            var deferred = $.Deferred();

            // the two drop downs that let the user select the attribute to use for doc notes notifier
            app.context.configService.getAdminOTC(function (adminOTC) {
                self.viewModel.typeOptions(adminOTC.get('configs').models); 

                // load the saved values if they exist
                if (self.viewModel.docIndicatorAttribute() && self.viewModel.docIndicatorAttribute().type) {
                    var savedType = _.find(adminOTC.get('configs').models, function (m) {
                        return m.get('label') === self.viewModel.model().get('docIndicatorAttribute').type;
                    });

                    if (savedType) {
                        self.viewModel.selectedType(savedType);
                        self.viewModel.typeAttributes(savedType.get('attrs').models);
                        var savedAttr = _.find(savedType.get('attrs').models, function (a) {
                            return a.get('ocName') === self.viewModel.model().get('docIndicatorAttribute').attr;
                        });
                        self.viewModel.docIndicatorAttribute(savedAttr);
                    }
                }

                self.viewModel.selectedType.subscribe(function (selectedType) {
                    if (selectedType) {
                        self.viewModel.typeAttributes(selectedType.get('attrs').models);
                    } else {
                        // we fall here when the dropdown is set to the empty value, which would be when the user wants to turn off notifications
                        self.viewModel.typeAttributes('');
                        self.viewModel.model().set('docIndicatorAttribute', { type: '', attr: '' });
                    }
                });

                self.viewModel.docIndicatorAttribute.subscribe(function (selectedAttr) {
                    if (selectedAttr) {
                        self.viewModel.model().set('docIndicatorAttribute', { type: self.viewModel.selectedType().get('label'), attr: selectedAttr.get('ocName') });
                    }
                });

                deferred.resolve();
            });

            return deferred.promise();
        },
        getFormConfig: function() {
            var self = this;
            var deferred = $.Deferred();

            app.context.configService.getFormConfigNames(function (formConfigNames) {
                self.viewModel.potentialForms(formConfigNames);
                //since the form value is bound from the potentialForms observable,
                //this context call will come back after the form has been gathered
                //from the config. this resets the form to the right value.
                self.viewModel.form(self.formSubscribePlaceholder);
                deferred.resolve();
            }); 

            return deferred.promise();
        },
        setupTossAcross: function() {
            var self = this;
            var deferred = $.Deferred();

            // if no attrs have been configured then add these defaults
            if(!this.viewModel.model().get("attrsToDisplay")){
                var defaultAttrs = [
                    {"attrName": "Creation Date", "ocName":"creationDate"},
                    {"attrName": "Author", "ocName":"creator"},
                    {"attrName": "Note Type", "ocName":"note_type"},
                    {"attrName": "Note Detail", "ocName":"note_detail"},
                    {"attrName": "Documents", "ocName":"note_attachment"}
                ];
                this.viewModel.model().set("attrsToDisplay", defaultAttrs);

            }

            // gets the possible attributes of HPI Note
            app.context.configService.getAdminTypeConfig(this.viewModel.noteObjectType(), function(typeConfig){
                _.each(typeConfig.get("attrs").models, function(attr) {
                    if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("attrsToDisplay"), 'ocName')) === -1 ) { // does not include ones already on the viewModel
                        self.viewModel.availableAttributes.push({
                            'attrName': attr.get("label"),
                            'ocName': attr.get("ocName")
                        });
                    }
                });
                deferred.resolve();
            });

            return deferred.promise();
        },
        createAndRenderSubViews: function() {

            this.createAllSwitches();
            this.createAllTossAcross();

            this.setViews({
                "#authorDisplayName": this.authorDisplayName,
                "#attributesToDisplayTossAcross": this.attributesToDisplayTossAcross
            }).renderViews();
        },
        createAllSwitches: function() {
            this.authorDisplayName = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "authorDisplayName",
                switchTitle: window.localize("customConfig.folderNote.authorDisplayName.title"),
                configDescription: window.localize("customConfig.folderNote.authorDisplayName.desc")
            });
        },
        createAllTossAcross: function() {
            // check if there are any previously saved selected attributes on the toss across
            // add them to selected and remove them from available
            _.each(this.viewModel.model().get("attrsToDisplay"), function(attr){
                if(!attr.attributes){
                    this.viewModel.selectedAttributes.add({
                        'attrName': attr.attrName,
                        'ocName': attr.ocName
                    });
                }else{
                    this.viewModel.selectedAttributes.add({
                        'attrName': attr.attributes.attrName,
                        'ocName': attr.attributes.ocName
                    });
                }
            }, this);

            this.attributesToDisplayTossAcross = new TossAcross.Layout({
                srcCollection: {
                    title: window.localize("customConfig.bulkUploadConfig.availableAttributes"),
                    filter: true,
                    labelAttr: 'attrName',
                    valueAttr: 'ocName',
                    collection: this.viewModel.availableAttributes
                },
                targetCollections: [{
                    title: window.localize("customConfig.bulkUploadConfig.selectedAttributes"),
                    labelAttr: 'attrName',
                    valueAttr: 'ocName',
                    collection: this.viewModel.selectedAttributes
                }]
            });
        },
        _startListening: function() {
            // listens for updates to the selected attributes for the toss across. This updates the viewModel as the toss across is updates
            this.listenTo(this.viewModel.selectedAttributes, 'add remove reset', function(){
                var newObjectProps = [];
                _.each(this.viewModel.selectedAttributes.models, function(model){
                    if (model.attrName){
                        newObjectProps.push({attrName: model.attrName, ocName: model.ocName});
                    } else {
                        newObjectProps.push({attrName: model.get('attrName'), ocName: model.get('ocName')});
                    }
                }, this);
                this.viewModel.model().set("attrsToDisplay", _.extend([], newObjectProps));
            }, this);
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    return FolderNotesCustomConfigView;
});