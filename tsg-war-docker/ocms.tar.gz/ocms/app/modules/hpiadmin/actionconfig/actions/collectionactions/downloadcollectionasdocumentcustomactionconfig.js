define([
    "app",
    "modules/common/tossacross",
    
], function(app, TossAcross) {
	"use strict";
    var DownloadCollectionAsDocumentCustomConfigView = {};

	DownloadCollectionAsDocumentCustomConfigView.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/downloadcollectionasdocumentconfig",
		initialize: function(){
			var self = this;
			var viewModel = this.options.viewModel;
			
			// Clear the stuff that was already populated upon a change and before rebuilding.
			this.viewModel.availableNameAttributes = new Backbone.Collection();
			this.viewModel.selectedNameAttributes = new Backbone.Collection();
			
			this.fetchAvailableNameAttributesDeferred = $.Deferred();

			app.context.configService.getAdminTypeConfig("Collection", function(typeConfig){
				_.each(typeConfig.get("attrs").models, function(attr) {
					if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("nameAttrsToDisplay"), 'attrValue')) === -1 ) {
						self.viewModel.availableNameAttributes.push({
							'attrName': attr.get("label"),
							'attrValue': attr.get("ocName")
						});
					}
				});
				self.fetchAvailableNameAttributesDeferred.resolveWith(self);
			});

			// Listener that controls any movements to the attributes selected as the doc name for collections
			this.stopListening(this.viewModel.selectedNameAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedNameAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedNameAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("nameAttrsToDisplay", _.extend([], newObjectProps));
			}, this);
			// check if there are any previously saved selectd attributes 
			if(this.viewModel.model().get("nameAttrsToDisplay")){
				_.each(this.viewModel.model().get("nameAttrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedNameAttributes.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedNameAttributes.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("nameAttrsToDisplay", {});
			}
			
			this.fetchAvailableNameAttributesDeferred.done(this.buildNameTossAcross);
		},
		buildNameTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: window.localize("modules.common.tossAcross.availableAttributes"),
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.availableNameAttributes
				},
				targetCollections: [
					{
						title: window.localize("modules.common.tossAcross.selectedAttributes"),
						labelAttr: 'attrName',
						collection: this.viewModel.selectedNameAttributes
					}
				]
			});
			
			this.setView(".downloaded-doc-name-toss-across-outlet", tossAcross).render();
		},
		afterRender: function(){
			// need this for filtering to work 
			this.fetchAvailableNameAttributesDeferred.done(this.buildNameTossAcross);
		}
	});

	return DownloadCollectionAsDocumentCustomConfigView;
});