define([
	"app",
	'modules/hpiadmin/adminUtil',
    "modules/common/tossacross"
], function (app, AdminUtil, TossAcross) {
    "use strict";
    var SendToJmsCustomConfigView = app.module();
    
    SendToJmsCustomConfigView.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/sendtojmsconfig",
        events: {
			"click .admin_ui_subsectionToggle" : "toggleSubsection"
        },

        initialize: function () {
            var self = this;
			this.viewModel = this.options.viewModel;

            // Get the names of the workflow forms to populate the dropdown.
			this.viewModel.form = kb.observable(this.viewModel.model(), "form");
			this.viewModel.potentialForms = ko.observableArray();
			this.initializeDef = app.context.configService.getAdHocFormConfigNames(function(wfFormConfigNames) {
				self.viewModel.potentialForms(wfFormConfigNames);
            });
            
            // True or false determining if the selected files need to be PDFs/have a PDF rendition.
			this.viewModel.hasToBePdf = kb.observable(this.viewModel.model(), "hasToBePdf");
			if (!this.viewModel.hasToBePdf()) {
                this.viewModel.hasToBePdf("true");
            }

            // The size limit of the send to jms files.
            this.viewModel.sizeLimit = kb.observable(this.viewModel.model(), "sizeLimit");
            if (!this.viewModel.sizeLimit()) {
                this.viewModel.sizeLimit("5");
            }

            // Get the available document types to display.
			this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
			this.fetchAvailableDocumentTypesDeferred = $.Deferred();

			app.context.configService.getAdminOTC(function(config) {
				config.get("configs").each(function (typeConfig) {
					if (typeConfig.get("isContainer") === "false") {
						self.viewModel.availableDocumentTypesInConfig.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					}
				}, this);
				self.fetchAvailableDocumentTypesDeferred.resolveWith(self);
			});

            // The document type that the attributes will be pulled off of for the attrubutes toss-across.
            this.viewModel.selectedDocumentType = kb.observable(this.viewModel.model(), 'selectedDocumentType');
			this.viewModel.selectedDocumentType.subscribe(function(){
				// Clear the stuff that was already populated upon a change and before rebuilding.
				self.viewModel.potentialAttributes.reset();
				self.viewModel.selectedAttributes.reset();
				self.populatePotentialAttributes();
				self.buildAttributeTossAcross();
			});
            
            // Setup the attribute toss-across.
            this.viewModel.potentialAttributes = new Backbone.Collection();
			this.viewModel.selectedAttributes = new Backbone.Collection();
			
			// Listener that controls any movements to the attributes selected to display for an object type
			this.stopListening(this.viewModel.selectedAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("attrsToDisplay", _.extend([], newObjectProps));
			}, this);
			
			// check if there are any previously saved selected attributes 
			if(this.viewModel.model().get("attrsToDisplay")){
				_.each(this.viewModel.model().get("attrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedAttributes.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("attrsToDisplay", {});
            }
        },

        populatePotentialAttributes: function(){
			var self = this;
			this.viewModel.potentialAttributes.reset();
			
			if (this.viewModel.selectedDocumentType()){
				//Getting all potential attributes from the OTC
				app.context.configService.getAdminTypeConfig(this.viewModel.selectedDocumentType(), function(typeConfig){
					_.each(typeConfig.get("attrs").models, function(attr) {
						if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("attrsToDisplay"), 'attrValue')) === -1 ) {
							self.viewModel.potentialAttributes.push({
								'attrName': attr.get("label"),
								'attrValue': attr.get("ocName")
							});
						}
					});
				});
			}
        },
        
        buildAttributeTossAcross: function(){
			this.populatePotentialAttributes();
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.potentialAttributes
				},
				targetCollections: [
					{
						title: 'Selected Attribute',
						labelAttr: 'attrName',
						collection: this.viewModel.selectedAttributes
					}
				]
			});
			
			this.setView("#attributesTossAcross", tossAcross).render();
		},

        afterRender: function () {
            var self = this;
			
			this.initializeDef.done(function(){
				kb.applyBindings(self.viewModel, self.$el[0]);
            });
            
            this.buildAttributeTossAcross();
		},
		
		toggleSubsection: function(e) {
			AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
		}
    });

    return SendToJmsCustomConfigView;
});