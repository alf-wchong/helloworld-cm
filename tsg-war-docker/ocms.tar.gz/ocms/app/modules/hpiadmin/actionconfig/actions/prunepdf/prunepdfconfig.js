define([
	"app",
	"modules/hpiadmin/common/iosswitch"
], function(app, IOSSwitch) {
	"use strict";

	var PrunePDFCustomConfigView = {};

	PrunePDFCustomConfigView.View = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/prunepdfconfig",
		events: {
			"change #form-name-select": "updateFormName",
		},
		initialize: function() {
			var self = this;

			this.model = this.viewModel.model();

			app.context.configService.getFormConfigNames(function(formConfigNames) {
				self.formNames = formConfigNames;
				if(!self.model.get("formName")) {
					self.model.set("formName", self.formNames[0]);
				}
				self.render();
			});

			this.enableVersioningSwitchView = new IOSSwitch.View({
				model: this.model,
				configModelKey: 'enableVersioning',
				switchTitle: window.localize("customConfig.prunePDF.versioning.title"),
				configDescription: window.localize("customConfig.prunePDF.versioning.description")
			});

			this.enableAuditingSwitchView = new IOSSwitch.View({
				model: this.model,
				configModelKey: 'enableAuditing',
				switchTitle: window.localize("customConfig.prunePDF.auditing.title"),
				configDescription: window.localize("customConfig.prunePDF.auditing.description")
			});

			this.setViews({
				'#prunePdf-enableVersioning-iosSwitch': this.enableVersioningSwitchView,
				'#prunePdf-enableAuditing-iosSwitch': this.enableAuditingSwitchView
			});
		},

		updateFormName: function(event) {
			event.stopPropagation();
			var newFormName = this.$('#form-name-select').val();
			this.model.set("formName", newFormName);
		},

		serialize: function() {
			return {
				formNames: this.formNames,
				formName: this.model.get("formName")
			};
		}
	});

	return PrunePDFCustomConfigView;
});