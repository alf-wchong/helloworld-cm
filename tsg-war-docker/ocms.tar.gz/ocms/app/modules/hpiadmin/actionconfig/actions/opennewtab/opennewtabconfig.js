// OpenNewTab module
//@author: Bradley White
define([
        // Application.
        "app",
        "modules/hpiadmin/common/iosswitch"
    ],

    // Map dependencies from above array.
    function (app, iOSSwitch) {
        "use strict";
        //Start with declaring your id - this is the same value as in the filename between the words action. and .js
        //get the config from the namespace. The action handler is responsible for this; //

        var action = {};

        action.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/opennewtabconfig",
            events: {
                "click #addOtherPropBtn": "addOverlayParameterEntry"
            },
            initialize: function(options) {
                this.model = options.viewModel.model();
                if(!this.model.has("overlayParameters")) {
                    this.model.set("overlayParameters", []);
                } 

                if(!this.model.get('selectedNewTabViewer')) {
                    this.model.set('selectedNewTabViewer', "stream");
                }

                this.eventBus = _.extend({}, Backbone.Events);
                this._startListening();

                //initialize content switch
                this.createContentSwitchView();

                //initialize other properties
                _.each(this.model.get("overlayParameters"), this.createOverlayParameterEntryView, this);
            },
            _startListening: function() {
                this.listenTo(this.eventBus, "propertyDeleted", this.deleteOverlayParameterEntry);
                this.listenTo(this.model, "change:selectedNewTabViewer", this.processSwitchChange, this);
            },
            addOverlayParameterEntry: function() {
                //Create new model
                var newPropModel = {
                    key: "", 
                    value: ""
                };
                this.model.get("overlayParameters").push(newPropModel);
                
                //Display new model
                this.createOverlayParameterEntryView(newPropModel);
            },
            deleteOverlayParameterEntry: function(modelToDelete) {
                this.model.set("overlayParameters", _.reject(this.model.get("overlayParameters"), function(model) {
                    return (model.key === modelToDelete.key) && (model.value === modelToDelete.value);
                }));
            },
            createOverlayParameterEntryView: function(propModel) {
                var newPropView = new action.OverlayParametersEntryView({
                    model: propModel,
                    eventBus: this.eventBus
                });
                this.insertView("#overlayParametersEntryHook", newPropView).render();
            },
            createContentSwitchView: function() {
                var contentSwitchView = new iOSSwitch.View({
                    model: this.model,
                    configModelKey: "selectedNewTabViewer",
                    onLabel: window.localize("customConfig.openNewTab.docViewer"),
                    offLabel: window.localize("customConfig.openNewTab.stream"),
                    switchTitle: window.localize("customConfig.openNewTab.enableDocViewer"),
                    configDescription: window.localize("customConfig.openNewTab.enableDocViewerTooltip"),
                    customClass: "switch-two",
                    trueVal: "docviewer",
                    falseVal: "stream"
                });
                this.insertView("#contentSwitchHook", contentSwitchView);
            },
            processSwitchChange: function(model) {
                var newVal = model.get("selectedNewTabViewer");
                if (newVal === "stream") {
                    this.$("#overlayParameters").removeClass("invisible");
                } else {
                    this.$("#overlayParameters").addClass("invisible");
                }
            },
            afterRender: function() {
                this.processSwitchChange(this.model);
            }
        });

        action.OverlayParametersEntryView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/opennewtabconfig-overlayparameters",
            events: {
                "click #deletePropBtn": "deleteProperty",
                "keyup #propKey": "updateKey",
                "keyup #propValue": "updateValue"
            },

            deleteProperty: function() {
                this.eventBus.trigger("propertyDeleted", this.model);
                this.remove();
            },

            updateKey: function() {
                this.model.key = this.$("#propKey").val();
            },

            updateValue: function() {
                this.model.value = this.$("#propValue").val();
            },

            serialize: function() {
                return {
                    key: this.model.key,
                    value: this.model.value
                };
            }
        });

        return action;
    });