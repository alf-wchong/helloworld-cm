define([
	"app",
	"modules/common/tossacross",
	"sendemail"
], function(app, TossAcross, SendEmail) {
	"use strict";
    var SendCombinedCollectionEmailCustomConfigView = {};

    SendCombinedCollectionEmailCustomConfigView.View = SendEmail.CustomConfigView.extend({
        initialize: function(){
			SendCombinedCollectionEmailCustomConfigView.View.__super__.initialize.apply(this, arguments);
			var self = this;

			this.collectionActionConfig = true;
            // Clear the stuff that was already populated upon a change and before rebuilding.
			this.viewModel.availableNameAttributes = new Backbone.Collection();
			this.viewModel.selectedNameAttributes = new Backbone.Collection();
            
            this.fetchAvailableNameAttributesDeferred = $.Deferred();

            app.context.configService.getAdminTypeConfig("Collection", function(typeConfig){
                _.each(typeConfig.get("attrs").models, function(attr) {
                    if ( $.inArray(attr.get("ocName"), _.pluck(self.viewModel.model().get("nameAttrsToDisplay"), 'attrValue')) === -1 ) {
                        self.viewModel.availableNameAttributes.push({
                            'attrName': attr.get("label"),
                            'attrValue': attr.get("ocName")
                        });
                    }
                });
                self.fetchAvailableNameAttributesDeferred.resolveWith(self);
            });

			// Listener that controls any movements to the attributes selected as the doc name for collections
			this.stopListening(this.viewModel.selectedNameAttributes, 'add remove reset');
			this.listenTo(this.viewModel.selectedNameAttributes, 'add remove reset', function(){
				var newObjectProps = [];
				_.each(self.viewModel.selectedNameAttributes.models, function(model){
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue});
					} else {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue')});
					}
				});
				self.viewModel.model().set("nameAttrsToDisplay", _.extend([], newObjectProps));
			}, this);
			// check if there are any previously saved selectd attributes 
			if(this.viewModel.model().get("nameAttrsToDisplay")){
				_.each(this.viewModel.model().get("nameAttrsToDisplay"), function(attr){				
					if(!attr.attributes){
						self.viewModel.selectedNameAttributes.add({
							'attrName': attr.attrName,
							'attrValue': attr.attrValue
						});
					}else{
						self.viewModel.selectedNameAttributes.add({
							'attrName': attr.attributes.attrName,
							'attrValue': attr.attributes.attrValue
						});
					}
				});
			} else {
				this.viewModel.model().set("nameAttrsToDisplay", {});
            }
            
            this.fetchAvailableNameAttributesDeferred.done(this.buildNameTossAcross);
		},
		setupDefaults: function() {
			// tells us if its our first time setting up these configs so we need to set a default
			var initializeCollectionAttachmentsTab =  this.viewModel.collectionAttachmentsTab() === null;
			var initializeHideAvailableDocsTab =  this.viewModel.hideAvailableDocsTab() === null;

			// call the super to set everything up then overwrite the defaults we want to change
			// for collection actions
			SendCombinedCollectionEmailCustomConfigView.View.__super__.setupDefaults.apply(this, arguments);

			//default collection attachments tab to false
			if(initializeCollectionAttachmentsTab){
				this.viewModel.collectionAttachmentsTab("false");
			}
			// default hideAvailableDocsTab to true
			if (initializeHideAvailableDocsTab){
				this.viewModel.hideAvailableDocsTab("true");
			}
		},
		buildNameTossAcross: function(){
			var tossAcross = new TossAcross.Layout({
				srcCollection: {
					title: window.localize("modules.common.tossAcross.availableAttributes"),
					filter: true,
					labelAttr: 'attrName',
					collection: this.viewModel.availableNameAttributes
				},
				targetCollections: [
					{
						title: window.localize("modules.common.tossAcross.selectedAttributes"),
						labelAttr: 'attrName',
						collection: this.viewModel.selectedNameAttributes
					}
				]
			});
			
			this.setView(".sendEmail-doc-name-toss-across-outlet", tossAcross).render();
		},
        afterRender: function(){
			SendCombinedCollectionEmailCustomConfigView.View.__super__.afterRender.apply(this, arguments);
            // need this for filtering to work 
            this.fetchAvailableNameAttributesDeferred.done(this.buildNameTossAcross);
        }
    });
	
	return SendCombinedCollectionEmailCustomConfigView;
});