define([
  // Application.
  "app",
  "knockout",
  "knockback"
],

  // Map dependencies from above array.
  function (app, ko, kb) {
    window.localize("modules.hpiAdmin.actionConfig.otherProperties.useStrict");
    // Create a new module.
    var Otherproperties = app.module();

    // Relatedobjects.
    Otherproperties.Model = Backbone.RelationalModel.extend();

    // Return the module for AMD compliance.
    return Otherproperties;
  });
