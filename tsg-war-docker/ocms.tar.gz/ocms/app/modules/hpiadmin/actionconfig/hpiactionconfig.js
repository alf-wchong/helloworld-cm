define([
	"app",
	"knockout",
	"knockback",
	"modules/actions/actionmodules"
],
function(app, ko, kb, actionModules) {
	
	"use strict";
	
	var Action = app.module();

	Action.ExtraProperty = Backbone.Model.extend({});

	Action.ExtraPropertyCollection = Backbone.Collection.extend({
		model: Action.ExtraProperty
	});

	Action.Model = Backbone.Model.extend({
		defaults: function() {
			return {
				modalSize: undefined,
				modalBackdrop: undefined,
				keyboard: undefined,
				paneSize: undefined,
				autoLaunch: undefined,
				whyCantI: undefined,
				subTitle: undefined,
				instantExecute: "false",
				otherProperties: new Backbone.Collection(null, { model: Backbone.ExtraProperty })
			};
		},
		initialize: function (options) {
			this.actionId = this.attributes.actionId;
			if(options && options.otherProperties) {
				this.attributes.otherProperties = new Action.ExtraPropertyCollection(options.otherProperties);
			} else {
				this.set("otherProperties", new Action.ExtraPropertyCollection());
			}
			if(options && options.ocActionId) {
				this.ocActionId = options.ocActionId;
			}
		}
	});

	// default collection
	Action.Collection = Backbone.Collection.extend({
		model: Action.Model,
		url: "#"
	});

	Action.getAvailableActions = function(callback) {
		Backbone.ajax({
			type: "GET",
			url: app.serviceUrlRoot + "/action/available",
			success: function(availableActions) {
				callback(availableActions);
			},
			error: function(jqXHR) {
				var date = new Date(), 
					bodyText = window.localize("modules.hpiAdmin.actionConfig.hpiActionConfig.unableToGet") + jqXHR.responseText + " - " + date;
				app.trigger("alert:error", {
					header : (window.localize("modules.hpiAdmin.actionConfig.hpiActionConfig.errorRetrieving")),
					message : bodyText
				});
			}
		});
	};

	Action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/default",
		initialize: function() {
			var vm = this.options.viewModel;
			vm.addProp = function() {
				var act = vm.model();
				act.get("otherProperties").push(new Action.ExtraProperty({ key: "", value: "" }));
			};
			vm.deleteProperty = function(propToDelete) {
				var key = propToDelete.__kb.object.attributes.key;
				var act = vm.model();
				_.each(act.get("otherProperties").models, function(model) {
					if(model.attributes.key === key) {
						act.get("otherProperties").remove(model);
					}
				});
			};
		},
		afterRender: function() {
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});

	Action.ConfigViewModel = function(model, options) {
		var self = this;

		// don't change, we need to have ko stamp the id on teh div
		// or jquery can find it in 2 places (the tempalte and the runtime)
		self.outlet = "custom-action-config-outlet";
		self.showEditAction = ko.observable(false);
		self.hideEditAction = function() {
			self.showEditAction(false);
		};

		// this is used to indicate whether the config itself is a header config (i.e. Application config)
		self.isHeaderMode = ko.observable(false);
		if(options.isHeaderMode) {
			self.isHeaderMode(options.isHeaderMode);
		}

		self.whyCantILabel = kb.observable(model, "whyCantILabel");
		if (!self.whyCantILabel()) {
			self.whyCantILabel("Why Can't I");
		}

		self.whyCantIIcon = kb.observable(model, "whyCantIIcon");
		if (!self.whyCantIIcon()) {
			self.whyCantIIcon("question-sign");
		}

		// the configured actions
		self.actions = kb.collectionObservable(model.get("actions") || new Backbone.Collection());
		// the actions available on the server
		self.serverActions = ko.observableArray();

		self.availableActions = ko.observableArray([]);
		
		self.updateActions = function() {
			var array = [];
			_.each(self.serverActions(), function(sAct) {
				var found = false;
				_.each(self.actions(), function(oAct) {
					if(sAct.name === oAct.actionId()) {
						found = true;
					}
				});
				if(!found) {
					array.push(sAct);
				}
			});
			array.sort(function(a,b) {
				if(a.name < b.name) {return -1;}
				if(a.name > b.name) {return 1;}
				return 0;
			});
			self.availableActions(array);
		};

		// this represents the action the user clicked on to add to the configured actions
		self.actionToAdd = ko.observable();
		// this is bound to the "Available [Header] Actions" list and will get fired everytime the user selects an action to add
		self.actionToAdd.subscribe(function(actionToAdd) {
			// this will be undefined if this subscription is triggered with no elements left in the select box
			if(actionToAdd) {
				// call our function to add this action to the configured actions
				self.newAction(actionToAdd);	
			}
		});

		self.newAction = function(clickedAction) {
			// using the name, look up the template and add away
			var oldActionLength = self.actions().length;
			if(clickedAction) {
				var defaultConfig = actionModules.getDefaultConfig(clickedAction.name);
				var actionToAdd = new Action.Model(defaultConfig);
				actionToAdd.set("actionId", clickedAction.name);
				actionToAdd.description = clickedAction.description;
				var ocActionId = clickedAction.ocActionId;
				if(!ocActionId) {
					//if for some reason ocActionId isn't set on the action model
					//when it is created, we will use the actionModule config to
					//set it
					ocActionId = defaultConfig.ocActionId || defaultConfig.actionId;
				}
				actionToAdd.set("ocActionId", ocActionId);
				// this is used to indicate whether the actions added are in header mode
				if(options.isHeaderMode) {
					actionToAdd.set("isHeaderMode", options.isHeaderMode);
				} else { // default actions to false for header mode
					actionToAdd.set("isHeaderMode", false);
				}
				model.get("actions").add(actionToAdd);
				self.updateActions();
				self.editAction(self.actions()[oldActionLength]);
			}
		};

		self.deleteAction = function(actionVM) {
			var act = actionVM.model();
			model.get("actions").remove(act);
			if(self.selectedAction() === actionVM) {
				self.selectedAction(undefined);
				// because below they couldn't use setView to set the customconfigview on the outlet, I can't
				// use getView and then remove to empty the outlet. Instead I'm using jQuery to empty out the outlet
				if(!$('#custom-action-config-outlet').is(":empty")) {
					$('#custom-action-config-outlet').empty();
				}
			}
			self.updateActions();
		};
		self.selectedAction = ko.observable();

		self.currentActionDescription = ko.observable();
		self.currentActionConditionDescriptions = ko.observableArray();

		self.selectedAction.subscribe(function(newVal) {
			if(undefined === newVal || null === newVal) {
				self.currentActionDescription("");
				self.currentActionConditionDescriptions([]);
				return;
			}
			var serverAction =  _.find(self.serverActions(), function(serverAction) {
				return newVal.actionId() === serverAction.name;
			}); 

			self.currentActionDescription(serverAction.description);

			var conditionDescriptions = [];
			$.each(serverAction.requiredConditionEvaluatorList, function(idx, strVal) {
				if(strVal.match(" - ")) {
					conditionDescriptions.push(strVal.split(" - ")[1]);
				} else {
					conditionDescriptions.push(strVal);
				}
			});

			self.currentActionConditionDescriptions(conditionDescriptions);
		});


		//get available actions
		Action.getAvailableActions(function(data) {

			var actionConfigs = actionModules.getAllRegisteredActionConfigs();
			var availableActions = {};

			_.each(actionConfigs, function(action, actionName){
				//for compatability, we default to actionId if ocActionId doesn't exist
				var actionId = actionConfigs[actionName].ocActionId || actionConfigs[actionName].actionId;
				var ocActionIds = actionId && _.filter(_.keys(data), function(key) {
					//we want our hpi action id and oc action id to either match exactly 
					//or be '${actionName}-noContext' so either 'checkout' or 'checkout-noContext' 
					//will match 'checkout'
					//'checkout-controlleddoc' will only match 'checkout-controlleddoc'
					if(key === actionId){
						//exact match
						return true;
					} else if(key.indexOf("noContext") !== -1 && key.indexOf(actionId) === 0){
						//noContext match
						return true;
					}
						return false;
					}
				);
				if(ocActionIds) {
					_.each(ocActionIds, function(ocActionId) {
						if (options.showGroupActions && data[ocActionId].group) {
							availableActions[actionName] = _.extend({}, data[ocActionId], {"ocActionId" : ocActionId});
							availableActions[actionName].description = window.localize(availableActions[actionName].description);
						} else if (self.isHeaderMode() && ocActionId.indexOf('noContext') !== -1) {
							availableActions[actionName] = _.extend({}, data[ocActionId], {"ocActionId" : ocActionId});
							availableActions[actionName].description = window.localize(availableActions[actionName].description);
						} else if (!self.isHeaderMode() && !options.showGroupActions && !data[ocActionId].group && ocActionId.indexOf('noContext') === -1) {
							availableActions[actionName] = _.extend({}, data[ocActionId], {"ocActionId" : ocActionId});
							availableActions[actionName].description = window.localize(availableActions[actionName].description);
						}
					});
				}
				if (availableActions[actionName] && !availableActions[actionName].name) {
					availableActions[actionName].name = actionName;
				}
			});

			self.serverActions.removeAll();
			self.serverActions(availableActions);
			self.updateActions();
		});

		return this;
	};


	Action.View = Backbone.Layout.extend({
		template : "hpiadmin/actions/actionconfig",
		initialize: function(){
			//we expect a view model was provided
			if(!this.options.viewmodel || !this.model){
				app.log.error(window.localize("modules.hpiAdmin.actionConfig.hpiActionConfig.actionConfig") + 
				window.localize("modules.hpiAdmin.actionConfig.hpiActionConfig.backoneRelational"));
				return;
			}

			var tracName = this.options.viewmodel.name();
			var availableObjectTypes = this.options.availableObjectTypes;

			var defaults = {
				showGroupActions :  true,
				showSingleActions : true
			};
			_.defaults(this.options, defaults);
			var actionconfig = new Action.ConfigViewModel(this.model, this.options);
			actionconfig.editAction = function(actionVM){
				actionconfig.selectedAction(actionVM);
				actionconfig.showEditAction(true);
				//attach the customConfig view (or default) with the whole view model
				var CustomView = (actionModules.getAction(actionVM.actionId()) && actionModules.getAction(actionVM.actionId()).CustomConfigView) || Action.CustomConfigView;
				//The ^ Capital is the constructor 
				var customView = new CustomView({viewModel : actionVM, trac : tracName, availableObjectTypes: availableObjectTypes});
				customView.render();
				//because this main config view is technnically backed by a template using the normal
				//setView doesn't work. I wouldn't recommend imitating this, but it's the admin so i'm leaving it.
				$('#custom-action-config-outlet').empty();
				$('#custom-action-config-outlet').append(customView.$el);

			};

			//this should be the only place we interact wtih the provided viewmodel
			this.options.viewmodel.actionConfig = actionconfig;
		},
		beforeRender : function(){
			//this template is only needed once, we'll pull if from the DOM if it's already there
			$('#action-config-template').remove();
		},
		afterRender: function() {
			self.$('[data-toggle="tooltip"]').tooltip();
		}
	});

	/*needed to be removed and added to actionmodules.js and renamed as actionConfigDefaults
	Action.optionDefaults = {

	};*/

	// Return the module for AMD compliance.
	return Action;

});