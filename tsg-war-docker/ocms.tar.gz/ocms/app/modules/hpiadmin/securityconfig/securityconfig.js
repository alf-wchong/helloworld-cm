// Objecttypeconfig module
define([
	"app",
	"modules/hpiadmin/hpiadmin",
	"modules/hpiadmin/securityconfig/securedtrac"
],

function(app, Hpiadmin, Securedtrac) {
	"use strict";

	var Securityconfig = app.module();

	// Default Model.
	Securityconfig.Model = Hpiadmin.Config.extend({
		type: "SecurityConfig",
		defaults : {
			type : "SecurityConfig"
		},
		initialize: function(options) {
			//Backbone doesn't support nesting Collections in Models OOTB, this initialize
			//lets us setup our internal collection
			if (options && options.securedTracs) {
				this.set("securedTracs", new Securedtrac.Collection(options.securedTracs));	
			} else {
				this.set("securedTracs", new Securedtrac.Collection());
			}
		},
		parseResponse: function(response) {
			//if this is the first time this config is loaded (id will be undefined),
			//then we need to build up the secured tracs without overwriting the
			//one that has already been init'ed. if the id is already present, then
			//the parse was hit after a save, and we are confident that the model we
			//already have is what is returned from the server, so remove config model
			//info from the response
			if (this.id) {
				response = _.pick(response, 'id');
			} else if (response && response.securedTracs) {
				this.set("securedTracs", new Securedtrac.Collection(response.securedTracs));
				delete response.securedTracs;
			}

			return response;
		}
	});

	Securityconfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/securityconfig/securityconfig",
		className: "securityConfig",
		events: {
			"click #unconfigured-secured-tracs li": "addSecuredTrac",
			"click #savesecurity-btn": "saveSecurity"
        },
		initialize: function() {
			var that = this;
			if(this.model.get("name")){
				//we are in 'edit' mode
				this.listenTo(this.model, "sync", function(){
					that.render();
				});
				this.listenTo(this.model.get("securedTracs"), "add", function(){
					that.render();
				});
				this.listenTo(this.model.get("securedTracs"), "remove", function(){
					that.render();
				});
			}

			app.context.configService.getTracConfigs(function(tracConfigs) {
				that.allTracs = tracConfigs.map(function(tracConfig) {
					return { 
						tracName: tracConfig.get("name"),
						tracLabel: tracConfig.get("displayName")
					};
				});
				$.ajax({
					url: app.serviceUrlRoot + "/groups",
					type: "GET",
					success: function(groups) {
						that.groupNames = _.pluck(groups, "authorityId");

						that.setViews({
							"#securedtraccollection-outlet": new Securedtrac.Views.Collection({
								collection: that.model.get("securedTracs"),
								groupNames: that.groupNames
							})
						});
							
						that.render();
					}
				});
			}, function() {}, true);
		},
		beforeRender : function() {
			var that = this;
			
			that.tracs = _.reject(that.allTracs, function(trac) {
				return _.contains(that.model.get("securedTracs").pluck("tracName"), trac.tracName);
			});
		},
		serialize: function() {
			var createMode = false;
			if(!this.model.get("name")){
				createMode = true;
			}

			return {
				createMode: createMode,
				cid: this.cid,
				tracs: this.tracs
			};
		},
		addSecuredTrac: function(event){
			var that = this, tracName = event.target.id.split("~|~")[0];

			var tracInfo = _.find(that.allTracs, function(trac) {
				return trac.tracName === tracName;
			});

			that.model.get("securedTracs").add(new Securedtrac.Model({
				tracName: tracInfo.tracName,
				tracLabel: tracInfo.tracLabel,
				allowedGroups: []
			}));
		},
        saveSecurity: function() {
			var that = this;

			that.model.save({}, {
				success: function() {
					app.trigger("modelSaveOrDestroy");
					Backbone.history.navigate("admin/SecurityConfig", {replace: true, trigger: true});
					app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
				},
				error: function() {
					app.trigger("alert:error", {
						header : window.localize("generic.errorSavingConfig"),
						message : window.localize("generic.configSaveFailed")
					});
				}
			});
		}
	});
	
	return Securityconfig;

});
