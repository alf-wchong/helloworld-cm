// Formtype module
define([
	"app",
	"handlebars"
],

// Map dependencies from above array.
function(app, Handlebars) {

	// Create a new module.
	var Securedtrac = app.module();

	Securedtrac.Model = Backbone.Model.extend({
		defaults: {
			tracName: "",
			tracLabel: "",
			allowedGroups: []
		}
	});
	
	Securedtrac.Collection = Backbone.Collection.extend({
		model: Securedtrac.Model
	});

	// Default View.
	Securedtrac.Views.Model = Backbone.Layout.extend({
		template: "hpiadmin/securityconfig/securedtracmodel",
		events: {
			"click .hpi-section-header": "toggleVisibility",
			"click .btn.delete-securedtrac": "removeSecuredTrac",
			"keyup .filter-groups-input": "filterGroups",
			"change .unconfigured-groups-select": "addGroup",
			"click span.icon-delete": "removeGroup"
		},
		initialize: function(options) { 
			this.ui = {};
			this.allGroupNames = this.options.groupNames;
			this.filterValue = "";
			this.filteredGroups = this.unconfiguredGroups = this.allGroupNames.sort();
		},
		serialize: function(){
			return {
				cid: this.cid,
				tracLabel: this.model.get("tracLabel"),
				filterValue: this.filterValue,
				filteredGroups: this.filteredGroups,
				allowedGroups: this.model.get("allowedGroups")
			};
		},
		afterRender: function() {
			// set up some dom elements
			this.ui.content = this.$(".hpi-section-content");
		},
		toggleVisibility: function(e) { 
			this.ui.content.toggleClass("hidden");
			this.$(".filter-groups-input").focus(function(){
				this.selectionStart = this.selectionEnd = this.value.length;
			});
			this.$(".filter-groups-input")[0].focus();
		},
		removeSecuredTrac: function(e) {
			app.trigger("Securedtrac:remove", this.model);
		},
		filterGroups: function(e) {
			var that = this;
			that.filterValue = that.$(".filter-groups-input")[0].value;

			that.filteredGroups = _.filter(that.unconfiguredGroups, function(groupName) { 
				return (groupName.toLowerCase().indexOf(that.filterValue.toLowerCase()) !== -1);
			}).sort();
				
			that.render().promise().done(function() {
				that.toggleVisibility();
			});
		},
		addGroup: function(e) {
			var that = this;
			// loop over each of the selected options (this is a multiple select box)
			that.$("option:selected").each(function() {
				var groupName = this.value;

				//update our model and the filteredGroups list for rendering
				that.model.get("allowedGroups").push(groupName);
			});

			that.unconfiguredGroups = _.difference(that.allGroupNames, that.model.get("allowedGroups"));
			that.filterGroups();
		},
		removeGroup: function(e) {
			var that = this;
			var groupName = e.target.parentElement.id.split("~|~")[0];

			that.model.set("allowedGroups", _.without(that.model.get("allowedGroups"), groupName));

			that.unconfiguredGroups = _.difference(that.allGroupNames, that.model.get("allowedGroups"));
			that.filterGroups();
		}
	});

	Securedtrac.Views.Collection = Backbone.Layout.extend({
		template: "hpiadmin/securityconfig/securedtraccollection",
		initialize: function() {
			var that = this;

			that.listenTo(app, "Securedtrac:remove", function(model) {
				app.trigger("alert:confirmation", { 
					confirm: function() { 
						//remove the model passed in
						that.collection.remove(model);	
						that.render();
					},
					header: window.localize("modules.hpiAdmin.securityConfig.confirmDelete"),
					message: window.localize("modules.hpiAdmin.securityConfig.areYouSure")
				});
			});
		},
		beforeRender: function() {
			var that = this;

			if (that.collection && that.collection.length > 0) {
				that.collection.each(function(securedTrac) {
					that.insertView("#securedtraccollection-" + that.cid, new Securedtrac.Views.Model({
						model: securedTrac,
						groupNames: that.options.groupNames
					}));
				});
			}
		},
		serialize: function(){
			return {
				cid: this.cid
			};
		}
	});

	// Return the module for AMD compliance.
	return Securedtrac;

});