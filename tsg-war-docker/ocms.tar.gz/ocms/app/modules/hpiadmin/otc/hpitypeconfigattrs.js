// Hpitypeconfigattrs module
define([
	"app",
	"knockout",
	"knockback",
	"module",
	"modules/hpiadmin/otc/editcompositeattr",
	"modules/common/typeahead",
	"modules/common/spinner"
],

function(app, ko, kb, module, EditCompositeAttr, HPITypeahead, HPISpinner) {

	var Hpitypeconfigattrs = app.module();

	//Note: both checkMissingValues and markErros will look for configOCname's that are missing as well as configLabels.
	//In a normal instance, validation will not fire
	var checkMissingValues = function(isComposite) {
		var missingConfigNames, missingLabels;
		if (module.config().editMode || isComposite) {
			missingConfigNames = this.$('.configOcName').filter(function() {
				return !this.value;
			});
			missingLabels = this.$('.configLabel').filter(function() {
				return !this.value;
			});
			if (missingConfigNames.length === 0 && missingLabels.length === 0) {
				app.trigger("hpiTypeConfig:toggleSubmit", true);
			} else {
				app.trigger("hpiTypeConfig:toggleSubmit", false);
			}
		}
	};

	var markErrors = function() {

		//only check for configOcName if were in edit mode
		this.$('.configOcName').filter(function() {
			return !this.value;
		}).addClass('list-group-item-danger');
		this.$('.configLabel').filter(function() {
			return !this.value;
		}).addClass('list-group-item-danger');

	};

	// Default Model.
	Hpitypeconfigattrs.Model = Backbone.Model.extend({
		defaults: {
			label: "",
			ocName: "",
			composite: {},
			dataType: "",
			repoName: "",
			filter: "",
			repeating: false
		}
	});

	// Default Collection.
	Hpitypeconfigattrs.Collection = Backbone.Collection.extend({
		model: Hpitypeconfigattrs.Model,

		comparator: function(item) { 
			if (item.get("label") !== null) {
				return item.get("label").toLowerCase(); 
			}
			else {
				return "null";
			}
		}
	});

	//Controls the Hpitypeconfigattrss within the for each block of the hpitypeconfigattrs template.
	Hpitypeconfigattrs.ModelViewModel = function(options) {
		return kb.ViewModel.extend({
			constructor: function(model) {
				//adding this for model access in the collection viewmodel
				this.model = model;
				this.label = kb.observable(model, "label");
				this.dataType = kb.observable(model, "dataType");
				this.ocName = kb.observable(model, "ocName");
				this.nonMandatoryAspects = kb.observable(model, "nonMandatoryAspects");
				if (options.isComposite && !this.ocName()) {
					//if we are adding a new attrRow, lets give it a unique id. Otherwise, we already have one.
					this.ocName('ocName-' + model.cid);
				}
				this.repoName = kb.observable(model, "repoName");
				this.filter = kb.observable(model, "filter");
				this.repeating = kb.observable(model,"repeating");		
				//ko binding used for hbase when an attr is marked as readOnly. Not currently used in alfresco or dctm.
				//if in edit mode, default to readOnly
				this.hpiAdminReadOnly = kb.observable(model, { key: "hpiAdminReadOnly", 'default': !module.config().editMode });
				if (module.config().editMode || options.isComposite) {
					this.repeating = kb.observable(model, "repeating");
					if (!options.isComposite) {
						this.repoEditable = kb.observable(model, "repoEditable");
					}
				}
			}
		});
	};

	Hpitypeconfigattrs.CollectionViewModel = function(model) {
		var that = this;
		//if not in edit mode, default to showing all system attributes
		that.showSystemAttributes = kb.observable(model, { key: "showSystemAttributes", 'default': !module.config().editMode });
		that.toggleSystemAttributesText = ko.observable(window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.hideSystemAttr"));
		that.hpiTypeConfigsAttrs = kb.collectionObservable(model.get("attrs"), {
			factories: {
				"models" : Hpitypeconfigattrs.ModelViewModel({"isComposite" : model.get("isContainer") === 'Composite' ? true : false})
			}
		});
		that.label = kb.observable(model, "label");
		that.ocName = kb.observable(model, "ocName");
		that.isContainer = kb.observable(model, "isContainer");
		that.index = kb.observable(model, "index");
		that.allProps = model.get("attrs").pluck("ocName");

		that.nonMandatoryAspects = ko.observableArray(model.get("nonMandatoryAspects"));

		that.addNonMandatoryAspect = function() {

			var addAspectView = new AddAspectView({ typeModel: model, nmac: app.context.currentAdminNMAC(), viewModel: that });
			app.trigger("alert:custom", { view: addAspectView });

			markErrors();
		};

		that.removeAspect = function(aspect) {
			that.nonMandatoryAspects.remove(aspect);
		};


		//this will remove the attribute model from the viewmodel
		that.removeAttr = function(attr) {
			app.trigger("alert:confirmation", {
				message: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.areYouSure"),
				header: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.confirmRemoval"),
				confirm: function() {
					that.hpiTypeConfigsAttrs.collection().remove(attr.model);
					checkMissingValues(model.get("isContainer") === 'Composite');
				}
			});
		};

		that.addAttr = function() {
			if (!module.config().editMode && model.get("isContainer") !== 'Composite') {
				var addAttrView = new AddAttrView({ typeModel: model, viewModel: that });
				app.trigger("alert:custom", { view: addAttrView });
			} else {
				var addEditAttrView = new AddEditAttrView({ typeModel: model, viewModel: that });
				app.trigger("alert:custom", { view: addEditAttrView });
				markErrors();
			}
		};

		that.editComposite = function(attr) {
			var editCompositeAttrView = new EditCompositeAttr.View({
				attrModel: attr.model
			});
			app.trigger('editCompositeAttr', editCompositeAttrView);
		};

		that.toggleSystemAttributes = function() {
			if (that.showSystemAttributes()) {
				that.showSystemAttributes(false);
				that.toggleSystemAttributesText(window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.showSystemAttr"));
			} else {
				that.showSystemAttributes(true);
				that.toggleSystemAttributesText(window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.hideSystemAttr"));
			}
		};

		that.removeType = function() {
			app.trigger("hpiTypeConfig:clickMinusForHpiTypeConfig", model);
		};

		that.reindexObjectType = function() {
			var resultsView = new Hpitypeconfigattrs.ReindexResultsView({
				objectType: that.ocName()
			});

			app.trigger("alert:custom", {
				view: resultsView
			});
		};

	};

	var AddAspectView = Backbone.Layout.extend({
		template: "hpiadmin/nmac/hpinonmandatoryaspectconfigattrs/addattrmodal",
		events: {
			'click #add-btn': 'add'
		},
		initialize: function(options) {
			var self = this;
			this.nmac = options.nmac;
			this.viewModel = options.viewModel;
			this.allConfiguredAspects = _.map(this.nmac.get('configs').models, function(aspect) { return aspect.attributes; });

			this.aspectsAlreadyOnType = this.viewModel.nonMandatoryAspects();

			this.remainingAspects = _.reject(this.allConfiguredAspects, function(aspect) {
				return _.contains(self.aspectsAlreadyOnType, aspect.ocName);
			});
		},
		add: function() {
			if (this.aspectToAdd !== null && ($.inArray(this.aspectToAdd.ocName, this.viewModel.nonMandatoryAspects()) < 0)) {
				// If you are adding a Date object type, set the filter to be "Date"                   
				this.viewModel.nonMandatoryAspects().push(this.aspectToAdd.ocName); 
				
				this.viewModel.nonMandatoryAspects.valueHasMutated();

				// remove the attribute that is added from list of available attributes to add 
				// unserscore without
				this.remainingAspects = _.without(this.remainingAspects, this.aspectToAdd);
			
				this.render();
			}
		},
		serialize: function() {
			return {
				type: this.options.typeModel.get("ocName")
			};
		},
		beforeRender: function(){
			// stop listening to avoid memory leaks
			this.stopListening(this.typeahead);

			// re instantiate typeahead with updated 'remainingAspects'
			this.typeahead = new HPITypeahead({
				options: this.remainingAspects,
				displayKey: 'ocName', 
				searchOn: 'ocName',
				isGrowable: false
			});
				
			this.listenTo(this.typeahead, 'change:selected', function(option){
				// NOTE: reason we are checking for ocName here is that onBlur of typeahead (For some reason) only the 'value' 
				// is passed back in the 'option' object
				if (option !== null && option.ocName) {
					this.aspectToAdd = option;
				}
			}, this); 

			this.setView('.add-aspect-outlet', this.typeahead);
		}
	});

	var AddEditAttrView = Backbone.Layout.extend({
		template: "hpiadmin/otc/hpitypeconfigattrs/addeditattrmodal",
		events: {
			'click #add-btn': 'add',
			'keyup #newAttrLabel': 'updateAddButton',
			'keyup #newAttrOcName' : 'updateAddButton'
		},
		initialize: function() {

		},
		updateAddButton: function() {
			// If both the ocName and label fields are filled, we toggle the 'add' button to enabled
			// otherwise it is disabled
			if (this.$('#newAttrLabel')[0].value.length > 0 && this.$('#newAttrOcName')[0].value.length > 0) {
				this.$('#add-btn').removeAttr('disabled');				
			} else {
				this.$('#add-btn').attr('disabled', 'disabled');
			}
		},
		add: function() {
			var model = this.typeModel;
			if (model.get("isContainer") !== 'Composite') {
				this.options.viewModel.hpiTypeConfigsAttrs.collection().add(
					new Hpitypeconfigattrs.Model({
						label: this.$('#newAttrLabel')[0].value,
						ocName: this.$('#newAttrOcName')[0].value,
						dataType: this.$('#newAttrDataType')[0].value,
						repoName: '',
						filter: this.$('#newAttrFilter')[0].value,
						hpiAdminReadOnly: false,
						repeating: this.$('#newAttrRepeating')[0].checked,
						repoEditable: this.$('#newAttrRepoEditable')[0].checked
					}), { at: 0 }
				);
			} else {
				this.options.viewModel.hpiTypeConfigsAttrs.collection().add(
					new Hpitypeconfigattrs.Model({
						label: this.$('#newAttrLabel')[0].value,
						ocName: this.$('#newAttrOcName')[0].value,
						dataType: this.$('#newAttrDataType')[0].value,
						repoName: '',
						filter: this.$('#newAttrFilter')[0].value,
						hpiAdminReadOnly: false,
						repeating: this.$('#newAttrRepeating')[0].checked
					}), { at: 0 }
				);
			}
			app.trigger("alert:close");			
			this.render();
		},
		serialize: function() {
			return {
				type: this.options.typeModel.get("ocName"),
				properties: this.allAttrs
			};
		}
	});
	var AddAttrView = Backbone.Layout.extend({
		template: "hpiadmin/otc/hpitypeconfigattrs/addattrmodal",
		events: {
			'click #add-btn': 'add',
			'click #addAnother-btn': 'addAnother'
		},
		initialize: function() {
			var that = this;
			var type = this.options.typeModel.get("ocName");
			that.allAttrs = [];
			that.exisitngAttrs = _.map(that.options.typeModel.get("attrs").models, function(attr) {
				return attr.get("ocName");
			});
			$.ajax({
				url: app.serviceUrlRoot + "/dictionary/type?type=" + type,
				success: function(fullType) {
					that.fullType = fullType;
					that.allAttrs = fullType.allProperties;

					//we don't want to add any attrs already on the model
					that.allAttrs = _.reject(that.allAttrs, function(attr) {
						return _.contains(that.exisitngAttrs, attr.ocName);
					});

					that.allAttrs.sort(function(a, b) {
						return a.ocName.localeCompare(b.ocName);
					});
					that.render();
				}
			});

		},
		addAnother: function() {
			var ocProp = this.$('#newProp-select').val();
			var prop = _.findWhere(this.allAttrs, { ocName: ocProp });
			// If you are adding a Date object type, set the filter to be "Date"
			var filter = prop.dataType === "date" ? "date" : "";
			this.options.viewModel.hpiTypeConfigsAttrs.collection().add(
				new Hpitypeconfigattrs.Model({
					label: prop.label,
					ocName: prop.ocName,
					dataType: prop.dataType,
					repoName: prop.repoName,
					repeating: prop.repeating,
					filter: filter,
					repoEditable: prop.repoEditable
				}), { at: 0 });

			this.allAttrs = _.without(this.allAttrs, prop);
			this.render();
			app.trigger("alert:close");
		},
		add: function() {
			this.addAnother();
			app.trigger("alert:close");
		},
		serialize: function() {
			return {
				type: this.options.typeModel.get("ocName"),
				properties: this.allAttrs
			};
		}
	});

	Hpitypeconfigattrs.View = Backbone.View.extend({
		template: "hpiadmin/otc/hpitypeconfigattrs/hpitypeconfigattrs",
		events: {
			"keyup .configOcName": "updateValidation",
			"keyup .configLabel": "updateValidation",
			"click .edit-composite-attr": "editComposite"
		},
		initialize: function() {
			this.ui = {};


			//if we have composite types, we need to listen to our edit trigger
			this.listenTo(app, 'editCompositeAttr', function(editCompositeAttrView) {
				editCompositeAttrView.compositeTypes = this.model.attributes.compositeTypes;
				editCompositeAttrView.collection = this.model.collection;
				this.setView(".edit-composite-outlet-" + editCompositeAttrView.attrModel.get('ocName'), editCompositeAttrView).render();
			});

		},
		updateValidation: function(event) {
			if (module.config().editMode || this.model.get("isContainer") === "Composite") {
				//if we added a brand new row, there will be blank values and this will mark them errored accordingly
				if (event.target.value.trim().length > 0) {
					this.$(event.currentTarget).removeClass('list-group-item-danger');
				} else {
					this.$(event.currentTarget).addClass('list-group-item-danger');
				}
				checkMissingValues(this.model.get("isContainer") === "Composite");
			}
		},
		afterRender: function() {
			if (this.viewModel) {
				ko.cleanNode(this.$el[0]);
				kb.release(this.viewModel);
			}

			this.ui.ocInfo = this.$(".configs-tooltip.ocInfo");
			//add popover to icon for glyphicons
			this.ui.ocInfo.popover({
				placement: 'top',
				trigger: 'hover',
				title: 'OC Name',
				html: true,
				content: "<p> The OC Name for each Composite is generated with a unique ID to avoid replacing attributes.</p>",
				delay: { show: 500 }
			});


			this.ui.tooltip = this.$(".configs-tooltip.containerInfo");
			//add popover to icon for glyphicons
			this.ui.tooltip.popover({
				placement: 'top',
				trigger: 'hover',
				title: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.isContainer"),
				html: true,
				content: "<p>" + window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.thisShouldBe") + "</p>",
				delay: { show: 500 }
			});

			this.$('[data-toggle="popover"]').popover();

			this.viewModel = new Hpitypeconfigattrs.CollectionViewModel(this.model);
			kb.applyBindings(this.viewModel, this.$el[0]);

			if (module.config().editMode || this.model.get("isContainer") === "Composite") {
				//if we added a brand new row, there will be blank values and this will mark them errored accordingly
				markErrors();
				//trigger the submit to disabled since we just added unfilled out fields
				checkMissingValues(this.model.get("isContainer") === "Composite");
			}
		},
		serialize: function() {
			return {
				'editModeEnabled': module.config().editMode,
				'compositeType': this.model.get("isContainer") === "Composite",
				'enableIndexing': module.config().enableIndexing
			};
		}
	});

	Hpitypeconfigattrs.ReindexResultsView = Backbone.Layout.extend({
		template: "hpiadmin/otc/hpitypeconfigattrs/reindexResults",
		initialize: function(options) {
			this.objectType = options.objectType;
			this.currentlyReindexing = true;

			var date = new Date();
			$.ajax({
				url: app.serviceUrlRoot + "/externalIndex/reindexExternalSearch?objectType=" + this.objectType + "&key=" + date.getTime() + "&dropTable=true",
				type: "POST",
				global: false,
				context: this,
				success: function(results) {
					this.results = results;
				},
				statusCode: {
					409: function(){ 
						var message = window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.409message");
							app.trigger("alert:error", {
							header: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.errorReindexing"),
							message: message
						});
					}
				},
				complete: function() {
					this.currentlyReindexing = false;
					HPISpinner.destroySpinner(this.spinner);
					this.render();
				}
			});
		},
		afterRender: function() {
			if(this.currentlyReindexing) {
				var spinElem = this.$(".reindexingSpinner")[0];
				this.spinner = HPISpinner.createSpinner({
					color: '#b6b6b6',
					length: 32, 
					width: 8, 
					radius: 30,
				}, spinElem);
			}
		},
		serialize: function() {
			return {
				results: this.results,
				objectType: this.objectType,
				currentlyReindexing: this.currentlyReindexing
			};
		}
	});

	return Hpitypeconfigattrs;

});