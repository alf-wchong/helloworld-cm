// Objecttypeconfig module
define([
	"app",
	'module',
	"modules/hpiadmin/otc/editcompositeattrtable",
	"handlebars"
],

function(app, module, EditCompositeAttrTable, Handlebars) {
	"use strict";

	var EditCompositeAttr = app.module();

	EditCompositeAttr.View = Backbone.Layout.extend({
		template: "hpiadmin/otc/editcompositeattr",
		events: {
			"click .edit-composite-attrs-panel": "clickFilterInput",
			"change .type-compositetype-input": "compositeTypeChange",
			"change .type-compositetype-attrInput": "compositeAttrChange",
			"click .add-composite-attr-row": "addCompositeAttrRow",
			"click button.close": "closeMenu"
		},
		initialize: function(options) {

			this.availableAttrs = [];

			Handlebars.registerHelper('isCurrentType', _.bind(this.isCurrentType,this));
			this.attrModel = options.attrModel;
			this.listenTo(app, 'removeCompositeAttrType', this.removeCompositeAttrType);

		},
		beforeRender: function(){
			this.compositeAttrTable = new EditCompositeAttrTable.View({
				model: this.attrModel
			});
			this.setView(
				".edit-compositeattr-table-outlet", this.compositeAttrTable
			).render();
			var tempSelectedTypes = [];
			if(this.options.attrModel.get('attrTable')) {
				tempSelectedTypes = this.options.attrModel.get('attrTable');
				this.compositeTypes = _.filter(this.compositeTypes, function(type) {
					return !_.contains(_.pluck(tempSelectedTypes, 'typeOCname'), type.typeOCname);
				});
			}

		},
		serialize: function(){
			return {
				availableTypes : this.compositeTypes,
				availableAttrs : this.availableAttrs,
				selectedType: this.selectedType
			};
		},
		isCurrentType: function(type, currentType, options){
			if(type === this.selectedType){
				return options.fn(this);
			}else{
				return options.inverse(this);
			}
		},
		clickFilterInput: function(e) {
			// just stop clicking on the content from hiding the dropdown menu (events wont bubble)
			e.stopPropagation();
		},
		compositeTypeChange: function(event){
			var attrArray = _.filter(this.collection.models, function(objectTypeModel){
				return (objectTypeModel.get('ocName') === event.target.value.split("$$")[0]);
			});
			this.availableAttrs = _.map(attrArray[0].get('attrs').models,function(model){
				return { label: model.get('label'), ocName: model.get('ocName')};
			});
			var currentType = event.target.value;
			currentType = currentType.split("$$");
			this.selectedType = currentType[0];
			this.selectedTypeLabel = currentType[1];
			this.render();
		},
		compositeAttrChange: function(event){
			var currentAttr = event.target.value;
			currentAttr = currentAttr.split("$$");
			this.selectedAttr = currentAttr[0];
			this.selectedAttrLabel = currentAttr[1];
			this.checkValidation();
		},
		checkValidation: function(){

			var self = this;
			if(this.selectedAttr.length > 0 && this.selectedType.length > 0){
				self.toggleSubmit(true);
			}else{
				self.toggleSubmit(false);
			}

		},
		toggleSubmit: function(enabled){
            if(enabled) {
                this.$('.add-composite-attr-row').removeAttr('disabled');
            }
            else {
                this.$('.add-composite-attr-row').attr('disabled','disabled');
            }
        },
		addCompositeAttrRow: function(event){
			var self = this;
			this.compositeAttrTable.addRow({
				typeOCname: this.selectedType,
				attrOCname: this.selectedAttr,
			 	typeLabel: this.selectedTypeLabel,
				attrLabel: this.selectedAttrLabel
			});
			this.compositeTypes = _.filter(this.compositeTypes,function(type){
                return type.typeOCname !== self.selectedType;
            });

            this.render();
		},
		removeCompositeAttrType: function(type) {
			var self = this;
			self.compositeTypes.push(type);
			this.render();
		},

		afterRender: function(){
		},
		closeMenu: function(e) {
			this.$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
		}
	});

	return EditCompositeAttr;

});
