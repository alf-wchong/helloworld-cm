// Objecttypeconfig module
define([
	"app",
	'module',
	"modules/hpiadmin/otc/hpitypeconfig",
	"modules/hpiadmin/otc/hpitypeconfigattrs"
],

function(app, module, Hpitypeconfig, Hpitypeconfigattrs) {
	"use strict";
	
	var CreateObjectType = app.module();

	CreateObjectType.View = Backbone.Layout.extend({
		template: "hpiadmin/otc/createobjecttypecontrol",
		events: {
			"click .create-type-input": "clickFilterInput",
			"click button.close": "closeMenu",
			"click .create-otc-type": "createType",
			"keyup .type-label-input": "updateTypeLabel",
			"keyup .type-ocName-input": "updateTypeOCName",
			"click .type-supertype-input": "updateTypeSupertype"
		},
		initialize: function() {
			this.collection.sort();
			this.typeLabel = '';
			this.typeOCName = '';
			this.typeContainer = '';
			this.typeSupertype = '';
			this.availableSupertypes = [];
			
			_.each(this.collection.models, function(model){
				this.availableSupertypes.push({
					'supertypeLabel': model.get("label"),
					'supertypeOCname' : model.get("ocName")
				});
			},this);
		},
		serialize: function(){
			return {
				availableSupertypes : this.availableSupertypes
			};
		},
		updateTypeLabel: function(event) { 
			this.typeLabel = event.target.value;
			if(this.typeLabel.trim().length > 0){
				this.$(event.currentTarget).removeClass('list-group-item-danger');
			}else{
				this.$(event.currentTarget).addClass('list-group-item-danger');
			}
			this.checkValidation();
		},
		updateTypeSupertype: function(event) { 
			this.typeSupertype = event.target.value;
			this.checkValidation();
		},
		updateTypeOCName: function(event) { 
			this.typeOCName = event.target.value;
			if(this.typeOCName.trim().length > 0){
				this.$(event.currentTarget).removeClass('list-group-item-danger');
			}else{
				this.$(event.currentTarget).addClass('list-group-item-danger');
			}
			this.checkValidation();
		},
		checkValidation: function(){
			var self = this;
			if(this.typeLabel.length > 0 && this.typeOCName.length > 0 && this.typeSupertype.length > 0){
				self.toggleSubmit(true);
			}else{
				self.toggleSubmit(false);
			}
		},
		toggleSubmit: function(enabled){
            if(enabled) {
                this.$('.create-otc-type').removeAttr('disabled');
            }
            else {
                this.$('.create-otc-type').attr('disabled','disabled');
            }
        },
		createType: function() { 
			var self = this;
			// we're going to build up an array of type config attrs 
			var typeConfigAttrs = [];
			
			// helper function to add a type config attribute to the array of typeConfigAttrs we're building
			var addTypeConfigAttr = function(prop) {
				//default the filter for all dataTypes of date to "date"
				var filter = prop.dataType === "date" ? "date" : "";
				typeConfigAttrs.push({
					label : prop.label,
					ocName : prop.ocName,
					dataType : prop.dataType,
					repoName : prop.repoName,
					repeating: prop.repeating,
					repoEditable: prop.repoEditable,
					hpiAdminReadOnly: prop.hpiAdminReadOnly,
					filter : filter
				});
			};
			
			// each time a new model is added to the config, see if that model's superType is already a part
			// of the collection of models for the config. If the superTypeName exists, we want to use the superType's
			// attributes that are already configured for the attributes the models have in common.
			this.collection.each(function(configModel) {
				if (configModel.get("label") === self.typeSupertype || configModel.get("ocName") === self.typeSupertype) {
					// we found our super type so loop through each of its attribute, find the corresponding attribute in the sub-type
					// and copy the attributes from the super type to the sub-type
					self.typeContainer = configModel.get("isContainer");
					configModel.get("attrs").each(function(attr) {
						//Add and Hpitypeconfigattrs Model for each property found on the supertype
						addTypeConfigAttr(attr.attributes);
					});
				}
			});
			// create our collection with our array of type config attrs
			var hpiAttrs = new Hpitypeconfigattrs.Collection(typeConfigAttrs).sort();
			
			// create our type config model now that we have our attrs for it
			this.collection.add(new Hpitypeconfig.Model({
				label: this.typeLabel,
				ocName: this.typeOCName,
				isContainer: this.typeContainer,
				repoTypeName: this.typeOCName,
                superType: this.typeSupertype,
				attrs: hpiAttrs
			}));
			
			//clear out values after were done with them incase they want to reopen the view
			this.resetForm();
		},
		resetForm: function(){
			this.$('.type-label-input')[0].value = '';
			this.$('.type-ocName-input')[0].value = '';
			this.$('.type-supertype-input')[0].value = '';
			this.$('.type-label-input').addClass('list-group-item-danger');
			this.$('.type-ocName-input').addClass('list-group-item-danger');
			this.typeLabel = '';
			this.typeOCName = '';
			this.typeContainer = 'false';
			this.typeSupertype = '';
		},
		clickFilterInput: function(e) {
			// just stop clicking on the content from hiding the dropdown menu (events wont bubble)
			e.stopPropagation();
		},
		closeMenu: function(e) { 
			this.$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
		}
	});

	return CreateObjectType;

});
