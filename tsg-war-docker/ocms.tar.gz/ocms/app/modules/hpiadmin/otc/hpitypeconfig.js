// Hpitypeconfig module
define([
	"app",
	"knockout",
	"knockback",
	"modules/hpiadmin/otc/repotype",
	"modules/hpiadmin/otc/hpitypeconfigattrs",
	"modules/common/alert/alert",
	"modules/hpiadmin/hpiadmin"

],

function(app, ko, kb, Repotype, Hpitypeconfigattrs, Alert, Hpiadmin) {

	var Hpitypeconfig = app.module();

	// Default Model.-- extends the hpi admin config to take advantage of the parse method that is there
	Hpitypeconfig.Model = Hpiadmin.Config.extend({
		defaults: {
			label: "",
			ocName: "",
			isContainer: "",
			repoTypeName: "",
			index: false,
			nonMandatoryAspects: []
		},
		idAttribute: "_id",
		url: function() {
			return Hpiadmin.configURLRoot + "config/?id=" + this.id;
		},
		initialize: function(options) {
			if (options && options.attrs) {
				if (options.attrs instanceof Backbone.Collection) {
					this.set("attrs", options.attrs);
				} else {
					this.set("attrs", new Hpitypeconfigattrs.Collection(options.attrs).sort());
				}
			} else {
				this.set("attrs", new Hpitypeconfigattrs.Collection());
			}
		},
		parseResponse: function(response) {
			if (response && response.attrs) {
				this.set("attrs", new Hpitypeconfigattrs.Collection(response.attrs).sort());
				delete response.attrs;
			}

			return response;
		},
		//cacheing the model after the first fetch to save some time
		//NOTE: if you end up wanting to copy this for another config, then we should move it to hpiadmin.config
		//that wiill have other implications so I'm holding off for now.
		fetch: function(options) {
			var that = this;
			//'adapted' from here https://gist.github.com/tbranyen/3950130
			options = options || {};
			// Save a reference to the original deferred.
			var oldDef = that._def;

			// Return early if we already fetched/there was no reload request
			if (that._def && !options.reload && !that.reload) {
				return that._def.promise();
			}

			// If a deferred doesn't exist, create one.  If the clear flag is provided,
			// jump in to create a new deferred.
			that._def = $.Deferred();

			// If the clear was provided and there is an existing deferred, resolve it
			// once this has resolved.
			if (options.reload && oldDef) {
				that._def.done(oldDef.resolve);
			}

			// Call the original `fetch` method and store its return value (jqXHR).
			var req = Backbone.Model.prototype.fetch.apply(that, arguments);

			// Once the request has finished, resolve this deferred.
			req.done(_.bind(function() {
				that._def.resolveWith(that, [that]);
			}, that));

			// Return the deferred to wait with.
			return that._def.promise();
		}
	});

	// Default Collection.
	Hpitypeconfig.Collection = Backbone.Collection.extend({
		model: Hpitypeconfig.Model,

		comparator: function(item) { return item.get("label").toLowerCase(); }
	});

	//Controls the Hpitypeconfigs within the for each block of the hpitypeconfig template.
	Hpitypeconfig.Model.ViewModel = function(model) {
		var that = this;
		that.cid = ko.observable(model.cid);
		that.label = kb.observable(model, "label");
		that.editing = ko.observable(false);
		that.onEditClick = function() {
			that.editing(!that.editing());
			var currentViewId = "#view" + that.cid();
			//the OTC is originally lazy loaded, we need to get all of the attrs now if
			//we haven't yet
			if (model.get("attrs").length === 0) {
				model.fetch({
					success: function(result) {
						app.log.debug("Full type config for " + that.label() + " fetched.");
						that.viewHelper(that.editing(), currentViewId);
					}
				});
			} else {
				that.viewHelper(that.editing(), currentViewId);
			}
		};
		that.viewHelper = function(editing, viewId) {
			if (editing) {
				app.layout.getView("#content-outlet").setView(viewId, new Hpitypeconfigattrs.View({ model: model })).render();
			} else {
				app.layout.getView("#content-outlet").removeView(viewId);
			}
		};
	};

	Hpitypeconfig.Collection.ViewModel = function(collection) {
		//Define a model factory for the collectionObservable. This lets the Model.ViewModel understand
		//the model it is manipulating when the for each is used in the template.
		var that = {};
		this.hpiTypeConfigs = that.hpiTypeConfigs = kb.collectionObservable(collection, {
			factories: {
				"models": Hpitypeconfig.Model.ViewModel
			}
		});

		this.onSaveClick = function() {
			app.trigger("hpiTypeConfig:onClickSaveConfig", collection);
		};
		this.onClearClick = function() {
			app.trigger("alert:confirmation", {
				header: window.localize("modules.hpiAdmin.otc.hpiTypeConfig.clearObjectType"),
				message: window.localize("modules.hpiAdmin.otc.hpiTypeConfig.youAreAbout"),
				confirm: function() {
					app.trigger("clearOtc:clickYes");
				}
			});
		};
	};

	Hpitypeconfig.View = Backbone.View.extend({
		template: "hpiadmin/otc/hpitypeconfig/hpitypeconfig",

		afterRender: function() {
			if (this.viewModel) {
				ko.cleanNode(this.$el[0]);
				kb.release(this.viewModel);
			}
			this.viewModel = new Hpitypeconfig.Collection.ViewModel(this.collection);
			kb.applyBindings(this.viewModel, this.$el[0]);
		},

		initialize: function() {
			this.collection.sort();

			//Everytime a repoType is clicked, we need to build a corresponding Hpitypeconfig for the view.
			this.listenTo(app, "repoType:click", function(model) {

				// we're going to build up an array of type config attrs 
				var typeConfigAttrs = [];

				// helper function to add a type config attribute to the array of typeConfigAttrs we're building
				var addTypeConfigAttr = function(prop) {
					//default the filter for all dataTypes of date to "date"
					var filter = prop.dataType === "date" ? "date" : "";
					typeConfigAttrs.push({
						label: prop.label,
						ocName: prop.ocName,
						dataType: prop.dataType,
						repoName: prop.repoName,
						filter: filter,
						repeating: prop.repeating						
					});
				};

				//Add and Hpitypeconfigattrs Model for each property found on the repoType
				_.each(model.get("allProperties"), function(prop) {
					addTypeConfigAttr(prop);
				});

				// each time a new model is added to the config, see if that model's superType is already a part
				// of the collection of models for the config. If the superTypeName exists, we want to use the superType's
				// attributes that are already configured for the attributes the models have in common.
				this.collection.each(function(configModel) {
					if (configModel.get("label") === model.get("superTypeName") || configModel.get("ocName") === model.get("superTypeName")) {
						// we found our super type so loop through each of its attribute, find the corresponding attribute in the sub-type
						// and copy the attributes from the super type to the sub-type
						configModel.get("attrs").each(function(attr) {
							// find the attribute on the sub-type
							var subAttr = _.find(typeConfigAttrs, function(typeConfigAttr) {
								return typeConfigAttr.ocName === attr.get("ocName");
							});

							// we may not have found one if this attribute only exists on the parent type
							if (subAttr) {
								// loop through each of the attribute's attrs and overrite / add to the sub-type's attributes
								_.each(attr.attributes, function(value, key) {
									// if the value is an array, we want to do a deep copy of it so any changes to the sub-type
									// will not affect the parent type
									if (_.isArray(value)) {
										subAttr[key] = $.extend(true, [], value);
									} else {
										subAttr[key] = value;
									}
								});
							} else {
								typeConfigAttrs.push(attr);
							}
						});
					}
				});

				// create our collection with our array of type config attrs
				var hpiAttrs = new Hpitypeconfigattrs.Collection(typeConfigAttrs).sort();

				// create our type config model now that we have our attrs for it
				this.collection.add(new Hpitypeconfig.Model({
					label: model.get("ocName"),
					ocName: model.get("ocName"),
					isContainer: "false",
					repoTypeName: model.get("ocName"),
					index: model.get("index"),
					attrs: hpiAttrs,
					nonMandatoryAspects: []
				}));
			});


			//Listen for the trigger that occurs after clicking the minus sign next to a row in Object Type
			//table, which signifies removing a model. Remove the model from the collection.
			this.listenTo(app, "hpiTypeConfig:clickMinusForHpiTypeConfig", function(model) {
				var currentViewId = "#view" + model.cid;
				app.layout.getView("#content-outlet").removeView(currentViewId);
				this.collection.remove(model);
			});

			//Listen for the trigger that occurs after text validation to toggle submit to true or false
			this.listenTo(app, "hpiTypeConfig:toggleSubmit", function(valid) {
				if (valid) {
					this.$('.saveConfig').removeAttr('disabled');
	            }
	            else {
					this.$('.saveConfig').attr('disabled', 'disabled');
				}
			});

			//Reset the collection of Hpitypeconfigs when the clearOtc button is pressed. If a Hpitypeconfig's
			//attributes were being edited at the time of the clear, remove the editing view.
			this.listenTo(app, "clearOtc:clickYes", function() {
				this.collection.reset();
				if (app.layout.getView("#content-outlet").getView("#hpiTypeConfigAttrs")) {
					app.layout.getView("#content-outlet").removeView("#hpiTypeConfigAttrs");
				}
			});

			//Whenever the collection of Hpitypeconfigs changes, trigger an event that the repoType View can
			//listen to in order to stay in sync.
			this.listenTo(this.collection, "add remove", function() {
				app.trigger("hpiTypeConfig:collectionChange", this.collection);

				this.collection.sort();
			});

			// The OTC can generate new TypeConfigs, which we add to the collection here.
			this.listenTo(app, "hpiTypeConfig:newTypeConfigAdded", function(newModel) {
				// First we check if was a previously added type.
				var previousVersionOfType = this.collection.findWhere({ ocName: newModel.get("ocName") });

				// If so, only add differences between the previously uploaded type and this new one.
				if (previousVersionOfType) {
					var newAttrs = newModel.get("attrs");
					newAttrs = newAttrs.models;

					var oldAttrs = previousVersionOfType.get("attrs");
					oldAttrs = oldAttrs.models;

					// Get the attributes from the new type's model that were not present on the type's existing model.
					newAttrs = _.reject(newAttrs, function(newAttr) {
						var matchingOldAttr = _.find(oldAttrs, function(oldAttr) {
							return newAttr.get("ocName") === oldAttr.get("ocName");
						});

						// If this attribute is an old one, then overwrite the old label.
						if (matchingOldAttr) {
							matchingOldAttr.set("label", newAttr.get("label"));
						}

						return matchingOldAttr;
					});

					// Finally add all the new attributes onto the type's existing model.
					previousVersionOfType.get("attrs").add(newAttrs);
				} else { // If not, just add it.
					this.collection.add(newModel);
				}
			});
		}
	});

	return Hpitypeconfig;

});
