define([
  "knockout",
  "modules/otc/objecttypeconfig"
],

// Map dependencies from above array.
function(ko, Objecttypeconfig) {

    /*
    * This event handler will present the list of available configs and 
    * allow users to select properties of documents in those configs
    * 
    * Should be used with a div element
    */
    ko.bindingHandlers.otcPropertyPicker = {
        init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
            
            // This will be called when the binding is first applied to an element
            // Set up any initial state, event handlers, etc. here
            
            //setup a list
            $(element).append('<ul id="selectedProperties"></ul><a class="btn" id="selectorBtn">Select Properties</a>');
            $("#selectorBtn").click(function(event){
            
            });
        },
        update: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
            // This will be called once when the binding is first applied to an element,
            // and again whenever the associated observable changes value.
            // Update the DOM element based on the supplied values here.
        }
    };
   
    //nothing here but be compliant
    return {}; 

});
