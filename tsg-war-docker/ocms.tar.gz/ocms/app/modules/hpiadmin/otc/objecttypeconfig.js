// Objecttypeconfig module
define([
        "app",
        'module',
        "knockout",
        "modules/hpiadmin/hpiadmin-switcher",
        "modules/hpiadmin/otc/repotype",
        "modules/hpiadmin/otc/hpitypeconfig",
        "modules/hpiadmin/otc/hpitypeconfigattrs",
        "modules/hpiadmin/otc/createobjecttype",
        "modules/hpiadmin/otc/createcompositetype",
        "modules/common/alert/alert",
        "modules/hpiadmin/hpiadmin",
        "modules/wizard/services/questionutils"
    ],

    function(app, module, ko, Switcher, Repotype, Hpitypeconfig, Hpitypeconfigattrs, CreateObjectType, CreateCompositeType, Alert, Hpiadmin, QuestionUtils) {
        "use strict";

        var Objecttypeconfig = app.module();

        // Default Model.
        Objecttypeconfig.Model = Hpiadmin.Config.extend({
            type: "ObjectTypeConfig",
            defaults: {
                type: "ObjectTypeConfig"
            },
            //in case we are ever just creating an otc model
            //like in unit tests...
            initialize: function(options) {
                if (options && options.configs) {
                    this.set("configs", new Hpitypeconfig.Collection(options.configs));
                } else {
                    this.set("configs", new Hpitypeconfig.Collection());
                }
            },
            parseResponse: function(response) {
                if (this.id) {
                    //just want the id
                    response = _.pick(response, 'id');
                } else if (response && response.configs) {
                    this.set("configs", new Hpitypeconfig.Collection(response.configs));
                    delete response.configs;
                }

                return response;
            }
        });

        //Collection of models
        Objecttypeconfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
            model: Objecttypeconfig.Model,
            initialize: function() {
                this.type = "ObjectTypeConfig";
            }
        });

        Objecttypeconfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/otc/objecttypeconfiglayout",
            events: {
                'click .addCompositeType': 'addCompositeType',
                'click .add-compositetype-outlet': 'clickFilterInput'
            },
            initialize: function() {
                var self = this;
                app.context.configService.getAdminNMAC(function() {

                    self.setViews({
                        ".add-type-outlet": new Objecttypeconfig.Views.Typecontrol({
                            collection: self.model.get("configs")
                        }),
                        "#hpiTypeConfigs": new Hpitypeconfig.View({
                            collection: self.model.get("configs"),
                            name: self.model.get("name")
                        }),
                        ".add-compositetype-outlet": new CreateCompositeType.View({
                            collection: self.model.get("configs")
                        })
                    }).render();
                    if (module.config().editMode) {
                        self.setViews({
                            ".create-type-outlet": new CreateObjectType.View({
                                collection: self.model.get("configs")
                            })
                        }).render();
                    }

                    //this will ensure the unconfigured repotype list is up-to-date
                    app.trigger("hpiTypeConfig:collectionChange", self.model.get("configs"));

                    //Listen for a save click from the Objecttypeconfig. Takes in the collection built up in the Objecttypeconfig.View
                    //and saves to the repo. After saving, navigates to the saved model's url.
                    self.listenTo(app, "hpiTypeConfig:onClickSaveConfig", function(collection) {
                        self.model.set("configs", collection);
                        var that = this;
                        $(".otcNotLoad").hide();
                        $(".otcLoad").show();
                        //if we are in "editMode" call a separate endpoint to actual save in the repo
                        if (module.config().editMode) {
                            //this is an special dictionary endpoint to update the backing dictionary with some more hooks in it to allow for playing with the json before it is saved
                            var jsonConfig = JSON.stringify(this.model);
                            $.ajax({
                                type: "PUT",
                                contentType: "application/json",
                                url: app.serviceUrlRoot + "/dictionary/updateJson",
                                data: jsonConfig,
                                success: function() {
                                    $(".otcLoad").hide();
                                    $(".otcNotLoad").show();

                                    //{replace: true} skips routing to the add New url and proceed to the new OTC
                                    Backbone.history.navigate("admin/ObjectTypeConfig", { replace: true, trigger: true });
                                    app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                                },
                                error: function() {
                                    app.trigger("alert:error", {
                                        header: window.localize("generic.errorSavingConfig"),
                                        message: window.localize("modules.hpiAdmin.otc.objectTypeConfig.unableToUpdate")
                                    });
                                }
                            });
                        } else //else, this is our normal path
                        {
                            that.model.save({}, {
                                success: function() {
                                    $(".otcLoad").hide();
                                    $(".otcNotLoad").show();

                                    //{replace: true} skips routing to the add New url and proceed to the new OTC
                                    Backbone.history.navigate("admin/ObjectTypeConfig", { replace: true, trigger: true });
                                    app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                                },
                                error: function() {
                                    app.trigger("alert:error", {
                                        header: window.localize("generic.errorSavingConfig"),
                                        message: window.localize("generic.configSaveFailed")
                                    });
                                },
                                wait: false
                            });
                        }

                    });

                }, this);
            },
            addCompositeType: function() {
                //need to add a blank type here
                var typeConfigAttrs = [];

                typeConfigAttrs.push({
                    label: '',
                    ocName: '',
                    dataType: 'string',
                    repoName: '',
                    filter: '',
                    hpiAdminReadOnly: false,
                    repeating: false
                });
                // create our collection with our array of type config attrs
                var hpiAttrs = new Hpitypeconfigattrs.Collection(typeConfigAttrs);

                // create our type config model now that we have our attrs for it
                this.model.get("configs").add(new Hpitypeconfig.Model({
                    label: "test",
                    ocName: "testOcName",
                    isContainer: "Composite",
                    repoTypeName: "testOcName",
                    superType: "",
                    attrs: hpiAttrs
                }));
            },
            clickFilterInput: function(e) {
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            },
            generateWizardOTC: function(pagesetName, wizardQuestions) {
                var newTypeConfigAttrs = [];
                var questions = _.keys(wizardQuestions);

                // For each question, we'll create a new attribute.
                _.each(questions, function(question) {
                    var questionObject = wizardQuestions[question];
                    var dataType = QuestionUtils.wizardTypeToAttrType[questionObject.type];
                    var filter = dataType === "date" ? "date" : "";
                    // For the oc Name, we'll add our AW prefix and remove all whitespace from the question.
                    var ocName = "aw_" + question.replace(/\s/g, "_");
                    ocName = ocName.replace(/[\(\)]/g, "");
                    var repoName = ocName;

                    newTypeConfigAttrs.push({
                        label: questionObject.label,
                        ocName: ocName,
                        dataType: dataType,
                        repoName: repoName,
                        filter: filter,
                        repeating: QuestionUtils.wizardTypeIsRepeating[questionObject.type],
                        repoEditable: true
                    });

                }, this);

                // Once we've created all the attrs, raise an event to create the type itself on the OTc.
                app.trigger("hpiTypeConfig:newTypeConfigAdded", new Hpitypeconfig.Model({
                    label: pagesetName,
                    ocName: pagesetName,
                    isContainer: "wizard",
                    repoTypeName: pagesetName,
                    superType: "Page Set Instance", // This is a placeholder, there may be a better way to do this.
                    attrs: newTypeConfigAttrs
                }));
            },
            afterRender: function() {
                var self = this;

                this.ui = {};
                this.ui.uploader = this.$('#fileupload');
                this.ui.uploader.fileupload({
                    url: app.serviceUrlRoot + '/psa/parsePSD'
                }).bind('fileuploaddone', function(e, data) {
                    var typeName = data.files[0].name;
                    typeName = typeName.split('.')[0];
                    self.generateWizardOTC(typeName, data.result);
                });
                $(".otcLoad").hide();
            },
            serialize: function() {
                return {
                    otcName: this.model.get("name"),
                    editModeEnabled: module.config().editMode
                };
            }
        });

        Objecttypeconfig.Views.Typecontrol = Backbone.Layout.extend({
            template: "hpiadmin/otc/addobjecttypecontrol",
            events: {
                "keyup #filter-types-input": "filterTypes",
                "click #filter-types-input": "clickFilterInput",
                "click button.close": "closeMenu",
                "click .unconfiguredtypes-outlet": "keepViewOpen"
            },
            beforeRender: function() {
                this.setViews({
                    ".unconfiguredtypes-outlet": new Repotype.Views.List()
                });
            },
            clickFilterInput: function(e) {
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            },
            closeMenu: function(e) {
                $(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
            },
            filterTypes: function() {
                // Pull the text out of the filter types text input
                var filterValue = $("#filter-types-input")[0].value;
                // Trigger the filter method in our repotype collection. Passing in this.collection
                // indicated the already configured object types
                app.trigger("unconfiguredObjectTypes:filter", filterValue, this.collection);
            },
            keepViewOpen: function(e) {
                var filterValue = $("#filter-types-input")[0].value;
                // Trigger the filter method in our repotype collection. Passing in this.collection
                // indicated the already configured object types
                app.trigger("unconfiguredObjectTypes:filter", filterValue, this.collection);
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            }
        });


        return Objecttypeconfig;

    });