// Repotype module
define([
	"app",
	"modules/common/alert/alert",
	"handlebars"
],

function(app, Alert, Handlebars) {

	var Repotype = app.module();

	// Default Model.
	Repotype.Model = Backbone.Model.extend({
		defaults: {
			ocName : "",
			repoName : "",
			superTypeName : "",
			properties : null,
			defaultAspects : null,
			allProperties : null
		},
		
		url: function() {
			return app.serviceUrlRoot + "/dictionary/type?type="+this.get("ocName");
		}
	});

	// Default Collection.
	Repotype.Collection = Backbone.Collection.extend({
		model: Repotype.Model,
		
		url: app.serviceUrlRoot + "/dictionary/type/definition",
		
		comparator: "ocName",
		
		parse: function(resp) {
			return _.toArray(resp);
		}
	});

	Repotype.Views.Item = Backbone.View.extend({
		template: "hpiadmin/otc/repotype/item",
		
		tagName: "option",

		attributes: {
			title: "Click to add attribute"
		},
		
		serialize: function() {
			return {
				repoType: this.model.toJSON()
			};
		}
	});

	Repotype.Views.List = Backbone.View.extend({
		tagName: "select",
		
		events: {
			// called when the user clicks on any of the options in the object type select box
			"change": "clickedRepoType"
		},

		attributes: {
			multiple : "multiple",
			size : "10",
			id : "unconfigured-types-select"
		},

		filteredRepoTypes: [],
		
		initialize: function() {
			this.collection = new Repotype.Collection();
			this.collection.fetch({ error: this.fetchError });
			
			//Listen for a trigger that clears the entire config. Re-fetch the entire of list of repoTypes and 
			//re-render
			this.listenTo(app, "clearOtc:clickYes", function(collection) {
				this.collection.fetch();
				this.filteredRepoTypes = [];
				this.render();
			});
			
			//Whenever the repoTypes collection has reset called on it, re-render the view.
			this.listenTo(this.collection, "sync", function() {
				this.render();
			});
			
			//When the collection controlling the Hpitypeconfig view changes, update the list of repoTypes available
			//to add to the config. This is what keeps the repoTypes up-to-date when loading a saved config
			this.listenTo(app, "hpiTypeConfig:collectionChange", function(collection) {
				this.filteredRepoTypes = [];
				collection.each(function(hpiTypeConfig) {
					this.filteredRepoTypes.push(hpiTypeConfig.get("repoTypeName"));
				}, this);
				this.render();
			});

			// Listen for when the user types in the text input to filter the unconfigured object types.
			// "filter" is the text currently in the filter input and is updated on every keyup
			this.listenTo(app, "unconfiguredObjectTypes:filter", function(filter, configuredTypes) {
				var self = this;
				this.filteredRepoTypes = [];

				// First we want to filter all the already-configured types
				configuredTypes.each(function(hpiTypeConfig) {
					this.filteredRepoTypes.push(hpiTypeConfig.get("repoTypeName"));
				}, this);
				// Filter all those types that do not match our filter input
				_.each(this.collection.models, function(type) {
					if (type.attributes.ocName.toLowerCase().indexOf(filter.toLowerCase()) === -1) {
						self.filteredRepoTypes.push(type.attributes.ocName);
					} 
				});
				// When we render now, the dropdown will contain all types that have not been configured
				// and match our filter string input
				this.render();
			});
		},

		// Check each repoType and if it's name exists in the filteredRepoTypes array, do not insert a view for it.
		beforeRender: function() {
			if (this.collection) {
				this.collection.sort();
				this.collection.each(function(repoType) {
					if (!_.contains(this.filteredRepoTypes, repoType.get("ocName"))) {
						this.insertView(new Repotype.Views.Item({
							model : repoType
						}));
					}
				}, this);
			}
		},

		// called when the user clicks on any of the options in the object type select box
		clickedRepoType: function(event) {
			var self = this;

			// loop over each of the selected options (this is a multiple select box)
			this.$("option:selected").each(function() {
				// get the repo type the user clicked on
				var clickedOnRepoType = $(this).text();
				clickedOnRepoType = Handlebars.Utils.escapeExpression(clickedOnRepoType);

				// find the model in our collection that corresponds to this type
				var repoModel = self.collection.findWhere({ ocName: clickedOnRepoType });

				// trigger the event that the user clicked on this type
				app.trigger("repoType:click", repoModel);
			});
		},
		
		//Displays an error alert if the collection of repoTypes cannot be provided by the REST service. Navigates
		//the user back to the index.
		fetchError: function() {
			app.trigger("alert:info", {
				header : window.localize("modules.hpiAdmin.otc.repoType.unableToFetch"),
				message : window.localize("modules.hpiAdmin.otc.repoType.unableToConnect"),
				success : function() {
					Backbone.history.navigate("", {trigger: true});
					app.layout.removeView("#configDetail");
				}
			});
		}
	});
	
	return Repotype;

});
