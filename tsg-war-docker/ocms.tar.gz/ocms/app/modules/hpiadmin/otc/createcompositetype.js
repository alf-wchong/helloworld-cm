// Objecttypeconfig module
define([
	"app",
	'module',
	"modules/hpiadmin/otc/hpitypeconfig",
	"modules/hpiadmin/otc/hpitypeconfigattrs"
],

function(app, module, Hpitypeconfig, Hpitypeconfigattrs) {
	"use strict";

	var CreateCompositeType = app.module();

	CreateCompositeType.View = Backbone.Layout.extend({
		template: "hpiadmin/otc/createcompositetypecontrol",
		events: {
			"click .create-type-input": "clickFilterInput",
			"click button.close": "closeMenu",
			"click .create-otc-type": "createType",
			"keyup .type-label-input": "updateTypeLabel",
			"change .type-compositetype-input": "addCompositeType",
			"click .removeCompositeType" : "removeCompositeType"
		},
		initialize: function() {
			this.collection.sort();
			this.typeLabel = '';
			this.typeOCName = '';
			this.typeContainer = '';
			this.typeSupertype = '';
			this.availableTypes = [];
			this.selectedTypes = [];

			_.each(this.collection.models, function(model){
				this.availableTypes.push({
					'typeLabel': model.get("label"),
					'typeOCname' : model.get("ocName")
				});
			},this);
		},
		serialize: function(){
			return {
				availableTypes : this.availableTypes,
				selectedTypes : this.selectedTypes,
				typeLabel : this.typeLabel,
				typeOCName : this.typeOCName
			};
		},
		afterRender: function(){
			this.checkValidation();
			this.updateStyling();
		},
		addCompositeType : function(event){
			var splitValue = event.target.value.split('$$');
			var typeLabel = splitValue[1];
			var typeValue = splitValue[0];
			this.selectedTypes.push({'typeLabel': typeLabel, 'typeOCname': typeValue});
			this.availableTypes = _.filter(this.availableTypes,function(availType){
				if(availType.typeOCname === typeValue){
					return false;
				}else{
					return true;
				}
			});

			this.render();
		},
		removeCompositeType : function(event){
			event.stopPropagation();
			var splitValue = event.target.value.split('$$');
			var typeLabel = splitValue[1];
			var typeValue = splitValue[0];
			this.availableTypes.push({'typeLabel': typeLabel, 'typeOCname': typeValue});
			this.selectedTypes = _.filter(this.selectedTypes,function(availType){
				if(availType.typeOCname === typeValue){
					return false;
				}else{
					return true;
				}
			});
			this.availableTypes.sort();
			this.render();
		},
		updateTypeLabel: function(event) {
			this.typeLabel = event.target.value;
			this.updateStyling();
			this.checkValidation();
		},
		updateStyling: function(event){
			if(this.typeLabel.trim().length > 0){
				this.$(".type-label-input").removeClass('list-group-item-danger');
			}else{
				this.$(".type-label-input").addClass('list-group-item-danger');
			}
			if(this.typeOCName.trim().length > 0){
				this.$(".type-ocName-input").removeClass('list-group-item-danger');
			}else{
				this.$(".type-ocName-input").addClass('list-group-item-danger');
			}
		},
		checkValidation: function(){
			var self = this;
			if(this.typeLabel.length > 0 && this.selectedTypes.length > 0){
				self.toggleSubmit(true);
			}else{
				self.toggleSubmit(false);
			}
		},
		toggleSubmit: function(enabled){
            if(enabled) {
                this.$('.create-otc-type').removeAttr('disabled');
            }
            else {
                this.$('.create-otc-type').attr('disabled','disabled');
            }
        },
		createType: function() {
			//need to add a blank type here
			var typeConfigAttrs = [];

			typeConfigAttrs.push({
				label : '',
				ocName : '',
				dataType : 'string',
				repoName : '',
				filter : '',
				hpiAdminReadOnly : false,
				repeating : false,
				repoEditable : false
			});
			// create our collection with our array of type config attrs
			var hpiAttrs = new Hpitypeconfigattrs.Collection(typeConfigAttrs);

			// create our type config model now that we have our attrs for it
			this.typeOCname = _.uniqueId('typeOCname');

			this.collection.add(new Hpitypeconfig.Model({
				label: this.typeLabel,
				ocName: this.typeOCname,
				isContainer: "Composite",
				repoTypeName: '',
                superType: "",
				attrs: hpiAttrs,
				compositeTypes: this.selectedTypes
			}));

			//clear out values after were done with them incase they want to reopen the view
			this.resetForm();
			//$('.add-compositetype-outlet').toggle();
			$('.compositeDropdown').click();
			
		},
		resetForm: function(){
			this.$('.type-label-input')[0].value = '';
			this.$('.type-compositetype-input')[0].value = '';
			this.$('.type-label-input').addClass('list-group-item-danger');
			this.typeLabel = '';
			this.selectedTypes = [];
			this.availableTypes = [];

			_.each(this.collection.models, function(model){
				this.availableTypes.push({
					'typeLabel': model.get("label"),
					'typeOCname' : model.get("ocName")
				});
			},this);
			this.render();
		},
		clickFilterInput: function(e) {
			// just stop clicking on the content from hiding the dropdown menu (events wont bubble)
			e.stopPropagation();
		},
		closeMenu: function(e) {
			this.$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
		}
	});

	return CreateCompositeType;

});
