// Objecttypeconfig module
define([
	"app",
	'module'
],

function(app, module) {
	"use strict";

	var EditCompositeAttrTable = app.module();

	EditCompositeAttrTable.View = Backbone.Layout.extend({
		template: "hpiadmin/otc/editcompositeattrtable",
		events: {
			'click .glyphicon-remove' : 'removeRow'
		},
		initialize: function(options) {
			this.rows = [];
			if(this.model.get('attrTable')){
				this.rows = this.model.get('attrTable');
			}
		},
		addRow: function(row){
			this.rows.push({typeLabel: row.typeLabel, attrLabel: row.attrLabel, typeOCname: row.typeOCname, attrOCname: row.attrOCname});
			this.model.set('attrTable',this.rows);
			this.render();
		},
		removeRow: function(event){
			var typeAndAttr = event.target.id.split("$$");
			var typeOCname = typeAndAttr[0];
			var attrOCname = typeAndAttr[1];
			var typeMap = {};
			var tempAttrTable = _.reject(this.model.get('attrTable'),function(tableRow){
				if(tableRow.typeOCname === typeOCname && tableRow.attrOCname === attrOCname){
					typeMap = {'typeLabel': tableRow.typeLabel,
							   'typeOCname': tableRow.typeOCname};
					return true;
				}else{
					return false;
				}
			});
			this.model.set('attrTable',tempAttrTable);
			this.rows = tempAttrTable;
			app.trigger('removeCompositeAttrType', typeMap);
			this.render();
		},
		serialize: function(){
			return {
				rows: this.rows
			};
		},
		afterRender: function(){
		}
	});

	return EditCompositeAttrTable;

});
