// Stageconfig module
define([
  // Application.
  "app",
  "knockout",
  "knockback",
  "module",
  "modules/hpiadmin/hpiadmin",
  
  //modules
  "modules/common/alert/alert",
  "modules/common/spinner",
  "handlebars"
],

// Map dependencies from above array.
function(app, ko, kb, module, Hpiadmin, Alert, HPISpinner, Handlebars) {
  "use strict";

  // Create a new module.
  var PicklistConfig = app.module();

    PicklistConfig.Picklist = Backbone.Model.extend({
      defaults: function(){
        return {
          ocName: "",
          defaultItems: [],
          label: "",
          picklistOption: "none",
          async: false,
          cache: false,
          options: [],
          lookupValues: false,
          type: ""
        };
      }
    });

    PicklistConfig.PicklistCollection = Backbone.Collection.extend({
      model: PicklistConfig.Picklist,

      comparator: function(task) {
        return task.get('label').toLowerCase();
      }
    });

    // This is based on an hpiadmin config.
    PicklistConfig.Model = Hpiadmin.Config.extend({
      type: "PicklistConfig",
      defaults : {
            type : "PicklistConfig",
            name : "default"
      },
      //in case we are ever just creating a picklistconfig model
      //like in unit tests...
      initialize: function(options){
        if(options && options.picklists){
          this.set("picklists", new PicklistConfig.PicklistCollection(options.picklists));
        } else {
          this.set("picklists", new PicklistConfig.PicklistCollection());
        }
      },
      parseResponse: function(response){
        if(this.id){
          //just want the id
          response = _.pick(response, 'id');
        } else if(response && response.picklists){
            _.each(response.picklists, function(picklist) {
              if(picklist.defaultItem) {
                picklist.defaultItems = [picklist.defaultItem];
                delete picklist.defaultItem;
              }
            });
            this.set("picklists", new PicklistConfig.PicklistCollection(response.picklists));
            delete response.picklists;
        }

        return response;
      }
    });

  //View that has the details to add a picklist
 PicklistConfig.Views.AddNewPicklistView = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/addnewpicklistview",
    events: {
      "click #add-picklist-btn": "addPicklist",
      "change #picklist-name-input": "picklistLabelChanged",
      "change #picklist-type-dropdown": "picklistTypeChanged",
      "change #ocPicklist-dropdown": "ocPicklistChanged",
      "change #webservice-input": "webserviceURLChanged",
      "keyup #picklist-name-input" : "updatePicklistList"
    },
    initialize: function(){
      var self = this;
      this.model = new PicklistConfig.Picklist();
      //In the html, helps with making sure the correct picklist type is "selected"
      Handlebars.registerHelper('equalsTo', function(v1, v2, options){
        if(v1 == v2) { 
          return options.fn(this); 
        }
        else{
          return options.inverse(this);
        }

      });
      //retrieving the ocPicklists for the picklists that are opencontent type
      $.get(app.serviceUrlRoot + "/picklists", function(picklists){
        self.ocPicklists = picklists;
        if(self.hasRendered){
          self.render();
        }
      });
    },

    afterRender: function(){
      this.hasRendered = true;
      $('#picklist-name-input').val(this.model.get("label"));
    },

    //when the user selects a picklist type from the dropdown
    picklistTypeChanged: function(evt){
      evt.stopPropagation();
      var newType = $('#picklist-type-dropdown').val();
      this.model.set("type", newType);
      
      //clear irrelevant values from the model
      if(newType !== "opencontent"){
        this.model.set("ocName", "");
      }
      if(newType !== "webservice"){
        this.model.set("webserviceURL", "");
      }
      this.render();
    },

    //when a name for picklist being added is entered
    picklistLabelChanged: function(evt){
      evt.stopPropagation();
      var newLabel = $('#picklist-name-input').val();
      this.model.set("label", newLabel);
    },

    //for type opencontent when an option from the oc picklist dropdown is selected
    ocPicklistChanged: function(evt){
      evt.stopPropagation();
      var newOcName = $('#ocPicklist-dropdown').val();
      this.model.set("ocName", newOcName);
    },

    //for webservice type, when a url is entered
    webserviceURLChanged: function(evt){
      evt.stopPropagation();
      var newWebserviceURL = $('#webservice-input').val();
      this.model.set("webserviceURL", newWebserviceURL);
    },

    //when the add button is clicked
    addPicklist: function(evt){
      evt.stopPropagation();
      var newLabel = $('#picklist-name-input').val();
      if(newLabel!==""){
        this.model.set("label", newLabel);
        //tell the parent view that a new picklist is added, so it adds it to the entire config
        this.trigger('picklistConfig:addNewPicklist', this.model);
        this.model = new PicklistConfig.Picklist();
        this.render();
      }
    },
    updatePicklistList: function(event) {
      if(event.keyCode == 13){
        this.addPicklist(event);
      }
    },


    serialize: function(){
      return{
          picklistLabel: this.model.get("label"),
          picklistType: this.model.get("type"),
          ocName: this.model.get("ocName"),
          showOcDropdown: this.model.get("type") === "opencontent" ? true : false,
          showWebserviceURL: this.model.get("type") === "webservice" ? true : false,
          ocPicklists: this.ocPicklists,
          dataDictionaryEnabled: module.config().dataDictionaryEnabled === false ? false : true
      };
    }
 });

//Shows the list of configured picklists 
 PicklistConfig.Views.PicklistListView = Backbone.Layout.extend({
     template: "hpiadmin/picklistconfig/picklistlistview",
     events: {
       "click #remove-picklist-btn": "removePicklistClicked",
       "click .toss-across-clickable": "picklistSelected"
     },

     initialize: function(options){
       this.picklistCollection = options.collection ? options.collection : new PicklistConfig.PicklistCollection();
     },

     //when the remove button is clicked
     removePicklistClicked: function(evt){
       var self = this;
       evt.stopPropagation();
       var labelClicked = $(evt.target).attr("value");
        app.trigger("alert:confirmation", {
        header: window.localize("modules.hpiAdmin.picklistConfig.picklistConfig.removePicklist"),
        message: window.localize("modules.hpiAdmin.picklistConfig.picklistConfig.youAreAbout"),
        confirm: function(evt){  
          self.removePicklist(labelClicked);
        }
      });

     },

     //removes picklist based on the picklist that was clicked and its label
     removePicklist: function(labelClicked){
        var deletePicklist = {};
        //find the picklist in the picklist collection that matches
        //the label of the picklist that was clicked to be able to remove the correct picklist
        deletePicklist = this.picklistCollection.find(function(picklist){
            return picklist.get("label") === labelClicked;
        });

        this.trigger('picklistConfig:removePicklist', labelClicked);
        this.picklistCollection.remove(deletePicklist);
        this.render();
     },

     //highlights and shows picklist when clicked
     picklistSelected: function(evt){
        evt.stopPropagation();
        this.selectedPicklist = $(evt.currentTarget).attr("value");
        //remove any highlights on any of the picklists firts, before highlighting the new selected picklist
        $('.toss-across-clickable').removeClass('picklist-selected');
        $(evt.currentTarget).addClass('picklist-selected');
        this.trigger('picklistConfig:picklistSelected', this.selectedPicklist);

     },

     //updates the picklist collection with added and removed picklists
     updateList: function(newCollection){
        this.picklistCollection = newCollection;
        this.render();
     },

     serialize: function(){
      return{
        picklists: this.picklistCollection.toJSON()
      };
     }
 });

  //view that shows all the information for a non-simple picklist
  PicklistConfig.Views.RepositoryPicklistItemsView = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/repositorypicklistitemsview",
    events: {
      "click .defaultItemCheckbox": "defaultItemsSelected",
      "change #picklistOption-dropdown": "picklistOptionChanged",
      "change #lookupValuesEnabled" : "toggleLookupValue"
    },

    initialize: function(){
      var self = this;
      var ocName = this.model.get("ocName");
      $.get(app.serviceUrlRoot + "/picklists/" + ocName, function(list){
        list.splice(0, 0, {label: "", value: ""});
        self.model.set("options", list);
        self.render();
        if(self.hasRendered){
         self.render();
       }  
      });

      //helps in html to check the defaultItems 
      Handlebars.registerHelper('setChecked', function(value) {
        var itemIsSelected = _.find(self.model.get('defaultItems'), function(item) {
          return value === item;
        }, self); // Weird scoping issues if self isn't bound and used inside this anonnymous function.
        // If we matched in our find, check the box.
        if(itemIsSelected) {
          return 'checked';
        } else {
          return '';
        }
      });
      //helps in the html to make sure the picklistOption dropdown has the correct selection
      Handlebars.registerHelper('equalsTo', function(v1, v2, options){
        if(v1 == v2) { 
          return options.fn(this); 
        }
        else{
          return options.inverse(this);
        }

      });
    },

    afterRender: function(){
      this.hasRendered = true;

      this.picklistUsedOnFormsView = new PicklistConfig.Views.PicklistUsedOnFormsView({
        model: this.model,
        formsList: this.formsList
      });
      this.insertView("#picklist-used-on-forms", this.picklistUsedOnFormsView);
      
      if(this.model.get("lookupValues")) {
        $("#enableLookupValues").prop("checked", true);
      } else {
        $("#disableLookupValues").prop("checked", true);
      }

      self.$('[data-toggle="tooltip"]').tooltip();
    },
    //when a new default is checked
    defaultItemsSelected: function(evt){
      evt.stopPropagation();
      var newDefault = $(evt.target).attr('value');
      // Find the index where this item is located in our defaultItems
      var indexOfNewValue = _.indexOf(this.model.get('defaultItems'), newDefault);

      // Get the array to push in the new value, then we will restore the array to the observable.
      var updatedDefaultItems = this.model.get('defaultItems');

      if(indexOfNewValue === -1) {
        // Item not found, add it to the array.
        updatedDefaultItems.push(newDefault);
      } else {
        // Item found, remove it from the array.
        updatedDefaultItems.splice(indexOfNewValue, 1);
      }
      this.model.set("defaultItems", updatedDefaultItems);
      this.trigger('picklistConfig:picklistUpdated', this.model);
    },

    //when a new picklist option from dropdown is selected
    picklistOptionChanged: function(evt){
      var self = this;
      evt.stopPropagation();
      //set the picklistOption 
      var picklistOptionValue = $(evt.target).attr('value');
      if(picklistOptionValue === "none"){
        self.model.set('async', false);
        self.model.set('cache', false);
        this.model.set("lookupValues", false);
        $("#lookupValueOption").hide();
      }
      else if(picklistOptionValue === "async"){
        self.model.set('async', true);
        self.model.set('cache', false);
        self.toggleLookupValue();
        $("#lookupValueOption").show();
      }
      else if(picklistOptionValue === "cache"){
        self.model.set('async', false);
        self.model.set('cache', true);
        this.model.set("lookupValues", false);
        $("#lookupValueOption").hide();
      }
      this.trigger('picklistConfig:picklistUpdated', this.model);
      this.model.set("picklistOption", picklistOptionValue);
    },
    toggleLookupValue: function() {
      this.model.set("lookupValues", $("#enableLookupValues").is(':checked'));
    },

    serialize: function(){
      return{
        model: this.model.toJSON(),
        picklistOption: this.model.get("picklistOption"),
        async: this.model.get('async'),
        lookupEnabled: this.model.get("lookupValues")
      };
    }
  });

  //the view for the information of a simple picklist
  PicklistConfig.Views.SimplePicklistItemsView = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/simplepicklistitemsview",
    events: {
      "click #simple-picklist-add-btn": "addNewValue",
      "change #picklistOption-dropdown": "picklistOptionChanged",
      "keyup #new-label-input": "updateOption",
      "keyup #new-value-input": "updateOption"
    },

    initialize: function(){
      var self = this;
      if(this.model.get("options").length === 0){
        self.model.get("options").splice(0,0, {label: "", value: ""});
      }
      //for each option on the model, create a new TableRow view with it's label and value, 
      //set up the listeners, and insert those views
      _.each(this.model.get("options"), function(option){
          var optionView = new PicklistConfig.Views.SimplePicklistTableRowView({
             label: option.label, value: option.value
          }, self.model.get("defaultItems"));
          self.setupInitialListeners(optionView);
          self.insertView("#simple-picklist-table-row", optionView);
      });

      var picklistUsedOnFormsView = new PicklistConfig.Views.PicklistUsedOnFormsView({
        model: this.model,
        formsList: this.formsList
      });
      self.insertView("#picklist-used-on-forms", picklistUsedOnFormsView);

      //helps html with making sure the correct picklistOption is selected
      Handlebars.registerHelper('equalsTo', function(v1, v2, options){
        if(v1 == v2) { 
          return options.fn(this); 
        }
        else{
          return options.inverse(this);
        }
      });
    },

    setupInitialListeners: function(optionView){
      var self = this;
      this.listenTo(optionView, "picklistConfig:removeOption", function(view){
          self.removeValue(view);
      });
      this.listenTo(optionView, "picklistConfig:defaultItemsSelected", function(value){
          self.defaultItemsSelected(value);
      });
      this.listenTo(optionView, "picklistConfig:optionLabelChanged", function(newLabel, view){
        self.optionLabelChanged(newLabel, view);
      });
      this.listenTo(optionView, "picklistConfig:optionValueChanged", function(newValue, view){
        self.optionValueChanged(newValue, view);
      });
      this.listenTo(optionView, "picklistConfig:sort", function(value, index) {
        self.sortOptions(value, index);
      });

    },

    afterRender: function(){
      var id = ".sortable-options";

      self.$('[data-toggle="tooltip"]').tooltip();

      //communicating with html that the options are sortable and can be reordered
      this.$(id).sortable({
        handle: ".picklist-option-row",
        update: function(event, ui) {
          ui.item.trigger("drop", ui.item.index());
        }
      });
    },

    addOption:function(newLabel, newValue){
      if(newLabel !== ""){
        if(newValue === ""){
          newValue = newLabel;
        }
        this.model.get("options").push({label: newLabel, value: newValue});
        $('#new-label-input').val("");
        $('#new-value-input').val("");
        this.trigger('picklistConfig:picklistUpdated', this.model);
        //new options created, meaning we need a new TableRow view and it needs to 
        //have the listeners and be inserted
        var optionView = new PicklistConfig.Views.SimplePicklistTableRowView({
          label: newLabel, value: newValue
        }, this.model.get("defaultItems"));
        this.setupInitialListeners(optionView);
        this.insertView("#simple-picklist-table-row", optionView).render();
        $("#new-label-input").focus();
      }
    },
    //when the add button for adding a new option is clicked
    addNewValue: function(evt){
      evt.stopPropagation();
      var newLabel = $('#new-label-input').val();
      var newValue = $('#new-value-input').val();
	  //if label is empty it wont add it to the options
      this.addOption(newLabel,newValue);
    },
    //listens for enter key to trigger addNewValue
    updateOption: function(event) {
      if(event.keyCode == 13){
        this.addNewValue(event);
      }
    },

    //when the removes tableRow view based on the option that was clicked to remove
    removeValue: function(badView){
      var badValue = {};
      _.each(this.model.get("options"), function(option){
        if(option.label === badView.label){
          badValue = option;
        }
      });
      var rowIndex = _.indexOf(this.model.get("options"), badValue);
      this.model.get("options").splice(rowIndex, 1);
      this.trigger('picklistConfig:picklistUpdated', this.model);
      //An option is removed from the model, and the view also needs to be removed
      badView.remove();
    },

    //sets new defaultItems based on the option that was checked as the new default item
    defaultItemsSelected: function(defaultValue){
      this.model.set("defaultItems", defaultValue);
      this.trigger('picklistConfig:picklistUpdated', this.model);
    },

    //when a new picklist option from dropdown is selected
    picklistOptionChanged: function(evt){
      var self = this;
      evt.stopPropagation();
      //set the picklist option
      var picklistOptionValue = $(evt.target).attr('value');
      if(picklistOptionValue === "none"){
        self.model.set('async', false);
        self.model.set('cache', false);
      }
      else if(picklistOptionValue === "async"){
        self.model.set('async', true);
        self.model.set('cache', false);
      }
      else if(picklistOptionValue === "cache"){
        self.model.set('async', false);
        self.model.set('cache', true);
      }
      this.trigger('picklistConfig:picklistUpdated', this.model);
      this.model.set("picklistOption", picklistOptionValue);
    },

    //updates option label based on the option that was edited
    optionLabelChanged: function(newLabel, view){
      //find the otpion on the model that the user edited and update accordingly
      _.each(this.model.get("options"), function(option){
        if(option.value === view.value){
          option.label = newLabel;
        }
      });
      this.trigger('picklistConfig:picklistUpdated', this.model);
    },

  //updates option value based on the option that was edited
    optionValueChanged: function(newValue, view){
      //find the option on the model that the user edited and update accordingly
      _.each(this.model.get("options"), function(option){
        if(option.label === view.label){
          option.value = newValue;
        }
      });
      this.trigger('picklistConfig:picklistUpdated', this.model);
    },

    //when options are reordered, sorts items correctly based on the index it was dropped and value of the picklist
    sortOptions: function(value, index){
      //when reordering the list, need to find the value of what is moving moved, 
      //and place it in the correct index
      var sortOption= {};
      _.each(this.model.get("options"), function(option){
        if(option.value === value){
          sortOption = option;
        }
      });
      var rowIndex = _.indexOf(this.model.get("options"), sortOption);
      this.model.get("options").splice(rowIndex, 1);
      this.model.get("options").splice(index, 0, sortOption);
      this.trigger('picklistConfig:picklistUpdated', this.model);
    },

    serialize: function(){
      return{
        model: this.model.toJSON(),
        picklistOption: this.model.get("picklistOption")
      };
    }
  });

  //The table row view of the simple picklist item's table
  PicklistConfig.Views.SimplePicklistTableRowView = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/simplepicklisttablerowview",
    events: {
      "click .glyphicon-remove": "removeValue",
      "click .defaultItemCheckbox": "defaultItemsSelected",
      "change #option-label": "labelChanged",
      "change #option-value": "valueChanged",
      "drop": "drop"
    },

    initialize: function(option, defaultItems){
      var self = this;     
      this.label = option.label;
      this.value = option.value;
      this.defaultValues = defaultItems;
      //helps html to check the correct default item
      Handlebars.registerHelper('setChecked', function(value) {
        var itemIsSelected = _.find(self.defaultValues, function(item) {
          return value === item;
        });
        // If we matched in our find, check the box.
        if(itemIsSelected) {
          return 'checked';
        } else {
          return '';
        }
      });
    },

    //when the remove button is clicked on a specific option
    removeValue: function(evt){
      var self = this;
      evt.stopPropagation();
      this.removeValue = $(evt.target).attr("value");
      app.trigger("alert:confirmation", {
        header: window.localize("modules.hpiAdmin.picklistConfig.picklistConfig.removePicklistOption"),
        message: window.localize("modules.hpiAdmin.picklistConfig.picklistConfig.youAreAboutToOption"),
        confirm: function(evt){  
          //the simplepicklistlistView will remove the option and trigger to update model
          self.trigger('picklistConfig:removeOption', self);
        }
      });
    },

    //when a new option is selected as the default item
    defaultItemsSelected: function(evt){
      evt.stopPropagation();

      var newDefault = $(evt.target).attr('value');
      // Find the index where this item is located in our defaultValues
      var indexOfNewValue = _.indexOf(this.defaultValues, newDefault);

      // Get the array to push in the new value, then we will restore the array to the observable.
      var updatedDefaultValues = this.defaultValues;

      if(indexOfNewValue === -1) {
        // Item not found, add it to the array.
        updatedDefaultValues.push(newDefault);
      } else {
        // Item found, remove it from the array.
        updatedDefaultValues.splice(indexOfNewValue, 1);
      }

      this.defaultValues = updatedDefaultValues;
      this.trigger('picklistConfig:defaultItemsSelected', this.defaultValues);
    },

    //when a new label name is entered for an existing option
    labelChanged: function(evt){
      evt.stopPropagation();
      var newLabel = $(evt.target).attr("value");
      this.label = newLabel;
      //editing the label of an option, trigger to the simplepicklistitemsview
      //to update the model
      this.trigger("picklistConfig:optionLabelChanged", newLabel, this);
    },

    //when a new value name is entered for an exitsing option
    valueChanged: function(evt){
      evt.stopPropagation();
      var oldValue = this.value;
      var newValue = $(evt.target).attr("value");
      this.value = newValue;
      //editing the value of an option, trigger to the simplepicklistitemsview
      //to update the model
      this.trigger("picklistConfig:optionValueChanged", newValue, this);
      this.updateDefaults(oldValue,newValue);
    },
    //when the valueChanged occurs, we need to update our defaults as well
    updateDefaults: function(oldValue, newValue){
      // Find the index where this item is located in our defaultValues
      var indexOfOldValue = _.indexOf(this.defaultValues, oldValue);
      //check to see if this is in our defaultItems, if so, we need to update
      if(indexOfOldValue !== -1){
          // Item found, remove it from the array.
          this.defaultValues.splice(indexOfOldValue, 1);
          //add our new value where the old one was
          this.defaultValues.splice(indexOfOldValue,0,newValue);

          this.trigger('picklistConfig:defaultItemsSelected', this.defaultValues);
      }
    },
    //when an option is dropped into a new place in the table
    drop: function(event, index) {
      //when and options is moved an dropped to a ceratin place, works with the sortable function
      //in the simplepicklistitems view in the afterRender
      var value = $(event.target.childNodes).attr("value");
      //everytime we move the formtype, need to sort the types correctly
      this.trigger("picklistConfig:sort", value, index);
    },


    serialize: function(){
      return{
        label: this.label,
        value: this.value,
        defaultValues: this.defaultValues
      };
    }
  });

  PicklistConfig.Views.PicklistUsedOnFormsView = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/picklistusedonformsview",
    
    initialize: function() {
      this.isEmpty = true;

      this.forms = this.picklistUsedOnForms();
 
      if(this.forms.length !== 0) {
        this.isEmpty = false;
      } 
    },

    picklistUsedOnForms: function() {
      var self = this;
      var forms = [];

      _.each(this.formsList, function(formConfig) {
        var configuredType = formConfig.get("configuredTypes").find(function(type) {
          var picklistPri = type.get("configuredAttrsPri").find(function(attrsPri) {
            if(attrsPri.get("picklist") === self.model.get("label")) {
              return attrsPri.get("picklist");
            }
          });

          var picklistSec = type.get("configuredAttrsSec").find(function(attrsSec) {
            if(attrsSec.get("picklist") === self.model.get("label")) {
              return attrsSec.get("picklist");
            }
          });

          if(picklistPri || picklistSec) {
            return type;
          }
        });

        if(configuredType) {
          forms.push(formConfig);
        }
      });
      return forms;
    },

    serialize: function() {
      return{
        isEmpty: this.isEmpty,
        forms: this.forms
      };
    }
  });

  // Default View.
  PicklistConfig.Views.Layout = Backbone.Layout.extend({
    template: "hpiadmin/picklistconfig/picklistconfig-mainlayout",
    events: {
      "click #save-config-btn": "saveConfig"
    },

    initialize: function(){ 
      //to get list of formConfigs for Picklist Used On Forms
      var self = this;
      var deferreds = [];
      var formConfigs = [];
      // shows spinner while we fetch formConfigs
      this.loadingSpinner = true;


      app.context.configService.getFormConfigNames(function(formConfigNames) {
        _.each(formConfigNames, function(formConfigName) {
          var deferred = app.context.configService.getFormConfig(formConfigName, function(formConfig) {
            formConfigs.push(formConfig);
          });
          deferreds.push(deferred);
        });

        $.when.apply($, deferreds).done(function() {
          // restores the picklist view and removes the temporary spinner view
          self.loadingSpinner = false;
          self.render();

          //Create a addNewPicklsitView and PicklistListView everytime
          //We have to do it inside the async calls to make sure the calls
          //are done before making the new views
          self.addNewPicklistView = new PicklistConfig.Views.AddNewPicklistView({
            model: self.model
          });

          self.picklistListView = new PicklistConfig.Views.PicklistListView({
            collection: self.model.get("picklists"),
            formsList: formConfigs
          });

          self.setView("#add-picklist", self.addNewPicklistView).render();
          self.setView("#picklist-list-view", self.picklistListView).render();

          //set up initial listeners
          self.setupInitialListeners();

        });
      }); //end of getting list of form configs
    },

    setupInitialListeners: function(){
      var self = this;
      this.listenTo(this.addNewPicklistView, "picklistConfig:addNewPicklist", function(model){
          self.addNewPicklist(model);
      });
      this.listenTo(this.picklistListView, "picklistConfig:removePicklist", function(label){
          self.removePicklist(label);
      });
      this.listenTo(this.picklistListView, "picklistConfig:picklistSelected", function(label){
          self.showPicklist(label);
      });     

    },

    //adds new model to the picklist array when a picklist is added
    addNewPicklist: function(model){
      this.model.get("picklists").add(model);
      this.picklistListView.updateList(this.model.get("picklists"));
      var label = model.get("label");
      this.showPicklist(label);
    },

    //removes model from the picklist and removes the activePicklistView if it was deleted.
    removePicklist: function(removeLabel){
      var self = this;
      var removeModel = this.model.get("picklists").find(function(picklistModel){
        return picklistModel.get("label") === removeLabel;
      });

      if(removeModel){
        if(self.activePicklistView && self.activePicklistView.model.get("label") === removeLabel){
          self.activePicklistView.remove();
        }
        this.model.get("picklists").remove(removeModel);
      } else {
        app.log.warn(window.localize("modules.hpiAdmin.picklistConfig.picklistConfig.couldNotFind") + removeLabel);
      }
    },

    //when picklist is selected, shows the details based on the type
    showPicklist: function(showLabel){
      var self = this;
      var list = this.model.get("picklists").findWhere({label: showLabel});
      var formsList = this.picklistListView.formsList;
      //based on whether the selected picklist is simple or non-simple determines
      //what the activePicklistView will be. First remove the activePicklistView if one is already showing
      //and check the new type and create a new view accordingly
      if(this.activePicklistView){
        self.activePicklistView.remove();
      }
      if(list.get("type") === "simple"){
        self.activePicklistView = new PicklistConfig.Views.SimplePicklistItemsView({
          model: list,
          formsList : formsList});
      }
      else{
        self.activePicklistView = new PicklistConfig.Views.RepositoryPicklistItemsView({
          model: list,
          formsList : formsList});
      }
      this.listenTo(this.activePicklistView, 'picklistConfig:picklistUpdated', function(model){
        self.updatePicklist(model);
      });
      this.setView("#picklist-items-view", this.activePicklistView).render();
    },

    //when anything changes on a model, updates the model
    updatePicklist: function(updatedModel){
      var findLabel = updatedModel.get("label");
      var oldModel = this.model.get("picklists").findWhere({label: findLabel});
      this.model.get("picklists").remove(oldModel);
      this.model.get("picklists").add(updatedModel);
    },

    //saves the changes and picklist 
    saveConfig: function(evt){
      _.each(this.model.get("picklists").models, function(picklistModel){
        if(picklistModel.get("type") === 'opencontent'){
          picklistModel.get("options").length = 0;
        }
      });
      this.model.save({}, {
          success: function(){
              app.trigger("modelSaveOrDestroy");
              Backbone.history.navigate("admin/PicklistConfig", {replace: true, trigger:true} );
              app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
          },
          error: function(){
              app.trigger("alert:error", {
                  header : window.localize("generic.errorSavingConfig"),
                  message :window.localize("generic.configSaveFailed") 
              });
          }
      });
      return this;
    },

    afterRender: function(){
      if(this.loadingSpinner){
        this.spinner = HPISpinner.createSpinner({
          lines: 13,
                  length: 10,
                  width: 6,
                  radius: 24
        }, $("#loading-forms-spinner")[0]);   
      }
      else{
        HPISpinner.destroySpinner(this.spinner);
      }
      //this.setView("#add-picklist", this.addNewPicklistView).render();
      //this.setView("#picklist-list-view", this.picklistListView).render();
    },

    serialize: function (){
      return{
        loadingSpinner: this.loadingSpinner,
        dataDictionaryEnabled: module.config().dataDictionaryEnabled === false ? false : true
      };
    }

  });
  // Return the module for AMD compliance.
  return PicklistConfig;
});
