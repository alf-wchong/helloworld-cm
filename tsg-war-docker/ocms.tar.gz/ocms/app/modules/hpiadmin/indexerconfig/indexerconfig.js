// Indexer Config module
define([
    // Application.
    "app",
    "knockout",
    "knockback",
    "handlebars",
    "module",
    "modules/hpiadmin/hpiadmin",
    "modules/hpiadmin/hpiadmin-switcher",
    "modules/hpiadmin/formconfig/formtype",
    "modules/hpiadmin/common/iosswitch",
    "modules/hpiadmin/common/iosswitchtwotiered",
    "modules/hpiadmin/formconfig/formattribute"
],
// Map dependencies from above array.
function(app, ko, kb, Handlebars, module, Hpiadmin, Switcher, Formtype, iOSSwitch, iOSSwitchTwoTiered, Formattribute) {

    // Create a new module.
    var IndexerConfig = app.module();

    // Default Model.
    IndexerConfig.Model = Hpiadmin.Config.extend({
        type: "IndexerConfig",
        defaults: function() {
            return {
                type: "IndexerConfig",
                form: "",
                types: new IndexerConfig.TypeCollection(),
                changeTypeInIndexer: false,
                autoSaveInIndexer: false,
                allowSplitPdf: false
            };
        },
        parseResponse: function(response) {
            //if this is the first time this config is loaded (id will be undefined),
            //then we need to build up the configured types without overwriting the
            //one that has already been init'ed. if the id is already present, then
            //the parse was hit after a save, and we are confident that the model we
            //already have is what is returned from the server, so remove config model
            //info from the response
            if (this.id) {
                response = _.pick(response, 'id');
            }

            if(response.types) {
                response.types = new IndexerConfig.TypeCollection(response.types, {parse: true});
            }

            return response;
        }
    });

    IndexerConfig.TypeModel = Backbone.Model.extend({
        defaults: {
            "configuredPreIndexAttrs": [],
            "configuredPostIndexAttrs": [],
            "ocName": "",
            "label": "",
            "messageIfInvalid": "",
            "positionalAttribute": ""
        },
        initialize: function(options) {
            if (options && options.configuredPreIndexAttrs) {
                this.set("configuredPreIndexAttrs", new Formattribute.Collection(options.configuredPreIndexAttrs));
            } else {
                this.set("configuredPreIndexAttrs", new Formattribute.Collection());
            }

            if (options && options.configuredPostIndexAttrs) {
                this.set("configuredPostIndexAttrs", new Formattribute.Collection(options.configuredPostIndexAttrs));
            } else {
                this.set("configuredPostIndexAttrs", new Formattribute.Collection());
            }
        },
        serialize: function() {
            return {
                messageIfInvalid: this.messageIfInvalid
            };
        }
    });

    IndexerConfig.TypeCollection = Hpiadmin.ConfigTypeCollection.extend({
        model: IndexerConfig.TypeModel,
        parse: function(typeModelArray) {
            _.each(typeModelArray, function(typeModel, idx) {
                 typeModelArray[idx] = new IndexerConfig.TypeModel(typeModel, {parse:true});
            });
            return typeModelArray;
        }
    });

    IndexerConfig.TypeView = Backbone.Layout.extend({
        template: "hpiadmin/indexer/indexertype",
        events: {
            "click .showHideConfig": "toggleTypeConfigOutlet",
            'keyup .message-if-invalid': 'updateInvalidMessage'
        },
        initialize: function(options) {
            this.options = options;

            this.config = options.config;

            this.model = options.model;

            //this model will serve as our attribute listener. This will allow individual
            //Formtypes to keep track of their attributes
            this.attrHelperPre = new Backbone.Model({
                allAttrs: [],
                configuredAttrs: [],
                configuredAttrsPre: [],
                unconfiguredAttrs: []
            });
            this.attrHelperPost = new Backbone.Model({
                allAttrs: [],
                configuredAttrs: [],
                configuredAttrsPost: [],
                unconfiguredAttrs: []
            });

        },
        afterRender: function() {
            this.loadView();
        },
        updateInvalidMessage: _.throttle(function(evt){
            this.model.set("messageIfInvalid", this.$(evt.currentTarget).val());
        }, 200, this),
        loadView: function() {
            var self = this;
            app.context.configService.getAdminTypeConfig(this.model.get("ocName"), function(typeConfig) {
                var allAttrs = [];
                //Retrieving all of the attributes from the form we are using
                //and pushing them onto our array we created
                _.each(typeConfig.get('attrs').models, function(attrModel) {
                    allAttrs.push(attrModel.get('ocName'));
                });
                //Using the collections for the pre-indexing attributes and post-indexing that was initialized
                //at the beginning of the config, the empty unconguredAttrs and configuredAttrs in the attrHelper 
                //object are being populated. 
                var configuredAttrsPre = self.model.get("configuredPreIndexAttrs").pluck("ocName");
                var configuredAttrsPost = self.model.get("configuredPostIndexAttrs").pluck("ocName");
                var unconfiguredAttrsPre = _.difference(allAttrs, configuredAttrsPre);
                var unconfiguredAttrsPost = _.difference(allAttrs, configuredAttrsPost);

                self.attrHelperPre.set("allAttrs", allAttrs);
                self.attrHelperPost.set("allAttrs", allAttrs);
                //configuredAttrs are the properties that are being auto-set
                self.attrHelperPre.set("configuredAttrs", configuredAttrsPre);
                self.attrHelperPost.set("configuredAttrs", configuredAttrsPost);
                //unconfiguredAttrs are the properties that are not being auto-set at the moment
                //and appear in the "Add Attributes" dropdown in the config
                self.attrHelperPre.set("unconfiguredAttrs", unconfiguredAttrsPre);
                self.attrHelperPost.set("unconfiguredAttrs", unconfiguredAttrsPost);

                //initializing the view that creates and populates the dropdown for the unconfigured attributes
                var attrControlViewPreIndexAttributes = new Formtype.Views.Attrcontrol({
                    allAttrs: allAttrs,
                    attrHelper: self.attrHelperPre,
                    repoType: typeConfig,
                    configuredAttrs: configuredAttrsPre
                });
                var attrControlViewPostIndexAttributes = new Formtype.Views.Attrcontrol({
                    allAttrs: allAttrs,
                    attrHelper: self.attrHelperPost,
                    repoType: typeConfig,
                    configuredAttrs: configuredAttrsPost
                });
                //initializing the view that will act as the outlet for the pre-indexing properties
                var preIndexingView = new IndexerConfig.Views.AutoSetProps({
                    repoType: typeConfig,
                    picklists: self.picklists,
                    collection: self.model.get("configuredPreIndexAttrs"),
                    collectionLabel: "configuredPreIndexAttrs",
                    allAttrs: allAttrs,
                    attrHelper: self.attrHelperPre,
                    primary: true,
                    typeCid: self.cid,
                    viewLabel: window.localize("indexerConfig.autosetProps.initiated")
                });
                //initializing the view that will act as the outlet for the pre-indexing properties
                var postIndexingView = new IndexerConfig.Views.AutoSetProps({
                    repoType: typeConfig,
                    picklists: self.picklists,
                    collection: self.model.get("configuredPostIndexAttrs"),
                    collectionLabel: "configuredPostIndexAttrs",
                    allAttrs: allAttrs,
                    attrHelper: self.attrHelperPost,
                    primary: true,
                    typeCid: self.cid,
                    viewLabel: window.localize("indexerConfig.autosetProps.completed")
                });

                var positionDataView = new iOSSwitch.View({
                    model: self.model,
                    configModelKey: "positionDataEnabled",
                    switchTitle: window.localize("indexerConfig.indexerMainLayout.positionalTracking"),
                    configDescription: window.localize("indexerConfig.positionalTrackingTooltip")
                });

                var suggestionDataView = new iOSSwitchTwoTiered.View({
                    model: self.model,
                    parentConfigModelKey: "suggestionDataEnabled",
                    parentSwitchTitle: window.localize("indexerConfig.indexerMainLayout.suggestionTracking"),
                    parentConfigDescription: window.localize("indexerConfig.indexerMainLayout.suggestionTrackingHelp"),
                    childConfigModelKey: "tableExtractEnabled",
                    childSwitchTitle: window.localize("Table Extract Mode"),
                    childConfigDescription: window.localize("Table Extract Mode")
                });

                self.setViews({
                    ".add-attributes-outlet-pre": attrControlViewPreIndexAttributes,
                    ".add-attributes-outlet-post": attrControlViewPostIndexAttributes,
                    ".preindex-attributes": preIndexingView,
                    ".postindex-attributes": postIndexingView,
                    "#positionDataEnabledView": positionDataView,
                    "#suggestionDataEnabledView": suggestionDataView
                });

                attrControlViewPreIndexAttributes.render();
                attrControlViewPostIndexAttributes.render();
                preIndexingView.render();
                postIndexingView.render();
                positionDataView.render();
                suggestionDataView.render();
            });
        },

        toggleTypeConfigOutlet: function() {
            if (this.$(".indexer-type-edit-outlet").is(":visible")) {
                this.$(".indexer-type-edit-outlet").hide();
            } else {
                this.$(".indexer-type-edit-outlet").show();
            }

            this.toggleExpandIcon();
        },

        toggleExpandIcon: function() {
            if (this.$("#indexerConfigArrow").hasClass("glyphicon-chevron-up")) {
                this.$("#indexerConfigArrow").addClass("glyphicon-chevron-down").removeClass("glyphicon-chevron-up");
            } else {
                this.$("#indexerConfigArrow").addClass("glyphicon-chevron-up").removeClass("glyphicon-chevron-down");
            }
        },
        serialize: function() {
            return {
                ocName: this.model.get("ocName"),
                label: this.model.get("label"),
                messageIfInvalid: this.model.get("messageIfInvalid")
            };
        }
    });

    // Default Collection.
    IndexerConfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
        model: IndexerConfig.Model,
        initialize: function() {
            this.type = "IndexerConfig";
        }
    });

    // Default View.
    IndexerConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/indexer/indexer-mainlayout",
        className: "container-fluid config-container",
        events: {
            "click #indexer-config-save": "saveConfig",
            "change #attribute-search-form": "changeForm",
            "click #change-type-in-indexer" : "updateChangeTypeInIndexer",
            "click #auto-save-in-indexer" : "updateAutoSaveInIndexer",
            "click #allow-split-pdf" : "updateAllowSplitPdf"
        },
        initialize: function() {
            var self = this;

            //default values
            this.model = this.options.model;
            this.showConfig = false;
            this.formDefault = false;
            this.formSelected = "";
            this.configSelected = this.model.get("name") ? true: false;

            //Get form configs for dropdown
            app.context.configService.getFormConfigNames(function(formConfigNames) {
                self.formConfigNames = formConfigNames;
                if (self.formConfigNames.length === 0) {
                    app.trigger("alert:changeNotification", "alert-danger", window.localize("indexerConfig.noFormsConfigured"), "#content-outlet");
                }

				//If a form is already selected, render the types of that form on the page
            	if (self.model && self.model.get("form")) {
                	self.formSelected = self.model.get("form");
                	app.context.configService.getFormConfig(self.model.get("form"), function(formConfig) {
                    	self.showConfig = true;
                    	self.formConfig = formConfig;
                    	self.render();
                	});
            	} else {
                	self.render();
				}
            });

            Handlebars.registerHelper('selected', function(value) {
                return value === self.formSelected ? 'selected' : '';
            });
        },

        changeForm: function() {
            var self = this;
            this.formName = this.$(event.target).val();
            this.formSelected = this.formName;
            this.model.set("form", this.formName);

            //Clearing out old types
            self.model.get("types").reset();

            if (this.formName !== "") {
                this.showConfig = true;
            } else {
                this.showConfig = false;
            }

            //Cleaning up the old views
            while (this.views["#indexerTypesOutlet"] && this.views["#indexerTypesOutlet"].length > 0) {
                this.views["#indexerTypesOutlet"][0].remove();
            }

            app.context.configService.getFormConfig(this.formName, function(formConfig) {
                self.formConfig = formConfig;
                formConfig.get("configuredTypes").each(function(type) {
                    var options = {};
                    options.model = new IndexerConfig.TypeModel({
                        "ocName": type.get("ocName"),
                        "label": type.get("label")
                    });
                    self.model.get("types").push(options.model);
                    options.config = self.model;
                    var view = new IndexerConfig.TypeView(options);
                    self.insertView("#indexerTypesOutlet", view).render();
                });
            });
        },

        serialize: function() {
            return {
                formConfigNames: this.formConfigNames,
                configSelected: this.configSelected,
                changeTypeInIndexer: this.model.get("changeTypeInIndexer"),
                autoSaveInIndexer: this.model.get("autoSaveInIndexer"),
                allowSplitPdf: this.model.get("allowSplitPdf"),
                enableSplitPDFOptions: module.config().enableSplitPDFOptions === false ? false : true
            };
        },

        saveConfig: function() {
            this.model.save({}, {
                success: function() {
                    app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                },
                error: function() {
                    app.trigger("alert:error", {
                        header: window.localize("indexerConfig.errorSavingConfig"),
                        message: window.localize("indexerConfig.errorSavingConfigMessage")
                    }); 
                }
            });
        },
        updateChangeTypeInIndexer: function() {
            this.model.set("changeTypeInIndexer", this.$(event.target)[0].checked);
        },
        updateAutoSaveInIndexer: function() {
            this.model.set("autoSaveInIndexer", this.$(event.target)[0].checked);
        },
        updateAllowSplitPdf: function() {
            this.model.set("allowSplitPdf", this.$(event.target)[0].checked);
        },
        attachTypeViews: function() {
            var self = this;
            if(this.formConfig && this.showConfig) {
                this.formConfig.get("configuredTypes").each(function(type) {
                    var options = {};
                    var indexerModel = self.model;
                    var objTypeCollection = indexerModel.get("types");

                    //Check if a type model already exists for this object type
                    var existingTypeModel = objTypeCollection.findWhere({
                        ocName: type.get('ocName')
                    });

                    //A new type has been added to the form
                    if (!existingTypeModel) {
                        options.model = new IndexerConfig.TypeModel({
                            "ocName": type.get("ocName"),
                            "label": type.get("label")
                        });
                        objTypeCollection.push(options.model);

                    } else {
                        options.model = existingTypeModel;
                    }
                    options.config = indexerModel;

                    var view = new IndexerConfig.TypeView(options);
                    self.insertView("#indexerTypesOutlet", view);
                });
            }
        },
        beforeRender: function() {
            var switcher = new Switcher.Views.Layout({ config: this.model, configClass: this.options.configClass });
            this.setView("#config-switcher-outlet", switcher);
            this.attachTypeViews();
        },
        afterRender: function() {
           self.$('[data-toggle="tooltip"]').tooltip();
        }
    });

    IndexerConfig.AttributeModel = Backbone.Model.extend({
        defaults: {
            ocName: "",
            repoName: "",
            value: "",
            validatedValue: "",
            showValidatedOption: false
        }
    });

    //This is the view for both pre and post indexing outlets
    IndexerConfig.Views.AutoSetProps = Formattribute.Views.Collection.extend({
        template: "hpiadmin/indexer/autosetprops",

        addConfiguredAttr: function(ocName) {
            var self = this;
            this.attrHelper = this.options.attrHelper;
            var propertiesAndAspectProperties = this.repoType.get("attrs");
            //add the attribute to the configured attributes by using the type's
            //fetched attributes from the dictionary service
            var selectedAttr = _.find(propertiesAndAspectProperties.models, function(model) {
                return model.get('ocName') === ocName;
            });

            if (selectedAttr) {
                self.collection.add(new IndexerConfig.AttributeModel({
                    ocName: selectedAttr.get('ocName'),
                    repoName: selectedAttr.get('repoName'),
                    value: selectedAttr.get("value")
                }));
            }
        },

        beforeRender: function() {
            var that = this;
            if (this.collection) {
                this.collection.each(function(property) {
                    if (that.collectionLabel === "configuredPostIndexAttrs") {
                        property.set("showValidatedOption", true);
                    }
                    that.insertView("#autosetprops-" + that.cid, new IndexerConfig.Views.AutoSetPropertyView({
                        model: property,
                        attrHelper: that.attrHelper
                    }));
                });
            }
        },
        afterRender: function() {
            var self = this;
            self.startCount = 0;
            //this makes sure that both tbody's that have this class are rendered before
            //we attach the sortable class
            //we don't use this.$() selector since a separate views add the tbody's
            this.sortableElements = $(".sortable-attributes");
            if (this.sortableElements.length === 2) {
                this.sortableElements.sortable({
                    connectWith: ".sortable-attributes",
                    revert: true,
                    receive: function(event, ui) {
                        ui.item.trigger("updateOtherCollection", ui.item.index());
                    },
                    stop: function(event, ui) {
                        if (this === ui.item.parent()[0]) {
                            ui.item.trigger("updateSameCollection", ui.item.index());
                        }
                        self.sortableElements.find(".dropzone").remove();
                        self.startCount = 0;
                    },
                    start: function() {
                        // this is NOT scoped to self -- because we want to find the elements outside this view in the DOM (dont want to trigger events in order to bubble up)
                        if (self.startCount === 0) {
                            self.sortableElements.append("<tr class='dropzone' style='border:2px dashed #f2dede; border-radius:6px'><td colspan='9' style='text-align:center'>Drop Here</td></tr>");
                            self.startCount++;
                        }
                    }
                });
            }

            // init any tooltips
            this.$("span").tooltip();
        },

        serialize: function() {
            return {
                viewLabel: this.options.viewLabel,
                cid: this.cid
            };
        }
    });
    //the view that is inserted into the pre/post indexing outlets for each individual property
    IndexerConfig.Views.AutoSetPropertyView = Backbone.Layout.extend({
        template: "hpiadmin/indexer/autosetpropertyview",
        events: {
            "click .remove-property": "removeAttribute",
            "keyup .auto-set-value": "updateAttributeValue",
            "keyup .auto-set-validated-value": "updateValidatedValue",
            "updateOtherCollection": "updateOtherCollection",
            "updateSameCollection": "updateSameCollection",
            "change .validated-value": "showValidatedValue",
            "click .processValidatedValue" : "changeProcessValidatedValue",
            "click .processValue" : "changeProcessValue"
        },
        initialize: function() {
            this.ui = {};
            this.label = this.model.get("ocName");
            this.attrHelper = this.options.attrHelper;
            
            // if we don't have values for processValdatedValue or processValue, we default to yes 
            if (_.isUndefined(this.model.get("processValidatedValue"))) {
                this.model.set("processValidatedValue", "true");
            }

            if (_.isUndefined(this.model.get("processValue"))) {
                this.model.set("processValue", "true");
            }

            //Puts the current value for the specific property in the text box
            Handlebars.registerHelper('input', function(value) {
                return new Handlebars.SafeString(
                    '<input class="col-md-6 form-control auto-set-value" type="text" value=' + value + ' >' + '</>'
                );
            });
            Handlebars.registerHelper('validatedinput', function(validatedValue) {
                return new Handlebars.SafeString(
                    '<input class="col-md-6 form-control auto-set-validated-value" type="text" value=' + validatedValue + ' >' + '</>'
                );
            });
        },
        afterRender: function() {
            this.ui.tooltip = this.$(".configs-tooltip.containerInfo");
            //add popover to icon for glyphicons

            this.ui.validatedValueInfo = this.$(".configs-tooltip.validatedValueInfo");
            //add popover to icon for glyphicons
            this.ui.validatedValueInfo.popover({
                placement: 'top',
                trigger: 'hover',
                title: 'Validated Value',
                html: true,
                content: "<p>" + window.localize("indexerConfig.validatedValueMessage") + "</p>",
                delay: {
                    show: 500
                }
            });
        },
        serialize: function() {
            return {
                cid: this.cid,
                ocName: this.model.get("ocName"),
                label: this.label,
                value: this.model.get("value"),
                validatedValue: this.model.get("validatedValue"),
                showValidatedOption: this.model.get("showValidatedOption"),
                processValidatedValue: this.model.get("processValidatedValue") === "true",
                processValue: this.model.get("processValue") === "true"
            };
        },
        removeAttribute: function() {
            //update our attrHelper
            this.attrHelper.set("unconfiguredAttrs",
                _.union(this.attrHelper.get("unconfiguredAttrs"), this.model.get("ocName")));
            this.attrHelper.set("configuredAttrs",
                _.without(this.attrHelper.get("configuredAttrs"), this.model.get("ocName")));

            //tell the collection of Formattrs that one was removed
            this.attrHelper.trigger("configuredAttrsRemoval", this.model);
        },
        updateAttributeValue: function(event) {
            this.model.set("value", event.target.value);
        },
        updateValidatedValue: function(event) {
            this.model.set("validatedValue", event.target.value);
        },
        changeProcessValidatedValue: function(e) {
            var target = "input[id='" + $(e.target).attr("for") + "']";
            this.model.set("processValidatedValue", $(target).val());
        },
        changeProcessValue: function(e) {
            var target = "input[id='" + $(e.target).attr("for") + "']";
            this.model.set("processValue", $(target).val());
        },
        updateOtherCollection: function(event, index) {
            //everytime we move the formattribute, need to sort the attributes correctly
            //the boolean tells the sort that the attribute is from the other
            //configuredAttr collection
            this.attrHelper.trigger("Formattribute:sort", this.model, index, false);
        },
        updateSameCollection: function(event, index) {
                //everytime we move the formattribute, need to sort the attributes correctly
                //the boolean tells the sort that the attribute is from the same
                //configuredAttr collection
                this.attrHelper.trigger("Formattribute:sort", this.model, index, true);
            }
            // showValidatedValue: function(event) {
            //     if ($(event.target).attr('checked')) {
            //         this.model.set("showValueChecked", true);
            //     }
            //     //if the checkbox isn't set, set the validatedValue to the first value so the value of the 
            //     //property will remain the same whether the form is valid or invalid
            //     else {
            //         this.model.set("showValueChecked", false);
            //         this.model.set("validatedValue", this.model.get("value"));
            //     }
            //     this.render();
            // }

    });

    // Return the module for AMD compliance.
    return IndexerConfig;

});