define([
	"app",
    "modules/hpiadmin/hpiadmin",
    "handlebars"
],
function(app, HpiAdmin, Handlebars) {
	"use strict";

	var LoggingConfig = app.module();

	LoggingConfig.Collection = Backbone.Collection.extend({
		model: LoggingConfig.Model
	});

	LoggingConfig.Model = HpiAdmin.Config.extend({
		type: "LoggingConfig",
		defaults: {
            "type": "LoggingConfig",
            "performanceLogging": false
		}
	});

	LoggingConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/loggingconfig/loggingconfig-layout",
        events: {
            "click .radioValueChange": "updateRadioValue",
            "click #saveLogConfig-btn": "saveConfig"
        },
		initialize: function(options) {
            Handlebars.registerHelper("setChecked", function(value, currentValue) {
                return value == currentValue ? "checked = true" : "";
            });
            this.model = options.model;
		},
        serialize: function() {
            return {
                "performanceLogging": this.model.get('performanceLogging')
            };
        },
        updateRadioValue: function(event) {
            var target = "input[id='" + $(event.target).attr("for") + "']";
            var newVal = $(target).val().localeCompare("true") === 0;
            this.model.set($(target).attr("name"), newVal);
        },
        saveConfig: function() {
            this.model.save({}, {
                success: function() {
                    app.trigger("modelSaveOrDestroy");
                    Backbone.history.navigate("admin/LoggingConfig", { replace: true, trigger: true });
                    app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", ".config-container");
                },
                error: function() {
                    app.trigger("alert:error", {
                        header: "Error Saving Config",
                        message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
                    });
                }
            });
        }
	});

	return LoggingConfig;
});
