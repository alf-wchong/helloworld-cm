define([
        "app",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/otc/objecttypeconfig",
        "modules/hpiadmin/stageconfig/stageconfig",
        "modules/hpiadmin/searchconfig/searchconfig",
        "modules/hpiadmin/indexerconfig/indexerconfig",
        "modules/hpiadmin/hpiconfiglist",
        "modules/common/tossacross"
    ],
    function(app, Hpiadmin, ObjectTypeConfig, StageConfig, SearchConfig, IndexerConfig, HPIConfigList, TossAcross) {
        "use strict";

        var TracConfig = app.module();

        TracConfig.Model = Hpiadmin.Config.extend({
            type: "TracConfig",
            defaults: {
                type: "TracConfig",
                typesUsedInTrac: [],
                displayName: ""
            },
            sync: function(method, model, options) {
                //OC and the rest of HPI expect
                //the configured types to be an array of strings
                if (model.get("typesUsedInTrac") instanceof Backbone.Collection) {
                    model.set('typesUsedInTrac', model.get("typesUsedInTrac").pluck('ocName'));
                }
                //call original save
                return Backbone.sync(method, model, options);
            }
        });

        // Default Collection.
        TracConfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
            model: TracConfig.Model,
            initialize: function(model, options) {
                this.type = "TracConfig";
            },
            comparator: function(model) {
                return model.get('ordinal');
            }
        });

        TracConfig.Views.Trac = Backbone.Layout.extend({
            className: "tracconfig",
            template: "hpiadmin/tracconfig/tracconfig-trac",
            events: {
                "change .trac-display-name": "setDisplayName",
                "click button.trac-delete": "deleteTrac",
                "click button.trac-copy": "copyTrac",
                "click .hpi-section-header": "toggleTrac",
                "update-sort": "updateSort"
            },
            initialize: function(options) {
                var self = this;
                this.model = this.options.model;
                this.name = this.options.name;
                this.ui = {};
                this.visible = false;

                this.searchConfig = new HPIConfigList.View({
                    config: this.model,
                    configClass: SearchConfig,
                    configType: 'SearchConfig'
                });

                this.stageConfig = new HPIConfigList.View({
                    config: this.model,
                    configClass: StageConfig,
                    configType: 'StageConfig'
                });

                //grab all the types we can use, we will update this list if any are configured
                //in the before render
                app.context.configService.getAdminOTC(function(adminOTC) {
                    self.allConfigTypes = adminOTC.get("configs");
                    //if we have a model here, take the types that are configured out of the list
                    //of non-configured types
                    //build backbone collection of used types
                    self.typesUsedInTrac = new Backbone.Collection();
                    if (!(self.model.get("typesUsedInTrac") instanceof Backbone.Collection)) {
                        _.each(self.model.get("typesUsedInTrac"), function(type) {
                            self.typesUsedInTrac.add(
                                new Backbone.Model({
                                    ocName: type
                                })
                            );
                        }, self);
                        self.model.set("typesUsedInTrac", self.typesUsedInTrac);
                    }
                    //remove any tracs already in use
                    self.typesNotUsedInTrac = new Backbone.Collection(self.allConfigTypes.reject(function(item, index) {
                        return self.model.get("typesUsedInTrac").findWhere({ 'ocName': item.get('ocName') });
                    }));
                    self.typesTossAcross = new TossAcross.Layout({
                        srcCollection: {
                            title: window.localize("modules.hpiAdmin.tracConfig.tracConfig.typeNotUsed"),
                            filter: true,
                            labelAttr: 'ocName',
                            collection: self.typesNotUsedInTrac
                        },
                        targetCollections: [{
                            title: window.localize("modules.hpiAdmin.tracConfig.tracConfig.typesUsedInTrac"),
                            labelAttr: 'ocName',
                            collection: self.model.get("typesUsedInTrac")
                        }]
                    });
                    if (self.rendered) {
                        self.setView('.trac-types-tossacross', self.typesTossAcross).render();
                    }

                });
            },
            setDisplayName: function() {
                this.model.set("displayName", this.ui.displayNameInput.val());
                this.ui.titleBarTracDisplayName.html(this.ui.displayNameInput.val());
            },
            deleteTrac: function() {
                // just call an event so the parent can remove from its collection
                this.trigger("trac:delete", this);
            },
            toggleTrac: function() {
                if (this.visible) {
                    this.ui.content.slideUp();
                    this.ui.content.css('padding-bottom', '0px');
                    this.ui.upDownIndicator.find("span").removeClass("glyphicon glyphicon-chevron-up").addClass("glyphicon glyphicon-chevron-down");
                } else {
                    this.ui.content.slideDown();
                    this.ui.upDownIndicator.find("span").removeClass("glyphicon glyphicon-chevron-down").addClass("glyphicon glyphicon-chevron-up");
                }
                this.visible = !this.visible;
            },
            attributes: function() {
                return {
                    'data-trac-name': this.model.get('name'),
                    'id': this.model.get('name')
                };
            },
            beforeRender: function() {
                this.setViews({
                    '.search-hpiconfig-list': this.searchConfig,
                    '.stage-hpiconfig-list': this.stageConfig
                });
                if (this.typesTossAcross) {
                    this.setView('.trac-types-tossacross', this.typesTossAcross);
                }
            },
            afterRender: function() {
                this.rendered = true;
                // trac name ui
                this.ui.tracname = this.$("span.trac-name");
                // display name ui
                this.ui.displayNameInput = this.$(".trac-display-name");
                // content ui
                this.ui.content = this.$('.hpi-collapsable');
                this.ui.upDownIndicator = this.$(".hideTracBtn");

                this.ui.tooltip = this.$(".configs-tooltip");

                this.ui.titleBarTracDisplayName = this.$(".trac-name-display .display-name");

                //add popover to icon for glyphicons
                this.ui.tooltip.popover({
                    placement: 'top',
                    trigger: 'hover',
                    title: window.localize("modules.hpiAdmin.tracConfig.tracConfig.tracConfigs"),
                    html: true,
                    content: "<p>" + window.localize("modules.hpiAdmin.tracConfig.tracConfig.eachTrac") + "</p>",
                    delay: { show: 500 }
                });

                //if the url contains the name of this config, dfisplay it
                if (this.model.get("name") === this.name) {
                    this.toggleTrac();
                }
            },
            serialize: function() {
                return {
                    "tracName": this.model.get("name"),
                    "displayName": this.model.get("displayName") || ""
                };
            }
        });

        TracConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/tracconfig/tracconfig-layout",
            events: {
                "click #trac-add-new": "createNewTrac",
                "click #trac-save": "saveTracs",
                "update-sort": "updateSort"
            },
            initialize: function(options) {
                // get all the tracs
                this.tracs = options.collection || null;
                this.name = options.name || null;
                this.ui = {};
            },
            addAllTracs: function() {
                var self = this;
                var views = [];
                this.tracs.each(function(trac, index) {
                    var view = new TracConfig.Views.Trac({ model: trac, name: this.name });
                    views.push(view);
                }, this);

                this.remove("#trac-configs-outlet");
                //insert the views in order based on the ordinal
                this.insertViews({
                    "#trac-configs-outlet": views
                });


                //apply listener after inserting into the DOM
                _.each(views, function(view) {
                    this.listenTo(view, "trac:delete", function(view) {

                        app.trigger("alert:confirmation", {
                            header: window.localize("modules.hpiAdmin.tracConfig.tracConfig.areYouSure"),
                            message: window.localize("modules.hpiAdmin.tracConfig.tracConfig.pleaseConfirm"),
                            confirm: function() {

                                // delete the model on the server
                                view.model.destroy({
                                    success: function(model, response) {
                                        // remove from tracs collection
                                        self.tracs.remove(view.model);
                                        // remove the view
                                        self.getView(view).remove();
                                    },
                                    error: function(model, response) {
                                        app.trigger("alert:changeNotification", "alert-danger", "Failed to delete configuration.", ".config-container");
                                        app.log.error("Error deleting config: " + response.responseText);
                                    }
                                });
                            }
                        });
                    });
                }, this);
            },
            createNewTrac: function() {
                var view = new TracConfig.Views.Create();
                app.trigger("alert:custom", { view: view });
                this.listenTo(view, "trac:create", function(trac) {
                    //all new configs should be added to the end of the list
                    trac.set('ordinal', this.tracs.length + 1);
                    this.tracs.add(trac);
                    this.render();
                });
            },
            saveTracs: function() {
                var tracsSaved = [];
                this.tracs.each(function(trac) {
                    var deferred = trac.save();
                    tracsSaved.push(deferred);
                }, this);

                $.when.apply($, tracsSaved).then(function() {
                    app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                }, function() {
                    app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.hpiAdmin.tracConfig.tracConfig.failedToRemove"), "#content-outlet");
                });

            },
            updateSort: function(event, data) {
                var position = data.position;
                var tracName = data.tracName;
                var model = this.tracs.findWhere({ name: tracName });
                //remove the current model so we can re-add it with the updated ordinal
                this.tracs.remove(model);

                //update the ordinals on each model
                this.tracs.each(function(model, index) {
                    var ordinal = index;
                    if (index >= position) {
                        ordinal += 1;
                    }
                    model.set('ordinal', ordinal);
                });

                //add the model back with it's new ordinal
                model.set('ordinal', position);
                this.tracs.add(model, { at: position });
            },
            beforeRender: function() {
                this.addAllTracs();
            },
            afterRender: function() {
                this.ui.configs = this.$('#trac-configs-outlet');
                this.ui.configs.sortable({
                    handle: ".hpi-section-header",
                    update: function(event, ui) {
                        var tracName = ui.item.data('trac-name');
                        ui.item.trigger("update-sort", {
                            tracName: tracName,
                            position: ui.item.index()
                        });
                    }
                });
                this.ui.configs.disableSelection();

                $(".hpi-section.trac").eq(0).bind("click", function() {
                    $(this).popover("hide");
                });
                $("#trac-add-new").eq(0).bind("click", function() {
                    $(".hpi-section.trac").popover("hide");
                });
                $("#trac-save").eq(0).bind("click", function() {
                    $(".hpi-section.trac").popover("hide");
                });

            }
        });

        TracConfig.Views.Create = Backbone.Layout.extend({
            template: "hpiadmin/tracconfig/tracconfig-new",
            events: {
                "keydown #new-trac-name": "checkTracName",
                "keyup #new-trac-name": "setTracName",
                "click #new-trac-save": "createTrac"
            },

            initialize: function(options) {
                this.model = new TracConfig.Model();
                this.ui = {};
            },

            afterRender: function() {
                this.ui.newTracName = this.$("#new-trac-name");
                this.ui.savebutton = this.$("#new-trac-save");
                this.validate();
            },

            checkTracName: function(e) {
                var regEx = new RegExp("^[a-zA-Z0-9]+$");

                //Not allowing spaces or non-letters/numbers to be typed in the input
                if (e.which === 32 || !regEx.test(e.key)) {
                    return false;
                }
            },
            setTracName: function() {
                this.model.set("name", this.ui.newTracName.val());
                this.validate();
            },

            validate: function() {
                if (this.model.get("name") === "" || this.model.get("name") === undefined) {
                    // just disable the button, this is simple enough
                    this.ui.savebutton.prop("disabled", true);
                    return false;
                }
                this.ui.savebutton.prop("disabled", false);
                return true;
            },

            createTrac: function() {
                this.trigger("trac:create", this.model);
                app.trigger("alert:close");
            }

        });

        return TracConfig;
    });