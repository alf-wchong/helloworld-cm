// WorkflowFormconfig module
define([
    "app",
    "modules/hpiadmin/hpiadmin-switcher",
    "modules/hpiadmin/hpiadmin",
    "modules/hpiadmin/formconfig/formtype",
    "modules/common/workflow",
    "modules/hpiadmin/workflowconfig/singleworkflow"
  ],

  function(app, Switcher, Hpiadmin, Formtype, Workflow, SingleWorkflow) {
    "use strict";

    var WorkflowConfig = app.module();

    // Default Model.
    WorkflowConfig.Model = Hpiadmin.Config.extend({
      type: "WorkflowConfig",
      defaults: {
        type: "WorkflowConfig"
      },
      parseResponse: function(response) {
        //if this is the first time this config is loaded (id will be undefined),
        //then we need to build up the configured types without overwriting the
        //one that has already been init'ed. if the id is already present, then
        //the parse was hit after a save, and we are confident that the model we
        //already have is what is returned from the server, so remove config model
        //info from the response
        if (this.id) {
          response = _.pick(response, 'id');
        } 
                
        return response;
      }
      
    });

    WorkflowConfig.Views.Layout = Backbone.Layout.extend({
      template: "hpiadmin/workflowconfig/workflowconfig",
      className: "WorkflowConfig",
      events: {
        "click #saveworkflow-btn": "saveWorkflow",
        "click #existing-wf": "loadWorkflow",
        "click #reset-workflow-config": "resetConfig"
      },
      initialize: function(options) {
        var self = this;

        this.currentWorkflows = [];
        this.rendered = false;
        this.workflowFormConfigs = null;

        //grab all defined wfs
        this.workflowDefinitions = new Workflow.DefinitionCollection();
        this.workflowDefinitions.fetch().done(function(wfs) {
          self.currentWorkflows = wfs;
          //If we have already rendered this view, then we will need to re render as to re serizlize.
          //If this view hasn't been rendered yet, then we are good.
          if (self.rendered) {
            self.render();
          }

          app.context.configService.getAdHocFormConfigNames(function(formConfigNames) {
              self.workflowFormConfigs= formConfigNames;
              self.render();
          });

        }); // end this.workflowDefinitions.fetch
        this.model = options.model;

        //If there aren't any WFs on the config (first time saving)
        if (!this.model.get('currentWorkflows')) {
          this.model.set('currentWorkflows', {});
        }
        
      },
      loadWorkflow: function(evt) {
        var self = this;
        
        // enable reset config button when selecting a workflow
        $("#reset-workflow-config").prop("disabled", false);
        
        //Getting our workflow
        var wf = _.findWhere(this.currentWorkflows, {
          'name': evt.target.text
        });
        
        var currentForms = self.workflowFormConfigs;
		// Check if workflow tasks exist on the model, if it does, we don't need to make a call to the server.
        if (this.model.get("currentWorkflows") && this.model.get("currentWorkflows")[wf.id]) {
          var tasks = this.model.get("currentWorkflows")[wf.id];
          var options = {
            "currentWfTasks": tasks,
            "workflow": wf,
            "currentWfForms": currentForms,
	          "existsOnModel" : true
          };
          
          //Setting our "SingleWorkFlow" View
          self.setView("#workflow-config", new SingleWorkflow.View(options)).render();
        } else {
          // If current workflows do not exist on the model, get tasks
          $.ajax({
            url: app.serviceUrlRoot + "/workflow/workflowdefinitiontasks?processDefinitionId=" + wf.id,
            success: function(data) {
              self.currentWfInfo = data;
              //Create our options to pass to our "single workflow" view.
              var opts = {
                "currentWfTasks": self.currentWfInfo,
                "workflow": wf,
                "currentWfForms": currentForms,
				        "existsOnModel" : false
              };
              
              //Setting our "SingleWorkFlow" View
              self.setView("#workflow-config", new SingleWorkflow.View(opts)).render();
            },
            error: function() {}
          });
        } // end else
      },
      getWorkflowIdFromName: function(wfName) {
        var wf = _.findWhere(this.currentWorkflows, {
          'name': wfName
        });
        return wf.id;
      },
      saveWorkflow: function() {
        //Get views call
        var workflowConfig = this.views['#workflow-config'];
        var wfId = this.getWorkflowIdFromName(workflowConfig.wfName);
        // TODO: Optimize to only set descriptions when updated.
        workflowConfig.setDescriptions();
        var config = workflowConfig.config;

        this.model.get('currentWorkflows')[wfId] = config;
        this.doSave();
      },
      resetConfig: function(){
        var self = this;
        
        app.trigger("alert:confirmation", {
          header : "Reset Config",
          message : "Would you like to reset this config?",
          confirm: function() {
            var workflowConfig = self.views['#workflow-config'];
            //Getting the ID and then clearing it on the model
            var wfId = self.getWorkflowIdFromName(workflowConfig.wfName);
            delete self.model.get('currentWorkflows')[wfId];
            
            //Saving the model
            self.doSave();
                      
            //Removing the workflow from the DOM
            $("#workflow-config").empty();
            
            // reenable reset config button
            $("#reset-workflow-config").prop("disabled", true);
          }
        });
        
        

      },
      //Since save and reset both have to "save" we are splitting this logic out.
      doSave: function(){
          var self = this;
          this.model.save({}, {
            success: function() {
              Backbone.history.navigate("admin/WorkflowConfig/" + self.model.get("name"), {
                replace: true,
                trigger: true
              });
              app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", "#content-outlet");
            },
            error: function() {
              app.trigger("alert:error", {
                header: "Error Saving Config",
                message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
              });
            }
          });  
      },
      afterRender: function() {
        this.rendered = true;
        
        //Making sure to show the current form in the dropdown
        $("#current-wf-text").text(this.workflowSelected);
        
        // disable reset config button until a workflow is selected
        $("#reset-workflow-config").prop("disabled", true);

      },
      serialize: function() {
        return {
          currentWfs: _.sortBy(this.currentWorkflows, 'name')
        };
      }
    });

    return WorkflowConfig;

  });