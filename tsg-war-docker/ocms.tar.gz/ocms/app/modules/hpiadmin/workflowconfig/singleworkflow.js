// WorkflowFormconfig module
define([
  "app",
  "modules/common/workflow"
],

  function (app, Workflow) {
    "use strict";
    var SingleWorkflow = app.module();

    // Default Model.
    SingleWorkflow.Model = Backbone.Model.extend({
      type: "WorkflowConfig",
      defaults: {
        type: "WorkflowConfig"
      },
      initialize: function (options) { },
      parse: function (response) { }
    });

    SingleWorkflow.View = Backbone.View.extend({
      template: "hpiadmin/workflowconfig/singleworkflow",
      events: {
        'click #existing-wf-form': 'wfFormSelected'
      },
      initialize: function (options) {
        this.options = options;
        this.config = {};
        this.currentWfTasks = options.currentWfTasks;
        this.wfName = options.workflow.name;
        this.workflowId = options.workflow.id;
        this.currentWfForms = options.currentWfForms;
        this.existsOnForm = options.existsOnForm;
      },
      loadExistingForm: function () {
        var self = this;
        self.config = this.currentWfTasks;
        _.each(this.currentWfTasks, function (task) {
          // Set description input if description exists
          if (task.description) {
            $("#" + task.id + "-description").val(task.description);
          }
          
          // Display selected form, if one exists
          if (task.configName) {
            $("#" + task.id + "btn").text(task.configName);
          }
        });
      },
      createNewForm: function () {
        var self = this;
        self.config = [];
        _.each(this.currentWfTasks, function (task) {
          var taskInfo = {};
          taskInfo.name = task.name;
          taskInfo.id = task.id;
          taskInfo.description = task.description;
          taskInfo.configName = task.configName;
          self.config.push(taskInfo);
        });
      },
      wfFormSelected: function (evt) {
        evt.preventDefault();
        var idForTask = $(evt.target.parentNode).attr('formWith');
        $("#" + idForTask + "btn").text(evt.target.text);
        this.updateConfig(idForTask, evt.target.text.trim());
      },
      updateConfig: function (taskId, formSelected) {
        var task = _.findWhere(this.config, { 'id': taskId });
        task.configName = formSelected;
      },
      setDescriptions: function () {
        var self = this;
        _.each(this.currentWfTasks, function (task) {
          var taskInfo = _.findWhere(self.config, {
            'id': task.id
          });
          taskInfo.description = $("#" + task.id + "-description").val();
        });
      },
      afterRender: function () {
        this.$("#current-wf-text").text(this.wfName);
        if (this.existsOnModel) {
          this.loadExistingForm();
        } else {
          this.createNewForm();
        }
      },
      serialize: function () {
        return {
          currentWfTasks: this.currentWfTasks,
          wfName: this.wfName,
          currentWfForms: this.currentWfForms
        };
      }
    });

    return SingleWorkflow;

  });