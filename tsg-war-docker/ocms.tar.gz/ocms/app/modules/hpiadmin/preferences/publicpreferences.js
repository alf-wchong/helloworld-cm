// Public preferences module
define([
        // Application.
        "app",
        "modules/hpiadmin/hpiadmin",
        "module",
        "moment"
    ],

    function(app, Hpiadmin, module, moment) {
        window.localize("modules.hpiAdmin.preferences.publicPreferences.useStrict"); //let's help out our linters

        var PublicPreferences = app.module();

        PublicPreferences.SavedSearchModel = Backbone.Model.extend({
            trac: '',
            modifiedDate: moment(),
            modifier: ''
        });

        PublicPreferences.SavedSearches = Backbone.Collection.extend({
            model: PublicPreferences.SavedSearchModel
        });

        PublicPreferences.Config = Backbone.Model.extend({
            defaults: {
                savedSearches: new PublicPreferences.SavedSearches(),
                version: false
            },
            parse: function(response) {
                if (response) {
                    if (typeof response === "string") {
                        var responseJson = JSON.parse(decodeURIComponent(response));
                        if (responseJson.savedSearches && responseJson.savedSearches.length > 0) {
                            responseJson.savedSearches = new PublicPreferences.SavedSearches(responseJson.savedSearches);
                        } else {
                            responseJson.savedSearches = new PublicPreferences.SavedSearches();
                        }
                        return responseJson;
                    } else {
                        //This would probably be better off returning the parent parse method
                        if (response.savedSearches && response.savedSearches.length > 0) {
                            response.savedSearches = new PublicPreferences.SavedSearches(response.savedSearches);
                        } else {
                            response.savedSearches = new PublicPreferences.SavedSearches();
                        }
                        return response;
                    }
                } else {
                    return response;
                }

            },
            url: function() {
                return Hpiadmin.configURLRoot + "publicPreferences/" + this.get("tracName") + "?latest=true" + "&appId=" + app.appId;
            },
            save: function(attrs, options) {
                return Backbone.Model.prototype.save.call(this, attrs, _.extend({}, options, {
                    type: 'POST'
                }));
            }
        });

        PublicPreferences.Collection = Backbone.Collection.extend({
            model: PublicPreferences.Config,
            fetch: function() {
                var that = this;
                var deferreds = [];
                app.context.tracConfigs.forEach(function(tracConfig) {
                    var name = tracConfig.get("name");
                    var newPref = new PublicPreferences.Config({ tracName: name, tracLabel: tracConfig.get("displayName") });
                    var deferred = $.Deferred();
                    deferreds.push(deferred);
                    newPref.fetch({
                        success: function(gottenPublicPrefs) {
                            that.add(gottenPublicPrefs);
                            deferred.resolve();
                        },
                        error: function() {
                            var newPublicPrefs = new PublicPreferences.Config({ tracName: name, tracLabel: tracConfig.get("displayName") });
                            that.add(newPublicPrefs);
                            deferred.resolve();
                            newPublicPrefs.save(); //save so we prevent errors from popping up in the future
                        }
                    });
                });
                return $.when.apply($, deferreds);
            }
        });



        return PublicPreferences;
    });