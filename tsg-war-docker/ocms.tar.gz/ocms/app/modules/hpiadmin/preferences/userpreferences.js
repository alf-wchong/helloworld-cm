// Stageconfig module
define([
    // Application.
    "app",
    "modules/hpiadmin/hpiadmin",
    "module"
],

// Map dependencies from above array.
function(app, Hpiadmin, module) {
    "use strict";


    // Create a new module.
    var UserPreferences = app.module();

    // Determine which implementation to use based on "location" defined in config-project
    UserPreferences.getUserPreferences = function(options) {
        var location = module.config().location || "repo";
        if(location === "repo") {
            return new UserPreferences.RepoConfig(options);
            } else if (location === "localstorage") {
            return new UserPreferences.LocalStorageConfig(options);
        }
    };

    UserPreferences.SavedSearchModel = Backbone.Model.extend({
        'trac': '' //default is an emtpy trac
    });

    UserPreferences.SavedSearches = Backbone.Collection.extend({
        model : UserPreferences.SavedSearchModel
    });

    //Base userpreferences that contains all logic shared between implementations
    UserPreferences.Config = Backbone.Model.extend({
        defaults : {
            savedSearches : new UserPreferences.SavedSearches(),
            searchResultsTableview: {},
            recentObjectsDashlets : {},
            resultsPerPage : "",
            roleBasedView: {
                name: "",
                filter: {}
            },
            allDashletOrders: {},
            lastSearchResultView: "",
            workflowProxy : {
                enabled: false,
                delegatedLoginName: "",
                delegatedDisplayName: ""
            },
            tours: {
              search: module.config().showSearchTour === undefined ? true : module.config().showSearchTour,
              stage:module.config().showStageTour === undefined ? true : module.config().showStageTour,
              dashboard: module.config().showDashboardTour === undefined ? false : module.config().showDashboardTour
            }
        },
        parse : function(response){
            if( typeof response === "string"){
                response = JSON.parse(decodeURIComponent(response));
            }
            // Expecting response to be an object and handling as such
            if(response){
                if(response.savedSearches && response.savedSearches.length > 0){
                    response.savedSearches = new UserPreferences.SavedSearches(response.savedSearches);
                } else {
                    response.savedSearches = new UserPreferences.SavedSearches();
                }
                return response;
            } else {
                return response;
            }
        },

        url: function(){
                return Hpiadmin.configURLRoot + "userPreferences/" + this.get("name") + "?latest=true" + "&appId=" + app.appId;
        },
        save: function(attrs, options){
            return Backbone.Model.prototype.save.call(this, attrs, _.extend({}, options, {
                type: 'POST'
            }));
        },
        //save now and don't wait the usual minute
        saveNow: function(attrs, options){
            return Backbone.Model.prototype.save.call(this, attrs, _.extend({}, options, {
                'type': 'POST',
                'async': false
            }));
        }
    });

    //Local Storage implementation
    UserPreferences.LocalStorageConfig = UserPreferences.Config.extend({
        sync : function(method, model, options){
            if(method === 'read') {
                var data = window.localStorage.getItem("userPrefs");
                if(data) {
                    options.success(data, 'success', null);
                } else {
                window.localStorage.setItem("userPrefs", JSON.stringify(model));
                options.success(this.defaults, 'success', null);
                }
            } else {
                window.localStorage.setItem("userPrefs", JSON.stringify(model));
            }
            //since we sync to local storage, no need for ajax request, just call any .done
            //function the user expects (for compatibility)
            return {
                done: function(callback) {
                    callback();
            }};
        }
    });

    // Repo Implementation
    UserPreferences.RepoConfig = UserPreferences.Config.extend({
        save: _.throttle(function(attrs, options) {
            //throttle the save so that it only happens every minutes
            // Proxy the call to the original save function
            return Backbone.Model.prototype.save.call(this, attrs, _.extend({}, options, {
                type: 'POST',
                global: false // prevent the loading backdrop from appearing
            }));
        }, 60000)
    });

     /**
     * Adds the current object (currently only supports folders) to the recentObjects section
     * of the user preferences cookie. These recent objects can be displayed in a dashlet
     * for user interaction.
     */
    UserPreferences.pushRecentObjects = function() {
        // get the dashboard config so we can check if we have a recent objects dashlet
        app.context.configService.getDashboardConfig(function(dashconfig) {
            //get the user preferences so the recent objects will be defined  
            app.context.configService.getUserPreferences(function(userprefs) {
                // check to make sure the container objectId does not match the document objectId - if it does,
                // then this is most likely a PSI, which we don't support right now
                if(app.context.container.get("objectId") !== app.context.document.get("objectId")) {

                    // find a recent objects dashlet
                    var recentObjectsDashlets = dashconfig.get("dashlets").where({
                        dashletType: "RecentObjectsDashlet"
                    });

                    _.each(recentObjectsDashlets, function(recentObjectsDashlet) {

                        var docOrFolder;
                        if(recentObjectsDashlet.get("parentObjectType") === "Folder") {
                            docOrFolder = app.context.container;
                        }
                        else if(recentObjectsDashlet.get("parentObjectType") === "Document") {
                            docOrFolder = app.context.document;
                        }

                        if (docOrFolder && docOrFolder.get("objectId")) {
                            var currDashType = recentObjectsDashlet.get("selectedTypeForAttrs");
                            var currObjectType = docOrFolder.get("objectType");
                            //filters out document or folders for different custom dashlet types or
                            //if it is a generic folder or document we want to put anything in the dashlet
                            if(currDashType === currObjectType || currDashType === "Folder" || currDashType ==="Document"){                         
                                var recentObjectNameAttr = recentObjectsDashlet.get("objectName");
                                var recentObjectNameValue;

                                if(!recentObjectNameAttr || recentObjectNameAttr === "") {
                                    recentObjectNameValue = docOrFolder.get("properties").objectName;
                                } else  {
                                    recentObjectNameValue = _.find(docOrFolder.get("properties"), function(num, key){
                                        return key === recentObjectNameValue; 
                                    });
                                }

                                // construct our recent object
                                var recentObject = {
                                    recentObjectId: docOrFolder.get("objectId"),
                                    recentObjectName: recentObjectNameValue
                                };         

                                var recentObjectsUserPref = app.context.currentUserPreferences().get("recentObjectsDashlets"); 

                                if(!recentObjectsUserPref[recentObjectsDashlet.get("dashletId")]) {
                                    recentObjectsUserPref[recentObjectsDashlet.get("dashletId")] = [];
                                }      

                                // get our user's recent objects
                                var dashletUserPref = recentObjectsUserPref[recentObjectsDashlet.get("dashletId")];
                                
                                //if the userpreferences has nothing in it add our recentObject
                                if( dashletUserPref.length < 1) {
                                    //add the recent object that the user is viewing user preferences
                                    dashletUserPref.push(recentObject);
                                }
                                // check to see if we already have a recent object with the same name as the one we're adding
                                var existingRecentObjectWithSameId = _.findWhere(dashletUserPref, {
                                    recentObjectId: docOrFolder.get("objectId")
                                });

                                if(existingRecentObjectWithSameId) {
                                    // get rid of the old recent objects (since we're adding it to the top now with
                                    // possibly updated property values)
                                    dashletUserPref = _.filter(dashletUserPref, function(objectInList){
                                        return objectInList.recentObjectId !== existingRecentObjectWithSameId.recentObjectId;
                                    });
                                }
                                //only show the configured number of recentObjects
                                var maxLength = recentObjectsDashlet.get("numberOfObjects");

                                while(dashletUserPref.length >= maxLength){
                                    dashletUserPref.pop();
                                }

                                if(!_.findWhere(dashletUserPref, {recentObjectId: recentObject.recentObjectId})){

                                    dashletUserPref.unshift(recentObject);
                                }
                                    
                                //set the recent objects on the dashlet-id
                                recentObjectsUserPref[recentObjectsDashlet.get("dashletId")] = dashletUserPref;
                                //update the recentObjectsDashlets user pref
                                app.context.currentUserPreferences().set("recentObjectsDashlets", recentObjectsUserPref);    
                            }
                        
                        } 
      
                    });  
                }
            });         
        });
    };

    // Return the module for AMD compliance.
    return UserPreferences;
    });