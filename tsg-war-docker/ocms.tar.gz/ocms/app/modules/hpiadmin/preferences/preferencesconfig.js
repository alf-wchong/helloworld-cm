//Index Inbox module
define([
	// Application.
	"app",
	"modules/hpiadmin/preferences/userpreferences",
	"modules/hpiadmin/preferences/publicpreferences",
	"module",
	"modules/common/queryabletypeahead",
	"modules/hpiadmin/searchconfig/searchconfig",
	"modules/hpiadmin/preferences/dashboardpreferencesview"
],

	function(app, UserPreferences, PublicPreferences, module, QueryableTypeahead, SearchConfig, DashboardPreferencesView) {

		// Create a new module.
		var PreferencesConfig = app.module();

		// Default View.
		PreferencesConfig.Views.Layout = Backbone.Layout.extend({
			template: "hpiadmin/preferences/preferencesconfig",
			className : "preferencesconfig",
			events: {
				"click #savedSearch-pref-btn": "clearAllSavedSearchs",
				"click #tableColumns-pref-btn": "resetTableColumns",
				"click #dashletOrder-pref-btn": "resetDashletOrder",
				"click .savedSearchEdit": "openEdit",
				"click .publicSavedSearchEdit": "openPubEdit",
				"click .savedSearchSave": "updateName",
				"click .savedSearchDelete": "removeSavedSearch",
				"keyup .savedSearchNameInput": "checkEnter",
				"keydown .savedSearchNameInput": "checkEnter",
				"click .savedSearchDeleteTrac": "deleteAllSearchesInTrac",
				"change #autoMinimize": "toggleAutoMinimize",
				"change #workflowProxySwitch": "updateProxyBoolean",
				"click #workflowProxySubmitButton": "submitWorkflowProxy",
				"keydown #workflowProxyUserList" : "sanitizeKey",
				"click .publishSavedSearch" : "publishSavedSearch",
				"click #pubSavedSearch-pref-btn" : "clearAllPublicSavedSearch",
				"click .publicSavedSearchSave" : "savePublicSearchName",
				"click .publicSavedSearchDelete" : "deletePublicSearch",
				"click .publicSavedSearchDeleteTrac" : "deleteTracPublicSearch",
				"change .tourSlider": "updateTourPrefs"
			},
			initialize: function() {
				var self = this;
				this.name = "PreferencesConfig";
				this.currentUserPreferences = this.options.config;
				this.anyPSSuneditable = false;
				this.userWorkflowTypeahead = new QueryableTypeahead({
	                queryUrl: app.serviceUrlRoot + "/aw-workflow/searchWizardContributors",
	                displayKey: 'displayName',
	                searchOn: 'displayName',
	                placeholder: 'Start typing here...'
	            });
				this.publicPreferences = this.options.publicPreferences;
				var publishingGroupDef = this.setPublishingGroups(this.publicPreferences);

				if(self.currentUserPreferences.get("tours")){
					this.toursAvailable = _.without(_.keys(self.currentUserPreferences.get('tours')), '_id');
				} else{
					this.currentUserPreferences.set("tours", {
						'search' : false,
						'stage' : false,
						'dashboard' : false
					});
				}
				
				
				
				// render the view once sortSavedSearchesByTrac function has finished
				var sortSearchesDef = this.sortSavedSearchesByTrac();

				
				$.when.apply($, [publishingGroupDef, sortSearchesDef]).then(function() {
					self.isAnyPSSUneditable();
					self.render();
				});

		
			},
			beforeRender: function() {
				this.setView("#workflowProxyUserList", this.userWorkflowTypeahead);
				this.buildDashboardPreferencesMap();
			},
			afterRender: function(){
				var self = this;
				if(self.currentUserPreferences.get("autoMinimize")){
					$("#enableAutoMinimize").prop("checked", true);
				} 
				if(self.currentUserPreferences.get("workflowProxy")) {
					self.workflowProxy = _.clone(self.currentUserPreferences.get("workflowProxy"));
					if(self.workflowProxy.enabled) {
						self.toggleUserTypeahead(true);
						self.toggleSlide(true);
					} 
					else {
						self.toggleUserTypeahead(false);
						self.toggleSlide(false);
					}
				} else {
					self.workflowProxy = {
						enabled: false,
						delegatedLoginName: "",
						delegatedDisplayName: ""
					};
					self.toggleSlide(false);
					self.toggleUserTypeahead(false);
				}
				if(this.options.initialTab){ // routed from the dashboard to route directly to another tab
					// remove active classes from user search prefs
					$('.userPrefTab').removeClass("active");

					if(this.options.initialTab === "workflow"){
						$("#workflowPrefsTab").addClass("active"); // activate the workflow tab and its content via the data-target id selector
						$($("#workflowPrefsTab > a").attr("data-target")).addClass("active"); // jquery selects 'a' child from our tab
					} else if(this.options.initialTab === "dashboard"){
						$("#userDashletPrefsTab").addClass("active"); // activate the dashlet tab and its content via the data-target id selector
						$($("#userDashletPrefsTab > a").attr("data-target")).addClass("active"); 
					}

				}
	            self.startListeningToUserList();
							
							
							/**
							 * hides the dashboard tour slider and label
							 * remove this when the dashboard tour is implemented!!!!!!
							 */
							$("#dashboardTourLabel").hide();
							$("#completedashboardTour").hide();


				_.each(this.toursAvailable, function(tour){
					$("#enable" + tour).prop("checked", self.currentUserPreferences.get('tours')[tour]);
				});
			},

			buildDashboardPreferencesMap: function() {
				var dashboardPreferencesMap = {};
				var self = this;
				
				app.context.configService.getDashboardConfig(function(dashboardConfig){
					_.each(dashboardConfig.get('tabs'), function(tab) {
						var tabDashlets = [];
						var selectedDashlets = tab.selectedDashlets;
						_.each(selectedDashlets, function(dashletConfig){
							var dashletModel = dashboardConfig.get("dashlets").findWhere({ dashletId : dashletConfig.dashletId });
	
							tabDashlets.push(dashletModel.attributes);
						});
	
						dashboardPreferencesMap[tab.tabName] = tabDashlets;
					});

					self.dashboardPreferencesView = new DashboardPreferencesView.View({
						dashboardMap: dashboardPreferencesMap
					});
					self.setView("#dashletTabSlidersContainer", self.dashboardPreferencesView);
				});
			},
			updateTourPrefs: function(e){
				var tourChanged = $(e.currentTarget).attr('value');
				if($(e.target).val() === 'true'){
					this.currentUserPreferences.get('tours')[tourChanged] = true;
				} else{
					this.currentUserPreferences.get('tours')[tourChanged] = false;
				}
				this.currentUserPreferences.save({version: false}, {global: false});
			},

			toggleSlide: function(enabled) {
				$("#enableWorkflowProxy").prop("checked", enabled);
				$("#disableWorkflowProxy").prop("checked", !enabled);
			},

			toggleUserTypeahead: function(visible) {
				var self = this;
				if(visible) {
					$(".hiddenProxy").show("fast");
					$(".hiddenProxy input.form-control").val(self.workflowProxy.delegatedDisplayName);
				} else {
					$(".hiddenProxy").hide("fast");
				}
			},

			removeSavedSearch: function(event){
				var self = this;
				var searchName = $(event.target).val();
				var removeModel = this.currentUserPreferences.get("savedSearches").findWhere({name: searchName});
				app.trigger("alert:confirmation", {
					header : "Clear Saved Search",
					message : "Would you like to delete " + searchName + "?",
					confirm: function() {
						// remove the search from self.savedSearches for the specific trac
						var tracSavedSearches = _.findWhere(self.savedSearches, {tracValue: removeModel.get("trac")});
						tracSavedSearches.searches = _.filter(tracSavedSearches.searches, function(value){
							if(value.get("name") === searchName){
								return false;
							}
							return true;
						});
						self.currentUserPreferences.get("savedSearches").remove(removeModel);
						self.render();
						self.currentUserPreferences.save({version: false}, {global: false});
					}
				});
			},
			openEdit: function(event){
				var searchName = $(event.target).val();
				if(searchName){
					this.currentUserPreferences.get("savedSearches").where({name: searchName})[0].set("edit", true);
					this.render();
				}
			},
			updateName: function(event){
				var searchName = $(event.target).val();
				var newName = $(event.target.parentElement).siblings("input").val();
				var blankElement = $(event.target.parentElement.parentElement).siblings();
				this.updateNameNoEvent(searchName, newName, blankElement);
			},
			updateNameNoEvent: function(searchName, newName, blankElement){
				if(newName.length > 0){
					this.currentUserPreferences.get("savedSearches").where({name: searchName})[0].set("edit", false);
					this.currentUserPreferences.get("savedSearches").where({name: searchName})[0].set("name", newName);
					this.render();
					this.currentUserPreferences.save({version: false}, {global: false});
				}
				else{
					this.$(blankElement).show();
				}
			},
			clearAllSavedSearchs: function(event){
				var self = this;
				app.trigger("alert:confirmation", {
					header : window.localize("modules.hpiAdmin.preferences.preferencesConfig.deleteSavedSearches"),
					message : window.localize("modules.hpiAdmin.preferences.preferencesConfig.wouldYouLike"),
					confirm: function() {
						self.savedSearches = [];
						self.currentUserPreferences.set("savedSearches", new UserPreferences.SavedSearches());
						self.render();
						self.currentUserPreferences.save({version: false}, {global: false});
					}
				});
			},
			deleteAllSearchesInTrac: function(event){
				var self = this;
				var trac = event.target.value;
				app.trigger("alert:confirmation", {
					header : window.localize("modules.hpiAdmin.preferences.preferencesConfig.deleteSavedSearches"),
					message : window.localize("modules.hpiAdmin.preferences.preferencesConfig.wouldYouLikeToClear") + trac + window.localize("modules.hpiAdmin.preferences.preferencesConfig.trac"),
					confirm: function() {
						self.savedSearches = _.filter(self.savedSearches, function(value) {
							if(value.tracValue === trac) {
								return false;
							}
							return true;
						});
						self.currentUserPreferences.get("savedSearches").remove(self.currentUserPreferences.get("savedSearches").where({trac: trac}));
						self.render();
						self.currentUserPreferences.save({version: false}, {global: false});
					}
				});
			},
			resetTableColumns: function(event){
				var self = this;
				app.trigger("alert:confirmation", {
					header : window.localize("modules.hpiAdmin.preferences.preferencesConfig.resetTableViewColumns"),
					message : window.localize("modules.hpiAdmin.preferences.preferencesConfig.wouldYouLikeToReset"),
					confirm: function() {
						self.currentUserPreferences.set("searchResultsTableview", {});
						app.trigger("alert:changeNotification", "alert-success", window.localize("modules.hpiAdmin.preferences.preferencesConfig.successfullyReset"), "#userPreference-search-section");
						self.currentUserPreferences.save({version: false}, {global: false});
					}
				});
			},
			checkEnter: function(event){
				if(event.keyCode === 13){
					event.preventDefault();
					event.stopPropagation();
					var newName = $(event.target).val();
					var searchName = $(event.target).siblings("span.savedSearchSaveSpan").attr("value");
					var blankElement = $(event.target.parentElement).siblings();
					this.updateNameNoEvent(searchName, newName, blankElement);
				}
			},
			sortSavedSearchesByTrac: function(){
				var self = this;
				var tracs = [];
				var deferredCalls = [];

				// waits for all deferreds in deferredCalls array to resolve
				var overallDeferred = new $.Deferred();  

				this.currentUserPreferences.get("savedSearches").each(function(model){
					if(_.where(tracs, {name: model.get("trac")}).length === 0){
						tracs.push({name: model.get("trac")});
					}
				});

				this.savedSearches = [];

				_.each(tracs, function(trac){
					var currentTrac = app.context.tracConfigs.findWhere({name: trac.name});
					if(currentTrac){
						//if there is a saved search for a non-existing trac, we aren't going to show it
						var tracLabel = currentTrac.get("displayName");
						var tracName = currentTrac.get("name");
						var searchConfigName = currentTrac.get("SearchConfig");

						// create a deferred for each search config that the overall deferred will wait for
						var searchDeferred = new $.Deferred(); 
						deferredCalls.push(searchDeferred);

						// builds up the object for savedSearches array
						app.context.configService.getSearchConfigByName(searchConfigName, function(searchConfig) {
							var newObject = {
								tracLabel: tracLabel ? tracLabel : trac.name,
								tracValue: trac.name,
								searches : self.currentUserPreferences.get("savedSearches").where({trac: trac.name}),
								enabledPublicSavedSearch: searchConfig.get("sidebarConfig").get("enabledPublicSavedSearch"),
								ableToPublishSavedSearch: self.ableToPublish(trac.name)
							};
							self.savedSearches.push(newObject);
							searchDeferred.resolve();
						});
					}
				});

				// Once all the deferreds in deferredCalls have been resoved, resolve our overall Deferred
				$.when.apply($, deferredCalls).then(function() {
					overallDeferred.resolve();
				});
				return overallDeferred;
			},

			setPublishingGroups: function(tracsWithConfigs){
				var self = this;
				var deferredCalls = [];
				var overallDeferred = new $.Deferred();  

				
				var currentUserGroups = _.pluck(app.user.get("groups"),'authorityId');
					//get each trac with 
				_.each(tracsWithConfigs.models, function(trac){
					var currentTrac = app.context.tracConfigs.findWhere({name: trac.get("tracName")});
					if(currentTrac){
						//if there is a saved search for a non-existing trac, we aren't going to show it

						var searchConfigName = currentTrac.get("SearchConfig");

						// create a deferred for each search config that the overall deferred will wait for
						var searchDeferred = new $.Deferred(); 
						deferredCalls.push(searchDeferred);

						app.context.configService.getSearchConfigByName(searchConfigName, function(searchConfig) {
							var groupsAllowedOnTrac =searchConfig.get("savedSearchAdminGroups").models;
							var attributes = _.pluck(groupsAllowedOnTrac, 'attributes');
							groupsAllowedOnTrac = _.pluck(attributes, 'name');
							if (groupsAllowedOnTrac.length < 1 || _.intersection(groupsAllowedOnTrac, currentUserGroups).length > 0) {
								trac.set('editiblePSSUser', true);
							}else{
								trac.set('editiblePSSUser', false);
							}
							searchDeferred.resolve();
						});
					}
				});

				
				// Once all the deferreds in deferredCalls have been resoved, resolve our overall Deferred
				$.when.apply($, deferredCalls).then(function() {
					overallDeferred.resolve();
				});
				return overallDeferred;


			},
			isAnyPSSUneditable: function(){
				var self = this;
				_.each(this.publicPreferences.models, function(model){
					if(model.attributes.savedSearches.length>0){
						if(model.attributes.editiblePSSUser == false){
							self.anyPSSuneditable = true;
						}
					}
				});

			},
			ableToPublish: function(trac){

				var canPublish;
				_.each(this.publicPreferences.models, function(model){
					if(model.get("tracName")==trac){
						canPublish = model.get("editiblePSSUser");
						return;
					}
				}, canPublish);

				return canPublish;
			},
			serialize: function() {
				return { 
					"userPreferencesTitle" : module.config().userPreferencesTitle || window.localize("header.userPreferences.title"),
					"savedSearches": this.savedSearches,
					"publicPreferences": this.publicPreferences,
					"toursAvailable" : this.toursAvailable || [],
					"enableWizard" : app.enableWizard,
					"anyUneditableFields": this.anyPSSuneditable
				};
			},
			resetDashletOrder: function() {
				var self = this;
				app.trigger("alert:confirmation", {
					header : window.localize("modules.hpiAdmin.preferences.preferencesConfig.resetDashletOrder"),
					message : window.localize("modules.hpiAdmin.preferences.preferencesConfig.wouldYouLikeToResetDashboard"),
					confirm: function() {
						self.currentUserPreferences.set("allDashletOrders", {});
						app.trigger("alert:changeNotification", "alert-success", window.localize("modules.hpiAdmin.preferences.preferencesConfig.successfullyResetDashlet"), "#userPreference-dashlet-section");
					}
				});
			},
			toggleAutoMinimize: function(){
				if($("#enableAutoMinimize").is(":checked")){
					this.currentUserPreferences.set("autoMinimize", true);
				} else{
					this.currentUserPreferences.set("autoMinimize", false);
				}
				this.currentUserPreferences.save({version: false}, {global: false});				
			}, 
			updateProxyBoolean: function() {
				var self = this;
				if($("#enableWorkflowProxy").is(":checked")) {
					self.toggleUserTypeahead(true);
					self.toggleSubmit(false);
				} else {
					self.clearUserInput();
					self.userWorkflowTypeahead.clear();
					self.workflowProxy.enabled = false;
					self.workflowProxy.delegatedLoginName = "";
					self.workflowProxy.delegatedDisplayName = "";
					self.toggleSubmit(true);
					self.toggleUserTypeahead(false);
				}
			},
	        clearUserInput: function(){
	            var self = this;
	            self.workflowProxy.delegatedDisplayName = "";
	            self.workflowProxy.delegatedLoginName = "";
	            self.isLastUserSelectionValid = false;
	        },
			startListeningToUserList: function() {
				var self = this;

	            if(self.userWorkflowTypeahead){
	                self.stopListening(self.userWorkflowTypeahead);
	                self.listenTo(self.userWorkflowTypeahead, 'change:selected', function(option){
	                    if(option){
	                        self.selectedUserEventHandler(option);
	                    }
	                    else{
	                    	self.workflowProxy.enabled = false;
	                        self.workflowProxy.delegatedLoginName = '';
	                        self.workflowProxy.delegatedDisplayName = '';
	                        self.toggleSubmit(false);
	                    }
	                }, self);

	                self.listenTo(self.userWorkflowTypeahead, 'typeahead:clear', function(){
	                    self.clearUserInput();
	                }, self);
	            }
	        },
	        sanitizeKey: function(evt){
	            //catch the enter key to prevent the query text being set as the selected user
	            var code = evt.keyCode || evt.which;
	            if(code === 13){
	                //prevent default for enter key only
	                evt.preventDefault();
	            }
	        },
	        selectedUserEventHandler: function(userSelected){
	            var self = this;
	            self.toggleSubmit(false);
	            self.workflowProxy.delegatedLoginName = userSelected.authorityId;
	            self.workflowProxy.delegatedDisplayName = userSelected.displayName;
	            self.workflowProxy.enabled = true; 
	            self.updateProxyValidate();
	        },
	        updateProxyValidate: function() {
	        	var self = this;
	        	if(self.workflowProxy && self.workflowProxy.enabled) {
	        		if(self.workflowProxy.delegatedLoginName && self.workflowProxy.delegatedLoginName !== '' && 
	        			self.workflowProxy.delegatedDisplayName && self.workflowProxy.delegatedDisplayName !== '') 
	        		{
	        			self.toggleSubmit(true);
	        		} else {
	        			self.toggleSubmit(false);
	        		}
	        	} else {
	        		self.toggleSubmit(true);
	        	}
	        },
		    toggleSubmit: function(enabled){
		    	var self = this;
	            $("#workflowProxySubmitButton").prop("disabled", !enabled);
	            self.submitDisabled = !enabled;
	        },

	        submitWorkflowProxy: function() {
	        	var self = this;
	        	if(self.submitDisabled) {
	        		return;//do nothing.
	        	}
	        	var updateUrl = app.serviceUrlRoot + "/users/setInboxProxy";
	        	var urlFriendlyWorkflow = {
	        		"proxyUserLoginName" : self.workflowProxy.delegatedLoginName
	        	};
	        	self.tempWorkflow = self.currentUserPreferences.get("workflowProxy");

	        	$.ajax({
						url: updateUrl, 
						type: "POST",
						contentType: "application/json",
						data: JSON.stringify(urlFriendlyWorkflow),
						success: function (result) {
							//perform save here to ensure configuration is synchronized with database:
							self.currentUserPreferences.set("workflowProxy", self.workflowProxy);
							self.currentUserPreferences.save({version: false}, {global: false});
							app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");

						},
						error: function(jqXHR, textStatus, errorThrown) {
							var messageContents = "";
							if(errorThrown.indexOf("Forbidden") > -1) {
								messageContents = window.localize("modules.hpiAdmin.preferences.preferencesConfig.yourConfigSaveFailedSelected");
							} else {
								messageContents = window.localize("modules.hpiAdmin.preferences.preferencesConfig.yourConfigSaveFailedSaving");
							}
							app.trigger("alert:error", {
                            	header : "Error Saving Config",
                            	message : messageContents
							});
							self.workflowProxy = self.tempWorkflow;//reset the backup settings. 
							self.currentUserPreferences.set("workflowProxy", self.workflowProxy);

						},
						global : false
				});
	        },

	        publishSavedSearch : function(evt) {
	        	var that = this;
	        	var savedSearchName = evt.currentTarget.value;
	        	var savedSearch = this.currentUserPreferences.get("savedSearches").findWhere({name: savedSearchName});
	        	var publicPref = this.publicPreferences.findWhere({tracName: savedSearch.get("trac")});
	        	app.trigger("alert:confirmation", {
	        		header: window.localize("publicPreferences.publishSavedSearch.header"),
	        		message: window.localize("publicPreferences.publishSavedSearch.msg"),
	        		confirm: function() {
	        			var tracSavedSearches = _.findWhere(that.savedSearches, {tracValue: savedSearch.get("trac")});
	        			tracSavedSearches.searches = _.filter(tracSavedSearches.searches, function(value){
	        				if(value.get("name") === savedSearchName){
	        					return false;
	        				}
	        				return true;
	        			});
			        	savedSearch.set("modifiedDate", moment());
			        	savedSearch.set("modifier", app.user.get("displayName") + " (" + app.user.get("loginName") + ")");
			        	publicPref.get("savedSearches").add(savedSearch);
			        	that.currentUserPreferences.get("savedSearches").remove(savedSearch);
			        	publicPref.save();
			        	that.currentUserPreferences.save();
			        	that.render();
	        		}
	        	});
	        },

	        clearAllPublicSavedSearch: function(evt) {
	        	var that = this;
	        	app.trigger("alert:confirmation", {
					header : window.localize("publicPreferences.delete.all"),
					message: window.localize("publicPreferences.delete.all.msg"),
					confirm: function() {
			        	that.publicPreferences.forEach(function(publicPref) {
			        		publicPref.get("savedSearches").reset();
			        		publicPref.save();
			        	});
			        	that.render();
					}
				});
	        },
	        /**
	        	Here, because we mask our buttons to have the value "searchName_trac_tracName",
	        	we provide a function to cleanly separate that out for us.
	        **/

	        translateSavedSearchEvent: function(evtName) {
	        	var rawVal = evtName;
	        	var searchName = rawVal.slice(0, rawVal.lastIndexOf('_trac_'));
	        	var tracName = rawVal.slice(rawVal.lastIndexOf('_trac_') + '_trac_'.length);
	        	return {searchName: searchName, tracName: tracName};
	        },

	        openPubEdit: function(evt) {
	        	var rawVal = $(evt.target).val();
	        	var vals = this.translateSavedSearchEvent(rawVal);
	        	var tracPublicPref = this.publicPreferences.findWhere({tracName: vals.tracName});
	        	var savedSearch = tracPublicPref.get("savedSearches").findWhere({name: vals.searchName});
	        	savedSearch.set("edit", true);
	        	this.render();
	        },
	        savePublicSearchName: function(evt) {
	        	var vals = this.translateSavedSearchEvent($(evt.target).val());
	        	var tracPublicPref = this.publicPreferences.findWhere({tracName: vals.tracName});
	        	var savedSearch = tracPublicPref.get("savedSearches").findWhere({name: vals.searchName});
	        	var newName = $(evt.target).parent().siblings("input").val();
	        	savedSearch.set("edit", false);
	        	savedSearch.set("name", newName);
	        	savedSearch.set("modifier", app.user.get("displayName") + " (" + app.user.get("loginName") + ")");
	        	savedSearch.set("modifiedDate", moment());
	        	tracPublicPref.save();
	        	this.render();
	        },

	        deletePublicSearch: function(evt) {
	        	var that = this;
	        	var vals = this.translateSavedSearchEvent($(evt.target).val());
	        	var tracPublicPref = this.publicPreferences.findWhere({tracName: vals.tracName});
	        	var savedSearch = tracPublicPref.get("savedSearches").findWhere({name: vals.searchName});
	        	app.trigger("alert:confirmation", {
					header : window.localize("publicPreferences.delete"),
					message: window.localize("publicPreferences.delete.msg"),
					confirm: function() {
			        	tracPublicPref.get("savedSearches").remove(savedSearch);
			        	tracPublicPref.save();
			        	that.render();
					}
				});	        
	        },

	        deleteTracPublicSearch: function(evt) {
	        	var that = this;
	        	var val = $(evt.target).val();
	        	var tracPublicPref = this.publicPreferences.findWhere({tracName: val});
	        	app.trigger("alert:confirmation", {
					header : window.localize("publicPreferences.delete.trac"),
					message: window.localize("publicPreferences.delete.trac.msg"),
					confirm: function() {
			        	tracPublicPref.get("savedSearches").reset();
			        	tracPublicPref.save();
			        	that.render();
					}
				});
	        }


	    });
				

		// Return the module for AMD compliance.
		return PreferencesConfig;

	});
