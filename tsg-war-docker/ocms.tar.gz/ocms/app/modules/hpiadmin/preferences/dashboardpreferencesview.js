define([
	'app',
    'modules/hpiadmin/common/iosswitch'
], function(app, iOSSwitch){
    var DashboardPreferencesView = {};
    
	DashboardPreferencesView.View = Backbone.Layout.extend({
		template: 'hpiadmin/preferences/dashboardpreferencesview',
		events: {
            'click .clearSearchBtn' : 'clear',
            'change .dashletSwitchContainer': 'toggleDashletVisibility'
		},
		initialize: function(config){
			this.options = (config.options instanceof Backbone.Collection ? _.pluck(config.options.models, 'attributes') : config.options) || [];
			if(!this.options){
				this.options = [];
            }
            this.dashboardMap = config.dashboardMap;
        },
        beforeRender: function() {
            var dashletSwitch;
            var dashletPreferences = app.context.currentUserPreferences().get("dashletVisibilities");
            // create/update the respective dashlet order and save it back on the config

            // if no preferences, create an empty version that we can add to later
            if(!dashletPreferences) {
                dashletPreferences = new Backbone.Collection([]);
            }
            _.each(this.dashboardMap, function(dashletList){
                // for each tab, get it's configured dashlets
                _.each(dashletList, function(dashletAttrs){
                    var dashletSwitchObject;

                    // if we already have preferences for that, use those
                    _.each(dashletPreferences, function(dashletSwitchArray){
                        if(dashletSwitchArray.dashletId === dashletAttrs.dashletId) {
                            dashletSwitchObject = dashletSwitchArray;
                        }
                    }, this);

                    // if preferences exist, we will use those to set the switch to the correct value
                    if(dashletSwitchObject) {
                        dashletSwitch = new iOSSwitch.View({
                            configModelKey: "dashboardPreferencesEnabled",
                            switchTitle: dashletAttrs.dashletName,
                            onLabel: (window.localize("userpreferences.config.dashboard.showSwitch")),
                            offLabel: (window.localize("userpreferences.config.dashboard.hideSwitch")),
                            defaultSwitchValue: dashletSwitchObject.dashletVisibility,
                            configDescription: (window.localize("userPreferences.config.dashboard.switchDescription"))
                        });
                    } else {
                        // otherwise we create a switch and set it's value to true because we want to show it
                        dashletSwitch = new iOSSwitch.View({
                            configModelKey: "dashboardPreferencesEnabled",
                            switchTitle: dashletAttrs.dashletName,
                            onLabel: (window.localize("userpreferences.config.dashboard.showSwitch")),
                            offLabel: (window.localize("userpreferences.config.dashboard.hideSwitch")),
                            defaultSwitchValue: true,
                            configDescription: (window.localize("userPreferences.config.dashboard.switchDescription"))
                        });
    
                        var dashletId = dashletAttrs.dashletId;

                        // then we will push our new dashlet to user preferences with the correct visibility
                        dashletPreferences.push({
                            dashletId: dashletId,
                            dashletVisibility: dashletSwitch.model.get('dashboardPreferencesEnabled')
                        });
                        app.context.currentUserPreferences().set("dashletVisibilities", dashletPreferences);
                    }

                    this.setView("#dashletVisibilitySwitch-" + dashletAttrs.dashletId, dashletSwitch);
                }, this);
            }, this);
        },
        toggleDashletVisibility: function(e) {
            var fullId = e.currentTarget.id;

            // Cut off prefix to get actually id so we can update the preferences map
            var dashletId = fullId.substr(fullId.indexOf("-") + 1, fullId.length);

            var newValue = $(e.currentTarget).find(".switch.ios input[type='radio']:checked").val() === 'true';

            var dashletPreferences = app.context.currentUserPreferences().get("dashletVisibilities");

            // set the visibility to the new values for the dashletId
            _.each(dashletPreferences, function(dashletSwitchArray){
                if(dashletSwitchArray.dashletId === dashletId) {
                    dashletSwitchArray.dashletVisibility = newValue;
                }
            }, this);

            //reset the dashlet visibility preferences since we have updated a value
            app.context.currentUserPreferences().set("dashletVisibilities", dashletPreferences);
        },
		serialize: function(){
			return {
				dashboardMap: this.dashboardMap
			};
        }
	});
	return DashboardPreferencesView;
});