// Formtype module
define([
	"app",
	"handlebars",
	"modules/hpiadmin/formconfig/formattribute",
	"modules/hpiadmin/otc/repotype",
	"module"
],

	// Map dependencies from above array.
	function (app, Handlebars, Formattribute, Repotype, module) {

		// Create a new module.
		var Formtype = app.module();

		Formtype.Model = Backbone.Model.extend({
			defaults: {
				ocName: "",
				label: "",
				overrideType: "",
				externalFormRules: [],
				positionValuesAttrib: "",
				positionDataType: ""
			},
			initialize: function (options) {
				if (options && options.configuredAttrsPri) {
					this.set("configuredAttrsPri", new Formattribute.Collection(options.configuredAttrsPri));
				} else {
					this.set("configuredAttrsPri", new Formattribute.Collection());
				}

				if (options && options.configuredAttrsSec) {
					this.set("configuredAttrsSec", new Formattribute.Collection(options.configuredAttrsSec));
				} else {
					this.set("configuredAttrsSec", new Formattribute.Collection());
				}
			}
		});

		Formtype.Collection = Backbone.Collection.extend({
			model: Formtype.Model
		});

		// Default View.
		Formtype.Views.Model = Backbone.Layout.extend({
			template: "hpiadmin/formconfig/formtypemodel",
			events: {
				"click .hpi-section-header": "toggleEditMode",
				"click .btn.delete-type": "removeFormType",
				"click .add-all-attrs": "addAllTypes",
				"change input.overrideCheckbox": "updateOverride",
				"change select.attribute-overrideType": "updateAttribute",
				"drop": "drop"
			},
			initialize: function (options) {
				this.ui = {};
				this.picklists = options.picklists;
				this.override = this.model.get("overrideType") ? true : false;
				this.configuredTypesNames = this.options.configuredTypesNames;

				//this model will serve as our attribute listener. This will allow individual
				//Formtypes to keep track of their attributes
				this.attrHelper = new Backbone.Model({
					allAttrs: [],
					configuredAttrs: [],
					unconfiguredAttrs: []
				});

				Handlebars.registerHelper("configuredTypesNamesVisible", function (options) {
					if (!this.override) {
						return false;
					}
					return options.fn(this);
				});

				//This helper determines what value should be selected in the overrideType
				//dropdown for the type
				Handlebars.registerHelper("overrideSelect", function (options) {
					//options.hash.overrideType is the value of overrideType on the current model
					//options.hash.currentOption is the value of the current option from the
					//template
					//if this matches the model's overrideType, then we should return selected
					if (options.hash.overrideType === options.hash.currentOption) {
						return "selected";
					} else {
						return "";
					}
				});
			},
			afterRender: function () {
				// set up some dom elements
				this.ui.content = this.$(".hpi-section-content");

				self.$('[data-toggle="tooltip"]').tooltip();
			},
			serialize: function () {
				return {
					label: this.model.get("label"),
					overrideType: this.model.get("overrideType"),
					override: this.override,
					configuredTypesNames: this.configuredTypesNames,
					cid: this.cid
				};
			},
			updateOverride: function (event) {
				var that = this;
				this.override = event.target.checked;
				if (!event.target.checked) {
					this.model.set("overrideType", "");
				}

				this.render().promise().done(function () {
					that.toggleVisibility(true);
				});
			},
			updateAttribute: function (event) {
				var that = this;
				//get the attrName from the id, splitting out the cid attached
				var attrToSet = event.target.id.split("-")[0];
				this.model.set(attrToSet, event.target.value);
				if (!event.target.value) {
					this.override = false;
				}

				this.render().promise().done(function () {
					that.toggleVisibility(true);
				});
			},
			toggleEditMode: function () {
				// this is proxy function we can call -- we'll want to delegate to either toggle visibility (false) or editFormType()
				if (this.ui.content.hasClass("hidden")) {
					this.editFormType();
					// let editFormType call toggleVisiblity on its .done() deferred resolve
				}
				else {
					this.toggleVisibility(false);
				}
			},
			editFormType: function (event) {
				var that = this;

				app.context.configService.getAdminTypeConfig(this.model.get('ocName'), function (typeConfig) {

					//we need to keep track of which type is being edited
					var currentFormType = that.model;
					var allAttrs = [];
					_.each(typeConfig.get('attrs').models, function (attrModel) {
						allAttrs.push(attrModel.get('ocName'));
					});
					var configuredAttrs = _.union(currentFormType.get("configuredAttrsPri").pluck("ocName"),
						currentFormType.get("configuredAttrsSec").pluck("ocName"));
					var unconfiguredAttrs = _.difference(allAttrs, configuredAttrs);

					that.attrHelper.set("allAttrs", allAttrs);
					that.attrHelper.set("configuredAttrs", configuredAttrs);
					that.attrHelper.set("unconfiguredAttrs", unconfiguredAttrs);

					that.attrHelper.set(('isComposite'), typeConfig.get("isContainer"));
					if (typeConfig.get("isContainer") === "Composite") {
						currentFormType.set('composite', true);
					}

					//set the attr view view the currentFormType passed from the model view
					that.setViews({
						".add-attributes-outlet": new Formtype.Views.Attrcontrol({
							allAttrs: allAttrs,
							attrHelper: that.attrHelper,
							repoType: typeConfig,
							configuredAttrs: currentFormType.get("configuredAttrsPri")
						}),
						".primary-attributes": new Formattribute.Views.Collection({
							repoType: typeConfig,
							picklists: that.picklists,
							collection: currentFormType.get("configuredAttrsPri"),
							allAttrs: allAttrs,
							attrHelper: that.attrHelper,
							primary: true,
							typeCid: that.cid
						}),
						".secondary-attributes": new Formattribute.Views.Collection({
							repoType: typeConfig,
							picklists: that.picklists,
							collection: currentFormType.get("configuredAttrsSec"),
							allAttrs: allAttrs,
							attrHelper: that.attrHelper,
							primary: false,
							typeCid: that.cid
						}),
						".external-form-condition-outlet": new Formtype.Views.ExternalFormRules({
							model: that.model
						})
					}).render().promise().done(function () {
						that.toggleVisibility(true);
					});

				});
			},
			// true for show, false for hide
			toggleVisibility: function (show) {
				if (show) {
					this.ui.content.removeClass("hidden");
				}
				else {
					this.ui.content.addClass("hidden");
				}
			},
			removeFormType: function (event) {
				app.trigger("Formtype:remove", this.model);
			},
			drop: function (event, index) {
				//everytime we move the formtype, need to sort the types correctly
				app.trigger("Formtype:sort", this.model, index);
			},
			addAllTypes: function () {
				this.attrHelper.trigger("Formattribute:addAllAttrs");
			}
		});

		Formtype.Views.Collection = Backbone.Layout.extend({
			template: "hpiadmin/formconfig/formtypecollection",
			initialize: function () {
				var that = this;

				this.listenTo(app, "Formtype:remove", function (model) {
					//remove the attribute view if the removed type was the current type
					app.trigger("alert:confirmation", {
						confirm: function () {
							if (that.currentFormType && that.currentFormType === model) {
								that.removeView("#attrcontrol");
								that.removeView("#formattributesprimary");
								that.removeView("#formattributessecondary");
							}
							//remove the model passed in

							that.collection.remove(model);
							that.render();

						},
						header: window.localize("modules.hpiAdmin.formConfig.formType.confirmDelete"),
						message: window.localize("modules.hpiAdmin.formConfig.formType.areYouSure")
					});
				});

				this.listenTo(app, "Formtype:sort", function (model, position) {
					this.collection.remove(model);
					this.collection.add(model, { at: position });
				});
			},
			beforeRender: function () {
				var that = this;
				var configuredTypesNames = _.map(this.collection.models, function (tempModel) {
					return tempModel.get("ocName");
				});
				//need a blank value at the beginning
				configuredTypesNames.unshift("");

				if (this.collection && this.collection.length > 0) {
					this.collection.each(function (formType) {
						that.insertView("#formtypecollection-" + that.cid, new Formtype.Views.Model({
							model: formType,
							picklists: that.options.picklists,
							configuredTypesNames: configuredTypesNames
						}));
					});
				}
			},
			serialize: function () {
				return {
					cid: this.cid
				};
			},
			cleanup: function () {
				$(window).unbind("scroll");
			},
			afterRender: function () {
				var id = "#formtypecollection-" + this.cid;
				this.$(id).sortable({
					handle: ".hpi-section-header",
					update: function (event, ui) {
						ui.item.trigger("drop", ui.item.index());
					}
				});

				this.handleScrolling = function () {
					if ($(".table-condensed").offset() && $(window).scrollTop() > $(".table-condensed").offset().top) {
						$(".table-header").addClass("sticky").css("position", "fixed");
					} else {
						$(".table-header").removeClass("sticky").css("position", "relative");
					}
				};

				$(window).bind("scroll", this.handleScrolling);
			}
		});

		Formtype.Views.Attrcontrol = Backbone.Layout.extend({
			template: "hpiadmin/formconfig/formtypeattrcontrol",
			events: {
				"keyup #filter-attrs-input": "filterAttrs",
				"click #filter-attrs-input": "clickFilterInput",
				"click button.close": "closeMenu",
				"click .unconfiguredattrs-outlet": "keepViewOpen"
			},
			initialize: function () {
				this.hiddenFilter = false;
				this.repoType = this.options.repoType;
				this.attrHelper = this.options.attrHelper;
			},
			serialize: function () {
				return {
					cid: this.cid
				};
			},
			beforeRender: function () {
				this.setViews({
					".unconfiguredattrs-outlet": new Formattribute.Views.Unconfiguredattrs({
						typeName: this.repoType.get("ocName"),
						attrHelper: this.attrHelper
					})
				});
			},
			afterRender: function () {
				//since we just rendered, need to check if the attrs should be hidden or not
				if (this.hiddenFilter) {
					this.$("#filter-attrs-div").hide();
				}
			},
			clickFilterInput: function (e) {
				// just stop clicking on the content from hiding the dropdown menu (events wont bubble)
				e.stopPropagation();
			},
			closeMenu: function (e) {
				$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
			},
			filterAttrs: function (event) {
				this.attrHelper.trigger("Formattribute:filterAttrs", this.cid);
			},
			keepViewOpen: function (e) {

				this.attrHelper.trigger("Formattribute:filterAttrs", this.cid);
				e.stopPropagation();
			}
		});

		Formtype.Views.ExternalFormRules = Backbone.Layout.extend({
			template: "hpiadmin/formconfig/formattribute-external-form-rules",
			events: {
				"click .remove-external-form-rule": "removeExternalRule",
				"change .select-external-form-rule": "updateAttributeVal",
				"blur #failureMessageInput": "updateFailureMessage",
				"click button.close": "closeMenu",
				"click #filter-attrs-input": "clickFilterInput",
				"click .external-form-container": "keepViewOpen"
			},
			initialize: function () {
				var self = this;

				self.formFailureMessage = self.model.get("formFailureMessage");

				self.configuredExternalFormRules = _.clone(module.config().availableConditions);
				_.each(self.model.get("externalFormRules"), function (rule) {
					self.configuredExternalFormRules = _.reject(self.configuredExternalFormRules, function (optionRule) {
						return optionRule.ruleValue === rule.ruleValue;
					});
				});
				//add blank string to beginning, for visibility, if any rules are left on our array
				if (!_.isEmpty(self.configuredExternalFormRules)) {
					self.configuredExternalFormRules.unshift({ ruleLabel: "", ruleValue: "" });
				}
			},
			closeMenu: function (e) {
				$('.external-form-group').toggleClass('open');
			},

			updateAttributeVal: function (event) {
				//get the attrName from the id, splitting out the cid attached
				var attrToSet = event.target.id.split("-")[0];
				if (attrToSet !== "externalFormRules") {
					app.logger.warn("Warning: Activated external rule listener outside of external rules");
				}
				if (event.target.value === "") {
					return;//do nothing if it's selected the blank
				}
				var conditions = this.model.get(attrToSet);
				if (!conditions) {
					conditions = [];
				}
				var ruleToAdd;
				this.configuredExternalFormRules = _.reject(this.configuredExternalFormRules, function (rule) {
					if (rule.ruleValue === event.target.value) {
						ruleToAdd = rule;
						return true;
					}
				});
				conditions.push(ruleToAdd);
				this.model.set(attrToSet, conditions);

				this.render();

				// make sure we dont bubble up to the parent view or it will re-render this whole thing.
				event.stopPropagation();
			},

			updateFailureMessage: function (event) {
				var self = this;
				self.formFailureMessage = event.target.value;
				self.model.set("formFailureMessage", self.formFailureMessage);
			},

			removeExternalRule: function (event) {
				event.stopPropagation();
				var self = this;
				var val = event.currentTarget.attributes.value.value;
				var removedRule;
				var filteredRules = _.reject(this.model.get("externalFormRules"), function (rule) {
					if (rule.ruleValue === val) {
						removedRule = rule;
						return true;
					}
				});
				this.model.set("externalFormRules", filteredRules);
				this.configuredExternalFormRules.push(removedRule);
				if (this.configuredExternalFormRules.length === 1) {
					self.configuredExternalFormRules.unshift({ ruleLabel: "", ruleValue: "" });
				}
				this.render();
			},
			keepViewOpen: function (e) {
				e.stopPropagation();
			},
			serialize: function () {
				return {
					cid: this.model.cid,
					externalFormRules: this.model.get("externalFormRules"),
					allExternalFormRules: this.configuredExternalFormRules,
					failureMessage: this.formFailureMessage
				};
			}
		});

		// Return the module for AMD compliance.
		return Formtype;

	});