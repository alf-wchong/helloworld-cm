// Objecttypeconfig module
define([
	"app",

    "modules/hpiadmin/hpiadmin-switcher",

	"modules/hpiadmin/hpiadmin",
	"modules/hpiadmin/formconfig/formtype",
	"modules/hpiadmin/picklistconfig/picklistconfig"
],

function(app, Switcher, Hpiadmin, Formtype, PicklistConfig) {
	"use strict";

	var Formconfig = app.module();

	// Default Model.
	Formconfig.Model = Hpiadmin.Config.extend({
		type: "FormConfig",
		defaults : {
			type : "FormConfig"
		},
		initialize: function(options) {
			//Backbone doesn't support nesting Collections in Models OOTB, this initialize
			//lets us setup our internal collection
			if (options && options.configuredTypes) {
				this.set("configuredTypes", new Formtype.Collection(options.configuredTypes));	
			} else {
				this.set("configuredTypes", new Formtype.Collection());
			}
		},
		parseResponse: function(response) {
			//if this is the first time this config is loaded (id will be undefined),
			//then we need to build up the configured types without overwriting the
			//one that has already been init'ed. if the id is already present, then
			//the parse was hit after a save, and we are confident that the model we
			//already have is what is returned from the server, so remove config model
			//info from the response
			if (this.id) {
				response = _.pick(response, 'id');
			} else if (response && response.configuredTypes) {
				//we need this check for the case when we create a Formtype.Collection
				//to get the formConfig names
				this.set("configuredTypes", new Formtype.Collection(response.configuredTypes));
				delete response.configuredTypes;
			}

			return response;
		}
	});

	//Collection of formconfig models
	//This collection is used by the context to pull down all saved formconfigs
	Formconfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
		model: Formconfig.Model,
		initialize: function(model, options) {
			this.type = "FormConfig";			
		}
	});

	Formconfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formconfig",
		className: "formConfig",
		events: {
			"click #saveform-btn": "saveForm",
			"click #unconfigured-types-list a": "addFormType"
        },
		initialize: function() {
			var that = this;
			if(this.model.get("name")){
				//we are in 'edit' mode
				this.listenTo(this.model, "sync", function(){
					that.render();
				});
				this.listenTo(this.model.get("configuredTypes"), "add", function(){
					that.render();
				});
				this.listenTo(this.model.get("configuredTypes"), "remove", function(){
					that.render();
				});
			}

			//grab all the types we can use, we will update this list if any are configured
			//in the before render
			var deferreds = [];
			deferreds.push(app.context.configService.getAdminOTC(function(adminOTC){
				that.allTypes = adminOTC.get("configs");

				//take the types that are configured out of the list of non-configured types
				that.tempTypes = _.difference(that.allTypes.pluck('ocName'),
				  		that.model.get("configuredTypes").pluck('ocName'));
				that.types = [];
				_.each(that.tempTypes, function(type) {
					var fullObj = _.find(that.allTypes.models, function(model) {
				 		return model.get('ocName') === type;
				 	});
				 	var tempObj = {'label': fullObj.attributes.label,
				 					'ocName':fullObj.attributes.ocName};
				 	that.types.push(tempObj);
				 });
				 that.types = that.types;
			}));

			//need all the picklists possible before setting the formtypecollection view
			deferreds.push(app.context.findOrCreateConfig(PicklistConfig.Model, "default").fetch({
				success: function(picklistConfig){
					that.picklists = picklistConfig.get("picklists").pluck("label");
					//add a blank value to the beginning of the array
					that.picklists.splice(0, 0, "");

					that.setViews({
						"#formtypecollection-outlet": new Formtype.Views.Collection({
							collection: that.model.get("configuredTypes"),
							picklists: that.picklists
						})
					});
				},
				error: function(){
					app.trigger("alert:error", {
						header: window.localize("generic.alert"),
						message: window.localize("modules.hpiAdmin.formConfig.formConfig.weAreUnable")
					});
				}
			}));

			$.when.apply(this, deferreds).done(function(){
				// Moved this logic from beforeRender so the variable that.allTypes is populated before we hit this code.
				var switcher = new Switcher.Views.Layout({config: that.model, configClass: that.options.configClass });
				that.setView("#config-switcher-outlet", switcher);
				that.render();
			});
		},
		serialize: function() {
			var createMode = false;
			if(!this.model.get("name")){
				createMode = true;
			}

			return {
				createMode: createMode,
				form: this.model && this.model.attributes,
				types: this.types || this.allTypes
			};
		},
		saveForm: function() {
			this.model.set("displayName", this.$('#displayname-input').val());

			this.saveModel();
		},
		addFormType: function(event){
			var that = this;

			app.context.configService.getAdminTypeConfig(event.target.id.split("-")[0], function(type) {
				if(type.get('isContainer') === 'Composite') {
				that.model.get("configuredTypes").add(new Formtype.Model({
					ocName: type.get("ocName"),
						label: type.get("label"),
						composite: 'Composite'
					}));
				} else {
					that.model.get("configuredTypes").add(new Formtype.Model({
						ocName: type.get("ocName"),
					label: type.get("label")
				}));
				}


				that.render();
			});
		},
        saveModel: function() {
			var that = this;
			_.each(that.model.get("configuredTypes").models, function(type, index) {
				type.set("ordinal", index);
			});
			this.model.save({}, {
				success: function() {
					app.trigger("modelSaveOrDestroy");
					Backbone.history.navigate("admin/FormConfig/" + that.model.get("name"), {replace: true, trigger: true});
					app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
				},
				error: function() {
					app.trigger("alert:error", {
						header : window.localize("generic.errorSavingConfig"),
						message : window.localize("generic.configSaveFailed")
					});
				}
			});
		}
	});
	
	return Formconfig;

});
