// Formattribute module
define([
	"app",
	"handlebars", 
	"module"

],

// Map dependencies from above array.
function(app, handlebars, module) {

	// Create a new module.
	var Formattribute = app.module();

	Formattribute.Model = Backbone.Model.extend({
		defaults: {
			ocName: "",
			repoName: "",
			controlType: "",
			editable: false,
			formEditable: false,
			required: false,
			repeating: false,
			picklist: "",
			dataType: "",
			dependsOn: [],
			growable: false,
			autoSelect: false,
			allowDropdown: false,
			timestamped: false,
			onlyNewEntries: false,
			canTypeInBox: false,
			enforceDateBeforeToday: false,
			enforceDateAfterToday: false,
			minChars: "",
			maxChars: "",
			isWysiwyg: false,
			regex: "",
			regexRule: "",
			minCharBeforeQuery: app.minCharBeforeQuery,
			computedPattern: "",
			selectAllEnabled: false,
			delimitedListSelectEnabled: false,
			listDelimiter: ",",
			readOnlyGroupedAttrs: [],
			helptext: "",
			defaultValue: "",
			defaultValueCurrentDate: false,
			makeSearchExact: false,
			upperCase:false,
			caseSensitive:false,
			parentAspect:"",
			externalValueURL:""
		}
	});
	
	Formattribute.Collection = Backbone.Collection.extend({
		model: Formattribute.Model
	});

	// Model View.
	Formattribute.Views.Model = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributemodel",
		tagName: "tr",
		events: {
			"click span.icon-delete": "removeAttribute",
			"change select.form-control.controlType": "updateAttribute",
			"change input.checkbox": "updateCheckbox",
			"updateOtherCollection": "updateOtherCollection",
			"updateSameCollection": "updateSameCollection",
			"click .control-options": "clickControlOptions"
		},
		initialize: function() {
			var that = this;
			this.label = this.model.get("ocName");
			this.attrHelper = this.options.attrHelper;
			app.context.configService.getLabels(this.options.objectType, 
					this.model.get("ocName")).done(function(labels) {
				that.label = labels;

				that.setViews({
					".control-options-subview-outlet": new Formattribute.Views.ControlOptions({
						model: that.model,
						picklists: that.options.picklists,
						attrHelper: that.attrHelper,
						objectType: that.objectType
					}),
					".control-picklistwarning-subview-outlet": new Formattribute.Views.Picklistwarning({
						model: that.model
					}),
					".control-picklistcascadewarning-subview-outlet": new Formattribute.Views.PicklistCascadeWarning({
						model: that.model
					}),
					".control-rules-subview-outlet" : new Formattribute.Views.ControlRules({
						model: that.model,
						allAttrs: that.attrHelper.get("allAttrs").sort()
					}),
					".control-external-rules-subview-outlet" : new Formattribute.Views.ControlExternalRules({
						model: that.model
					}),
					".control-visibilityDependentWarning-subview-outlet" : new Formattribute.Views.VisibilityDependentWarning({
						model: that.model
					}),
					".control-enableDependentWarning-subview-outlet" : new Formattribute.Views.EnableDependentWarning({
						model: that.model
					}),
					".control-lockWarning-subview-outlet" : new Formattribute.Views.LockWarning({
						model: that.model
					})
				}).render();
			});

			handlebars.registerHelper("optionsvisible", function(options) { 
				// any controls that DON'T have additional options should be specified here;
				var optionControls = ["Hidden", "ProximityDateSearch"];
				if(_.contains(optionControls, this.controlType)) {
					return "";	
				}
				return options.fn(this);
			});

			//This helper determines what control should be selected in the controlType
			//dropdown for each attribute
			handlebars.registerHelper("control", function(options) {
				//options.hash.currentOption is the value of the current option from the
				//template
				//if this matches the model's controlType, then we should return selected
				if (this.controlType === options.hash.currentOption) {
					return "selected";
				} else {
					return "";
				}
			});
		},
		serialize: function(){
			return {
				ocName: this.model.get("ocName"),
				repoName: this.model.get("repoName"),
				controlType: this.model.get("controlType"),
				formEditable: this.model.get("formEditable"),
				editable: this.model.get("editable"),
				required: this.model.get("required"),
				repeating: this.model.get("repeating"),
				dataType: this.model.get("dataType"),
				appendOnly: this.model.get("appendOnly"),
				label: this.label,
				cid: this.model.cid,
				selectAllEnabled: this.model.get("selectAllEnabled"),
				delimitedListSelectEnabled: this.model.get("delimitedListSelectEnabled")
			};
		},
		removeAttribute: function() {
			//update our attrHelper
			this.attrHelper.set("unconfiguredAttrs",
						_.union(this.attrHelper.get("unconfiguredAttrs"), this.model.get("ocName")));
			this.attrHelper.set("configuredAttrs", 
					_.without(this.attrHelper.get("configuredAttrs"), this.model.get("ocName")));
			
			//tell the collection of Formattrs that one was removed
			this.attrHelper.trigger("configuredAttrsRemoval", this.model);
		},
		updateAttribute: function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];

			this.model.set(attrToSet, event.target.value);
			
			if(event.target.value === "Computed"){
				this.model.set('editable', false);
			}

			this.render();
		},
		updateCheckbox: function(event) {
			var notOnModel = ["cascading"];
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];

			if (!_.contains(notOnModel, attrToSet)) {
				this.model.set(attrToSet, event.target.checked);
			}

			// appendOnly can only be set to true when repeating and editable are true
			if(attrToSet === "repeating" || attrToSet === "editable") {
				if(!this.model.get('repeating') || !this.model.get('editable')) {
					this.model.set('appendOnly', false); 
				}
			}

			this.render();
		},
		updateOtherCollection: function(event, index) {
			//everytime we move the formattribute, need to sort the attributes correctly
			//the boolean tells the sort that the attribute is from the other
			//configuredAttr collection
			this.attrHelper.trigger("Formattribute:sort", this.model, index, false);
		},
		updateSameCollection: function(event, index) {
			//everytime we move the formattribute, need to sort the attributes correctly
			//the boolean tells the sort that the attribute is from the same
			//configuredAttr collection
			this.attrHelper.trigger("Formattribute:sort", this.model, index, true);
		},
		clickControlOptions: function(event) { 
			if (event.stopPropagation) { // W3C/addEventListener()
		        event.stopPropagation();
		    }
		    else { // Older IE.
		        event.cancelBubble = true;
			}
		}
	});

	Formattribute.Views.Collection = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributecollection",
		initialize: function() {
			this.repoType = this.options.repoType;
			this.picklists = this.options.picklists;
			this.primary = this.options.primary;
			this.hiddenAttrs = false;
			this.parentCid = this.options.typeCid;
			this.attrHelper = this.options.attrHelper;

			// We debounce here, because addAll would spam render()'s for each attribute added.
			this.listenTo(this.collection, "add", _.debounce(function(){
				this.render();
			}), 100);
			this.listenTo(this.collection, "remove", function(){
				this.render();
			});

			this.listenTo(this.attrHelper, "configuredAttrsRemoval", function(model) {
				this.collection.remove(model);
			});

			// Depending on the event fired, we'll add to either the primary or secondary collection.
			if (this.primary) {
				this.listenTo(this.attrHelper, "configuredAttrsAddition", this.addConfiguredAttr);
			} else {
				this.listenTo(this.attrHelper, "configuredAttrsSecondaryAddition", this.addConfiguredAttr);
			}

			this.listenTo(this.attrHelper, "Formattribute:sort", function(model, position, sameCollection) {
				//both model views will fire the sort event, need to make sure we only
				//manipulate the collection where the model is located
				if (this.collection.get(model)) {
					this.collection.remove(model);
					if (sameCollection) {
						this.collection.add(model, {at: position});
					}
				} else if (!sameCollection) {
					this.collection.add(model, {at: position});
				}
			});
		},
		addConfiguredAttr: function(ocName) {
            var self = this;
            var propertiesAndAspectProperties = this.repoType.get("attrs");
            if(this.repoType.get('isContainer') === 'Composite'){
                //if this is a composite type, were not going to mess with the repoType, it doesnt exist.

			//add the attribute to the configured attributes by using the type's
			//fetched attributes from the dictionary service
                var selectedAttr = _.find(propertiesAndAspectProperties.models, function(model) {
                    return model.get('ocName') === ocName;
                });

                if (selectedAttr) {
                    var control;
                    if (selectedAttr.dataType === "date") {
                        control = "DateBox";
                    } else {
                        control = "TextBox";
                    }
                    self.collection.add(new Formattribute.Model({
                        ocName : selectedAttr.get('ocName'),
                        repoName: selectedAttr.get('repoName'),
                        controlType : control,
                        editable: true,
                        formEditable: true,
                        required: false,
                        repeating : false,
						dataType : selectedAttr.get('dataType'),
						parentAspect : selectedAttr.get('parentAspect')
                    }));
                }
            }else{
                app.context.configService.getTypeAttrs(this.repoType.get("ocName"), function(attributes) {

                    //add the attribute to the configured attributes by using the type's
                    //fetched attributes from the dictionary service
                    var selectedAttr = _.find(propertiesAndAspectProperties.models, function(model) {
                        return model.get('ocName') === ocName;
                    });
                    //we need to get the repo attr so that we can set the repoEditable flag correctly
                    var selectedRepoAttr = _.find(attributes, function(model) {
				return model.ocName === ocName;
			});

			if (selectedAttr) {
				var control;
				if (selectedAttr.dataType === "date") {
					control = "DateBox";
				} else {
					control = "TextBox";
				}
                        self.collection.add(new Formattribute.Model({
                            ocName : selectedAttr.get('ocName'),
                            repoName: selectedAttr.get('repoName'),
							controlType : control,
                            editable: selectedRepoAttr ? selectedRepoAttr.repoEditable : true,
                            formEditable: selectedRepoAttr ? selectedRepoAttr.repoEditable : true,
                            required: selectedRepoAttr ? selectedRepoAttr.required : false,
                            repeating : selectedRepoAttr ? selectedRepoAttr.repeating : false,
							dataType : selectedAttr.get('dataType'),
							parentAspect : selectedAttr.get('parentAspect')
				}));
			}
                });
            }

		},

		beforeRender: function() {
			var that = this;

			if (this.collection) {
				this.collection.each(function(formAttribute) {
					that.insertView("#formattributecollection-"+that.cid, new Formattribute.Views.Model({
						model: formAttribute,
						picklists: that.picklists,
						attrHelper: that.attrHelper,
						objectType: that.repoType.get("ocName")
					}));
				});
			}
		},
		serialize: function() {
			return {
				cid: this.cid,
				typeName: this.repoType.get("ocName"),
				empty: this.collection.length > 0 ? false : true,
				primary: this.primary
			};
		},
		afterRender : function() {
			var self = this;
			self.startCount = 0;
			//this makes sure that both tbody's that have this class are rendered before
			//we attach the sortable class
			//we don't use this.$() selector since a separate views add the tbody's
			// also: make sure we're only applying the sortable to the decendants of THIS TYPE (or it breaks) (this.parentCid is passed from the parent formtype.model)
			this.sortableElements = $(".formtype-" + this.parentCid + " .sortable-attributes");
			if (this.sortableElements.length === 2) {
				this.sortableElements.sortable({
					connectWith: ".formtype-" + this.parentCid + " .sortable-attributes",
					revert: true,
					receive: function(event, ui){
						ui.item.trigger("updateOtherCollection", ui.item.index());
					},
					stop: function(event, ui) {
						if(this === ui.item.parent()[0]){
							ui.item.trigger("updateSameCollection", ui.item.index());
						}
						self.sortableElements.find(".dropzone").remove();
						self.startCount = 0;						
					},
					start: function() { 
						// this is NOT scoped to self -- because we want to find the elements outside this view in the DOM (dont want to trigger events in order to bubble up)
						if(self.startCount === 0){
							self.sortableElements.append("<tr class='dropzone' style='border:2px dashed #f2dede; border-radius:6px'><td colspan='9' style='text-align:center'>Drop Here</td></tr>");
							self.startCount++;
						}
					}
				});
			}

			// init any tooltips
			this.$("span").tooltip();
		}
	});

	Formattribute.Views.ControlRules = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattribute-control-rules",
		events: {
			"change .control-rules .control-options select.select": "updateAttribute",
			"keyup .control-rules input.visibilityDependentAttr-input": "updateAttributeVal",
			"keyup .control-rules input.enableDependentAttr-input": "updateAttributeVal",
			"keyup .control-rules input.lock-input": "updateAttributeVal",
			"change .control-rules input.checkbox-inline": "updateCheckbox",
			"blur .prependedValuesInput": "updatePrependedValues"
		},
		initialize: function(options){
			this.options = options;
			this.model = options.model;

			handlebars.registerHelper("checkAttrIsSelected", function(attr, selected) {
				return attr == selected ? 'selected': '';
			});
		},
		updateCheckbox: function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			this.model.set(attrToSet, event.target.checked);

			if (attrToSet === 'visibilityDependent'){
				app.trigger("renderVisibilityDependentWarning");
				// if visibilityDependent is being unchecked, if so need to reset visibilityDependentAttr
				if (!event.target.checked){
					this.model.set('visibilityDependentAttr', '');
					this.model.set('visibilityDependentAttrVal', '');
				}
			}

			if (attrToSet === 'enableDependent'){
				app.trigger("renderEnableDependentWarning");
				// if enableDependent is being unchecked, if so need to reset enableDependentAttr
				if (!event.target.checked){
					this.model.set('enableDependentAttr', '');
					this.model.set('enableDependentAttrVal', '');
				}
			}

			if(attrToSet === "lock"){
				app.trigger("renderlockWarning");
				// if lock is being unchecked, if so need to reset allowedUnlockGroups
				if (!event.target.checked){
					this.model.set('allowedUnlockGroups', '');
					this.model.set("lockAuth", '');
				}
			}

			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
		updateAttribute: function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			this.model.set(attrToSet, event.target.value);

			if (attrToSet === 'visibilityDependentAttr'){
				app.trigger('renderVisibilityDependentWarning');
			} else if (attrToSet === 'enableDependentAttr'){
				app.trigger('renderEnableDependentWarning');
			}

			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},

		updatePrependedValues : function() {
			var values = $("#prependedValues-" + this.model.cid).val();
			this.model.set("valuesToPrependWhenSorting", values);
		},

		updateAttributeVal: _.debounce(function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			this.model.set(attrToSet, event.target.value);

			if (attrToSet === 'visibilityDependentAttrVal'){
				app.trigger('renderVisibilityDependentWarning');
			} else if (attrToSet === 'enableDependentAttrVal'){
				app.trigger('renderEnableDependentWarning');
			} else if (attrToSet === "allowedUnlockGroups"){
				app.trigger("renderlockWarning");
			}

			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		}, 1000),

		afterRender: function() {

			// updating the prepended values input
			$("#prependedValues-" + this.model.cid).val(this.model.get("valuesToPrependWhenSorting"));
		},

		serialize: function() {
			// add a blank value at the beginning if one isn't present
			if(this.options.allAttrs[0]){
				this.options.allAttrs.unshift("");
			}
			return {
				cid: this.model.cid,
				hidden: this.model.get('hidden'),
				rememberLastSearchTerm: this.model.get('rememberLastSearchTerm'),
				visibilityDependent: this.model.get('visibilityDependent'),
				enableDependent: this.model.get('enableDependent'),
				lock: this.model.get('lock'),
				allAttrs: this.options.allAttrs,
				visibilityDependentAttr: this.model.get('visibilityDependentAttr'),
				enableDependentAttr: this.model.get('enableDependentAttr'),
				parentAspect: this.model.get('parentAspect'),
				visibilityDependentAttrVal: this.model.get("visibilityDependentAttrVal"),
				enableDependentAttrVal: this.model.get("enableDependentAttrVal"),
				allowedUnlockGroups: this.model.get("allowedUnlockGroups"),
				lockAuth: this.model.get("lockAuth"),
				hideWhenNoAspect : this.model.get('hideWhenNoAspect'),
				andRepeatingTerms: this.model.get('andRepeatingTerms'),
				repeating: this.model.get("repeating"),
				sortRepeatingAttrs: this.model.get("sortRepeatingAttrs"),
				valuesToPrependWhenSorting: this.model.get("valuesToPrependWhenSorting"),
			};
		}
	});

	Formattribute.Views.ControlExternalRules = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattribute-external-control-rules",
		events: {
			"click .remove-external-rule" : "removeExternalRule",
            "click #clearInvalidValueEnabledInput" : "updateClearInvalidValueEnabled",
			"change .select-external-rule" : "updateAttributeVal",
			"blur #failureMessageInput" : "updateFailureMessage"
		},
		initialize: function(){
			var self = this;
			self.visible = module.config().availableConditions && module.config().availableConditions.length > 0;

			self.failureMessage = self.model.get("failureMessage");
            self.clearInvalidValueEnabled = self.model.get("clearInvalidValueEnabled");

			self.configuredExternalRules = _.clone(module.config().availableConditions);
			_.each(self.model.get("externalRules"), function(rule) {
				self.configuredExternalRules = _.reject(self.configuredExternalRules, function(optionRule) {
					return optionRule.ruleValue === rule.ruleValue;
				});
			});
			//add blank string to beginning, for visibility, if any rules are left on our array
			if(!_.isEmpty(self.configuredExternalRules)) {
				self.configuredExternalRules.unshift({ruleLabel: "", ruleValue: ""});
			}
		},
		updateAttributeVal: function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			if(attrToSet !== "externalRules") {
				app.logger.warn(window.localize("modules.hpiAdmin.formConfig.formAttribute.warning"));
			}
			if(event.target.value === "") {
				return;//do nothing if it's selected the blank
			}
			var conditions = this.model.get(attrToSet);
			if(!conditions) {
				conditions = [];
			}
			var ruleToAdd;
			this.configuredExternalRules = _.reject(this.configuredExternalRules, function(rule) {
				if(rule.ruleValue === event.target.value) {
					ruleToAdd = rule;
					return true;
				}
			});
			conditions.push(ruleToAdd);
			this.model.set(attrToSet, conditions);

			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
        updateClearInvalidValueEnabled: function(event) {
            var self = this;
            self.clearInvalidValueEnabled = event.target.checked;
            self.model.set("clearInvalidValueEnabled", self.clearInvalidValueEnabled);
        },
		updateFailureMessage: function(event) {
			var self = this;
			self.failureMessage = event.target.value;
			self.model.set("failureMessage", self.failureMessage);
		},
		removeExternalRule: function(event) {
			event.stopPropagation();
			var self = this;
			var val = event.currentTarget.attributes.value.value;
			var removedRule;
			var filteredRules = _.reject(this.model.get("externalRules"), function(rule) {
				if(rule.ruleValue === val) {
					removedRule = rule;
					return true;
				}
			});
			this.model.set("externalRules", filteredRules);
			this.configuredExternalRules.push(removedRule);
			if(this.configuredExternalRules.length === 1) {
				self.configuredExternalRules.unshift({ruleLabel: "", ruleValue: ""});
			}
			this.render();
		},
		serialize: function() {
			return {
				cid: this.model.cid,
				externalRules: this.model.get("externalRules"),
				allExternalRules: this.configuredExternalRules,
				visible: this.visible,
				failureMessage: this.failureMessage,
                clearInvalidValueEnabled: this.clearInvalidValueEnabled
			};
		}
	});

	Formattribute.Views.ControlOptions = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattribute-control-options",
		events: {
			"click .control-options #computedAttr-button": "updateComputedPattern",
			"change .control-options select.select": "updateAttribute",
			"change .control-options input.input": "updateAttribute",
			"keyup .control-options input.regexRuleInput": "updateAttributeDebounced",
			"keyup .control-options input.defaultValueInput": "updateDefaultValueDebounced",
			"change .control-options input.checkbox": "updateCheckbox",
			"change .control-options textarea.input": "updateAttribute",
			"click .glyphicon-remove": "updateAttributeRemove",
			"click .control-options button.btn": "updateAttributeRemove",
			"keyup .control-options input.minCharBeforeQuery": "updateAttributeDebounced",
			"keyup .control-options input.listDelimiter": "updateAttributeDebounced"
		},
		initialize: function() { 
			var self = this;
			//This helper determines if the timestamped and onlyNewEntries
			//checkboxes should be displayed
			handlebars.registerHelper("timevisible", function() {
				var timestampedControls = ["TextAreaList"];
				//if the current controlType is one that doesn't need a timestamp and
				//onlyNewEntries checkboxes, return style that doesn't display 
				//the two checkboxes
				if (!_.contains(timestampedControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			//This helper determines if the textbox select should be displayed
			handlebars.registerHelper("textboxvisible", function() {
				var textbox = ["TextBox"];
				if (!_.contains(textbox, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			//This helper determines if the textarea select should be displayed
			handlebars.registerHelper("textareavisible", function() {
				var textarea = ["TextArea"];
				if (!_.contains(textarea, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			//This helper determines if the picklist select should be displayed
			handlebars.registerHelper("pickvisible", function() {
				var picklistControls = ["DropDown", "AutoComplete",  "CheckBox", "RadioButton"];
				//if the current controlType is one that doesn't need a picklist,
				//return style that doesn't display the picklist select
				if (!_.contains(picklistControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					//if the picklist control is being displayed, trigger a render
					//on the warning display if the picklist is not set
					app.trigger("renderPicklistWarning");
					return "";
				}
			});

			// This helper determines if the appendOnly checkbox should be displayed
			handlebars.registerHelper("appendOnlyVisible", function () {
				var blacklistPicklistControls = ["CheckBox", "RadioButton, TextArea"];
				// if the current controlType doesn't get appendOnly or repeating and editable are not both true
				// return style that doesn't display it
				if ((_.contains(blacklistPicklistControls, this.controlType)) || !(this.repeating === true && this.editable === true)) {
					return "style='display:none;'";
				}

				return "";
			});

			//This helper determines what value should be selected in the depndOn
			//dropdown for each attribute
			handlebars.registerHelper("depends", function(options) {
				//options.hash.dependsOn is the value of dependsOn on the current model
				//options.hash.currentOption is the value of the current option from the
				//template
				//if this matches the model's dependsOn, then we should return selected
				if (options.hash.dependsOn === options.hash.currentOption) {
					return "selected";
				} else {
					return "";
				}
			});

			//This helper determines if the growable checkbox should be displayed
			handlebars.registerHelper("growvisible", function() {
				var growableControls = ["AutoComplete"];
				//if the current controlType is one that doesn't need a growable attr,
				//return style that doesn't display the growable checkbox
				if (!_.contains(growableControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			//This helper determines if the growable checkbox should be displayed
			handlebars.registerHelper("computedvisible", function() {
				var computedControls = ["Computed"];
				//if the current controlType is one that doesn't need a growable attr,
				//return style that doesn't display the growable checkbox
				if (!_.contains(computedControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			handlebars.registerHelper("datecontrolvisible", function() {
				var dateControls = ["DateBox", "DatetimeBox"];
				//if the current controlType is one that doesn't need a growable attr,
				//return style that doesn't display the growable checkbox
				if (!_.contains(dateControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});

			handlebars.registerHelper("readonlyvisible", function() {
				var readOnlyControls = ["ReadOnly"];
				// If the current controlType is ReadOnly, display it's configuration options
				if (!_.contains(readOnlyControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return "";
				}
			});
			//This helper determines if the numeric range select should be displayed
			handlebars.registerHelper("numericrangevisible", function() {
				var numericRangeControls = ["NumericRange"];
				if (!_.contains(numericRangeControls, this.controlType)) {
					return "style='display:none;'";
				} else {
					return ""; 
				}
			});
			app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
				if(self.model.get("controlType") === "DatetimeBox"){
					self.dateFormat = dateTimeFormat.dateFormat + " " + dateTimeFormat.timeFormat;
				}else{
					self.dateFormat = dateTimeFormat.dateFormat;
				}
			});
		},
		afterRender: function() {
			this.$("span").tooltip();
		},
		serialize: function() { 
			var self = this;
			var cascading;
			if (this.$("#cascading-" + this.model.cid)[0]) {
				cascading = this.$("#cascading-" + this.model.cid)[0].checked;
			} else {
				cascading = this.model.get("dependsOn").length < 1 ? false : true;
			}
			var selectAllEnabled;
			if($("#selectAllEnabled-" + this.model.cid)[0]) {
				selectAllEnabled = $("#selectAllEnabled-" + this.model.cid)[0].checked;
			} else {
				selectAllEnabled = this.model.get("selectAllEnabled");
			}

			var delimitedListSelectEnabled;
			if($("#delimitedListSelectEnabled-" + this.model.cid)[0]) {
				delimitedListSelectEnabled = $("#delimitedListSelectEnabled-" + this.model.cid)[0].checked;
			} else {
				delimitedListSelectEnabled = this.model.get("delimitedListSelectEnabled");
			}

			// add a blank value at the beginning if one isn't present
			this.options.attrHelper.get("allAttrs").sort();
			if(this.options.attrHelper.get("allAttrs")[0]){
				this.options.attrHelper.get("allAttrs").unshift("");
			}

			// Get unconfigured attributes to display in ReadOnly control options.
			this.doPrettyConversions(this.options.attrHelper.get("unconfiguredAttrs"));
			
			// Remove all attributes from unconfiguredAttrs that are already configured
			_.each(this.model.get('readOnlyGroupedAttrs'), function(attrToAdd){
				self.options.attrHelper.set('unconfiguredAttrs',_.without(self.options.attrHelper.get('unconfiguredAttrs'), attrToAdd.ocName));
			});

			return { 
				controlType: this.model.get("controlType"),
				timestamped: this.model.get("timestamped"),
				onlyNewEntries: this.model.get("onlyNewEntries"),
				minChars: this.model.get("minChars"),
				maxChars: this.model.get("maxChars"),
				isWysiwyg: this.model.get("isWysiwyg"),
				regex: this.model.get("regex"),
				regexRule: this.model.get("regexRule"),
				minCharBeforeQuery: this.model.get("minCharBeforeQuery"),
				picklists: this.options.picklists,
				picklist: this.model.get("picklist"),
				cascading: cascading,
				computedPattern: this.model.get("computedPattern"),
				allAttrs: this.options.attrHelper.get("allAttrs").sort(),
				dependsOn: this.model.get("dependsOn"),
				visibilityDependentAttr: this.model.get("visibilityDependentAttr"),
				enableDependentAttr: this.model.get("enableDependentAttr"),
				parentAspect: this.model.get('parentAspect'),
				visibilityDependentAttrVal: this.model.get("visibilityDependentAttrVal"),
				enableDependentAttrVal: this.model.get("enableDependentAttrVal"),
				growable: this.model.get("growable"),
				autoSelect: this.model.get("autoSelect"),
				allowDropdown: this.model.get("allowDropdown"),
				cid: this.model.cid,
				canTypeInBox: this.model.get("canTypeInBox"),
				enforceDateBeforeToday: this.model.get("enforceDateBeforeToday"),
				enforceDateAfterToday: this.model.get("enforceDateAfterToday"),
				repeating: this.model.get("repeating"),
				editable: this.model.get("editable"),
				selectAllEnabled: selectAllEnabled,
				delimitedListSelectEnabled: delimitedListSelectEnabled,
				listDelimiter: this.model.get("listDelimiter"),
				readOnlyGroupedAttrs: this.model.get('readOnlyGroupedAttrs'),
				availableTypeAttrs: this.prettyUnconfiguredAttrs,
				helptext: this.model.get("helptext"),
				defaultValue: this.model.get("defaultValue"),
				defaultValueCurrentDate: this.model.get("defaultValueCurrentDate"),
				makeSearchExact: this.model.get("makeSearchExact"),
				appendOnly: this.model.get("appendOnly"),
				upperCase: this.model.get("upperCase"),
				caseSensitive: this.model.get("caseSensitive"),
				dateFormat: this.dateFormat,
				defaultValueInputError: this.defaultValueInputError,
				externalValueURL: this.model.get("externalValueURL")
			};
		},
		updateComputedPattern: function(event) {
			this.model.set("computedPattern", 
					this.model.get("computedPattern") + "$" + 
					this.$("#computedAttrs-" + this.model.cid).find(":selected").text() + "$");

			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
		updateAttribute: function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			if(attrToSet === "dependsOn"){
				this.updateDependsOnValue(event.target.value);
			}
			else if(attrToSet === 'readOnlyAvailableAttrs'){
				this.addGroupedAttr(event);
			}
			else{
				this.model.set(attrToSet, event.target.value);
				this.render();
			}
			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
		updateAttributeRemove: function(event){
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			if(attrToSet === "removeDependsOn"){
				this.removeDependsOnValue(event);
			}
			else if(attrToSet === 'removeGroupedAttr'){
				this.removeGroupedAttr(event);
			}
			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
		updateAttributeDebounced: _.debounce(function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			this.model.set(attrToSet, event.target.value);
			if(attrToSet === 'regexRule'){
				this.serialize();
			}
			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},1000),
		updateDefaultValueDebounced: _.debounce(function(event) {
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			if(moment(event.target.value, this.dateFormat, true).isValid()){
				this.defaultValueInputError = false;
				this.model.set(attrToSet, event.target.value);
			}else{
				this.defaultValueInputError = true;
			}

			if(attrToSet === 'defaultValue'){
				this.render();
			}
			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},1000),
		updateDependsOnValue: function(value){
			if(!(this.model.get("dependsOn") instanceof Array)){
				var tempArray = [];
				if(this.model.get("dependsOn")){
					tempArray.push(this.model.get("dependsOn"));
				}
				this.model.set("dependsOn", tempArray);
			}
			if(value && this.model.get("dependsOn").indexOf(value) === -1){
				this.model.get("dependsOn").push(value);
				this.render();
				app.trigger("renderPicklistCascadeWarning", true, this.model.get("ocName"));
			}
		},
		removeDependsOnValue: function(event){
			event.stopPropagation();
			this.model.get("dependsOn").splice(this.model.get("dependsOn").indexOf($(event.target).attr("value")), 1);
			this.render();
			app.trigger("renderPicklistCascadeWarning", true, this.model.get("ocName"));
		},
		updateCheckbox: function(event) {
			var notOnModel = ["cascading"];
			//get the attrName from the id, splitting out the cid attached
			var attrToSet = event.target.id.split("-")[0];
			if (!_.contains(notOnModel, attrToSet)) {
				this.model.set(attrToSet, event.target.checked);
			} else if (_.contains(notOnModel, attrToSet) && event.target.checked && this.model.get("dependsOn").length === 0) {
				//this means the cascading checkbox was selected, and dependsOn hasn't been set yet
				//we need to add the first value in allAttrs
				this.model.set("dependsOn", []);
				app.trigger("renderPicklistCascadeWarning", event.target.checked, this.model.get("ocName"));
			}  else if (_.contains(notOnModel, attrToSet) && !event.target.checked) {
				//this means the cascading checkbox was deselected, so we need to clear
				//out the dependsOn attr
				this.model.set("dependsOn", []);
				app.trigger("renderPicklistCascadeWarning", event.target.checked, this.model.get("ocName"));
			}
			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},
		// Add an attribute to the list of this model's read only control grouped attributes.
		addGroupedAttr: function(event){
			// Get the label and value from the triggered event.
			var attrToAdd = {};
			attrToAdd.label = $(event.target).find(':selected').text().trim();
			attrToAdd.ocName = event.currentTarget.value;

			// Add this item to the list of grouped attributes.
			this.model.get('readOnlyGroupedAttrs').push(attrToAdd);

			// Update our attrHelper since the attribte we have just added should be
			// removed from the list of attributes available to be configured.	
			this.attrHelper.set('configuredAttrs',
					_.union(this.attrHelper.get('configuredAttrs'), attrToAdd.ocName));
			this.attrHelper.set('unconfiguredAttrs',
					_.without(this.attrHelper.get('unconfiguredAttrs'), attrToAdd.ocName));

			this.render();
		},
		// Remove an already grouped attribute from the list of this model's read only control.
		removeGroupedAttr: function(event){
			// Get the value from the triggered event.
			var attrToRemove = $(event.target).attr('value');

			// Remove this item from the list of existing grouped attributes.
			var oldArray = this.model.get('readOnlyGroupedAttrs');
			// Filter all values in the oldArray that do not match the new value, resulting in an array that does not contain the removed attribtue.
			// Take this returned array and set it to the model variable.
			this.model.set('readOnlyGroupedAttrs', 
				_.filter(oldArray, function(object){ 
					return object.ocName !== attrToRemove; 
				})
			);

			// Update our attrHelper since the attribte we have just removed should be
			// added back to the list of attributes available to be configured.
			this.attrHelper.set('unconfiguredAttrs',
					_.union(this.attrHelper.get('unconfiguredAttrs'), attrToRemove));
			this.attrHelper.set('configuredAttrs',
					_.without(this.attrHelper.get('configuredAttrs'), attrToRemove));

			this.render();
		},
		//This takes an array of ocNames and turns them into an array of objects sorted by the "pretty" name.
		doPrettyConversions: function(arr){
			var self = this;
			this.prettyUnconfiguredAttrs = [];
			_.each(arr, function(attrOCName){
				app.context.configService.getLabels(self.options.objectType, attrOCName).done(function(label) {
					self.prettyUnconfiguredAttrs.push({
						'label': label,
						'ocName': attrOCName
					});
				});
			});
			//Sort
			this.prettyUnconfiguredAttrs = _.sortBy(this.prettyUnconfiguredAttrs, 'label');
		}
	});

	Formattribute.Views.VisibilityDependentWarning = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributevisibilitydependswarning",
		initialize: function() {
			this.listenTo(app, "renderVisibilityDependentWarning", function() {
				this.render();
			});

			handlebars.registerHelper("visibilityDependentWarning", function(){
				if(this.visibilityDependent && (!this.visibilityDependentAttr || !this.visibilityDependentAttrVal)){
					return '';
				} else {
					return "style='display:none;'";
				}
			});
		}
	});

	Formattribute.Views.EnableDependentWarning = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributeenabledependswarning",
		initialize: function() {
			this.listenTo(app, "renderEnableDependentWarning", function() {
				this.render();
			});

			handlebars.registerHelper("enableDependentWarning", function(){
				if(this.enableDependent && (!this.enableDependentAttr || !this.enableDependentAttrVal)){
					return '';
				} else {
					return "style='display:none;'";
				}
			});
		}
	});

	Formattribute.Views.LockWarning = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributelockwarning",
		initialize: function() {
			this.listenTo(app, "renderlockWarning", function() {
				this.render();
			});

			handlebars.registerHelper("lockWarning", function(){
				if(this.lock && !this.allowedUnlockGroups){
					return '';
				} else {
					return "style='display:none;'";
				}
			});
		}
	});

	Formattribute.Views.Picklistwarning = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributepicklistwarning",
		initialize:function() {
			this.listenTo(app, "renderPicklistWarning", function() {
				this.render();
			});

			handlebars.registerHelper("picklistwarning", function() { 
				// any controls that DON'T have additional options should be specified here;
				var picklistControls = ["DropDown", "AutoComplete", "MultiSelect",
						"ConfigDropDown", "CheckBox", "RadioButton"];
				if(_.contains(picklistControls, this.controlType) && this.picklist === "") {
					return "";
				} else {
					return "style='display:none;'";
				}
			});
		},
		serialize: function() {
			return {
				controlType: this.model.get("controlType"),
				picklist: this.model.get("picklist")
			};
		}
	});

	Formattribute.Views.PicklistCascadeWarning = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributepicklistcascadewarning",
		initialize:function() {
			var self = this;
			this.listenTo(app, "renderPicklistCascadeWarning", function(isCascading, ocName) {
				if(self.model.get("ocName") === ocName){
					self.isCascading = isCascading;
					self.render();
				}
			});

			handlebars.registerHelper("picklistcascadewarning", function() { 
				// any controls that DON'T have additional options should be specified here;
				var picklistControls = ["DropDown", "AutoComplete", "MultiSelect",
						"ConfigDropDown", "CheckBox", "RadioButton"];
				if(_.contains(picklistControls, this.controlType) && this.isCascading && !this.hasDependsOn) {
					return "";
				} else {
					return "style='display:none;'";
				}
			});
		},
		serialize: function() {
			return {
				controlType: this.model.get("controlType"),
				picklist: this.model.get("picklist"),
				isCascading: this.isCascading,
				hasDependsOn: this.model.get("dependsOn").length > 0 ? true : false
			};
		}
	});

	Formattribute.Views.Unconfiguredattrs = Backbone.Layout.extend({
		template: "hpiadmin/formconfig/formattributeunconfiguredattrs",
		events: {
			"change #unconfigured-attrs-select": "addAttr"
		},
		initialize:function() {
			this.typeName = this.options.typeName;
			this.attrHelper = this.options.attrHelper;

			//to get filtering working like we expect, we need the list of uncofigured
			//attrs, but also another list that we use in the view
			this.filteredAttrs = _.clone(this.attrHelper.get("unconfiguredAttrs").sort());

			this.listenTo(this.attrHelper, "change:unconfiguredAttrs", function() {
				//the unconfiguredAttrs were changed somewhere, reset the viewableAttrs
				this.attrHelper.trigger("Formattribute:filterAttrs");
			});

			this.listenTo(this.attrHelper, "Formattribute:filterAttrs", function(cid) {
				//the cid is the "id" for the specific dropdown we are wanting to filter on. The cid is passed
				//in when the Formtype.AttrControl view fires an event when someone starts typing
				//in the filter input. 
				var filterValue;
				if(!$(".formtypeattr-filter-" +cid)[0]) {
					filterValue =$("#filter-attrs-input")[0].value;
				}
				else {
					filterValue = $(".formtypeattr-filter-" +cid)[0].value;
				}
	
				
				//Get the unconfigured attrs.
				this.doPrettyConversions(this.attrHelper.get("unconfiguredAttrs"));
				
				//Filter based on the label
				this.filteredAttrs = _.filter(this.prettyFilteredAttrs, function(attr) { 
					if (attr.label.toLowerCase().indexOf(filterValue.toLowerCase()) !== -1) {
						return true;
					} else {
						return false;
					}
				});
				//Sort the filtered results.
				this.prettyFilteredAttrs = _.sortBy(this.filteredAttrs, 'label');
					
				this.render();
			});

			this.listenTo(this.attrHelper, "Formattribute:addAllAttrs", this.addAllAttrs);
			
			//Get the initial unconfigured attrs.
			this.doPrettyConversions(this.filteredAttrs);
		},
		//This takes an array of ocNames and turns them into an array of objects sorted by the "pretty" name.
		doPrettyConversions: function(arr){
			var self = this;
			this.prettyFilteredAttrs = [];
			_.each(arr, function(attr){
				app.context.configService.getLabels(self.typeName, attr).done(function(label) {
					self.prettyFilteredAttrs.push({
						'label': label,
						'value': attr
					});
				});
			});
			//Sort
			this.prettyFilteredAttrs = _.sortBy(this.prettyFilteredAttrs, 'label');
		},
		serialize: function(){
			return {
				typeName: this.typeName,
				filteredAttrs: this.prettyFilteredAttrs
			};
		},
		addAttr: function() {
			var that = this;
			// loop over each of the selected options (this is a multiple select box)
			this.$("option:selected").each(function() {
				var ocName = this.value;

				//update our attrHelper
				that.attrHelper.set("configuredAttrs" , 
						_.union(that.attrHelper.get("configuredAttrs"), ocName));
				that.attrHelper.set("unconfiguredAttrs", 
						_.without(that.attrHelper.get("unconfiguredAttrs"), ocName));

				//tell the collection of Formattrs that one was added
				that.attrHelper.trigger("configuredAttrsAddition", ocName);
			});
		},
		addAllAttrs: function() {
			var that = this;
			// loop over all options
			this.$("option").each(function() {
				var ocName = this.value;

				//update our attrHelper
				that.attrHelper.set("configuredAttrs" , 
						_.union(that.attrHelper.get("configuredAttrs"), ocName));
				that.attrHelper.set("unconfiguredAttrs", 
						_.without(that.attrHelper.get("unconfiguredAttrs"), ocName));

				//tell the collection of Formattrs that one was added
				that.attrHelper.trigger("configuredAttrsSecondaryAddition", ocName);
			});
		}
	});

	// Return the module for AMD compliance.
	return Formattribute;

});