define([
	"app",
	"modules/hpiadmin/hpiadmin",
	//modules
	"modules/common/tossacross",
	"modules/hpiadmin/common/iosswitch"
],
function(app, Hpiadmin, TossAcross, iOSSwitch) {

	"use strict";

	var DeveloperZone = app.module();

	DeveloperZone.Collection = Backbone.Collection.extend({
		model: DeveloperZone.Model
	});

	DeveloperZone.Model = Hpiadmin.Config.extend({
		type: "DeveloperZone",

		defaults: {
			type: "DeveloperZone"
		},

		// in case we are ever just creating a dashconfig model - like in unit tests...
		initialize: function(options) {

		}
	});

	// this is the create modal view for creating a new dashlet
	DeveloperZone.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/developerzone/developerzone-layout",

		events: {
			//Events here
		},

		initialize: function() {
			// let's make a clean model for this new dashlet
			this.defaultModel = new DeveloperZone.Model();

			// get our dashlet models already configured
			this.dashletModels = this.options.model.get("developerModels");

			// this will hold our UI DOM elements so we can store references to them here
			this.ui = {};
		},

		beforeRender: function(){
			this.renderDeveloperViews();
		},

		afterRender: function() {

		},
		renderDeveloperViews: function() {
			var developerView = new DeveloperZone.Views.View({
				model: this.defaultModel
			});


			// insert the dashlets in order based on the ordinal
			this.insertView("#developer-zone-view-outlet", developerView);
		}
	});

	//copy pasta this to create your custom views if you need more than one
	DeveloperZone.Views.View = Backbone.Layout.extend({
		template: "hpiadmin/developerzone/developerzone-view",

		events: {

		},

		defaults: {

		},

		initialize: function(options){
			this.availableAttributes = new Backbone.Collection([
				{
					label: 'Fire',
				 	ocName: 'fire'
				},
				{
					label: 'Ice',
				 	ocName: 'ice'
				},
				{
					label: 'Water',
				 	ocName: 'water'
				},
				{
					label: 'Air',
				 	ocName: 'air'
				},
				{
					label: 'Earch',
				 	ocName: 'earth'
				},
				{
					label: 'Wind',
				 	ocName: 'wind'
				}

			]);
			this.availableAttributes2 = new Backbone.Collection([
				{
					label: 'Charizard',
				 	ocName: 'char'
				},
				{
					label: 'Blastoise',
				 	ocName: 'blast'
				},
				{
					label: 'Mewtwo',
				 	ocName: 'mewtwo'
				},
				{
					label: 'Dragonite',
				 	ocName: 'drag'
				}

			]);
			this.selectedAttributes = new Backbone.Collection([]);
			this.selectedAttributes2 = new Backbone.Collection([]);

			this.metaToss = new TossAcross.Layout({
				clickAcross: true,
				enableAddRemove: true,
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'label',
					valueAttr: 'ocName',
					collection: this.availableAttributes
				},
				targetCollections: [
					{
						filter: true,
						title: 'Selected Attributes',
						labelAttr: 'label',
						valueAttr: 'ocName',
						collection: this.selectedAttributes
					}
				]
			});

			this.metaToss2 = new TossAcross.Layout({
				srcCollection: {
					title: 'Available Attributes',
					filter: true,
					labelAttr: 'label',
					valueAttr: 'ocName',
					collection: this.availableAttributes2
				},
				targetCollections: [
					{
						title: 'Selected Attributes',
						labelAttr: 'label',
						valueAttr: 'ocName',
						collection: this.selectedAttributes2
					}
				]
			});

			this.configSwitch = new iOSSwitch.View({
				model: this.options.model,
				configModelKey: "switch-example",
				switchTitle: "Example Backbone Config Switch",
				configDescription: "This is an example Backbone switch."
			});

			this.setViews({
				"#meta-toss-across2": this.metaToss2,
				"#meta-toss-across": this.metaToss,
				'#hpi-config-switch': this.configSwitch
			}).render();
		},

		// before we render
		beforeRender: function() {

		},

		afterRender: function() {

		}
	});

	return DeveloperZone;
});
