// RepoAspect module
define([
        "app",
        "modules/common/alert/alert",
        "handlebars"
    ],

    function(app, Alert, Handlebars) {

        var RepoAspect = app.module();

        // Default Model.
        RepoAspect.Model = Backbone.Model.extend({
            defaults: {
                ocName: "",
                repoName: "",
                superTypeName: "",
                properties: null,
                defaultAspects: null,
                allProperties: null
            },

            url: function() {
                return app.serviceUrlRoot + "/dictionary/aspect?aspect=" + this.get("ocName");
            }
        });

        // Default Collection.
        RepoAspect.Collection = Backbone.Collection.extend({
            model: RepoAspect.Model,

            url: app.serviceUrlRoot + "/dictionary/aspect/definition",

            comparator: "ocName",

            parse: function(resp) {
                var aspects = _.toArray(resp);
                return _.filter(aspects, function(aspect) {
                    return aspect.properties.length > 0;
                });
            }
        });

        RepoAspect.Views.Item = Backbone.View.extend({
            template: "hpiadmin/nmac/repoaspect/item",

            tagName: "option",

            attributes: {
                title: "Click to add attribute"
            },

            serialize: function() {
                return {
                    repoAspect: this.model.toJSON()
                };
            }
        });

        RepoAspect.Views.List = Backbone.View.extend({
            tagName: "select",

            events: {
                // called when the user clicks on any of the options in the object type select box
                "change": "clickedRepoAspect"
            },

            attributes: {
                multiple: "multiple",
                size: "10",
                id: "unconfigured-types-select"
            },

            filteredRepoAspects: [],

            initialize: function() {
                this.collection = new RepoAspect.Collection();
                this.collection.fetch({
                    error: this.fetchError
                });

                //Listen for a trigger that clears the entire config. Re-fetch the entire of list of repoTypes and 
                //re-render
                this.listenTo(app, "clearOtc:clickYes", function(collection) {
                    this.collection.fetch();
                    this.filteredRepoAspects = [];
                    this.render();
                });

                //Whenever the repoTypes collection has reset called on it, re-render the view.
                this.listenTo(this.collection, "sync", function() {
                    this.render();
                });

                //When the collection controlling the Hpitypeconfig view changes, update the list of repoTypes available
                //to add to the config. This is what keeps the repoTypes up-to-date when loading a saved config
                this.listenTo(app, "hpiAspectConfig:collectionChange", function(collection) {
                    this.filteredRepoAspects = [];
                    collection.each(function(hpiAspectConfig) {
                        this.filteredRepoAspects.push(hpiAspectConfig.get("repoTypeName"));
                    }, this);
                    this.render();
                });

                // Listen for when the user types in the text input to filter the unconfigured object types.
                // "filter" is the text currently in the filter input and is updated on every keyup
                this.listenTo(app, "unconfiguredAspects:filter", function(filter, configuredAspects) {
                    var self = this;
                    this.filteredRepoAspects = [];

                    // First we want to filter all the already-configured types
                    configuredAspects.each(function(hpiAspectConfig) {
                        this.filteredRepoAspects.push(hpiAspectConfig.get("repoTypeName"));
                    }, this);
                    // Filter all those types that do not match our filter input
                    _.each(this.collection.models, function(aspect) {
                        if (aspect.attributes.ocName.toLowerCase().indexOf(filter.toLowerCase()) === -1) {
                            self.filteredRepoAspects.push(aspect.attributes.ocName);
                        }
                    });
                    // When we render now, the dropdown will contain all types that have not been configured
                    // and match our filter string input
                    this.render();
                });
            },

            // Check each repoType and if it's name exists in the filteredRepoTypes array, do not insert a view for it.
            beforeRender: function() {
                if (this.collection) {
                    this.collection.sort();
                    this.collection.each(function(repoAspect) {
                        if (!_.contains(this.filteredRepoAspects, repoAspect.get("ocName"))) {
                            this.insertView(new RepoAspect.Views.Item({
                                model: repoAspect
                            }));
                        }
                    }, this);
                }
            },

            // called when the user clicks on any of the options in the object type select box
            clickedRepoAspect: function(event) {
                var self = this;

                // loop over each of the selected options (this is a multiple select box)
                this.$("option:selected").each(function() {
                    // get the repo type the user clicked on
                    var clickedOnRepoAspect = $(this).text();
                    clickedOnRepoAspect = Handlebars.Utils.escapeExpression(clickedOnRepoAspect);

                    // find the model in our collection that corresponds to this type
                    var repoModel = self.collection.findWhere({
                        ocName: clickedOnRepoAspect
                    });

                    // trigger the event that the user clicked on this type
                    app.trigger("repoAspect:click", repoModel);
                });
            },

            //Displays an error alert if the collection of repoTypes cannot be provided by the REST service. Navigates
            //the user back to the index.
            fetchError: function() {
                app.trigger("alert:info", {
                    header: window.localize("modules.hpiAdmin.otc.repoType.unableToFetch"),
                    message: window.localize("modules.hpiAdmin.otc.repoType.unableToConnect"),
                    success: function() {
                        Backbone.history.navigate("", {
                            trigger: true
                        });
                        app.layout.removeView("#configDetail");
                    }
                });
            }
        });

        return RepoAspect;

    });