// Hpitypeconfigattrs module
define([
        "app",
        "knockout",
        "knockback",
        "module"
    ],

    function(app, ko, kb, module) {

        var NonMandatoryAspectAttrs = app.module();

        var markErrors = function() {

            //only check for configOcName if were in edit mode
            this.$('.configOcName').filter(function() {
                return !this.value;
            }).addClass('list-group-item-danger');
            this.$('.configLabel').filter(function() {
                return !this.value;
            }).addClass('list-group-item-danger');

        };

        // Default Model.
        NonMandatoryAspectAttrs.Model = Backbone.Model.extend({
            defaults: {
                label: "",
                ocName: "",
                dataType: "",
                repoName: "",
                filter: "",
                repeating: false
            }
        });

        // Default Collection.
        NonMandatoryAspectAttrs.Collection = Backbone.Collection.extend({
            model: NonMandatoryAspectAttrs.Model,

            comparator: function(item) {
                if (item.get("label") !== null) {
                    return item.get("label").toLowerCase(); 
                }
                else {
                    return item.get("ocName").toLowerCase();                
                }   
            }     
        });

        //Controls the Hpitypeconfigattrss within the for each block of the hpitypeconfigattrs template.
        NonMandatoryAspectAttrs.ModelViewModel = function(options) {
            return kb.ViewModel.extend({
                constructor: function(model) {
                    //adding this for model access in the collection viewmodel
                    this.model = model;
                    this.label = kb.observable(model, "label");
                    this.dataType = kb.observable(model, "dataType");
                    this.ocName = kb.observable(model, "ocName");
                    this.repoName = kb.observable(model, "repoName");
                    this.filter = kb.observable(model, "filter");
                    this.repeating = kb.observable(model,"repeating");		
                    //ko binding used for hbase when an attr is marked as readOnly. Not currently used in alfresco or dctm.
                    //if in edit mode, default to readOnly
                    this.hpiAdminReadOnly = kb.observable(model, { key: "hpiAdminReadOnly", 'default': !module.config().editMode });
                    if (module.config().editMode) {
                        this.repeating = kb.observable(model, "repeating");
                    }
                }
            });
        };

        NonMandatoryAspectAttrs.CollectionViewModel = function(model) {
            var that = this;
            //if not in edit mode, default to showing all system attributes
            that.showSystemAttributes = kb.observable(model, { key: "showSystemAttributes", 'default': !module.config().editMode });
            that.toggleSystemAttributesText = ko.observable("Show System Attributes");
            that.hpiTypeConfigsAttrs = kb.collectionObservable(model.get("attrs"), {
                factories: {
                    "models": NonMandatoryAspectAttrs.ModelViewModel()
                }
            });
            that.label = kb.observable(model, "label");
            that.ocName = kb.observable(model, "ocName");
            that.isContainer = kb.observable(model, "isContainer");
            that.allProps = model.get("attrs").pluck("ocName");

            //this will remove the attribute model from the viewmodel
            that.removeAttr = function(attr) {
                app.trigger("alert:confirmation", {
                    message: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.areYouSure"),
                    header: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.confirmRemoval"),
                    confirm: function() {
                        that.hpiTypeConfigsAttrs.collection().remove(attr.model);
                    }
                });
            };

            that.addAttr = function() {
                if (!module.config().editMode) {
                    var addAttrView = new AddAttrView({ typeModel: model, viewModel: that });
                    app.trigger("alert:custom", { view: addAttrView });
                } else {
                    that.hpiTypeConfigsAttrs.collection().add(
                        new NonMandatoryAspectAttrs.Model({
                            label: '',
                            ocName: '',
                            dataType: 'string',
                            repoName: '',
                            filter: '',
                            hpiAdminReadOnly: false,
                            repeating: false,
                            repoEditable: false
                        }), { at: 0 });
                    markErrors();
                    //trigger the submit to disabled since we just added unfilled out fields
                    app.trigger("hpiTypeConfig:toggleSubmit", false);
                }
            };

            that.toggleSystemAttributes = function() {
                if (that.showSystemAttributes()) {
                    that.showSystemAttributes(false);
                    that.toggleSystemAttributesText(window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.showSystemAttr"));
                } else {
                    that.showSystemAttributes(true);
                    that.toggleSystemAttributesText(window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.hideSystemAttr"));
                }
            };

            that.removeType = function() {
                app.trigger("hpiTypeConfig:clickMinusForHpiTypeConfig", model);
            };
        };

        var AddAttrView = Backbone.Layout.extend({
            template: "hpiadmin/nmac/nonmandatoryaspectconfigattrs/addattrmodal",
            events: {
                'click #add-btn': 'add',
                'click #addAnother-btn': 'addAnother'
            },
            initialize: function() {
                var that = this;
                var aspect = this.options.typeModel.get("ocName");
                that.allAttrs = [];
                that.exisitngAttrs = _.map(that.options.typeModel.get("attrs").models, function(attr) {
                    return attr.get("ocName");
                });
                $.ajax({
                    url: app.serviceUrlRoot + "/dictionary/aspect?aspect=" + aspect,
                    success: function(fullType) {
                        that.fullType = fullType;
                        that.allAttrs = fullType.allProperties;

                        //we don't want to add any attrs already on the model
                        that.allAttrs = _.reject(that.allAttrs, function(attr) {
                            return _.contains(that.exisitngAttrs, attr.ocName);
                        });

                        that.allAttrs.sort(function(a, b) {
                            return a.ocName.localeCompare(b.ocName);
                        });
                        that.render();
                    }
                });

            },
            addAnother: function() {
                var ocProp = this.$('#newProp-select').val();
                var prop = _.findWhere(this.allAttrs, { ocName: ocProp });
                // If you are adding a Date object type, set the filter to be "Date"
                var filter = prop.dataType === "date" ? "date" : "";
                this.options.viewModel.hpiTypeConfigsAttrs.collection().add(
                    new NonMandatoryAspectAttrs.Model({
                        label: prop.label,
                        ocName: prop.ocName,
                        dataType: prop.dataType,
                        repoName: prop.repoName,
                        repeating: prop.repeating,
                        filter: filter,
                        repoEditable: prop.repoEditable
                    }), { at: 0 });

                // remove the attribute that is added from list of available attributes to add 
                // unserscore without
                this.allAttrs = _.without(this.allAttrs, prop);
                this.render();
            },
            add: function() {
                this.addAnother();
                app.trigger("alert:close");
            },
            serialize: function() {
                return {
                    type: this.options.typeModel.get("ocName"),
                    properties: this.allAttrs
                };
            }
        });

        NonMandatoryAspectAttrs.View = Backbone.View.extend({
            template: "hpiadmin/nmac/nonmandatoryaspectconfigattrs/nonmandatoryaspectconfigattrs",
            events: {
                "keyup .configOcName": "updateValidation",
                "keyup .configLabel": "updateValidation"
            },
            initialize: function() {
                this.ui = {};
            },
            updateValidation: function(event) {
                if (module.config().editMode) {
                    //if we added a brand new row, there will be blank values and this will mark them errored accordingly
                    if (event.target.value.trim().length > 0) {
                        this.$(event.currentTarget).removeClass('list-group-item-danger');
                    } else {
                        this.$(event.currentTarget).addClass('list-group-item-danger');
                    }
                }
            },
            afterRender: function() {
                if (this.viewModel) {
                    ko.cleanNode(this.$el[0]);
                    kb.release(this.viewModel);
                }

                this.ui.ocInfo = this.$(".configs-tooltip.ocInfo");
                //add popover to icon for glyphicons
                this.ui.ocInfo.popover({
                    placement: 'top',
                    trigger: 'hover',
                    title: 'OC Name',
                    html: true,
                    content: "<p> The OC Name for each Aspect is generated with a unique ID to avoid replacing attributes.</p>",
                    delay: { show: 500 }
                });


                this.ui.tooltip = this.$(".configs-tooltip.containerInfo");
                //add popover to icon for glyphicons
                this.ui.tooltip.popover({
                    placement: 'top',
                    trigger: 'hover',
                    title: window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.isContainer"),
                    html: true,
                    content: "<p>" + window.localize("modules.hpiAdmin.otc.hpiTypeConfigsAttrs.thisShouldBe") + "</p>",
                    delay: { show: 500 }
                });


                this.viewModel = new NonMandatoryAspectAttrs.CollectionViewModel(this.model);
                kb.applyBindings(this.viewModel, this.$el[0]);

                if (module.config().editMode) {
                    //if we added a brand new row, there will be blank values and this will mark them errored accordingly
                    markErrors();
                }
            },
            serialize: function() {
                return {
                    'editModeEnabled': module.config().editMode
                };
            }
        });

        return NonMandatoryAspectAttrs;

    });