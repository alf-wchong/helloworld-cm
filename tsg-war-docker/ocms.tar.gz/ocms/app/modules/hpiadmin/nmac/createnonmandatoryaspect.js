// Objecttypeconfig module
define([
        "app",
        'module',
        "modules/hpiadmin/nmac/singlenonmandatoryaspect",
        "modules/hpiadmin/nmac/nonmandatoryaspectattrs"
    ],

    function(app, module, SingleNonMandatoryAspect, NonMandatoryAspectAttrs) {
        "use strict";

        var CreateNonMandatoryAspect = app.module();

        CreateNonMandatoryAspect.View = Backbone.Layout.extend({
            template: "hpiadmin/nmac/createnonmandatoryaspectcontrol",
            events: {
                "click .create-type-input": "clickFilterInput",
                "click button.close": "closeMenu",
                "click .create-nmac-aspect": "createAspect",
                "keyup .aspect-label-input": "updateAspectLabel",
                "keyup .aspect-ocName-input": "updateAspectOCName",
                "click .type-supertype-input": "updateTypeSupertype"
            },
            initialize: function() {
                this.collection.sort();
                this.filterLabel = '';
                this.aspectOCName = '';
                this.aspectContainer = '';
                this.typeSupertype = '';
                this.availableSupertypes = [];

                _.each(this.collection.models, function(model) {
                    this.availableSupertypes.push({
                        'supertypeLabel': model.get("label"),
                        'supertypeOCname': model.get("ocName")
                    });
                }, this);
            },
            serialize: function() {
                return {
                    availableSupertypes: this.availableSupertypes
                };
            },
            updateAspectLabel: function(event) {
                this.filterLabel = event.target.value;
                if (this.filterLabel.trim().length > 0) {
                    this.$(event.currentTarget).removeClass('list-group-item-danger');
                } else {
                    this.$(event.currentTarget).addClass('list-group-item-danger');
                }
                this.checkValidation();
            },
            updateTypeSupertype: function(event) {
                this.typeSupertype = event.target.value;
                this.checkValidation();
            },
            updateAspectOCName: function(event) {
                this.aspectOCName = event.target.value;
                if (this.aspectOCName.trim().length > 0) {
                    this.$(event.currentTarget).removeClass('list-group-item-danger');
                } else {
                    this.$(event.currentTarget).addClass('list-group-item-danger');
                }
                this.checkValidation();
            },
            checkValidation: function() {
                var self = this;
                if (this.filterLabel.length > 0 && this.aspectOCName.length > 0 && this.typeSupertype.length > 0) {
                    self.toggleSubmit(true);
                } else {
                    self.toggleSubmit(false);
                }
            },
            toggleSubmit: function(enabled) {
                if (enabled) {
                    this.$('.create-nmac-aspect').removeAttr('disabled');
                } else {
                    this.$('.create-nmac-aspect').attr('disabled', 'disabled');
                }
            },
            createAspect: function() {
                var self = this;
                // we're going to build up an array of type config attrs 
                var aspectConfigAttrs = [];

                // helper function to add a type config attribute to the array of aspectConfigAttrs we're building
                var addAspectConfigAttr = function(prop) {
                    //default the filter for all dataTypes of date to "date"
                    var filter = prop.dataType === "date" ? "date" : "";
                    aspectConfigAttrs.push({
                        label: prop.label,
                        ocName: prop.ocName,
                        dataType: prop.dataType,
                        repoName: prop.repoName,
                        repeating: prop.repeating,
                        repoEditable: prop.repoEditable,
                        hpiAdminReadOnly: prop.hpiAdminReadOnly,
                        filter: filter
                    });
                };

                // each time a new model is added to the config, see if that model's superType is already a part
                // of the collection of models for the config. If the superTypeName exists, we want to use the superType's
                // attributes that are already configured for the attributes the models have in common.
                this.collection.each(function(configModel) {
                    if (configModel.get("label") === self.typeSupertype || configModel.get("ocName") === self.typeSupertype) {
                        // we found our super type so loop through each of its attribute, find the corresponding attribute in the sub-type
                        // and copy the attributes from the super type to the sub-type
                        self.aspectContainer = configModel.get("isContainer");
                        configModel.get("attrs").each(function(attr) {
                            //Add and Hpitypeconfigattrs Model for each property found on the supertype
                            addAspectConfigAttr(attr.attributes);
                        });
                    }
                });
                // create our collection with our array of type config attrs
                var hpiAttrs = new NonMandatoryAspectAttrs.Collection(aspectConfigAttrs).sort();

                // create our type config model now that we have our attrs for it
                this.collection.add(new SingleNonMandatoryAspect.Model({
                    label: this.filterLabel,
                    ocName: this.aspectOCName,
                    isContainer: this.aspectContainer,
                    repoTypeName: this.aspectOCName,
                    superType: this.typeSupertype,
                    attrs: hpiAttrs
                }));

                //clear out values after were done with them incase they want to reopen the view
                this.resetForm();
            },
            resetForm: function() {
                this.$('.aspect-label-input')[0].value = '';
                this.$('.aspect-ocName-input')[0].value = '';
                this.$('.type-supertype-input')[0].value = '';
                this.$('.aspect-label-input').addClass('list-group-item-danger');
                this.$('.aspect-ocName-input').addClass('list-group-item-danger');
                this.filterLabel = '';
                this.aspectOCName = '';
                this.aspectContainer = 'false';
                this.typeSupertype = '';
            },
            clickFilterInput: function(e) {
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            },
            closeMenu: function(e) {
                this.$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
            }
        });

        return CreateNonMandatoryAspect;

    });