
define([
    "app",
    'oc',
    "modules/hpiadmin/hpiadmin"
],

function(app, OC,Hpiadmin) {

    var UserConfig = app.module();

    UserConfig.Model = Hpiadmin.Config.extend({
        type: "UserConfig",
        defaults: {
            type: "UserConfig"
        }
    });

    UserConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/userconfig/userconfig",
        className: "userConfig",
        initialize: function(options) {
            var self =this;
            this.usersView = new UserConfig.Users();
            this.setView('#users-outlet', self.usersView);

            //Calls createUser endpoint
            this.listenTo(app, "populateUsersRender", function(){
                self.usersView.populateUsers();
            });  

            this.listenTo(this.usersView, "onClickRemoveUserConfirmation", function(userToRemove){
                self.userToRemove = userToRemove;
                 $.ajax({
                    type: "POST", 
                    url: app.serviceUrlRoot + "/users/deleteUser?userToRemove=" + userToRemove,
                    contentType: "application/json",
                    data: JSON.stringify(userToRemove),    
                        success: function(results){
                            if(self.getView('#users-metadata-outlet') !== undefined){
                                if(self.userToRemove == self.getView("#users-metadata-outlet").userID){
                                    self.removeView('#users-metadata-outlet'); 
                                }
                            }
                            self.usersView.populateUsers();
                            app.trigger("removeUsers", self.userToRemove); 
                        },
                         error: function(jqXHR, textStatus, errorThrown){
                             app.trigger("alert:error", {
                                message: "An unexpected error occured when trying to remove the user. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                            });
                        }
                    });
            });
            //Passes userName to metaData to display metadata for selected User
            this.listenTo(this.usersView, "user-selected", function(userID, firstName, lastName){
                //passes in layout as a refrence to UserConfig.Views.Layout so that if the password is updated then UserConfig.UserMetadata can re-render
                this.setView('#users-metadata-outlet', new UserConfig.UserMetadata({"userID": userID,'firstName':firstName,'lastName': lastName, 'layout':this})).render();
            }); 
        }
    });

    UserConfig.Users = Backbone.Layout.extend({ 
        template: "hpiadmin/userconfig/users",
         events: {
            'click #new-user-button': 'onClickAddNewUser',
            'click #remove-user': 'onClickRemoveUserConfirmation',
            'click .list-group-item': 'onClickUser',
            'keyup .savedsearch-filter-results': 'filterResults'
        },
        initialize: function(options) {
            this.users = [];
            this.populateUsers();
            this.insertFilterText();
        },
        insertFilterText: function(){
            if(this.filterText !== undefined){
                $('.savedsearch-filter-results').text(this.filterText);
            }
        },
        userRender: function(results){
            var self = this;
            var users = [];
             _.each(results, function(result) {
                users.push({
                    firstName: result.firstName,
                    lastName: result.lastName,
                    userName : result.userName
                });
            });
            self.users = users;
            self.render(); 
        },
        populateUsers: function()
        {
            var self = this;
            var requestObj = {
                "authorityType": "user"
            };
            $.ajax(
            {
                url: app.serviceUrlRoot + "/authorities/search", 
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                success: function (results) {
                    var users = [];
                    _.each(results, function(result) {
                        users.push({
                            firstName: result.firstName,
                            lastName: result.lastName,
                            userName : result.authorityId
                        });
                    });

                    self.users = users;
                    self.render();  
                },
                global : false
            });
        },

        onClickUser: function(options){
            var self =this;
            //This if statement is to check to see if the user clicked the remove button. 
            if(options.currentTarget.attributes.value.value !== "remove-user"){
                var userID = options.currentTarget.attributes.value.value;
                if( userID !== ""){
                    self.trigger("user-selected", userID);
                }
                //remove the class from all other selected items
                $(".list-group-item").removeClass("user-config-active");
                //add the class to signify this was the user that was selected
                $("#user-" + userID).addClass("user-config-active");
            }    
        },
        onClickAddNewUser: function(options) {
            this.users = [];
            var passingInOptions = {
                'register' : "false"
            };
            var createUser = new UserConfig.CreateUserView(passingInOptions);
            app.trigger('alert:custom', {
                view: createUser
            }); 
        },
        onClickRemoveUserConfirmation: function(options){
            var self = this;
            var userToRemove = options.currentTarget.parentElement.innerText;
            var usersID = options.currentTarget.parentElement.attributes.value.value;
            app.trigger("alert:confirmation", {
                header: "Are you sure?", 
                message: "Please confirm that you would like to delete " + userToRemove,
                confirm: function() {
                   self.trigger("onClickRemoveUserConfirmation", usersID);
                }
            });
        },
        filterResults: _.debounce(function(event) {
            var self = this;
            self.filterText = $(event.target).val().toLowerCase();
            var filteredUsers;
            var unfilteredUsers = self.allUsers;
                filteredUsers = _.filter(unfilteredUsers, function(model) {
                    var found = false;
                    if(model.firstName.toLowerCase().indexOf(self.filterText) !== -1){
                        found = true;  
                    }
                    return found;
                });
            self.userRender(filteredUsers);
        }, 400),
        afterRender: function(){
            if(this.filterText !== undefined){
                $('.savedsearch-filter-results').val(this.filterText);
                 $('.savedsearch-filter-results').focus();
            }
        },
        serialize: function() {
            return {
                "users": this.users
            };
        }
    });

    /* View for the Create User Modal*/
    UserConfig.CreateUserView = Backbone.Layout.extend({
        template: "hpiadmin/userconfig/createUser",
        events: {
            'click #new-config-user-save': 'createUser',
            'keyup #new-config-firstName': 'update',
            'keyup #new-config-lastName': 'update',
            'keyup #new-config-Email': 'update',
            'keyup #new-config-Password': 'update',
            'keyup #new-config-confirmPassword': 'update',
            'keyup #new-config-userName': 'update'  
        },
        initialize: function(options) {
            this.options = options;
            this.validEmail = false;
        },
        update: _.debounce(function(event){
            var input = this.$(event.currentTarget).val();
            var id = '#'+event.currentTarget.id;
            if(input.length > 0){
                this.$(id +'-error').text('');
                this.$(id).parent().removeClass("has-error");
                if(id === "#new-config-userName"){
                    var lowerCaseUserName = input.toLowerCase();
                    $(id).val(lowerCaseUserName);
                } else if(id === "#new-config-Email"){
                    //validates email address that the email address follows formate: [letters]@[letters].[At least 2 letters]
                    var emailReg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                    if(emailReg.test(input)){
                        this.validEmail = true;
                        this.$(id +'-error').text('');
                        this.$(id).parent().removeClass("has-error");
                    }else{
                        this.$(id +'-error').text('Not a valid email address');
                        this.$(id).parent().addClass("has-error");
                        this.validEmail = false;
                    }
                }else if(id === "#new-config-confirmPassword" || id === "#new-config-Password"){
                   var password = this.$("#new-config-Password").val();
                    var confirmPassword = this.$("#new-config-confirmPassword").val();
                    if(confirmPassword === password){
                        this.$("#new-config-confirmPassword-error").text('');
                        this.$("#new-config-Password-error").text('');
                        this.$("#new-config-confirmPassword").parent().removeClass("has-error");
                        this.$("#new-config-Password").parent().removeClass("has-error");
                    }else{
                        this.$("#new-config-confirmPassword-error").text('Password and Confirm Password dont match!');
                        this.$("#new-config-Password-error").text('Password and Confirm Password dont match!');
                        this.$("#new-config-confirmPassword").parent().addClass("has-error");
                        this.$("#new-config-Password").parent().addClass("has-error");
                    }
                }
            } else {
                this.$(id +'-error').text('This field must be filled out');
                this.$(id).parent().addClass("has-error");
            }
            
            this.enableCreateButton();
        }),
        enableCreateButton: function(){
            var userName = $('#new-config-userName').val();
            var password = $('#new-config-Password').val();
            var confirmPassword = $('#new-config-confirmPassword').val();
            var firstName =  $('#new-config-firstName').val();
            var lastName =  $('#new-config-lastName').val();

            if( firstName && lastName && userName && this.validEmail && password && confirmPassword && password === confirmPassword){
                $('#new-config-user-save').attr("disabled", false);
            }else{
                $('#new-config-user-save').attr("disabled", true);
            }
        },
        createUser: function(event){
            var self = this;
            self.event = event;
            var userName = $('#new-config-userName').val();
            var email = $('#new-config-Email').val();
            var password = $('#new-config-Password').val();
            var firstName = $('#new-config-firstName').val();
            var lastName = $('#new-config-lastName').val();
            self.userName = userName;
            self.password = password;

            $.ajax({type: "POST", url: app.serviceUrlRoot + "/users/createUser?"+ "userName=" + userName + "&email=" + email + "&firstName=" + firstName + "&lastName=" + lastName + "&password=" + password ,  
                    success: function(results){
                        
                            if(self.options.register === "register"){
                                $.ajax({type: "POST",
                                 url: app.serviceUrlRoot + "/authentication/newSession?"+ "username=" + userName +"&docbase=" +"testDoc",
                                 data: password,
                                 contentType: "text/plain",  
                                    success: function(results){
                                        app.trigger("registeredUser", self.userName,self.password, self.event);
                                        //Backbone.history.navigate(app.context.currentApplicationConfig().get("defaultPath") || "/dashboard", {trigger: true});
                                    }
                                });
                            }else{
                                app.trigger("alert:close");
                                app.trigger("populateUsersRender");
                            }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        app.log.debug("You failed-createUser");
                        if(jqXHR.status === 500){
                            $('#new-config-userName-error').text('This User Name is not unique!');
                        }
                    }     
                });
        }
    });
    
    UserConfig.UserMetadata = Backbone.Layout.extend({
        template: "hpiadmin/userconfig/userMetadata",
        events: {
            'click #metadata-password-edit': 'onClickEdit',
            'click #metadata-save' : 'onClickSave',
            'keyup .userInfo' : 'update'
        },
        initialize: function(options){
            this.options = options;
            this.userName = this.options.userID;
            this.lastLogin = null;
            this.email = null;
            this.failedPasswordCount = null;
            this.getMetaData();
        },
        update: _.debounce(function(event){
            var id = '#'+event.currentTarget.id;
            if(id === "#metadata-email"){
                this.checkEmail();
            }else{
                this.checkForChanges();
            }
        }),
        checkForChanges: function(){
            var firstName = $('#metadata-firstName').val();
            var lastName = $('#metadata-lastName').val();
            var email = $('#metadata-email').val();
            if(this.metadata.firstName === firstName && this.metadata.lastName === lastName && this.metadata.emailAddress === email){
                $('#metadata-save').hide();
            }else{
                $('#metadata-save').show();
            }
        },
        getMetaData: function(){
            var self = this;
            var requestObj = {
                "authorityType": "user",
                "criterion": {
                    "attrToSearch": "userName", 
                    "matchType": "contains", 
                    "searchTerm": self.userName
                }
            };
            $.ajax(
            {
                url: app.serviceUrlRoot + "/authorities/search",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                success: function(result){
                    self.metadata = result[0];
                    self.lastLogin = self.metadata.lastLogin;
                    self.failedPasswordCount = self.metadata.failedPasswordCount;
                    self.email = self.metadata.emailAddress;
                    self.firstName = self.metadata.firstName;
                    self.lastName = self.metadata.lastName;
                    self.render();
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app.trigger("alert:error", {
                        message: "An unexpected error occured when trying to retrieve the users metadata. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                    });
                }
            });
        },
        onClickEdit: function(options){
                var passingInOptions = {
                'passwordData' : this.metadata,
                'layout': this.options.layout
                };
                var passwordMetadata = new UserConfig.PasswordMetadata(passingInOptions);
                app.trigger('alert:custom', {
                    view: passwordMetadata
                }); 
        },
        onClickSave: function(){
            var self = this;
            var firstName = $('#metadata-firstName').val();
            var lastName = $('#metadata-lastName').val();
            var email = $('#metadata-email').val();

            $.ajax({type: "POST", url: app.serviceUrlRoot + "/users/updateUser?userName=" + this.userName + "&firstName="  + firstName + "&lastName=" + lastName + "&email=" + email,  
                success: function(results){
                    self.getMetaData();
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app.trigger("alert:error", {
                        message: "An unexpected error occured when trying to update the user. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                    });
                }  
            });
        },
        checkEmail : function(){
            //validates email address that the email address follows formate: [letters]@[letters].[At least 2 letters]
            var emailReg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var email = $('#metadata-email').val();
            if(emailReg.test(email)){
                $('#metadata-email-error').text('');
                this.checkForChanges();
            }else{
                $('#metadata-save').hide();
                $('#metadata-email-error').text('Must be a valid email!');
            }
        },
        afterRender: function() {
            //self.metadata is undefined at the initial creation on the view
            $('#metadata-save').hide();
        },
        serialize: function() {
            return {
                "id": this.userName,
                "lastLogin": this.lastLogin,
                "passwordCount": this.failedPasswordCount,
                "email": this.email,
                "firstName": this.firstName,
                "lastName": this.lastName
            };
        }
    });

    UserConfig.PasswordMetadata = Backbone.Layout.extend({
        template: "hpiadmin/userconfig/passwordMetadata",
        events: { 
            'keyup #passwordMetadata-updatePassword' : 'update',
            'keyup #passwordMetadata-updatePasswordConfirm' : 'update',
            'click #passwordMetadata-save' : 'savePasswordChanges'
        },
        initialize: function(options) {
            this.options = options;
        },
         update: _.debounce(function(event){
            if($('#passwordMetadata-updatePassword').val() !== $('#passwordMetadata-updatePasswordConfirm').val()){
                $('#passwordMetadata-updatePassword-error').text("Update password and Confirm password need to match!");
                $('#passwordMetadata-updatePasswordConfirm-error').text("Update password and Confirm password need to match!");
                $('#passwordMetadata-save').attr("disabled", true);
            }else{
                $('#passwordMetadata-updatePassword-error').text("");
                $('#passwordMetadata-updatePasswordConfirm-error').text("");
                $('#passwordMetadata-save').attr("disabled", false);
            }
         }),
         savePasswordChanges: function(){
            var newPassword = $('#passwordMetadata-updatePassword').val();
            var self = this;
            $.ajax({type: "POST", url: app.serviceUrlRoot + "/users/updateUser?userName=" + this.options.passwordData.authorityId + "&password=" + newPassword ,  
                success: function(results){
                    //grabs the view and updates the meta data in UserConfig.UserMetadata
                    self.layout.getView('#users-metadata-outlet').getMetaData();
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app.trigger("alert:error", {
                        message: "An unexpected error occured when trying to update the user. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                    });
                }
            });
         }
    });

    return UserConfig;
}); 

