// Stageconfig module
define([
	// Application.
	"app",
	"knockout",
	"knockback",
	"modules/hpiadmin/hpiadmin",
	
	//modules
	"modules/common/alert/alert",
	"modules/hpiadmin/actionconfig/hpiactionconfig"
],

// Map dependencies from above array.
function(app, ko, kb, Hpiadmin, alert, ActionConfig) {
	"use strict";

	// Create a new module.
	var DetailViewConfig = app.module();

		// M O D E L S  &  C O L L E C T I O N S 

		DetailViewConfig.Relation = Backbone.Model.extend({
		});

		DetailViewConfig.RelationCollection = Backbone.Collection.extend({
			modeL: DetailViewConfig.Relation
		});

		/**
		* FIELD MODEL/COLLECTION
		**/
		DetailViewConfig.Field = Backbone.Model.extend({
			defaults: function() { 
				return {
					"ocName" : ""
				};
			}
		});

		DetailViewConfig.FieldCollection = Backbone.Collection.extend({
			model: DetailViewConfig.Field
		});

		/**
		* FIELDSET MODEL/COLLECTION
		**/
		DetailViewConfig.FieldSet = Backbone.Model.extend({
			defaults: function() { 
				return { 
					"title" : ""
				};
			},
			initialize: function(options){
				if(options && options.fields){
					this.set("fields", new DetailViewConfig.FieldCollection(options.fields));
				} else {
					this.set("fields", new DetailViewConfig.FieldCollection());
				}
			}
		});

		DetailViewConfig.FieldSetCollection = Backbone.Collection.extend({
			model: DetailViewConfig.FieldSet,
			defaults: function() { 
				return { 
					"name" : "",
					"relationName": "",
					"type": ""
				};
			}
		});

		/**
		* TYPE MODEL/COLLECTION 
		**/
		DetailViewConfig.Type = Backbone.Model.extend({
			defaults: function() { 
				return { 
					"objectType" : ""
				};
			},
			initialize: function(options){
				if(options && options.fieldsets){
					this.set("fieldsets", new DetailViewConfig.FieldSetCollection(options.fieldsets));
				} else {
					this.set("fieldsets", new DetailViewConfig.FieldSetCollection());
				}

				if(options && options.overviewAttrs){
					this.set("overviewAttrs", new DetailViewConfig.FieldSetCollection(options.overviewAttrs));
				} else {
					this.set("overviewAttrs", new DetailViewConfig.FieldSetCollection());
				}
			}
		});

		DetailViewConfig.TypeCollection = Backbone.Collection.extend({
			model: DetailViewConfig.Type    
		});

		DetailViewConfig.Model = Hpiadmin.Config.extend({
			type: "DetailViewConfig",
			defaults: function() { 
				return { 
					"type" : "DetailViewConfig",
					"name" : "default"
				};
			},
			parseResponse: function(response){
				if(this.id){
					//just want the id
					response = _.pick(response, 'id');
				} else if(response){
					if(response.types){
						this.set("types", new DetailViewConfig.TypeCollection(response.types));
						delete response.types;
					}
					if(response.actions){
						this.set("actions", new ActionConfig.Collection(response.actions));
						delete response.actions;
					}
					if(response.relations){
						this.set("relations", new DetailViewConfig.RelationCollection(response.relations));
						delete response.relations;
					}
				}

				return response;
			}
		});

		// V I E W S  &  V I E W  M O D E L S 

		DetailViewConfig.RelationViewModel = kb.ViewModel.extend({
			constructor: function(model) { 

				var self = this;

				kb.ViewModel.prototype.constructor.apply(this, arguments);

				self.name = kb.observable(model, "name");
				self.relationName = kb.observable(model, "relationName");
				self.type = kb.observable(model, "type");

				return this;

			}
		});

		DetailViewConfig.FieldViewModel = kb.ViewModel.extend({ 
			
			constructor: function(model) { 
				var self = this;

				kb.ViewModel.prototype.constructor.apply(this, arguments);

				self.ocName = kb.observable(model, "ocName");

				return this;
			}
		});

		/**
		*   FieldSetViewModel
		*   Sub-Viewmodel for each fieldset
		**/
		DetailViewConfig.FieldSetViewModel = kb.ViewModel.extend ({ 
			
			constructor: function(model, options) { 
				var self = this;

				kb.ViewModel.prototype.constructor.apply(this, arguments);

				self.title = kb.observable(model, "title");
				self.fields = kb.collectionObservable(model.get("fields"), {
					//view_model : DetailViewConfig.FieldViewModel
					factories: {
						"models" : DetailViewConfig.FieldViewModel
					}
				});

				self.afterMoveField = function(droppedItem) { 

				};

				return this;
			}

		});

		/**
		*   TypeViewModel 
		*   Contains a sub-viewmodel for each type
		**/
		DetailViewConfig.TypeViewModel = kb.ViewModel.extend({ 
			
			constructor: function(model) {

				var self = this;
				self.model = model;

				kb.ViewModel.prototype.constructor.apply(this, arguments);

				self.objectType = kb.observable(model, "objectType");
				self.fieldSets = kb.collectionObservable(model.get("fieldsets"), {
					//view_model: DetailViewConfig.FieldSetViewModel
					factories: {
						"models" : DetailViewConfig.FieldSetViewModel                       
					}
				});
				
				self.potentialAttributes = ko.observableArray();
				//grab our potential type names from the top level config, and use the config
				//service to get their full set of attributes
				app.context.configService.getAdminTypeConfig(self.objectType(), function(typeConfig){
					
					var attributes = kb.collectionObservable(typeConfig.get("attrs"), { 
						//view_model: DetailViewConfig.FieldViewModel 
						factories: { 
							"models" : DetailViewConfig.FieldViewModel
						}
					});

					self.potentialAttributes = attributes;
					
				});

				self.addNewFieldSet = function() { 
					var newFieldset = new DetailViewConfig.FieldSet();
					//model.get("fieldsets").add(newFieldset);
					self.fieldSets.push(new DetailViewConfig.FieldSetViewModel(newFieldset));
				};

				self.removeFormSet = function(formSet) { 
					self.fieldSets.remove(formSet);
				};

				self.overviewAttrs = kb.collectionObservable(model.get("overviewAttrs"), { 
					factories: {
						"models": DetailViewConfig.FieldViewModel
					}
				});

				return this;
			}

		});

		/**
		*   ViewModel
		*   Main Viewmodel that contains everything for this config
		**/
		DetailViewConfig.ViewModel = function(model) { 
			
			var self = this;
			self.model = model;

			self.id = kb.observable(model, "id");
			self.configName = kb.observable(model, "name");
			self.type = kb.observable(model, "type");
			self.types = kb.collectionObservable(model.get("types"), {
				//view_model : DetailViewConfig.TypeViewModel
				factories: {
					'models': DetailViewConfig.TypeViewModel
				}
			});
			
			/**
			*   Get the available object types based on the config name we've selected 
			**/
			self.selectedType = ko.observable(); // the selected type on the dropdown
			
			self.potentialTypes = ko.observableArray();
			self.getTypes = function(){ 
				var potentialTypes = [];

				// get our available types
				app.context.configService.getAdminOTC(function(model){
					//self.potentialTypes.removeAll();
					model.get("configs").each( function(type){
						potentialTypes.push({"label" : type.attributes.label,
											"ocName" : type.attributes.ocName});
					});

					self.potentialTypes(potentialTypes);
				});

			};

			/**
			*   Add a new type to be configured 
			**/
			self.showAddType = ko.observable();
			self.showAddTypeForm = function() { 
				// set up the list of available types
				self.getTypes();
				// show it
				self.showAddType(true);
			};
			
			/**
			*   Hide the add type UI
			**/
			self.cancelAddType = function() { 
				self.showAddType(false);
			};

			/**
			*   Add a new type to our collection
			**/
			self.addType = function() { 
				// create and add our new type
				var newType = new DetailViewConfig.Type({ objectType: self.selectedType().ocName });
				var viewModel = new DetailViewConfig.TypeViewModel(newType);
				//model.get("types").add(newType);
				self.types.push(viewModel);
			};

			/**
			*   Remove a particular type config
			**/
			self.removeType = function(type) {
				self.types.remove(type);
			};

			/**
			*   Saves the config
			**/
			self.saveConfig = function(val, event) { 
				event.preventDefault();
				// set the app config type
				//TODO - shouldn't need to do this anymore
				//app.context.configName(self.configName());
				self.model.save();
			};
			

			/******** RELATIONS **********/
			self.relations = kb.collectionObservable(model.get("relations"), {
				factories: { 
					"models" : DetailViewConfig.RelationViewModel
				}
			});

			self.addRelation = function() { 
				model.get("relations").add(new DetailViewConfig.Relation());
			};
			
			self.removeRelation = function(item) { 
				self.relations.remove(item);
			};
		};

		DetailViewConfig.Views.Layout = Backbone.Layout.extend({
			template: "hpiadmin/applicationconfig/detailviewconfig-mainlayout",

			initialize: function() { 
				this.viewModel = new DetailViewConfig.ViewModel(this.model);
				this.viewModel.name = ko.observable(this.model.get("name"));
				this.setView("#action-config-template-outlet", new ActionConfig.View({viewmodel: this.viewModel, model : this.model, showSingleActions: true }));

				// set the app config type
				//TODO - shouldn't need to do this anymore
				//app.context.configName(this.viewModel.configName());
			},

			afterRender: function() { 
				kb.applyBindings(this.viewModel, this.$el[0]);
			}
		});

	// Return the module for AMD compliance.
	return DetailViewConfig;

});
