// ApplicationConfig
define([
        // Application.
        "app",
        "knockout",
        "knockback",
        "spectrum",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/actionconfig/hpiactionconfig",
        "handlebars",

        //modules
        "modules/common/tossacross",
        "modules/hpiadmin/common/iosswitch",
        "modules/hpiadmin/common/imageuploader",
        "modules/common/alert/alert",
        "moment",
        "momentTimezone",
        /*"jqueryMomentTimezones",*/
        "datetimePicker"
    ],

    // Map dependencies from above array.
    function(app, ko, kb, Spectrum, Hpiadmin, ActionConfig, Handlebars, TossAcross, iOSSwitch, ImageUploader) {
        "use strict";

        var appConfigVent = _.extend({}, Backbone.Events);

        // Create a new module.
        var AppConfig = app.module();

        AppConfig.SimpleGroup = Backbone.Model.extend({
            name: ""
        });

        AppConfig.SimpleGroupCollection = Backbone.Collection.extend({
            model: AppConfig.SimpleGroup
        });

        // This is based on an hpiadmin config.
        AppConfig.Model = Hpiadmin.Config.extend({
            type: "ApplicationConfig",
            defaults: {
                type: "ApplicationConfig",
                adminGroups: new AppConfig.SimpleGroupCollection(),
                defaultConfig: "default",
                enableHeaderNotifications: false,
                hideFileExtensions: "false",
                shouldSterilizeFilenames: "false",
                regexToSterilizeFilenamesWith: "[\\\\#\\\\:\\\\/]",
                sterilizeReplacementString: "",
                defaultPath: "/dashboard",
                enableLogoLink: "false",
                sessionTimeout: 120,
                dateFormat: "usaStandard",
                timeFormat: "usaStandard",
                headerCss: "",
                navigationBarCssTop: "",
                navigationBarCssBottom: "",
                linkCss: "",
                buttonCss: "",
                primaryBtnTextColor: "",
                secondaryBtnColor: "",
                secondaryBtnTextColor: "",
                hoverTextCss: "",
                selectedCss: "",
                navigationBarTextCss: "",
                searchResultsNumDefault: "25",
                enabledHeaderLinks: [],
                customHeaders: [],
                headerIconsEnabled: "false",
				enableAlfrescCmisQuery : false,
                appId: "default",
                headerIcons: {
                    "Search": "search",
                    "Collections": "duplicate",
                    "Dashboard": "home"
                }
            },
            initialize: function(options) {
                if (options && options.actions) {
                    this.set("actions", new ActionConfig.Collection(options.actions));
                } else {
                    this.set("actions", new ActionConfig.Collection());
                }

                if (options && options.adminGroups) {
                    this.set("adminGroups", new AppConfig.SimpleGroupCollection(options.adminGroups));
                } else {
                    this.set("adminGroups", new AppConfig.SimpleGroupCollection());
                }
            },
            parseResponse: function(response) {
                if (this.id) {
                    //just want the id
                    response = _.pick(response, 'id');
                } else if (response) {
                    if (response.actions) {
                        this.set("actions", new ActionConfig.Collection(response.actions));
                        delete response.actions;
                    }
                    if (response.adminGroups) {
                        this.set("adminGroups", new AppConfig.SimpleGroupCollection(response.adminGroups));
                        delete response.adminGroups;
                    }
                }

                return response;
            }
        });


        AppConfig.ViewModel = kb.ViewModel.extend({
            constructor: function(model) {
                var self = this;

                //use super constructor to create id, name observables
                kb.ViewModel.prototype.constructor.call(this, model, {
                    requires: ["id", "name"]
                });
                this.name("default");
                this.defaultConfigName = kb.observable(model, "defaultConfig");
                this.newGroup = ko.observable();
                this.selectedGroup = ko.observable();
                //this.enableHeaderNotifications = kb.observable(model, "enableHeaderNotifications");
                this.enabled = ko.observable();
                this.headerIconsEnabled = kb.observable(model, 'headerIconsEnabled');

                this.dashboardHeaderIcon = ko.observable();
                this.collectionsHeaderIcon = ko.observable();
                this.searchHeaderIcon = ko.observable();

                if (model.get("enableHeaderNotifications")) { this.enabled("true"); } else { this.enabled("false"); }
                this.enabled.subscribe(function(boolString) {
                    if (boolString === "true") {
                        model.set("enableHeaderNotifications", true);
                    } else {
                        model.set("enableHeaderNotifications", false);
                    }
                });



                // whether or not to hide file extensions from the document names that are being uploaded
                this.hideFileExtensions = kb.observable(model, "hideFileExtensions");

                // sterilizing filenames configs
                this.shouldSterilizeFilenames = kb.observable(model, "shouldSterilizeFilenames");
                this.regexToSterilizeFilenamesWith = kb.observable(model, "regexToSterilizeFilenamesWith");
                this.sterilizeReplacementString = kb.observable(model, "sterilizeReplacementString");

                this.enableAlfrescCmisQuery = kb.observable(model, "enableAlfrescCmisQuery");	

                this.headerCss = kb.observable(model, "headerCss");
                this.navigationBarCssTop = kb.observable(model, "navigationBarCssTop");
                this.navigationBarCssBottom = kb.observable(model, "navigationBarCssBottom");
                this.linkCss = kb.observable(model, "linkCss");
                this.buttonCss = kb.observable(model, "buttonCss");
                this.primaryBtnTextColor = kb.observable(model, "primaryBtnTextColor");
                this.secondaryBtnColor = kb.observable(model, "secondaryBtnColor");
                this.secondaryBtnTextColor = kb.observable(model, "secondaryBtnTextColor");

                this.hoverTextCss = kb.observable(model, "hoverTextCss");
                this.selectedCss = kb.observable(model, "selectedCss");
                this.navigationBarTextCss = kb.observable(model, "navigationBarTextCss");

                this.defaultPath = kb.observable(model, "defaultPath");

                this.enableLogoLink = kb.observable(model, "enableLogoLink");

                this.sessionTimeout = kb.observable(model, "sessionTimeout");

                //create custom header model
                self.customHeaders = ko.observableArray();
                if (model.get("customHeaders")) {
                    self.customHeaders(model.get("customHeaders"));
                }

                // Default header link options
                self.defaultHeaderLinks = ["Search", "Collections", "Dashboard"];
                //for our ease,
                //we create an array of label to observable-and-ID-of-preview-area
                //so that we can monitor the default link observables and generate previews
                //in just one go.
                self.headerIconObservables = {
                    "Search": {
                        "observable": self.searchHeaderIcon,
                        "previewArea": "searchIconPreview"
                    },
                    "Collections": {
                        "observable": self.collectionsHeaderIcon,
                        "previewArea": "collectionsIconPreview"
                    },
                    "Dashboard": {
                        "observable": self.dashboardHeaderIcon,
                        "previewArea": "dashboardIconPreview"
                    }
                };


                self.headerLinkOptionsCollection = new Backbone.Collection();
                self.enabledHeaderLinksCollection = new Backbone.Collection();

                _.each(model.get('enabledHeaderLinks'), function(link) {
                    self.enabledHeaderLinksCollection.add({
                        'linkName': link
                    });
                }, this);

                _.each(self.defaultHeaderLinks, function(link) {
                    // Only add the header links to the options if they are not already enabled.
                    var found = self.enabledHeaderLinksCollection.findWhere({ 'linkName': link });

                    if (found === undefined) {
                        self.headerLinkOptionsCollection.add({
                            'linkName': link
                        });
                    }
                }, this);

                this.linksTossAcross = new TossAcross.Layout({
                    srcCollection: {
                        title: window.localize("applicationConfig.appConfigMainLayout.headerLinkOptions"),
                        filter: false,
                        labelAttr: 'linkName',
                        collection: self.headerLinkOptionsCollection
                    },
                    targetCollections: [{
                        title: window.localize("applicationConfig.appConfigMainLayout.enabledHeaderLinks"),
                        labelAttr: 'linkName',
                        collection: self.enabledHeaderLinksCollection
                    }]
                });

                appConfigVent.trigger("tossAcrossReady", ".toss-across-headerlinks", this.linksTossAcross);

                app.listenTo(self.enabledHeaderLinksCollection, 'add remove reset', function() {
                    model.set("enabledHeaderLinks", self.enabledHeaderLinksCollection.pluck('linkName'));
                }, this);


                this.currentHeaderLink = ko.observable();
                this.timezoneFormat = kb.observable(model, "timezoneFormat");
                this.dateFormat = kb.observable(model, "dateFormat");
                this.timeFormat = kb.observable(model, "timeFormat");

                this.searchResultsNumDefault = kb.observable(model, "searchResultsNumDefault");
                //this.adminUsers = ko.observableArray();

                this.secureObjectTypeFiltering = kb.observable(model, "secureObjectTypeFiltering");
                if (this.secureObjectTypeFiltering() === null || _.isUndefined(this.secureObjectTypeFiltering)) {
                    this.secureObjectTypeFiltering(false);
                }

                this.deniedUserGroupsCollection = new Backbone.Collection();
                this.allowedUserGroupsCollection = new Backbone.Collection();

                this.allowedGroupsForCustomLinks = ko.observableArray([]);
                this.deniedGroupsForCustomLinks = ko.observableArray([]);

                //When the allowedGroupsForCustomLinks is changed
                this.allowedGroupsForCustomLinks.subscribe(function(allowedGroup) {
                    var myLinks = model.get("customHeaders");

                    _.each(myLinks, function(headerLink) {
                        if (headerLink.url === self.currentHeaderLink()) {
                            headerLink.allowedGroups = allowedGroup;
                        }
                    });
                });
                //iterate through all of the header icon observables,
                //add a subscription so that when they're updated, a new icon preview
                //is created so the user can see the icon they've typed in.
                _.each(self.headerIconObservables, function(iconObservable, idx) {
                    var previewArea = iconObservable.previewArea;
                    iconObservable.observable.subscribe(function(newVal) {
                        if (!previewArea) {
                            return; //no need to proceed if no preview area defined
                        }
                        $("#" + previewArea).removeClass();
                        $("#" + previewArea).addClass("glyphicons glyphicons-" + newVal);
                        var headerIcons = model.get("headerIcons");
                        headerIcons[idx] = newVal;
                        model.set("headerIcons", headerIcons);
                    });

                });

                app.listenTo(self.allowedUserGroupsCollection, 'add remove reset', function() {
                    var allowedGroups = self.allowedUserGroupsCollection;
                    var adminGroups = [];
                    allowedGroups.each(function(g) {
                        var group = new AppConfig.SimpleGroup({ name: g.get('name') });
                        //there is an issue between knockback and bb-relational where
                        group.attributes.id = group.get("cid");
                        adminGroups.push(group);
                    });
                    //need to be using collections, since this is what is expected for
                    //the value adminGroups on the model
                    var adminGroupCollection = new AppConfig.SimpleGroupCollection(adminGroups);
                    model.set("adminGroups", adminGroupCollection);
                }, this);

                self.initialize = function() {
                    var requestGroupObject = {
                        "authorityType": "group",
                        "criterion": {
                            "attrToSearch": "displayName",
                            "matchType": "startsWith",
                            "searchTerm": "*"
                        }
                    };

                    var opts = {
                        url: app.serviceUrlRoot + "/authorities/search",
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify(requestGroupObject),
                        success: function(groups) {
                            var adminGroups = [];
                            _.each(groups, function(group) {
                                var exists = false;
                                _.each(model.get("adminGroups").models, function(ag) {
                                    if (ag.get("name") === group.authorityId) {
                                        adminGroups.push(group.authorityId);
                                        exists = true;
                                    }
                                });
                                if (!exists) {
                                    //difference
                                    self.deniedUserGroupsCollection.add({
                                        'name': group.authorityId
                                    });
                                }

                                //initially populate denied group will all groups
                                self.deniedGroupsForCustomLinks.push(group.authorityId);

                                self.allGroupsHolder = [];
                                self.allGroupsHolder = self.deniedGroupsForCustomLinks();
                            });

                            var adminModels = model.get("adminGroups");
                            adminModels.each(function(aModel) {
                                self.allowedUserGroupsCollection.add({
                                    'name': aModel.get('name')
                                });
                            });

                            self.typesTossAcross = new TossAcross.Layout({
                                srcCollection: {
                                    title: window.localize("applicationConfig.appConfigMainLayout.deniedGroups"),
                                    filter: true,
                                    labelAttr: 'name',
                                    collection: self.deniedUserGroupsCollection
                                },
                                targetCollections: [{
                                    title: window.localize("applicationConfig.appConfigMainLayout.allowedGroups"),
                                    labelAttr: 'name',
                                    collection: self.allowedUserGroupsCollection
                                }]
                            });

                            appConfigVent.trigger("tossAcrossReady", ".toss-across-groups", self.typesTossAcross);
                        },
                        error: function() {
                            app.log.error("User groups could not be loaded");
                        }
                    };
                    $.ajax(opts);
                };

                this.addGroup = function() {
                    var group = new AppConfig.SimpleGroup({ name: this.newGroup() });
                    //there is an issue between knockback and bb-relational where
                    group.attributes.id = group.attributes.cid;
                    model.get("adminGroups").push(group);
                    this.newGroup("");
                };
                this.removeGroup = function() {
                    //var m = model.get("adminUsers").where({name: this.selectedUser().})[0];
                    model.get("adminGroups").remove(this.selectedGroup().model());
                };


                //view related model properties
                this.onCreateConfig = function() {
                    model.save({}, {
                        success: function() {
                            app.trigger("modelSaveOrDestroy");
                            Backbone.history.navigate("admin/ApplicationConfig", { replace: true, trigger: true });
                            app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", ".config-container");
                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: "Error Saving Config",
                                message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
                            });
                        }
                    });
                };

                return this;
            }


        });

        // Default View.
        AppConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/applicationconfig/appconfig-mainlayout",
            manage: true,
            events: {
                "click #customHeader-btn-add": "addLink",
                "click .customHeader-tbody .glyphicon-edit": "showHeaderTossAcross",
                "click .customHeader-tbody .glyphicon-remove": "deleteLink",
                "keyup #customHeader-input-label": "updateLabel",
                "keyup #customHeader-input-icon": "updateIcon",
                "keyup #customHeader-input-url": "updateUrl",
                "keyup .customHeader-iconInput-value": "updateIconPreview",
                "updateCustomHeaderOrder": "updateCustomHeaderOrder",
                "click .input-toggleHeaderIcons": "toggleDefaultHeaderIcons",
                "click #restoreDefaultCss": "restoreDefaultCss"
            },

            initialize: function() {
                this.viewModel = window.acVm = new AppConfig.ViewModel(this.model, this);
                this.viewModel.initialize();
                this.setChildViews();

                this.listenTo(appConfigVent, "tossAcrossReady", function(el, tossAcrossView) {
                    this.setView(el, tossAcrossView).render();
                }, this);
            },
            setChildViews: function() {
                //put the action template onto the page and augment viewmodel and indicate that application config's action are in header mode
                this.actionConfigTemplateView = new ActionConfig.View({ viewmodel: this.viewModel, model: this.model, showGroupActions: false, isHeaderMode: true });

                //add in oc settings
                this.ocSettingsView = new AppConfig.OCSettingsView();

                this.enableFilterObjectTypesByUser = new iOSSwitch.View({
                    model: this.viewModel.model(),
                    configModelKey: "filterObjectTypesByUser",
                    switchTitle: window.localize("applicationConfig.appConfigMainLayout.filterObjectTypesByUser"),
                    configDescription: window.localize("applicationConfig.appConfigMainLayout.filterObjectTypesByUser.info"),
                    onLabel: window.localize("generic.yes"),
                    offLabel: window.localize("generic.no"),
                    titleIsHeaderTag: true
                });

                this.setViews({
                    "#action-config-template-outlet": this.actionConfigTemplateView,
                    ".ocsettings": this.ocSettingsView,
                    "#enableFilterObjectTypesByUser": this.enableFilterObjectTypesByUser,
                    "#logoUpload": new ImageUploader.View({
                        imageName: "login-logo.png",
                        title: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.logo.title"),
                        tooltip: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.logo.tooltip"),
                        security: {
                            allowedMimetypes: ["image/png"]
                        }
                    }),
                    '#headerLogoUpload': new ImageUploader.View({
                        imageName: "header-logo.png",
                        title: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.headerLogo.title"),
                        tooltip: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.headerLogo.tooltip"),
                        security: {
                            allowedMimetypes: ["image/png"]
                        }
                    }),
                    '#siteIconUpload': new ImageUploader.View({
                        imageName: "favicon.ico",
                        title: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.siteIcon.title"),
                        tooltip: window.localize("applicationConfig.appConfigMainLayout.logoCustomization.siteIcon.tooltip"),
                        security: {
                            allowedMimetypes: ["image/x-icon"],
                            dimensionSizes: {
                                minWidth: 512,
                                minHeight: 512,
                                squareImage: true
                            }
                        }
                    }),
                    '#loginLogoutBackgroundImageUpload': new ImageUploader.View({
                        imageName: "login-logout-background.png",
                        title: window.localize("applicationConfig.appConfigMainLayout.BackgroundImageCustomization.loginLogout.title"),
                        tooltip: window.localize("applicationConfig.appConfigMainLayout.BackgroundImageCustomization.loginLogout.tooltip"),
                        security: {
                            allowedMimetypes: ["image/png"]
                        }
                    })
                });
            },
            beforeRender: function() {
                if (this.viewModel.linksTossAcross) {
                    this.setView(".toss-across-headerlinks", this.viewModel.linksTossAcross);
                }
                if (this.viewModel.typesTossAcross) {
                    this.setView(".toss-across-groups", this.viewModel.typesTossAcross);
                }
            },
            afterRender: function() {
                var self = this;
                this.rendered = true;

                // Not the best way to do this, but it will initialize this view automatically if the model is configured to show this.
                this.toggleDefaultHeaderIcons();

                //Instantiate popovers. These are used in place of tooltips because of the conflict between
                //jQueryUI and Bootstrap
                $("#addGroups").popover({
                    placement: 'left',
                    trigger: 'hover',
                    title: 'Group List',
                    content: 'All of these Groups have access to HPI\'s Admin tool',
                    delay: { show: 1000 }
                });

                $("#userToAdd").popover({
                    placement: 'left',
                    trigger: 'hover',
                    title: 'Group',
                    content: 'Enter the name of a group you would like to have access to HPI\'s Admin tool',
                    delay: { show: 1000 }
                });

			this.$("#headerCss").spectrum({color: self.viewModel.headerCss(), change: function(color){
                        self.viewModel.headerCss(color.toHexString());
			}});
			this.$("#navigationBarCssTop").spectrum({color: self.viewModel.navigationBarCssTop(), change: function(color){
                        self.viewModel.navigationBarCssTop(color.toHexString());
			}});
			this.$("#navigationBarCssBottom").spectrum({color: self.viewModel.navigationBarCssBottom(), change: function(color){
                        self.viewModel.navigationBarCssBottom(color.toHexString());
			}});
			this.$("#linkCss").spectrum({color: self.viewModel.linkCss(), change: function(color){
                        self.viewModel.linkCss(color.toHexString());
            }});

			this.$("#buttonCss").spectrum({color: self.viewModel.buttonCss(), change: function(color){
                        self.viewModel.buttonCss(color.toHexString());
            }});

            this.$("#primaryBtnTextColor").spectrum({color: self.viewModel.primaryBtnTextColor(), change: function(color){
                self.viewModel.primaryBtnTextColor(color.toHexString());
            }});
            
            this.$("#secondaryBtnColor").spectrum({color: self.viewModel.secondaryBtnColor(), change: function(color){
                self.viewModel.secondaryBtnColor(color.toHexString());
            }});

            this.$("#secondaryBtnTextColor").spectrum({color: self.viewModel.secondaryBtnTextColor(), change: function(color){
                self.viewModel.secondaryBtnTextColor(color.toHexString());
            }});

			this.$("#hoverTextCss").spectrum({color: self.viewModel.hoverTextCss(), change: function(color){
                        self.viewModel.hoverTextCss(color.toHexString());
			}});
			this.$("#selectedCss").spectrum({color: self.viewModel.selectedCss(), change: function(color){
                        self.viewModel.selectedCss(color.toHexString());
			}});
			this.$("#navigationBarTextCss").spectrum({color: self.viewModel.navigationBarTextCss(), change: function(color){
                        self.viewModel.navigationBarTextCss(color.toHexString());
			}});			
                //Informational popover that instructs the user on how to use glyphicons
                var glyphPopover = {
                    placement: 'top',
                    trigger: 'focus',
                    title: 'Glyphicons',
                    html: true,
                    content: "Some common glyphicons include 'edit', 'search', and 'list-alt'. For a full list, click <a href='http://glyphicons.com' target='_blank'>on this link</a>. <br/><br/> Type a new glyphicon name and hit 'Enter' to update its preview.",
                    delay: { show: 500 }
                };
                $(".headerIconConfigInput").popover(glyphPopover);

                // This makes sure that both tbody's that have this class are rendered before we attach the sortable class
                // We don't use this.$() selector since a separate views add the tbody's
                // also: make sure we're only applying the sortable to the decendants of this table (or it breaks)
                this.sortableElements = $("#customHeaders-table .sortable-attributes");
                if (this.sortableElements.length) {
                    this.sortableElements.sortable({
                        connectWith: "#customHeaders-table .sortable-attributes",
                        revert: true,
                        stop: function(event, ui) {
                            ui.item.trigger("updateCustomHeaderOrder", ui.item.index());
                            self.sortableElements.find(".dropzone").remove();
                        },
                        start: function() {
                            self.sortableElements.append("<tr class='dropzone' style='border:2px dashed #f2dede; border-radius:6px'><td colspan='9' style='text-align:center'>Drop Here</td></tr>");
                        }
                    }).disableSelection();
                }

                kb.applyBindings(this.viewModel, this.$el[0]);
                $(".customHeader-iconInput-value").popover(glyphPopover);
            },
            restoreDefaultCss: function() {
                var self = this;
                self.$("#navigationBarCssTop").spectrum("set", "#ffffff");
                self.viewModel.navigationBarCssTop("#ffffff");

                self.$("#navigationBarCssBottom").spectrum("set", "#ffffff");
                self.viewModel.navigationBarCssBottom("#ffffff");

                self.$("#headerCss").spectrum("set", "#464646");
                self.viewModel.headerCss("#464646");

                self.$("#linkCss").spectrum("set", "#0055b8");
                self.viewModel.linkCss("#0055b8");

                self.$("#buttonCss").spectrum("set", "#00754a");
                self.viewModel.buttonCss("#00754a");

                self.$("#primaryBtnTextColor").spectrum("set", "#f5fffa");
                self.viewModel.primaryBtnTextColor("#f5fffa");

                self.$("#secondaryBtnColor").spectrum("set", "#dee9f6");
                self.viewModel.secondaryBtnColor("#dee9f6");

                self.$("#secondaryBtnTextColor").spectrum("set", "#464646");
                self.viewModel.secondaryBtnTextColor("#464646");

                self.$("#hoverTextCss").spectrum("set", "#464646");
                self.viewModel.hoverTextCss("#464646");

                self.$("#selectedCss").spectrum("set", "#ffffff");
                self.viewModel.selectedCss("#ffffff");

                self.$("#navigationBarTextCss").spectrum("set", "#359b34");
                self.viewModel.navigationBarTextCss("#359b34");
            },
            updateLabel: function(event) {
                this.label = event.target.value;
                this.checkValidation();
            },
            updateUrl: function(event) {
                this.url = event.target.value;
                this.checkValidation();
            },
            updateIcon: function(event) {
                this.icon = event.target.value;
            },
            checkValidation: function() {
                // Make sure there are values for label and url to activate the button to create a new customHeader link.
                if (!this.label || !this.url || this.label.length === 0 || this.url.length === 0) {
                    this.$('#customHeader-btn-add').attr('disabled', 'disabled');
                } else {
                    this.$('#customHeader-btn-add').removeAttr('disabled');
                }
            },
            addLink: function() {
                // Create a temporary JSON object for the new custom header link.
                var newHeader = {
                    label: Handlebars.Utils.escapeExpression(this.label),
                    url: Handlebars.Utils.escapeExpression(this.url),
                    icon: Handlebars.Utils.escapeExpression(this.icon),
                    iconPreview: this.generateIconPreview(this.icon),
                    newWindow: false,
                    allowedGroups: []
                };

                // Grab the custom headers already in the model, if they don't exist create a blank array to initialize the custom headers.
                var tempHeaders = this.model.get('customHeaders');
                if (!tempHeaders) {
                    tempHeaders = [];
                }

                // Clear out the display variables after a link has been created.
                this.$('#customHeader-input-label').val('');
                this.$('#customHeader-input-url').val('');
                this.$('#customHeader-input-icon').val('');
                this.$('#customHeader-btn-add').attr('disabled', 'disabled');

                // Add the new header to the existing array of headers, and set all of these onto the model.
                tempHeaders.push(newHeader);
                this.model.set('customHeaders', tempHeaders);
                this.viewModel.customHeaders(tempHeaders);
            },

            /**
            	This function does the actual work of adding the icon to the model.
            */
            generateIconPreview: function(icon) {
                return "glyphicons glyphicons-" + icon;
            },

            deleteLink: function(event) {
                var self = this;

                // Trigger an alert so that the user confirms the intent of removing the targeted custom header.
                var eventValue = event.target.value;
                app.trigger("alert:confirmation", {
                    header: "Remove Custom Header Option",
                    message: "You are about to remove this header. Do you wish to continue?",
                    confirm: function() {
                        self.confirmDeleteLink(eventValue);
                    }
                });
            },
            confirmDeleteLink: function(selectedHeader) {
                // Get the headers currently stored in the model.
                var headers = this.model.get('customHeaders');

                // Find the header that needs to be deleted from the array in the model.
                var headerToDelete = _.find(headers, function(header) {
                    return header.url === selectedHeader;
                });

                // Get the current headers in this model to find where the header to be deleted is located.
                var rowIndex = _.indexOf(headers, headerToDelete);

                // Remove the selected header from the index we found above and set the resulting header array to the model again.
                headers.splice(rowIndex, 1);
                this.model.set('customHeaders', headers);
                this.viewModel.customHeaders(headers);
            },

            showHeaderTossAcross: function(event) {
                var self = this;
                var eventValue = event.currentTarget.value;

                // Set the variable currentHeaderLink to be null if the value of currentHeaderLink equals that of the triggered event.
                if (this.viewModel.currentHeaderLink() === eventValue) {
                    this.viewModel.currentHeaderLink('');
                    // Otherwise, we are either opening a new toss accross or changing to another custom header, so set the eventValue on that variable.
                } else {
                    this.viewModel.currentHeaderLink(eventValue);
                }
                // Get the current headers from the model.
                var headers = this.model.get('customHeaders');

                //Fill denied group array if not already in the array
                _.each(headers, function(customLink) {
                    //Find corresponding link to one we are currently looking at
                    if (customLink.url === eventValue) {
                        //Fill Allowed Group
                        if (!customLink.allowedGroups) {
                            //if we dont have any denied groups, everything needs to default into the allowed
                            self.viewModel.deniedGroupsForCustomLinks(self.viewModel.allGroupsHolder);
                        } else {
                            //we do have denied groups, make our denied ko observable equal to the denied groups array
                            self.viewModel.allowedGroupsForCustomLinks(customLink.allowedGroups);
                            //the allowed groups are now the full group list minus thes denied groups
                            self.viewModel.deniedGroupsForCustomLinks(_.difference(self.viewModel.allGroupsHolder, customLink.allowedGroups));
                        }
                    }
                });
            },

            updateCustomHeaderOrder: function(event, addIndex) {
                // Get the current headers we have in the model.
                var headers = this.model.get('customHeaders');

                // Get the header that was moved to a new location.
                var changedHeader = event.target.value;
                // Find the header that needs to be deleted from the array in the model.
                var headerToMove = _.find(headers, function(header) {
                    return header.url === changedHeader;
                });

                // Get the current headers in this model to find where the header to be deleted is located.
                var removeIndex = _.indexOf(headers, headerToMove);

                // Change the order of the selectedHeader in the array.
                headers.splice(removeIndex, 1);
                headers.splice(addIndex, 0, headerToMove);

                // Update the model and viewModel with the newly re-ordered headers.
                this.model.set('customHeaders', headers);
                this.viewModel.customHeaders(headers);
            },

            updateIconPreview: function(event) {
                var headers = this.model.get('customHeaders');

                // Get the value (url) of the header icon we must modify, and the current array of headers
                var modifiedIcon = event.target.name.split('-')[1]; //Getting the url from icon-{url}
                var modifiedIconHeader = _.find(headers, function(header) {
                    return header.url === modifiedIcon;
                });
                var modifyIndex = _.indexOf(headers, modifiedIconHeader);

                // Save the current value of the glyphicon to remove its class and add the new one to its preview
                var iconPreviewsArray = $('.customHeader-iconPreview');
                var iconPreviewToModify = _.find(iconPreviewsArray, function(iconPrev) {
                    return iconPrev.name === 'iconPreview-' + headers[modifyIndex].url;
                });
                $(iconPreviewToModify).removeClass(headers[modifyIndex].iconPreview.split(' ')[1]); // Remove the glyphicons-{iconName} class
                $(iconPreviewToModify).addClass('glyphicons-' + modifiedIconHeader.icon); // Add the glyphicons-{iconName} class

                // Generate a new icon preview for this header with the new icon that was provided to us.
                headers[modifyIndex].iconPreview = this.generateIconPreview(modifiedIconHeader.icon);

                // Save our model with the new header modified icon.
                this.model.set('customHeaders', headers);
                this.viewModel.customHeaders(headers);
            },

            toggleDefaultHeaderIcons: function() {
                var viewModel = this.viewModel;
                var model = this.model;

                if (viewModel.headerIconsEnabled() === 'true') {
                    $(".hiddenIconConfig").show("fast");

                    // Update the default headerlinks to show the links that we have currently stored in the model
                    _.each(viewModel.defaultHeaderLinks, function(link) {
                        var observable = viewModel.headerIconObservables[link].observable;
                        var val = model.get("headerIcons")[link];
                        observable(val);
                    });
                } else if (viewModel.headerIconsEnabled() === 'false') {
                    $(".hiddenIconConfig").hide("fast");
                }
            }
        });

        //OC Settings - updating Config Path and Data Dictionary
        AppConfig.OCSettingsView = Backbone.Layout.extend({
            template: "hpiadmin/ocsettingsmodal",

            events: {
                "click #dataDictionaryBtn": "updateDataDictionary"
            },
            initialize: function() {
            },
            serialize: function() {
                //updates variable configPath with the current config path
                return {
                    "appId": app.appId
                };
            },
            updateDataDictionary: function() {
                //Updates the data dictionary
                $.ajax({
                    url: app.serviceUrlRoot + "/dictionary/update",
                    type: "GET",
                    success: function() {
                        app.trigger("alert:changeNotification", "alert-success",
                            "Your Data Dictionary has successfully been updated!",
                            "#dataDictionarySuccessMsg");
                    }
                });
            }

        });

        // Return the module for AMD compliance.
        return AppConfig;
    });