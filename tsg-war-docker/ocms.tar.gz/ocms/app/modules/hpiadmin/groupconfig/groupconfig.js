define([
    "app",
    'oc',
    "slickgridbase",
    "modules/hpiadmin/hpiadmin-switcher",
    "modules/hpiadmin/hpiadmin",
        "modules/common/tossacross"
],

function(app, OC, SlickGridBase, Switcher, Hpiadmin, TossAcross) {

    var GroupConfig = app.module();
    GroupConfig.Model = Hpiadmin.Config.extend({
        type: "GroupConfig",
        defaults: {
            type: "GroupConfig"
        }
    });

    GroupConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/groupconfig",
        className: "groupConfig",
        initialize: function(options) {
            var self = this;
            this.groupsView = new GroupConfig.Groups();
            this.setView('#groups-outlet', this.groupsView);
         
            //Calls addGroup endpoint
            this.listenTo(app, "addGroup", function(groupToAdd){
                $.ajax({type: "POST", url: app.serviceUrlRoot + "/users/createGroup?groupName=" + groupToAdd, 
                    success: function(results){
                        self.groupsView.populateGroups();
                         app.trigger("alert:close");
                    },
                    error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to add the group. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    }    
                });
            });
            //Calls removeGroup endpoint 
            this.listenTo(this.groupsView, "onClickRemoveConfirmation", function(groupToRemove){
                self.groupToRemove = groupToRemove;
                $.ajax({type: "POST", url: app.serviceUrlRoot + "/users/deleteGroup?groupName=" + groupToRemove, 

                    success: function(results){
                        if(self.getView('#users-outlet') !== undefined){
                            if(self.groupToRemove == self.getView('#users-outlet').groupName){
                                self.removeView('#users-outlet'); 
                            }
                        }
                        self.groupsView.populateGroups(); 
                    },
                    error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to remove the group. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    }
                });
            }); 
            //Passes groupName to User's outlet to display Users for selected Group
            this.listenTo(this.groupsView, "group-selected", function(groupName){
                this.setView('#users-outlet', new GroupConfig.Users({"groupName": groupName}));
            });    
            //Refreshes and closes addUsers Modal   
            this.listenTo(app, "addUsers", function(groupName){
                this.setView('#users-outlet', new GroupConfig.Users({"groupName": groupName}));
                app.trigger("alert:close");
            });  
            this.listenTo(app, "removeUsers", function(groupName){
                this.setView('#users-outlet', new GroupConfig.Users({"groupName": groupName}));
                app.trigger("alert:close");

            });          
    }});


    GroupConfig.Users =  Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/users", 
        events: {
            'keyup .users-filter': 'filterUsers',
            'click #add-users-button': 'onClickAddUsers',
            'click #remove-users-button': 'onClickRemoveUsers'
        },
        initialize: function(options) {
            this.options = options;
            this.groupName = this.options.groupName;
            this.populateUsers(this.groupName, "");
            this.gridData = [];
            this.groups =[];
            this.usersInGroup = new Backbone.Collection();
        },
        populateUsers: function(groupName, searchString)
        {
            var self = this;
            var requestObj = {
                "authorityType": "group",
                "childOfAuthority": groupName
            };
            $.ajax(
            {
                url: app.serviceUrlRoot + "/authorities/search", 
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                success: function (results) {
                    var gridItems = [];
                    self.usersInGroup = results;
                    _.each(results, function(result) {
                        gridItems.push({
                            displayName: result.displayName,
                            id: result.authorityId,
                            email: result.emailAddress
                        });
                    });
                    self.userSort(gridItems);
                    self.gridData = gridItems;
                    self.render();    
                },
                global : false
            });
        }, 

        //For searching users on keyup function
        filterUsers: _.debounce(function(event)
        {
            var self = this;
            window.SlickBase.GlobalEditorLock.cancelCurrentEdit();
            this.searchString = $(event.target).val().toLowerCase();
                self.dataView.setFilterArgs({
                    searchString: this.searchString
                });
            //Refresh dataview to allow change in filter take affect
            self.dataView.refresh();
        }, 400),
        
        myFilter: function (item, args) {
            if (args.searchString !== "" && item.displayName.toLowerCase().indexOf(args.searchString) == -1) {
                return false;
            }
            return true;
        },
  
        onClickAddUsers: function(event) {
            var addGroup = new GroupConfig.AddUsersView({
                "groupName": this.groupName,
                "existingUsers": this.gridData,
                "dataView": this.dataView
            });

            app.trigger('alert:custom', {
                view: addGroup,
                width: 900
            });
        },
        onClickRemoveUsers: function(event) {
            var self = this;
            var selectedRows = this.grid.getSelectedRows();
            var grid = this.grid;
            this.selectedUsers = [];
            this.selectedUsersNames= [];
            _.each(selectedRows, function(userIndex) {
                var user = self.grid.getData().getItemByIdx(userIndex);
                self.selectedUsers.push(user.id);
                self.selectedUsersNames.push(user.displayName);
            });
            var removeUser = new GroupConfig.RemoveUsersView(self.selectedUsersNames, self.groupName, self.selectedUsers, grid);
            app.trigger('alert:custom', {
                view: removeUser,
                width: 900,
                height: 600
            });
        },
        //Sorts users on intial selection of Group
        userSort: function(gridItems) {
            gridItems.sort(function (dataRow1, dataRow2) {
                //sets to ABC Order on Last Name of entered displayName
                if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) < dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                    return -1; }
                else if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) > dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                    return 1;
                }
                else{
                    return 0;
                }
            });
        },
        
        afterRender: function(args) {
            var self = this;
            var searchString = "";
            var columns = [];
           
            var checkboxSelector = new Slick.CheckboxSelectColumn({
                cssClass: "slick-cell-checkboxsel"
            });

            columns.push(checkboxSelector.getColumnDefinition());
            columns.push({ id: "displayName", name: "User", field: "displayName", width: 452, sortable: true, resizable: false});
            columns.push({id: "email", name: "Email", field: "email", width: 450, sortable: false, resizable: true});
        
            this.gridOptions = {
                editable: false,
                enableAddRow: true,
                enableCellNavigation: true 
            };

            var options = {
                editable: false,
                enableCellNavigation: true,
                asyncEditorLoading: true,
                defaultColumnWidth: 125
            };
                
            this.dataView = new window.SlickBase.Data.DataView();
             
            this.grid = new window.SlickBase.Grid("#usersGrid", self.dataView, columns, options);

            this.grid.setSelectionModel(new Slick.RowSelectionModel({selectActiveRow: false}));
            this.grid.registerPlugin(checkboxSelector);

            this.grid.onSort.subscribe(function (event, args) {
                self.dataView.sort(function (dataRow1, dataRow2) {
                if(!args.sortAsc){
                    //sets to ABC Order on Last Name of entered displayName
                    if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) < dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                        return -1;
                    }
                    else if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) > dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                        return 1;
                    }
                    else{
                        return 0;
                    }
                    args.sortAsc =false;
                }
                else{
                    if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) < dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                        return 1;
                    }
                    else if(dataRow1.displayName.substring(dataRow1.displayName.indexOf(' ')+1, dataRow1.displayName.indexOf(' ')+2 ) > dataRow2.displayName.substring(dataRow2.displayName.indexOf(' ')+1, dataRow2.displayName.indexOf(' ')+2)) {
                        return -1;
                    }
                    else{
                        return 0;
                    }
                    args.sortAsc =true;
                }             
                });
            });
            this.grid.onSelectedRowsChanged.subscribe(function (e, args) {
                    var selectedRows = args.grid.getSelectedRows();
                    if(selectedRows.length > 0){
                       $('#remove-users-button').removeClass('disabled');
                        $('#remove-users-button').removeAttr('disabled');
                    }
                    else{
                        $('#remove-users-button').addClass('disabled');
                        $('#remove-users-button').attr('disabled', 'disabled');
                    }
            });

            this.dataView.onRowCountChanged.subscribe(function (e, args) {
                self.grid.updateRowCount();
                self.grid.render();
            });

            this.dataView.onRowsChanged.subscribe(function (e, args) {
                self.grid.invalidateRows(args.rows);
                self.grid.render();
            });

            this.dataView.beginUpdate();
            this.dataView.setItems(this.gridData);
            this.dataView.setFilterArgs({
                searchString: searchString
            });
            self.dataView.setFilter(self.myFilter);
            this.dataView.endUpdate();
        },
        serialize: function() {
            return {
                "groupName": this.groupName
            };
        }
    }); 
    GroupConfig.RemoveUsersView = Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/removeusers",
        events:{
            'click #new-config-user-remove': 'removeUsers'
        },
        initialize: function(selectedUsersNames, groupName, selectedUsers, grid){
            this.selectedUsersNames = selectedUsersNames;
            this.groupName = groupName;
            this.selectedUsers = selectedUsers; 
            this.grid = grid;  
        },
        removeUsers: function(groupName , selectedUsers){
            var self =this;
            $.ajax({
                type: "POST", 
                url: app.serviceUrlRoot + "/users/removeUsersFromGroup?groupName=" + this.groupName,
                contentType: "application/json",
                data: JSON.stringify(this.selectedUsers),    
                    success: function(results){
                        var dataView = self.dataView;
                        _.each(this.selectedUsers, function(selectedUser) {
                            dataView.deleteItem(selectedUser);
                        });
                        app.trigger("removeUsers", self.groupName); 
                    },
                    error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: window.localize("modules.hpiAdmin.groupConfig.groupConfig.youFailed") 
                        });                    }
            });
        },
        
        serialize: function() {
            return {
                "users": this.selectedUsersNames,
                "groupName" : this.groupName
            };
        }
    });

    GroupConfig.AddUsersView = Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/addusers",
        events: {
            'keyup .typeahead-input': 'update',
            'click .executeSearchBtn': 'searchUsers',
            'click #add-users': 'addUsers' 
        },
        initialize: function(options) {
            this.options = options;
            this.groupName = this.options.groupName;

            // On initialization of modal, we are passed a list of existing users
            // to filter our source users from
            this.existingUsers = new Backbone.Collection(this.options.existingUsers);
            this.sourceUsers = new Backbone.Collection();
            this.targetUsers = new Backbone.Collection();
            this.targetUsers.on(window.localize("modules.hpiAdmin.groupConfig.groupConfig.changeAddRemove"), this.checkTarget, this);
            this.query = "";
            this.checkQuery();
            this.checkTarget();
            this.populateTossAcross(this.sourceUsers, this.targetUsers);
            this.dataView = this.options.dataView;
        },

        update: _.debounce(function(event){
            this.query = this.$(event.currentTarget).val();
            this.checkQuery();
        }),

        checkTarget: function(){
            if(this.targetUsers.length > 0) {
                this.$('#add-users').removeClass('disabled');
            }
            else {
                this.$('#add-users').addClass('disabled');
            }
        },
        populateTossAcross: function(sourceUsers, targetUsers){
           var self = this;
           var attributesTossAcross = new TossAcross.Layout({
                srcCollection: {
                    title: 'Available Users',
                    clickAcross: true,
                    labelAttr: 'displayName',
                    collection: sourceUsers
                },
                targetCollections: [{
                    title: 'Users To Add To ' + self.groupName,
                    labelAttr: 'displayName',
                    clickAcross: true,
                    collection: targetUsers
                }]
            });

            // Set view and render
            this.setView("#users-tossacross-outlet", attributesTossAcross).render();
        },
        checkQuery: function(){
            if(this.query && this.query.length >= 3){ //min three character length
                this.$('.executeSearchBtn').removeClass('disabled');
                this.$('.executeSearchBtn').removeAttr('disabled');
                this.$('.group-error-message-output').text('');
                return true;
            }else if(!this.query || this.query.length < 3){
                this.$('.executeSearchBtn').addClass('disabled');
                //IE 9-10 support - double tap disabled buttons
                this.$('.executeSearchBtn').attr('disabled', 'disabled');
                this.$('.group-error-message-output').text('three characters minimum');
                return false;
            }
        },
        searchUsers: function(event){
            var self = this;
            var searchString = this.query;
            var requestObj = {
                "authorityType": "user",
                "criterion": {
                    "attrToSearch": "displayName", 
                    "matchType": "contains", 
                    "searchTerm": searchString
                }
            };
            $.ajax({
                url: app.serviceUrlRoot + "/authorities/search", 
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                    success: function (result) {
                        var users = new Backbone.Collection();
                        var existingAuthorities = _.pluck(self.dataView.getItems(), "id");
                        var existingSelectedAuthorities = self.targetUsers.pluck("username"); 
                        _.each(result, function(user) {
                            if(!_.contains(existingAuthorities, user.authorityId) && 
                                !_.contains(existingSelectedAuthorities, user.authorityId)) {
                                    users.push({
                                        "displayName" : user.displayName,
                                        "username" : user.authorityId
                                    });
                                }
                        });
                        if(users.length>0){
                            self.sourceUsers = users;
                            self.populateTossAcross(self.sourceUsers, self.targetUsers);
                        }
                        else{
                            self.$('.executeSearchBtn').attr('disabled', 'disabled');
                            self.$('.group-error-message-output').text(window.localize("modules.hpiAdmin.groupConfig.groupConfig.noMatched"));
                        }
                    },
                     error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to search for the users. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    },
                global : false
            });
        },
        addUsers: function() {
            var self=this;
            var usernamesToAdd = this.targetUsers.pluck("username");
            $.ajax(
            {
                url: app.serviceUrlRoot + "/users/addUsersToGroup?groupName=" + this.groupName,
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(usernamesToAdd), 
                    success: function (result) {
                        self.targetUsers.each(function(addedUser) {
                            self.dataView.addItem({
                                id: addedUser.get("username"), 
                                "displayName": addedUser.get("displayName")
                            });
                            app.trigger("addUsers", self.groupName); 
                        });

                        self.targetUsers = new Backbone.Collection();
                        self.populateTossAcross(self.sourceUsers, self.targetUsers);
                        self.dataView.refresh();
                    },
                     error: function(jqXHR, textStatus, errorThrown){
                        app.trigger("alert:error", {
                            message: "An unexpected error occured when trying to add the user to the group. Please contact your adminstrator with the following message:\n\n" + new Date().toLocaleString() + "\n" +  jqXHR.responseText 
                        });
                    },
                global : false
            });
        }
    });
    GroupConfig.Groups = Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/groups",
        events: {
            'click #new-group-button': 'onClickAdd',
            'click #remove-group': 'onClickRemoveConfirmation',
            "keyup .groups-filter": "filterResults",
            'click .list-group-item': 'onClickGroup'
        },
        initialize: function(options) {
            this.groupsCollection = new GroupConfig.GroupCollection();
            this.groups = [];
            this.populateGroups();
        },
        groupRender: function(results){
            var self = this;
                var groups = [];
                _.each(results, function(group)
                {
                    groups.push({
                        "displayName": group.get("displayName"),
                        "groupName": group.get("authorityId")
                    });
                });
            self.groups = groups;
            self.render();
        },
        populateGroups: function() {
            var self = this;
             var requestObj = {
                "authorityType": "group"
            };
            $.ajax(
            {
                url: app.serviceUrlRoot + "/authorities/search", 
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestObj),
                success: function(result) {
                    var groups = [];
                    _.each(result,function(group){
                        groups.push({
                            "displayName": group.displayName,
                            "groupName": group.authorityId
                        });
                    });
                    self.groups = groups;
                    self.groupsCollection.push(groups);
                    self.render();
                }
            }); 
        },
        onClickGroup: function(options){
            var self =this;
            var groupName = options.currentTarget.innerText;
            if( groupName !== ""){
                self.trigger("group-selected", groupName);
            }    
        },

        onClickAdd: function(options) {
            var addGroup = new GroupConfig.AddGroupView(this.groups);
            app.trigger('alert:custom', {
                view: addGroup
            }); 
        },

        onClickRemoveConfirmation: function(options) {
            var self = this;
            var groupToRemove = options.currentTarget.parentElement.innerText;
            app.trigger("alert:confirmation", {
                header: window.localize("modules.hpiAdmin.groupConfig.groupConfig.areYouSure"), 
                message: window.localize("modules.hpiAdmin.groupConfig.groupConfig.pleaseConfirm") + groupToRemove,
                confirm: function() {
                   self.trigger("onClickRemoveConfirmation", groupToRemove);
                }
            });
        },

        filterResults: _.debounce(function(event) {
            var self = this;
            self.filterText = $(event.target).val().toLowerCase();
            var filteredGroups;
            var unfilteredGroups = self.groupsCollection.models;
                filteredGroups = _.filter(unfilteredGroups, function(model) {
                    var found = false;
                    if(model.get("displayName").toLowerCase().indexOf(self.filterText) !== -1){
                        found = true;  
                    }
                    return found;
                });
            self.groupRender(filteredGroups);
        }, 400),
        afterRender: function() {
            if(this.filterText) {
                var filterInputBox = this.$(".groups-filter");
                filterInputBox.focus().val("").blur().focus().val(this.filterText);
            }
        },
        serialize: function() {
            return {
                "groups": this.groups
            };
        }
    });

    GroupConfig.Group = Backbone.Model.extend({
    });

    GroupConfig.GroupCollection = Backbone.Collection.extend({
        initialize: function() {
            this.query = "*";
        },
        url: function() {
            return app.serviceUrlRoot + "/users/queryForGroups?query=" + this.query;
        }
    });

    GroupConfig.AddGroupView = Backbone.Layout.extend({
        template: "hpiadmin/groupconfig/addGroup",
        events: {
            'keyup #new-config-groupName': 'update', 
            'click #new-config-group-save': 'addGroup'
        },

        initialize: function(options) {
            this.options = options;
            this.currentGroups = this.options;
            this.query = "";
            this.checkGroupName();
        },

        update: _.debounce(function(event) {
            this.inputText = this.$(event.currentTarget).val();
            this.checkGroupName();
        }),

        checkGroupName: function() {
            var self =this;
            var filteredGroups = _.filter(self.currentGroups, function(checkGroup){
                if(self.inputText === checkGroup.displayName){
                    return true;
                }
                return false;
            });

            if (filteredGroups.length > 0){
                $('#new-config-group-save').attr("disabled", true);
                this.$('.group-error-message-output').text('Group ' + self.inputText + " already exists");
            }
            else if(self.inputText ==="" ){
                $('#new-config-group-save').attr("disabled", true);
                this.$('.group-error-message-output').text("Please enter a Group Name");
            }
            else{
                $('#new-config-group-save').attr("disabled", false);
                this.$('.group-error-message-output').text('');            
            }
        },

        addGroup: function(){
            var groupName = $('#new-config-groupName').val();
            app.trigger("addGroup", groupName);
        }
    });   

    return GroupConfig;
});     