define(['app'], function (app) {
    var iOSSwitch = {};

    iOSSwitch.View = Backbone.View.extend({
        template: 'hpiadmin/common/iosswitch/iosswitch',
        events: function () {
            var events = {};
            events['click .iosSwitch_' + this.cid] = 'updateSwitchSelection';
            return events;
        },
        initialize: function (options) {
            this.model = options.model || new Backbone.Model();
            // this is the key the config is stored as on the model
            this.configModelKey = options.configModelKey;
            this.onLabel = options.onLabel || window.localize('generic.on');
            this.offLabel = options.offLabel || window.localize('generic.off');
            this.switchTitle = options.switchTitle || '';

            this.defaultSwitchValue = options.defaultSwitchValue || false;
            // this populates the information icon hover text
            this.configDescription = options.configDescription || '';

            //This allows adding an additional class to the iosSwitch root div
            this.customClass = options.customClass;

            //This allows overriding the true/false values when updating the model
            this.trueVal = options.trueVal|| true;
            this.falseVal = options.falseVal || false;

            // For code cleanliness, initialize the variable to false so there's no undefined configs for sliders.s
	        if(_.isUndefined(this.model.get(this.configModelKey))){
                if(this.defaultSwitchValue) {
                    this.model.set(this.configModelKey, true);
                } else {
                    this.model.set(this.configModelKey, false);
                }
            }

            this.isChecked = (this.model.get(this.configModelKey) === this.trueVal);
        },
        updateSwitchSelection: function (event) {
            this.isChecked = $(event.target).val() === 'true';
			var newVal = this.isChecked ? this.trueVal : this.falseVal;
            // The html holds/returns the value of the slider as a string "true" or "false" because we are using an input control, we want to save the actual boolean value.
            this.model.set(this.configModelKey, newVal);
        },
        serialize: function () {
            return {
                cid: this.cid,
                isChecked: this.isChecked,
                onLabel: this.onLabel,
                offLabel: this.offLabel,
                switchTitle: this.switchTitle,
                configDescription: this.configDescription,
                customClass: this.customClass
            };
        },
        afterRender: function() {
            self.$('[data-toggle="tooltip"]').tooltip();
        }
    });

    return iOSSwitch;
});