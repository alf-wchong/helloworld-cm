define(['app'], function () {
    var AdminDropdown = {};

    AdminDropdown.View = Backbone.View.extend({
        className: 'adminDropdown',
        template: 'hpiadmin/common/admindropdown/admindropdown',
        events: function () {
            var events = {};
            events["change #selection_" + this.cid] = 'formChanged';
            return events;
        },
        initialize: function(options) {
            // arguments to be passed in
            this.model = options.model;
            this.configModelKey = options.configModelKey || 'adminDropdown';
            this.title = options.title || window.localize('hpiAdmin.dropdown.default.title');
            this.configDescription = options.configDescription;
            this.initializeOptionObjects(options.optionObjects);
            this.updateSelected(this.model.get(this.configModelKey));
        },
        initializeOptionObjects: function(objects) {
            // format options like [ {displayValue: "", value: ""}, {...}, ... ]
            this.optionObjects = (objects && !_.isEmpty(objects)) ? _.clone(objects) : [];
        },
        changeOptionObjects: function(newOptions) {
            this.initializeOptionObjects(newOptions);
            this.updateSelected(this.model.get(this.configModelKey));
            this.render();
        },
        formChanged: function (event) {
            var value =  $(event.target).val();
            this.model.set(this.configModelKey, value);
            this.updateSelected(value);
        },
        updateSelected: function(value) {
            _.each(this.optionObjects, function(option){
                option.selected = false;
                // not comparing types since html returns a string and optionObject can include other datatypes
                if(value == option.value) {
                    option.selected = true;
                }
            }, this);

            //If the value of the model doesn't match any of the options to select, reset the value
            //of the model and select the first option
            var selectedVal = _.findWhere(this.optionObjects, {
                selected: true
            });

            if(selectedVal === undefined) {

                if(this.optionObjects.length >= 1) {
                    this.optionObjects[0].selected = true;
                    this.model.set(this.configModelKey, this.optionObjects[0].value);
                }
                else {
                    this.model.set(this.configModelKey, '');
                }
            }
        },
        serialize: function() {

            return {
                cid: this.cid,
                title: this.title,
                configDescription: this.configDescription,
                options: this.optionObjects
            };
        }
    });

    return AdminDropdown;
});