define([
    "app",
    "backbone"
],
function(app, Backbone) {
    "use strict";
    var ImageUploader = app.module();

    ImageUploader.View = Backbone.Layout.extend({
        template: "hpiadmin/common/imageuploader/imageupload",
        className: "imageUpload",
        events: {
            "click #selectImage" : "selectImage",
            "change .imageToUpload" : "uploadFile",
            "click #removeImage" : "removeImage"
        },
        initialize: function(options) {
            this.imageName = options.imageName;
            this.title = options.title;
            this.security = options.security;
            this.tooltip = options.tooltip;
        },
        selectImage: function() {
            this.$(".imageToUpload").click();
        },
        uploadFile: function() {
            var self = this;
            var file = this.$('.imageToUpload')[0].files[0];
            this.validate(file).done(function(valid) {
                if(valid) {
                    var fd = new FormData();    
                    fd.append( 'file', file);
                    $.ajax({
                        url: app.serviceUrlRoot + '/configs/assetFile?name=' + self.imageName + '&appId=' + app.appId,
                        data: fd,
                        //Setting processData to false lets you prevent JQuery from automatically transforming the data into a query string
                        processData: false,
                        //Need to set to false to send the form data or JQuery will default it incorrectly
                        contentType: false,
                        context: self,
                        type: 'POST',
                        success: self.render
                    });
                } else {
                    self.render();
                }
            });
        },
        removeImage: function() {
            this.errorMsg = undefined;
            $.ajax({
                url: app.serviceUrlRoot + '/configs/assetFile?name=' + this.imageName + '&appId=' + app.appId,
                type: "DELETE",
                context: this,
                success: this.render,
                global: false
            });
        },
        validate: function(image) {
            var deferred = new $.Deferred();
            this.errorMsg = undefined;
            if(!this.security) {
                return deferred.resolve(true);
            }

            if(this.security.allowedMimetypes) {
                if(!_.contains(this.security.allowedMimetypes, image.type)) {
                    this.errorMsg = window.localize("hpiAdmin.imageUploader.invalidMimetype") + this.security.allowedMimetypes;
                    deferred.resolve(false);
                    return deferred;
                }
            }
            if(this.security.dimensionSizes) {
                var  img = new Image();
                var objectUrl = URL.createObjectURL(image);
                img.onload = _.partial(this._onImageLoad, this, deferred, objectUrl);
                img.src = objectUrl;
            } else {
                deferred.resolve(true);
            }
            return deferred;
        },
        _onImageLoad : function(parentContext, deferred, objectUrl) {
            URL.revokeObjectURL(objectUrl);
            if(parentContext.security.dimensionSizes.maxWidth < this.width || parentContext.security.dimensionSizes.maxHeight < this.height) {
                parentContext.errorMsg = window.localize("hpiAdmin.imageUploader.imageTooLarge") + parentContext.security.dimensionSizes.maxWidth 
                                        + " x " + parentContext.security.dimensionSizes.maxHeight;
                deferred.resolve(false);
            } else if(parentContext.security.dimensionSizes.minWidth > this.width || parentContext.security.dimensionSizes.minHeight > this.height) {
                parentContext.errorMsg = window.localize("hpiAdmin.imageUploader.imageTooSmall") + parentContext.security.dimensionSizes.minWidth 
                                        + " x " + parentContext.security.dimensionSizes.minHeight;
                deferred.resolve(false);
            } else if(parentContext.security.dimensionSizes.squareImage && this.width !== this.height) {
                parentContext.errorMsg = window.localize("hpiAdmin.imageUploader.imageNotSquare");
                deferred.resolve(false);
            } else {
                deferred.resolve(true);
            }
        },
        serialize: function() {
            return {
                "rootUrl": app.serviceUrlRoot,
                "appId": app.appId,
                "imageName": this.imageName,
                //Passing in the current time to append to the image URL. This is to prevent the browser from fetching the cached 
                //call when an image has been updated
                "currentTime": new Date().getTime(),
                "title": this.title,
                "errorMsg": this.errorMsg,
                "tooltip": this.tooltip
            };
        },
        afterRender: function() {
            this.$('[data-toggle="tooltip"]').tooltip();
        }
    });
    return ImageUploader;
});