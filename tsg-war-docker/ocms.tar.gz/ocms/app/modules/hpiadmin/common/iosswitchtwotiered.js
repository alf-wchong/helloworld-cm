define([
    'app',
    "modules/hpiadmin/common/iosswitch",
], 

function (app, iOSSwitch) {

    var iOSSwitchTwoTiered = {};

    iOSSwitchTwoTiered.View = Backbone.Layout.extend({
        template: 'hpiadmin/common/iosswitch/iosswitchtwotiered',
        events: function () {
            var events = {};
            events['click .iosSwitch_' + this.parentCid] = 'updateParentSwitchSelection';
            return events;
        },
        initialize: function (options) {
            this.parent = new iOSSwitch.View({
                model: options.model,
                configModelKey: options.parentConfigModelKey,
                switchTitle: options.parentSwitchTitle,
                configDescription: options.parentConfigDescription
            });

            this.child = new iOSSwitch.View({
                model: options.model,
                configModelKey: options.childConfigModelKey,
                switchTitle: options.childSwitchTitle,
                configDescription: options.childConfigDescription
            });

            this.hideChild = !this.parent.model.get(this.parentConfigModelKey);

            this.parentCid = this.parent.cid;
            this.childCid = this.child.cid;
            this.model = options.model || new Backbone.Model();

            this.setViews({
                "#parentSwitch": this.parent, 
                "#childSwitch": this.child 
            });
            if(this.hideChild) {
                this.child.$el.hide();
            }
        },
        updateParentSwitchSelection: function(event) {
            this.hideChild = ($(event.target).val() === 'false');
            this.render();
        },
        serialize: function () {
            var self = this;

            if(this.hideChild) {
                this.child.$el.fadeOut({
                    done: function() {
                        self.child.model.set(self.child.configModelKey, false);
                        self.child.render(); 
                    }
                });
            } else {
                this.child.$el.fadeIn();
            }
            return {
                hideChild: this.hideChild
            };
        }
    });

    return iOSSwitchTwoTiered;
});