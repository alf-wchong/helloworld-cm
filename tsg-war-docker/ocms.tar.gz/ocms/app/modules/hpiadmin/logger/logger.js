// Logger module
define([
	"log4javascript"
],

function(log4javascript) {

	var Logger = this.log4javascript.getLogger();
	var patternLayout = new this.log4javascript.PatternLayout("%d{dd MMM yyyy HH:mm:ss,SSS} %-5p - %m%n");
    var consoleAppender = new this.log4javascript.BrowserConsoleAppender();
    consoleAppender.setLayout(patternLayout);
	Logger.addAppender(consoleAppender);
	Logger.setLevel(this.log4javascript.Level.DEBUG);

	// Return the module for AMD compliance.
	return Logger;

});