// WorkflowFormconfig module
define([
        "app",
        "handlebars",
        "modules/hpiadmin/hpiadmin-switcher",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/formconfig/formtype",
        "modules/common/workflow",
        "modules/hpiadmin/otc/repotype",
        "modules/hpiadmin/workflowformconfig/singleattribute"
    ],

    function(app, Handlebars, Switcher, Hpiadmin, Formtype, Workflow, Repotype, SingleAttribute) {
        "use strict";

        var SingleWorkflowForm = app.module();

        SingleWorkflowForm.CustomAttrsModel = Hpiadmin.Config.extend({
            type: "CustomAttributes",
            defaults: {
                type: "CustomAttributes",
                attrs: [],
                name: "default"
            },
            initialize: function(options) {},
            parseResponse: function(response) {
                //if this is the first time this config is loaded (id will be undefined),
                //then we need to build up the configured types without overwriting the
                //one that has already been init'ed. if the id is already present, then
                //the parse was hit after a save, and we are confident that the model we
                //already have is what is returned from the server, so remove config model
                //info from the response
                if (this.id) {
                    response = _.pick(response, 'id');
                }

                return response;
            }
        });

        // Default Model.
        SingleWorkflowForm.Model = Hpiadmin.Config.extend({
            type: "WorkflowFormConfig",
            defaults: {
                type: "WorkflowFormConfig",
                // Default workflow attributes
                workflowAttributes: [{
                    ocName: "bpm_assignees",
                    value: "bpm_assignees",
                    label: "Assignees"
                }, {
                    ocName: "bpm_comment",
                    value: "bpm_comment",
                    label: "Comment"
                }, {
                    ocName: "bpm_groupAssignee",
                    value: "bpm_groupAssignee",
                    label: "Group Assignee"
                }, {
                    ocName: "bpm_reviewOutcome",
                    value: "bpm_reviewOutcome",
                    label: "Review Outcome"
                }, {
                    ocName: "bpm_status",
                    value: "bpm_status",
                    label: "Status"
                }, {
                    ocName: "bpm_workflowDueDate",
                    value: "bpm_workflowDueDate",
                    label: "Workflow Due Date"
                }]
            },
            initialize: function(options) {},
            parse: function(response) {
                //Sometime the response is a json object, sometimes it is a string that should be a json object
                if (typeof response === "string") {
                    response = JSON.parse(decodeURIComponent(response));
                }

                //if this is the first time this config is loaded (id will be undefined),
                //then we need to build up the configured types without overwriting the
                //one that has already been init'ed. if the id is already present, then
                //the parse was hit after a save, and we are confident that the model we
                //already have is what is returned from the server, so remove config model
                //info from the response
                if (this.id) {
                    response = _.pick(response, 'id');
                }

                if (response.controls) {
                    response.controls = new SingleAttribute.Collection(response.controls).models;
                }

                return response;
            }
        });

        //Collection of workflowformconfig models
        //This collection is used by the context to pull down all saved workflowformconfigs
        SingleWorkflowForm.Collection = Hpiadmin.ConfigTypeCollection.extend({
            model: SingleWorkflowForm.Model,
            initialize: function(model, options) {
                this.type = "WorkflowFormConfig";
            }
        });

        SingleWorkflowForm.Views.Layout = Backbone.View.extend({
            template: "hpiadmin/workflowformconfig/singleworkflowform",
            events: {
                "keyup #filter-attrs-input-wf": "filterAttrs",
                "click #filter-attrs-input-wf": "clickFilterInput",
                "click button.close": "closeMenu",
                "click .add-all-attrs": "addAllAttrs",
                "click #add-attribute": "createCustomAttribute",
                "updateSameCollection": "updateSameCollection",
                "click #delete-attribute": "deleteCustomAttributes"
            },
            initialize: function(options) {
                var self = this;
                this.options = options;
                this.config = {};
                this.picklists = options.picklists;
                this.hiddenFilter = false;
                this.defaultWorkflowAttributes = options.model.defaults.workflowAttributes;
                if (options.customAttrsModel) {
                    this.customAttrsModel = options.customAttrsModel;
                } else {
                    this.customAttrsModel = new SingleWorkflowForm.CustomAttrsModel();
                }

                //Combining these so that any custom attributes will be in the dropdown if they aren't being used on the form
                this.workflowAttributes = _.union(this.defaultWorkflowAttributes, this.customAttrsModel.get('attrs'));

                // Determines which attributes are configured/unconfigured
                this.attrHelper = new Backbone.Model({
                    allAttrs: [],
                    configuredAttrs: [],
                    unconfiguredAttrs: []
                });

                this.wfFormName = options.wfFormName;

                //Making a collection of the controls
                this.collection = new SingleAttribute.Collection(this.model.get('controls'));

                //Listener for sorting
                this.listenTo(this.attrHelper, "WorkflowFormAttribute:sort", function(model, position) {
                    this.collection.remove(model);
                    this.collection.add(model, {
                        at: position
                    });
                });

                // We debounce here, because addAll would spam render()'s for each attribute added.
                this.listenTo(this.collection, "add", _.debounce(function() {
                    self.model.set('controls', self.collection.models);
                    self.render();
                }), 100);

                this.listenTo(this.collection, "remove", function() {
                    self.model.set('controls', self.collection.models);
                    self.render();
                });

                this.listenTo(this.collection, "change", function(e) {
                    self.model.set('controls', self.collection.models);
                    var custAttr = _.findWhere(self.customAttrsModel.get("attrs"), {
                        'ocName': e.get('ocName')
                    });
                    if (custAttr) {
                        custAttr.label = e.get('label');
                    }
                    self.render();
                });

                this.listenTo(app, "configuredAttrsAdded", function(formAttribute) {
                    self.collection.add(formAttribute);
                    self.insertView("#wfformattributecollection", new SingleAttribute.View({
                        model: formAttribute,
                        attrHelper: self.attrHelper,
                        picklists: self.picklists
                    })).render();
                });

                this.listenTo(this.attrHelper, "configuredAttrsRemoval", function(model) {
                    self.collection.remove(model);
                });

                this.listenTo(app, 'saveWorkflowForm', function() {
                    //Saving the current form
                    this.model.save({}, {
                        success: function() {
                            Backbone.history.navigate("admin/WorkflowFormConfig/", {
                                replace: true,
                                trigger: true
                            });
                            app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", "#content-outlet");

                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: "Error Saving Config",
                                message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
                            });
                        }
                    });

                    //Saving the "custom attributes" model/config
                    this.customAttrsModel.save({}, {
                        success: function() {
                            Backbone.history.navigate("admin/WorkflowFormConfig/", {
                                replace: true,
                                trigger: true
                            });
                            app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", "#content-outlet");

                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: "Error Saving Config",
                                message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
                            });
                        }
                    });
                });

                this.listenTo(app, 'deleteWorkflowForm', function() {
                    this.model.destroy({}, {
                        success: function() {
                            Backbone.history.navigate("admin/WorkflowFormConfig/", {
                                replace: true,
                                trigger: true
                            });
                            app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", "#content-outlet");

                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: "Error Saving Config",
                                message: "Your configuration save failed. The configuration cannot have the same name as another configuration."
                            });
                        }
                    });
                });

                //The modals for our custom attributes
                this.$("#create-custom-modal").modal();
                this.$("#delete-custom-modal").modal();

                var allAttributes = _.pluck(this.workflowAttributes, "value");
                var configuredAttributes = this.collection.pluck("value");
                // Remove any configured custom attributes that have been removed from the master list
                // First, find what custom attributes are not in allAttributes
                // Then, remove any missing custom attributes from configuredAttributes
                // by taking the difference of configuredAttributes and the missing custom attributes
                configuredAttributes = _.difference(configuredAttributes, _.difference(configuredAttributes, allAttributes));
                var unconfiguredAttributes = _.difference(allAttributes, configuredAttributes);
                // Determine custom attributes
                var customAttributes = this.customAttrsModel.get("attrs");
                this.customAttributeObjects = [];
                _.each(customAttributes, function(value) {
                    self.customAttributeObjects.push(_.findWhere(self.workflowAttributes, {
                        "value": value
                    }));
                });

                // Populate attrHelper
                this.attrHelper.set("allAttrs", allAttributes);
                this.attrHelper.set("configuredAttrs", configuredAttributes);
                this.attrHelper.set("unconfiguredAttrs", unconfiguredAttributes);
                this.setView("#unconfigured-attributes", new SingleWorkflowForm.UnconfiguredAttributes({
                    attrHelper: self.attrHelper,
                    formName: self.wfFormName,
                    workflowAttributes: self.workflowAttributes
                })).render();

                this.render();
            },
            beforeRender: function() {
                var self = this;
                // Collection has the form controls so far
                if (this.collection) {
                    this.collection.each(function(formAttribute) {
                        self.insertView("#wfformattributecollection", new SingleAttribute.View({
                            model: formAttribute,
                            attrHelper: self.attrHelper,
                            picklists: self.picklists
                        }));
                    });
                } // end if
            },
            updateConfig: function(taskId, formSelected) {
                this.config[taskId] = formSelected;
            },
            updateSameCollection: function(event, index) {
                //everytime we move the formattribute, need to sort the attributes correctly
                //the boolean tells the sort that the attribute is from the same
                //configuredAttr collection
                this.attrHelper.trigger("WorkflowFormAttribute:sort", this.model.get("controls")[this.movedIndex], index);

            },
            afterRender: function() {
                this.$("#delete-custom-modal").on('show.bs.modal', this.initializeDeleteModal());
                this.$("#create-custom-modasl").on('show.bs.modal', function() {
                    // Clear out previous values
                    $("#attribute-name").val("");
                    $("#attribute-label").val("");
                    // Hide any error messages
                    $("#blank-attribute-error").hide();
                    $("#duplicate-attribute-error").hide();
                });

                this.$("[data-toggle='tooltip']").tooltip();

                var self = this;
                //since we just rendered, need to check if the attrs should be hidden or not
                if (this.hiddenFilter) {
                    this.$("#filter-attrs-div").hide();
                }

                this.$("#current-wf-form-text").text(this.wfFormName);

                self.setView("#unconfigured-attributes", new SingleWorkflowForm.UnconfiguredAttributes({
                    formName: self.wfFormName,
                    'attrHelper': self.attrHelper,
                    workflowAttributes: self.workflowAttributes
                })).render();

                self.startCount = 0;
                //this makes sure that both tbody's that have this class are rendered before
                //we attach the sortable class
                //we don't use this.$() selector since a separate views add the tbody's
                // also: make sure we're only applying the sortable to the decendants of THIS TYPE (or it breaks) (this.parentCid is passed from the parent formtype.model)
                this.sortableElements = $(".wf-form-attr");
                if (this.sortableElements.length >= 2) {
                    this.$("#wfformattributecollection").sortable({
                        revert: true,
                        handle: ".wf-form-attr",
                        stop: function(event, ui) {
                            if (this === ui.item.parent()[0]) {
                                ui.item.trigger("updateSameCollection", ui.item.index());
                            }
                            self.$("#wfformattributecollection").find(".dropzone").remove();
                            self.startCount = 0;
                        },
                        start: function(event, ui) {
                            self.movedIndex = ui.item.index();
                            // this is NOT scoped to self -- because we want to find the elements outside this view in the DOM (dont want to trigger events in order to bubble up)
                            if (self.startCount === 0) {
                                self.$("#wfformattributecollection").append("<tr class='dropzone' style='border:2px dashed #f2dede; border-radius:6px'><td colspan='9' style='text-align:center'>Drop Here</td></tr>");
                                self.startCount++;
                            }
                        }
                    }).disableSelection();
                }

            },
            addAllAttrs: function() {
                // Calls UnconfiguredAttributes
                this.attrHelper.trigger("WorkflowFormAttribute:addAllAttrs");
            },
            createCustomAttribute: function() {
                var label = this.$("#attribute-label").val();
                var name = this.$("#attribute-name").val();
                if (label && name) {
                    this.$("#blank-attribute-error").hide();
                    if (_.contains(this.attrHelper.get("allAttrs"), name)) {
                        this.$("#duplicate-attribute-error").show();
                        return;
                    }
                    this.$("#duplicate-attribute-error").hide();
                    var newAttribute = {
                        "ocName": name,
                        "value": name,
                        "label": label
                    };
                    this.workflowAttributes.push(newAttribute);
                    this.customAttributeObjects.push(newAttribute);
                    this.customAttrsModel.get("attrs").push(newAttribute);
                    this.attrHelper.get("allAttrs").push(name);
                    this.attrHelper.get("configuredAttrs").push(name);
                    this.attrHelper.trigger("configuredAttrsAddition", name);
                    app.trigger('configuredAttrsAdded', new SingleAttribute.Model({
                        "ocName": name,
                        "label": label,
                        "value": name
                    }));
                } else {
                    this.$("#duplicate-attribute-error").hide();
                    this.$("#custom-attribute-error").show();
                }
            },
            clickFilterInput: function(e) {
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            },
            closeMenu: function(e) {
                this.$(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
            },
            filterAttrs: function(event) {
                this.attrHelper.trigger("Formattribute:filterAttrs");
            },
            deleteCustomAttributes: function() {
                var self = this;
                // Get checked items
                var checkedAttributes = this.$("input.delete-checkboxes[type=checkbox]:checked");
                _.each(checkedAttributes, function(checkbox) {
                    var value = $(checkbox).val();
                    // Find index in workflowAttributes to remove
                    var index = self.workflowAttributes.findIndex(function(item) {
                        return item.value === value;
                    });
                    self.workflowAttributes.splice(index, 1);
                    // Find index in customAttributeObjects to remove
                    index = self.customAttrsModel.get("attrs").findIndex(function(item) {
                        return item.value === value;
                    });
                    self.customAttrsModel.get("attrs").splice(index, 1);
                    // Remove custom attribute from attrHelper
                    self.attrHelper.set("allAttrs", _.without(self.attrHelper.get("allAttrs"), value));
                    self.attrHelper.set("unconfiguredAttrs", _.without(self.attrHelper.get("unconfiguredAttrs"), value));
                    self.attrHelper.set("configuredAttrs", _.without(self.attrHelper.get("configuredAttrs"), value));
                });
                this.$("#delete-custom-modal").modal('toggle');

                this.render();
            },
            initializeDeleteModal: function() {
                var deleteCheckboxes = this.$(".delete-checkboxes");
                deleteCheckboxes.click(function() {
                    $("#delete-attribute").prop('disabled', !deleteCheckboxes.is(":checked"));
                });
            },
            serialize: function() {
                return {
                    currentWfFormControls: this.model.get('controls'),
                    wfFormName: this.model.get('name'),
                    cid: this.cid,
                    empty: this.attrHelper.get('configuredAttrs').length === 0,
                    customAttributes: this.customAttrsModel.get("attrs")
                };
            }
        });

        SingleWorkflowForm.UnconfiguredAttributes = Backbone.Layout.extend({
            template: "hpiadmin/formconfig/formattributeunconfiguredattrs",
            events: {
                "change #unconfigured-attrs-select": "addAttr"
            },
            initialize: function(options) {
                this.typeName = options.formName;
                this.workflowAttributes = options.workflowAttributes;
                //to get filtering working like we expect, we need the list of uncofigured
                //attrs, but also another list that we use in the view
                this.filteredAttrs = _.clone(this.attrHelper.get("unconfiguredAttrs").sort());

                this.listenTo(this.attrHelper, "change:unconfiguredAttrs", function() {
                    //the unconfiguredAttrs were changed somewhere, reset the viewableAttrs
                    this.attrHelper.trigger("WorkflowFormAttribute:filterAttrs");
                });

                this.listenTo(this.attrHelper, "WorkflowFormAttribute:filterAttrs", function() {
                    var filterValue = $("#filter-attrs-input-wf")[0].value;

                    //Get the unconfigured attrs.
                    this.getAttributeLabels(this.attrHelper.get("unconfiguredAttrs"));

                    //Filter based on the label
                    this.filteredAttrs = _.filter(this.labeledAttributes, function(attr) {
                        if (attr.label.toLowerCase().indexOf(filterValue.toLowerCase()) !== -1) {
                            return true;
                        } else {
                            return false;
                        }
                    });
                    //Sort the filtered results.
                    this.labeledAttributes = _.sortBy(this.filteredAttrs, 'label');

                    this.render();
                });

                // Called from View
                this.listenTo(this.attrHelper, "WorkflowFormAttribute:addAllAttrs", this.addAllAttrs);

                //Get the initial unconfigured attrs.
                this.getAttributeLabels(this.filteredAttrs);
            },
            getAttributeLabels: function(attributes) {
                var self = this;
                this.labeledAttributes = [];
                _.each(attributes, function(attribute) {
                    self.labeledAttributes.push(_.findWhere(self.workflowAttributes, {
                        value: attribute
                    }));
                });
                //Sort
                this.labeledAttributes = _.sortBy(this.labeledAttributes, 'label');
            },
            addAttr: function(event) {
                var that = this;
                // loop over each of the selected options (this is a multiple select box)
                this.$("option:selected").each(function() {
                    that.addSingleAttribute(this);
                });
            },
            addAllAttrs: function() {
                var that = this;
                // loop over all options
                this.$("option").each(function() {
                    that.addSingleAttribute(this);
                });
            },
            addSingleAttribute: function(attribute) {
                var attributeValue = attribute.value;

                //update our attrHelper
                this.attrHelper.set("configuredAttrs",
                    _.union(this.attrHelper.get("configuredAttrs"), attributeValue));
                this.attrHelper.set("unconfiguredAttrs",
                    _.without(this.attrHelper.get("unconfiguredAttrs"), attributeValue));

                //tell the collection of Formattrs that one was added
                this.attrHelper.trigger("configuredAttrsAddition", attributeValue);

                app.trigger('configuredAttrsAdded', new SingleAttribute.Model(_.findWhere(this.workflowAttributes, {
                    value: attributeValue
                })));
            },
            serialize: function() {
                return {
                    typeName: this.typeName,
                    filteredAttrs: this.labeledAttributes
                };
            }
        });

        return SingleWorkflowForm;
    });