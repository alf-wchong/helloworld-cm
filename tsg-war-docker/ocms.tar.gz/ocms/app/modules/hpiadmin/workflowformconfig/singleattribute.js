// WorkflowFormconfig module
define([
    "app",
    "handlebars",
    "modules/hpiadmin/hpiadmin-switcher",

    "modules/hpiadmin/hpiadmin",
    "modules/hpiadmin/formconfig/formtype",
    "modules/common/workflow",
    "modules/hpiadmin/otc/repotype",
    "modules/hpiadmin/formconfig/formattribute"
  ],

  function(app, Handlebars, Switcher, Hpiadmin, Formtype, Workflow, Repotype, Formattribute) {
    "use strict";

    var SingleAttribute = app.module();

    SingleAttribute.Model = Backbone.Model.extend({
      defaults: {
        ocName: "",
        repoName: "",
        controlType: "AutoComplete",
        editable: true,
        formEditable: true,
        required: false,
        repeating: false,
        importing: false,
        picklist: "",
        dataType: "",
        dependsOn: [],
        growable: false,
        autoSelect: false,
        allowDropdown: false,
        timestamped: false,
        onlyNewEntries: false,
        canTypeInBox: false,
        enforceDateBeforeToday: false,
        enforceDateAfterToday: false,
        minChars: "",
        maxChars: "",
        regex: "",
        regexRule: "",
        computedPattern: "",
        helptext: ""
      }
    });

    SingleAttribute.Collection = Backbone.Collection.extend({
      model: SingleAttribute.Model
    });

    // Model View.
    SingleAttribute.View = Backbone.Layout.extend({
      template: "hpiadmin/workflowformconfig/singleattribute",
      tagName: "tr",
      events: {
        "click span.icon-delete": "removeAttribute",
        "change select.form-control.controlType": "updateAttribute",
        "change input.form-control.singleAttr": "updateAttrLabel",
        "change input.checkbox": "updateCheckbox",
        "updateOtherCollection": "updateOtherCollection",
        "updateSameCollection": "updateSameCollection",
        "click .control-options": "clickControlOptions"
      },
      initialize: function(options) {
        var that = this;
        this.label = this.model.get("label");
        this.attrHelper = this.options.attrHelper;
        
        that.setViews({
          ".control-options-subview-outlet": new Formattribute.Views.ControlOptions({
            model: that.model,
            picklists: that.options.picklists,
            attrHelper: that.attrHelper
          }),
          ".control-external-rules-subview-outlet" : new Formattribute.Views.ControlExternalRules({
            model: that.model
          }),
          ".control-rules-subview-outlet" : new Formattribute.Views.ControlRules({
						model: that.model,
						allAttrs: that.attrHelper.get("allAttrs").sort()
					}),
          ".control-picklistwarning-subview-outlet": new Formattribute.Views.Picklistwarning({
            model: that.model
          }),
          ".control-picklistcascadewarning-subview-outlet": new Formattribute.Views.PicklistCascadeWarning({
            model: that.model
          })
        }).render();

        Handlebars.registerHelper("optionsvisible", function(options) {
          // any controls that DON'T have additional options should be specified here;
          var optionControls = ["Hidden", "NONE", "Special", "ProximityDateSearch"];
          if (_.contains(optionControls, this.controlType)) {
            return "";
          }
          return options.fn(this);
        });

        //This helper determines what control should be selected in the controlType
        //dropdown for each attribute
        Handlebars.registerHelper("control", function(options) {
          //options.hash.currentOption is the value of the current option from the
          //template
          //if this matches the model's controlType, then we should return selected
          if (this.controlType === options.hash.currentOption) {
            return "selected";
          } else {
            return "";
          }
        });
        
      },
      serialize: function() {
        return {
          controlType: this.model.get("controlType"),
          formEditable: this.model.get("editable"),
          editable: this.model.get("editable"),
          required: this.model.get("required"),
          repeating: this.model.get("repeating"),
          importing: this.model.get("importing"),
          dataType: this.model.get("dataType"),
          label: this.label,
          value: this.model.get("value"),
          cid: this.model.cid
        };
      },
      removeAttribute: function(event) {
        // Check if configuredAttrs or unconfiguredAttrs contains the value
        var value = this.model.get("value");
        if (_.contains(this.attrHelper.get("unconfiguredAttrs"), value) || 
          _.contains(this.attrHelper.get("configuredAttrs"), value)) {
          //update our attrHelper
          this.attrHelper.set("unconfiguredAttrs",
            _.union(this.attrHelper.get("unconfiguredAttrs"), value));
          this.attrHelper.set("configuredAttrs",
            _.without(this.attrHelper.get("configuredAttrs"), value));
        }
        //tell the collection of Formattrs that one was removed
        this.attrHelper.trigger("configuredAttrsRemoval", this.model);
      },
      updateAttribute: function(event) {
        //get the attrName from the id, splitting out the cid attached
        var attrToSet = event.target.id.split("-")[0];

        this.model.set(attrToSet, event.target.value);

        if (event.target.value === "Computed") {
          this.model.set('editable', false);
        }

        this.model.set('formEditable', true);

        this.render();
      },
      updateCheckbox: function(event) {
        var notOnModel = ["cascading"];
        //get the attrName from the id, splitting out the cid attached
        var attrToSet = event.target.id.split("-")[0];

        if (!_.contains(notOnModel, attrToSet)) {
          this.model.set(attrToSet, event.target.checked);
        }

        this.render();
      },
      updateSameCollection: function(event, index) {
        //everytime we move the formattribute, need to sort the attributes correctly
        //the boolean tells the sort that the attribute is from the same
        //configuredAttr collection
        this.attrHelper.trigger("Formattribute:sort", this.model, index, true);
      },
      updateAttrLabel: function(evt){
          this.model.set('label', evt.currentTarget.value.trim());
      },
      clickControlOptions: function(event) {
        if (event.stopPropagation) { // W3C/addEventListener()
          event.stopPropagation();
        } else { // Older IE.
          event.cancelBubble = true;
        }
      }
    });

    return SingleAttribute;

  });
