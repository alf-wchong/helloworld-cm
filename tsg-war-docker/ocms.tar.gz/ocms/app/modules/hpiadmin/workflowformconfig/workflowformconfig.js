// WorkflowFormConfig module
define([
        "app",
        //Clean this up!
        "modules/hpiadmin/hpiadmin-switcher",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/formconfig/formtype",
        "modules/hpiadmin/picklistconfig/picklistconfig",
        "modules/hpiadmin/workflowformconfig/singleworkflowform",
        "modules/hpiadmin/workflowformconfig/singleattribute"
    ],

    function(app, Switcher, Hpiadmin, Formtype, PicklistConfig, SingleWorkflowForm, SingleAttribute) {
        "use strict";

        var WorkflowFormConfig = app.module();


        WorkflowFormConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/workflowformconfig/workflowformconfig",
            className: "WorkflowFormConfig",
            events: {
                "click #saveform-btn": "saveForm",
                "click #existing-form": "loadForm",
                "click #deleteform-btn": "deleteForm",
                "click #create-modal-button": "createNewForm",
                "click #save-new-config": "addNewConfig"
            },
            initialize: function(options) {
                var self = this;

                // boolean to determine whether footer buttons should appear
                self.showFooter = false;
                // boolean to determine whether create form should appear
                self.createConfig = false;

                //Getting the current picklist config
                if (!app.context.currentPicklistConfig()) {
                    app.context.configService.getPicklistServices();
                } else {
                    this.picklists = app.context.currentPicklistConfig();
                }

                //Getting the current workflow form NAMES and the current custom attributes
                app.context.configService.getAdHocFormConfigNames(function(formConfigNames) {
                    app.context.configService.getCustomAttributes(function(model) {
                        self.customAttrsModel = model;
                        self.currentForms = formConfigNames;
                        self.render();
                    });
                });
            },
            loadForm: function(evt) {
                var self = this;
                // currentIndex used for deletion search efficiency in deleteForm
                this.createConfig = false;

                app.context.configService.getAdHocFormConfig(evt.target.text, function(model) {
                    self.model = model;
                    self.setFormView(model);
                });
            },
            setFormView: function(model) {
                this.picklists = app.context.currentPicklistConfig().get("picklists").pluck('label');

                var opts = {
                    "wfFormName": model.get('name'),
                    "picklists": this.picklists,
                    "model": model,
                    "customAttrsModel": this.customAttrsModel
                };

                this.setView("#workflow-form", new SingleWorkflowForm.Views.Layout(opts)).render();
                this.showFooter = true;
                this.render();
            },
            createNewForm: function() {
                this.createConfig = true;
                this.render();
            },
            addNewConfig: function() {
                var formName = this.$("#workflow-config-name").val();
                // Verify that name is neither blank nor already exists
                if (this.validateConfigName(formName)) {

                    this.setFormView(new SingleWorkflowForm.Model({
                        'name': formName
                    }));

                    this.invalidName = false;
                    // Update index for deleteForm
                    this.currentIndex = this.$("#current-wf-forms").length - 1;
                } else {
                    this.invalidName = true;
                }
                this.createConfig = false;
                this.render();
            },
            //Helper function to prevent the creation of forms with the same name
            validateConfigName: function(formName) {
                if (!formName) {
                    this.emptyName = true;
                    this.duplicateName = false;
                    return false;
                }

                if (_.findWhere(this.currentForms, {
                        name: formName
                    })) {
                    this.duplicateName = true;
                    this.emptyName = false;
                    return false;
                }
                return true;
            },
            saveForm: function() {
                //Triggering the event here since the button is on this template and the model is
                //containted in singleworkflowform.js
                app.trigger("saveWorkflowForm");
            },
            deleteForm: function() {
                //Triggering the event here since the button is on this template and the model is
                //containted in singleworkflowform.js
                app.trigger("deleteWorkflowForm");
                this.getView("#workflow-form").remove();
                this.currentForms = _.without(this.currentForms, this.model.get('name'));
                this.showFooter = false;
                this.render();
            },
            afterRender: function(){
                //Making sure the name of the displayed form is showing in the dropdown
                if(this.model.get('name')){
                    $("#current-wf-form-text").text(this.model.get('name'));
                }

                //Making sure that after deleting a form, the dropdown shows the proper text, not the deleted form's text
                if( !_.contains(this.currentForms, this.model.get('name')) ){
                    $("#current-wf-form-text").text("Please select a form");
                }

            },
            serialize: function() {
                return {
                    currentForms: _.sortBy(this.currentForms, 'name'),
                    showFooter: this.showFooter,
                    createConfig: this.createConfig,
                    duplicateName: this.duplicateName,
                    invalidName: this.invalidName,
                    emptyName: this.emptyName
                };
            }
        });

        return WorkflowFormConfig;
    });