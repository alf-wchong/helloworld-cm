define([
    "app",
    "handlebars",
    "modules/hpiadmin/hpiadmin",
    "modules/common/spinner",
    "modules/common/downloadutils",
    'modules/hpiadmin/adminUtil'
],
//map dependencies 
function(app, handlebars, Hpiadmin, HPISpinner, downloadUtils, AdminUtil) {

    "use strict";

    var LicenseManager = app.module();

    LicenseManager.Model = Hpiadmin.Config.extend({
        type: "LicenseManager",
        defaults: {
            type: "LicenseManager"
        }
    });

    LicenseManager.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/licensemanager/LicenseManager-layout",

        events: {
            'click .admin_ui_subsectionToggle' : 'toggleSubsection',
        },
        initialize: function() {
            // make a clean model for the new dashlet
            this.defaultModel = new LicenseManager.Model();
        },
        toggleSubsection: function(e) {
            AdminUtil.UI.toggleCustomConfigSubsection({'event': e});     
        },
        beforeRender: function(){
            this.renderViews();
        },
        renderViews: function() {
            var infoView = new LicenseManager.Views.LicenseInfo({
                model: this.defaultModel
            });
            var importView = new LicenseManager.Views.ImportLicense({
                model: this.defaultModel
            });

            // insert the dashlets in order based on the ordinal
            this.insertView(".license-info-outlet", infoView);

            this.insertView(".import-license-outlet", importView);
            
            this.listenTo(importView, "importSuccess", function() {
                this.render();
            });
        }
    });

    LicenseManager.Views.LicenseInfo = Backbone.Layout.extend({
        template: "hpiadmin/licensemanager/LicenseManager-info",

        initialize: function(){
            this.licenseData = [];
            this.getLicensePojo();
        },
        getLicensePojo: function() {
            var self = this;
            var url = app.serviceUrlRoot + "/license/getLicenseDetails";
            $.ajax({
                url: url,
                type: "GET",
                dataType: "JSON",
                data: {},
                global: false,
                success: function (data) {
                    // returns a JSON representation of a POJO
                    self.pojo = data;
                    _.each(_.keys(data), function(prop) {
                        if (prop === 'expirationDate') {
                            self.pojo[prop] = new Date(self.pojo.expirationDate);
                        }
                        self.licenseData.push({
                            name: self.mappingJson()[prop].prettyName,
                            val: self.pojo[prop],
                            info: self.mappingJson()[prop].info
                        });
                    });
                    self.render();
                },
                error: function () {
                    app.trigger("alert:error", {
                        header: window.localize("modules.hpiAdmin.licenseManager.licenseInfoError"), 
                        message: window.localize("modules.hpiAdmin.licenseManager.licenseInfoErrorMessage") 
                    });
                }
            });
        },
        serialize : function() {
            return {
                licenseData: this.licenseData
            };
        },
        // this JSON is currently what comes back from OC (OCMSLicenseInfo.java) if new 
        // properties are added to the POJO - they need to be updated and mapped here
        mappingJson : function() {
            return {
                expiringSoon : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.expiringSoon"),
                    info: window.localize("modules.hpiAdmin.licenseManager.expiringSoonInfo")
                },
                expirationDate : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.expirationDate"),
                    info: window.localize("modules.hpiAdmin.licenseManager.expirationDateInfo")
                }, 
                licenseType : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.licenseType"),
                    info: window.localize("modules.hpiAdmin.licenseManager.licenseTypeInfo")
                }, 
                daysRemainingUntilExpiration : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.daysLeft"),
                    info: window.localize("modules.hpiAdmin.licenseManager.daysLeftInfo")
                }, 
                maxUserCount : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.maxUsers"),
                    info: window.localize("modules.hpiAdmin.licenseManager.maxUsersInfo")
                }, 
                repoUserCount : {
                    prettyName: window.localize("modules.hpiAdmin.licenseManager.repoUsers"),
                    info: window.localize("modules.hpiAdmin.licenseManager.repoUsersInfo")
                }
            };
        }
    });

    LicenseManager.Views.ImportLicense = Backbone.Layout.extend({
        template: "hpiadmin/licensemanager/LicenseManager-import",

        events: {
            "click #license-submit" : "submitLicense",
        },
        submitLicense: function(evt) {
            // user clicked the submit button for the license page
            evt.preventDefault();
            // get the floating and text license from the form
            var floatingLicense = $("#login-license-floating").val();
            var textLicense = $("#login-license-text").val();
            var submitUrl = app.serviceUrlRoot + "/license/validateLicense";

            // send license data to OC REST endpoint and get back success or failure
            Backbone.ajax({
                url: submitUrl,
                data: {
                    floatingLicense: floatingLicense, 
                    textLicense: textLicense,
                    isAdminUpload: true
                },
                type: "POST",
                async: false,
                context: this,
                success: function() {
                    // display a success message then re render the views with the new license information
                    app.trigger("alert:info", {
                        header: window.localize("modules.hpiAdmin.licenseManager.importSuccess"), 
                        message: window.localize("modules.hpiAdmin.licenseManager.importSuccessMessage")
                    });  
                    
                    this.trigger("importSuccess");
                },
                error: function() {
                    // display error message and allow for user to resubmit license
                    app.trigger("alert:error", {
                        header: window.localize("modules.hpiAdmin.licenseManager.importFailure"), 
                        message: window.localize("modules.hpiAdmin.licenseManager.importFailureMessage") 
                    });
                }
            });
        }
    });

    return LicenseManager;
});



