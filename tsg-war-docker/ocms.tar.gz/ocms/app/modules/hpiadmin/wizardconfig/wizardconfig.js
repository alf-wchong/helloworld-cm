// Objecttypeconfig module
define([
    "app",
    "modules/hpiadmin/hpiadmin",
    "modules/hpiadmin/wizardconfig/wizardformconfig",
    "modules/hpiadmin/stageconfig/stageconfig",
    "modules/actions/actionmodules"
    ],

    function(app, Hpiadmin, WizardForm, StageConfig, theModule) {
        "use strict";

        var WizardConfig = app.module();

    // Default Model.
    WizardConfig.Model = Hpiadmin.Config.extend({
        type: "WizardConfig",
        defaults : {
            type : "WizardConfig"
        },
        initialize: function(options) {
            //Check for any previously configured forms
            if (options && options.wizardForms) {
                this.set("wizardForms", new WizardForm.Collection(options.wizardForms)); 
            } else {
                this.set("wizardForms", new WizardForm.Collection());
            }
        },
        parseResponse: function(response) {
            //if this is the first time this config is loaded (id will be undefined),
            //then we need to build up the wizard forms without overwriting the
            //one that has already been init'ed. if the id is already present, then
            //the parse was hit after a save, and we are confident that the model we
            //already have is what is returned from the server, so remove config model
            //info from the response
            if (this.id) {
                response = _.pick(response, 'id');
            } else if (response && response.wizardForms) {
                this.set("wizardForms", new WizardForm.Collection(response.wizardForms));
                delete response.wizardForms;
            }

            return response;
        }
    });

    WizardConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/wizardconfig/wizardconfig",
        className: "WizardConfig",
        events: {
            "click .addForm": "addForm",
            "click #saveworkflow-btn": "saveConfig"
        },
        initialize: function() {
            var that = this;
            var matchAll = ["wizard", "streamline"];
            this.forms = [];
            //Ajax request for all of our forms
            $.ajax({
                url : app.serviceUrlRoot + "/aw-form/getPageSets",
                type: "GET",
                success: function(forms) {
                    _.each(forms, function (form) {
                        that.forms.push(form.pageSetName);
                    });
                    that.actions = [];
                    var actionList = theModule.filterByGroupMatchingAll(matchAll); //Return a list of actions, filtered by our matchAll groups
                    //Add the label and id of each action
                    _.each(actionList, function (action) {
                        that.actions.push({actionId: action.actionId, label : action.label});
                    });
                    //Add our 'None'action
                    that.actions.push({label:"None", actionId: "None"});
                    //Sort alphabetically by label
                    that.actions.sort(function(a1, a2) { 
                        return (a1.label.toLowerCase()).localeCompare((a2.label.toLowerCase()));
                    });
                    //Re-render whenever a new form is added
                    that.listenTo(that.model.get("wizardForms"), "add", function(){
                        that.render();
                    });
                    that.listenTo(app, "removeCompleted", function(form) {
                        that.forms.push(form);
                        that.render();
                    });
                    //Create our collection using our wizardForms and actions list
                    _.each(that.model.get("wizardForms").models, function (model) {
                        var formName = model.get("formName");
                         that.forms = _.filter(that.forms, function (form) {
                            return form.localeCompare(formName) !== 0;
                        });
                    });
                    that.setViews({
                        "#wizardformcollection-outlet": new WizardForm.Views.Collection({
                            collection: that.model.get("wizardForms"),
                            actions: that.actions
                        })
                    });
                    that.render();
                }
            });
        },
        //Add a form config to the page
        addForm: function(event){
            //Trigger our event that our collection is listening to
            this.forms = _.filter(this.forms, function (form) {
                return form.localeCompare($(event.target).attr("id")) !== 0;
            });
            app.trigger("WizardForm:add", $(event.target).attr("id"));
        },
        //Save all configs that we have
        saveConfig: function() {
            var that = this;
            //Iterate over each view and update our values to what their are currently
            //Save the model to the server
            app.trigger("WizardForm:save");
            that.model.save({}, {
                success: function() {
                    //Re-fetch our data from the server
                    that.model.fetch({
                        success: function() {
                            //Re intialize our model, reload the page, and alert the user that changes were saved to the server
                            that.stopListening();
                            that.initialize();
                            Backbone.history.navigate("admin/WizardConfig", {replace: true, trigger: true});
                            app.trigger("alert:changeNotification", "alert-success", "Changes successfully pushed to the server.", "#content-outlet");
                        }
                    });
                },
                error: function() {
                    //Alert the user there was an error saving
                    app.trigger("alert:error", {
                        header : "Error Saving Config",
                        message : "Your configuration save failed. The configuration cannot have the same name as another configuration."
                    });
                }
            });
        },
        serialize: function() {
            return {
                currentForms: this.forms.sort() //Return our list of forms sorted by name
            };
        }
    });
return WizardConfig;
});
