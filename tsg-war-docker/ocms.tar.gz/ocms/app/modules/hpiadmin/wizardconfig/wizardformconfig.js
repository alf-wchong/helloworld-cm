// Formtype module
define([
        "app",
        "handlebars"
    ],

    // Map dependencies from above array.
    function(app, Handlebars) {

        // Create a new module.
        var WizardForm = app.module();

        WizardForm.Model = Backbone.Model.extend({
            defaults: {
                formName: "",
                formLabel: "",
                navigationAwayFromInvalidPages: true,
                externalEndpointForPrepopulation: false,
                prePopulationEndpoint: "",
                streamline: false,
                title: "Confirmation Page",
                message: "Thank you for filling out the form",
                selectedStageChoice: true,
                selectedActionId: "",
                selectedActionLabel: "",
                selectedRelaunchChoice: true,
                selectedViewerChoice: true,
                isOA: true
            }
        });

        WizardForm.Collection = Backbone.Collection.extend({
            model: WizardForm.Model
        });

        // Default View.
        WizardForm.Views.Model = Backbone.Layout.extend({
            template: "hpiadmin/wizardconfig/wizardformconfig",
            events: {
                "click .hpi-section-header": "toggleVisibility",
                "click .delete-wizardform": "removeWizardForm",
                "click .actionDropdown": "changeAction",
                "click .radioValueChange": "updateRadioValue",
                "keyup .textValueChange": "updateTextValue",
                "click .showHide": "toggle"
            },
            initialize: function(options) {
                Handlebars.registerHelper("setChecked", function(value, currentValue) {
                    if (value == currentValue) {
                        return "checked = true";
                    } else {
                        return "";
                    }
                });
                this.ui = {};
                this.actions = this.options.actions;
                this.listenTo(app, "WizardForm:save", function() {
                    if (!this.model.get("streamline")) {
                        var defaults = this.model.defaults;
                        this.model.set("title", defaults.title);
                        this.model.set("message", defaults.message);
                        this.model.set("selectedStageChoice", defaults.selectedStageChoice);
                        this.model.set("selectedRelaunchChoice", defaults.selectedRelaunchChoice);
                        this.model.set("selectedViewerChoice", defaults.selectedViewerChoice);
                        this.model.set("isOA", defaults.isOA);
                    }
                });
                //Search for our actions for the current selection
                this.render();
            },
            serialize: function() {
                return {
                    cid: this.cid,
                    formLabel: this.model.get("formLabel"),
                    navigationAwayFromInvalidPages: this.model.get("navigationAwayFromInvalidPages"),
                    externalEndpointForPrepopulation: this.model.get("externalEndpointForPrepopulation"),
                    prePopulationEndpoint: this.model.get("prePopulationEndpoint"),
                    streamline: this.model.get("streamline"),
                    actions: this.actions,
                    title: this.model.get("title"),
                    message: this.model.get("message"),
                    selectedStageChoice: this.model.get("selectedStageChoice"),
                    selectedActionId: (this.model.get("selectedActionId")) ? this.model.get("selectedActionId") : "None",
                    selectedActionLabel: (this.model.get("selectedActionLabel")) ? this.model.get("selectedActionLabel") : "None",
                    selectedRelaunchChoice: this.model.get("selectedRelaunchChoice"),
                    selectedViewerChoice: this.model.get("selectedViewerChoice"),
                    isOA: this.model.get("isOA")
                };
            },
            afterRender: function() {
                //Save all our DOM element lookups
                this.ui.content = this.$(".hpi-section-content");
                this.ui.viewerSelect = this.$("#viewerSelect");
                this.ui.navigationAwayFromInvalidPagesOptions = this.$("#navigationAwayFromInvalidPagesOptions");
                this.ui.externalEndpointForPrepopulationOptions = this.$("#externalEndpointForPrepopulationOptions");
                this.ui.prePopulationEndpoint = this.$("#prePopulationEndpoint");
                this.ui.streamlineOptions = this.$("#streamlineOptions");
                this.ui.actionLabel = this.$("#actionLabel");
            },
            //Hide and show the form on toggle
            toggleVisibility: function(event) {
                this.ui.content.toggleClass("hidden");
            },
            toggle: function(event) {
                var attr = $("input[id='" + $(event.target).attr("for") + "']").attr("name");
                if ($(event.target).attr("for").includes("enable")) {
                    if (this.ui[$(event.target).attr("toggle")].is(":hidden")) {
                        this.model.set(attr, true);
                        this.ui[$(event.target).attr("toggle")].show();
                    }
                } else {
                    if (this.ui[$(event.target).attr("toggle")].is(":visible")) {
                        this.model.set(attr, false);
                        this.ui[$(event.target).attr("toggle")].hide();
                    }
                }
            },
            //Update our option dropdown when a value is clicked
            changeAction: function(event) {
                this.ui.actionLabel.html($(event.target).html().split("~|~")[0]);
                this.ui.actionLabel.attr("actionId", ($(event.target).attr("actionId").split("~|~")[0]));
                if (this.ui.actionLabel.html().localeCompare("None") === 0) {
                    this.model.set("selectedActionId", "");
                    this.model.set("selectedActionLabel", "");
                } else {
                    this.model.set("selectedActionId", this.ui.actionLabel.attr("actionId"));
                    this.model.set("selectedActionLabel", this.ui.actionLabel.html());
                }
            },
            //Trigger the remove wizard event when a form is deleted
            removeWizardForm: function(e) {
                app.trigger("WizardForm:remove", this.model);
            },
            updateRadioValue: function(event) {
                var target = "input[id='" + $(event.target).attr("for") + "']";
                if ($(target).val().localeCompare("true") === 0) {
                    this.model.set($(target).attr("name"), true);
                } else {
                    this.model.set($(target).attr("name"), false);
                }
            },
            updateTextValue: function(event) {
                this.model.set($(event.target).attr("id"), $(event.target).val());
            }
        });

        WizardForm.Views.Collection = Backbone.Layout.extend({
            template: "hpiadmin/wizardconfig/wizardformcollection",
            initialize: function() {
                var that = this;
                //If one of the views is removed, confirm the delete, then remove it from our collection
                that.listenTo(app, "WizardForm:remove", function(model) {
                    app.trigger("alert:confirmation", {
                        confirm: function() {
                            //remove the model passed in
                            that.collection.remove(model);
                            that.render();
                            app.trigger("removeCompleted", model.get("formName"));
                        },
                        header: "Confirm Delete",
                        message: "Are you sure you want remove the config for this form template?"
                    });
                });
                //A new form is added
                that.listenTo(app, "WizardForm:add", function(formName) {
                    //Add the form to our collectionn
                    that.collection.add(new WizardForm.Model({
                        formName: formName,
                        formLabel: formName
                    }));
                });
            },
            beforeRender: function() {
                var that = this;
                //Add each config view to our collection
                if (that.collection.models) {
                    for (var i = 0; i < that.collection.models.length; i++) {
                        that.insertView("#wizardformcollection-" + that.cid, new WizardForm.Views.Model({
                            model: that.collection.models[i],
                            actions: that.options.actions
                        }));
                    }
                }
            },
            serialize: function() {
                return {
                    cid: this.cid
                };
            }
        });

        // Return the module for AMD compliance.
        return WizardForm;
    });