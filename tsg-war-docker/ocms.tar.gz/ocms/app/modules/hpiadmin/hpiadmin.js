// Confignavigator module
define([
        // Application.
        "jquery",
        "app",
        "module"
    ],

    // Map dependencies from above array.
    function($, app, module) {
        "use strict";

        // Create a new module.
        var Hpiadmin = app.module();
        //if this module is configured to use local configs change url accordingly
        Hpiadmin.configURLRoot = module.config().useLocal ? "" : app.serviceUrlRoot + "/";

        app.appId = app.appId ? app.appId : module.config().appId || "default";

        //Perhaps this could draw from a config file, but this should be a list of all type of configs HPI can handle.
        Hpiadmin.knownConfigTypes = [
            "ObjectTypeConfig",
            "StageConfig",
            "SearchConfig",
            "IndexerConfig",
            "ApplicationConfig",
            "PicklistConfig",
            "DetailViewConfig",
            "CollectionConfig",
            "DashboardConfig",
            "TracConfig",
            "FormConfig",
            "GroupConfig",
            "WorkflowFormConfig",
            "WorkflowConfig",
            "WorkflowCustomAttrubutes",
            "SecurityConfig",
            "UserConfig",
            "WizardConfig",
            "AdminSearchTool",
            "aclConfig",
            "ConfigArchiver",
            "LicenseManager",
            "DeveloperZone",
            "LoggingConfig",
            "TemplateManagementConfig"
        ];

        // All Hpi Configs will have at minimum a type and a name
        Hpiadmin.Config = Backbone.Model.extend({
            defaults: {
                name: "",
                label: "",
                id: "",
                type: ""
            },
            url: function() {
                return Hpiadmin.configURLRoot + "configs/" + this.get("type") + "/" + this.get("name") + "?latest=true" + "&appId=" + app.appId;
            },
            parse: function(response) {
                //Sometime the response is a json object, sometimes it is a string that should be a json object
                if (typeof response === "string") {
                    response = JSON.parse(decodeURIComponent(response));
                }
                return this.parseResponse(response);
            },
            parseResponse: function(response){
                // function should be implemented by subclass
                return response;
            }
        });

        // A collection of configs all the same type
        Hpiadmin.ConfigTypeCollection = Backbone.Collection.extend({
            model: Hpiadmin.Config,

            initialize: function(model, options) {
                //if a type was passed in set it
                if (options) {
                    this.type = options.type || undefined;
                }
            },

            url: function() {
                if (this.type) {
                    var url = Hpiadmin.configURLRoot + "configs/" + this.type + "?latest=true" + "&appId=" + app.appId;
                    if (this.full) {
                        url = url + "&fullConfigs=true";
                    }
                    return url;
                } else {
                    return Hpiadmin.configURLRoot + "configs/";
                }
            }
        });

        // Main View.
        Hpiadmin.Views.NavBar = Backbone.Layout.extend({
            template: "hpiadmin/admin-sidenav",
            initialize: function() {
                var self = this;
                this.name = "admin-sidenav";
                this.configCollections = [];
                //the first time this is setup, we want to go and get any collections from the server
                _.each(Hpiadmin.knownConfigTypes, function(configType) {
                    //create a new collection for these configs
                    this.configCollections.push(new Hpiadmin.ConfigTypeCollection([], { type: configType }));
                }, this);

                this.listenTo(app, "modelSaveOrDestroy", function() {
                    //re-render the navbar to show the proper configs
                    //this should be called whenever a config is saved and deleted
                    this.render();
                });

                this.configViews = [];
                _.each(this.configCollections, function(configCollection) {
                    self.configViews.push(new Hpiadmin.Views.ConfigTreeBranch({
                        collection: configCollection,
                        configType: configCollection.type
                    }));
                    //populate the collection
                    configCollection.fetch({
                        global: false
                    });
                }, this);

            },
            beforeRender: function() {
                var self = this;

                // Sort the config views
                var swapped;
                do {
                    swapped = false;
                    for (var i = 0; i < self.configViews.length - 1; i++) {
                        if (self.configViews[i].options.configType > self.configViews[i + 1].options.configType) {
                            var temp = self.configViews[i];
                            self.configViews[i] = self.configViews[i + 1];
                            self.configViews[i + 1] = temp;
                            swapped = true;
                        }
                    }
                } while (swapped);

                _.each(self.configViews, function(view) {
                    self.insertView("#configs-outlet", view);
                });
            }
        });

        Hpiadmin.Views.ConfigTreeBranch = Backbone.Layout.extend({
            template: "hpiadmin/configtree",

            tagName: "li",

            beforeRender: function() {
                //insert nodes for each branch of the collection
                this.collection.each(function(config) {
                    this.insertView(".configleaf-outlet", new Hpiadmin.Views.TreeLeaf({
                        model: config,
                        configType: this.options.configType
                    }));
                }, this);
            },

            serialize: function() {
                return { configType: this.options.configType };
            },

            events: {
                "click .nav-header": "loadConfigDetails"
            },

            loadConfigDetails: function() {

                Backbone.history.navigate("admin/");

            },

            initialize: function() {
                this.listenTo(this.collection, "sync", function() {
                    this.render();
                });
            }
        });

        var CopyModalView = Backbone.View.extend({
            template: "hpiadmin/copymodal",

            events: {
                "click #copyConfig": "onClickCopy"
            },

            onClickCopy: function() {

                var newName = this.$el.find("#newName").val();

                this.model.fetch({

                    success: function(results) {
                        //copies the attributes then clears the id and sets the new name
                        var newModel = results.clone();
                        newModel.set("id", undefined);
                        newModel.set("name", newName);

                        newModel.save({}, {
                            success: function() {
                                Backbone.history.navigate("admin/" + newModel.get("type") + "/" + newModel.get("name"), { trigger: true });
                                app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                                app.trigger("alert:close");
                            },
                            error: function() {
                                app.trigger("alert:changeNotification", "alert-danger", window.localize("generic.configSaveFailed"));
                            }
                        });

                    },
                    error: function(data) {
                        app.trigger("alert:error", {
                            header: window.localize("generic.alert"),
                            message: window.localize("modules.hpiAdmin.hpiAdmin.thereWas") + data
                        });
                    }
                });
            }
        });

        Hpiadmin.Views.TreeLeaf = Backbone.Layout.extend({
            template: "hpiadmin/configleaf",
            tagName: "li",

            serialize: function() {
                return this.model.toJSON();
            },
            events: {
                "click i#trash": "deleteConfig",
                "click span": "loadConfigInstance",
                "click i#copy": "onCopyClick"
            },

            // Waits for a copy function to be clicked then inititates the trigger.
            onCopyClick: function() {
                app.trigger("alert:custom", { view: new CopyModalView({ model: this.model }) });
            },

            loadConfigInstance: function(event) {
                Backbone.history.navigate("admin/" + this.options.configType + "/" + this.model.get("name"), { trigger: true });
                event.stopPropagation();
            },

            deleteConfig: function(event) {
                var that = this;
                event.stopPropagation();
                app.trigger("alert:confirmation", {
                    header: window.localize("modules.hpiAdmin.hpiAdmin.removeConfig"),
                    message: window.localize("modules.hpiAdmin.hpiAdmin.youAreAbout"),
                    confirm: function() {
                        that.model.destroy({
                            success: function() {
                                app.trigger("modelSaveOrDestroy");
                            }
                        });

                        //Check to see if the current config marked for deletion is loaded into the configDetail view.
                        //If it is, remove the view and navigate back to the root URL.
                        var urlParts = (Backbone.history.fragment).split("/");
                        if (that.model.get("name") === urlParts[urlParts.length - 1]) {
                            app.layout.removeView("#content-outlet");
                            // CHECK
                            Backbone.history.navigate("admin/");
                        }
                        app.trigger("alert:changeNotification", "alert-success", window.localize("modules.hpiAdmin.hpiAdmin.configuration") + that.model.get("name") + window.localize("modules.hpiAdmin.hpiAdmin.successfullyDeleted"), "#content-outlet");
                    }
                });
            }
        });

        Hpiadmin.Views.Tabs = Backbone.Layout.extend({
            template: "hpiadmin/admin-layout-tabs",

            initialize: function(options) {
                this.currentConfig = options.currentConfig;
                this.isHidden = false;
                this.showPeopleTab = false;
                if (app.showGroupManager || app.showUserManager || app.showAclManager) {
                    this.showPeopleTab = true;
                }
            },
            toggleDisplay: function() {
                this.isHidden = !this.isHidden;
                this.render();
            },
            afterRender: function() {

                $('[data-toggle="tooltip"]').tooltip();

                if (this.currentConfig) {
                    this.$("#tab-" + this.currentConfig).children().addClass("active");
                    this.$("#tab-" + this.currentConfig).parent().addClass("in");
                } else {
                    app.log.error(window.localize("modules.hpiAdmin.hpiAdmin.currentConfig"));
                }

            },
            serialize: function() {
                var self = this;
                return {
                    "showGroupManager": app.showGroupManager,
                    "showUserManager": app.showUserManager,
                    "showAclManager": app.showAclManager,
                    "showPeopleTab": self.showPeopleTab,
                    "developerTab": app.developerZone,
                    "enableWizard": app.enableWizard,
                    "isHidden": this.isHidden,
                    "showTemplateManager": app.showTemplateManager
                };
            }
        });

        Hpiadmin.Views.Home = Backbone.Layout.extend({
            template: "hpiadmin/home"
        });

        Hpiadmin.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/admin-layout",
            events: {
                "click #expander": "toggleAdminTabs"
            },
            initialize: function(options) {
                this.currentConfig = options.currentConfig;
                this.tabView = new Hpiadmin.Views.Tabs({ currentConfig: this.currentConfig });
                this.subview = options.subview;
            },
            toggleAdminTabs: function() {
                this.tabView.toggleDisplay();
                $('#admin-display-outlet').toggleClass("span-wide");
                $('#expander span').toggleClass("glyphicon-chevron-left glyphicon-chevron-right");
            },
            beforeRender: function() {
                this.setView("#admin-tabs-outlet", this.tabView);
                this.setView("#admin-display-outlet", this.subview);
            },
            afterRender: function() {
                app.log.debug(window.localize("modules.hpiAdmin.hpiAdmin.renderedMain"));
            }
        });

        // Return the module for AMD compliance.
        return Hpiadmin;

    });