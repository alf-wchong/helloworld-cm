define([
    "app",
    "modules/common/spinner"
],

    function (app, HPISpinner) {
        "use strict";

        var TemplateManagementModals = app.module();

        TemplateManagementModals.VersionTemplate = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/templatemanagementmodals/versiontemplate-modal",
            events: {
                "click #action-confirmed": "uploadNewVersionOfTemplate",
                "click #downloadTemplate": "downloadTemplate"
            },
            initialize: function (options) {
                this.options = options;
                // this.uploadFileName = false;
            },
            serialize: function () {
                var contentVisible = false;
                if(_.isUndefined(this.uploadFileName) && this.options.content){
                    contentVisible = true;
                }
                return {
                    templateName: this.options.docOco.properties.objectName,
                    templateTitle: this.options.docOco.properties.title,
                    templateDescription: this.options.docOco.properties.versionDescription,
                    fileName: this.uploadFileName,
                    templateContent: this.options.content,
                    contentVisible: contentVisible,
                    nameReadonly: this.options.nameReadonly,
                    titleDescRequired: this.options.titleDescRequired
                };
            },
            afterRender: function () {
                var self = this;
                //new version document
                this.$(".fileuploader-input").fileupload({
                    add: function (e, data) {
                        self.saveNewVersionOfDoc(data);
                    }
                });
            },
            downloadTemplate: function (event) {
                window.location = app.serviceUrlRoot + "/content/content?id=" + event.currentTarget.value + "&download=true&contentType[]="+this.options.downloadMimeType;
            },
            versionTemplate: function () {
                //Just triggers an event handled by the actual delete method in awtemplate-config
                this.options.ocTemplEventBus.trigger("newVersionRequested", this.options.templateName);
            },
            saveNewVersionOfDoc: function (file) {
                var self = this;

                this.uploadFile = file.files[0];
                this.uploadFileName = file.files[0].name;

                self.render();
            },
            uploadNewVersionOfTemplate: function () {
                var def = $.Deferred();
                var self = this;
                // Get form values

                if(this.$("#template-version-form-description").val()){
                    this.docOco.properties.versionDescription = this.$("#template-verion-form-description").val();
                }
                if(this.$("#template-version-form-title").val()){
                    this.docOco.properties.title = this.$("#template-version-form-title").val();
                }
                this.newTemplateContent = this.$("#template-verion-form-content").val();

                //make call to oc to PUT the update object
                $.ajax({
                    url: app.serviceUrlRoot + '/openContentObject',
                    type: 'PUT',
                    contentType: "application/json",
                    data: JSON.stringify(this.docOco),
                    success: function (data) {
                        if(self.uploadFileName != "" || self.newTemplateContent.trim() != self.options.content.trim()){
                            var fd = new FormData();
                            if(self.uploadFileName){
                                fd.append('properties', {"prop-name": self.uploadFileName});
                                fd.append('parts', self.uploadFile, self.uploadFileName);
                            }else{
                                var newTemplateBlob = new Blob([self.newTemplateContent], {type: 'text/html'});
                                fd.append('properties', {"prop-name": data.properties.objectName});
                                fd.append('parts', newTemplateBlob, data.properties.objectName);
                            }

                            fd.append('versionType', "minor");
                            fd.append('objectId', self.docOco.objectId);

                            var action = new Backbone.Model({
                                name: 'uploadNewVersion',
                                parameters: {
                                    objectId: self.docOco.objectId,
                                    versionType: 'minor'
                                }
                            });

                            fd.append('action', JSON.stringify(action));
                            $.ajax({
                                method: "POST",
                                data: fd,
                                contentType: false,
                                processData: false,
                                url: app.serviceUrlRoot + "/action/executeWithAttachment",
                                success: function (data) {
                                    var objectIdOfNewVersion = data.result;
                                    def.resolve(objectIdOfNewVersion);
                                },
                                error: function () {
                                    HPISpinner.destroySpinner(self.spinner);
                                }
                            });
                        }
                    }
                });

                return def.promise();
            }
        });

        TemplateManagementModals.AddTemplate = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/templatemanagementmodals/addtemplate-modal",
            events: {
                "click #action-confirmed": "uploadNewDoc",
                "change .objectTypeSelection": "changeSelectedProp"
            },
            initialize: function (options) {
                this.options = options;
                // Define the configured location for templates
                this.parentFolder = "/hpi/" + app.appId + "/ocmsTemplates";
                this.objectTypes = [];
                this.getObjectTypes();
            },
            afterRender: function () {
                var self = this;

                // add document file uploader
                this.$(".fileuploader-input").fileupload({
                    // ignoring linting for this catch block
                    // eslint-disable-next-line no-console
                    add: function (e, data) {
                        self.setNewDoc(data);
                    }
                });
            },
            serialize: function () {
                return {
                    fileName: this.uploadFileName,
                    targetTypeDropdown: this.options.targetTypeDropdown,
                    objectTypes: this.objectTypes,
                    nameReadonly: this.options.nameReadonly,
                    titleDescRequired: this.options.titleDescRequired
                };
            },
            changeSelectedProp: function(event){
                this.selectedType = event.target.value;
            },
            getObjectTypes: function(){
                var self = this;
                app.context.configService.getAdminOTC(function(OTC){
                    self.currentType = {ocName: window.localize("modules.common.addDocTemplate.selectAnObject"), label: window.localize("modules.common.addDocTemplate.selectAnObject")};
    
                    self.configuredObjects = OTC.get("configs");
    
                    _.each(self.configuredObjects.models, function(model){
                       self.objectTypes.push({ocName: model.get("ocName"), label: model.get("label")});
                    });
                });
            },
            uploadNewDoc: function () {
                var self = this;

                this.spinner = HPISpinner.createSpinner({
                    color: '#666'
                }, this.$el.find(".progressSpinner")[0]);

                // Upload new template
                this.uploadNewTemplate(this.uploadFile).done(function () {
                    // When template is uploaded, update the body to reflect this.
                    self.ocTemplEventBus.trigger("updateBody");
                });
            },
            setNewDoc: function (file) {
                // Get the template's file so that we can serialize the name and 
                // populate the form with the name
                this.uploadFile = file.files[0];
                this.uploadFileName = file.files[0].name;

                this.render();
            },
            uploadNewTemplate: function () {
                var fd = new FormData();

                // Prepare form data to upload our new  template.
                fd.append('parentId', this.parentFolder);
                fd.append('objectType', 'tsgTemplate');
                fd.append('prop-objectName', this.uploadFileName);
                fd.append('prop-tsgTemplateType', this.options.tsgTemplateTypeParam);

                if(this.$("#template-add-form-description").val()){
                    fd.append('prop-versionDescription', this.$("#template-add-form-description").val());
                }
                if(this.$("#template-add-form-title").val()){
                    fd.append('prop-title', this.$("#template-add-form-title").val());
                }
                if(this.options.targetTypeDropdown === true){
                    fd.append('prop-tsgTargetType', this.selectedType);
                }

                fd.append('parts', this.uploadFile, this.uploadFileName);

                return $.ajax({
                    method: "POST",
                    data: fd,
                    contentType: false,
                    dataType: "json",
                    processData: false,
                    url: app.serviceUrlRoot + "/content/upload",
                    error: function() {
                        // If failure, alert the user there was a problem.
                        app.trigger("alert:error", { 
                            header: window.localize("templateManagementConfig.templateManagementConfig.uploadErrorTitle"),
                            message: window.localize("templateManagementConfig.templateManagementConfig.uploadErrorBody")
                        });
                        HPISpinner.destroySpinner(self.spinner);
                    }
                });
            }
        });
        return TemplateManagementModals;
    });