define([
    "app",
    "oc",
    "modules/common/ocquery",
    "modules/hpiadmin/templatemanagementconfig/templatemanagementmodals"
],

function(app, OC, OcQuery, TemplateManagementModals) {
    "use strict";

    var TemplateManagementBody = app.module();

    TemplateManagementBody.Views.Layout = Backbone.Layout.extend({

        template: "hpiadmin/templatemanagementconfig/templatemanagementbody",
        events: {
            "change #octemplateselect": "selectionChanged",
            "click #version-template-button" : "templateVersion",
            "click #add-template-button" : "templateAdd"
        },

        initialize: function(options) {
            this.options = options;
            this.existingTemplate = [];
            this.populateBody(); //this calls render()
            this._startListening();
        },

        _startListening: function(){
            this.listenTo(this.ocTemplEventBus, "updateBody", this.populateBody);
        },

        populateBody: function() {
            var self = this;
            var query = new OcQuery.Collection([], {});
            query.searchParameters = [
                {   // search current template type
                    paramName: null,
                    paramValue: "tsgTemplate",
                    paramType : "type",
                    operator: "OPERATOR_EQUALS"
                },                  
                {   // search for those with content as template type
                    paramName: "tsgTemplateType",
                    paramValue: this.options.tsgTemplateTypeParam,
                    paramType : "property",
                    operator: "OPERATOR_EQUALS"
                }
            ];

            query.state.sortKey = "title";

            // run the query
            var deferred = query.fetch({
                success: function(data){
                    if(data.models.length) {
                        self.parseQueryResults(data);
                    }
                }
            });

            $.when(deferred).done(function() {
                self.render();
            });
        },
        parseQueryResults: function(data){
            this.existingTemplate = [];
            data.models.forEach(function(model) {
                if(model.get("properties").objectName) {

                    var objectId = model.get("objectId");
                    var objectName = model.get("properties").objectName;
                    var objectTitle = model.get("properties").title ? model.get("properties").title : "";
                    var objectDescription = model.get("properties").versionDescription ? model.get("properties").versionDescription : "";
                    var objectTargetType = model.get("properties").tsgTargetType ? model.get("properties").tsgTargetType : "";

                    this.existingTemplate.push({
                        objectId: objectId,
                        templateName: objectName,
                        templateTitle: objectTitle,
                        templateDescription: objectDescription,
                        templateTargetType: objectTargetType,
                        showTargetType: this.options.targetTypeDropdown
                    });
                }
            }, this);
        },

        serialize: function() {
            return {
                existingTemplates: this.existingTemplate,
                templateTypeDesc: this.options.templateTypeDesc,
                nameReadonly: this.options.nameReadonly,
                titleDescRequired: this.options.titleDescRequired
            };
        },

        templateVersion: function(event) {
            event.preventDefault();
            var self = this;
            this.selectedTemplateId = event.currentTarget.value;

            var oco = new OC.OpenContentObject( { objectId : this.selectedTemplateId } );
            oco.fetch({global: false});
            oco.fetch().done(function(docOco){ 
                var encodedId = encodeURIComponent(docOco.objectId);
                self.docOco = docOco;
                if( self.options.tsgTemplateTypeParam == "ftl"){
                    $.ajax({
                        url: app.serviceUrlRoot +"/content/content?&id=" + encodedId,
                        type: 'GET',
                        contentType: "application/json",
                        success: function (data) {               
                            //Create version modal
                            var versionModal = new TemplateManagementModals.VersionTemplate({
                                docOco: self.docOco,
                                content: data,
                                ocTemplEventBus: self.ocTemplEventBus,
                                tsgTemplateTypeParam: self.options.tsgTemplateTypeParam,
                                downloadMimeType: self.options.downloadMimeType
                            });
                            
                            if(self.views["#version-modal-outlet"]) {
                                self.views["#version-modal-outlet"].remove();
                            }

                            self.setView("#version-modal-outlet", versionModal).render();
                        }
                    });
                } else {
                    //Create version modal
                    var versionModal = new TemplateManagementModals.VersionTemplate({
                        docOco: self.docOco,
                        content: false,
                        ocTemplEventBus: self.ocTemplEventBus,
                        tsgTemplateTypeParam: self.options.tsgTemplateTypeParam,
                        downloadMimeType: self.options.downloadMimeType
                    });
                    
                    if(self.views["#version-modal-outlet"]) {
                        self.views["#version-modal-outlet"].remove();
                    }

                    self.setView("#version-modal-outlet", versionModal).render();
                }
            });
        },
        templateAdd: function(event){
            event.preventDefault();
            // Create the add template modal
            var addTemplateModal = new TemplateManagementModals.AddTemplate({
                ocTemplEventBus: this.ocTemplEventBus,
                tsgTemplateTypeParam: this.options.tsgTemplateTypeParam,
                targetTypeDropdown: this.options.targetTypeDropdown,
                nameReadonly: this.options.nameReadonly,
                titleDescRequired: this.options.titleDescRequired
            });
            
            if(this.views["#add-modal-outlet"]) {
                this.views["#add-modal-outlet"].remove();
            }

            // Set the view
            this.setView("#add-modal-outlet", addTemplateModal).render();
        },
    });

    return TemplateManagementBody;
});