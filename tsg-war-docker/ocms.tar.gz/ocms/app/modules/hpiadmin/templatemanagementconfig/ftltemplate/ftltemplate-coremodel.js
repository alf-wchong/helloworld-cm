define([
        "app"
    ],

    function(app) {
        "use strict";

        var FTLTemplateManagementCoreModel = app.module();

        FTLTemplateManagementCoreModel.Config = Backbone.Model.extend({
            idAttribute: "FTLTemplateManagement",
            defaults: function() {
                return {
                    configuredTemplates: new FTLTemplateManagementCoreModel.TemplateShellCollection()
                };
            },
            parse: function(attrsObj){
                attrsObj.configuredTemplates = new FTLTemplateManagementCoreModel.TemplateShellCollection(attrsObj.configuredTemplates, {parse:true});
                return attrsObj;
            },
        });

        /* Stored in default config file.
         * Serves as a reference to the actual template model
         * And the document the template is based on
         */
        // This represents the template models we have already configured
        FTLTemplateManagementCoreModel.TemplateShellModel = Backbone.Model.extend({
            idAttribute: 'FTLTemplate',
            defaults: function() {
                return {
                    name: '',
                    filename: ''
                };
            },
            parse: function(attrsObj) {
                return attrsObj;
            }
        });

        //Collection of template (shell) models, stored in default config
        FTLTemplateManagementCoreModel.TemplateShellCollection = Backbone.Collection.extend({
            idAttribute: 'FTLTemplateCol',
            model: FTLTemplateManagementCoreModel.TemplateShellModel,
            comparator: 'name',
            parse: function(modelsArr){
                _.each(modelsArr, function(model, index){
                    modelsArr[index] = new FTLTemplateManagementCoreModel.TemplateShellModel(model, {parse:true});
                });
                return modelsArr;
            }
        });
        return FTLTemplateManagementCoreModel;
    });