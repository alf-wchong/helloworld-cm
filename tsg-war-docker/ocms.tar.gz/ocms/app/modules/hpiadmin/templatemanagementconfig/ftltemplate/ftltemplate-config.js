// Objecttypeconfig module
define([
        "app",
        "modules/hpiadmin/templatemanagementconfig/templatemanagementbody"
    ],

    function(app, TemplateManagementBody) {
        "use strict";

        var FTLTemplateManagementConfig = app.module();

        FTLTemplateManagementConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/templatemanagementtabtitle",
            className: "FTLTemplateManagementConfig",
            events: {
            },
            initialize: function(options) {
                var that = this;

                this.ocTemplEventBus = _.extend({}, Backbone.Events);

                //Eventually we will want to get the correct configs passed in. 
                this.config = options.model.get("FTLTemplateConfig");
                this.configuredTemplates = this.config.get('configuredTemplates');

                this.removeViewIfExisting("#template-management-config-tab-body");
                this.bodyView = new TemplateManagementBody.Views.Layout({
                    collection: this.configuredTemplates,
                    ocTemplEventBus: this.ocTemplEventBus,
                    templateTypeDesc: window.localize("templateManagementConfig.freeMarkerTemplateConfig.description"),
                    tsgTemplateTypeParam: "ftl",
                    downloadType: "ftl",
                    targetTypeDropdown: false,
                    nameReadonly: true,
                    titleDescRequired: true
                });
                that.setView("#template-management-config-tab-body", this.bodyView);
            },
            removeViewIfExisting: function(viewSelector) {
                if(this.views[viewSelector]) {
                    this.views[viewSelector].remove();
                }
            },
            serialize: function(){
                return {
                    configTitle: window.localize("templateManagementConfig.freeMarkerTemplateConfig.freeMarkerTemplate")
                };
            }
        });

        return FTLTemplateManagementConfig;

    });