// Objecttypeconfig module
define([
        "app",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-doc",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-dropdown",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-body",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-coremodel"
    ],

    function(app, AWTemplateManagementDoc, AWTemplateManagementDropdown, AWTemplateManagementBody, AWTemplateManagementCoreModel) {
        "use strict";

        var AWTemplateManagementConfig = app.module();

        AWTemplateManagementConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-config",
            className: "AWTemplateManagementConfig",
            events: {
            },
            initialize: function(options) {
                var that = this;

                this.ocTemplEventBus = _.extend({}, Backbone.Events);

                //Eventually we will want to get the correct configs passed in. 
                this.config = options.model.get("awTemplateConfig");
                this.configuredTemplates = this.config.get('configuredTemplates');

                this.removeViewIfExisting("#ocDropdown");
                this.dropdownView = new AWTemplateManagementDropdown.Views.Layout({
                    collection: this.configuredTemplates,
                    ocTemplEventBus: this.ocTemplEventBus
                });
                that.setView("#ocDropdown", this.dropdownView);

                this.removeViewIfExisting("#templatemanagementdoc");
                this.docView = new AWTemplateManagementDoc.Views.Layout({
                    modelName: '',
                    ocTemplEventBus: this.ocTemplEventBus
                });
                that.setView("#templatemanagementdoc", this.docView).render();

                this._startListening();


            },
            serialize: function() {

                return {
                };
            },
            _startListening: function() {
                this.listenTo(this.ocTemplEventBus, "dropdownSelectionChanged", this.dropdownSelectionChanged);
                this.listenTo(this.ocTemplEventBus, "newTemplateUploaded", function(newTemplateModel) {
                    var shellTemplateModel = this.getShellFromFullTemplate(newTemplateModel);
                    this.addTemplateToCollection(shellTemplateModel);
                });
                this.listenTo(this.ocTemplEventBus, "saveConfigRequested", this.saveAWTemplateConfigs);
                this.listenTo(this.ocTemplEventBus, "deleteTemplateRequested", this.deleteTemplate);
                this.listenTo(this.ocTemplEventBus, "newVersionRequested", this.changeVersion);
            },
            dropdownSelectionChanged: function(newTemplateName){
                
                var self = this;

                //Repopulate doc view
                self.removeViewIfExisting("#templatemanagementdoc");
                self.docView = new AWTemplateManagementDoc.Views.Layout({
                    modelName: newTemplateName,
                    ocTemplEventBus: self.ocTemplEventBus
                });
                self.setView("#templatemanagementdoc", self.docView).render();


                //Find full template and repopulate body view with it
                app.context.findOrCreateConfig(AWTemplateManagementCoreModel.TemplateModel, newTemplateName).fetch({
                    success: function(templateModel) {
                        self.removeViewIfExisting("#templatemanagementbody");
                        self.bodyView = new AWTemplateManagementBody.Views.Layout({
                            model: templateModel,
                            ocTemplEventBus: self.ocTemplEventBus
                        });
                        self.setView("#templatemanagementbody", self.bodyView).render();
                    },
                    error: function() {
                        app.trigger("alert:error", {
                            header: window.localize("generic.alert"),
                            message: window.localize("modules.hpiAdmin.formConfig.formConfig.weAreUnable")
                        });
                    }
                });
            },
            getShellFromFullTemplate: function(templateModel) {
                 var shellTemplate = new AWTemplateManagementCoreModel.TemplateShellModel();
                 shellTemplate.set("name", templateModel.get("name"));
                 shellTemplate.set("filename", templateModel.get("filename"));
                 return shellTemplate;
            },
            addTemplateToCollection: function(templateModel){
                
                //Add new template to collection
                this.configuredTemplates.add(templateModel);

                //Save config model with new template in it
                this.saveAWTemplateConfigs();

            },
            saveAWTemplateConfigs: function(){
                this.options.model.set("awTemplateConfig", this.config);
                this.options.model.save();
            },
            deleteTemplate: function(templateName){

                //Find template to delete
                var template = this.configuredTemplates.findWhere({name: templateName});

                //Remove from config model
                this.configuredTemplates.remove(template);

                //Save configs
                this.saveAWTemplateConfigs();

                //Reset the subviews
                this.resetDocAndBodyViews();

                //Throw event to delete template from backend
                this.ocTemplEventBus.trigger("templateDeleted", template);
            },
            changeVersion: function(templateName, newMailMergeData) {
                
                var self = this;

                //Find template model
                app.context.findOrCreateConfig(AWTemplateManagementCoreModel.TemplateModel, templateName).fetch({
                    success: function(templateModel) {
                        
                        //Update MMF
                        templateModel.get("configuredTypes").models[0].set("mailMergeData", newMailMergeData);

                        //Save template changes
                        templateModel.save();

                        //Change dropdown selection to this model
                        self.ocTemplEventBus.trigger("templateVersionUpdated", templateModel); 
                    },
                    error: function() {
                        app.trigger("alert:error", {
                            header: window.localize("generic.alert"),
                            message: window.localize("modules.hpiAdmin.formConfig.formConfig.weAreUnable")
                        });
                    }
                });
            },
            resetDocAndBodyViews: function(){

                //Reset doc view with empty model
                this.removeViewIfExisting("#templatemanagementdoc");
                this.docView = new AWTemplateManagementDoc.Views.Layout({
                    modelName: '',
                    ocTemplEventBus: this.ocTemplEventBus
                }); 
                this.setView("#templatemanagementdoc", this.docView).render();

                //Just remove body view
                this.removeViewIfExisting("#templatemanagementbody");
            },
            removeViewIfExisting: function(viewSelector) {
                if(this.views[viewSelector]) {
                    this.views[viewSelector].remove();
                }
            }
        });

        return AWTemplateManagementConfig;

    });