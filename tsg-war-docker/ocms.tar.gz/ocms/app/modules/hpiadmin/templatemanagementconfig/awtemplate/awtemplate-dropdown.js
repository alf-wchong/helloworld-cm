define([
        "app",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-modals"
    ],

    function(app, AWTemplateManagementModals) {
        "use strict";

        var AWTemplateManagementDropdown = app.module();

        AWTemplateManagementDropdown.Views.Layout = Backbone.Layout.extend({

            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-dropdown",
            events: {
                "change #octemplateselect": "selectionChanged",
                "click #delete-template-button": "deleteTemplate",
            },

            initialize: function(options) {
                this.options = options;
                this.existingTemplate = [];
                this.populateDropdown(true); //this calls render()
                this._startListening();

            },

            _startListening: function() {
                this.listenTo(this.options.collection, "add", function(newTemplate) {
                    this.populateDropdown(false, newTemplate);
                });
                this.listenTo(this.options.collection, "remove", function() {
                    this.populateDropdown(true);
                });
                this.listenTo(this.options.ocTemplEventBus, "templateVersionUpdated", function(template) {
                    this.populateDropdown(false, template);
                });
            },

            populateDropdown: function(selectDefault, selectModel) {
                var self = this;

                self.existingTemplate = [];
                self.options.collection.each(function(model) {
                    if(model.get("name")) {

                        var selected = false;
                        if(selectModel && (model.get("name") === selectModel.get("name"))) {
                            selected = true;
                        }

                        self.existingTemplate.push({
                            value: model.get("name"),
                            label: model.get("name"),
                            selected: selected
                        });
                    }
                }, self);

                //If true, selects the disabled help text
                //Otherwise, one of the selected values in existingTemplate should be true
                self.selectDefault = selectDefault;

                self.render();

                //If selecting non-default model, simulate selection changed event
                if(selectModel) {
                    this.selectedTemplateName = selectModel.get("name");
                    this.notifyModelOfChangedSelection(this.selectedTemplateName);
                }
            },

            serialize: function() {
                return {
                    existingTemplate: this.existingTemplate,
                    selectDefault: this.selectDefault
                };
            },

            selectionChanged: function() {
                this.selectedTemplateName = $("#octemplateselect option:selected").val();
                this.notifyModelOfChangedSelection(this.selectedTemplateName);
            },

            notifyModelOfChangedSelection: function(selectionName) {
                this.options.ocTemplEventBus.trigger("dropdownSelectionChanged", selectionName);
            },

            deleteTemplate: function() {
                this.selectedTemplateName = $("#octemplateselect option:selected").val();

                //Create confirmation modal
                var confirmationModal = new AWTemplateManagementModals.DeleteTemplateModal({
                    templateName: this.selectedTemplateName,
                    ocTemplEventBus: this.ocTemplEventBus
                });

                if(this.views["#confirmation-modal-outlet"]) {
                    this.views["#confirmation-modal-outlet"].remove();
                }
                this.setView("#confirmation-modal-outlet", confirmationModal).render();
            }
        });

        return AWTemplateManagementDropdown;
    });