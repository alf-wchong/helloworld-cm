// templatemanagementattribute module
define([
        "app",
        "handlebars",
        "module",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-coremodel"

    ],

    // Map dependencies from above array.
    function(app, handlebars, module, AWTemplateManagementCoreModel) {

        // Create a new module.
        var AWTemplateManagementAttribute = app.module();

        // Model View.
        AWTemplateManagementAttribute.Views.Model = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-model",
            tagName: "tr",
            events: {
                "keyup input.form-control.questionTextInput": "updatequestionTextDebounced",
                "click span.icon-delete": "removeAttribute",
                "change select.form-control.controlType": "updateAttribute",
                "change input.checkbox": "updateCheckbox",
                "updateOtherCollection": "updateOtherCollection",
                "updateSameCollection": "updateSameCollection",
                "click .control-options": "clickControlOptions"
            },
            initialize: function() {
                var that = this;
                this.questionText = this.model.get("questionText");
                this.keysHelper = this.options.keysHelper;

                that.setViews({
                    ".control-options-subview-outlet": new AWTemplateManagementAttribute.Views.ControlOptions({
                        model: that.model,
                        picklists: that.options.picklists,
                        keysHelper: this.options.keysHelper
                    }),
                    ".control-rules-subview-outlet": new AWTemplateManagementAttribute.Views.ControlRules({
                        model: that.model,
                        keysHelper: this.options.keysHelper
                    }),
                });

                handlebars.registerHelper("optionsvisible", function(options) {
                    // any controls that DON'T have additional options should be specified here;
                    var optionControls = ["Hidden", "ProximityDateSearch", "NONE"];
                    if (_.contains(optionControls, this.controlType)) {
                        return "";
                    }
                    return options.fn(this);
                });

                //This helper determines what control should be selected in the controlType
                //dropdown for each attribute
                handlebars.registerHelper("control", function(options) {
                    //options.hash.currentOption is the value of the current option from the
                    //template
                    //if this matches the model's controlType, then we should return selected
                    if (this.controlType === options.hash.currentOption) {
                        return "selected";
                    } else {
                        return "";
                    }
                });
            },
            serialize: function() {
                return {
                    mailMergeField: this.model.get("mailMergeField"),
                    questionText: this.model.get("questionText"),
                    controlType: this.model.get("controlType"),
                    formEditable: this.model.get("formEditable"),
                    editable: this.model.get("editable"),
                    required: this.model.get("required"),
                    repeating: this.model.get("repeating"),
                    dataType: this.model.get("dataType"),
                    appendOnly: this.model.get("appendOnly"),
                    cid: this.model.cid,
                    selectAllEnabled: this.model.get("selectAllEnabled")
                };
            },
            removeAttribute: function(event) {
                //update our keysHelper
                this.keysHelper.set("unconfiguredMailMergeKeys",
                    _.union(this.keysHelper.get("unconfiguredMailMergeKeys"), this.model.get("mailMergeField")));
                this.keysHelper.set("configuredMailMergeKeys",
                    _.without(this.keysHelper.get("configuredMailMergeKeys"), this.model.get("mailMergeField")));

                //tell the collection of templatemanagementattributes that one was removed
                this.keysHelper.trigger("configuredMailMergeKeysRemoval", this.model);
            },
            updateAttribute: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];

                this.model.set(attrToSet, event.target.value);

                if (event.target.value === "Computed") {
                    this.model.set('editable', false);
                }

                this.render();
            },
            updateCheckbox: function(event) {
                var notOnModel = ["cascading"];
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];

                if (!_.contains(notOnModel, attrToSet)) {
                    this.model.set(attrToSet, event.target.checked);
                }

                // appendOnly can only be set to true when repeating and editable are true
                if (attrToSet === "repeating" || attrToSet === "editable") {
                    if (!this.model.get('repeating') || !this.model.get('editable')) {
                        this.model.set('appendOnly', false);
                    }
                }

                this.render();
            },
            updateOtherCollection: function(event, index) {
                //everytime we move the templatemanagementattribute, need to sort the attributes correctly
                //the boolean tells the sort that the attribute is from the other
                this.keysHelper.trigger("AWTemplatemanagementattribute:sort", this.model, index, false);
            },
            updateSameCollection: function(event, index) {
                //everytime we move the templatemanagementattribute, need to sort the attributes correctly
                //the boolean tells the sort that the attribute is from the same
                this.keysHelper.trigger("AWTemplatemanagementattribute:sort", this.model, index, true);
            },
            updatequestionTextDebounced: _.debounce(function(event) {
                var newquestionText = event.target.value;
                this.model.set("questionText", event.target.value);
                this.$("label.questionTextLabel").html(newquestionText);
            }, 200),
            clickControlOptions: function(event) {
                if (event.stopPropagation) { // W3C/addEventListener()
                    event.stopPropagation();
                } else { // Older IE.
                    event.cancelBubble = true;
                }
            }
        });

        AWTemplateManagementAttribute.Views.Collection = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-collection",
            initialize: function() {
                this.keysHelper = this.options.keysHelper;
                this.picklists = this.options.picklists;
                this.parentCid = this.options.typeCid;

                // We debounce here, because addAll would spam render()'s for each attribute added.
                this.listenTo(this.collection, "add", _.debounce(function() {
                    this.render();
                }), 100);
                this.listenTo(this.collection, "remove", function() {
                    this.render();
                });

                this.listenTo(this.keysHelper, "configuredMailMergeKeysRemoval", function(model) {
                    this.collection.remove(model);
                });

                this.listenTo(this.keysHelper, "configuredMailMergeKeysAddition", this.addMailMergeKey);

                this.listenTo(this.keysHelper, "AWTemplatemanagementattribute:sort", function(model, position, sameCollection) {
                    //both model views will fire the sort event, need to make sure we only
                    //manipulate the collection where the model is located
                    if (this.collection.get(model)) {
                        this.collection.remove(model);
                        if (sameCollection) {
                            this.collection.add(model, {
                                at: position
                            });
                        }
                    } else if (!sameCollection) {
                        this.collection.add(model, {
                            at: position
                        });
                    }
                });
            },
            addMailMergeKey: function(key) {
                if (this.options.keysHelper.get("keyInfo")[key].type === "date") {
                    control = "DateBox";
                } else {
                    control = "TextBox";
                }

                //This replaces any underscores with spaces and capitalizes the first letters of all words.
                var questionText = key.replace(/_/g, " ").replace(/\w\S*/g, function(txt) {
                    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
                });

                this.collection.add(new AWTemplateManagementCoreModel.AttributeModel({
                    mailMergeField: key,
                    questionText: questionText,
                    controlType: control,
                    editable: true,
                    formEditable: true,
                    required: false,
                    repeating: false,
                    dataType: "string",
                    parentAspect: null
                }));
            },
            beforeRender: function() {
                var that = this;

                if (this.collection) {
                    this.collection.each(function(templateManagementAttribute) {
                        that.insertView("#templatemanagementattributecollection-" + that.cid, new AWTemplateManagementAttribute.Views.Model({
                            model: templateManagementAttribute,
                            picklists: that.picklists,
                            keysHelper: that.keysHelper
                        }));
                    });
                }
            },
            serialize: function() {
                return {
                    cid: this.cid,
                    empty: this.collection.length > 0 ? false : true
                };
            },
            afterRender: function() {
                var self = this;
                self.startCount = 0;
                //this makes sure that both tbody's that have this class are rendered before
                //we attach the sortable class
                //we don't use this.$() selector since a separate views add the tbody's
                // also: make sure we're only applying the sortable to the decendants of THIS TYPE (or it breaks) (this.parentCid is passed from the parent formtype.model)
                this.sortableElements = $(".templatemanagementtype-" + this.parentCid + " .sortable-attributes");
                if (this.sortableElements.length === 1) {
                    this.sortableElements.sortable({
                        connectWith: ".templatemanagementtype-" + this.parentCid + " .sortable-attributes",
                        revert: true,
                        receive: function(event, ui) {
                            ui.item.trigger("updateOtherCollection", ui.item.index());
                        },
                        stop: function(event, ui) {
                            if (this === ui.item.parent()[0]) {
                                ui.item.trigger("updateSameCollection", ui.item.index());
                            }
                            self.sortableElements.find(".dropzone").remove();
                            self.startCount = 0;
                        },
                        start: function(event, ui) {
                            // this is NOT scoped to self -- because we want to find the elements outside this view in the DOM (dont want to trigger events in order to bubble up)
                            if (self.startCount === 0) {
                                self.sortableElements.append("<tr class='dropzone' style='border:2px dashed #f2dede; border-radius:6px'><td colspan='9' style='text-align:center'>Drop Here</td></tr>");
                                self.startCount++;
                            }
                        }
                    });
                }

                // init any tooltips
                this.$("span").tooltip();
            }
        });

        AWTemplateManagementAttribute.Views.ControlRules = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-control-rules",
            events: {
                "change .control-rules .control-options select.select": "updateAttribute",
                "keyup .control-rules input.dependantAttr-input": "updateAttributeVal",
                "change .control-rules input.checkbox-inline": "updateCheckbox"
            },
            initialize: function() {
                handlebars.registerHelper("checkAttrIsSelected", function(attr, selected) {
                    return attr == selected ? 'selected' : '';
                });
            },
            updateCheckbox: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                this.model.set(attrToSet, event.target.checked);

                if (attrToSet === 'visibilityDependent') {
                    app.trigger("renderVisibilityDependantWarning");
                    // if visibilityDependent is being unchecked, if so need to reset dependantAttr
                    if (!event.target.checked) {
                        this.model.set('dependantAttr', '');
                        this.model.set('dependantAttrVal', '');
                    }
                }
                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            updateAttribute: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                this.model.set(attrToSet, event.target.value);

                if (attrToSet === 'dependantAttr') {
                    app.trigger('renderVisibilityDependantWarning');
                }
                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },

            updateAttributeVal: _.debounce(function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                this.model.set(attrToSet, event.target.value);

                if (attrToSet === 'dependantAttrVal') {
                    app.trigger('renderVisibilityDependantWarning');
                }
                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            }, 1000),

            serialize: function() {
                // add a blank value at the beginning if one isn't present
                return {
                    cid: this.model.cid,
                    hidden: this.model.get('hidden'),
                    rememberLastSearchTerm: this.model.get('rememberLastSearchTerm'),
                    visibilityDependent: this.model.get('visibilityDependent'),
                    mailMergeKeys: this.options.keysHelper.get("mailMergeKeys"),
                    dependantAttr: this.model.get('dependantAttr'),
                    parentAspect: this.model.get('parentAspect'),
                    dependantAttrVal: this.model.get("dependantAttrVal"),
                    hideWhenNoAspect: this.model.get('hideWhenNoAspect')
                };
            }
        });

        AWTemplateManagementAttribute.Views.ControlExternalRules = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-external-control-rules",
            events: {
                "click .remove-external-rule": "removeExternalRule",
                "click #clearInvalidValueEnabledInput": "updateClearInvalidValueEnabled",
                "change .select-external-rule": "updateAttributeVal",
                "blur #failureMessageInput": "updateFailureMessage"
            },
            initialize: function() {
                var self = this;
                self.visible = module.config().availableConditions && module.config().availableConditions.length > 0;

                self.failureMessage = self.model.get("failureMessage");
                self.clearInvalidValueEnabled = self.model.get("clearInvalidValueEnabled");

                self.configuredExternalRules = _.clone(module.config().availableConditions);
                _.each(self.model.get("externalRules"), function(rule) {
                    self.configuredExternalRules = _.reject(self.configuredExternalRules, function(optionRule) {
                        return optionRule.ruleValue === rule.ruleValue;
                    });
                });
                //add blank string to beginning, for visibility, if any rules are left on our array
                if (!_.isEmpty(self.configuredExternalRules)) {
                    self.configuredExternalRules.unshift({
                        ruleLabel: "",
                        ruleValue: ""
                    });
                }
            },
            updateAttributeVal: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                if (attrToSet !== "externalRules") {
                    app.logger.warn(window.localize("modules.hpiAdmin.formConfig.formAttribute.warning"));
                }
                if (event.target.value === "") {
                    return; //do nothing if it's selected the blank
                }
                var conditions = this.model.get(attrToSet);
                if (!conditions) {
                    conditions = [];
                }
                var ruleToAdd;
                this.configuredExternalRules = _.reject(this.configuredExternalRules, function(rule) {
                    if (rule.ruleValue === event.target.value) {
                        ruleToAdd = rule;
                        return true;
                    }
                });
                conditions.push(ruleToAdd);
                this.model.set(attrToSet, conditions);

                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            updateClearInvalidValueEnabled: function(event) {
                var self = this;
                self.clearInvalidValueEnabled = event.target.checked;
                self.model.set("clearInvalidValueEnabled", self.clearInvalidValueEnabled);
            },
            updateFailureMessage: function(event) {
                var self = this;
                self.failureMessage = event.target.value;
                self.model.set("failureMessage", self.failureMessage);
            },
            removeExternalRule: function(event) {
                event.stopPropagation();
                var self = this;
                var val = event.currentTarget.attributes.value.value;
                var removedRule;
                var filteredRules = _.reject(this.model.get("externalRules"), function(rule) {
                    if (rule.ruleValue === val) {
                        removedRule = rule;
                        return true;
                    }
                });
                this.model.set("externalRules", filteredRules);
                this.configuredExternalRules.push(removedRule);
                if (this.configuredExternalRules.length === 1) {
                    self.configuredExternalRules.unshift({
                        ruleLabel: "",
                        ruleValue: ""
                    });
                }
                this.render();
            },
            serialize: function() {
                return {
                    cid: this.model.cid,
                    externalRules: this.model.get("externalRules"),
                    allExternalRules: this.configuredExternalRules,
                    visible: this.visible,
                    failureMessage: this.failureMessage,
                    clearInvalidValueEnabled: this.clearInvalidValueEnabled
                };
            }
        });

        AWTemplateManagementAttribute.Views.ControlOptions = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-control-options",
            events: {
                "click .control-options #computedAttr-button": "updateComputedPattern",
                "change .control-options select.select": "updateAttribute",
                "change .control-options input.input": "updateAttribute",
                "keyup .control-options input.regexRuleInput": "updateAttributeDebounced",
                "keyup .control-options input.defaultValueInput": "updateDefaultValueDebounced",
                "change .control-options input.checkbox": "updateCheckbox",
                "change .control-options textarea.input": "updateAttribute",
                "click .glyphicon-remove": "updateAttributeRemove",
                "click .control-options button.btn": "updateAttributeRemove",
                "keyup .control-options input.minCharBeforeQuery": "updateAttributeDebounced",
                "change .predefinedRegex": "updatePredefinedRegex"

            },
            initialize: function() {
                var self = this;
                //This helper determines if the timestamped and onlyNewEntries
                //checkboxes should be displayed
                handlebars.registerHelper("timevisible", function() {
                    var timestampedControls = ["TextAreaList"];
                    //if the current controlType is one that doesn't need a timestamp and
                    //onlyNewEntries checkboxes, return style that doesn't display 
                    //the two checkboxes
                    if (!_.contains(timestampedControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                //This helper determines if the textbox select should be displayed
                handlebars.registerHelper("textboxvisible", function() {
                    var textbox = ["TextBox"];
                    if (!_.contains(textbox, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                //This helper determines if the textarea select should be displayed
                handlebars.registerHelper("textareavisible", function() {
                    var textarea = ["TextArea"];
                    if (!_.contains(textarea, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                //This helper determines if the picklist select should be displayed
                handlebars.registerHelper("pickvisible", function() {
                    var picklistControls = ["DropDown", "AutoComplete", "CheckBox", "RadioButton"];
                    //if the current controlType is one that doesn't need a picklist,
                    //return style that doesn't display the picklist select
                    if (!_.contains(picklistControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        //if the picklist control is being displayed, trigger a render
                        //on the warning display if the picklist is not set
                        app.trigger("renderPicklistWarning");
                        return "";
                    }
                });

                // This helper determines if the appendOnly checkbox should be displayed
                handlebars.registerHelper("appendOnlyVisible", function() {
                    var blacklistPicklistControls = ["CheckBox", "RadioButton, TextArea"];
                    // if the current controlType doesn't get appendOnly or repeating and editable are not both true
                    // return style that doesn't display it
                    if ((_.contains(blacklistPicklistControls, this.controlType)) || !(this.repeating === true && this.editable === true)) {
                        return "style='display:none;'";
                    }

                    return "";
                });

                //This helper determines what value should be selected in the picklist
                //dropdown for each attribute
                handlebars.registerHelper("pick", function(options) {
                    //options.hash.picklist is the value of picklist on the current model
                    //options.hash.currentOption is the value of the current option from the
                    //template
                    //if this matches the model's picklist, then we should return selected
                    if (options.hash.picklist === options.hash.currentOption) {
                        return "selected";
                    } else {
                        return "";
                    }
                });

                //This helper determines what value should be selected in the depndOn
                //dropdown for each attribute
                handlebars.registerHelper("depends", function(options) {
                    //options.hash.dependsOn is the value of dependsOn on the current model
                    //options.hash.currentOption is the value of the current option from the
                    //template
                    //if this matches the model's dependsOn, then we should return selected
                    if (options.hash.dependsOn === options.hash.currentOption) {
                        return "selected";
                    } else {
                        return "";
                    }
                });

                //This helper determines if the growable checkbox should be displayed
                handlebars.registerHelper("growvisible", function(options) {
                    var growableControls = ["AutoComplete"];
                    //if the current controlType is one that doesn't need a growable attr,
                    //return style that doesn't display the growable checkbox
                    if (!_.contains(growableControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                //This helper determines if the growable checkbox should be displayed
                handlebars.registerHelper("computedvisible", function(options) {
                    var computedControls = ["Computed"];
                    //if the current controlType is one that doesn't need a growable attr,
                    //return style that doesn't display the growable checkbox
                    if (!_.contains(computedControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                handlebars.registerHelper("datecontrolvisible", function(options) {
                    var dateControls = ["DateBox", "DatetimeBox"];
                    //if the current controlType is one that doesn't need a growable attr,
                    //return style that doesn't display the growable checkbox
                    if (!_.contains(dateControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });

                handlebars.registerHelper("readonlyvisible", function(options) {
                    var readOnlyControls = ["ReadOnly"];
                    // If the current controlType is ReadOnly, display it's configuration options
                    if (!_.contains(readOnlyControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });
                //This helper determines if the numeric range select should be displayed
                handlebars.registerHelper("numericrangevisible", function() {
                    var numericRangeControls = ["NumericRange"];
                    if (!_.contains(numericRangeControls, this.controlType)) {
                        return "style='display:none;'";
                    } else {
                        return "";
                    }
                });
                app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat) {
                    if (self.model.get("controlType") === "DatetimeBox") {
                        self.dateFormat = dateTimeFormat.dateFormat + " " + dateTimeFormat.timeFormat;
                    } else {
                        self.dateFormat = dateTimeFormat.dateFormat;
                    }
                });
            },
            afterRender: function() {
                this.$("span").tooltip();
                $('#predefinedRegex-' + this.model.cid + ' option:contains("' + this.model.get("predefinedRegex") + '")').prop("selected", true);
            },
            serialize: function() {
                var self = this;
                var cascading;
                if (this.$("#cascading-" + this.model.cid)[0]) {
                    cascading = this.$("#cascading-" + this.model.cid)[0].checked;
                } else {
                    cascading = this.model.get("dependsOn").length < 1 ? false : true;
                }
                var selectAllEnabled;
                if ($("#selectAllEnabled-" + this.model.cid)[0]) {
                    selectAllEnabled = $("#selectAllEnabled-" + this.model.cid)[0].checked;
                } else {
                    selectAllEnabled = this.model.get("selectAllEnabled");
                }

                // Get unconfigured attributes to display in ReadOnly control options.
                this.doPrettyConversions(this.options.keysHelper.get("unconfiguredMailMergeKeys"));

                // Remove all attributes from unconfiguredMailMergeKeys that are already configured
                _.each(this.model.get('readOnlyGroupedAttrs'), function(attrToAdd) {
                    self.options.keysHelper.set('unconfiguredMailMergeKeys', _.without(self.options.keysHelper.get('unconfiguredMailMergeKeys'), attrToAdd.mailMergeField));
                });



                return {
                    controlType: this.model.get("controlType"),
                    timestamped: this.model.get("timestamped"),
                    onlyNewEntries: this.model.get("onlyNewEntries"),
                    sectionId: this.model.get("sectionId"),
                    sectionName: this.model.get("sectionName"),
                    minChars: this.model.get("minChars"),
                    maxChars: this.model.get("maxChars"),
                    regex: this.model.get("regex"),
                    regexRule: this.model.get("regexRule"),
                    minCharBeforeQuery: this.model.get("minCharBeforeQuery"),
                    picklists: this.options.picklists,
                    picklist: this.model.get("picklist"),
                    cascading: cascading,
                    computedPattern: this.model.get("computedPattern"),
                    mailMergeKeys: this.options.keysHelper.get("mailMergeKeys"),
                    dependsOn: this.model.get("dependsOn"),
                    dependantAttr: this.model.get("dependantAttr"),
                    parentAspect: this.model.get('parentAspect'),
                    dependantAttrVal: this.model.get("dependantAttrVal"),
                    growable: this.model.get("growable"),
                    autoSelect: this.model.get("autoSelect"),
                    allowDropdown: this.model.get("allowDropdown"),
                    cid: this.model.cid,
                    canTypeInBox: this.model.get("canTypeInBox"),
                    enforceDateBeforeToday: this.model.get("enforceDateBeforeToday"),
                    enforceDateAfterToday: this.model.get("enforceDateAfterToday"),
                    repeating: this.model.get("repeating"),
                    editable: this.model.get("editable"),
                    selectAllEnabled: selectAllEnabled,
                    readOnlyGroupedAttrs: this.model.get('readOnlyGroupedAttrs'),
                    availableTypeAttrs: this.prettyunconfiguredMailMergeKeys,
                    helptext: this.model.get("helptext"),
                    defaultValue: this.model.get("defaultValue"),
                    defaultValueCurrentDate: this.model.get("defaultValueCurrentDate"),
                    makeSearchExact: this.model.get("makeSearchExact"),
                    appendOnly: this.model.get("appendOnly"),
                    upperCase: this.model.get("upperCase"),
                    caseSensitive: this.model.get("caseSensitive"),
                    dateFormat: this.dateFormat,
                    defaultValueInputError: this.defaultValueInputError,
                    predefinedRegex: this.model.get("predefinedRegex")
                };
            },
            updatePredefinedRegex: function(evt) {
                var attrToSet = event.target.id.split("-")[0];
                this.model.set(attrToSet, $("#" + event.target.id + " option:selected").text());
                this.model.set("regex", event.target.value);
                this.render();
                evt.stopPropagation();
            },
            updateComputedPattern: function(event) {
                this.model.set("computedPattern",
                    this.model.get("computedPattern") + "$" +
                    this.$("#computedAttrs-" + this.model.cid).find(":selected").text() + "$");

                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            updateAttribute: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                if (attrToSet === "dependsOn") {
                    this.updateDependsOnValue(event.target.value);
                } else if (attrToSet === 'readOnlyAvailableAttrs') {
                    this.addGroupedAttr(event);
                } else {
                    this.model.set(attrToSet, event.target.value);
                    this.render();
                }
                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            updateAttributeRemove: function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                if (attrToSet === "removeDependsOn") {
                    this.removeDependsOnValue(event);
                } else if (attrToSet === 'removeGroupedAttr') {
                    this.removeGroupedAttr(event);
                }
                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            updateAttributeDebounced: _.debounce(function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                this.model.set(attrToSet, event.target.value);
                if (attrToSet === 'regexRule') {
                    this.serialize();
                }
                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            }, 1000),
            updateDefaultValueDebounced: _.debounce(function(event) {
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                if (moment(event.target.value, this.dateFormat, true).isValid()) {
                    this.defaultValueInputError = false;
                    this.model.set(attrToSet, event.target.value);
                } else {
                    this.defaultValueInputError = true;
                }

                if (attrToSet === 'defaultValue') {
                    this.render();
                }
                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            }, 1000),
            updateDependsOnValue: function(value) {
                if (!(this.model.get("dependsOn") instanceof Array)) {
                    var tempArray = [];
                    if (this.model.get("dependsOn")) {
                        tempArray.push(this.model.get("dependsOn"));
                    }
                    this.model.set("dependsOn", tempArray);
                }
                if (value && this.model.get("dependsOn").indexOf(value) === -1) {
                    this.model.get("dependsOn").push(value);
                    this.render();
                    app.trigger("renderPicklistCascadeWarning", true, this.model.get("mailMergeField"));
                }
            },
            removeDependsOnValue: function(event) {
                event.stopPropagation();
                this.model.get("dependsOn").splice(this.model.get("dependsOn").indexOf($(event.target).attr("value")), 1);
                this.render();
                app.trigger("renderPicklistCascadeWarning", true, this.model.get("mailMergeField"));
            },
            updateCheckbox: function(event) {
                var notOnModel = ["cascading"];
                //get the attrName from the id, splitting out the cid attached
                var attrToSet = event.target.id.split("-")[0];
                if (!_.contains(notOnModel, attrToSet)) {
                    this.model.set(attrToSet, event.target.checked);
                } else if (_.contains(notOnModel, attrToSet) && event.target.checked && this.model.get("dependsOn").length === 0) {
                    //this means the cascading checkbox was selected, and dependsOn hasn't been set yet
                    //we need to add the first value in allAttrs
                    this.model.set("dependsOn", []);
                    app.trigger("renderPicklistCascadeWarning", event.target.checked, this.model.get("mailMergeField"));
                } else if (_.contains(notOnModel, attrToSet) && !event.target.checked) {
                    //this means the cascading checkbox was deselected, so we need to clear
                    //out the dependsOn attr
                    this.model.set("dependsOn", []);
                    app.trigger("renderPicklistCascadeWarning", event.target.checked, this.model.get("mailMergeField"));
                }
                this.render();

                // make sure we dont bubble up to the parent view or it will re-render this whole thing.
                event.stopPropagation();
            },
            // Add an attribute to the list of this model's read only control grouped attributes.
            addGroupedAttr: function(event) {
                // Get the questionText and value from the triggered event.
                var attrToAdd = {};
                attrToAdd.questionText = $(event.target).find(':selected').text().trim();
                attrToAdd.mailMergeField = event.currentTarget.value;

                // Add this item to the list of grouped attributes.
                this.model.get('readOnlyGroupedAttrs').push(attrToAdd);

                // Update our keysHelper since the attribte we have just added should be
                // removed from the list of attributes available to be configured.	
                this.keysHelper.set('configuredMailMergeKeys',
                    _.union(this.keysHelper.get('configuredMailMergeKeys'), attrToAdd.mailMergeField));
                this.keysHelper.set('unconfiguredMailMergeKeys',
                    _.without(this.keysHelper.get('unconfiguredMailMergeKeys'), attrToAdd.mailMergeField));

                this.render();
            },
            // Remove an already grouped attribute from the list of this model's read only control.
            removeGroupedAttr: function(event) {
                // Get the value from the triggered event.
                var attrToRemove = $(event.target).attr('value');

                // Remove this item from the list of existing grouped attributes.
                var oldArray = this.model.get('readOnlyGroupedAttrs');
                // Filter all values in the oldArray that do not match the new value, resulting in an array that does not contain the removed attribtue.
                // Take this returned array and set it to the model variable.
                this.model.set('readOnlyGroupedAttrs',
                    _.filter(oldArray, function(object) {
                        return object.mailMergeField !== attrToRemove;
                    })
                );

                // Update our keysHelper since the attribte we have just removed should be
                // added back to the list of attributes available to be configured.
                this.keysHelper.set('unconfiguredMailMergeKeys',
                    _.union(this.keysHelper.get('unconfiguredMailMergeKeys'), attrToRemove));
                this.keysHelper.set('configuredMailMergeKeys',
                    _.without(this.keysHelper.get('configuredMailMergeKeys'), attrToRemove));

                this.render();
            },
            //This takes an array of mailMergeField and turns them into an array of objects sorted by the "pretty" name.
            doPrettyConversions: function(arr) {
                var self = this;
                this.prettyunconfiguredMailMergeKeys = [];
                _.each(arr, function(attrmailMergeField) {
                    self.prettyunconfiguredMailMergeKeys.push({
                        'questionText': attrmailMergeField,
                        'mailMergeField': attrmailMergeField
                    });
                });
                //Sort
                this.prettyunconfiguredMailMergeKeys = _.sortBy(this.prettyunconfiguredMailMergeKeys, function(key) {
                    return this.keysHelper.get("keyInfo")[key.mailMergeField].ordinal;
                }, this);
            }
        });

        AWTemplateManagementAttribute.Views.VisibilityDependentWarning = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-visibilitydependswarning",
            initialize: function() {
                this.listenTo(app, "renderVisibilityDependantWarning", function() {
                    this.render();
                });

                handlebars.registerHelper("visibilityDependentWarning", function() {
                    if (this.visibilityDependent && (!this.dependantAttr || !this.dependantAttrVal)) {
                        return '';
                    } else {
                        return "style='display:none;'";
                    }
                });
            }
        });

        AWTemplateManagementAttribute.Views.Picklistwarning = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-picklistwarning",
            initialize: function() {
                this.listenTo(app, "renderPicklistWarning", function() {
                    this.render();
                });

                handlebars.registerHelper("picklistwarning", function(options) {
                    // any controls that DON'T have additional options should be specified here;
                    var picklistControls = ["DropDown", "AutoComplete", "MultiSelect",
                        "ConfigDropDown", "CheckBox", "RadioButton"
                    ];
                    if (_.contains(picklistControls, this.controlType) && this.picklist === "") {
                        return "";
                    } else {
                        return "style='display:none;'";
                    }
                });
            },
            serialize: function() {
                return {
                    controlType: this.model.get("controlType"),
                    picklist: this.model.get("picklist")
                };
            }
        });

        AWTemplateManagementAttribute.Views.PicklistCascadeWarning = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-picklistcascadewarning",
            initialize: function() {
                var self = this;
                this.listenTo(app, "renderPicklistCascadeWarning", function(isCascading, mailMergeField) {
                    if (self.model.get("mailMergeField") === mailMergeField) {
                        self.isCascading = isCascading;
                        self.render();
                    }
                });

                handlebars.registerHelper("picklistcascadewarning", function(options) {
                    // any controls that DON'T have additional options should be specified here;
                    var picklistControls = ["DropDown", "AutoComplete", "MultiSelect",
                        "ConfigDropDown", "CheckBox", "RadioButton"
                    ];
                    if (_.contains(picklistControls, this.controlType) && this.isCascading && !this.hasDependsOn) {
                        return "";
                    } else {
                        return "style='display:none;'";
                    }
                });
            },
            serialize: function() {
                return {
                    controlType: this.model.get("controlType"),
                    picklist: this.model.get("picklist"),
                    isCascading: this.isCascading,
                    hasDependsOn: this.model.get("dependsOn").length > 0 ? true : false
                };
            }
        });

        AWTemplateManagementAttribute.Views.UnconfiguredMailMergeKeys = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute-unconfiguredmailmergekeys",
            events: {
                "change #unconfigured-attrs-select": "addAttr"
            },
            initialize: function() {
                this.typeName = this.options.typeName;
                this.keysHelper = this.options.keysHelper;

                //to get filtering working like we expect, we need the list of uncofigured
                //attrs, but also another list that we use in the view

                this.keysHelper.set("unconfiguredMailMergeKeys", _.sortBy(this.keysHelper.get("unconfiguredMailMergeKeys"), function(key) {
                    return this.keysHelper.get("keyInfo")[key].ordinal;
                }, this));

                this.filteredAttrs = _.clone(this.keysHelper.get("unconfiguredMailMergeKeys"));

                this.listenTo(this.keysHelper, "change:unconfiguredMailMergeKeys", function() {
                    //the unconfiguredMailMergeKeys were changed somewhere, reset the viewableAttrs
                    this.keysHelper.trigger("AWTemplatemanagementattribute:filterAttrs");
                });

                this.listenTo(this.keysHelper, "AWTemplatemanagementattribute:filterAttrs", function(cid) {
                    //the cid is the "id" for the specific dropdown we are wanting to filter on. The cid is passed
                    //in when the Formtype.AttrControl view fires an event when someone starts typing
                    //in the filter input. 
                    var filterValue;
                    if (!$(".templatemanagementtypeattr-filter-" + cid)[0]) {
                        filterValue = $("#filter-attrs-input")[0].value;
                    } else {
                        filterValue = $(".templatemanagementtypeattr-filter-" + cid)[0].value;
                    }


                    //Get the unconfigured attrs.
                    this.doPrettyConversions(this.keysHelper.get("unconfiguredMailMergeKeys"));

                    //Filter based on the questionText
                    this.filteredAttrs = _.filter(this.prettyFilteredAttrs, function(attr) {
                        if (attr.questionText.toLowerCase().indexOf(filterValue.toLowerCase()) !== -1) {
                            return true;
                        } else {
                            return false;
                        }
                    });
                    //Sort the filtered results.
                    this.prettyFilteredAttrs = _.sortBy(this.filteredAttrs, function(key) {
                        return this.keysHelper.get("keyInfo")[key.mailMergeField].ordinal;
                    }, this);

                    this.render();
                });

                this.listenTo(this.keysHelper, "AWTemplatemanagementattribute:addAllAttrs", this.addAllAttrs);

                //Get the initial unconfigured attrs.
                this.doPrettyConversions(this.filteredAttrs);
            },
            //This takes an array of mailMergeFields and turns them into an array of objects sorted by the "pretty" name.
            doPrettyConversions: function(arr) {
                var self = this;
                this.prettyFilteredAttrs = [];
                _.each(arr, function(attr) {
                    self.prettyFilteredAttrs.push({
                        'questionText': attr,
                        'mailMergeField': attr
                    });
                });
                //Sort
                this.prettyFilteredAttrs = _.sortBy(this.prettyFilteredAttrs, function(key) {
                    return this.keysHelper.get("keyInfo")[key.mailMergeField].ordinal;
                }, this);
            },
            serialize: function() {
                return {
                    typeName: this.typeName,
                    filteredAttrs: this.prettyFilteredAttrs
                };
            },
            addAttr: function(event) {
                var that = this;
                // loop over each of the selected options (this is a multiple select box)
                this.$("option:selected").each(function() {
                    var mailMergeField = this.value;

                    //update our keysHelper
                    that.keysHelper.set("configuredMailMergeKeys",
                        _.union(that.keysHelper.get("configuredMailMergeKeys"), mailMergeField));
                    that.keysHelper.set("unconfiguredMailMergeKeys",
                        _.without(that.keysHelper.get("unconfiguredMailMergeKeys"), mailMergeField));

                    //tell the collection of templatemanagementattributes that one was added
                    that.keysHelper.trigger("configuredMailMergeKeysAddition", mailMergeField);
                });
            },
            addAllAttrs: function() {
                var that = this;
                // loop over all options
                this.$("option").each(function() {
                    var mailMergeField = this.value;

                    //update our keysHelper
                    that.keysHelper.set("configuredMailMergeKeys",
                        _.union(that.keysHelper.get("configuredMailMergeKeys"), mailMergeField));
                    that.keysHelper.set("unconfiguredMailMergeKeys",
                        _.without(that.keysHelper.get("unconfiguredMailMergeKeys"), mailMergeField));

                    //tell the collection of templatemanagementattributes that one was added
                    that.keysHelper.trigger("configuredMailMergeKeysAddition", mailMergeField);
                });
            }
        });

        AWTemplateManagementAttribute.Views.Attrcontrol = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-type-attrcontrol",
            events: {
                "keyup #filter-attrs-input": "filterAttrs",
                "click #filter-attrs-input": "clickFilterInput",
                "click button.close": "closeMenu",
                "click .unconfiguredMailMergeKeys-outlet": "keepViewOpen"
            },
            initialize: function() {
                this.hiddenFilter = false;
                this.repoType = this.options.repoType;
                this.keysHelper = this.options.keysHelper;
            },
            serialize: function() {
                return {
                    cid: this.cid
                };
            },
            beforeRender: function() {
                this.setViews({
                    ".unconfiguredMailMergeKeys-outlet": new AWTemplateManagementAttribute.Views.UnconfiguredMailMergeKeys({
                        keysHelper: this.keysHelper
                    })
                });
            },
            afterRender: function() {
                //since we just rendered, need to check if the attrs should be hidden or not
                if (this.hiddenFilter) {
                    this.$("#filter-attrs-div").hide();
                }
            },
            clickFilterInput: function(e) {
                // just stop clicking on the content from hiding the dropdown menu (events wont bubble)
                e.stopPropagation();
            },
            closeMenu: function(e) {
                $(e.currentTarget).parents(".btn-group").find(".btn").dropdown("toggle");
            },
            filterAttrs: function(event) {
                this.keysHelper.trigger("AWTemplatemanagementattribute:filterAttrs", this.cid);
            },
            keepViewOpen: function(e) {

                this.keysHelper.trigger("AWTemplatemanagementattribute:filterAttrs", this.cid);
                e.stopPropagation();
            }
        });


        // Return the module for AMD compliance.
        return AWTemplateManagementAttribute;

    });