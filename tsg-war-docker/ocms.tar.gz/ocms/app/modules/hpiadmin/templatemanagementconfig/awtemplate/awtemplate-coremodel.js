define([
        "app",
        "modules/hpiadmin/hpiadmin"
    ],

    function(app, Hpiadmin) {
        "use strict";

        var AWTemplateManagementCoreModel = app.module();

        AWTemplateManagementCoreModel.Config = Backbone.Model.extend({
            idAttribute: "AWTemplateManagement",
            defaults: function() {
                return {
                    configuredTemplates: new AWTemplateManagementCoreModel.TemplateShellCollection()
                };
            },
            parse: function(attrsObj){
                attrsObj.configuredTemplates = new AWTemplateManagementCoreModel.TemplateShellCollection(attrsObj.configuredTemplates, {parse:true});
                return attrsObj;
            },
        });

        /* Stored in default config file.
         * Serves as a reference to the actual template model
         * And the document the template is based on
         */
        // This represents the template models we have already configured
        AWTemplateManagementCoreModel.TemplateShellModel = Backbone.Model.extend({
            idAttribute: 'AWTemplate',
            defaults: function() {
                return {
                    name: '',
                    filename: ''
                };
            },
            parse: function(attrsObj) {
                return attrsObj;
            }
        });

        //Collection of template (shell) models, stored in default config
        AWTemplateManagementCoreModel.TemplateShellCollection = Backbone.Collection.extend({
            idAttribute: 'AWTemplateCol',
            model: AWTemplateManagementCoreModel.TemplateShellModel,
            comparator: 'name',
            parse: function(modelsArr){
                _.each(modelsArr, function(model, index){
                    modelsArr[index] = new AWTemplateManagementCoreModel.TemplateShellModel(model, {parse:true});
                });
                return modelsArr;
            }
        });


        /* Stored in template config files
         * EG: if template name is template1, the backbone model
         * is stored in configs/TemplateManagementConfig/template1
         */
        // This represents the template models we have already configured
        AWTemplateManagementCoreModel.TemplateModel = Hpiadmin.Config.extend({
            defaults: function() {
                return {
                    name: '',
                    filename: '',
                    type: 'TemplateManagementConfig',
                    configuredTypes: new AWTemplateManagementCoreModel.TypeCollection()
                };
            },
            initialize: function(options) {
                //Backbone doesn't support nesting Collections in Models OOTB, this initialize
                //lets us setup our internal collection
                if (options && options.configuredTypes) {
                    this.set("configuredTypes", new AWTemplateManagementCoreModel.TypeCollection(options.configuredTypes));  
                } else {
                    this.set("configuredTypes", new AWTemplateManagementCoreModel.TypeCollection());
                }
            },
            parseResponse: function(response) {
                //if this is the first time this config is loaded (id will be undefined),
                //then we need to build up the configured types without overwriting the
                //one that has already been init'ed. if the id is already present, then
                //the parse was hit after a save, and we are confident that the model we
                //already have is what is returned from the server, so remove config model
                //info from the response
                if (this.id) {
                    response = _.pick(response, 'id');
                } else if (response && response.configuredTypes) {
                    response.configuredTypes = new AWTemplateManagementCoreModel.TypeCollection(response.configuredTypes, {parse:true});
                }

                return response;
            }
        });

        //This represents a type the template is configured on
        AWTemplateManagementCoreModel.TypeModel = Backbone.Model.extend({
            idAttribute: 'AWType',
            defaults: function() {
                return {
                    mailMergeData: '',
                    configuredAttrs: new AWTemplateManagementCoreModel.AttributeCollection()
                };
            },
            parse: function(attrsObj) {
                attrsObj.configuredAttrs = new AWTemplateManagementCoreModel.AttributeCollection(attrsObj.configuredAttrs, {parse:true});
                return attrsObj;
            }
        });

        //This is the collection of types a template is configured on
        AWTemplateManagementCoreModel.TypeCollection = Backbone.Collection.extend({
            idAttribute: 'AWTypeCol',
            model: AWTemplateManagementCoreModel.TypeModel,
            parse: function(modelsArr){
                _.each(modelsArr, function(model, index){
                    modelsArr[index] = new AWTemplateManagementCoreModel.TypeModel(model, {parse:true});
                });
                return modelsArr;
            }
        });

        AWTemplateManagementCoreModel.AttributeModel = Backbone.Model.extend({
            idAttribute: 'AWAttribute',
            defaults: {
                mailMergeField: "",
                questionText: "",
                controlType: "",
                editable: false,
                formEditable: false,
                required: false,
                repeating: false,
                picklist: "",
                dataType: "",
                dependsOn: [],
                growable: false,
                autoSelect: false,
                allowDropdown: false,
                timestamped: false,
                onlyNewEntries: false,
                canTypeInBox: false,
                enforceDateBeforeToday: false,
                enforceDateAfterToday: false,
                sectionId: "",
                sectionName: "",
                minChars: "",
                maxChars: "",
                regex: "",
                regexRule: "",
                minCharBeforeQuery: app.minCharBeforeQuery,
                computedPattern: "",
                selectAllEnabled: false,
                readOnlyGroupedAttrs: [],
                helptext: "",
                defaultValue: "",
                defaultValueCurrentDate: false,
                makeSearchExact: false,
                upperCase: false,
                caseSensitive: false,
                parentAspect: ""
            },
            parse: function(model) {
                return model;
            }
        });

        AWTemplateManagementCoreModel.AttributeCollection = Backbone.Collection.extend({
            idAttribute: 'AWAttributeCol',
            model: AWTemplateManagementCoreModel.AttributeModel,
            parse: function(modelsArr){
                _.each(modelsArr, function(model, index){
                    modelsArr[index] = new AWTemplateManagementCoreModel.AttributeModel(model, {parse:true});
                });
                return modelsArr;
            }
        });

        return AWTemplateManagementCoreModel;
    });