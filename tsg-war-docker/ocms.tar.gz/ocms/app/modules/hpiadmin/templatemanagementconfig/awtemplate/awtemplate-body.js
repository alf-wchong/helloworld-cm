define([
        "app",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-type",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-coremodel",
        "modules/hpiadmin/picklistconfig/picklistconfig",
    ],

    function(app, AWTemplateManagementType, AWTemplateManagementCoreModel, PicklistConfig) {
        "use strict";

        var AWTemplateManagementBody = app.module();

        AWTemplateManagementBody.Views.Layout = Backbone.Layout.extend({

            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-body",
            className: "AWTemplateManagementBody",
            events: {
                "click #saveform-btn": "saveForm"
            },

            initialize: function(options) {
                var that = this;

                this.options = options;

                if(options.model instanceof Backbone.Model){
                    this.model = options.model;
                } else { //Don't make a model of a model
                    this.model = new AWTemplateManagementCoreModel.TemplateModel(options.model);
                }
            
                if (this.model.get("name")) {
                    //we are in 'edit' mode
                    this.listenTo(this.model, "sync", function() {
                        that.render();
                    });
                }

                this._startListening();

                this.picklists = [];

                this.uploadFile = null;
                this.uploadFileName = "";

                this.selectUploadElement = ".fileuploader-input";

                this.selectVersionElement = ".fileversion-input";

                this.populatePicklist();
                
            },
            _startListening: function() {
                this.listenTo(this.model.get("configuredTypes"), "add", function() {
                    that.populatePicklist();
                });
                this.listenTo(this.model.get("configuredTypes"), "remove", function() {
                    that.populatePicklist();
                });
                this.listenTo(this.options.ocTemplEventBus, "deleteTemplateRequested", function() {
                    this.model.destroy();
                });
            },
            serialize: function() {
                var createMode = false;
                if (!this.model.get("name")) {
                    createMode = true;
                }

                return {
                    createMode: createMode,
                    form: this.model && this.model.attributes,
                };
            },
            populatePicklist: function() {
                var self = this;
                app.context.findOrCreateConfig(PicklistConfig.Model, "default").fetch({
                    success: function(picklistConfig) {
                        self.picklists = picklistConfig.get("picklists").pluck("label");
                        //add a blank value to the beginning of the array
                        self.picklists.splice(0, 0, "");
                        self.setViews({
                            "#templatemanagementtypecollection-outlet": new AWTemplateManagementType.Views.Collection({
                                collection: self.model.get("configuredTypes"),
                                picklists: self.picklists
                            })
                        });
                        self.render();
                    },
                    error: function() {
                        app.trigger("alert:error", {
                            header: window.localize("generic.alert"),
                            message: window.localize("modules.hpiAdmin.formConfig.formConfig.weAreUnable")
                        });
                    }
                });
            },
            saveForm: function() {
                this.model.save();
                this.options.ocTemplEventBus.trigger("saveConfigRequested");
            }
        });

        return AWTemplateManagementBody;

    });