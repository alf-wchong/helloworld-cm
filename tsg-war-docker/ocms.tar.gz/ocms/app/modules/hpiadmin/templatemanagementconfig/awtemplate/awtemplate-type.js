// Formtype module
define([
        "app",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-attribute",
    ],

    // Map dependencies from above array.
    function(app, AWTemplateManagementAttribute) {

        // Create a new module.
        var AWTemplateManagementType = app.module();

        AWTemplateManagementType.Views.Collection = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-type-collection",
            initialize: function() {
                var that = this;
            },
            beforeRender: function() {
                var that = this;
                var configuredTypesNames = _.map(this.collection.models, function(tempModel) {
                    return tempModel.get("ocName");
                });
                //need a blank value at the beginning
                configuredTypesNames.unshift("");

                if (this.collection && this.collection.length > 0) {
                    this.collection.each(function(templateManagementType) {
                        that.insertView("#templatemanagementtypecollection-" + that.cid, new AWTemplateManagementType.Views.Model({
                            model: templateManagementType,
                            picklists: that.options.picklists,
                            configuredTypesNames: configuredTypesNames
                        }));
                    });
                }
            },
            serialize: function() {
                return {
                    cid: this.cid
                };
            }
        });

        // Default View.
        AWTemplateManagementType.Views.Model = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-type-model",
            events: {
                "click #add-all-attrs": "addAllTypes",
                "change select.attribute-overrideType": "updateAttribute",
            },
            defaults: {
                mailMergeData: {}
            },
            initialize: function() {
                this.ui = {};

                var keyInfo = this.model.get("mailMergeData");
                var mailMergeKeys = _.sortBy(Object.keys(keyInfo), function(key) {
                    return keyInfo[key].ordinal;
                });
                var configuredMailMergeKeys = [];

                _.each(this.model.get("configuredAttrs").models, function(configuredKey) {
                    configuredMailMergeKeys.push(configuredKey.get("mailMergeField"));
                });

                // These are all unconfigured MM Keys (and any new keys)
                var unconfiguredMailMergeKeys = _.difference(mailMergeKeys, configuredMailMergeKeys);

                // These are the MM keys that no longer exist and therefore should be removed
                var mmKeysToRemove = _.difference(configuredMailMergeKeys, mailMergeKeys);

                //These are the configured MM keys that should stay
                configuredMailMergeKeys = _.difference(configuredMailMergeKeys, mmKeysToRemove);

                // The final step is to actually remove the attrs from the attr collection
                var newModels = this.model.get("configuredAttrs").reject(function(attr) {
                    return _.contains(mmKeysToRemove, attr.get('mailMergeField'));
                });

                //this.model.set("configuredAttrs", new AWTempateManagementCoreModel.AttributeCollection(newModels)); Should already be set?

                //this model will serve as our attribute listener. This will allow individual
                //Formtypes to keep track of their attributes
                this.keysHelper = new Backbone.Model({
                    keyInfo: keyInfo,
                    mailMergeKeys: mailMergeKeys,
                    configuredMailMergeKeys: configuredMailMergeKeys,
                    unconfiguredMailMergeKeys: unconfiguredMailMergeKeys
                });

                //set the attr view view the currentFormType passed from the model view
                this.setViews({
                    "#add-attributes-outlet": new AWTemplateManagementAttribute.Views.Attrcontrol({
                        keysHelper: this.keysHelper
                    }),
                    "#attributes": new AWTemplateManagementAttribute.Views.Collection({
                        keysHelper: this.keysHelper,
                        collection: this.model.get("configuredAttrs"),
                        typeCid: this.cid
                    })
                });
                if (this.model.get("initLoad")) {
                    this.addAllTypes();
                    this.model.remove("initLoad");
                }
                this.render();
            },
            serialize: function() {
                return {
                    cid: this.cid
                };
            },
            addAllTypes: function() {
                this.keysHelper.trigger("AWTemplatemanagementattribute:addAllAttrs");
            }
        });

        // Return the module for AMD compliance.
        return AWTemplateManagementType;
    });