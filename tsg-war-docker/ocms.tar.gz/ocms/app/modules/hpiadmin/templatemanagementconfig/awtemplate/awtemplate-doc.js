    define([
        "app",
        "modules/common/spinner",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-coremodel"
    ],

    function(app, HPISpinner, AWTemplateManagementCoreModel) {
        "use strict";

        var AWTemplateManagementDoc = app.module();

        AWTemplateManagementDoc.Views.Layout = Backbone.Layout.extend({

            template: "hpiadmin/templatemanagementconfig/awtemplate/awtemplate-doc",
            className: "AWTemplateManagementDoc",
            events: {
                "click #importBtn": "uploadDoc",
                "click #versionBtn": "uploadNewVersionDoc",
                "click #clearImportButton": "clearUpload"
            },

            initialize: function(options) {
                this.options = options;
                this.parentFolder = "/hpi/" + app.appId + "/ocmsTemplates";

                this.ui = {};
                this.ui.hideError = true;
                this.ui.hideImportBtn = true;
                this.ui.hideVersionBtn = true;
                this.ui.hideClearBtn = true;
                this.ui.hideSelect = false;
                this.ui.hideUploadNewVersion = true;

                this.uploadFile = null;
                this.uploadFileName = "";

                this.selectUploadElement = ".fileuploader-input";

                this.selectVersionElement = ".fileversion-input";

                this._startListening();
            },
            _startListening: function() {
                this.listenTo(this.options.ocTemplEventBus, "templateDeleted", this.deleteTemplateFromBackend);
            },
            serialize: function() {
                var createMode = false;
                if (this.options.modelName === '') {
                    createMode = true;
                }

                return {
                    hideError: this.ui.hideError,
                    hideImportBtn: this.ui.hideImportBtn,
                    hideVersionBtn: createMode,
                    hideUploadNewVersion: this.ui.hideUploadNewVersion,
                    initialText: this.ui.initialText,
                    hideSelect: this.ui.hideSelect,
                    hideClearBtn: this.ui.hideClearBtn,
                    fileName: this.uploadFileName
                };
            },

            afterRender: function() {
                var self = this;
                //select documents file 
                this.$(this.selectUploadElement).fileupload({
                    add: function(e, data) {
                        self._uploadDoc(data);
                    }
                });

                //new version document
                this.$(this.selectVersionElement).fileupload({
                    add: function(e, data) {
                        self._uploadAndVersionDoc(data);
                    }
                });
                HPISpinner.destroySpinner(self.spinner);
            },
            _uploadAndVersionDoc: function(file) {
                var self = this;

                this.uploadFile = file.files[0];
                this.uploadFileName = file.files[0].name;
                var fileExtension = this.uploadFileName.substring(this.uploadFileName.lastIndexOf(".") + 1);

                this.ui.initialText = false;
                this.ui.hideFileName = false;
                this.ui.hideClearBtn = false;
                this.ui.hideSelect = true;
                this.ui.hideVersionBtn = true;


                if (fileExtension === "doc" || fileExtension === "docx") {
                    this.ui.hideUploadNewVersion = false;
                } else {
                    this.ui.hideError = false;
                }
                self.render();
            },
            uploadNewVersionDoc: function() {
                var self = this;

                $("#dropZoneFile").css('background-color', '#c0c0c0');
                $('#importBtn').prop('disabled', true);
                $('.clearDocButton').prop('disabled', true);

                self.spinner = HPISpinner.createSpinner({
                    color: '#666'
                }, this.$el.find(".progressSpinner")[0]);

                // Add a date padding to the filename so it is unique
                var path = this.parentFolder + '/' + this.uploadFileName;

                this.getIdOfExistingTemplate(path).done(function(idOfExistingTemplate) {
                    var that = self;
                    self.uploadNewVersionOfTemplate(idOfExistingTemplate).done(function(objectIdOfNewVersion) {
                        that.getNewMMFieldsAndReRender(objectIdOfNewVersion);
                    }, this);
                }, this);
            },
            getIdOfExistingTemplate: function(path) {
                var def = $.Deferred();
                $.ajax({
                    url: app.serviceUrlRoot + "/content/getIdByPath?path=" + encodeURIComponent(path),
                    success: function(idOfExistingTemplate) {
                        def.resolve(idOfExistingTemplate);
                    },
                    global: false
                });

                return def.promise();
            },

            uploadNewVersionOfTemplate: function(idOfExistingTemplate) {

                var def = $.Deferred();
                var fd = new FormData();
                fd.append('properties', {
                    "prop-name": this.uploadFileName
                });
                fd.append('parts', this.uploadFile, this.uploadFileName);
                fd.append('versionType', "minor");
                fd.append('objectId', idOfExistingTemplate);

                var action = new Backbone.Model({
                    name: 'uploadNewVersion',
                    parameters: {
                        objectId: idOfExistingTemplate,
                        versionType: 'minor',
                    }
                });

                fd.append('action', JSON.stringify(action));
                $.ajax({
                    method: "POST",
                    data: fd,
                    contentType: false,
                    processData: false,
                    url: app.serviceUrlRoot + "/action/executeWithAttachment",
                    success: function(data) {
                        console.log(data);
                        var objectIdOfNewVersion = data.result;
                        def.resolve(objectIdOfNewVersion);
                    },
                    error: function(data) {
                        console.log(data);
                        HPISpinner.destroySpinner(self.spinner);
                    }
                });
                return def.promise();
            },

            getNewMMFieldsAndReRender: function(objectIdOfNewVersion) {
                var self = this;
                var def = $.Deferred();
                $.ajax({
                    method: "GET",
                    url: app.serviceUrlRoot + "/universal/getFormFields?objectId=" + objectIdOfNewVersion,
                    success: function(newMailMergeData) {

                        var modelName = self.uploadFileName.substring(0, self.uploadFileName.lastIndexOf("."));
                        self.options.ocTemplEventBus.trigger("newVersionRequested", modelName, newMailMergeData);
                        def.resolve();
                    },
                    error: function(data) {
                        console.log(data);
                        HPISpinner.destroySpinner(self.spinner);
                    }
                });
                return def.promise();
            },
            _uploadDoc: function(file) {
                var self = this;

                this.uploadFile = file.files[0];
                this.uploadFileName = file.files[0].name;
                var fileExtension = this.uploadFileName.substring(this.uploadFileName.lastIndexOf(".") + 1);

                this.ui.initialText = false;
                this.ui.hideFileName = false;
                this.ui.hideClearBtn = false;
                this.ui.hideSelect = true;

                if (fileExtension === "doc" || fileExtension === "docx") {
                    this.ui.hideImportBtn = false;
                } else {
                    this.ui.hideError = false;
                }

                self.render();
            },
            uploadDoc: function() {
                var self = this;

                $("#dropZoneFile").css('background-color', '#c0c0c0');
                $('#importBtn').prop('disabled', true);
                $('.clearDocButton').prop('disabled', true);

                self.spinner = HPISpinner.createSpinner({
                    color: '#666'
                }, this.$el.find(".progressSpinner")[0]);

                // Add a date padding to the filename so it is unique
                var fileName = this.uploadFileName;

                var fd = new FormData();
                fd.append('parentId', this.parentFolder);
                fd.append('objectType', 'Document');
                fd.append('properties', {
                    "prop-name": fileName
                });
                fd.append('parts', this.uploadFile, fileName);

                $.ajax({
                    method: "POST",
                    data: fd,
                    contentType: false,
                    dataType: "json",
                    processData: false,
                    url: app.serviceUrlRoot + "/content/upload",
                    success: function(data) {
                        var objectId = data;
                        $.ajax({
                            method: "GET",
                            url: app.serviceUrlRoot + "/universal/getFormFields?objectId=" + objectId,
                            success: function(data) {
                                var newModel = new AWTemplateManagementCoreModel.TemplateModel();
                                newModel.get("configuredTypes").add(new AWTemplateManagementCoreModel.TypeModel({
                                    mailMergeData: data,
                                    initload: true
                                }));
                                newModel.set("name", self.uploadFileName.substring(0, self.uploadFileName.lastIndexOf(".")));
                                newModel.set("filename", self.uploadFileName);
                                newModel.save({}, {
                                    success: function() {
                                        self.options.ocTemplEventBus.trigger("newTemplateUploaded", newModel);
                                    },
                                    error: function() {
                                        //Do nothing for now
                                    }
                                });
                                self.ui.hideError = true;
                                self.ui.hideImportBtn = true;
                                self.ui.hideClearBtn = true;
                                self.ui.hideSelect = false;

                                self.uploadFile = null;
                                self.uploadFileName = "";
                            },
                            error: function(data) {
                                console.log(data);
                                HPISpinner.destroySpinner(self.spinner);
                            }
                        });
                    },
                    error: function(data) {
                        console.log(data);
                        HPISpinner.destroySpinner(self.spinner);
                    }
                });
            },
            deleteTemplateFromBackend: function(template) {

                var path = this.parentFolder + '/' + template.get("filename");

                this.getIdOfExistingTemplate(path).done(function(idOfTemplateToDelete) {
                    var formData = {
                        objectId: idOfTemplateToDelete,
                        allVersions: true
                    };

                    $.ajax({
                        url: app.serviceUrlRoot + "/content/deleteObjects",
                        type: "POST",
                        data: formData,
                        global: false,
                        success: function() {
                            app.log.debug("Document deleted successfully");
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            app.log.debug((window.localize("modules.actions.bulkUpload.errorDeleting")) + errorThrown);
                        }
                    });
                });
            },
            clearUpload: function() {
                this.ui = {};
                this.ui.hideError = true;
                this.ui.hideImportBtn = true;
                this.ui.hideVersionBtn = true;
                this.ui.hideClearBtn = true;
                this.ui.hideUploadNewVersion = true;
                this.ui.hideSelect = false;

                this.uploadFile = null;
                this.uploadFileName = "";

                this.render();
            }
        });

        return AWTemplateManagementDoc;
    });