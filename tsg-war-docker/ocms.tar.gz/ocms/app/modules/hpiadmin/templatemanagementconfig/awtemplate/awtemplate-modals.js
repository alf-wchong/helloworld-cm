define([
    "app",
    "modules/common/spinner"
],

function(app, HPISpinner) {
    "use strict";

    var AWTemplateManagementModals = app.module();
    
    /* Copied from capturetemplate-new.js but not implemented for awtemplate yet

    AWTemplateManagementModals.CopyTemplateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-confirmationModal",
        events: {
            "click #action-confirmed" : "copyTemplate",
            "keyup #new-template-name": "validate"
        },
        initialize: function(options){
            this.objectTypeConfig = options.objectTypeConfig; 
            this.existingTemplates = this.objectTypeConfig.get("existingTemplates");
            this.templateSelected = options.templateSelected;
            this.captureTemplEventBus = options.captureTemplEventBus;
        },
        copyTemplate: function(){
            var originalTemplate = this.existingTemplates.findWhere({'templateName': this.templateSelected});
            var templateCopy = new CaptureTemplateConfig.TemplateModel({
                templateName: this.ui.newName.val(),
                templateObjectId: originalTemplate.get("templateObjectId")
            });
            this.existingTemplates.add(templateCopy);

            var copiedTemplateView = new CaptureTemplateExisting.Views.Layout({
                objectType : this.objectTypeConfig.get("objectType"),
                templateConfig: templateCopy,
                captureTemplEventBus: this.captureTemplEventBus
            });       
            this.captureTemplEventBus.trigger('main:replaceNewExistingViewOutlet', copiedTemplateView);
        },
        afterRender: function(){
            this.ui = {};
            this.ui.newName = this.$("#new-template-name");
            this.ui.confirmationButton = this.$("#action-confirmed");

            this.validate();
        },
        validate: function(){
            if(this.ui.newName.val()){
                this.ui.confirmationButton.prop("disabled", false);
            } else {
                this.ui.confirmationButton.prop("disabled", true);
            }
        },
        serialize: function(){
            return {
                header: "hpiAdmin.templateManagementConfig.copyTemplateHeader",
                newModal: false,
                copyModal: true, 
                deletionModal: false, 
                bodyMessage: "hpiAdmin.templateManagementConfig.copyTemplateBodyMessage",
                bodyInputText: "hpiAdmin.templateManagementConfig.copyTemplateBodyInput",
                footerText: "hpiAdmin.templateManagementConfig.copyTemplateFooter"
            };
        }
    });
    */

    AWTemplateManagementModals.DeleteTemplateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/templatemanagement-confirmationModal",
        events: {
            "click #action-confirmed" : "deleteTemplate"
        },
        initialize: function(options){
            this.options = options;
        },
        deleteTemplate: function(){
            //Just triggers an event handled by the actual delete method in awtemplate-config
            this.options.ocTemplEventBus.trigger("deleteTemplateRequested", this.options.templateName);
        },
        serialize: function(){
            return {
                header: "hpiAdmin.templateManagementConfig.deleteTemplateHeader",
                newModal: false,
                copyModal: false, 
                deletionModal: true, 
                bodyMessage: "hpiAdmin.templateManagementConfig.deleteTemplateBody",
                footerText: "hpiAdmin.templateManagementConfig.deleteTemplateFooter"
            };
        }
    });
    return AWTemplateManagementModals;
});