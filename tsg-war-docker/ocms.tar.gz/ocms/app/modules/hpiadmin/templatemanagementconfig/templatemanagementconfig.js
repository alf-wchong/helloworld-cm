// Objecttypeconfig module
define([
        "app",
        "modules/hpiadmin/hpiadmin",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-config",
        "modules/hpiadmin/templatemanagementconfig/awtemplate/awtemplate-coremodel",
        "modules/hpiadmin/templatemanagementconfig/contenttemplate/contenttemplate-config",
        "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-main",
        "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-config",
        "modules/hpiadmin/templatemanagementconfig/ftltemplate/ftltemplate-config",
        "modules/hpiadmin/templatemanagementconfig/ftltemplate/ftltemplate-coremodel",
    ],

    function(app, HPIAdmin, AWTemplateConfig, AWTemplateCoreModel, ContentTemplateConfig, CaptureTemplateMain, CaptureTemplateConfig, FTLTemplateConfig, FTLTemplateMain) {
        "use strict";

        var TemplateManagementConfig = app.module();

        // Default Model.
        TemplateManagementConfig.Model = HPIAdmin.Config.extend({
            type: "TemplateManagementConfig",
            defaults: {
                type: "TemplateManagementConfig",
                contentTemplateConfig: {},
                awTemplateConfig: new AWTemplateCoreModel.Config(),
                captureTemplateConfig: new CaptureTemplateConfig.Config(),
                FTLTemplateConfig: new FTLTemplateMain.Config()
            },
            initialize: function() {
            },
            parseResponse: function(response) {
                //if this is the first time this config is loaded (id will be undefined),
                //then we need to build up the configured types without overwriting the
                //one that has already been init'ed. if the id is already present, then
                //the parse was hit after a save, and we are confident that the model we
                //already have is what is returned from the server, so remove config model
                //info from the response
                if (this.id) {
                    response = _.pick(response, 'id');
                }
                else { // first time, build up the config
                    // We want to pass the {parse:true} object because we want to build up the configs
                    // correctly from top to bottom as soon as we get them.
                    response.captureTemplateConfig = new CaptureTemplateConfig.Config(response.captureTemplateConfig, {parse:true});
                    response.awTemplateConfig = new AWTemplateCoreModel.Config(response.awTemplateConfig, {parse:true});
                    response.FTLTemplateConfig = new FTLTemplateMain.Config(response.FTLTemplateConfig, {parse:true});
                }

                return response;
            }
        });

        TemplateManagementConfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/templatemanagementconfig/templatemanagementconfig",
            className: "TemplateManagementConfig",
            events: {
                "click #tmc_contenttemplate_tab": "showContentTemplateConfig",
                "click #tmc_octemplate_tab": "showAWTemplateConfig",
                "click #tmc_capturetemplate_tab": "showCaptureTemplateConfig",
                "click #tmc_ftltemplate_tab": "showFTLTemplateConfig",
            },
            initialize: function() {
                this.buildAndSetTemplateView(CaptureTemplateMain);
            },
            showContentTemplateConfig: function(){
                this.buildAndSetTemplateView(ContentTemplateConfig);
            },
            showAWTemplateConfig: function(){
                this.buildAndSetTemplateView(AWTemplateConfig);
            },
            showFTLTemplateConfig: function(){
                this.buildAndSetTemplateView(FTLTemplateConfig);
            },
            showCaptureTemplateConfig: function(){
                this.buildAndSetTemplateView(CaptureTemplateMain);
            },
            buildAndSetTemplateView: function(configModule){
                if(this.views['#tmc_configOutlet']){
                    this.views['#tmc_configOutlet'].remove();
                }

                var templateConfigView = new configModule.Views.Layout({
                    'model': this.model,
                    'configClass': configModule
                });

                // Set the subview onto the correct outlet and render this view immediately after
                this.setView('#tmc_configOutlet', templateConfigView).render();
            }
        });

        return TemplateManagementConfig;

    });