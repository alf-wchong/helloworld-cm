define([
    "app",
    "oc",
    "modules/stage/documentViewers/OAViewer",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_fingerprint_attribute",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-config",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-util"
],

function(app, OC, OAViewer, CaptureTemplateExistingAttribute, CaptureTemplateExistingFingerprintAttribute, CaptureTemplateConfig, CATUtil) {
    "use strict";

    var CaptureTemplateExisting = app.module();

    CaptureTemplateExisting.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingTemplate",
        initialize: function(options){      
            var self = this;     
            this.options = options;
            this.captureTemplEventBus = options.captureTemplEventBus;
            this.existingTemplateConfig = options.templateConfig;


            //Fetch the template associated with this config
            this.fetchTemplateOco(options).done(function(templateOco) {
                self.initializeTemplate(templateOco);
                    
                //Set up doc viewer
                self.createOAViewer();

                //Fetch document info
                self.fetchDocumentInfo().done(function(data) {
                    //store doc height
                    self.docHeight = data.pages[0].height;

                    //Set up all subviews (attributes and fingerprints)
                    self.initializeSubviews();

                    //Set up event bus
                    self._startListening();
                });
            });
        },

        fetchTemplateOco: function(options) {
            var deferred = $.Deferred();

            //If a new template is being made, use the objectId generated and passed into this view,
            //otherwise search for the template.
            if(options.templateObjectId) {
                 var templateOco = new OC.OpenContentObject({ objectId : this.templateObjectId});
                 templateOco.fetch({
                    success: function(templateOco) {
                        deferred.resolve(templateOco);
                    }
                 });
            } else {
                CATUtil.searchForTemplate(this.existingTemplateConfig.get("templateFileName")).done(function(templateOco) {
                    deferred.resolve(templateOco);
                });
            }

            return deferred.promise();
        },

        initializeTemplate: function(templateOco) {
            this.templateOco = templateOco;
            this.templateObjectId = templateOco.id;
            this.templateOcoProperties = templateOco.get("properties");

            // Set up attribute collection
            if(this.templateOcoProperties.tsgCaptureModel){
                this.attributeCollection = new CaptureTemplateConfig.AttributeCollection(JSON.parse(this.templateOcoProperties.tsgCaptureModel));
            } else {
                this.attributeCollection = new CaptureTemplateConfig.AttributeCollection();
            }
        },

        initializeSubviews: function() {

            //Set up fingerprint attributes
            this.fingerprintAttributeCollection = this.existingTemplateConfig.get("fingerprintAttributes");
            this.createExistingFingerprintAttributeViews();

            // Create all the subviews used in an existing configuration
            this.showAttributeSelectionDropdown();
            this.showFingerprintAttributeSelectionDropdown();
            this.createExistingAttributeViews();
            this.render();
        },
        
        fetchDocumentInfo: function(){
            // Fetch document height for coordinate conversion
            var queryString = $.param({
                "id": this.templateOcoProperties.objectId,
                "lastModified": this.templateOcoProperties.modifiedDate
            });

            return $.ajax({
                url: app.serviceUrlRoot + "/annotation/getDocumentInfo?" + queryString,
                type: "GET"
            }).fail(function(errorResponse) {
                var responseText = JSON.parse(errorResponse.responseText);
                app.trigger("alert:error", {
                    header: window.localize("indexer.indexer.fetchDocPropertiesFailure"),
                    message: responseText.message
                });
            });
        },
        _startListening: function(){
            this.listenTo(this.captureTemplEventBus, "existing:newAttributeSelected", _.bind(this.insertNewAttributeView, this));
            this.listenTo(this.captureTemplEventBus, "existing:newFingerprintAttributeSelected", _.bind(this.insertNewFingerprintAttributeView, this));
            this.listenTo(this.captureTemplEventBus, "attributeSaved", this.saveTemplate);
            this.listenTo(this.captureTemplEventBus, "templatePublished", this.publishTemplateToSuggestionEngine);
            this.listenTo(this.captureTemplEventBus, "existingTemplateDeleted", this.deleteTemplateFromSuggestionEngine);
            this.listenTo(this.fingerprintAttributeCollection, "add", this.storeFingerprintChanges);
            this.listenTo(this.fingerprintAttributeCollection, "remove", this.storeFingerprintChanges);
        },
        insertNewAttributeView: function(attributeView){
            this.insertView("#existingAttributes-outlet", attributeView).render();
        },
        insertNewFingerprintAttributeView: function(attributeView){
            this.insertView("#existingFingerprintAttributes-outlet", attributeView).render();
        },
        storeFingerprintChanges: function() {
            this.existingTemplateConfig.set("fingerprintAttributes", this.fingerprintAttributeCollection.toJSON());
        },
        saveTemplate: function(){
            this.templateOcoProperties["tsgCaptureModel"]= JSON.stringify(this.attributeCollection.toJSON());
            this.templateOco.set("properties",  this.templateOcoProperties);
            this.templateOco.save();
        },
        showAttributeSelectionDropdown: function() {
            var attributeDropdownView = new CaptureTemplateExisting.AttributeDropdownView({
                objectType: this.options.objectType,
                attributeCollection: this.attributeCollection,
                captureTemplEventBus: this.captureTemplEventBus,
                existingTemplateConfig: this.existingTemplateConfig,
                docHeight: this.docHeight
            });

            this.setView("#attribute-dropdown-outlet", attributeDropdownView);
        },
        showFingerprintAttributeSelectionDropdown: function() {
            var fingerprintAttributeDropdownView = new CaptureTemplateExisting.FingerprintAttributeDropdownView({
                objectType: this.options.objectType,
                attributeCollection: this.fingerprintAttributeCollection,
                captureTemplEventBus: this.captureTemplEventBus,
                existingTemplateConfig: this.existingTemplateConfig
            });

            this.setView("#fingerprintAttribute-dropdown-outlet", fingerprintAttributeDropdownView);
        },
        createOAViewer: function(){
            var oaViewer = new OAViewer.Views.Viewer({
                documentId: this.templateObjectId,
                showAnnotations: true,
                oaviewerMode: "indexer",
                openAnnotateSearchValue: ""
            });

            this.setView("#contentViewer-outlet", oaViewer);
        },
        createExistingAttributeViews: function(){
            _.each(this.attributeCollection.models, function(attributeModel){
                var attributeView = new CaptureTemplateExistingAttribute.Views.Layout({
                    attributeModel : attributeModel,
                    templateId: this.templateObjectId,
                    docHeight: this.docHeight,
                    captureTemplEventBus: this.captureTemplEventBus
                });

                this.insertView("#existingAttributes-outlet", attributeView);
            }, this);
        },
        createExistingFingerprintAttributeViews: function(){
            _.each(this.fingerprintAttributeCollection.models, function(attributeModel){
                var attributeView = new CaptureTemplateExistingFingerprintAttribute.Views.Layout({
                    attributeModel : attributeModel,
                    templateId: this.templateObjectId,
                    captureTemplEventBus: this.captureTemplEventBus
                });

                this.insertView("#existingFingerprintAttributes-outlet", attributeView);
            }, this);
        },
        publishTemplateToSuggestionEngine: function(){
            var self = this;

            // build up json for the suggestr endpoint
            var templateName = this.existingTemplateConfig.get("templateName");
            var objectType = this.objectType;
            var attributeModels = [];
            _.each(JSON.parse(this.templateOcoProperties.tsgCaptureModel), function(attribute){
				var attributeModel = CATUtil.convertAttributeToSuggestionFormat(attribute, this.docHeight);
                attributeModels.push(attributeModel);
            }, this);

            var templateModel = {
                "templateName": templateName,
                "objectType": objectType,
                "attrExtractionCollection": {
                    "attributeModels": attributeModels
                }
            };

            var suggestionTemplateIdParam = "";
            if(this.templateOcoProperties.tsgSuggestrTemplateId) {
                suggestionTemplateIdParam = "?" + $.param({"suggestionTemplateId": this.templateOcoProperties.tsgSuggestrTemplateId});
            }

            var oldTemplateId = this.templateOcoProperties.tsgSuggestrTemplateId;
            
            //Add or update template model stored in suggestion engine
            $.ajax({
                url: app.serviceUrlRoot + '/docAnalysis/addTemplateOrUpdateExisting' + suggestionTemplateIdParam,
                type: "POST",
                context: this,
                contentType: "application/json",
                data: JSON.stringify(templateModel)
            }).then(function(suggestionTemplateId) {
                var deferred = $.Deferred();
                self.templateOcoProperties.tsgSuggestrTemplateId = suggestionTemplateId;

                //If a new template was added, send the document behind the template
                //and its attribute models to the suggestion engine as well
                if(suggestionTemplateId != oldTemplateId) {
                    var documentObjectId = this.templateObjectId;

                    //Add Document
                    self.addDocumentToSuggestionEngine(suggestionTemplateId, documentObjectId)

                    //Add attributes
                    .then(function(suggestionDocumentId) {
                        return self.addAttributesToSuggestionEngineDocument(suggestionDocumentId, attributeModels);
                    })
                    .then(function() {
                        deferred.resolve();
                    })
                    .fail(function(errorResponse) {
                        deferred.reject(errorResponse);
                    });
                    return deferred.promise();
                
                } else {
                    return deferred.resolve();
                }
            }).then(function() {
                //If all calls succeed, save the template
                self.saveTemplate();
            }).fail(function(errorResponse) {
                var responseText = JSON.parse(errorResponse.responseText);
                    app.trigger("alert:error", {
                        header: window.localize("hpiAdmin.templateManagementConfig.publishFailure"),
                        message: responseText.message
                });
            });
        },
        addDocumentToSuggestionEngine: function(suggestionTemplateId, documentObjectId) {
            var queryString = $.param({
                "suggestionTemplateId": suggestionTemplateId,
                "objectId": documentObjectId,
                "verified": true
            });

            //Add document behind the template to suggestion engine
            return $.ajax({
                url: app.serviceUrlRoot + '/docAnalysis/addNewDocument?' + queryString,
                type: "POST",
                contentType: "application/json"
            });
        },
        addAttributesToSuggestionEngineDocument: function(suggestionDocumentId, attributeModels) {
            var attributeCollection = {
                attributeModels: attributeModels
            };
            
            var data = JSON.stringify(attributeCollection);

            var queryString = $.param({
                "suggestionDocumentId": suggestionDocumentId
            });

            return $.ajax({
                url: app.serviceUrlRoot + '/docAnalysis/addAttributeModels?' + queryString,
                type: "PUT",
                contentType: "application/json",
                data: data
            });
        },
        deleteTemplateFromSuggestionEngine: function(){

            //Make sure the template id is present, otherwise we can't make the request
            if(!this.templateOcoProperties.tsgSuggestrTemplateId) {
                return;
            }

            var templateIdParam = $.param({
                suggestionTemplateId: this.templateOcoProperties.tsgSuggestrTemplateId
            });

            $.ajax({
                url: app.serviceUrlRoot + "/docAnalysis/deleteTemplate?" + templateIdParam,
                type: "DELETE",
                context: this,
                success: function() {},
                error: function(errorResponse) {
                    var responseText = JSON.parse(errorResponse.responseText);
                    app.trigger("alert:error", {
                        header: window.localize("hpiAdmin.templateManagementConfig.suggestionDeleteTemplateError"),
                        message: responseText.message
                    });
                },
            });
        },
        serialize: function(){
            return{
                existingAttributes : this.attributeCollection.models
            };
        }
    });

    CaptureTemplateExisting.AttributeDropdownView = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeDropdown",
        events: {
            "change #attributeSelectionDropdown" : "selectedNewAttribute"
        },
        initialize: function(options){
            var self = this;
            this.objectType = options.objectType;
            this.attributeCollection = options.attributeCollection;
            this.captureTemplEventBus = options.captureTemplEventBus;
            this.existingTemplateConfig = options.existingTemplateConfig;
            this.docHeight = options.docHeight;

            this._startListening();

            this.allAttributes = [];
            // Making a network call to get all the available attributes for this objectType
            app.context.configService.getTypeAttrs(this.objectType, function(allAttributes) {
                self.allAttributes = allAttributes;
                // Now that we have this information we can render the dropdown 
                self.render();
            });

        },
        _startListening: function(){
            this.listenTo(this.captureTemplEventBus, "attributeDeleted",_.bind(this.deleteAttribute, this));
        },
        getUnconfiguredAttributes: function(){
            this.unconfiguredAttributes = [];
            this.configuredAttributes = [];
            _.each(this.attributeCollection.models, function(attributeModel){
                this.configuredAttributes.push(attributeModel.get("attrOCName"));
            }, this);

            _.each(this.allAttributes, function(attr){
                // Checking if the attribute has already been configured. 
                if(this.configuredAttributes.indexOf(attr.ocName) === -1){
                    this.unconfiguredAttributes.push({
                        'ocName': attr.ocName,
                        'label' : attr.label
                    });
                }
            }, this);

            this.unconfiguredAttributes.sort(function(attr1, attr2){
                return ((attr1.label < attr2.label) ? -1 : (attr1.label > attr2.label) ? 1 : 0);
            });
        },
        selectedNewAttribute: function(evt) {
            var attrOcName = evt.target.value;
            var attrLabel = evt.target.selectedOptions[0].text;

            // Removing the attribute selected from the dropwdown 
            $('#attributeSelectionDropdown option:selected').remove();
            $('#attributeSelectionDropdown').prop("selectedIndex", 0);
            
            // Adding a model for the attribute to the config
            var attributeModel = new CaptureTemplateConfig.AttributeModel({
                'attrOCName': attrOcName,
                'attrLabel': attrLabel
            });
            this.attributeCollection.add(attributeModel);

            // Creating a new attribute view and putting it on the DOM
            var attributeView = new CaptureTemplateExistingAttribute.Views.Layout({
                attributeModel: attributeModel,
                templateId: this.templateObjectId,
                docHeight: this.docHeight,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.captureTemplEventBus.trigger("existing:newAttributeSelected", attributeView);
        },
        deleteAttribute: function(attrOCName){
            // Removing from the config so that we dont create a view for this attribute again
            this.attributeCollection.remove(attrOCName);

            // Re-render so that the dropdown has the correct values
            this.render();

            //Save the model so that deletion is saved in backend
            this.captureTemplEventBus.trigger("attributeSaved");
        },
        beforeRender: function(){
            this.getUnconfiguredAttributes();
        },
        serialize: function(){
            return {
                unconfiguredAttributes: this.unconfiguredAttributes
            };
        }
    });

    CaptureTemplateExisting.FingerprintAttributeDropdownView = CaptureTemplateExisting.AttributeDropdownView.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingFingerprintAttributeDropdown",
        events: {
            "change #fingerprintAttributeSelectionDropdown" : "selectedNewFingerprintAttribute"
        },
        _startListening: function(){
            this.listenTo(this.captureTemplEventBus, "fingerprintAttributeDeleted", _.bind(this.deleteAttribute, this));
        },
        selectedNewFingerprintAttribute: function(evt) {
            var attrOcName = evt.target.value;
            var attrLabel = evt.target.selectedOptions[0].text;

            // Removing the attribute selected from the dropwdown 
            $('#fingerprintAttributeSelectionDropdown option:selected').remove();
            $('#fingerprintAttributeSelectionDropdown').prop("selectedIndex", 0);
            
            // Adding a model for the attribute to the config
            var attributeModel = new CaptureTemplateConfig.BasicAttributeModel({
                'attrOCName': attrOcName,
                'attrLabel': attrLabel
            });
            this.attributeCollection.add(attributeModel);

            // Creating a new attribute view and putting it on the DOM
            var attributeView = new CaptureTemplateExistingFingerprintAttribute.Views.Layout({
                attributeModel: attributeModel,
                templateId: this.templateObjectId,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.captureTemplEventBus.trigger("existing:newFingerprintAttributeSelected", attributeView);
        }
    });

    return CaptureTemplateExisting;

});
