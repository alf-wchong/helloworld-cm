define([
    "app",
    "modules/common/ocquery"
], 

function(app, Ocquery) {

    var CaptureTemplateUtil = app.module();

    CaptureTemplateUtil.isCoordModelEmpty = function(coords) {
        var firstSetIsEmpty = (!coords.left || !coords.right || !coords.top || !coords.bottom);
        var secondSetIsEmpty = (!coords.x || !coords.y || !coords.width || !coords.height);
        return firstSetIsEmpty && secondSetIsEmpty;
    };

    /**
     * Converts capture coordinate model to suggestion engine coordinate model
     * @param{Object} coords -- capture coordinate model to convert
     * @param{Integer} docHeight -- Height of a document's page in points
     */    
    CaptureTemplateUtil.captureCoordsToSuggestionCoords = function(coords, docHeight) {
        var convertedCoords = {};

        if(CaptureTemplateUtil.isCoordModelEmpty(coords)) {
            convertedCoords.left = "";
            convertedCoords.right = "";
            convertedCoords.top = "";
            convertedCoords.bottom = "";
            convertedCoords.pageNum = 0;
        } else {
            convertedCoords.left = coords.left;
            convertedCoords.right = coords.right;
            convertedCoords.top = docHeight - coords.top;
            convertedCoords.bottom = docHeight - coords.bottom;
            convertedCoords.pageNum = coords.pageNum;
        }

        return convertedCoords;
    };

    /**
     * Converts text select coordinate model to capture coordinate model
     * @param{Object} coords -- text select model to convert
     */
    CaptureTemplateUtil.tSCoordsToCaptureCoords = function(coords) {
        var convertedCoords = {};

        if(CaptureTemplateUtil.isCoordModelEmpty(coords)) {
            convertedCoords.x = "";
            convertedCoords.y = "";
            convertedCoords.height = "";
            convertedCoords.width = "";
            convertedCoords.top = "";
            convertedCoords.bottom = "";
            convertedCoords.left = "";
            convertedCoords.right = "";
            convertedCoords.pageNum = 0;       
        } else {
            convertedCoords.x = coords.x;
            convertedCoords.y = coords.y;
            convertedCoords.height = coords.height;
            convertedCoords.width = coords.width;
            convertedCoords.top = coords.y;
            convertedCoords.bottom = coords.y + coords.height;
            convertedCoords.left = coords.x;
            convertedCoords.right = coords.x + coords.width;
            convertedCoords.pageNum = coords.page;
        }

        return convertedCoords;
    };

    /**
     * Converts text select coordinate model to suggestion engine coordinate model
     * @param{Object} coords -- text select coordinate model to convert
     * @param{Integer} docHeight -- Height of a document's page in points
     */    
    CaptureTemplateUtil.tsCoordsToSuggestionCoords = function(coords, docHeight) {
        var convertedCoords = {};

        if(CaptureTemplateUtil.isCoordModelEmpty(coords)) {
            convertedCoords.left = "";
            convertedCoords.right = "";
            convertedCoords.top = "";
            convertedCoords.bottom = "";
            convertedCoords.pageNum = 0;
        } else {
            convertedCoords.left = coords.x;
            convertedCoords.right = coords.x + coords.width;
            convertedCoords.top = docHeight - coords.y;
            convertedCoords.bottom = docHeight - (coords.y + coords.height);
            convertedCoords.pageNum = coords.page;
        }

        return convertedCoords;
    };

    /**
     * Converts suggestion engine coordinate model to text select coordinate model
     * @param{Object} coords -- suggestion engine coordinate model to convert
     * @param{Integer} docHeight -- Height of a document's page in points
     */    
    CaptureTemplateUtil.suggestionCoordsToTSCoords = function(coords, docHeight) {
        var convertedCoords = {};

        //OA's coordinate grid origin is the top left corner, Suggestion Engine's is bottom left corner
        if(CaptureTemplateUtil.isCoordModelEmpty(coords)) {
            convertedCoords.x = "";
            convertedCoords.y = "";
            convertedCoords.height = "";
            convertedCoords.width = "";
            convertedCoords.page = 0;
        } else {
            convertedCoords.x = coords.left;
            convertedCoords.y = docHeight - coords.top;
            convertedCoords.height = coords.top - coords.bottom;
            convertedCoords.width = coords.right - coords.left;
            convertedCoords.page = coords.pageNum;
        }

        return convertedCoords;
    };

    CaptureTemplateUtil.joinTSRectangles = function(coordsList) {
        //In OA, the coordinate grid origin is at the top left corner of the page.
        // (x, y) is the coordinate pair of the top left corner of the rectangle.
        // This function assumes that all rectangles are on the same page.

        var isFirstArea = true;
        var x = null, y = null, width = null, height = null;
        _.each(coordsList, function(coords) {
            if(isFirstArea) {
                isFirstArea = false;
                x = coords.x;
                y = coords.y;
                width = coords.width;
                height = coords.height;
            }

            var newX = x, newY = y, newWidth = width, newHeight = height;
            newX = _.min([x, coords.x]);
            newY = _.min([y, coords.y]);
            newWidth = _.max([x+width, coords.x+coords.width]) - newX;
            newHeight = _.max([y+height, coords.y+coords.height]) - newY;
            x = newX; y = newY; width = newWidth; height = newHeight;
        });

        return {
            x: x,
            y: y,
            width: width,
            height: height,
            page: coordsList[0].page
        };
    };

    CaptureTemplateUtil.convertAttributeToSuggestionFormat = function(attr, docHeight) {
        var zonalModel = {
            "coordinates" : CaptureTemplateUtil.captureCoordsToSuggestionCoords(attr.zonalModel.zonalCoordinatesModel, docHeight),
            "regex": attr.zonalModel.regex,
        };
        var keyValueModel = {
            "keyCoordinates": CaptureTemplateUtil.captureCoordsToSuggestionCoords(attr.keyValueModel.labelCoordinatesModel, docHeight),
            "valCoordinates": CaptureTemplateUtil.captureCoordsToSuggestionCoords(attr.keyValueModel.valueCoordinatesModel, docHeight),
            "valRegex": attr.keyValueModel.valRegex,
            "aliases": attr.keyValueModel.aliases
        };
                
        var attributeModel = {
            "attrOCName": attr.attrOCName,
            "zonalModel": zonalModel,
            "keyValueModel": keyValueModel
        };
        return attributeModel;
    };

    /**
     * Searches the repository for a tsgCaptureTemplate (OC object type name) with the given objectName
     * @param {String} templateFileName - name of the template to search for
     * @return the full oco of the template, assuming the template name is unique in the repository
     */
    CaptureTemplateUtil.searchForTemplate = function(templateFileName){
        var query = new Ocquery.Collection();
        query.state.pageSize = 1;
        
        query.searchParameters = [
            {
                paramName: "objectName",
                paramValue: templateFileName,
                paramType: "property",
            },
            {
                paramName: "tsgCaptureTemplate",
                paramType: "type",
                paramValue: "tsgCaptureTemplate"
            }
        ];

        var deferred = $.Deferred();

        query.fetch({
            global: false,
            context: this,
            success: function(collection){
                if(collection.at(0)) {
                    deferred.resolve(collection.at(0));
                } else {
                    deferred.reject(collection);
                }
            },
            error: function(jqxhr){
                deferred.reject(jqxhr);
            }
        });

        return deferred.promise();
    };

    return CaptureTemplateUtil;
});