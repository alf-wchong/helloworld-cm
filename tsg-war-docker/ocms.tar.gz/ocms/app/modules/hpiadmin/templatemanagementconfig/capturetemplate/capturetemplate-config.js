define([
    "app"
],

function(app) {
    "use strict";
    
    var CaptureTemplateConfig = app.module();
    
    
    ///////////////// MODELS BELOW ARE USED IN CONFIG PERSISTENCE ///////////////////////

    /**
     * A cast to ensure that our ObjectTypeCollection is named in the config and clear for anyone else using it.
     */
    CaptureTemplateConfig.Config = Backbone.Model.extend({
        idAttribute: "CaptureConfig",
        defaults: function(){
            return {
                configuredTypes: new CaptureTemplateConfig.ObjectTypeCollection()
            };
        },
        parse: function(attrsObj){
            attrsObj.configuredTypes = new CaptureTemplateConfig.ObjectTypeCollection(attrsObj.configuredTypes, {parse:true});
            return attrsObj;
        }
    });

    /**
     * Object type model is the definition for a single document type. A single document type can contain various
     * templates associated to itself. The model holds the collection of templates associated to its type under
     * the existingTemplates attribute.
     */
    CaptureTemplateConfig.ObjectTypeModel = Backbone.Model.extend({
        idAttribute: "ObjectType",
        defaults: function(){
            return {
                objectType: "",
                existingTemplates: new CaptureTemplateConfig.TemplateCollection()
            };
        },
        parse: function(attrsObj){
            attrsObj.existingTemplates = new CaptureTemplateConfig.TemplateCollection(attrsObj.existingTemplates, {parse:true});
            return attrsObj;
        }
    });
    /**
     * Holds a collection of ObjectTypeModels for a single object type in the dropdown of Document Types that were
     * retrieved from the OTC.
     */
    CaptureTemplateConfig.ObjectTypeCollection = Backbone.Collection.extend({
        idAttribute: "ObjectTypeColl",
        parse: function(modelsArr){
            _.each(modelsArr, function(model, index){
                modelsArr[index] = new CaptureTemplateConfig.ObjectTypeModel(model, {parse:true});
            });
            return modelsArr;
        },
        model: CaptureTemplateConfig.ObjectTypeModel
    });
    
    /**
     * Template model is the definition for a single template, held under the above colleciton. The only things 
     * needed for the admin interface from this model are the id and name, we will query for this object and the actual
     * capture configurations once this is selected.
     */
    CaptureTemplateConfig.TemplateModel = Backbone.Model.extend({
        idAttribute: "TemplateName",
        // Last level of the configs doesn't need a parse.
        defaults: function(){
            return {
                templateObjectId: "",
                templateName: "",
                templateFileName: "",
                fingerprintAttributes: new CaptureTemplateConfig.FingerprintCollection()
            };
        },
        parse: function(modelsArr){
            modelsArr.fingerprintAttributes = new CaptureTemplateConfig.FingerprintCollection(modelsArr.fingerprintAttributes, {parse:true});
            return modelsArr;
        }    
    });
    /**
     * Holds a collection of TemplateModels for templates configured under and object type. This collection
     * is held by the ObjectTypeModel under the existingTemplates attribute.
     */
    CaptureTemplateConfig.TemplateCollection = Backbone.Collection.extend({
        idAttribute: "TemplateColl",
        parse: function(modelsArr){
            _.each(modelsArr, function(model, index){
                modelsArr[index] = new CaptureTemplateConfig.TemplateModel(model, {parse:true});
            });
            return modelsArr;
        },
        model: CaptureTemplateConfig.TemplateModel
    });
    
    ///////////////// MODELS BELOW ARE USED TO HOLD CAPTURE DATA ///////////////////////
    /**
     * This collection is saved on an attribute on the template object that the user configured, should be tsgCaptureModel at the time
     * of writing this, on the tsg_captureTemplate object type.
     * 
     * This collection holds individual Attribute models, for each attribute of the object type that was configured. Attribute models
     * each hold configurations for zonal and key value models.
     */
    CaptureTemplateConfig.BasicAttributeModel = Backbone.Model.extend({
        idAttribute: "attrOCName",
        defaults: function(){
            return {
                attrOCName: '',
                attrLabel: ''
            };
        },
    });

    CaptureTemplateConfig.AttributeModel = CaptureTemplateConfig.BasicAttributeModel.extend({
        defaults: function(){
            return {
                zonalModel: new CaptureTemplateConfig.ZonalModel(),
                keyValueModel: new CaptureTemplateConfig.KeyValueModel()
            };
        }, 
        initialize: function(){
            var zonalModel = this.get("zonalModel");
            var keyValueModel = this.get("keyValueModel");
            if(!(zonalModel instanceof Backbone.Model)){
                this.set("zonalModel", new CaptureTemplateConfig.ZonalModel(zonalModel));
            }
            if(!(keyValueModel instanceof Backbone.Model)){
                this.set("keyValueModel", new CaptureTemplateConfig.KeyValueModel(keyValueModel));
            }
        }
    });
    CaptureTemplateConfig.AttributeCollection = Backbone.Collection.extend({
        idAttribute: "AttributeColl",
        model: CaptureTemplateConfig.AttributeModel
    });

    /**
     * Zonal model holds the following configurations:
     *  - extraction data coordinate model for a single zone
     *  - regex to match against the extracted value
     *  - confidence threshold model
     */
    CaptureTemplateConfig.ZonalModel = Backbone.Model.extend({
        defaults: function(){
            return {
                zonalCoordinatesModel: new CaptureTemplateConfig.CoordinatesModel(),
                regex: ""
                //confidenceLevelModel: new CaptureTemplateConfig.ConfidenceModel()
            };
        },
        initialize: function(){
            var zonalCoordinatesModel = this.get("zonalCoordinatesModel");
            // var confidenceLevelModel = this.get("confidenceLevelModel");
            if(!(zonalCoordinatesModel instanceof Backbone.Model)){
                this.set("zonalCoordinatesModel", new CaptureTemplateConfig.CoordinatesModel(zonalCoordinatesModel));
            }
            // if(!(confidenceLevelModel instanceof Backbone.Model)){
            //     this.set("confidenceLevelModel", new CaptureTemplateConfig.ConfidenceModel(confidenceLevelModel));
            // }
        }
    });

    CaptureTemplateConfig.FingerprintCollection = Backbone.Collection.extend({
        idAttribute: "FingerprintColl",
        parse: function(fingerprintAttrs){
            _.each(fingerprintAttrs, function(model, index){
                fingerprintAttrs[index] = new CaptureTemplateConfig.BasicAttributeModel(model, {parse:true});
            });
            return fingerprintAttrs;
        },
        model: CaptureTemplateConfig.BasicAttributeModel
    });

    /**
     * KeyValue model holds the following configurations:
     *  - extraction data coordinate model for the key
     *  - extraction data coordinate model for the value
     *  - potential aliases to match against the key
     *  - confidence threshold model
     */
    CaptureTemplateConfig.KeyValueModel = Backbone.Model.extend({
        defaults: function() {
            return {
                labelCoordinatesModel: new CaptureTemplateConfig.CoordinatesModel(),
                valueCoordinatesModel: new CaptureTemplateConfig.CoordinatesModel(),
                // confidenceLevelModel: new CaptureTemplateConfig.ConfidenceModel(),
                aliases: [],
                valRegex: ""
            };
        }, 
        initialize: function(){
            var labelCoordinatesModel = this.get("labelCoordinatesModel");
            var valueCoordinatesModel = this.get("valueCoordinatesModel");
            // var confidenceLevelModel = this.get("confidenceLevelModel");
            if(!(labelCoordinatesModel instanceof Backbone.Model)){
                this.set("labelCoordinatesModel", new CaptureTemplateConfig.CoordinatesModel(labelCoordinatesModel));
            }
            if(!(valueCoordinatesModel instanceof Backbone.Model)){
                this.set("valueCoordinatesModel", new CaptureTemplateConfig.CoordinatesModel(valueCoordinatesModel));
            }
            // if(!(confidenceLevelModel instanceof Backbone.Model)){
            //     this.set("confidenceLevelModel", new CaptureTemplateConfig.ConfidenceModel(confidenceLevelModel));
            // }
        }
    });

    /**
     * Coordinates model contains the data we retrieve from OA when drawing on the document. These are the
     * core configurations needed for extraction of data for a single zone, a key or a value on a given attribute.
     */
    CaptureTemplateConfig.CoordinatesModel = Backbone.Model.extend({
        defaults: {
            top: '',
            bottom: '',
            left:'',
            right:'',
            x : '',
            y : '',
            width : '',
            height : '',
            pageNum : ''
        }
    });    
    
    // TODO: Can put this as an attribute on another model... no need to have a one value model
    CaptureTemplateConfig.ConfidenceModel = Backbone.Model.extend({
        defaults: {
            confidenceLevel: ''
        }
    });
    
    return CaptureTemplateConfig;
    
});