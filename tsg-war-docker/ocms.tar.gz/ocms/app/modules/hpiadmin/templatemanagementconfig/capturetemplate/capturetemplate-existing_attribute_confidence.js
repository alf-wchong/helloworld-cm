define([
    "app"
],

function(app) {
    "use strict";

    var CaptureTemplateExistingAttributeConfidence = app.module();

    CaptureTemplateExistingAttributeConfidence.Views.Layout = Backbone.Layout.extend({
        template:"hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeTextInput",
        initialize: function(options){
            this.model = options.model;

            this.configurationAvailable = !_.isEmpty(this.model);
        },
        serialize: function(){
            return {
                text: "hpiAdmin.templateManagementConfig.minimumConfidenceInternal",
                helpText: "hpiAdmin.templateManagementConfig.minimumConfidenceInternalTooltip",
                configurationAvailable: this.configurationAvailable,
                model: this.model.attributes
            };
        }       
    });

    return CaptureTemplateExistingAttributeConfidence;

});
