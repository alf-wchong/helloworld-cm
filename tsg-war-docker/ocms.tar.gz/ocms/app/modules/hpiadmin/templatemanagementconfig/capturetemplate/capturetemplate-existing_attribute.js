define([
    "app",
    "modules/hpiadmin/adminUtil",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_zonal",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_keyvalue",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-util"
],

function(app, AdminUtil, CATZonal, CATKeyValue, CATUtil) {
    "use strict";

    var CaptureTemplateExistingAttribute = app.module();

        CaptureTemplateExistingAttribute.ValidateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-validationModal",
        initialize: function(options) {
            this.result = options.result ? options.result.text : null;
        },
        serialize: function(){
            return {
                result: this.result,
                error: !this.result
            };
        }
    });
    
    CaptureTemplateExistingAttribute.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttribute",
        events : function(){
            var events = {};
            events["click .admin_ui_subsectionToggle"] = "toggleSubsection";
            events["click #save-attribute-button"] = "saveTemplate";
            events["click #validate-attribute-button"] = "validateAttribute";
            events["click #keyValueEnable-" + this.attrOCName] = "createKeyValueView";
            events["click #zonalEnable-" + this.attrOCName] = "createZonalView";
            events["click #confirm-attribute-delete-" + this.attrOCName] = "deleteAttribute";
            return events;
        },
        initialize: function(options){
            this.attributeModel = options.attributeModel;
            this.templateId = options.templateId;
            this.captureTemplEventBus = options.captureTemplEventBus;
            this.attrLabel = options.attributeModel.get("attrLabel");
            this.attrOCName = options.attributeModel.get("attrOCName");
            this.options = options;

            //Set up sub view
            this.createKeyValueView();

            this._startListening();
        },
        _startListening: function(){
            this.listenTo(this.captureTemplEventBus, "closeSubsection", this.closeSubsection);
        },
        closeSubsection: function(sectionOCName){
            //Only close the subesction if the name isn't the same as this attribute's name
            if(sectionOCName != this.attrOCName) {
                var elemToHide = this.$el.find(".admin_ui_subsectionToggle")[0]; //Have to find the html element using jquery to close
                
                //If already hidden just return
                if(AdminUtil.UI.isCustomConfigSectionHidden(elemToHide)) {
                    return;
                }

                //Otherwise hide it and reset stuff
                AdminUtil.UI.hideCustomConfigSubsection(elemToHide);

                //Reset the state of all the coordinate buttons
                this.captureTemplEventBus.trigger("resetCoordinateState", this.attrOCName);
            }

        },
        toggleSubsection: function(e){
            AdminUtil.UI.toggleCustomConfigSubsection({'event': e});

            //If this attribute view toggled from hidden->showing
            if(!AdminUtil.UI.isCustomConfigSectionHidden(e.currentTarget)) {

                //Close all other attribute views
                this.captureTemplEventBus.trigger("closeSubsection", this.attrOCName);

                //Restore any annotation state on OA for this attribute
                this.captureTemplEventBus.trigger("displayCoordinateModel", this.attrOCName);
            } 
            //else showing->hidden
            else {

                //Reset the state of all the coordinate buttons
                this.captureTemplEventBus.trigger("resetCoordinateState", this.attrOCName);
            }
        },
        saveTemplate: function(){
            this.captureTemplEventBus.trigger("attributeSaved");
        },
        createKeyValueView: function(){

            //Remove zonal view if it exists
            this.captureTemplEventBus.trigger("resetCoordinateState", this.attrOCName);
            this.removeView("#coordinateModel-outlet");

            var keyValueView = new CATKeyValue.Views.Layout({
                model: this.attributeModel.get("keyValueModel"),
                attrOCName: this.attrOCName,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.setView("#coordinateModel-outlet", keyValueView).render();
            this.captureTemplEventBus.trigger("displayCoordinateModel", this.attrOCName);
        },
        createZonalView: function(){
            
            //Remove keyValue view if it exists
            this.captureTemplEventBus.trigger("resetCoordinateState", this.attrOCName);
            this.removeView("#coordinateModel-outlet");
            
            var zonalView = new CATZonal.Views.Layout({
                model: this.attributeModel.get("zonalModel"),
                attrOCName: this.attrOCName,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.setView("#coordinateModel-outlet", zonalView).render();
            this.captureTemplEventBus.trigger("displayCoordinateModel", this.attrOCName);
        },
        validateAttribute: function(){

            //Figure out if kv or zonal tab is active
            var tabId = "#keyValueEnable-" + this.attrOCName;
            var kvActive = this.$(tabId).attr("checked");

            //Call respective validate function
            if(!kvActive) {
                this.validateZonal();
            } else {
                this.validateKV();
            }
        },
        validateZonal: function(){
            var self = this;

            //Combine the coordinate model attributes and the zonal model non-backbone-model attributes into one json obj
            var coordinateModelAttrs = this.attributeModel.get("zonalModel").get("zonalCoordinatesModel").attributes;
            var regex = this.attributeModel.get("zonalModel").get("regex");
            
            //Construct the attribute json SuggestR expects
            var attributes = {
                coordinates: CATUtil.captureCoordsToSuggestionCoords(coordinateModelAttrs, this.options.docHeight),
                regex: regex,
            };

            //Form request
            var data = {
                'objectId': this.templateId,
                'zonalModel': JSON.stringify(attributes)
            };

            //Send it
            $.ajax({
                url: app.serviceUrlRoot + "/docAnalysis/getZonalSuggestion",
                type: "GET",
                data: data,
                success: function(data){

                    var result = JSON.parse(data);

                    //Populate a modal with the result
                    var validateTemplateModal = new CaptureTemplateExistingAttribute.ValidateModal({
                        'result': result.zonalCandidate,
                        'resultType': 'zonal'
                    });
                    self.setView("#attribute-modal-outlet", validateTemplateModal).render();
                },
                error: function(errorResponse){
                    var responseText = JSON.parse(errorResponse.responseText);
                    app.trigger("alert:error", {
                        header: window.localize("hpiAdmin.templateManagementConfig.validationFailure"),
                        message: responseText.message
                    });
                }
            });

            //Delete previous validation modal
            if(this.views["#attribute-modal-outlet"]) {
                this.views["#attribute-modal-outlet"].remove();
            }
        },
        validateKV: function(){
            var self = this;

            //Combine the coordinate model attributes and the zonal model non-backbone-model attributes into one json obj
            var keyCoordinates = this.attributeModel.get("keyValueModel").get("labelCoordinatesModel").attributes;
            var valCoordinates = this.attributeModel.get("keyValueModel").get("valueCoordinatesModel").attributes;
            var aliases = this.attributeModel.get("keyValueModel").get("aliases");
            var valRegex = this.attributeModel.get("keyValueModel").get("valRegex");
            
            //Construct the attribute json SuggestR expects
            var attributes = {
                aliases: aliases,
                keyCoordinates: CATUtil.captureCoordsToSuggestionCoords(keyCoordinates, this.options.docHeight),
                valCoordinates: CATUtil.captureCoordsToSuggestionCoords(valCoordinates, this.options.docHeight),
                valRegex: valRegex
            };

            //Form request
            var data = {
                'objectId': this.templateId,
                'kvModel': JSON.stringify(attributes)
            };

            //Send it
            $.ajax({
                url: app.serviceUrlRoot + "/docAnalysis/getKVSuggestion",
                type: "GET",
                data: data,
                success: function(data){
                    var result = JSON.parse(data);

                    //Populate a modal with the result
                    var validateTemplateModal = new CaptureTemplateExistingAttribute.ValidateModal({
                        'result': result.kvCandidate,
                        'resultType': "keyValue"
                    });
                    self.setView("#attribute-modal-outlet", validateTemplateModal).render();
                },
                error: function(errorResponse){
                    var responseText = JSON.parse(errorResponse.responseText);
                    app.trigger("alert:error", {
                        header: window.localize("hpiAdmin.templateManagementConfig.validationFailure"),
                        message: responseText.message
                    });
                }
            });

            //Delete previous validation modal
            if(this.views["#attribute-modal-outlet"]) {
                this.views["#attribute-modal-outlet"].remove();
            }
        },
        deleteAttribute: function(){
            this.captureTemplEventBus.trigger("attributeDeleted", this.attrOCName);
            // Deleting this view from the DOM 
            this.remove();
            // Making sure that the view is not bound to any events either 
            this.unbind();
        },
        serialize: function(){
            return {
                attrLabel: this.attrLabel,      
                attrOCName: this.attrOCName,
                zonalConfigured: this.zonalCoordinatesConfigured        
            };
        }
    });

    return CaptureTemplateExistingAttribute;

});
