define([
    "app",
    "modules/common/spinner",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-config"
],

function(app, HPISpinner, CaptureTemplateExisting, CaptureTemplateConfig) {
    "use strict";

    var CaptureTemplateNew = app.module();

    CaptureTemplateNew.NewTemplateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/templatemanagement-confirmationModal",
        events: {
            "click #action-confirmed" : "addTemplate",
            "keyup #new-template-name": "validate"
        },
        initialize: function(options) {
            this.objectTypeConfig = options.objectTypeConfig;
            this.existingTemplates = this.objectTypeConfig.get("existingTemplates");
            this.captureTemplEventBus = options.captureTemplEventBus;
        },
        addTemplate: function() {  
            this.uploadFile = this.ui.selectUploadElement[0].files[0];

            this.newTemplateName = this.ui.newName.val();
 
            this.uploadDoc();
        },
        uploadDoc: function() {
            $("#dropZoneFile").css('background-color', '#c0c0c0');
            $('#importBtn').prop('disabled', true);
            $('.clearDocButton').prop('disabled', true);

            this.spinner = HPISpinner.createSpinner({
                color: '#666'
            }, this.$el.find(".progressSpinner")[0]);

            // Add a date padding to the filename so it is unique
            var fileExtension = this.uploadFile.name.substring(this.uploadFile.name.lastIndexOf("."));
            this.fileName = this.newTemplateName + "-" + moment().unix() + fileExtension;

            var fd = new FormData();
            fd.append('parentId', "/hpi/" + app.appId + "/ocmsTemplates");
            fd.append('objectType', 'tsgCaptureTemplate');
            fd.append('prop-tsgTargetType', this.objectTypeConfig.get("objectType"));
            fd.append('parts', this.uploadFile, this.fileName);

            $.ajax({
                method: "POST",
                data: fd,
                contentType: false,
                dataType: "json",
                processData: false,
                url: app.serviceUrlRoot + "/content/upload",
                context: this,
                success: this.uploadDocSuccess,
                error: function() {
                    HPISpinner.destroySpinner(this.spinner);
                }
            });
        },
        uploadDocSuccess: function(response){
            this.templateObjectId = response;

            var newTemplate = new CaptureTemplateConfig.TemplateModel({
                templateName: this.newTemplateName,
                templateObjectId: this.templateObjectId,
                templateFileName : this.fileName
            });
            this.existingTemplates.add(newTemplate);

            var newTemplateView = new CaptureTemplateExisting.Views.Layout({
                objectType : this.objectTypeConfig.get("objectType"),
                templateConfig: newTemplate,
                captureTemplEventBus: this.captureTemplEventBus,
                templateObjectId : this.templateObjectId
            });
            this.captureTemplEventBus.trigger('main:replaceNewExistingViewOutlet', newTemplateView);
        },
        afterRender: function(){
            this.ui = {};
            this.ui.selectUploadElement = this.$(".fileuploader-input");
            this.ui.newName = this.$("#new-template-name");
            this.ui.confirmationButton = this.$("#action-confirmed");

            // Everytime the user selects a file we want to check validate
            this.ui.selectUploadElement.on('change', _.bind(this.validate, this)); 

            this.validate();
        },
        validate: function(){
            if(this.ui.newName.val() && this.ui.selectUploadElement[0].files[0]){
                this.ui.confirmationButton.prop("disabled", false);
            } else {
                this.ui.confirmationButton.prop("disabled", true);
            }
        },
        serialize: function(){
            return {
                header: "hpiAdmin.templateManagementConfig.newTemplateHeader",
                newModal: true,
                copyModal: false, 
                deletionModal: false, 
                bodyInputText: "hpiAdmin.templateManagementConfig.newTemplateBody",
                footerText: "hpiAdmin.templateManagementConfig.newTemplateFooter"
            };
        }
    });
    
    CaptureTemplateNew.CopyTemplateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/templatemanagement-confirmationModal",
        events: {
            "click #action-confirmed" : "copyTemplate",
            "keyup #new-template-name": "validate"
        },
        initialize: function(options){
            this.objectTypeConfig = options.objectTypeConfig; 
            this.existingTemplates = this.objectTypeConfig.get("existingTemplates");
            this.templateSelected = options.templateSelected;
            this.captureTemplEventBus = options.captureTemplEventBus;
        },
        copyTemplate: function(){
            var originalTemplate = this.existingTemplates.findWhere({'templateName': this.templateSelected});
            var templateCopy = new CaptureTemplateConfig.TemplateModel({
                templateName: this.ui.newName.val(),
                templateObjectId: originalTemplate.get("templateObjectId")
            });
            this.existingTemplates.add(templateCopy);

            var copiedTemplateView = new CaptureTemplateExisting.Views.Layout({
                objectType : this.objectTypeConfig.get("objectType"),
                templateConfig: templateCopy,
                captureTemplEventBus: this.captureTemplEventBus
            });       
            this.captureTemplEventBus.trigger('main:replaceNewExistingViewOutlet', copiedTemplateView);
        },
        afterRender: function(){
            this.ui = {};
            this.ui.newName = this.$("#new-template-name");
            this.ui.confirmationButton = this.$("#action-confirmed");

            this.validate();
        },
        validate: function(){
            if(this.ui.newName.val()){
                this.ui.confirmationButton.prop("disabled", false);
            } else {
                this.ui.confirmationButton.prop("disabled", true);
            }
        },
        serialize: function(){
            return {
                header: "hpiAdmin.templateManagementConfig.copyTemplateHeader",
                newModal: false,
                copyModal: true,
                deletionModal: false,
                bodyMessage: "hpiAdmin.templateManagementConfig.copyTemplateBodyMessage",
                bodyInputText: "hpiAdmin.templateManagementConfig.copyTemplateBodyInput",
                footerText: "hpiAdmin.templateManagementConfig.copyTemplateFooter"
            };
        }
    });

    CaptureTemplateNew.DeleteTemplateModal = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/templatemanagement-confirmationModal",
        events: {
            "click #action-confirmed" : "deleteTemplate"
        },
        initialize: function(options){
            this.objectTypeConfig = options.objectTypeConfig;
            this.existingTemplates = this.objectTypeConfig.get("existingTemplates");
            this.templateSelected = options.templateSelected;
            this.captureTemplEventBus = options.captureTemplEventBus;
        },
        deleteTemplate: function(){
            var formData = {
                objectId: this.existingTemplates.findWhere({'templateName': this.templateSelected}).get("templateObjectId"),
                allVersions: true
            };
            
            $.ajax({
                url: app.serviceUrlRoot + "/content/deleteObjects",
                type: "POST",
                data: formData,
                global: false,
                success: function() {
                    app.log.debug("Document deleted successfully");
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app.log.debug((window.localize("modules.actions.bulkUpload.errorDeleting")) + errorThrown);
                }
            });
            this.existingTemplates.remove(this.existingTemplates.findWhere({'templateName': this.templateSelected}));
        },
        serialize: function(){
            return {
                header: "hpiAdmin.templateManagementConfig.deleteTemplateHeader",
                newModal: false,
                copyModal: false, 
                deletionModal: true, 
                bodyMessage: "hpiAdmin.templateManagementConfig.deleteTemplateBody",
                footerText: "hpiAdmin.templateManagementConfig.deleteTemplateFooter"
            };
        }
    });
    return CaptureTemplateNew;
});