define([
    "app",
    "modules/externalEventsModule"
],

function(app, ExternalEventsModule) {
    "use strict";

    var CaptureTemplateExistingAttributeCoordinates = app.module();

    CaptureTemplateExistingAttributeCoordinates.Views.Layout = Backbone.Layout.extend({
        template:"hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeCoordinates",
        events: function() {
            var events = {};
            events["click #draw-" + this.label + "-property-btn"] = "drawZonalPropertyData";
            events["click #show-" + this.label + "-property-btn"] = "showZonalPropertyData";
            events["click #capture-" + this.label + "-property-btn"] = "captureZonalPropertyData";
            return events;
        },
        initialize: function(options){
            this.options = options;    
            this.label = options.label;
            this.text = options.text;
            this.attrOCName = options.attrOCName;
            this.captureTemplEventBus = options.captureTemplEventBus;

            this.resetCoordinateState(this.attrOCName);
            this._startListening();
        },
        _startListening: function() {
            this.listenTo(this.captureTemplEventBus, "resetCoordinateState", this.resetCoordinateState);
            this.listenTo(this.captureTemplEventBus, "displayCoordinateModel", this.displayCoordinateModel);
        },
        resetCoordinateState: function(attrOCName) {
            if(this.attrOCName != attrOCName) {
                return;
            }

            //Clear document view of annotations and corresponding zoom changes
            ExternalEventsModule.removeAllAnnotations.call(this);

            //Reset internal state
            this.isUserCapturing = false;
            this.hasUserCaptured = this.isModelPopulated();
            this.isUserPreviewing = false;
            this.annotationUpdatedCalled = false;
        },
        displayCoordinateModel: function(attrOCName) {
            this.isUserCapturing = false;
            this.hasUserCaptured = this.isModelPopulated();
            this.isUserPreviewing = false;
            if(this.attrOCName != attrOCName) {
                return;
            }

            if(this.hasUserCaptured) {
                this.showZonalPropertyData();
            }
        },
        isModelPopulated: function(){
            var x = this.options.model.get("x") != '';
            var y = this.options.model.get("y") != '';
            var width = this.options.model.get("width") != '';
            var height = this.options.model.get("height") != '';
            var pageNum = this.options.model.get("pageNum") != '';

            return x && y && width && height && pageNum;
        },
        drawZonalPropertyData: function(event){            
            if (app.openAnnotate) {
            // massage out the input for the event here so that when we pass it through the correct input gets populated
                this.isUserCapturing = true;
                ExternalEventsModule.initiateCaptureAnnotation.call(this, event, this.options.model);
                this.listenToOnce(app.openAnnotate, "annotationUpdated", function() {
                    this.annotationUpdatedCalled = true;
                });
                this.render();
            }
        },
        showZonalPropertyData: function(){
            if(!app.openAnnotate) {
                return;
            }

            //If SHOWING preview
            if(this.hasUserCaptured && !this.isUserPreviewing){
                this.isUserPreviewing = true;
                this.highlightZonalPropertyData();
            }

            //If HIDING preview
            else {
                this.isUserPreviewing = false;
                this.hideZonalPropertyData(); //Hides all, so no need to pass annotationObj
            }

            this.render();
        },
        hideZonalPropertyData: function(){
            if (app.openAnnotate) {
                ExternalEventsModule.removeAllAnnotations.call(this);
            }
        },
        captureZonalPropertyData: function() {
            if (app.openAnnotate && this.annotationUpdatedCalled) {
                ExternalEventsModule.removeAllAnnotations.call(this);
                this.isUserCapturing = !this.isModelPopulated();
                this.hasUserCaptured = this.isModelPopulated();
                this.render();
                this.annotationUpdatedCalled = false;
            }
        },
        highlightZonalPropertyData: function() {
            var annotationObj = {
                bottomX: this.options.model.get("x"),
                bottomY: this.options.model.get("y"),
                topX: (this.options.model.get("width") + this.options.model.get("x")),
                topY: (this.options.model.get("height") + this.options.model.get("y")),
                width: this.options.model.get("width"),
                height: this.options.model.get("height"),                    
                page: this.options.model.get("pageNum")
            };

            if(app.openAnnotate) {
                ExternalEventsModule.createHighlightAnnotation.call(this, annotationObj);
            }
        },
        afterRender: function() {
            self.$('[data-toggle="tooltip"]').tooltip();
        },
        serialize: function(){

            //Set status icon class
            if(this.isUserCapturing) {
                this.statusClass = "inProgress";
            } else if (this.hasUserCaptured) {
                this.statusClass = "captured";
            } else {
                this.statusClass = "noValue";
            }

            //Set text for the draw button
            if(this.hasUserCaptured) {
                this.drawText = "Redraw";
            } else {
                this.drawText = "Draw";
            }

            //Set text for the show button
            if(this.isUserPreviewing) {
                this.showText = "Hide";
            } else {
                this.showText = "Show";
            }

            return {
                text: this.text,
                label: this.label,
                showDrawButton: !this.isUserCapturing,
                showCaptureButton: this.isUserCapturing,
                showShowButton: (this.hasUserCaptured && !this.isUserCapturing),
                disableDrawButton: this.isUserPreviewing,
                showText: this.showText,
                drawText: this.drawText,
                statusClass: this.statusClass

            };
        }  
    });

    return CaptureTemplateExistingAttributeCoordinates;

});
