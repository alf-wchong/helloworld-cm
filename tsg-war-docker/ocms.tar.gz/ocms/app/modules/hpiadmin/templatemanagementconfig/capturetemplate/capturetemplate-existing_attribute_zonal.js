define([
    "app",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_coordinates",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_confidence",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-uielements"
],

function(app, CATCoordinates, CATConfidence, CATUIElems) {
    "use strict";

    var CaptureTemplateExistingAttributeZonal = app.module();

    CaptureTemplateExistingAttributeZonal.Views.Layout = Backbone.Layout.extend({
        template:"hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeZonal",
        initialize: function(options){
            this.model = options.model;
            this.attrOCName = options.attrOCName;
            this.captureTemplEventBus = options.captureTemplEventBus;
            this.createZonalCoordinateView();
			this.createRegexValidatorView();
            //this.createZonalConfidenceLevelView();
        },
        createZonalCoordinateView: function(){
            var zonalCoordinatesView = new CATCoordinates.Views.Layout({
                model: this.model.get("zonalCoordinatesModel"),
                text: 'Zonal coordinates',
                label: 'zonalCoordinate',
                attrOCName: this.attrOCName,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.setView("#zonalCoordinateModel-outlet", zonalCoordinatesView);
        },
        /* createZonalConfidenceLevelView: function(){
            var zonalConfidenceLevelView = new CATConfidence.Views.Layout({
                model: this.model.get("confidenceLevelModel")
            });
            this.setView("#zonalConfidenceLevelModel-outlet", zonalConfidenceLevelView);
        } */
        createRegexValidatorView: function(){
            var regexValidatorView = new CATUIElems.RegexValidatorView({
                model: this.model,
                text: "hpiAdmin.templateManagementConfig.regexValidatorText",
                helpText: "hpiAdmin.templateManagementConfig.regexValidatorHelp",
                regexKey: "regex"
            });
            this.setView("#regexValidatorModel-outlet", regexValidatorView);
        }
    });

    return CaptureTemplateExistingAttributeZonal;

});
