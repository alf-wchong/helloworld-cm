define([
    "app"
],
  
function(app) {
    "use strict";
    var CaptureTemplateUIElements = app.module();

    CaptureTemplateUIElements.RegexValidatorView = Backbone.Layout.extend({
        template:"hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeTextInput",
        events: {
            "keyup #regex": "validate"
        },
        validate: function(){
            this.model.set(this.regexKey, this.$("#regex").val());
        },
        initialize: function(options){
            this.model = options.model;
            this.regexKey = options.regexKey;
            this.options = options;
        },
        serialize: function(){
            return {
                text: this.options.text,
                helpText: this.options.helpText,
                model: this.model.attributes,
                regexValue: this.model.get(this.regexKey)
            };
        }       
    });
    return CaptureTemplateUIElements;
});