define([
    "app",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_coordinates",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing_attribute_confidence",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-uielements"
],

function(app, CATCoordinates, CATConfidence, CATUIElems) {
    "use strict";

    var CaptureTemplateExistingAttributeKeyValue = app.module();

    CaptureTemplateExistingAttributeKeyValue.Views.Layout = Backbone.Layout.extend({
        template:"hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeKeyValue",
        initialize: function(options){
            this.model = options.model;
            this.createLabelCoordinateView();
            this.createValueCoordinateView();
            this.createValueRegexView();
            this.createAliasesView();
            //this.createKeyValueConfidenceLevelView();
        },
        createLabelCoordinateView: function(){
            var labelCoordinatesView = new CATCoordinates.Views.Layout({
                model: this.model.get("labelCoordinatesModel"),
                text: 'hpiAdmin.templateManagementConfig.labelCoordinateText',
                label: 'labelCoordinate',
                attrOCName: this.attrOCName,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.setView("#labelCoordinateModel-outlet", labelCoordinatesView);
        },
        createValueCoordinateView: function(){
            var valueCoordinatesView = new CATCoordinates.Views.Layout({
                model: this.model.get("valueCoordinatesModel"),
                text: 'hpiAdmin.templateManagementConfig.valueCoordinateText',
                label: 'valueCoordinate',
                attrOCName: this.attrOCName,
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.setView("#valueCoordinateModel-outlet", valueCoordinatesView);
        },
        createValueRegexView: function() {
            var valRegexValidatorView = new CATUIElems.RegexValidatorView({
                model: this.model,
                text: "hpiAdmin.templateManagementConfig.valRegexValidatorText",
                helpText: "hpiAdmin.templateManagementConfig.valRegexValidatorHelp",
                regexKey: "valRegex"
            });
            this.setView("#valRegexValidatorModel-outlet", valRegexValidatorView);
        },
        createAliasesView: function(){
            var aliasesView = new CaptureTemplateExistingAttributeKeyValue.AliasView({
                aliasNames: this.model.get("aliases")
            });
            this.setView("#aliases-outlet", aliasesView);
        },
    });

    CaptureTemplateExistingAttributeKeyValue.AliasView = Backbone.Layout.extend({
        template : "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingAttributeAliases",
        events : {
            "click #add-alias-btn" : "addAlias",
            "click #delete-alias" : "deleteAlias",
        },
        initialize: function(options){
            this.aliasNames = options.aliasNames;
        },
        addAlias: function(){
            var aliasName = this.$("#alias-name").val();
            // Checking if text entered is not blank
            if(aliasName){
                this.aliasNames.push(aliasName);
                this.render();
            }
        },
        deleteAlias: function(evt){
            var deletedAliasName = $(evt.currentTarget).data("value");
            var index = this.aliasNames.indexOf(deletedAliasName);
            // Removing the element from array if we can find it 
            if(index !== -1){
                this.aliasNames.splice(index, 1);
                this.render();
            }
        },
        serialize: function(){
            return {
                aliasNames : this.aliasNames
            };
        }
    });

    return CaptureTemplateExistingAttributeKeyValue;

});
