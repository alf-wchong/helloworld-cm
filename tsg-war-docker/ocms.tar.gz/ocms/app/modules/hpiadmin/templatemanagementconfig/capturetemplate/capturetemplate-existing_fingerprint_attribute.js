define([
    "app",
],

function(app) {
    "use strict";

    var CaptureTemplateExistingFingerprintAttribute = app.module();
    
    CaptureTemplateExistingFingerprintAttribute.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existingFingerprintAttribute",
        events: {
            "click #delete-fingerprint-attribute-button" : "deleteFingerprintAttribute"
        },
        initialize: function(options){
            this.attributeModel = options.attributeModel;
            this.captureTemplEventBus = options.captureTemplEventBus;
            this.attrLabel = options.attributeModel.get("attrLabel");
            this.attrOCName = options.attributeModel.get("attrOCName");
        },
        deleteFingerprintAttribute: function(){
            this.captureTemplEventBus.trigger("fingerprintAttributeDeleted", this.attrOCName);
            // Deleting this view from the DOM 
            this.remove();
            // Making sure that the view is not bound to any events either 
            this.unbind();
        },
        serialize: function(){
            return {
                attrLabel: this.attrLabel,
                attrOCName: this.attrOCName,
            };
        }
    });

    return CaptureTemplateExistingFingerprintAttribute;
});
