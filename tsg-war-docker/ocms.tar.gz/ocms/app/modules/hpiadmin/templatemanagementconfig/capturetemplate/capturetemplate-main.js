define([
    "app",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-config",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-existing",
    "modules/hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-new"
],

function(app, CaptureTemplateConfig, CaptureTemplateExisting, CaptureTemplateNew) {
    "use strict";

    var CaptureTemplateMain = app.module();
   
    CaptureTemplateMain.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-main",
        events: {
            "change .objectTypeSelection": "createExistingTemplateDropdownView",
            "click #save-capture-template": "saveCaptureTemplateConfigs",
            "click #publish-capture-template": "publishCaptureTemplateConfigs"
        },
        initialize: function(options){
            this.captureTemplEventBus = _.extend({}, Backbone.Events);
            this.options = options;

            //Eventually we will want to get the correct configs passed in. 
            this.config = options.model.get("captureTemplateConfig");
            this.configuredObjectTypes = this.config.get('configuredTypes');
            
            this._startListening();

            app.context.configService.getAdminOTC(function (config){
                // we only care about document types so filter through the returned configs for only document configs
                this.documentConfigs = config.get("configs").filter(function (config) {
                    return config.get("isContainer") === "false";
                });

                this.allDocumentTypes = _.map(this.documentConfigs, function (docConfig) {
                    return {
                        'label': docConfig.get("label"),
                        'value': docConfig.get("ocName")
                    };
                });

                // Since intiialize involves a call to get OTC it is possible that view already rendered without this information, so we are re-rendering
                this.render();
            }, function(){}, this);
        },
        _startListening: function(){
            this.listenTo(this.captureTemplEventBus, 'main:replaceNewExistingViewOutlet', _.bind(this.replaceNewExistingViewOutlet, this));
            this.listenTo(this.captureTemplEventBus, "existingTemplateDeleted", function() {
                this.removeExistingTemplateView();
                this.saveCaptureTemplateConfigs();
            });
            this.listenTo(this.captureTemplEventBus, "newTemplateAdded", function() {
                this.saveCaptureTemplateConfigs();
            });
        },
        replaceNewExistingViewOutlet: function(newView){
            this.removeExistingTemplateView();

            // Set the subview onto the correct outlet 
            this.setView('#new-existing-template-outlet', newView);
        },
        removeExistingTemplateView: function(){
            if(this.views['#new-existing-template-outlet']){
                this.views['#new-existing-template-outlet'].remove();
            }
        },
        createExistingTemplateDropdownView: function(event){
            this.removeExistingTemplateView();

            var selectedObjectType = event.target.value;

            var objectTypeConfig = this.configuredObjectTypes.findWhere({'objectType': selectedObjectType});
            // If a config does not exist for this object type then create a blank one
            if(!objectTypeConfig){
                objectTypeConfig = new CaptureTemplateConfig.ObjectTypeModel({
                    'objectType' : selectedObjectType
                });

                this.configuredObjectTypes.add(objectTypeConfig);
            } 

            var existingTemplateDropdownView = new CaptureTemplateMain.ExistingTemplateDropdown({
                'objectType': selectedObjectType,
                'captureTemplEventBus': this.captureTemplEventBus,
                'objectTypeConfig': objectTypeConfig
            });
            this.setView("#existing-template-dropdown-view", existingTemplateDropdownView).render();
        },
        saveCaptureTemplateConfigs: function(){
            this.options.model.set("captureTemplateConfig", this.config);
            this.options.model.save();

            //Save the individual attribute models too
            this.captureTemplEventBus.trigger("attributeSaved");
        },
        publishCaptureTemplateConfigs: function(){
            this.captureTemplEventBus.trigger("templatePublished");
        },
        serialize: function(){
            return{
                objectTypes: this.allDocumentTypes
            };
        }
    });

    CaptureTemplateMain.ExistingTemplateDropdown = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/capturetemplate/capturetemplate-mainTemplatePicker",
        events: {
            "change #templateSelection": "showExistingTemplateConfiguration",
            "click #new-template-button" : "addNewTemplate",
            "click #copy-template-button" : "copyTemplate",
            "click #delete-template-button" : "deleteTemplate"
        },
        initialize: function(options){
            this.objectTypeConfig = options.objectTypeConfig;
            this.objectType = options.objectType;
            this.captureTemplEventBus = options.captureTemplEventBus;

            this._startListening();
        },
        _startListening: function(){
            this.listenTo(this.objectTypeConfig.get("existingTemplates"), "add", this.templateAdded);
            this.listenTo(this.objectTypeConfig.get("existingTemplates"), "remove", this.templateDeleted);
        },
        templateAdded: function(){
            var select = this.$("#templateSelection");
            
            // Creating an option element for the new template that was added
            var opt = document.createElement('option');
            var templateNames = this.objectTypeConfig.get("existingTemplates").pluck("templateName");
            opt.value = templateNames[templateNames.length-1];
            opt.innerHTML = templateNames[templateNames.length-1];
            select[0].appendChild(opt);
            
            // Making sure that the template that has just been added is now selected
            select.val(opt.value);

            this.captureTemplEventBus.trigger("newTemplateAdded");

            this.validate();
        },
        templateDeleted: function() {
            this.captureTemplEventBus.trigger("existingTemplateDeleted");
            this.render();
        },
        showExistingTemplateConfiguration: function(){
            var templateSelected = $("#templateSelection option:selected").val();
            
            var existingTemplateConfigurationView = new CaptureTemplateExisting.Views.Layout({
                objectType : this.objectType,
                templateConfig: this.objectTypeConfig.get("existingTemplates").findWhere({'templateName': templateSelected}),
                captureTemplEventBus: this.captureTemplEventBus
            });
            this.captureTemplEventBus.trigger('main:replaceNewExistingViewOutlet', existingTemplateConfigurationView);

            this.validate();
        },
        addNewTemplate: function() {
            var newTemplateModal = new CaptureTemplateNew.NewTemplateModal({
                'objectTypeConfig': this.objectTypeConfig,
                'captureTemplEventBus': this.captureTemplEventBus,
            });

            this.setView("#confirmation-modal-outlet", newTemplateModal).render();
        },
        copyTemplate: function(){
            var copyTemplateModal = new CaptureTemplateNew.CopyTemplateModal({
                'objectTypeConfig': this.objectTypeConfig,
                'captureTemplEventBus': this.captureTemplEventBus,
                'templateSelected': this.$("#templateSelection").val()
            });

            this.setView("#confirmation-modal-outlet", copyTemplateModal).render();
        },
        deleteTemplate: function(){
            var deleteTemplateModal = new CaptureTemplateNew.DeleteTemplateModal({
                'objectTypeConfig': this.objectTypeConfig,
                'captureTemplEventBus': this.captureTemplEventBus,
                'templateSelected': this.$("#templateSelection").val()
            });

            this.setView("#confirmation-modal-outlet", deleteTemplateModal).render();
        },
        beforeRender: function(){
            this.existingTemplates = this.objectTypeConfig.get("existingTemplates").pluck("templateName");
        },       
        afterRender: function(){
            this.ui = {};
            this.ui.copyTemplateButton = this.$("#copy-template-button");
            this.ui.deleteTemplateButton = this.$("#delete-template-button");

            this.validate();
        },
        validate: function(){
            if(this.$("#templateSelection").val()){
                this.ui.copyTemplateButton.prop("disabled", false);
                this.ui.deleteTemplateButton.prop("disabled", false);
            } else {
                this.ui.copyTemplateButton.prop("disabled", true);
                this.ui.deleteTemplateButton.prop("disabled", true);
            }
        },
        serialize: function(){
            return {
                existingTemplates: this.existingTemplates
            };
        }
    });

    return CaptureTemplateMain;

});