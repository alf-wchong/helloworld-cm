// Objecttypeconfig module
define([
    "app",
    "modules/hpiadmin/templatemanagementconfig/templatemanagementbody"
],

function(app, TemplateManagementBody) {
    "use strict";

    var ContentTemplateManagementConfig = app.module();

    ContentTemplateManagementConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/templatemanagementconfig/templatemanagementtabtitle",
        className: "ContentTemplateManagementConfig",
        events: {
        },
        initialize: function() {
            var that = this;

            this.ocTemplEventBus = _.extend({}, Backbone.Events);

            this.removeViewIfExisting("#template-management-config-tab-body");
            this.bodyView = new TemplateManagementBody.Views.Layout({
                ocTemplEventBus: this.ocTemplEventBus,
                templateTypeDesc: window.localize("templateManagementConfig.contentTemplateConfig.description"),
                tsgTemplateTypeParam: "content",
                downloadType: "docx",
                targetTypeDropdown: true,
                nameReadonly: false,
                titleDescRequired: false
            });
            that.setView("#template-management-config-tab-body", this.bodyView);
        },
        removeViewIfExisting: function(viewSelector) {
            if(this.views[viewSelector]) {
                this.views[viewSelector].remove();
            }
        },
        serialize: function(){
            return {
                configTitle: window.localize("templateManagementConfig.contentTemplateConfig.contentTemplate")
            };
        }
    });

    return ContentTemplateManagementConfig;

});