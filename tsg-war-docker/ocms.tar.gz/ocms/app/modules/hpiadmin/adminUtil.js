define([], function (){

    var AdminUtil = {};

    // Place any functionality related to the UI in this object.
    AdminUtil.UI = {};

    AdminUtil.UI.toggleCustomConfigSubsection = function(args){
        // Don't want to execute this twice in case we click on the nested <a> tag that holds the same class that triggers this method.
        args.event.stopPropagation();

        // Grab all DOM elements that we are going to be using to expand/collapse the section
        var eventObj = $(args.event.currentTarget);

        // Find the descendant span element, child or grand child, that holds the glyphicon
        var childGlyphiconSpan = eventObj.find('.glyphicon');
        // Get the closest ancestor element that holds the section header class. This element could be itself, so if the event is
        // triggered from the section header itself, or the <a> tag within the header, this function should still get us the correct element
        var parentSectionHeader = eventObj.closest('.hpi-section-header');
        // Get the sibling content section to the header we selected above.
        var siblingSectionContent = parentSectionHeader.siblings('.hpi-section-content');

        // Toggle class between hidden and shown
        siblingSectionContent.toggleClass('hidden');
        // Toggle classes defined, which means it will remove or add the individual classes separated by spaces
        childGlyphiconSpan.toggleClass('glyphicon-chevron-up glyphicon-chevron-down');
    };

    AdminUtil.UI.hideCustomConfigSubsection = function(section){

        //Grab jQuery object
        var jQSection = $(section);

        //This is pretty much the same as the above function but hides the section
        //rather than toggling show/hide
        var childGlyphiconSpan = jQSection.find('.glyphicon');
        var parentSectionHeader = jQSection.closest('.hpi-section-header');
        var siblingSectionContent = parentSectionHeader.siblings('.hpi-section-content');

        siblingSectionContent.addClass('hidden');
        childGlyphiconSpan.addClass('glyphicon-chevron-down');
        childGlyphiconSpan.removeClass('glyphicon-chevron-up');
    };

    AdminUtil.UI.isCustomConfigSectionHidden = function(section){
        jQSection = $(section);
        var parentSectionHeader = jQSection.closest('.hpi-section-header');
        var siblingSectionContent = parentSectionHeader.siblings('.hpi-section-content');
        return siblingSectionContent.hasClass('hidden');
    };

    return AdminUtil;
});