define([
        "app",
        'oc',
        "modules/hpiadmin/hpiadmin",
        "modules/common/action",
        "modules/common/downloadutils",
        "modules/common/spinner",
        "datetimePicker",
        "jqueryDownload",
        "module"
    ],

    function(app, OC, Hpiadmin, Action, downloadUtils, HPISpinner, datetimePicker, jqueryDownload, module) {

        var AdminSearchTool = app.module();
        AdminSearchTool.Model = Hpiadmin.Config.extend({
            type: "AdminSearchTool",
            defaults: {
                type: "AdminSearchTool"
            }
        });
        AdminSearchTool.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/adminsearchtool/adminsearchtool",
            className: "adminsearchtool",
            events: {
                "change #objectTypeSelector-adminTool": "updateObjectType",
                "keyup #searchLimit-adminTool": "limitIsNumber",
                "click #adminExecuteSearch-adminTool": "executeSearch",
                "click #adminUpdateProperties-adminTool": "UpdateProperties",
                "click #deleteNodes-adminTool": "setUpDeleteNodes",
                "click #deleteNodesBtn-adminTool": "deleteNodes",
                "click #forceDeleteBox-adminTool": "forceDeleteSwitch",
                "keyup #csvPath-adminTool": "updateRepoPath",
                "change #selectedSearchConfig-adminTool": "updateSearchConfig",
                "click .adminSearchTool_QueryModeToggle": "updateOpenAdminQueryMode"
            },
            initialize: function() {
                var self = this;
                this.searchParams = [];
                this.updateParams = [];
				// Used to make sure our search limit only contains digits
                this.onlyDigitsRegex = new RegExp("^[0-9]+$");

                this.objectType = "";
                this.loading = true;
                this.searchLimit = "1000";
                this.currentObjectTypeIndex = 0;
                this.currentSearchConfigIndex = 0; 
                this.bulkDelete = false;
                this.forceDelete = false;
                // All the types on the OTC
				this.allOCTypes = [];
				// The query mode chosen in the admin tool
                this.queryMode = "FTS";
                // The query mode we will default the slider to
                this.defaultQueryMode = "FTS";
                // The types we will actually show on the page
				this.OCTypesToShow = [];
				// The properties our search will return
				this.searchResultProperties = null;
                this.searchConfig = null;
                this.searchConfigName = "";
                this.repoPath = "";
                this.searchConfigs = [""];
                this.passthroughQueryEnabled = module.config().passthroughQueryEnabled;
                
                app.context.configService.getSearchConfigNames(function(searchConfigs) {
					// Sort our sort configs
                    self.searchConfigs = _.union(self.searchConfigs, searchConfigs).sort();
                    app.context.configService.getAdminOTC(function(OTC) {
                        app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat) {
                            self.dateFormat = app.context.dateService.getJQueryDateFormat(dateTimeFormat.dateFormat);
                            self.timeFormat = app.context.dateService.getJQueryTimeFormat(dateTimeFormat.timeFormat);
                            //frustratingly, moment uses a different formatting system than jquery.. just separate these for now
                            //and we can use both when we need to.
                            self.momentDateFormat = dateTimeFormat.dateFormat;
                            self.momentTimeFormat = dateTimeFormat.timeFormat.replace(' z', '');
                            if (self.spinner !== undefined) {
                                HPISpinner.destroySpinner(self.spinner);
                                self.$('#adminSearchToolContainer').show();
                                self.render();
                            }
                        });

                        self.allOCTypes = _.pluck(OTC.attributes.configs.models, 'attributes');
						// Sort our types by name
                        self.allOCTypes = _.sortBy(self.allOCTypes, function(type) { return type.ocName; });
						// Default to having all types showing
                        self.OCTypesToShow = self.allOCTypes;

                        app.context.configService.getUserPreferences(function(currentUserPreferences) {
                            self.userPreferences = currentUserPreferences;
        
                            if (currentUserPreferences.get("searchConfig")) {
                                self.searchConfigName = currentUserPreferences.get("searchConfig");
                                app.context.configService.getSearchConfigByName(self.searchConfigName, function(config) {
									// If we have a search config, get it and resolve it
                                    self.searchConfig = config;
                                    self.resolveSearchConfig();
                                    self.loading = false;
                                    self.resetSearch();
                                }, this);
                            } else {
								// Resolve having no search config
                                self.resolveSearchConfig();
                                self.loading = false;
                                self.resetSearch();
                            }
                            if (currentUserPreferences.get("adminBulkDeletePath")) {
                                self.repoPath = currentUserPreferences.get("adminBulkDeletePath");
                            } else {
                                self.repoPath = "";
                            }
                        });
                    });
                });

                this.listenTo(app, "searchPropertiesUpdated", function(searchParams) {
                    this.searchParams = searchParams;
                    this.validate();
                });
                this.listenTo(app, "updatePropertiesUpdated", function(updateParams) {
                    this.updateParams = updateParams;
                    this.validate();
                });
            },
            resolveSearchConfig: function() {
				// Default back to FTS and showing all types
                this.defaultQueryMode = "FTS";
                this.OCTypesToShow = this.allOCTypes;
                if (this.searchConfig) {
                    this.OCTypesToShow = [];
					// If we have a search config, parse it for object types to display
                    var searchConfigTypes = this.searchConfig.get("resultsConfig").get("resultsTableConfig").get("types").models;
                    // We want to find if there is a configured search for the object specified
                    _.each(searchConfigTypes, function(searchConfigType) {
                        var tempType = _.findWhere(this.allOCTypes, {
                            ocName: searchConfigType.get("objectType")
                        });
                        this.OCTypesToShow.push(tempType);
                    }, this);

                    this.resolveSearchProps();

                    // Adding the search implementation configuration
                    if (this.searchConfig.has("OCQueryImpl") && app.enableDirectSQL) {
                        var searchConfigQueryMode = this.searchConfig.get("OCQueryImpl");
                        if (searchConfigQueryMode === "OCSQLOnly" || searchConfigQueryMode === "OCSQLIfPossible") {
                            this.defaultQueryMode = "directSQL";
                        }
                    }
                } else {
                    this.resolveSearchProps();
                }
            },
            resolveSearchProps: function() {
                if (this.OCTypesToShow.length > 0) {
					// Go through our types to show, getting all properties configured
                    this.propNames = _.pluck(this.OCTypesToShow[this.currentObjectTypeIndex].attrs.models, 'attributes');
                    this.propNames = _.filter(this.propNames, function(model) {
                        return (model.dataType === "string" || model.dataType === "date");
                    });
                    this.objectType = this.OCTypesToShow[this.currentObjectTypeIndex].ocName;
                } else {
					// If we have no types to show, we have no properties or object type
                    this.propNames = [];
                    this.objectType = "";
                }

                this.searchResultProperties = this.propNames;
                if (this.searchConfig) {
					// Parse our search config for the properties we should return froma  search
                    this.searchResultProperties = [];
                    var searchConfigTypes = this.searchConfig.get("resultsConfig").get("resultsTableConfig").get("types").models;
                    // We want to find if there is a configured search for the object specified
                    _.each(searchConfigTypes, function(searchConfigType) {
                        if(searchConfigType.get("objectType") === this.objectType) {
                            // There is a configured search for the object specificied, lets get all the properties
                            _.each(searchConfigType.get("fields"), function(field) {
                                var tempProp = _.findWhere(this.propNames, {
                                    label: field.label
                                });
                                this.searchResultProperties.push(tempProp);
                            }, this);
                        }
                    }, this);
                }
            },
            updateOpenAdminQueryMode: function(event) {
                this.queryMode = $(event.target).val();
            },
            UpdateProperties: function() {
                var self = this;
                var url = app.serviceUrlRoot + '/query/searchAdminUpdateProperties?sort_by=objectName&order=asc';
                _.each(this.searchParams, function(val) {
					// Add our chosen search type to the url
					var searchType = (val.searchType === "equals") ? "OPERATOR_EQUALS" : "LOGIC_LIKE";
                    url = url + "&oc_property[]=" + val.propNameOC + "~:~" + val.propValue  + "~:~" + searchType;
                });
                url = url + "&oc_type[]=" + this.objectType + "&logic[]= and";

                // Adding the search implementation configuration
                url = this.addQueryParam(url);

                var updatedProperties = {};
                _.each(this.updateParams, function(val) {
                    if (val.propType === "date") {
                        updatedProperties[val.propNameOC] = moment(val.fromDate, self.dateFormat + " " + self.timeFormat, true).toDate().getTime();
                    } else {
                        //else is for when propType is a string
                        updatedProperties[val.propNameOC] = val.propValue;
                    }
                });
                
                $.ajax({
                    url: url,
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(updatedProperties),
                    success: function() {
                        app.trigger("alert:info", {
                            header: "Update Properties Success",
                            message: "All documents successfully updated."

                        });
                    },
                    global: true
                });
            },
            setUpDeleteNodes: function() {
                var self = this;
                app.context.configService.getUserPreferences(function(currentUserPreferences) {

                    currentUserPreferences.set('adminBulkDeletePath', self.repoPath);

                    app.trigger('alert:confirmation', {
                        message: "Are you sure you want to delete all documents matching your search parameters?",
                        header: "Confirm Bulk Delete",
                        confirmLabel: "Delete",
                        confirmBtnClass: "btn-danger",
                        confirm: function() {
                            self.deleteNodes();
                        }
                    });
                });
            },
            forceDeleteSwitch: function() {
                this.forceDelete = !this.forceDelete;
            },
            deleteNodes: function() {
                var fileName = new Date().toString();
                fileName = fileName.substring(0, fileName.indexOf('-'));
                var url = app.serviceUrlRoot + '/content/searchAdminBulkDelete?sort_by=objectName&order=asc';
                //Build up url of search poarams, limit results, and oc type

                url = this.buildURL(url);
                url = url + "&fileName=" + fileName;
                url = url + "&forceDelete=" + this.forceDelete;
                url = url + "&repoPath=" + this.repoPath;

                $.ajax({
                    url: url,
                    type: "DELETE",
                    contentType: "application/json",
                    success: function() {
                        app.trigger("alert:info", {
                            header: "Bulk Deletion Started",
                            message: "Bulk Deletion Started - When finished, the tracking file will be located in Repository with file name 'Admin Bulk Delete Tracking File-" + fileName + ".csv' at the path specified"
                        });
                    },
                    error: function(message) {
                        app.trigger("alert:error", {
                            header: "Bulk Delete Failure",
                            message: "Could not begin bulk deletion " + message
                        });
                    },
                    global: true
                });
            },
            executeSearch: function() {
                var self = this;
                var url = app.serviceUrlRoot + '/query/searchAdmin?sort_by=objectName&order=asc';
                url = this.buildURL(url);

                //==================
                _.each(this.searchResultProperties, function(val) {
                    url = url + "&ocNames=" + val.ocName;
                });

                // Only limit results for an execute search where we have a limit
                if (this.searchLimit !== "") {
                    url = url + "&limit_results=" + this.searchLimit;
                }

				// Destroy the spinner if we still have one spinning
                if (self.searchSpinner) {
                    HPISpinner.destroySpinner(self.searchSpinner);
                }

				// Set up a search spinner if we have the parent element to place it in
                var spinElem = this.$el.find("#search-loading")[0];
		        if(spinElem) {
			        // animate our loading indicator with spin.js (lighter weight than animated gif)
			        self.searchSpinner = HPISpinner.createSpinner({
				        top: '1000%'
			        }, spinElem);
                }

				// Success callback for our jquery file download
                var successCallback = function() {
					// Destroy the spinner if we have one
                    if (self.searchSpinner) {
                        HPISpinner.destroySpinner(self.searchSpinner);
                    }
                };

				// Failure callback for our jquery file download
                var failCallback = function(html) {
					// Destroy the spinner if we have one
                    if (self.searchSpinner) {
                        HPISpinner.destroySpinner(self.searchSpinner);
                    }
                    var parsedHTML = jQuery.parseHTML(html);
                    var message = parsedHTML[0].textContent;
                    message = jQuery.parseJSON(message);
                    message = message.status + ": " + message.message;
                    app.trigger("alert:changeNotification", "alert-danger", message, "#adminsearch-outlet");
                };

                //creates a hidden iframe and loads the csv into it. Then downloads the csv from the iframe. Needed as a work around for browser security
                downloadUtils.asyncCallbackDownload(url, successCallback, failCallback);
            },
            buildURL: function(url) {
                var self = this;
                _.each(this.searchParams, function(val) {
                    var searchType = (val.searchType === "equals") ? "OPERATOR_EQUALS" : "LOGIC_LIKE";
                    if (val.propType === "string") {
						// Add our chosen search type to the url
                        url = url + "&oc_property[]=" + val.propNameOC + "~:~" + val.propValue + "~:~" + searchType;
                    } else {
                        var  dateTo = "";
                        var dateFrom = "";
                        if (val.fromDate) {
                            dateFrom = moment(val.fromDate, self.momentDateFormat + " " + self.momentTimeFormat, true).toDate().getTime();
                        }
                        if (val.toDate) {
                            dateTo = moment(val.toDate, self.momentDateFormat + " " + self.momentTimeFormat, true).toDate().getTime();
                        }
                        url = url + "&oc_property[]=" + val.propNameOC + "~:~" + dateFrom + "|" + dateTo + "~:~LOGIC_LIKE";
                    }
                });
                url = url + "&oc_type[]=" + this.objectType + "&logic[]= and";

				// Adding the search implementation configuration
                url = this.addQueryParam(url);

                return url;
            },
            addQueryParam : function(url) {
				// Determine what type of query we are running
				// CMIS enabled to false means we run an FTS query
                var cmisEnabled = false;
                if (this.queryMode) {
                    if (this.queryMode === "CMIS") {
						// CMIS query
                        cmisEnabled = true;
                    } else if (this.queryMode === "DirectSQL") {
						// Always run admin queries as OCSQLOnly
                        url += "&OCQueryImpl=OCSQLOnly";
                    }
                }
                 url += "&cmisEnabled=" + cmisEnabled;
                 return url;
            },
            updateRepoPath: function(evt) {
                var self = this;
                this.repoPath = evt.currentTarget.value;
                // Save the path whenever the user changes it.
                app.context.configService.getUserPreferences(function(currentUserPreferences) {
                    currentUserPreferences.set('adminBulkDeletePath', self.repoPath);
                });
                this.validate();
            },
            dateStringToLong: function(date) {
                var a = date.split(" ");
                var d = a[0].split("/");
                var t = a[1].split(":");
                t[2] = "00";
                date = new Date(d[2], (d[0] - 1), d[1], t[0], t[1], t[2]);
                return date.getTime();
            },
            updateSearchConfig: function() {
                var self = this;
                this.searchConfigName = this.$('#selectedSearchConfig-adminTool').val();
                this.userPreferences.set("searchConfig", this.searchConfigName);
                
                this.objectType = "";
                this.currentObjectTypeIndex = 0;
                this.searchConfig = null;
				if (this.searchConfigName) {
                    // Only fire if we chose a non-blank search config
                    app.context.configService.getSearchConfigByName(this.searchConfigName, function(config) {
                        self.searchConfig = config;
                        self.resolveSearchConfig();
                        self.resetSearch();
                    });
                } else {
                    this.resolveSearchConfig();
                    this.resetSearch();
                }
            },
            resetSearch: function() {
                // Reset our search params and re-render
                this.queryMode = "FTS";
                this.forceDelete = false;
                this.searchParams = [];

                this.removeView('#searchPropertyAdder');
                this.removeView('#updatePropertyAdder');
                this.render();
            },
            updateObjectType: function() {
                var selector = this.$('#objectTypeSelector-adminTool')[0];
                this.currentObjectTypeIndex = selector.selectedIndex;
                this.resolveSearchProps();
                this.resetSearch();
            },
            limitIsNumber: function() {
                this.searchLimit = this.$('#searchLimit-adminTool').val();
                // Allow empty limits (meaning we get back all results)
                if (this.searchLimit !== "") {
                    if (this.onlyDigitsRegex.test(this.searchLimit)) {
                         // Our string only contains digits
                         this.$("#searchLimitError").text('');
                         this.$("#searchLimitError").removeClass("user-error-message-output");
                         this.validate();
                    } else {
                        this.$("#searchLimitError").text('The Search Limit must be a Positive Integer');
                        this.$("#searchLimitError").addClass("user-error-message-output");
                        this.$('#adminExecuteSearch-adminTool').attr('disabled', true);
                    }
                } else {
                    // The value is blank (we allow to indicate we're reutring all results)
                    this.$("#searchLimitError").text('');
                    this.$("#searchLimitError").removeClass("user-error-message-output");
                    this.validate();
                }
            },
            validate: function() {
                if (this.updateParams.length !== 0) {
                    this.$('#adminUpdateProperties-adminTool').attr('disabled', false);
                } else {
                    this.$('#adminUpdateProperties-adminTool').attr('disabled', true);
                }
                if (this.searchParams.length !== 0) {
                    this.$('#adminExecuteSearch-adminTool').attr('disabled', false);
                    if (this.repoPath.length < 1) {
                        this.$('#deleteNodes-adminTool').attr('disabled', true);
                    } else {
                        this.$('#deleteNodes-adminTool').attr('disabled', false);
                    }
                } else {
                    this.$('#adminUpdateProperties-adminTool').attr('disabled', true);
                    this.$('#adminExecuteSearch-adminTool').attr('disabled', true);
                    this.$('#deleteNodes-adminTool').attr('disabled', true);
                }
            },
            afterRender: function() {
                if (this.loading) {
                    this.spinner = HPISpinner.createSpinner({}, this.$('#admin-display-outlet')[0]);
                } else {
                    this.$('#selectedSearchConfig-adminTool').val(this.searchConfigName);
                    this.$('#objectTypeSelector-adminTool')[0].selectedIndex = this.currentObjectTypeIndex;
					// If we have no types to show or no properties to search on, hide the search tool
                    if (this.OCTypesToShow.length > 0 && this.searchResultProperties.length > 0) {
                        this.setView('#searchPropertyAdder', new AdminSearchTool.PropertyAdder({
                            'propNames': this.propNames,
                            'dateFormat': this.dateFormat,
                            'timeFormat': this.timeFormat
                        })).render();
                        this.setView('#updatePropertyAdder', new AdminSearchTool.UpdateProperties({
                            'propNames': this.propNames
                        })).render();
                        this.$("#searchConfigError").text("");
                        this.$("#searchConfigError").removeClass("user-error-message-output");
                    } else if (this.searchConfigName !== "") {
                        if (this.OCTypesToShow.length <= 0) {
                            // Alert the user their search config has no types configured
                            this.$("#searchConfigError").text(window.localize("searchConfig.searchConfigMainLayout.searchConfig") + " " + this.searchConfigName + " " + window.localize("hpiAdmin.adminSearchTool.searchConfigNoType"));
                            this.$("#searchConfigError").addClass("user-error-message-output");
                        } else if (this.searchResultProperties.length <= 0) {
                            // Alert the user their search config has no properties configured for the chosen type
                            this.$("#searchConfigError").text(window.localize("searchConfig.searchConfigMainLayout.searchConfig") + " " + this.searchConfigName + " " + window.localize("hpiAdmin.adminSearchTool.searchConfigNoProperties") + " : " + this.objectType);
                            this.$("#searchConfigError").addClass("user-error-message-output");
                        } else {
                            this.$("#searchConfigError").text("");
                            this.$("#searchConfigError").removeClass("user-error-message-output");
                        }
                    } else {
                        this.$("#searchConfigError").text("");
                        this.$("#searchConfigError").removeClass("user-error-message-output");
                    }
                    if(this.passthroughQueryEnabled) {
                        this.setView('#passthroughQuery', new AdminSearchTool.PassthroughQuery()).render();
                    }
                }

                self.$('[data-toggle="tooltip"]').tooltip();
            },
            serialize: function() {
                return {
                    searchLimit: this.searchLimit,
                    OCTypes: this.OCTypesToShow,
                    loading: this.loading,
                    repoPath: this.repoPath,
                    searchConfigs: this.searchConfigs,
                    defaultQueryMode: this.defaultQueryMode,
                    passthroughQueryEnabled: this.passthroughQueryEnabled,
                    enableDirectSQL: app.enableDirectSQL
                };
            }

        });
        AdminSearchTool.PropertyAdder = Backbone.Layout.extend({
            template: "hpiadmin/adminsearchtool/addProperty",
            className: "adminsearchtool",
            events: {
                "change .propNameSelector": "updatePropName",
                "change .toDate": "updateToDate",
                "change .fromDate": "updateFromDate",
                "keyup .propValue": "updatePropValue",
                "change .propSearchType": "updatePropSearchType",
                "click .glyphicon-remove": "removeProperty",
                "click .addToBtn": "addToProperties"
            },
            initialize: function(options) {
                this.propNames = options.propNames;
                this.dateFormat = options.dateFormat;
                this.timeFormat = options.timeFormat;

                this.properties = [];

                this.currentPropName = "";
                this.currentPropValue = "";
                this.currentPropSearchType = "equals";
                this.currentPropNameOC = "";
                this.currentPropNameIndex = 0;
            },
            updatePropName: function(event) {
                var selector = $(event.target)[0];
                var index = selector.selectedIndex;
                this.currentPropNameIndex = index;
                this.currentPropName = selector.options[index].text;
                this.currentPropNameOC = selector.options[index].value;
                this.enableAddToSearch();
                this.render();
            },
            updateFromDate: function(event) {
                this.fromDateValue = $(event.target).val();
                this.enableAddToSearch();
            },
            updateToDate: function(event) {
                this.toDateValue = $(event.target).val();
                this.enableAddToSearch();
            },
            updatePropValue: function(event) {
                this.currentPropValue = $(event.target).val();
                this.enableAddToSearch();
            },
            updatePropSearchType: function(event) {
                this.currentPropSearchType = $(event.target).val();
            },
            enableAddToSearch: function() {
                if (this.date) {
                    if (this.toDateValue || this.fromDateValue) {
                        this.$('.addToBtn').attr('disabled', false);
                    } else {
                        this.$('.addToBtn').attr('disabled', true);
                    }
                } else {
                    if (this.currentPropValue) {
                        this.$('.addToBtn').attr('disabled', false);
                    } else {
                        this.$('.addToBtn').attr('disabled', true);
                    }
                }
            },
            addToProperties: function() {


                var index = _.findWhere(this.properties, {
                    propName: this.currentPropName
                });
                //if index is not undefined then that means the property is already being searched on
                if (!this.date) {
                    if (index !== undefined) {
                        index.propValue = this.currentPropValue;
                        index.searchType = this.currentPropSearchType;
                    } else {
                        this.properties.push({
                            propName: this.currentPropName,
                            propValue: this.currentPropValue,
                            propNameOC: this.currentPropNameOC,
                            propType: "string",
                            searchType: this.currentPropSearchType
                        });
                    }
                } else {
                    if (index !== undefined) {
                        index.toDate = this.toDateValue;
                        index.fromDate = this.fromDateValue;
                    } else {
                        this.properties.push({
                            propName: this.currentPropName,
                            fromDate: this.fromDateValue,
                            toDate: this.toDateValue,
                            propNameOC: this.currentPropNameOC,
                            propType: "date"
                        });
                    }
                }

                this.currentPropName = "";
                this.currentPropValue = "";
                this.currentPropSearchType = "equals";
                this.currentPropNameOC = "";
                this.fromDateValue = "";
                this.toDateValue = "";
                this.render();
            },
            removeProperty: function(event) {
                var currentId = event.currentTarget.id;
                _.each(this.properties, function(value, index, properties) {
                    if (value.propNameOC === currentId) {
                        properties.splice(index, 1);
                    }
                });
                this.render();
            },
            beforeRender: function() {
                app.trigger("searchPropertiesUpdated", this.properties);
                this.searchDate = true;
                if (this.propNames[this.currentPropNameIndex].dataType === "date") {
                    this.date = true;
                } else {
                    this.date = false;
                }
            },
            afterRender: function() {
                if (this.propNames) {
                    this.$('.propNameSelector')[0].selectedIndex = this.currentPropNameIndex;
                    this.currentPropName = this.$('.propNameSelector')[0].options[this.currentPropNameIndex].text;
                    this.currentPropNameOC = this.$('.propNameSelector')[0].options[this.currentPropNameIndex].value;
                    
					if (this.currentPropValue) {
						// If we have a current prop value, add it back to the DOM
						var propValueInput = this.$('.propValue')[0];
						if (propValueInput) {
                        	this.$('.propValue')[0].value = this.currentPropValue;
                        	this.$('.addToBtn').attr('disabled', false);
						}
                    }
                    if (this.currentPropSearchType) {
						// If we have a current prop search type, add it back to the DOM
                        var propSearchTypeDropdown = this.$('.propSearchType')[0];
                        if (propSearchTypeDropdown) {
                            propSearchTypeDropdown.value = this.currentPropSearchType;
                        }
                    }
                    
					if (this.date) {
                        this.$('.fromDate').datetimepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: this.dateFormat,
                            timeFormat: this.timeFormat
                        });
                        this.$('.toDate').datetimepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: this.dateFormat,
                            timeFormat: this.timeFormat
                        });
                    }
                }
            },
            serialize: function() {
                return {
                    propNames: this.propNames,
                    props: this.properties,
                    date: this.date,
                    searchDate: this.searchDate,
                    searchConfis: this.searchConfigs
                };
            }

        });
        AdminSearchTool.UpdateProperties = AdminSearchTool.PropertyAdder.extend({
            template: "hpiadmin/adminsearchtool/updateProperty",
            className: "adminsearchtool",
            beforeRender: function() {
                var self = this;
                this.searchDate = false;
                app.trigger("updatePropertiesUpdated", this.properties);
                if (this.propNames[0].hasOwnProperty('repoEditable')) {
                    self.propNames = _.filter(self.propNames, function(model) {
                        return (model.repoEditable);
                    });
                }
                if (this.propNames[this.currentPropNameIndex].dataType === "date") {
                    this.date = true;
                } else {
                    this.date = false;
                }
            }
        });
        AdminSearchTool.PassthroughQuery = Backbone.Layout.extend({
            template: "hpiadmin/adminsearchtool/passthroughquery",
            className: "adminsearchtool",
            events: {
                "keyup #adminSearchTool_passthroughquery_valueBox": "updateQueryString",
                "click #adminTool_adminpassthroughquery_executeBtn": "confirmExecuteQuery"
            },
            updateQueryString: _.debounce(function(event) {
                this.queryString = $(event.target).val();
                this.validate();
            }, 200),
            validate: function() {
                if (this.queryString.length) {
                    this.$('#adminTool_adminpassthroughquery_executeBtn').attr('disabled', false);
                } else {
                    this.$('#adminTool_adminpassthroughquery_executeBtn').attr('disabled', true);
                }
            },
            confirmExecuteQuery: function() {
                var self = this;

                var message = window.localize("hpiAdmin.adminSearchTool.passthroughQuery.confirm") + "\n" + self.queryString;

                app.trigger('alert:confirmation', {
                    message: message,
                    header: window.localize("hpiAdmin.adminSearchTool.passthroughQuery.confirm.header"),
                    confirmLabel: window.localize("hpiAdmin.adminSearchTool.executeSearch"),
                    confirmBtnClass: "btn-hpi",
                    cancelLabel: window.localize("generic.cancel"),
                    confirm: function() {
                        self.executeQuery();
                    }
                });
            },
            executeQuery: function(){
                var self = this;

                var callback = function() {
                    app.trigger('alert:info', {
                        message: window.localize("modules.actions.exportSearchResults.theResults"),
                        header: window.localize("hpiAdmin.adminSearchTool.passthroughQuery.downloading")
                    });
                };
                
                var fileName = "Query Results " + new Date().toString();
                fileName = fileName.substring(0, fileName.indexOf('-')) + '.xlsx';

                var sqlQueryAction = new Action.Model({
                    name: "executeReadOnlyPassThroughQuery",
                    actionId: "executeReadOnlyPassThroughQuery",
                    parameters: { 
                        queryString: self.queryString,
                        fileName: fileName
                    }
                });

                var errorHandler = function(errorReason) {
                    app.trigger("alert:error", {
                        header: window.localize("hpiAdmin.adminSearchTool.passthroughQuery.errorHeader"),
                        message: window.localize("hpiAdmin.adminSearchTool.passthroughQuery.error") + "\n" + errorReason
                    });
                };
                var url = app.serviceUrlRoot + '/action/executeAndReturnStream?download=true';


                downloadUtils.asyncDownload(url, sqlQueryAction.attributes, callback, errorHandler);
            }
        });

        return AdminSearchTool;
    });