// Confignavigator module
define([
    // Application.
    "app",
    "module"
    ],

// Map dependencies from above array.
function(app, module) {
    "use strict";

    // Create a new module.
    var AdminSecurity = app.module();

    // Default Model.
    AdminSecurity.Model = Backbone.Model.extend({
        defaults: function(){
            return {
                url: app.serviceUrlRoot + '/hpi/authenticateSecuredAdmin',
                password: '',
                username: '',
                loading: false,
                failure: ''
            };
        }
    });

    AdminSecurity.Views.LoginView = Backbone.Layout.extend({
        template: "hpiadmin/applicationconfig/securedadminlogin",
        events: {
            "click #admin-login-submit" : "submitCredentials",
            "keyup #admin-login-username" : "updateUsername",
            "keyup #admin-login-password" : "updatePassword"
        },

        initialize: function(options) {
            if(options){
                this.options = options;
            }

            this.model = new AdminSecurity.Model();
        },

        submitCredentials: function(evt) {
            evt.preventDefault();
            var self = this;

            $('#admin-loading').show();

            // Get our username and password from the view.
            this.setUsername();
            this.setPassword();

            // Build the endpoint URL to authenticate against OC.
            var adminAuthenticationURL = this.model.get('url') + '?username=' + this.model.get('username');

            // Call OC endpoint to authenticate this user's credentials into the admin.
            $.ajax({
                url: adminAuthenticationURL,
                data: JSON.stringify(self.model.get('password')),
                contentType: "application/json",
                type: "POST",
                success: function(authenticationAnswer) {
                    if(authenticationAnswer){
                        // User's credentials were successfully authenticated, continue to process the rest of the admin URL.
                        self.options.nextFunction();
                    } else {
                        // Set and show error message to the user.
                        $('#admin-login-error').text('Admin sign in failed, please re-enter credentials.');
                        $('#admin-login-error').show();
                        
                        // Clear the username and password from the view.
                        self.resetUsername();
                        self.resetPassword();

                        $('#admin-loading').hide();
                    }

                },
                error: function(jqXHR, textStatus) {
                    // Set and show error message to the user.
                    $('#admin-login-error').text('Admin sign in failed, please re-enter credentials.');
                    $('#admin-login-error').show();

                    // Clear the username and password from the view.
                    self.resetUsername();
                    self.resetPassword();

                    $('#admin-loading').hide();
                },
                async: false
            });
        },

        // Set the username that was submitted on the model.
        setUsername: function(){
            var username = $('#admin-login-username').val();
            this.model.set('username', username);
        },
        resetUsername: function(){
            this.model.set('username', '');
            $('#admin-login-username').val(this.model.get('username'));
        },

        // Set the password that was submitted on the model.
        setPassword: function(){
            var password = $('#admin-login-password').val();
            this.model.set('password', password);
        },
        // Reset the password on the model and respective view.
        resetPassword: function(){
            this.model.set('password', '');
            $('#admin-login-password').val(this.model.get('password'));
        }
    });

    // Return the module for AMD compliance.
    return AdminSecurity;

});
