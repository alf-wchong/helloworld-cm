define([
    "app",
    "knockout",
    "knockback"
],

    function (app, ko, kb) {
        "use strict";
        var OAModeSelect = app.module();

        OAModeSelect.SwitchView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/oamodeconfigswitch",
            initialize: function (options) {
                this.viewModel = options.viewModel;
            },
            afterRender: function () {
                kb.applyBindings(this.viewModel, this.$el[0]);
            },
            serialize: function () {
                return {
                    cid: this.cid
                };
            }
        });

        OAModeSelect.DropdownView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/oamodeconfigdropdown",
            initialize: function (options) {
                this.viewModel = options.viewModel;
            },
            afterRender: function () {
                kb.applyBindings(this.viewModel, this.$el[0]);
            },
            serialize: function () {
                return {
                    cid: this.cid
                };
            }
        });

        return OAModeSelect;
    });