//Collectionconfig Module
define([
        "app",
        "knockout",
        "knockoutsortable",
        "knockback",
        "modules/hpiadmin/hpiadmin",
        "modules/common/alert/alert",
        "modules/hpiadmin/searchconfig/groupactionsconfig",
        "modules/hpiadmin/searchconfig/resultsgridconfig",
        "modules/hpiadmin/searchconfig/resultslistconfig",
        "modules/hpiadmin/searchconfig/resultstableconfig"
    ],

    function(app, ko, kos, kb, Hpiadmin, Alert, GroupActionsConfig, ResultsGridConfig, ResultsListConfig, ResultsTableConfig) {

        // Create a new module
        var Collectionconfig = app.module();

        // Results Model
        Collectionconfig.ResultsConfig = Hpiadmin.Config.extend({
            initialize: function(options) {
                if (options && options.groupActionsConfig) {
                    this.set("groupActionsConfig", new GroupActionsConfig.Model(options.groupActionsConfig));
                } else {
                    this.set("groupActionsConfig", new GroupActionsConfig.Model());
                }
                if (options && options.resultsGridConfig) {
                    this.set("resultsGridConfig", new ResultsGridConfig.Model(options.resultsGridConfig));
                } else {
                    this.set("resultsGridConfig", new ResultsGridConfig.Model());
                }
                if (options && options.resultsTableConfig) {
                    this.set("resultsTableConfig", new ResultsTableConfig.Model(options.resultsTableConfig));
                } else {
                    this.set("resultsTableConfig", new ResultsTableConfig.Model());
                }
                if (options && options.resultsListConfig) {
                    this.set("resultsListConfig", new ResultsListConfig.Model(options.resultsListConfig));
                } else {
                    this.set("resultsListConfig", new ResultsListConfig.Model());
                }
            }
        });

        Collectionconfig.Model = Hpiadmin.Config.extend({
            type: "CollectionConfig",
            defaults: {
                type: "CollectionConfig",
                availableObjectTypes: []
            },
            initialize: function(options) {
                if (options && options.resultsConfig) {
                    this.set("resultsConfig", new Collectionconfig.ResultsConfig(options.resultsConfig));
                } else {
                    this.set("resultsConfig", new Collectionconfig.ResultsConfig());
                }
            },
            parseResponse: function(response) {
                if (this.id) {
                    //just want the id
                    response = _.pick(response, "id");
                } else if (response && response.resultsConfig) {
                    this.set("resultsConfig", new Collectionconfig.ResultsConfig(response.resultsConfig));
                    delete response.resultsConfig;
                }

                return response;
            }
        });

        Collectionconfig.ViewModel = kb.ViewModel.extend({
            constructor: function(model, options) {
                var self = this;

                kb.ViewModel.prototype.constructor.call(this, model, {
                    factories: {
                        "modules.groupActionsConfig": GroupActionsConfig.ViewModel,
                        "modules.resultsGridConfig": ResultsGridConfig.ViewModel,
                        "modules.resultsTableConfig": ResultsTableConfig.ViewModel,
                        "modules.resultsListConfig": ResultsListConfig.ViewModel
                    },
                    requires: ["id", "name", "availableObjectTypes"]
                });

                self.newConfigName = ko.observable("default");

                // get the types when we have selected a config
                self.potentialTypes = ko.observableArray();

                //get the default config 
                app.context.configService.getAdminOTC(function(model) {
                    self.potentialTypes.removeAll();
                    model.get("configs").each(function(type) {
                        self.potentialTypes.push({
                            "label": type.attributes.label,
                            "ocName": type.attributes.ocName
                        });
                    });
                });

                self.selectedTypes = ko.observableArray();
                self.availableObjectTypes = kb.observable(model, "availableObjectTypes");


                self.logModel = function() {};

                self.removeTypes = function() {
                    self.availableObjectTypes([]);
                };

                self.addTypes = function() {
                    var dummyArray = [];
                    _.each(self.selectedTypes(), function(item) {
                        dummyArray.push(item.ocName);
                    });
                    model.set("availableObjectTypes", dummyArray);
                };

                this.onCreateConfig = function() {
                    if (self.newConfigName() && !self.id()) {
                        model.set("name", self.newConfigName());
                    }
                    model.save(model.toJSON(), {
                        success: function() {
                            app.trigger("modelSaveOrDestroy");
                            Backbone.history.navigate("admin/CollectionConfig", { replace: true, trigger: true });
                            app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: window.localize("generic.errorSavingConfig"),
                                message: window.localize("generic.configSaveFailed")
                            });
                        }
                    });
                };

                this.subConfig = ko.observable();
                return this;
            }
        });

        Collectionconfig.Collection = Backbone.Collection.extend({
            model: Collectionconfig.Model
        });

        Collectionconfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/collectionconfig/collectionconfig-mainlayout",
            afterRender: function() {
                var that = this;
                if (this.viewModel) {
                    app.trigger("alert:info", {
                        header: window.localize("generic.alert"),
                        message: window.localize("modules.hpiAdmin.memoryLeak")
                    });
                }
                this.viewModel = new Collectionconfig.ViewModel(this.model, this);

                this.viewModel.subConfig.subscribe(function(value) {
                    switch (value) {
                        case "GroupActions":
                            that.setView("#subconfig-outlet", new GroupActionsConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("groupActionsConfig")
                            })).render();
                            break;
                        case "Search Results":
                            that.setView("#subconfig-outlet", new ResultsTableConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("resultsTableConfig"),
                                availableObjectTypes: that.model.get("availableObjectTypes")
                            })).render();
                            break;
                    }
                });
                ko.bindingHandlers.sortable.afterMove = this.viewModel.logModel;

                kb.applyBindings(this.viewModel, this.$el[0]);
            }
        });


        return Collectionconfig;

    });