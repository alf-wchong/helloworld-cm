// Attributesearchconfig module
define([
	// Application.
	"app"
],

// Map dependencies from above array.
function(app) {

	// Create a new module.
	var AttributeSearchConfig = app.module();

	//Submodels
	AttributeSearchConfig.TypeModel = Backbone.Model.extend({
		defaults : function() {
			return {
				objectType : "",
				defaultSortOrder : "",
				defaultSortAttr : "",
				allowSearchAllVersions : "false",
				defaultSearchAllVersions: "false"
			};
		}
	});

	AttributeSearchConfig.TypeCollection = Backbone.Collection.extend({
		model: AttributeSearchConfig.TypeModel
	});

	// Default Model.
	AttributeSearchConfig.Model = Backbone.Model.extend({
		defaults : function() {
			return {
				"type"		: "AttributeSearchConfig",
				"label"		: window.localize("modules.hpiAdmin.searchConfig.attributeSearchConfig.attributeSearch"),
				"enabled"	: false,
				"formTypes" : { "type": "",
								"defaultSortAttr": "",
								"defaultSortOrder": "",
								"allowSearchAllVersions": "",
								"defaultSearchAllVersions": ""
							}
			};
		},
		initialize: function(options){
			if(options && options.types){
				this.set("types", new AttributeSearchConfig.TypeCollection(options.types));
			} else {
				this.set("types", new AttributeSearchConfig.TypeCollection());
			}
		}
	});

	AttributeSearchConfig.GroupViewModel = kb.ViewModel.extend({
		constructor: function(model, options) {
			var self = this;

			kb.ViewModel.prototype.constructor.apply(this, arguments);

			self.groupLabel = ko.observable(model.get("label"));

			self.selectedAttributes = ko.observableArray([]);
			_.each(model.get('attributes'), function(attr) {
				self.selectedAttributes.push(attr);
			});

			self.selectedAttributes.subscribe(function() {
				var selected = [];
				_.each(self.selectedAttributes(), function(attr) {
					selected.push(attr);
				});
				model.set('attributes', selected);
			});

			return this;
		}
	});

	AttributeSearchConfig.TypeViewModel = kb.ViewModel.extend({
		constructor: function(model, options) {
			var self = this;

			self.showObjectText = ko.observable("Expand");
        	self.showObjectConfig = ko.observable(false);

			kb.ViewModel.prototype.constructor.apply(this, arguments);

			self.defaultSortOrder = kb.observable(model, 'defaultSortOrder');
			self.defaultSortAttr = kb.observable(model, 'defaultSortAttr');
			self.allowSearchAllVersions = kb.observable(model, 'allowSearchAllVersions');
			self.defaultSearchAllVersions = kb.observable(model, 'defaultSearchAllVersions');

			if(self.defaultSearchAllVersions() === null){
				self.defaultSearchAllVersions(false);
			}

			self.changeDefaultSortAttr = function(newSortAttr){
				self.defaultSortAttr(newSortAttr);
			};
			self.objectType = kb.observable(model, 'objectType');
			return this;
		}
	});

	AttributeSearchConfig.ViewModel = function(model, options) { 
			
		var self = this;

		self.id = kb.observable(model, "id");
		self.configName = kb.observable(model, "name");
		self.types = kb.collectionObservable(model.get("types") || new Backbone.Collection(),
		{
			view_model: AttributeSearchConfig.TypeViewModel
		});

		//enabled is configurable so we'll have to declare it here
		self.enabled = ko.observable();
		if (model.get("enabled")) {self.enabled("true");}
		else {self.enabled("false");}
		self.enabled.subscribe(function() {
			if (self.enabled() === "true") {
				model.set('enabled', true);
			} else {
				model.set('enabled', false);
			}
		});

		self.formTypes = kb.observable(model, "formTypes");
		var initialFormTypes = [];
		//loop over the types on the search config form to get
		//all the types from the form on our attribute search config
		//After this loop, we will have only the types on the form on the config
		_.each(options.availableObjectTypes, function(typeName){
			//see if the type is already on the attribute search config
			var existingType = _.findWhere(self.formTypes(), {"type": typeName});
			if(existingType){
				//if it is, great, we'll  use it
				initialFormTypes.push(existingType);
			} else {
				//if not, we want it on there, so add it
				initialFormTypes.push({
					"type" : typeName,
					"defaultSortAttr": "objectName",
					"defaultSortOrder": "-1",
					"allowSearchAllVersions": "false",
					"defaultSearchAllVersions": "false"
				});
			}
		});
		//set our formTypes collection
		self.formTypes(initialFormTypes);

		self.currentType = ko.observable();
		self.currentAttrs = ko.observableArray();
		self.setCurrentType = function(formType) {
			if (self.currentType() !== formType.type) {
				self.currentType(formType.type);
				app.context.configService.getAdminTypeConfig(formType.type, function(objectTypeConfig) {
					self.currentAttrs(objectTypeConfig.get('attrs').models);
				});
			} else {
				self.currentType(undefined);
			}
		};
		self.setDefaultSortAttr = function(attr) {
			var ocAttr = attr.get('ocName');

			_.find(self.formTypes(), function(object) { 
				return object.type === self.currentType();
			}).defaultSortAttrLabel= attr.get('label');

			_.find(self.formTypes(), function(object) { 
				return object.type === self.currentType();
			}).defaultSortAttr = ocAttr;

			//this is admittedly really stupid, best what I think is the most headache
			//free option. ko needs to know the observable changed, and since this is
			//a dependant, you can't call valueHasMutated
			self.formTypes(_.union(self.formTypes(), []));
		};
		self.updateFormTypes = function(order) {
			self.formTypes(_.union(self.formTypes(), []));
		};
		/** END FORMCONFIG ADDITIONS ****/
		return self;
	};


	// Default View.
	AttributeSearchConfig.Views.Layout = Backbone.Layout.extend({
		template : "hpiadmin/searchconfig/attributesearchconfig",

		initialize: function() {
			if(this.viewModel){
				app.trigger("alert:error", {
					header: window.localize("generic.alert"),
					message: window.localize("modules.hpiAdmin.memoryLeak")
				});
			}
		},
		beforeRender: function() {
			ko.bindingHandlers.enterKey = {
				init: function(element, valueAccessor, allBindings, vm) {
					ko.utils.registerEventHandler(element, "keyup", function(e) {
						if (e.keyCode === 13) {
							ko.utils.triggerEvent(element, "change");
							valueAccessor().call(vm, vm);
						}

						return true;
					});
				}
			};
		},
		afterRender: function() {
			var self = this;

			self.viewModel = new AttributeSearchConfig.ViewModel(this.model, this.options);
			self.viewModel.selectedTrac = this.options.selectedTrac;

			kb.applyBindings(self.viewModel, this.$el[0]);
		}
	});

	// Return the module for AMD compliance.
	return AttributeSearchConfig;

});
