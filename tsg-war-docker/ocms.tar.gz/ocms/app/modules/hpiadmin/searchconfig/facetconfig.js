define([
	"app"
],

function(app) {
	"use strict";

	var FacetConfig = app.module();

	//create a vent for all search control modules
    FacetConfig.vent = _.extend({}, Backbone.Events);

	FacetConfig.Type = Backbone.Model.extend({
		defaults: function() {
			return {
				objectType: "",
				facetableAttributes: [],
				filters: []
			};
		}
	});

	// The list of filters available for any given object type
	// objectType - the object type the filters are associated with
	// filters - an array of filters for the objectType
	// facetableAttrs - the list of attributes that are configured to be facetable
	FacetConfig.Filters = Backbone.Model.extend({
      defaults: function(){
        return {
          objectType: "",
          filters: [],
          facetableAttrs: []
        };
      }
    });

    // A filter for a given document type
    // label - the name of the filter
    // values - an array of objects containing the attribute name and values to be selected and faceted on
    FacetConfig.Filter = Backbone.Model.extend({
      defaults: function(){
        return {
          label: "",
          values: []
        };
      }
    });

    // A filter for a given attribute on a given object type
    // attribute- the pretty name of the attribute to filter on
    // ocName- the oc name of the attribute to filter on
    // values - an array of the values for the given attribute to select and facet on
    FacetConfig.AttributeFilter = Backbone.Model.extend({
      defaults: function(){
        return {
          attribute: "",
          ocName: "",
          values: []
        };
      }
    });

	FacetConfig.TypeCollection = Backbone.Collection.extend({
		model: FacetConfig.Type
	});

	FacetConfig.Model = Backbone.Model.extend({
		defaults: function(){
			return {
				"type"		: "Facetconfig",
				"label"		: window.localize("modules.hpiAdmin.searchConfig.facetConfig.facets"),
				"enabled"	: false
			};
		},
		initialize: function(options){
			if(options && options.types){
				this.set("types", new FacetConfig.TypeCollection(options.types));
			} else {
				this.set("types", new FacetConfig.TypeCollection());
			}
		}
	});

	FacetConfig.TypeView = kb.ViewModel.extend({
		constructor: function(model) {
			var self = this;
			self.showObjectText = ko.observable("Expand");
        	self.showObjectConfig = ko.observable(false);
        	self.toggleShowObject = function() {
	            if (self.showObjectConfig()) {
	                self.showObjectConfig(false);
	                self.showObjectText("Expand");
	            } else {
	                self.showObjectConfig(true);
	                self.showObjectText("Collapse");

	            }
        	};

			kb.viewModel.prototype.constructor.apply(this, arguments);

			// cant have spaces in html id so creating object name with no spaces
			this.objectName = model.get("objectType");
			if(this.objectName.indexOf(" ") !== -1){
				self.objectName = self.objectName.split(" ")[0];
			} 

			model.set({objectName: this.objectName}); 

			self.objectType = kb.observable(model, 'objectType');

			self.selectedAttributes = ko.observableArray([]);
			_.each(model.get('facetableAttributes'), function(attr) {
				self.selectedAttributes.push(attr);
			});

			self.selectedAttributes.subscribe(function() {
				var attrs = [];
				_.each(self.selectedAttributes(), function(attr) {
					attrs.push(attr);
				});
				model.set('facetableAttributes', attrs);
				FacetConfig.vent.trigger("facetConfig:attributesChanged", model );
			});

			self.potentialAttributes = ko.observableArray([]);
			app.context.configService.getAdminTypeConfig(self.objectType(), function(typeConfig) {
				var remainingVals = _.reject(typeConfig.get("attrs").models, function(attr) {
					return _.find(model.get('facetableAttributes'), function(alreadyInAttr) {
						return alreadyInAttr.attrName === attr.get('ocName');
					});
				});
				_.each(remainingVals, function(attr)  {
					self.potentialAttributes.push({
						attrName: attr.get('ocName'),
						attrLabel: attr.get('label')
					});
				});
			});	

			return self;
		}
	});

	function ConfigViewModel(model, options, parentView) {
		var self = this;
		self.id = kb.observable(model, 'id');


			/** BEGIN AWFUL KNOCKBACK CODE **/
        //this is pretty terrible, but the knockback constructor was not honoring
        //the object we passed in, but by pushing stuff onto the collection
        //everything built correctly. this code should never be copied ever, please
        //just rip out knockback
        var tempTypes = model.get("types");
        model.set("types", new Backbone.Collection());
        self.types = kb.collectionObservable(model.get("types"), 
            {
                view_model: FacetConfig.TypeView
            }
        );
        _.each(tempTypes.models, function(type) {
            model.get("types").push(type);
        });
        /** END AWFUL KNOCKBACK CODE**/

		//enabled is configurable so we'll have to declare it here
		self.enabled = ko.observable();
		if (model.get("enabled")) {self.enabled("true");}
		else {self.enabled("false");}
		self.enabled.subscribe(function() {
			if (self.enabled() === "true") {
				model.set('enabled', true);
			} else {
				model.set('enabled', false);
			}
		});
		
		//grab our potential type names from the top level config, and use the config
		//service to get their full set of attributes
		self.potentialTypes = ko.observableArray();
		self.getTypes = function() {
			self.potentialTypes.removeAll();
			_.each(options.availableObjectTypes, function(item){
				app.context.configService.getAdminTypeConfig(item, function(typeConfig){
					var isNew = true;

					_.each(model.get("types").models, function(oldType) {
						if (oldType.get("objectType") === typeConfig.get("ocName")) {isNew = false;}
					});

					if (isNew) {self.potentialTypes.push(typeConfig);}
				});
			});
		};
		self.getTypes();
		
		self.selectedType = ko.observable();
		self.selectedType.subscribe(function(type) {
		if (type) {
			self.potentialTypes.remove(type);
			var newType = new FacetConfig.Type({objectType: type.get("ocName"),

				// default to have no filters configured
				filters: new FacetConfig.Filters({
					filters: [],
					objectType: type.get("ocName")
				})
			});
			model.get("types").push(newType);
			self.selectedType(undefined);
			
			// when you add a new type in facet config we need to re render the view
			parentView.render();
		}
		});
			
		self.showAddType = ko.observable();
		self.showAddTypeForm = function() {
			self.showAddType(true);
		};
		self.cancelAddType = function() {
			self.showAddType(false);
		};
		
		self.removeType = function(type) {
			_.each(model.get("types").models, function(t) {
				if (t.get("objectType") === type.objectType()) {
					model.get("types").remove(t);
				}
			});
			self.getTypes();
		};

		return self;
	}

	FacetConfig.Views.RoleBasedViewAdderView = Backbone.Layout.extend({
	    template: "hpiadmin/searchconfig/addnewrolebasedview",

	     events: {
        	"click #add-filter-btn": "addFilter"
    	},

	    initialize: function(options) {
	    	this.filterCollection = options.model;
	        this.model = new FacetConfig.Filter();
	    },

	    afterRender: function() {
	        $('#filter-name-input-' + this.filterCollection.objectName).val(this.model.get("label"));
	    },

	    //when the add button is clicked
	    addFilter: function(evt) {
	        evt.stopPropagation();
	        var objectName = this.filterCollection.objectName ? this.filterCollection.objectName : this.filterCollection.get("objectName");
	        var newLabel = $('#filter-name-input-' + objectName).val();
	        if (newLabel !== "") {
	            this.model.set("label", newLabel);

	            // create all the attributes from the set of available attributes
	            var values = [];
	            var facetAttrs = this.filterCollection.facetableAttrs ? this.filterCollection.facetableAttrs : this.filterCollection.get("facetableAttrs");
	            _.each(facetAttrs, function(attribute){
	            	values.push(new FacetConfig.AttributeFilter({attribute: attribute.attrLabel, ocName: attribute.attrName, values: []}));
	            });
	            if (this.filterCollection.filters){
	       		    this.filterCollection.filters.push({label: newLabel, values: values});
	       		} else {
	       			this.filterCollection.get("filters").push({label: newLabel, values: values});
	       		}
	            //tell the parent view that a new filter is added, so it adds it to the entire config
	            FacetConfig.vent.trigger('facetConfig:addNewFilter', objectName);
	            this.model = new FacetConfig.Filter();
	            this.render();
	        }
	    },

	    serialize: function() {
	        var filterType = this.filterCollection.objectName ? this.filterCollection.objectName : this.filterCollection.get("objectName");

	        return {
	             filterType: filterType
	        };
	    }
	});   

	// View for the list of all currently configured role-based filter views
	FacetConfig.Views.RoleBasedFilterView = Backbone.Layout.extend({
	   template: "hpiadmin/searchconfig/facetrolebasedfilters",
	   events: {
	        "click #remove-filter-btn": "removeFilterClicked",
	        "click #edit-filter-btn": "filterSelected"
	    },

	    initialize: function(options) {
	    	var self = this;
	   
	        this.filterCollection = options.collection;
	      
	        this.listenTo(FacetConfig.vent, "facetConfig:addNewFilter", function(objectType) {
	            this.render();
	        });

	        this.listenTo(FacetConfig.vent, "facetConfig:attributesChanged", function(model){
	        	var objectType = self.filterCollection.objectType ? self.filterCollection.objectType : self.filterCollection.get("objectType");
	        	if (objectType === model.get("objectType")){
	        		self.updateAvailableAttributes(model);
	        	}
	        });
	    },

	    //when the remove button is clicked, remove the filter
	    removeFilterClicked: function(evt) {
	        var self = this;
	        evt.stopPropagation();

	        // get the label
	        var labelClicked = $(evt.target).attr("value");

	        // launch the modal to prompt the user to confirm removing the value
	        app.trigger("alert:confirmation", {
	            header: window.localize("searchConfig.facetConfig.removeFilter"),
	            message: window.localize("searchConfig.facetConfig.youAreAbout"),
	            confirm: function(evt) {
	                self.removeFilter(labelClicked);
	            }
	        });

	    },

	    //removes filter based on the filter that was clicked and its label
	    removeFilter: function(labelClicked) {
	        var deleteFilter = {};
	        var filters = this.filterCollection.filters ? this.filterCollection.filters : this.filterCollection.get("filters");
	        //find the filter in the filter collection that matches
	        //the label of the filter that was clicked to be able to remove the correct filter
	        deleteFilter = _.find(filters, function(filter) {
	            return filter.label === labelClicked;
	        });

	        // get our filter collection without the current filter
	   		this.filterCollection.filters = _.without(filters, deleteFilter);
	   		
	        this.render();
	    },

	    //highlights and shows filter when clicked
	    filterSelected: function(evt) {
	        evt.stopPropagation();
	        this.selectedFilter = $(evt.currentTarget).attr("value");

	        //remove any highlights on any of the filter firts, before highlighting the new selected filter
	        $('.filter-label').removeClass('filter-selected');
	        $(evt.currentTarget.parentElement.previousElementSibling).addClass('filter-selected');

	      	this.showFilter(this.selectedFilter);
	    },

	    //when filter is selected, shows the details based on the type
	    showFilter: function(showLabel){

	        var self = this;

	        var filters = this.collection.filters ? this.collection.filters : this.collection.get("filters");
	        // find the filter we want based on the label that was clicked
	        var filter = _.find(filters, function(filter){
	            return filter.label === showLabel;
	        });

	        // Set our filter view to the one that was selected
	        self.activeFilterView = new FacetConfig.Views.FilterAttributesView({
	            model: filter
	        });

	        // set our view and render it
	        self.setView("#filter-attributes", this.activeFilterView).render();
	    },

	    // function to update the available attributes when the facetable attributes changes
	    updateAvailableAttributes: function(model){
	    	var self = this;

	    	// Set the available attributes on the collection so that new filters will have access to it
	    	this.filterCollection.facetableAttrs = model.get("facetableAttributes");

    		// Our list of filters that we will have after updating
    		var newFilters = [];

    		// the current collection of filters
    		var filters = this.collection.filters ? this.collection.filters : this.collection.get("filters");

    		// loop through each of the filters for this type, updating the available attributes on each
    		_.each(filters, function(filter){

    			newFilters = self.createNewFilters(model, filter);

    			// change out our old filter for the new one with the new list of attributes
	    		filter.values = newFilters;

	    		// reset the array
	    		newFilters = [];

    		});
    		
    		self.render();
	    },
	
		// goes through all available attributes, creating filters for those that do not exist while leaving the old configured attributes in place. 
	    createNewFilters: function(model, filter){
	    	var newFilters =[];
	    	// loop through each of the available attributes
			_.each(model.get("facetableAttributes"), function(attr){
				// see if we currently have a filter for this attribute, in case this attribute was already configured on
    			var attrFilter = _.find(filter.values, function(value){
    				return value.ocName === attr.attrName;
    			});

    			// If we already have this attribute, add it to our list. Otherwise, create a new filter for it
    			if (attrFilter){
    				newFilters.push(attrFilter);
    			} else {
    				newFilters.push(new FacetConfig.AttributeFilter({attribute: attr.attrLabel, ocName: attr.attrName, values: []}));
    			}
    		});
    		return newFilters;
		},

	    // If no facets are configured, we send a message saying as much
	    beforeRender: function(){
	    	if (this.options.collection.filters && this.options.collection.filters.length < 1) {
	            this.filterEmpty = true;
	        } else {
	            this.filterEmpty = false;
	        }
	    },


	    afterRender: function(){
	    	// removing all the other views whenever a new pre defined view is added or deleted
		   	this.$el.find("#configured-attributes").hide();
		   	this.$el.find("#add-attribute-values").hide();
		   	this.$el.find("#configured-values").hide();	

		   	self.$('[data-toggle="tooltip"]').tooltip();
	    },

	    serialize: function() {
	    	var filters = this.filterCollection.filters;
	    	if (!filters){
	    		filters = this.filterCollection.get("filters");
	    	}
	        return {
	            filters: JSON.parse(JSON.stringify(filters)),
	            filterEmpty: this.filterEmpty
	        };
	    }
	});

	// The view for all facets that are able to be configured to have filters
	FacetConfig.Views.FilterAttributesView = Backbone.Layout.extend({
	   template: "hpiadmin/searchconfig/filterattributesview",
	   events: {
	        "click #edit-attribute-btn": "attributeSelected"
	    },

	    initialize: function(options) { },

	    //highlights and shows filter when clicked
	    attributeSelected: function(evt) {
	        evt.stopPropagation();
	        this.selectedAttribute = $(evt.currentTarget).attr("value");
	        //remove any highlights on any of the filter first, before highlighting the new selected filter
	        $('.attribute-label').removeClass('filter-selected');
	        $(evt.currentTarget.parentElement.previousElementSibling).addClass('filter-selected');
	      	this.showAttribute(this.selectedAttribute);

	      	// Making sure that the views are made visible now that an attribute has been selected
	      	this.$el.find("#add-attribute-values").show();
	   		this.$el.find("#configured-values").show();

	    },

	    //when filter is selected, shows the details based on the type
	    showAttribute: function(showLabel){

	     var self = this;

	     // get our list of values for the given attribute
	     var values = _.find(self.model.values, function(model){
	     	if (model.attribute){
	     		return model.attribute === showLabel;
	     	} else {
	     		return model.get("attribute") === showLabel;
	     	}
	     });

	     // Set our two new views, on to be able to add a new value, and one to list out all the values
	     self.setView("#add-attribute-value", new FacetConfig.Views.AttributeAddValueView({values: values})).render();
	     self.setView("#attribute-values-list-view", new FacetConfig.Views.AttributeValueListView({ values: values})).render();
	    },

	    // if no attributes are configured, we want to tell the user that
	    beforeRender: function(){
	    	if (this.options.model.values < 1) {
	            this.attributeEmpty = true;
	        } else {
	            this.attributeEmpty = false;
	        }
	    },

	    afterRender: function(){
	    	// Making sure that the other two views are hidden
	      	this.$el.find("#add-attribute-values").hide();
	   		this.$el.find("#configured-values").hide();
	    },

	    serialize: function() {
	        return {
	            attributes: JSON.parse(JSON.stringify(this.model.values)),
	            attributeEmpty: this.attributeEmpty
	        };
	    }
	});

	// View to add a new value to the attribute collection
	FacetConfig.Views.AttributeAddValueView = Backbone.Layout.extend({
		template: "hpiadmin/searchconfig/addnewattributevalue",

	     events: {
        	"click #add-attribute-value-btn": "addValue"
    	},

	    initialize: function(options) { },

	    afterRender: function() {
	        this.$el.find("#attribute-value-input").focus();
	    },

	    //when the add button is clicked
	    addValue: function(evt) {
	        evt.stopPropagation();
	        var newLabel = this.$el.find('#attribute-value-input').val();
	        if (newLabel !== "") {
	            this.value = newLabel;
	            if (_.isArray(this.values.values)){
		            this.values.values.push(this.value);
		        } else {
		        	this.values.get("values").push(this.value);
		        }

	            //tell the parent view that a new filter is added, so it adds it to the entire config
	            FacetConfig.vent.trigger('facetConfig:addNewAttributeValue', this.value);
	            this.render();
	        }
	    }

	});

	FacetConfig.Views.AttributeValueListView = Backbone.Layout.extend({
	   template: "hpiadmin/searchconfig/attributevaluelist",

	   events: {
	        "click #remove-attribute-value-btn": "removeValueClicked"
	    },

	    initialize: function(options) {
	    	this.values = options.values;

	        this.listenTo(FacetConfig.vent, "facetConfig:addNewAttributeValue", function(value) {
	            this.render();
	        });
	    },

	    //when the remove button is clicked
	    removeValueClicked: function(evt) {
	        var self = this;
	        evt.stopPropagation();
	        var labelClicked = $(evt.target).attr("value");
	        app.trigger("alert:confirmation", {
	            header: window.localize("searchConfig.facetConfig.removeValue"),
	            message: window.localize("searchConfig.facetConfig.youAreAbout"),
	            confirm: function(evt) {
	                self.removeValue(labelClicked);
	            }
	        });

	    },

	    //removes filter based on the filter that was clicked and its label
	    removeValue: function(labelClicked) {
	        var vals = this.values.values;
	        if(!_.isArray(vals)){
				vals = this.values.get("values");
			}
	        //find the filter in the filter collection that matches
	        //the label of the filter that was clicked to be able to remove the correct filter

	   		this.values.values = _.without(vals, labelClicked);
	        this.render();
	    },

	    serialize: function() {
	    	var vals = this.values.values;
	    	if (!_.isArray(vals)) {
	    		vals = this.values.get("values");
	    	}
	        return {
	            values: JSON.parse(JSON.stringify(vals))
	        };
	    }
	});

	FacetConfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/searchconfig/facetconfig",
		initialize: function() {
			var self = this;
			this.viewModel = new ConfigViewModel(this.facetModel, this.options, this);

			//this should eventually be a part of facet config and then cached so that hpi can remember it whenever anyone logs in 
			this.model = new FacetConfig.Model();

			//populating all the potential and selected attributes for the different types
			var types = this.facetModel.get("types").models;

			this.objectTypes = [];

			_.each(types, function(type) {
				self.objectTypes.push(type.get("objectType"));
			    type.selectedAttributes = [];
			    //eventually this needs to be attributes on which filters have already been placed. For new views, selected attributes should be blank
			    _.each(type.get('facetableAttributes'), function(attr) {

			        type.selectedAttributes.push(attr);
			    });

			    type.filters = new FacetConfig.Filters();
			    
			
			    type.potentialAttributes = [];
			    app.context.configService.getAdminTypeConfig(type.get("objectType"), function(typeConfig) {
			        var remainingVals = _.reject(typeConfig.get("attrs").models, function(attr) {
			            return _.find(self.model.get('facetableAttributes'), function(alreadyInAttr) {
			                return alreadyInAttr.attrName === attr.get('ocName');
			            });
			        });
			        _.each(remainingVals, function(attr) {

			            type.potentialAttributes.push({
			                attrName: attr.get('ocName'),
			                attrLabel: attr.get('label')
			            });

			        });
			    });
			});
		},

	    serialize: function() {
	    	return{
	    		objectTypes : this.objectTypes
	    	};
	    },
	
		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);

			var self = this;
	    	var viewAdderEl, filterEl;
	    	_.each(this.options.facetModel.get("types").models, function(objectTypeInfo){
	    		var objectType = objectTypeInfo.get("objectType");

	    		var objectName = objectType;
				if(objectName.indexOf(" ") !== -1){
					objectName = objectName.split(" ")[0];
				} 

				// our type-specific elements
				viewAdderEl = "#roleBased-view-adder-" + objectName;
				filterEl = "#roleBased-filter-" + objectName;

				// find our current type config
				var type = _.find(self.options.facetModel.get("types").models, function(model) {
				 	return model.get('objectType') === objectType;
				 });

				// get the filters for the type
				var filterCollection = type.get("filters");
				if(filterCollection){ 
					filterCollection.objectName = objectName;
					filterCollection.facetableAttrs = type.get("facetableAttributes");
				}

				// Need to create our facetable attributes for this object
				if (_.isArray(filterCollection)){
					var facetableAttrs = [];
					_.each(type.get("facetableAttributes"), function(attr){
						facetableAttrs.push(new FacetConfig.AttributeFilter({attribute: attr.attrLabel, ocName: attr.attrName, values: []}));
					});
					filterCollection = new FacetConfig.Filters({
						objectType: objectType,
						objectName: objectName,
						filters: [],
						facetableAttrs: facetableAttrs
					});
				}

				// set our add view, as well as the view that has the list of all views
				self.setView(viewAdderEl, new FacetConfig.Views.RoleBasedViewAdderView({model: filterCollection})).render();
				self.roleBasedFilterView = new FacetConfig.Views.RoleBasedFilterView({
           			collection: filterCollection,
          			facetModel: self.options.facetModel, 
          			facetableAttrs: type.get("facetableAttributes")
           		});
				self.setView(filterEl, self.roleBasedFilterView).render();


			});

			self.$('[data-toggle="tooltip"]').tooltip();
		}
	});

	return FacetConfig;

});