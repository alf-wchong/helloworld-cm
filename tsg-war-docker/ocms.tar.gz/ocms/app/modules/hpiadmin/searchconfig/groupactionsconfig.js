// Groupactionsconfig module
define([
    // Application.
    "app",
    "modules/hpiadmin/actionconfig/hpiactionconfig"
],

// Map dependencies from above array.
function(app, ActionConfig) {

    "use strict";

    // Create a new module.
    var Groupactionsconfig = app.module();

    Groupactionsconfig.Model = Backbone.Model.extend({
        defaults : function(){
            return {
                "type": "GroupActions",
                "label": window.localize("modules.hpiAdmin.searchConfig.groupActionConfig.groupActions"),
                "enabled": true
            };
        },
        initialize: function(options){
            if(options && options.actions){
                this.set("actions", new ActionConfig.Collection(options.actions));
            } else {
                this.set("actions", new ActionConfig.Collection());
            }
        }

    });


    // Default View.
    Groupactionsconfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/searchconfig/groupactionsconfig",
        initialize: function(){
            this.viewModel = {};
            this.viewModel.name = ko.observable(this.options.tracName);
            //put the action template onto the page and augment viewmodel
            this.setView("#action-config-template-outlet", new ActionConfig.View({
                viewmodel: this.viewModel,
                model : this.model,
                showSingleActions: false,
                availableObjectTypes: this.options.availableObjectTypes
            }));
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);
        }
    });

    // Return the module for AMD compliance.
    return Groupactionsconfig;

});