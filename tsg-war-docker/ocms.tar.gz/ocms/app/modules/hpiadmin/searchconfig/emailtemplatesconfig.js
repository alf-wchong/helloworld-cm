define([
	"app",
	"modules/hpiadmin/hpiadmin"
],

function(app, Hpiadmin){
	var EmailTemplatesConfig = app.module();

	EmailTemplatesConfig.vent = _.extend({}, Backbone.Events);

	EmailTemplatesConfig.Model = Hpiadmin.Config.extend({
		defaults: {
			type: "EmailTemplatesConfig",
			name: "default",
			templates: []
		}
	});

	EmailTemplatesConfig.Layout = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/emailtemplatesconfig",
		events: {
			"click #create-new-template-btn" : "createNewTemplate",
			"click #save-email-templates-btn": "saveTemplatesToRepo"
		},
		initialize: function(){
			var self = this;
			this.templatesConfig = new EmailTemplatesConfig.Model();
			this.templatesConfig.fetch({
				complete: function(jqXHR, textStatus){
					self.templates = new Backbone.Collection(self.templatesConfig.get("templates"));
					self.refreshTemplatesList();
					
					self.selectedTemplateDetailsView = new EmailTemplatesConfig.SelectedTemplateDetailsView({
						templateIsSelected: false,
						name: "",
						content: ""
					});
					self.insertView(".email-template-details-outlet", self.selectedTemplateDetailsView).render();
					self.setAlert(false, "", [], "");
				}
			});

			this._stopListening();
			this.startListening();
		},
		_stopListening: function(){
			this.stopListening(EmailTemplatesConfig.vent);
		},
		startListening: function(){
			this.listenTo(EmailTemplatesConfig.vent, "select:template:to:display", function(templateName){
				this.displaySelectedTemplateDetails(templateName);
			});

			this.listenTo(EmailTemplatesConfig.vent, "remove:email:template", function(templateName){
				this.removeTemplate(templateName);
			});

			this.listenTo(EmailTemplatesConfig.vent, "update:current:template:details", function(fieldUpdatedName){
				this.saveTemplateLocally(fieldUpdatedName);
			});
		},
		// Rerenders the templatesListView to reflect the updated templates list.
		refreshTemplatesList: function(){
			if(this.templatesListView){
				this.templatesListView.remove();
			}
			this.templatesListView = new EmailTemplatesConfig.TemplatesListView({
				templates: this.templates
			});
			this.insertView(".email-templates-list-outlet", this.templatesListView).render();
		},
		// Finds the template with the specified name in the collection of templates.
		getTemplateLocally: function(templateName){
			return _.find(this.templates.models, function(templateModel){
				return templateModel.get("name") === templateName;
			});
		},
		// Updates the templatesConfig model with the current templates collection and saves the updated
		// model to the config object in the repo.
		saveTemplatesToRepo: function(){
			var self = this;
			this.templatesConfig.set("templates", this.templates);
			this.templatesConfig.save({}, {
				success: function(){
					self.setAlert(true, window.localize("customConfig.emailTemplatesConfig.alert.saved"), ["alert-danger", "alert-warning"], "alert-success");
				},
				error: function(){
					self.setAlert(true, window.localize("customConfig.emailTemplatesConfig.alert.error"), ["alert-success", "alert-warning"], "alert-danger");
				}
			});
		},
		// Saves the template the user is currently editing to the working collection. This function 
		// is responsible for saving either the template name or content depending on which field the 
		// user is editing. If the user edits the template name to a value that isn't unique, it will
		// not be saved.
		saveTemplateLocally: _.throttle(function(fieldUpdatedName){
			var self = this;
			var fieldUpdatedValue = $("#email-template-" + fieldUpdatedName).val();

			//If we are passing a name, make sure it is unique, as this is acting as our id
			if(fieldUpdatedName === "name" && this.getTemplateLocally(fieldUpdatedValue) && fieldUpdatedValue !== this.currentTemplateName){
				self.setAlert(true, window.localize("customConfig.emailTemplatesConfig.alert.mustBeUnique"), ["alert-danger", "alert-success"], "alert-warning");
				$("#save-email-templates-btn").prop('disabled', true);
				return;
			}

			// Update the value (fieldUpdatedValue) of the attribute (fieldUpdatedName) for the 
			// element in the templates collection that we are currently editing (currentTemplateName)
			this.templates.where({name: self.currentTemplateName}).map(function(templateToSave){
				templateToSave.set(fieldUpdatedName, fieldUpdatedValue);
			});
			this.refreshTemplatesList();

			// If the user updated the template name, update the current template name to the new value.
			// Since the name is the id of the template, we need to keep this up to date at all times.
			if(fieldUpdatedName === "name"){
				this.updateCurrentTemplateName(fieldUpdatedValue);
			}
			self.setAlert(false, "", [], "");
			$("#save-email-templates-btn").prop('disabled', false);
		}, 1000),
		// currentTemplateName keeps track of the name (id) of the template that is currently being edited
		// so when changes are made to this template, we can easily find it to make these changes
		updateCurrentTemplateName: function(templateName){
			this.currentTemplateName = templateName;
		},
		// Rerenders the templateDetailsView to reflect the template that is currently being edited.
		displaySelectedTemplateDetails: function(templateName){
			if(templateName !== this.currentTemplateName){
				var templateToDisplay = this.getTemplateLocally(templateName);

				this.updateCurrentTemplateName(templateName);

				this.selectedTemplateDetailsView.remove();
				this.selectedTemplateDetailsView = new EmailTemplatesConfig.SelectedTemplateDetailsView({
					templateIsSelected: templateToDisplay ? true : false,
					name: templateToDisplay ? templateToDisplay.get("name") : "",
					content: templateToDisplay ? templateToDisplay.get("content") : ""
				});
				this.insertView(".email-template-details-outlet", this.selectedTemplateDetailsView).render();
				this.setAlert(false, "", [], "");
			}
		},
		removeTemplate: function(templateName){
			var templateToRemove = this.getTemplateLocally(templateName);

			this.templates.remove(templateToRemove);
			this.refreshTemplatesList();
			this.displaySelectedTemplateDetails();

			this.setAlert(false, "", [], "");
		},
		// Creates a new template with default values and adds it to the collection.
		createNewTemplate: function(){
			var newTemplate = new Backbone.Model({
				name: "New Email Template",
				content: "Template Content Goes Here..."
			});

			// Only add a new template if the user has changed the name of the previous new template they added
			if(!this.getTemplateLocally(newTemplate.get("name"))){
				this.templates.add(newTemplate);
				this.refreshTemplatesList();
				this.displaySelectedTemplateDetails(newTemplate.get("name"));
				this.setAlert(false, "", [], "");
			}
			else{
				this.setAlert(true, window.localize("customConfig.emailTemplatesConfig.alert.cannotCreate") + newTemplate.get("name") + window.localize("customConfig.emailTemplatesConfig.alert.toBeUnique"), ["alert-danger", "alert-success"], "alert-warning");
			}
		},
		// Shows or hides an alert message and adds/removes the proper classes to visually represent the 
		// type of alert that is being displayed.
		setAlert: function(show, message, classesToRemove, classToAdd){
			$("#email-templates-alert-message").html(message);

			_.each(classesToRemove, function(removeClass){
				$("#email-templates-alert").removeClass(removeClass);
			});

			if(classToAdd){
				$("#email-templates-alert").addClass(classToAdd);
			}

			if(show){
				$("#email-templates-alert").show();
			}
			else{
				$("#email-templates-alert").hide();
			}
		}
	});

	EmailTemplatesConfig.TemplatesListView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/emailtemplateslist",
		events: {
			"click #template-item": "selectTemplate",
			"click #remove-email-template": "removeTemplate"
		},
		initialize: function(options){
			this.templates = options.templates;
		},
		selectTemplate: function(e){
			var templateName = $(e.currentTarget).attr("data-value");
			EmailTemplatesConfig.vent.trigger("select:template:to:display", templateName);
		},
		removeTemplate: function(e){
			var templateName = $(e.currentTarget).parent().attr("data-value");
			EmailTemplatesConfig.vent.trigger("remove:email:template", templateName);
		},
		serialize: function(){
			return{
				templates: this.templates.toJSON()
			};
		}
	});

	EmailTemplatesConfig.SelectedTemplateDetailsView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/emailtemplatedetails",
		events: {
			"keyup #email-template-name": "updateCurrentTemplateName",
			"keyup #email-template-content": "updateCurrentTemplateContent"
		},
		initialize: function(options){
			this.templateIsSelected = options.templateIsSelected;
			this.name = options.name;
			this.content = options.content;
		},
		updateCurrentTemplateName: function(e){
			EmailTemplatesConfig.vent.trigger("update:current:template:details", "name");
		},
		updateCurrentTemplateContent: function(e){
			EmailTemplatesConfig.vent.trigger("update:current:template:details", "content");
		},
		serialize: function(){
			return{
				templateIsSelected: this.templateIsSelected,
				name: this.name,
				content: this.content
			};
		}
	});

	return EmailTemplatesConfig;
});