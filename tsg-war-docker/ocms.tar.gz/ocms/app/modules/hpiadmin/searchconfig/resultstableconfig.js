// Resultstableconfig module
define([
  // Application.
    "app",
    "modules/hpiadmin/searchconfig/genericresultsconfig"
],

// Map dependencies from above array.
function(app, GenericResultsConfig) {

    // Create a new module.
    var Resultstableconfig = app.module();

    Resultstableconfig.TypeCollection = Backbone.Collection.extend({
        model: Resultstableconfig.TypeModel
    });

    // Default Model.
    Resultstableconfig.Model = GenericResultsConfig.Model.extend({
        defaults : function() {
            return {
                "type"      : "ResultsTable",
                "label"     : window.localize("modules.hpiAdmin.searchConfig.resultStableConfig.tableView"),
                "enabled"   : true,
                "icon"      : ""
            };
        }
    });
    
    //open for extension
    Resultstableconfig.ViewModel = GenericResultsConfig.ViewModel;

    Resultstableconfig.Views.Config = GenericResultsConfig.Views.Config.extend({
        template : "hpiadmin/searchconfig/resultstableconfig"
    });

    // Default View.
    Resultstableconfig.Views.Layout = GenericResultsConfig.Views.Layout.extend({
        template: "hpiadmin/searchconfig/resultstableconfig"
    });

    // Return the module for AMD compliance.
    return Resultstableconfig;
});
