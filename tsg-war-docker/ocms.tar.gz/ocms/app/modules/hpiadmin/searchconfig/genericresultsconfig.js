// Resultstableconfig module
define([
    // Application.
    "app",
    "module",
    "modules/hpiadmin/actionconfig/hpiactionconfig",
    "modules/common/iconservice"
],

    // Map dependencies from above array.
    function(app, module, ActionConfig, IconService) {

        // Create a new module.
        var GenericResultsConfig = app.module();

        // Subconfig Model; these are the configurations for each type on the list view

        // Default Search Timing Thresholds
        GenericResultsConfig.timingDefaults = {
            totalTimeBad : module.config().totalTimeBad,
            totalTimeMedium : module.config().totalTimeMedium,
            networkTimeBad : module.config().networkTimeBad,
            networkTimeMedium : module.config().networkTimeMedium,
            queryBuildTimeBad : module.config().queryBuildTimeBad,
            queryBuildTimeMedium : module.config().queryBuildTimeMedium,
            queryExecuteTimeBad : module.config().queryExecuteTimeBad,
            queryExecuteTimeMedium : module.config().queryExecuteTimeMedium,
            queryParseTimeBad : module.config().queryParseTimeBad,
            queryParseTimeMedium : module.config().queryParseTimeMedium,
            tableViewRenderTimeBad : module.config().tableViewRenderTimeBad,
            tableViewRenderTimeMedium : module.config().tableViewRenderTimeMedium,
            formatResultsTimeBad : module.config().formatResultsTimeBad,
            formatResultsTimeMedium : module.config().formatResultsTimeMedium
        };

        GenericResultsConfig.TypeModel = Backbone.Model.extend({
            defaults: function() {
                return {
                    "objectType": "",
                    "label": "",
                    "title": "",
                    "resolver": "stage",
                    "showExternalLink": false,
                    "resolverExternalLink": "http://${objectId}",
                    "fields": [],
                    "visibleFields": [],
                    "hiddenFields": [],
                    "showMimeIcon": false,
                    "hideForceFitOption": true,
                    "isForceFit": "true",
                    "enableDualPaneForceFit":false,
                    "hideSynchronouResizeOptions": false,
                    "enableThumbnailGridView": false,
                    "resetTableViewEnabled": false,
                    "standardizedTableViewEnabled": false,
                    "standardizedTableView": false,
                    "sortRepeatingAttrs": false
                };
            }
        });

        GenericResultsConfig.TypeCollection = Backbone.Collection.extend({
            model: GenericResultsConfig.TypeModel
        });

        // Default Model.
        GenericResultsConfig.Model = Backbone.Model.extend({
            defaults: function() {
                return {
                    "type": "ResultsTable",
                    "label": window.localize("modules.hpiAdmin.searchConfig.genericResultsConfig.tableView"),
                    "enabled": false,
                    "icon": ""
                };
            },
            initialize: function(options) {
                if (options && options.types) {
                    this.set("types", new GenericResultsConfig.TypeCollection(options.types));
                } else {
                    this.set("types", new GenericResultsConfig.TypeCollection());
                }

                if (options && options.actions) {
                    this.set("actions", new ActionConfig.Collection(options.actions));
                } else {
                    this.set("actions", new ActionConfig.Collection());
                }
            }
        });

        GenericResultsConfig.TypeViewModel = kb.ViewModel.extend({
            constructor: function(model) {
                var self = this;

                self.showObjectText = ko.observable("Expand");
                self.showObjectConfig = ko.observable(false);
                self.toggleShowObject = function() {
                    if (self.showObjectConfig()) {
                        self.showObjectConfig(false);
                        self.showObjectText("Expand");
                    } else {
                        self.showObjectConfig(true);
                        self.showObjectText("Collapse");

                    }
                };

                self.model = model;

                kb.viewModel.prototype.constructor.apply(this, arguments);

                self.objectType = kb.observable(model, "objectType");
                self.objectTypeNoSpace = ko.observable(model.get("objectType").split(' ').join(''));

                self.label = kb.observable(model, "label");

                self.title = kb.observable(model, "title");
                self.changeTitle = function(t) {
                    self.title(t);
                };

                self.isForceFit = kb.observable(model, "isForceFit");

                self.enableThumbnailGridView = kb.observable(model, "enableThumbnailGridView");

                self.resetTableViewEnabled = kb.observable(model, "resetTableViewEnabled");

                self.standardizedTableViewEnabled = kb.observable(model, "standardizedTableViewEnabled");

                self.standardizedTableView = kb.observable(model, "standardizedTableView");

                self.sortRepeatingAttrs = kb.observable(model, "sortRepeatingAttrs");

                // Create an observable for whether or not we show our external link resolver's input.
                self.showExternalLink = ko.observable(model.get("showExternalLink"));
                // Listen so that we also update the config model.  If we didn't do this, on subsiquent views the config
                // would render wrong.
                self.showExternalLink.subscribe(function() {
                    model.set('showExternalLink', self.showExternalLink());
                });


                /**** Related Objects resolver and resolver trac setup ****/
                self.resolver = ko.observable(model.get("resolver"));
                self.resolver.subscribe(function() {
                    // Check if we need to show the external link textBox.
                    var showExternLink = self.resolver() === "external-link" ? true : false;
                    self.showExternalLink(showExternLink);

                    model.set('resolver', self.resolver());
                });

                self.resolverExternalLink = ko.observable(model.get("resolverExternalLink"));
                self.resolverExternalLink.subscribe(function() {
                    model.set('resolverExternalLink', self.resolverExternalLink());
                });


                self.selectedAttributes = kb.observable(model, "fields");

                //For pre-existing configs. Copy fields values over to visibleFields (Used only once)
                if (model.get("fields").length > 0 && model.get("visibleFields").length === 0) {
                    _.each(model.get("fields"), function(field) {
                        model.get("visibleFields").push(field);
                    });
                }

                self.holdVisible = ko.observableArray([]);
                if (model.get("visibleFields").length > 0) {
                    _.each(model.get("visibleFields"), function(field) {
                        self.holdVisible.push(field);
                    });
                } else {
                    _.each(model.get("fields"), function(field) {
                        self.holdVisible.push(field);
                    });
                }

                self.holdHidden = ko.observableArray([]);
                if (model.get("hiddenFields").length > 0) {
                    _.each(model.get("hiddenFields"), function(field) {
                        self.holdHidden.push(field);
                    });
                }

                self.visibleAndHiddenAttributes = ko.observableArray(model.get("fields"));

                var updateFields = function() {
                    var availableAttributes = [];
                    availableAttributes.push("");

                    model.get("fields").splice(0, model.get("fields").length);
                    _.each(self.holdVisible(), function(field) {
                        model.get("fields").push(field);
                        availableAttributes.push(field);
                    });
                    _.each(self.holdHidden(), function(field) {
                        model.get("fields").push(field);
                        availableAttributes.push(field);
                    });

                    self.visibleAndHiddenAttributes(availableAttributes);
                };
                updateFields();

                self.potentialAttributes = ko.observableArray();

                self.holdVisible.subscribe(function() {
                    model.get("visibleFields").splice(0, model.get("visibleFields").length);
                    _.each(self.holdVisible(), function(field) {
                        model.get("visibleFields").push(field);
                    });
                    updateFields();
                });

                self.holdHidden.subscribe(function() {
                    model.get("hiddenFields").splice(0, model.get("hiddenFields").length);
                    _.each(self.holdHidden(), function(field) {
                        model.get("hiddenFields").push(field);
                    });
                    updateFields();
                });

                self.allAttributes = ko.observableArray();

                //grab our potential type names from the top level config, and use the config
                //service to get their full set of attributes
                app.context.configService.getAdminTypeConfig(self.objectType(), function(typeConfig) {
                    var selectedAttrs = _.pluck(self.selectedAttributes(), 'ocName');
                    _.each(typeConfig.get("attrs").models, function(attr) {
                        if ($.inArray(attr.get("ocName"), selectedAttrs) === -1) {
                            self.potentialAttributes.push({ 'ocName': attr.get("ocName"), 'label': attr.get('label') });
                        }
                        self.allAttributes.push({ 'ocName': attr.get("ocName"), 'label': attr.get("label") });
                    });
                });

                return this;
            }

        });

        GenericResultsConfig.ViewModel = function(model, options) {
            var self = this;

            self.showTypeText = ko.observable("Show");
            self.showTypeConfig = ko.observable(false);
            self.toggleShowType = function() {
                if (self.showTypeConfig()) {
                    self.showTypeConfig(false);
                    self.showTypeText("Show");
                } else {
                    self.showTypeConfig(true);
                    self.showTypeText("Hide");

                }
            };

            self.showActionText = ko.observable("Show");
            self.showActionConfig = ko.observable(false);
            self.toggleShowAction = function() {
                if (self.showActionConfig()) {
                    self.showActionConfig(false);
                    self.showActionText("Show");
                } else {
                    self.showActionConfig(true);
                    self.showActionText("Hide");

                }
            };

            self.id = kb.observable(model, "id");
            self.configName = kb.observable(model, "name");

            /** BEGIN AWFUL KNOCKBACK CODE **/
            //this is pretty terrible, but the knockback constructor was not honoring
            //the object we passed in, but by pushing stuff onto the collection
            //everything built correctly. this code should never be copied ever, please
            //just rip out knockback
            var tempTypes = model.get("types");
            model.set("types", new Backbone.Collection());
            self.types = kb.collectionObservable(model.get("types"), {
                view_model: GenericResultsConfig.TypeViewModel
            });
            _.each(tempTypes.models, function(type) {
                model.get("types").push(type);
            });
            /** END AWFUL KNOCKBACK CODE**/

            self.enabledHold = ko.observable();
            if (model.get("enabled")) { 
                self.enabledHold("true"); 
            } else { 
                self.enabledHold("false"); 
            }

            self.enabledHold.subscribe(function() {
                if (self.enabledHold() === "true") {
                    model.set('enabled', true);
                } else {
                    model.set('enabled', false);
                }
            });

            self.configuringTimeRangesShow = ko.observable("Show");
            self.configuringTimeRanges = ko.observable(false);
            self.configureTimeRanges = function(){
                if(self.configuringTimeRanges()){
                    self.configuringTimeRanges(false);
                    self.configuringTimeRangesShow("Show");
                }else{
                    self.configuringTimeRanges(true);
                    self.configuringTimeRangesShow("Hide");
                }
            };


            self.searchStatisticsEnabled = ko.observable(model.get("searchStatisticsEnabled"));
            // Default the value based on the model
            if (model.get("searchStatisticsEnabled") === "true") {
                self.searchStatisticsEnabled("true");
            } else {
                self.searchStatisticsEnabled("false");
            }

            self.searchStatisticsEnabled.subscribe(function(enabled) {
                model.set("searchStatisticsEnabled", enabled);
                // have the inputs collapsed by default
                self.configuringTimeRanges(false);
            });

            // Search Timing Thresholds
            var timingOptions = [
                "totalTimeBad",
                "totalTimeMedium",
                "networkTimeBad",
                "networkTimeMedium",
                "queryBuildTimeBad",
                "queryBuildTimeMedium",
                "queryExecuteTimeBad",
                "queryExecuteTimeMedium",
                "queryParseTimeBad",
                "queryParseTimeMedium",
                "tableViewRenderTimeBad",
                "tableViewRenderTimeMedium",
                "formatResultsTimeBad",
                "formatResultsTimeMedium"
            ];
            
            _.each(timingOptions, function(timingOption) {
                
                self[timingOption] = kb.observable(model, timingOption);

                if(!model.get(timingOption)) {
                    model.set(timingOption, GenericResultsConfig.timingDefaults[timingOption]);
                }
            });

            // function to run when resetting to defaut timings
            self.resetToDefaultTimes = function () {
                _.each(timingOptions, function(timingOption) {
                    model.set(timingOption, GenericResultsConfig.timingDefaults[timingOption]);
                });
            };

            //search icons next to name
            self.showMimeIcon = kb.observable(model, "showMimeIcon");

            // hide available options
            self.hideForceFitOption = kb.observable(model, "hideForceFitOption");
            self.enableDualPaneForceFit = kb.observable(model,"enableDualPaneForceFit");
            self.hideSynchronouResizeOptions = kb.observable(model, "hideSynchronouResizeOptions");

            // Enable or disable functionality related to export of search results via email (async action)
            self.enableExportViaEmail = kb.observable(model, "enableExportViaEmail");
            // Default the value based on the model
            if (model.get("enableExportViaEmail") === "true") {
                self.enableExportViaEmail("true");
            } else {
                self.enableExportViaEmail("false");
            }

            self.enableExportViaEmail.subscribe(function() {
                if (self.enableExportViaEmail() === "true") {
                    model.set('enableExportViaEmail', "true");
                } else {
                    model.set('enableExportViaEmail', "false");
                }
            });

            self.emailExportResultsLimit = kb.observable(model, "emailExportResultsLimit");
            if (model.get("emailExportResultsLimit")) {
                self.emailExportResultsLimit(model.get("emailExportResultsLimit"));
            } else {
                self.emailExportResultsLimit("1000");
            }

            self.emailExportResultsLimit.subscribe(function(newLimit) {
                model.set("emailExportResultsLimit", newLimit);
            });

            // Enable or disable the functionality that allows the user to change the email results
            // are being exported to
            self.disableEmailFieldForExport = kb.observable(model, "disableEmailFieldForExport");
            // Default the value based on the model
            if (model.get("disableEmailFieldForExport") === "false") {
                self.disableEmailFieldForExport("false");
            } else {
                self.disableEmailFieldForExport("true");
            }

            self.disableEmailFieldForExport.subscribe(function() {
                if (self.disableEmailFieldForExport() === "false") {
                    model.set('disableEmailFieldForExport', "false");
                } else {
                    model.set('disableEmailFieldForExport', "true");
                }
            });

            // the two drop downs that let the user select the attribute to use for doc notes notifier
            app.context.configService.getAdminOTC(function(adminOTC) {
                self.typeOptions = ko.observable(adminOTC.get('configs').models);
                self.selectedDocType = ko.observable();
                self.typeAttributes = ko.observable();
                self.docIndicatorAttribute = ko.observable();

                // load the saved values if they exist
                if (model.get('docIndicatorAttribute') && model.get('docIndicatorAttribute').type) {
                    var savedType = _.find(adminOTC.get('configs').models, function(m) {
                        return m.get('label') === model.get('docIndicatorAttribute').type;
                    });

                    if (savedType) {
                        self.selectedDocType(savedType);
                        self.typeAttributes(savedType.get('attrs').models);
                        var savedAttr = _.find(savedType.get('attrs').models, function(a) {
                            return a.get('ocName') === model.get('docIndicatorAttribute').attr;
                        });
                        self.docIndicatorAttribute(savedAttr);
                    }
                }

                self.selectedDocType.subscribe(function(selectedDocType) {
                    if (selectedDocType) {
                        self.typeAttributes(selectedDocType.get('attrs').models);
                    } else {
                        // we fall here when the dropdown is set to the empty value, which would be when the user wants to turn off notifications
                        self.typeAttributes('');
                        model.set('docIndicatorAttribute', { type: '', attr: '' });
                    }
                });

                self.docIndicatorAttribute.subscribe(function(selectedAttr) {
                    if (selectedAttr) {
                        model.set('docIndicatorAttribute', { type: self.selectedDocType().get('label'), attr: selectedAttr.get('ocName') });
                    }
                });

            });

            self.icon = kb.observable(model, "icon");

            // ---- T Y P E S ---- //

            self.selectedType = ko.observable();
            self.selectedType.subscribe(function(type) {
                if (type) {
                    self.potentialTypes.remove(type);
                    var newType = new GenericResultsConfig.TypeModel({ objectType: type.get("ocName"), label: type.get("label") });
                    model.get("types").push(newType);
                    self.potentialTypes.remove(type);
                    self.selectedType(undefined);
                    app.trigger("newTypeAdded", newType);
                }
            });

            //grab our potential type names from the top level config, and use the config
            //service to get their full set of attributes
            self.potentialTypes = ko.observableArray();
            self.getTypes = function() {
                self.potentialTypes.removeAll();
                _.each(options.availableObjectTypes, function(item) {
                    app.context.configService.getAdminTypeConfig(item, function(typeConfig) {
                        var isNew = true;

                        _.each(model.get("types").models, function(oldType) {
                            if (oldType.get("objectType") === typeConfig.get("ocName")) { isNew = false; }
                        });

                        if (isNew) { self.potentialTypes.push(typeConfig); }
                    });
                });
            };
            self.getTypes();

            self.showAddType = ko.observable();
            self.showAddTypeForm = function() {
                self.showAddType(true);
            };
            self.cancelAddType = function() {
                self.showAddType(false);
            };

            self.addType = function() {
                var newType = new GenericResultsConfig.TypeModel({ objectType: self.selectedType().get("ocName"), label: self.selectedType().get("label") });
                model.get("types").push(newType);
                self.potentialTypes.remove(self.selectedTyped());
            };

            self.removeType = function(type) {
                _.each(model.get("types").models, function(t) {
                    if (t.get("objectType") === type.objectType()) {
                        model.get("types").remove(t);
                    }
                });
                self.getTypes();
            };

            // ---- END OF TYPES ---- //


            return self;

        };

        GenericResultsConfig.Views.Config = Backbone.Layout.extend({
            //template : "hpiadmin/searchconfig/resultstableconfig",
        });

        GenericResultsConfig.Views.IndicatorIcons = Backbone.Layout.extend({
            template: "hpiadmin/searchconfig/indicatoricons",
            events: {
                "click .attr-indicator-icon-to-check": "checkAttrSelected",
                "click .attr-indicator-icon-to-display": "displayAttrSelected",
                "click .add-full-icon-indicator": "addFullRow",
                "click .add-lock-key-indicator" : "addLockKeyDefault",
                "click #delete-icon-config": "deleteRow",
                "blur #custom-icon-to-show": "updateIcon",
                "click #edit-icon-indicator": "editConfig",
                "click .type-of-compare": "changeTypeOfComparison"
            },
            initialize: function(options) {
                this.options = options;
                var self = this;
                //Creating a blank object to hold these
                self.allAttributes = [];
                app.context.configService.getAdminTypeConfig(self.options.type.get("objectType"), function(typeConfig){
                    _.each(typeConfig.get("attrs").models, function(attr) {
                        self.allAttributes.push({'ocName': attr.get("ocName"), 'label': attr.get("label")});
                    });
                });

                this.configuredIcons = [];
                if (options.type.get("configuredIcons")) {
                    this.configuredIcons = options.type.get("configuredIcons");
                }
            },
            addLockKeyDefault: function(e){
                e.preventDefault();
                //This is adding the lock by default doesn't matter what repository
                this.configuredIcons.push({
                    'checkAttribute': "lockOwner",
                    'prettyCheckAttribute': "lockOwner",
                    'valueToCheck': "",
                    'customIcon': "lock",
                    'attributeWithIcon': "objectName",
                    'prettyAttributeWithIcon': "Name",
                    'typeOfComparison': "exist",
                    'hoverText': "Document is currently checked out to $lockOwner"
                });
                //This is where it gets tricky, may be a better way some day
                this.configuredIcons.push({
                    'checkAttribute': "lockOwner",
                    'prettyCheckAttribute': "lockOwner",
                    'valueToCheck': "$user.loginName",
                    'customIcon': "keys",
                    'attributeWithIcon': "objectName",
                    'prettyAttributeWithIcon': "Name",
                    'typeOfComparison': "equal",
                    'hoverText': "Document is currently checked out to you"
                });

                //This is where it gets tricky, may be a better way some day
                this.configuredIcons.push({
                    'checkAttribute': "lockOwner",
                    'prettyCheckAttribute': "lockOwner",
                    'valueToCheck': "$user.displayName",
                    'customIcon': "keys",
                    'attributeWithIcon': "objectName",
                    'prettyAttributeWithIcon': "Name",
                    'typeOfComparison': "equal",
                    'hoverText': "Document is currently checked out to you"
                });
                this.options.type.set('configuredIcons', this.configuredIcons);
                this.render();
            },
            addFullRow: function(e) {
                e.preventDefault();
                this.configuredIcons.push({
                    'checkAttribute': this.checkAttribute,
                    'prettyCheckAttribute': this.prettyCheckAttribute,
                    'valueToCheck': this.$('#attr-value').val(),
                    'customIcon': this.$('#custom-icon-to-show').val(),
                    'attributeWithIcon': this.attributeWithIcon,
                    'prettyAttributeWithIcon': this.prettyAttributeWithIcon,
                    'typeOfComparison': this.typeOfComparison,
                    'hoverText': this.$("#hover-text").val()
                });
                this.options.type.set('configuredIcons', this.configuredIcons);
                this.render();
            },
            editConfig: function(e) {
                var iconToRemove = $(e.currentTarget.previousElementSibling).attr('icon');
                this.editTriggered = true;
                this.infoToEdit = _.findWhere(this.configuredIcons, {
                    'customIcon': iconToRemove
                });

                //Removing it from the selected attributes / modal body
                this.configuredIcons = _.without(this.configuredIcons, _.findWhere(this.configuredIcons, {
                    'customIcon': iconToRemove
                }));

                this.options.type.set('configuredIcons', this.configuredIcons);
                this.render();
            },
            deleteRow: function(e) {
                var iconToRemove = $(e.currentTarget.parentElement).attr('icon');

                //Removing it from the selected attributes / modal body
                this.configuredIcons = _.without(this.configuredIcons, _.findWhere(this.configuredIcons, {
                    'customIcon': iconToRemove
                }));
                this.options.type.set('configuredIcons', this.configuredIcons);
                this.render();
            },
            changeTypeOfComparison: function(e) {
                this.$("#selected-type-of-compare-text").text(e.currentTarget.textContent.trim());
                this.typeOfComparison = e.currentTarget.getAttribute('value');
                if (this.typeOfComparison === 'exist') {
                    this.$("#attr-value").attr("disabled", true);
                } else {
                    this.$("#attr-value").attr("disabled", false);
                }
            },
            checkAttrSelected: function(e) {
                this.$("#selected-attr-to-check-text").text(e.currentTarget.textContent.trim());
                this.checkAttribute = e.currentTarget.getAttribute('value');
                this.prettyCheckAttribute = e.currentTarget.textContent.trim();
            },
            displayAttrSelected: function(e) {
                this.$("#selected-attr-to-display-text").text(e.currentTarget.textContent.trim());
                this.attributeWithIcon = e.currentTarget.getAttribute('value');
                this.prettyAttributeWithIcon = e.currentTarget.textContent.trim();
            },
            updateIcon: function() {
                var iconClass = IconService.getIconClass(this.$('#custom-icon-to-show').val());
                this.$("#preview-icon").attr('class', iconClass);
            },
            displayEditedRow: function() {
                var infoToEdit = this.infoToEdit;

                this.$("#selected-attr-to-check-text").text(infoToEdit.prettyCheckAttribute);
                this.checkAttribute = infoToEdit.checkAttribute;
                this.prettyCheckAttribute = infoToEdit.prettyCheckAttribute;

                this.$("#selected-attr-to-display-text").text(infoToEdit.prettyAttributeWithIcon);
                this.attributeWithIcon = infoToEdit.attributeWithIcon;
                this.prettyAttributeWithIcon = infoToEdit.prettyAttributeWithIcon;

                this.$("#selected-type-of-compare-text").text(window.localize("searchConfig.indicatorIcons." + infoToEdit.typeOfComparison));
                this.typeOfComparison = infoToEdit.typeOfComparison;

                this.$('#custom-icon-to-show').val(infoToEdit.customIcon);

                this.$('#attr-value').val(infoToEdit.valueToCheck);

                this.$("#hover-text").val(infoToEdit.hoverText);

                this.updateIcon();
                this.editTriggered = false;
            },
            afterRender: function() {
                //This is for when an edit is triggered
                //We are putting the values in their respective inputs and update the current values on "this" so if it
                //gets added back, the values are correct.
                if (this.editTriggered) {
                    this.displayEditedRow();
                }
                //Informational popover that instructs the user on how to use glyphicons
                $("#custom-icon-to-show").popover({
                    placement: 'top',
                    trigger: 'focus',
                    title: 'Glyphicons',
                    html: true,
                    content: "Some common glyphicons include 'edit', 'search', and 'list-alt'. For a full list, click <a href='http://glyphicons.com' target='_blank'>on this link</a>. <br/><br/> Type a new glyphicon name and hit 'Enter' to update its preview.",
                    delay: { show: 500 }
                });

                self.$('[data-toggle="tooltip"]').tooltip();

            },
            serialize: function() {
                return {
                    attributes: this.options.type.get("fields"),
                    allAttributes: this.allAttributes,
                    configuredIcons: this.configuredIcons
                };
            }
        });



        // Default View.
        GenericResultsConfig.Views.Layout = Backbone.Layout.extend({
            //template: "hpiadmin/searchconfig/resultstableconfig",
            events: {
                "click .add-all-attr-btn": "addAllAttrs"
            },

            initialize: function() {
                var self = this;
                this.viewModel = new GenericResultsConfig.ViewModel(this.model, this.options);

                this.viewModel.name = ko.observable(this.options.tracName);

                this.model.get("types").each(function(type) {
                    self.insertView("configs-outlet", new GenericResultsConfig.Views.Config({ model: type }));
                });
                //put the action template onto the page and augment viewmodel
                this.setView("#action-config-template-outlet", new ActionConfig.View({ viewmodel: this.viewModel, model: this.model, showGroupActions: false }));

                this.ui = {};
            },
            addAllAttrs: function(event) {
                // In order to tell which type sent this event (since they're not Backbone views...) we store a cheater attribute on the DOM.
                var targetObjectType = $(event.target).attr("typeHolder");

                // Get our viewModels for each type.
                var viewModels = this.viewModel.types();

                // Find the VM that corresponds to the one clicked.  We need the VM, since the model itself only contains the attrs that ARE
                // configured, not the potential attrs.
                var addAllViewModel = _.find(viewModels, function(typeVM) {
                    return typeVM.model.get("objectType") === targetObjectType;
                });

                // Move all unconfigured potential attrs into hidden attrs.
                var allRemainingAttrs = _.union(addAllViewModel.holdHidden(), addAllViewModel.potentialAttributes());
                addAllViewModel.holdHidden(allRemainingAttrs);
                addAllViewModel.potentialAttributes([]);
            },
            afterRender: function() {
                var self = this;

                kb.applyBindings(this.viewModel, this.$el[0]);
                // Add the info popover for external link resolver.
                this.ui.tooltip = this.$(".extern-link-tooltip");
                //add popover to icon for glyphicons
                this.ui.tooltip.popover({
                    placement: 'right',
                    trigger: 'hover',
                    title: window.localize("modules.hpiAdmin.searchConfig.genericResultsConfig.externalLink"),
                    html: true,
                    content: "<p>" + window.localize("modules.hpiAdmin.searchConfig.genericResultsConfig.thisIs") + "</p>",
                    delay: { show: 500 }
                });

                this.listenTo(app, "newTypeAdded", function(newType) {
                    self.setView("#indicator-icons-outlet-" + newType.get("objectType").split(' ').join(''), new GenericResultsConfig.Views.IndicatorIcons({ type: newType })).render();
                });

                this.model.get("types").each(function(type) {
                    self.setView("#indicator-icons-outlet-" + type.get("objectType").split(' ').join(''), new GenericResultsConfig.Views.IndicatorIcons({ type: type })).render();
                });
            }
        });

        // Return the module for AMD compliance.
        return GenericResultsConfig;
    });
