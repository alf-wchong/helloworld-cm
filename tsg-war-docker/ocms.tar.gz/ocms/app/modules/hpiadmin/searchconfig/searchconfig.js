// Searchconfig module
define([
        // Application.
        "app",
        "knockout",
        "knockoutsortable",
        "knockback",
        "modules/hpiadmin/hpiadmin",

        "modules/hpiadmin/otc/objecttypeconfig",

        "modules/common/alert/alert",

        "modules/hpiadmin/hpiadmin-switcher",
        "modules/common/tossacross",
        "modules/hpiadmin/searchconfig/resultsgridconfig",
        "modules/hpiadmin/searchconfig/resultslistconfig",
        "modules/hpiadmin/searchconfig/resultstableconfig",
        "modules/hpiadmin/searchconfig/facetconfig",
        "modules/hpiadmin/searchconfig/attributesearchconfig",
        "modules/hpiadmin/searchconfig/groupactionsconfig",
        "modules/hpiadmin/searchconfig/advancedsearchconfig",
        "modules/hpiadmin/searchconfig/searchrestrictions/searchrestrictionconfig"
    ],

    // Map dependencies from above array.
    function(app, ko, kos, kb, Hpiadmin, Otc, Alert, Switcher, TossAcross, ResultsGridConfig, ResultsListConfig, ResultsTableConfig, FacetConfig, AttributeSearchConfig, GroupActionsConfig, AdvancedSearchConfig, SearchRestrictionConfig) {
        "use strict";
        // Create a new module.
        var Searchconfig = app.module();
        var searchConfigVent = _.extend({}, Backbone.Events);
        // Results Model
        Searchconfig.ResultsConfig = Hpiadmin.Config.extend({
            initialize: function(options) {
                if (options && options.resultsGridConfig) {
                    this.set("resultsGridConfig", new ResultsGridConfig.Model(options.resultsGridConfig));
                } else {
                    this.set("resultsGridConfig", new ResultsGridConfig.Model());
                }

                if (options && options.resultsListConfig) {
                    this.set("resultsListConfig", new ResultsListConfig.Model(options.resultsListConfig));
                } else {
                    this.set("resultsListConfig", new ResultsListConfig.Model());
                }

                if (options && options.resultsTableConfig) {
                    this.set("resultsTableConfig", new ResultsTableConfig.Model(options.resultsTableConfig));
                } else {
                    this.set("resultsTableConfig", new ResultsTableConfig.Model());
                }

                if (options && options.groupActionsConfig) {
                    this.set("groupActionsConfig", new GroupActionsConfig.Model(options.groupActionsConfig));
                } else {
                    this.set("groupActionsConfig", new GroupActionsConfig.Model());
                }
            }
        });


        Searchconfig.SimpleGroup = Backbone.Model.extend({
            name: ""
        });

        Searchconfig.SimpleGroupCollection = Backbone.Collection.extend({
            model: Searchconfig.SimpleGroup
        });

        // Sidebar Model
        Searchconfig.SidebarConfig = Hpiadmin.Config.extend({
            defaults: {
                quickSearchEnabled: true,
                savedSearchEnabled: false,
                folderViewTypeSelection: false,
                openAnnotateSearchEnabled: false,
                enabledPublicSavedSearch: false,
                keepFilter: false,
                disableSearchOnWildcardChar: false,
                wildcardCharacter: ''
            },
            initialize: function(options) {
                if (options && options.facetConfig) {
                    this.set("facetConfig", new FacetConfig.Model(options.facetConfig));
                } else {
                    this.set("facetConfig", new FacetConfig.Model());
                }

                if (options && options.attributeSearchConfig) {
                    this.set("attributeSearchConfig", new AttributeSearchConfig.Model(options.attributeSearchConfig));
                } else {
                    this.set("attributeSearchConfig", new AttributeSearchConfig.Model());
                }

                if (options && options.advancedSearchConfig) {
                    this.set("advancedSearchConfig", new AdvancedSearchConfig.Model(options.advancedSearchConfig));
                } else {
                    this.set("advancedSearchConfig", new AdvancedSearchConfig.Model());
                }

                if (options && options.searchRestrictionConfig) {
                    this.set("searchRestrictionConfig", new SearchRestrictionConfig.Model(options.searchRestrictionConfig));
                } else {
                    this.set("searchRestrictionConfig", new SearchRestrictionConfig.Model());
                }
            },
            parse: function(response) {
                return response;
            }
        });

        // Default Model.
        Searchconfig.Model = Hpiadmin.Config.extend({
            type: "SearchConfig",
            defaults: function() {
                return {
                    type: "SearchConfig",
                    limitSearchResults: "1000",
                    OCQueryImpl: "nativeAPI",
                    form: "",
                    savedSearchAdminGroups: new Searchconfig.SimpleGroupCollection()
                    
                };
            },
            //in case we need to create a Searchconfig from scratch
            //like in unit tests
            initialize: function(options) {
                if (options && options.resultsConfig) {
                    this.set("resultsConfig", new Searchconfig.ResultsConfig(options.resultsConfig));
                } else {
                    this.set("resultsConfig", new Searchconfig.ResultsConfig());
                }

                if (options && options.sidebarConfig) {
                    this.set("sidebarConfig", new Searchconfig.SidebarConfig(options.sidebarConfig));
                } else {
                    this.set("sidebarConfig", new Searchconfig.SidebarConfig());
                }

                
                if (options && options.savedSearchAdminGroups){
                    this.set("savedSearchAdminGroups", new Searchconfig.SimpleGroupCollection(options.savedSearchAdminGroups));
                } else{
                    this.set("savedSearchAdminGroups", new Searchconfig.SimpleGroupCollection());
                }
            },
            parseResponse: function(response) {
                if (this.id) {
                    delete response.resultsConfig;
                    delete response.sidebarConfig;
                    delete response.savedSearchAdminGroups;
                    delete response.label;
                    delete response.name;
                    delete response.type;
                    delete response.availableObjectTypes;
                    delete response.form;
                } else if (response) {
                    if (response.resultsConfig) {
                        this.set("resultsConfig", new Searchconfig.ResultsConfig(response.resultsConfig));
                        delete response.resultsConfig;
                    }
                    if (response.sidebarConfig) {
                        this.set("sidebarConfig", new Searchconfig.SidebarConfig(response.sidebarConfig));
                        delete response.sidebarConfig;
                    }
                    if (response.savedSearchAdminGroups) {
                        this.set("savedSearchAdminGroups", new Searchconfig.SimpleGroupCollection(response.savedSearchAdminGroups));
                        delete response.savedSearchAdminGroups;
                    }
                }
                return response;
            }
        });

        Searchconfig.ViewModel = kb.ViewModel.extend({
            constructor: function(model) {
                var self = this;

                kb.ViewModel.prototype.constructor.call(this, model, {
                    factories: {
                        "modules.resultsGridConfig": ResultsGridConfig.ViewModel,
                        "modules.resultsListConfig": ResultsListConfig.ViewModel,
                        "modules.resultsTableConfig": ResultsTableConfig.ViewModel,
                        "modules.facetConfig": FacetConfig.ViewModel,
                        "modules.AttributeSearchConfig": AttributeSearchConfig.ViewModel,
                        "modules.groupActionsConfig": GroupActionsConfig.ViewModel,
                        "modules.AdvancedSearchConfig": AdvancedSearchConfig.ViewModel
                    },
                    requires: ["id", "name", "availableObjectTypes"]
                });
                //had to seperate this out for now.
                //Some sort of issue with knockback
                self.newConfigName = ko.observable();

                // get the types when we have selected a config
                self.potentialTypes = ko.observableArray();

                //get the trac OTC 
                app.context.configService.getAdminOTC(function(model) {
                    self.potentialTypes.removeAll();
                    model.get("configs").each(function(type) {
                        self.potentialTypes.push({
                            "label": type.attributes.label,
                            "ocName": type.attributes.ocName
                        });
                    });
                });

                
                this.allowedGroupsForPublicSSEditing = new Backbone.Collection();
                this.deniedGroupsForPublicSSEditing =  new Backbone.Collection();

                
                self.selectedTypes = ko.observableArray();
                self.availableObjectTypes = kb.observable(model, "availableObjectTypes");
                self.label = kb.observable(model, "label");
                self.potentialForms = ko.observableArray();
                //path stuff
                self.typePathServerData = model.get("customTypePaths") ? model.get("customTypePaths") : {};
                self.typePathViewModels = ko.observableArray([]);
                self.objectTypesWithoutPathConfig = ko.observableArray([]);
                self.selectedObjectTypeWithoutPathConfig = ko.observable();
                //end path stuff
                //form stuff
                self.form = kb.observable(model, "form");
                var existingFormName = self.form();
                app.context.configService.getFormConfigNames(function(formConfigNames) {
                    self.potentialForms(formConfigNames);
                    //this is needed to make sure we keep our
                    //existing form value
                    self.form(existingFormName);
                });
                self.formTypes = kb.observable(model, "formTypes");

                self.form.subscribe(function(formName) {
                    if (formName) {
                        app.context.configService.getFormTypesAndAttrs(formName, function(typesAndAttrs) {
                            self.formTypes(_.pluck(typesAndAttrs, "type"));
                            if (self.subConfig()) {
                                //reload our subconfig with new form type
                                self.subConfig.valueHasMutated();
                            }
                        });
                        //custom path logic
                        app.context.configService.getFormConfig(formName, function(formConfig) {
                            self.objectTypesWithoutPathConfig.removeAll();
                            formConfig.get("configuredTypes").each(function(type) {
                                self.objectTypesWithoutPathConfig.push({ label: type.get('label'), value: type.get('ocName') });
                            });
                            self.objectTypesWithoutPathConfig(_.sortBy(self.objectTypesWithoutPathConfig(), 'label'));
                            _.each(_.keys(self.typePathServerData[formName]), function(typeKey) {
                                if (typeKey.indexOf("_id") === -1) {
                                    // skip the _id key, and remove all those that are already present
                                    self.objectTypesWithoutPathConfig.remove(_.findWhere(self.objectTypesWithoutPathConfig(), { "value": typeKey }));
                                }
                            });
                        });
                        self.typePathViewModels.removeAll();
                        _.each(_.keys(self.typePathServerData[formName]), function(typeKey) {
                            if (typeKey.indexOf("_id") === -1) {
                                // skip the limit types key and the _id key
                                self.typePathViewModels.push(new Searchconfig.TypePathViewModel({ objectType: typeKey, path: self.typePathServerData[formName][typeKey], typePathServerData: self.typePathServerData, formName: formName, model: model }));
                                self.objectTypesWithoutPathConfig.remove(_.findWhere(self.objectTypesWithoutPathConfig(), { "value": typeKey }));
                            }
                        });

                    }
                });

                // this allows a user to add a path configuration for a selected object type
                self.selectedObjectTypeWithoutPathConfig.subscribe(function(objectType) {
                    if (objectType) { // will be undefined if the caption is chosen
                        self.typePathViewModels.push(new Searchconfig.TypePathViewModel({ objectType: objectType, path: "", typePathServerData: self.typePathServerData, formName: self.form(), model: model }));
                        self.objectTypesWithoutPathConfig.remove(_.findWhere(self.objectTypesWithoutPathConfig(), { "value": objectType }));
                    }
                });

                // this allows a user to delete a path configuration for a selected object type
                self.deleteTypePath = function(typePath) {
                    self.typePathViewModels.remove(typePath);
                    if (self.typePathServerData[self.form()] && self.typePathServerData[self.form()][typePath.objectType]) {
                        delete self.typePathServerData[self.form()][typePath.objectType];
                    }
                    self.objectTypesWithoutPathConfig.push({
                        "label": typePath.typeLabel,
                        "value": typePath.objectType
                    });
                    self.objectTypesWithoutPathConfig(_.sortBy(self.objectTypesWithoutPathConfig(), 'label'));
                };

                self.form(existingFormName);
                //end form stuff

                this.onCreateConfig = function() {
                    if (self.newConfigName() && !self.id()) {
                        model.set("name", self.newConfigName());
                    }
                    model.save(model.toJSON(), {
                        success: function() {
                            app.trigger("modelSaveOrDestroy");
                            Backbone.history.navigate("admin/SearchConfig/" + model.get("name"), { replace: true, trigger: true });
                            app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
                        },
                        error: function() {
                            app.trigger("alert:error", {
                                header: window.localize("generic.errorSavingConfig"),
                                message: window.localize("generic.configSaveFailed")
                            });
                        }
                    });
                };


                self.buildUpGroups = function() {
                    
                    var requestGroupObject = {
                        "authorityType": "group",
                        "criterion": {
                            "attrToSearch": "displayName",
                            "matchType": "startsWith",
                            "searchTerm": "*"
                        }
                    };

                    var opts = {
                        url: app.serviceUrlRoot + "/authorities/search",
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify(requestGroupObject),
                        success: function(groups) {
                            var savedSearchAdminGroups = [];
                            _.each(groups, function(group) {
                                var exists = false;
                                _.each(model.get("savedSearchAdminGroups").models, function(ag) {
                                    if (ag.get("name") === group.authorityId) {
                                        savedSearchAdminGroups.push(group.authorityId);
                                        exists = true;
                                    }
                                });
                                if (!exists) {
                                    //difference
                                    self.deniedGroupsForPublicSSEditing.add({
                                        'name': group.authorityId
                                    });
                                }
                            });

                            var adminModels = model.get("savedSearchAdminGroups");
                            adminModels.each(function(aModel) {
                                self.allowedGroupsForPublicSSEditing.add({
                                    'name': aModel.get("name")
                                });
                            });

                            self.typesTossAcross = new TossAcross.Layout({
                                srcCollection: {
                                    title: window.localize("applicationConfig.appConfigMainLayout.deniedGroups"),
                                    filter: true,
                                    labelAttr: 'name',
                                    collection: self.deniedGroupsForPublicSSEditing
                                },
                                targetCollections: [{
                                    title: window.localize("applicationConfig.appConfigMainLayout.allowedGroups"),
                                    labelAttr: 'name',
                                    collection: self.allowedGroupsForPublicSSEditing
                                }]
                            });

                            searchConfigVent.trigger("tossAcrossReady", ".toss-across-groups", self.typesTossAcross);
                        },
                        error: function() {
                            app.log.error("User groups could not be loaded");
                        }
                    };
                    $.ajax(opts);
                };

                app.listenTo(self.allowedGroupsForPublicSSEditing, 'add remove reset', function() {
                    var allowedGroups = self.allowedGroupsForPublicSSEditing;
                    var savedSearchAdminGroups = [];
                    allowedGroups.each(function(g) {
                        var group = new Searchconfig.SimpleGroup({ name: g.get('name') });
                        //there is an issue between knockback and bb-relational where
                        group.attributes.id = group.get("cid");
                        savedSearchAdminGroups.push(group);
                    });
                    //need to be using collections, since this is what is expected for
                    //the value adminGroups on the model
                    var adminGroupCollection = new Searchconfig.SimpleGroupCollection(savedSearchAdminGroups);
                    model.set("savedSearchAdminGroups", adminGroupCollection);
                }, this);

                this.quickSearchEnabled = ko.observable(model.get("sidebarConfig").get("quickSearchEnabled"));
                this.quickSearchEnabled.subscribe(function(bool) {
                    model.get("sidebarConfig").set("quickSearchEnabled", bool);
                });

                this.openAnnotateSearchEnabled = ko.observable(model.get("sidebarConfig").get("openAnnotateSearchEnabled"));
                this.openAnnotateSearchEnabled.subscribe(function(bool) {
                    model.get("sidebarConfig").set("openAnnotateSearchEnabled", bool);
                });

                this.enabledPublicSavedSearch = ko.observable(model.get("sidebarConfig").get("enabledPublicSavedSearch"));
                this.enabledPublicSavedSearch.subscribe(function(bool) {
                    model.get("sidebarConfig").set("enabledPublicSavedSearch", bool);
                });

                this.savedSearchEnabled = ko.observable(model.get("sidebarConfig").get("savedSearchEnabled"));
                this.savedSearchEnabled.subscribe(function(bool) {
                    model.get("sidebarConfig").set("savedSearchEnabled", bool);
                });

                this.folderViewTypeSelection = ko.observable(model.get("sidebarConfig").get("folderViewTypeSelection"));
                this.folderViewTypeSelection.subscribe(function(bool) {
                    model.get("sidebarConfig").set("folderViewTypeSelection", bool);
                });

                this.disableSearchOnWildcardChar = kb.observable(model.get('sidebarConfig'), 'disableSearchOnWildcardChar');
                this.wildcardCharacter = kb.observable(model.get('sidebarConfig'), 'wildcardCharacter');

                this.enableTypeToPathSecurity = ko.observable(model.get("sidebarConfig").get("enableTypeToPathSecurity"));
                this.enableTypeToPathSecurity.subscribe(function(bool) {
                    model.get("sidebarConfig").set("enableTypeToPathSecurity", bool);
                });

                this.keepFilter = ko.observable(model.get("sidebarConfig").get("keepFilter"));
                this.keepFilter.subscribe(function(bool) {
                    model.get("sidebarConfig").set("keepFilter", bool);
                });


                this.subConfig = ko.observable();
                return this;
            }
        });

        // this represents a view model for a path configuration for an object type
        Searchconfig.TypePathViewModel = function(options) {
            var self = this;

            self.model = options.model;
            // the value of the objectType
            self.objectType = options.objectType;

            // the server data with trac configurations
            self.typePathServerData = options.typePathServerData;

            self.typeLabel = ko.observable("");
            app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
                self.typeLabel(typeLabel);
            });

            // the path that is displayed on the admin screen
            self.computedPath = ko.observable("");
            if (options.path) { // the path will be set if we get data back from the server
                self.computedPath(options.path);
            }

            // every time the observable's value changes, update that object type's path in the server data map
            self.computedPath.subscribe(function(newValue) {
                if (!self.typePathServerData[options.formName]) {
                    self.typePathServerData[options.formName] = {};
                }
                self.typePathServerData[options.formName][self.objectType] = newValue;
                self.model.set("customTypePaths", self.typePathServerData);
            });
        };

        // Default Collection.
        Searchconfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
            model: Searchconfig.Model,
            initialize: function() {
                this.type = "SearchConfig";
            }
        });

        // Default View.
        Searchconfig.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/searchconfig/searchconfig-mainlayout",
            beforeRender: function() {
                var switcher = new Switcher.Views.Layout({ config: this.model, configClass: this.options.configClass });
                this.setView("#config-switcher-outlet", switcher);
            },

            afterRender: function() {
                var that = this;
                if (this.viewModel) {
                    app.trigger("alert:info", {
                        header: window.localize("generic.alert"),
                        message: window.localize("modules.hpiAdmin.memoryLeak")
                    });
                }
                this.viewModel = new Searchconfig.ViewModel(this.model, this);
                this.viewModel.buildUpGroups();
                this.listenTo(searchConfigVent, "tossAcrossReady", function(el, tossAcrossView) {
                    this.setView(el, tossAcrossView).render();
                }, this);
                this.viewModel.subConfig.subscribe(function(value) {
                    switch (value) {
                        case "GridView":
                            that.setView("#subconfig-outlet", new ResultsGridConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("resultsGridConfig"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "ListView":
                            that.setView("#subconfig-outlet", new ResultsListConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("resultsListConfig"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "Search Results":
                            that.setView("#subconfig-outlet", new ResultsTableConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("resultsTableConfig"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "Facets":
                            that.setView("#subconfig-outlet", new FacetConfig.Views.Layout({
                                facetModel: that.model.get("sidebarConfig").get("facetConfig"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "AttributeSearch":
                            that.setView("#subconfig-outlet", new AttributeSearchConfig.Views.Layout({
                                model: that.model.get("sidebarConfig").get("attributeSearchConfig"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "GroupActions":
                            that.setView("#subconfig-outlet", new GroupActionsConfig.Views.Layout({
                                model: that.model.get("resultsConfig").get("groupActionsConfig"),
                                tracName: that.model.get("name"),
                                availableObjectTypes: that.viewModel.formTypes()
                            })).render();
                            break;

                        case "AdvancedSearch":
                            that.setView("#subconfig-outlet", new AdvancedSearchConfig.Views.Layout({
                                model: that.model.get("sidebarConfig").get("advancedSearchConfig")
                            })).render();
                            break;
                        case "Restrictions":
                            that.setView("#subconfig-outlet", new SearchRestrictionConfig.LayoutView({
                                model: that.model.get("sidebarConfig").get("searchRestrictionConfig")
                            })).render();
                            break;
                    }
                });

                kb.applyBindings(this.viewModel, this.$el[0]);
            },
            serialize: function() {
                return {
                    enableDirectSQL: app.enableDirectSQL
                };
            }


        });

        // Return the module for AMD compliance.
        return Searchconfig;

    });