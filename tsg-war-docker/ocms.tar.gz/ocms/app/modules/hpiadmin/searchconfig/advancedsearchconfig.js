define([
	"app"
],

function(app) {
	window.localize("modules.hpiAdmin.searchConfig.advancedSearchConfig.useStrict");

	var AdvancedSearchConfig = app.module();
    
    // Default Model.
    AdvancedSearchConfig.Model = Backbone.Model.extend({
        defaults : function() {
            return {
                "type"     		       : "AdvancedSearchConfig",
                "label"		           : window.localize("modules.hpiAdmin.searchConfig.advancedSearchConfig.advancedSearch"),
                "enabled"	           : false,
                "defaultAllLogicBtn"   : true
            };
        }
    });

	function ConfigViewModel(model, options) {
		var self = this;
		//enabled is configurable so we'll have to declare it here
		self.enabled = ko.observable();
		self.defaultAllLogicBtn = kb.observable(model, "defaultAllLogicBtn");
		if (model.get("enabled")) {self.enabled("true");}
		else {self.enabled("false");}
		self.enabled.subscribe(function() {
			if (self.enabled() === "true") {
				model.set('enabled', true);
			} else {
				model.set('enabled', false);
			}
		});
		
		return self;
	}

	AdvancedSearchConfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/searchconfig/advancedsearchconfig",
		initialize: function() {
			this.viewModel = new ConfigViewModel(this.model, this.options);
		},
		afterRender: function() {		
		    kb.applyBindings(this.viewModel, this.$el[0]);
		}
	});

	return AdvancedSearchConfig;
});