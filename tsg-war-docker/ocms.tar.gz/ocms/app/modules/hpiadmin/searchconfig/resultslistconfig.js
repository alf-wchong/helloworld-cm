// Resultslistconfig module
define([
  // Application.
	"app",
	"modules/hpiadmin/actionconfig/hpiactionconfig",
    "modules/hpiadmin/searchconfig/genericresultsconfig",
    "modules/common/iconservice"
],

// Map dependencies from above array.
function(app, ActionConfig, GenericResultsConfig) {

	// Create a new module.
	var Resultslistconfig = app.module();

	Resultslistconfig.TypeCollection = Backbone.Collection.extend({
		model: Resultslistconfig.TypeModel
	});

	// Default Model.
	Resultslistconfig.Model = GenericResultsConfig.Model.extend({
		defaults : function() {
			return {
				"type"		: "ResultsList",
				"label"		: window.localize("modules.hpiAdmin.searchConfig.resultsListConfig.listView"),
				"enabled"	: false,
				"icon"		: ""
			};
		}
	});

    //open for extension
	Resultslistconfig.ViewModel = GenericResultsConfig.ViewModel;

	Resultslistconfig.Views.Config = GenericResultsConfig.Views.Config.extend({
		template : "hpiadmin/searchconfig/resultslistconfig"
	});

	// Default View.
	Resultslistconfig.Views.Layout = GenericResultsConfig.Views.Layout.extend({
		template: "hpiadmin/searchconfig/resultslistconfig"
	});

	// Return the module for AMD compliance.
	return Resultslistconfig;
});
