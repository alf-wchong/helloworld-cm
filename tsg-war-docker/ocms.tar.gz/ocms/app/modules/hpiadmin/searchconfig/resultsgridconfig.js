// Resultsgridconfig module
define([
    // Application.
    "app",
    "modules/hpiadmin/actionconfig/hpiactionconfig",
    "modules/hpiadmin/searchconfig/genericresultsconfig",
    "modules/common/iconservice"
],

// Map dependencies from above array.
function(app, ActionConfig, GenericResultsConfig) {
    "use strict";

    // Create a new module.
    var Resultsgridconfig = app.module();

    Resultsgridconfig.TypeCollection = Backbone.Collection.extend({
        model: Resultsgridconfig.TypeModel
    });

    Resultsgridconfig.Model = GenericResultsConfig.Model.extend({
        defaults : function(){
            return {
                "type": "ResultsGrid",
                "label": window.localize("modules.hpiAdmin.searchConfig.resultsGridConfig.gridView"),
                "enabled": false,
                "icon": ""
            };
        }
    });

    //open for extension
    Resultsgridconfig.ViewModel = GenericResultsConfig.ViewModel;

    Resultsgridconfig.Views.Config = GenericResultsConfig.Views.Config.extend({
        template: "hpiadmin/searchconfig/resultsgridconfig"
    });

    // Default View.
    Resultsgridconfig.Views.Layout = GenericResultsConfig.Views.Layout.extend({
        template: "hpiadmin/searchconfig/resultsgridconfig"
    });

    // Return the module for AMD compliance.
    return Resultsgridconfig;

});
