// Advanced Search module
define([
	"app",
	"modules/hpiadmin/searchconfig/searchrestrictions/views/typeselectitemview",
	"modules/hpiadmin/searchconfig/searchrestrictions/views/typecollectionview",
	"modules/hpiadmin/searchconfig/searchrestrictions/views/groupbuttonview"
],
function(app, TypeSelect, TypeCollection, GroupButtonView) {

	// Create a new module.
	var GroupLayoutView = {};

	GroupLayoutView.LayoutView = Backbone.Marionette.LayoutView.extend({
		template: "hpiadmin/searchconfig/searchrestrictionconfig/grouplayoutview",
		className: "groupLayoutView well well-light",		
        manage: false,
		regions: {
			typeSelectionRegion: "#typeSelectionRegion",
            typeCollectionRegion : "#typeCollectionRegion",
            groupButtonRegion : "#groupButtonRegion"
		},
		initialize: function(options) {
			//we need to take our options and build up the gorup layout view accordingly, im not doing that at all right now
			if(options){
				//set the model
				this.model = options.model;
				this.types = this.model.get('types');
				this.group = options.model.get("group");
				this.queryLang = options.model.get('currentQueryLang');
			}
		},
		onShow: function(){
			//three regions inside grouplayout view; collection of types, available types to select, and button view (delete type)
			this.getRegion("typeCollectionRegion").show(new TypeCollection.CollectionView({collection: this.types, model: this.model}));
			this.getRegion("typeSelectionRegion").show(new TypeSelect.ItemView({model: this.model, queryLang: this.queryLang}));
			this.getRegion("groupButtonRegion").show(new GroupButtonView.ItemView({model: this.model}));
			this.serializeData();
		},
		serializeData: function(){
			return {  
				currentGroupLabel : this.group.groupLabel,
				groupName : this.group.groupName
			};
		}

    });
	
	GroupLayoutView.EmptyView = Backbone.Marionette.LayoutView.extend({
		template: "hpiadmin/searchconfig/searchrestrictionconfig/grouplayoutemptyview",
		tagName: "div",		
        manage: false,
		events: {
			'click #groupToggle' : "showNewGroup"
		},
		initialize: function(options) {
			if(options){
				this.model = options.model;
			}
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				test : 'test'
			};
		},
		showNewGroup: function() {
	    }

    });

	return GroupLayoutView;
});