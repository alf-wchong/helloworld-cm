// Advanced Search module
define([
	"app",
	"modules/hpiadmin/searchconfig/searchrestrictions/views/grouplayoutview"
],
function(app,GroupLayoutView) {

	// Create a new module.
	var SelectedGroupCollection = {};

	SelectedGroupCollection.CollectionView = Backbone.Marionette.CollectionView.extend({
		className: "selectedgroupcollection",
		childView: GroupLayoutView.LayoutView,
		emptyView: GroupLayoutView.EmptyView,		
        manage: false,

		initialize: function(options) {
			if(options){
				this.model = options.model;
				this.query = options.query;
			}
		}
		//KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
        //onShow: function(){
        	//This doesn't work because manage has to be true for this to work.
			//Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
			//on the view.  Consider the 'listenTo' above to be the 'onShow()'
        //},
    });

	return SelectedGroupCollection;
});