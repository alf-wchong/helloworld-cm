define([
	"app"
],
function(app) {

	// Create a new module.
	var GroupButtonView = {};

	GroupButtonView.ItemView = Backbone.Marionette.ItemView.extend({
		//el: "#fb-sidebar-outlet",
		template: "hpiadmin/searchconfig/searchrestrictionconfig/groupbuttonview",
		className: "typeSelect",		
        manage: false,
		events: {
			'click .removeGroup': 'removeGroup'
		},
		initialize: function(options) {
			if(options){
				this.model = options.model;
				this.group = this.model.get('group');
			}
		},
		onBeforeShow: function(){	
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
		},
		onRender: function() {
		},
		removeGroup: function() {
			//when remove group button is pressed, remove that model from the collection and add the deleted group
			//back into the available groups list
			this.model.collection.remove(this.model);
			app.trigger("availableGroupSelect:addDeletedGroup", this.group);
		}
		//KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
        //onShow: function(){
        	//This doesn't work because manage has to be true for this to work.
			//Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
			//on the view.  Consider the 'listenTo' above to be the 'onShow()'
        //},
    });

	return GroupButtonView;
});