define([
	"app",
	"modules/hpiadmin/searchconfig/searchrestrictions/restrictiontype"
],
function(app, RestrictionType) {

	// Create a new module.
	var RestrictionGroup = {};

	//default model with type, label, restriction (collection of groups and types) and the currentQueryLanguage (fts or dql)
	RestrictionGroup.Model = Backbone.Model.extend({
        defaults : function() {
            return {
            	"group"     		   : {},
                'types'		  		   : new RestrictionType.Collection(),
                'currentQueryLang'	   : 'fts'
            };
        },
        //Set restriction to be a backbone collection
        initialize: function(options) {
			if(options && options.types) {
				this.set('types', new RestrictionType.Collection(options.types));
			} else {
				this.set('types', new RestrictionType.Collection());
			}
		}
    });

    RestrictionGroup.Collection = Backbone.Collection.extend({
    	model: RestrictionGroup.Model
    });

	return RestrictionGroup;



});