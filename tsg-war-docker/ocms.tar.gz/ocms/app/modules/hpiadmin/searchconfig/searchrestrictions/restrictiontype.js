define([
	"app"
],
function(app) {

	// Create a new module.
	var RestrictionType = {};

	//default model with type, label, restriction (collection of groups and types) and the currentQueryLanguage (fts or dql)
	RestrictionType.Model = Backbone.Model.extend({
        defaults : function() {
            return {
            	'group'     		   : '',
                'type'		  		   : {},
                'queryString'	 	   : ''
            };
        }
    });

    RestrictionType.Collection = Backbone.Collection.extend({
    	model: RestrictionType.Model
    });

	return RestrictionType;



});