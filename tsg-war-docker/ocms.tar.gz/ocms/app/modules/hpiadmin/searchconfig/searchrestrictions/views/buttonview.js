define([
	"app",
	"handlebars"
],
function(app, Handlebars) {

	// Create a new module.
	var ButtonView = {};

	ButtonView.ItemView = Backbone.Marionette.ItemView.extend({
		//el: "#fb-sidebar-outlet",
		template: "hpiadmin/searchconfig/searchrestrictionconfig/buttonview",
		className: "typeSelect",		
        manage: false,
		events: {
			'click .resetButton': "resetAll",
			'click .removeButton' : "removeType",
			'keyup .postQueryRegex' : "updatePostQueryRegex",
			'change .postQueryRegexAttr': "updateRegexAttr"
		},
		initialize: function(options) {
			var self = this;

			if(options){
				this.model = options.model;
				this.group = this.model.get('group');
				this.type = this.model.get('type');
				this.postQueryRegex = this.model.get('postQueryRegex');
				this.postQueryRegexAttr = this.model.get('postQueryRegexAttr');
			}

			app.context.configService.getAdminTypeConfig(this.type.typeName, function(attributes) {
				//get all attributes from the otc and get pertaining data
				self.availableAttrs = _.map(attributes.get('attrs').models, function(attribute) {
					return {'ocName' : attribute.get('ocName'), 'label' : window.localize(attribute.get('label')),'selected': attribute.get('ocName') === self.postQueryRegexAttr};
				});
				//self.render();
			});
		},
		onBeforeShow: function(){
			
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				postQueryRegex : this.postQueryRegex,
				availableAttrs : this.availableAttrs,
				postQueryRegexAttr : this.postQueryRegexAttr
			};
		},
		removeType: function() {
			this.model.collection.remove(this.model);
			app.trigger("typeSelectItemView:addDeletedType"+this.group, this.type);
		},
		resetAll: function() {
			var self = this;
			self.model.set('queryString', '');
			app.trigger("queryEditView:renderView"+self.group+self.type.typeName, "");
		},
		updatePostQueryRegex: function(event){
			this.model.set('postQueryRegex', event.currentTarget.value);
		},
		updateRegexAttr: function(event){
			this.model.set('postQueryRegexAttr', event.currentTarget.value);
		}
		//KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
        //onShow: function(){
        	//This doesn't work because manage has to be true for this to work.
			//Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
			//on the view.  Consider the 'listenTo' above to be the 'onShow()'
        //},
    });

	return ButtonView;
});