// Advanced Search module
define([
	"app",
	"modules/hpiadmin/searchconfig/searchrestrictions/restrictiontype"
],
function(app, RestrictionType) {

	// Create a new module.
	var TypeSelect = {};

	TypeSelect.ItemView = Backbone.Marionette.ItemView.extend({
		//el: "#fb-sidebar-outlet",
		template: "hpiadmin/searchconfig/searchrestrictionconfig/typeselectitemview",
		className: "typeSelect",		
        manage: false,
		events: {
			'click .availableType' : "addNewType"
		},
		initialize: function(options) {
			var self = this;
			if(options){
				this.model = options.model;
				this.group = options.model.get('group').groupName;
				this.queryLang = options.queryLang;
			}
			
			this.availableTypes = [];
			
			app.context.configService.getAdminOTC(function (config) {
				config.get("configs").each(function (typeConfig) {
					//create available types based on config
					self.availableTypes.push({
						"label": window.localize(typeConfig.get("label")),
						"value": typeConfig.get("ocName")
					});
					
				});
				_.each(self.model.get('types').models, function(type) {
					//for each already configured type, remove it from available types list
					self.availableTypes = _.filter(self.availableTypes, function(availableType){
						return availableType.value != type.get('type').typeName;
					});
				});
				self.render();
			});

			this.listenTo(app, "typeSelectItemView:addDeletedType"+this.group, this.addDeletedType);
		},
		onBeforeShow: function(){
			
		},
		addDeletedType: function(type) {
			//add back type into available types when deleted from type collection
			this.availableTypes.push({
						"label": window.localize(type.typeLabel),
						"value": type.typeName
					});
			this.render();
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				availableTypes : this.availableTypes
			};
		},
		addNewType: function(event) {
			//when an available type is clicked, we have to add it to the types collection
			var self = this;
			var typeName = event.target.attributes.value.value;
			var typeLabel = event.target.textContent;
			//create new model for type, with the group on it along with the current type, and an initial empty query string
			var newType = new RestrictionType.Model({
				'group' : this.group,
				'queryLang' : this.queryLang,
				'type' : {'typeName' : typeName, 'typeLabel' : typeLabel},
				'queryString' : ""
			});
			//add new model to existing types backbone collection and set the model accordingly
			self.model.get('types').add(newType);
			self.model.set('types', self.model.get('types'));
			//remove type from available types as it is no longer so
			self.availableTypes = _.filter(self.availableTypes, function(type){
				return type.value != typeName;
			});
			self.render();
	    }
    });

	return TypeSelect;
});