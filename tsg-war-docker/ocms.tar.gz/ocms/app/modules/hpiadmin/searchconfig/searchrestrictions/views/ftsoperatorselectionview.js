// Advanced Search module
define([
        "app",
        "handlebars"
    ],
    function(app, Handlebars) {

        // Create a new module.
        var FtsOperatorSelect = {};

        FtsOperatorSelect.ItemView = Backbone.Marionette.ItemView.extend({
            template: "hpiadmin/searchconfig/searchrestrictionconfig/ftsoperatorselectionview",
            className: "typeSelect",
            manage: false,
            events: {
                'click #groupToggle': "showNewGroup",
                'click .list-group-item': "addOperator"
            },
            initialize: function(options) {
                var self = this;

                if (options) {
                    this.model = options.model;
                    this.group = this.model.get('group');
                    this.type = this.model.get('type').typeName;
                }

                //hardcoded list of various operators that could be used to build a query
                self.operators = [{
                        'value': '(',
                        'label': '('
                    },
                    {
                        'value': ')',
                        'label': ')'
                    },
                    {
                        'value': 'AND',
                        'label': 'AND'
                    },
                    {
                        'value': 'OR',
                        'label': 'OR'
                    },
                    {
                        'value': 'equals',
                        'label': '='
                    },
                    {
                        'value': 'notEquals',
                        'label': '!='
                    },
                    {
                        'value': 'lessThan',
                        'label': '<'
                    },
                    {
                        'value': 'greaterThan',
                        'label': '>'
                    },
                    {
                        'value': 'lessThanOrEquals',
                        'label': '<='
                    },
                    {
                        'value': 'greaterThanOrEquals',
                        'label': '>='
                    },
                    {
                        'value': 'like',
                        'label': 'LIKE'
                    }
                ];
            },
            onBeforeShow: function() {},
            onShow: function() {
                this.serializeData();
            },
            serializeData: function() {
                return {
                    operators: this.operators
                };
            },
            showNewGroup: function() {},
            addOperator: function() {
                    var self = this;
                    var index;
                    //get operator using jquery when one is clicked
                    var foundOpName = event.target.attributes.value.value;
                    //find operator in list based on value of jquery click
                    var currentOperator = _.findWhere(this.operators, { value: foundOpName });
                    var addition = "";
                    //possible for there already to be a string in the query edit view, so get that off the model
                    var tempString = this.model.get('queryString');
                    //there are various situations in which we have to deal with the operator in a specific way,
                    //so deal with those situations here
                    switch (currentOperator.value) {
                        case 'notEquals':
                            //change the last @ symbol to a ! if they are looking for not equals
                            index = tempString.lastIndexOf("@");
                            if (index != -1) {
                                tempString = tempString.substr(0, index) + "!" + tempString.substr(index + 1);
                            }
                            break;
                        case 'equals':
                            //if they are looking for an exact search, switch the @ sign with an =
                            index = tempString.lastIndexOf("@");
                            if (index != -1) {
                                tempString = tempString.substr(0, index) + "=" + tempString.substr(index + 1);
                            }
                            break;
                        case 'like':
                            //if the search is like, then add wildcards in there
                            tempString = tempString + "\\*VALUE\\*";
                            break;
                        case 'lessThan':
                        case 'lessThanOrEquals':
                            //For some reason, ._parent._parent._parent is the only level that the attribute persists on the model
                            if (self._parent._parent._parent.isLastAttrDate === true) {
                                //addition is then a date, and less than so start from a very old time because MIN doesn't work
                                addition = "[\"1500\\-01\\-01T10\\:00\\:00\\.000\" TO \"YYYY\\-MM\\-DDT00\\:00\\:00\\.000\"]";
                            } else {
                                if (currentOperator.value === 'lessThanOrEquals') {
                                    addition = "[MIN TO VALUE]";
                                } else {
                                    addition = "[MIN TO VALUE>";
                                }

                            }
                            tempString += addition;
                            break;
                        case 'greaterThan':
                        case 'greaterThanOrEquals':
                            ////For some reason, ._parent._parent._parent is the only level that the attribute persists on the model
                            if (self._parent._parent._parent.isLastAttrDate === true) {
                                //addition is then a date and it's greater than/greater than or equal, 
                                //so start with template date that they fill in and go to max
                                addition = "[\"YYYY\\-MM\\-DDT00\\:00\\:00\\.000\" TO MAX]";
                            } else {
                                if (currentOperator.value === 'greaterThanOrEquals') {
                                    addition = "[VALUE TO MAX]";
                                } else {
                                    addition = "<VALUE TO MAX]";
                                }

                            }
                            tempString += addition;
                            break;
                        default:
                            //All other cases that don't need special handling, AND, OR, (, and )
                            if (currentOperator.value !== "") {
                                tempString = tempString + " " + currentOperator.value;
                            }
                    } //end of operator switch

                    //set the model and then render the query edit view again
                    self.model.set('queryString', tempString);
                    app.trigger("queryEditView:renderView" + self.group + self.type, tempString);

                }
                //KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
                //onShow: function(){
                //This doesn't work because manage has to be true for this to work.
                //Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
                //on the view.  Consider the 'listenTo' above to be the 'onShow()'
                //},
        });

        return FtsOperatorSelect;
    });