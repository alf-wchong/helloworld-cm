// Advanced Search module
define([
	"app",
	"modules/hpiadmin/searchconfig/searchrestrictions/views/typelayoutview"
],
function(app,TypeLayoutView) {

	// Create a new module.
	var TypeCollection = {};

	TypeCollection.CollectionView = Backbone.Marionette.CollectionView.extend({
		className: "selectedgroupcollection",
		childView: TypeLayoutView.LayoutView,
		emptyView: TypeLayoutView.EmptyView,		
        manage: false,

		initialize: function(options) {
			if(options){
				this.model = options.model;
				this.collection = options.collection;
			}
		}
    });

	return TypeCollection;
});