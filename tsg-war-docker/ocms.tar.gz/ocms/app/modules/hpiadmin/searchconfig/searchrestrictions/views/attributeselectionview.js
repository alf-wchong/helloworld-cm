// Advanced Search module
define([
        "app",
        "handlebars"
    ],
    function(app, Handlebars) {

        // Create a new module.
        var AttributeSelect = {};

        AttributeSelect.ItemView = Backbone.Marionette.ItemView.extend({
            template: "hpiadmin/searchconfig/searchrestrictionconfig/attributeselectionview",
            className: "typeSelect",
            manage: false,
            events: {
                'click #groupToggle': "showNewGroup",
                'click .list-group-item': "addAttr"
            },
            initialize: function(options) {
                var self = this;
                if (options) {
                    this.model = options.model;
                    this.group = this.model.get('group');
                    this.type = this.model.get('type').typeName;
                }

                this.availableAttrs = [];
                app.context.configService.getAdminTypeConfig(this.type, function(attributes) {
                    //get all attributes from the otc and get pertaining data
                    self.availableAttrs = _.map(attributes.get('attrs').models, function(attribute) {
                        return { 'ocName': attribute.get('ocName'), 'label': window.localize(attribute.get('label')), 'dataType': attribute.get('dataType'), 'repoName': attribute.get('repoName') };
                    });
                    self.render();
                });

            },
            onShow: function() {
                this.serializeData();
            },
            serializeData: function() {
                return {
                    typeName: this.type,
                    availableAttrs: this.availableAttrs
                };
            },
            addAttr: function() {
                    var self = this;
                    //get attr name with jquery and find where it is on list of available attrs
                    var foundAttrName = event.target.attributes.value.value;
                    var currentAttr = _.findWhere(this.availableAttrs, { ocName: foundAttrName });
                    //grab current query string already in the query edit view
                    var currentQueryString = self.model.get('queryString');
                    //need repo name for attribute
                    var repoName = currentAttr.repoName;
                    var repoPieces = repoName.split(":");
                    //set up attribute in default 'like' search format
                    if (this.model.get("queryLang") === "dql") {
                        repoName = repoPieces[0];
                    } else {
                        repoName = "@" + repoPieces[0] + "\\:" + repoPieces[1] + ":";
                    }

                    var tempQueryString = currentQueryString + ' ' + repoName;
                    var isLastDate = false;
                    if (currentAttr.dataType === "date") {
                        isLastDate = true;
                    }

                    self.model.set("lastAttrType", currentAttr.dataType);
                    //set the model and whether this attribute is a date (deal with later)
                    self.model.set('queryString', tempQueryString);
                    //For some reason, ._parent._parent._parent is the only level that the attribute persists on the model
                    self._parent._parent._parent.isLastAttrDate = isLastDate;
                    //trigger into queryEditView to re-render the text area
                    app.trigger("queryEditView:renderView" + self.group + self.type, tempQueryString);
                }
                //KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
                //onShow: function(){
                //This doesn't work because manage has to be true for this to work.
                //Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
                //on the view.  Consider the 'listenTo' above to be the 'onShow()'
                //}
        });

        return AttributeSelect;
    });