// Advanced Search module
define([
        "app",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/attributeselectionview",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/ftsoperatorselectionview",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/dqloperatorselectionview",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/queryeditview",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/buttonview"
    ],
    function(app, AttributeSelect, FtsOperatorSelect, DQLOperatorSelect, QueryEdit, ButtonView) {

        // Create a new module.
        var TypeLayoutView = {};

        TypeLayoutView.LayoutView = Backbone.Marionette.LayoutView.extend({
            //el: "#fb-sidebar-outlet",
            template: "hpiadmin/searchconfig/searchrestrictionconfig/typelayoutview",
            className: "typeLayoutView well well-light",
            manage: false,
            regions: {
                attributeSelectRegion: "#attributeSelectRegion",
                opsSelectRegion: "#opsSelectRegion",
                queryEditRegion: "#queryEditRegion",
                buttonRegion: "#buttonRegion"
            },
            initialize: function(options) {
                if (options) {
                    this.model = options.model;
                    this.type = options.model.get('type');
                    this.group = options.model.get('group');
                    this.queryLang = options.model.get('queryLang');
                }
            },
            onShow: function() {
                //render 4 views within type layout view: attribute selection region, operator selection, query edit and button
                if (this.queryLang === 'fts') {
                    //As of now, fts is the only possible query language, but this if statement is made to handle
                    //future other languages such as dql
                    this.getRegion("opsSelectRegion").show(new FtsOperatorSelect.ItemView({ model: this.model }));
                } else if (this.queryLang === 'dql') {
                    this.getRegion("opsSelectRegion").show(new DQLOperatorSelect.ItemView({ model: this.model }));
                }
                this.getRegion("attributeSelectRegion").show(new AttributeSelect.ItemView({ model: this.model }));
                this.getRegion("queryEditRegion").show(new QueryEdit.ItemView({ model: this.model }));
                this.getRegion("buttonRegion").show(new ButtonView.ItemView({ model: this.model }));
                this.serializeData();
            },
            serializeData: function() {
                return {
                    currentType: this.type.typeLabel,
                    typeName: this.type.typeName,
                    groupName: this.group
                };
            }
        });

        TypeLayoutView.EmptyView = Backbone.Marionette.LayoutView.extend({
            template: "hpiadmin/searchconfig/searchrestrictionconfig/typelayoutviewempty",
            tagName: "div",
            manage: false,
            events: {
                'click #groupToggle': "showNewGroup"
            },
            initialize: function(options) {
                if (options) {
                    this.model = options.model;
                }
            },
            onShow: function() {
                this.serializeData();
            },
            serializeData: function() {
                return {
                    test: 'test'
                };
            },
            showNewGroup: function() {}
        });

        return TypeLayoutView;
    });