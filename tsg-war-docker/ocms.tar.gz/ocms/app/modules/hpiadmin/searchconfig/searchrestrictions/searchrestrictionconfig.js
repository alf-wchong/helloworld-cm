// Advanced Search module
define([
        "app",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/availablegroupselect",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/selectedgroupcollection",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/grouplayoutview",
        "modules/hpiadmin/searchconfig/searchrestrictions/views/querylangsliderview",
        "modules/hpiadmin/searchconfig/searchrestrictions/restrictiongroup"
    ],
    function(app, AvailableGroupSelect, SelectedGroupCollection, GroupLayoutView, QueryLangSliderView, RestrictionGroup) {

        // Create a new module.
        var SearchRestrictionConfig = {};

        //default model with type, label, restriction (collection of groups and types) and the currentQueryLanguage (fts or dql)
        SearchRestrictionConfig.Model = Backbone.Model.extend({
            defaults: function() {
                return {
                    "type": "Search Restriction Config",
                    "label": "Search Restriction",
                    'restriction': new RestrictionGroup.Collection(),
                    'currentQueryLang': 'fts'
                };
            },
            //Set restriction to be a backbone collection
            initialize: function(options) {
                if (options && options.restriction) {
                    this.set("restriction", new RestrictionGroup.Collection(options.restriction));
                } else {
                    this.set("restriction", new RestrictionGroup.Collection());
                }
                if (options && options.currentQueryLang) {
                    this.set('currentQueryLang', options.currentQueryLang);
                } else {
                    this.set('currentQueryLang', 'fts');
                }
            }
        });

        SearchRestrictionConfig.LayoutView = Backbone.Marionette.LayoutView.extend({
            template: "hpiadmin/searchconfig/searchrestrictionconfig/searchrestrictionconfig",
            className: "searchrestrictionconfig",
            regions: {
                groupSelectionItemView: "#groupSelectionItemView",
                groupCollectionView: "#groupCollectionView",
                queryLangSliderView: "#queryLangSliderView"
            },
            initialize: function(options) {
                var self = this;

                if (options) {
                    this.model = options.model;
                }

                this.listenTo(app, "searchrestrictionconfig:switchQuery", function(queryType) {
                    self.queryLangSwitch(queryType);
                });

            },
            afterRender: function() {
                this.getRegion("groupSelectionItemView").show(new AvailableGroupSelect.ItemView({ model: this.model }));
                this.getRegion("groupCollectionView").show(new SelectedGroupCollection.CollectionView({ collection: this.model.get('restriction'), model: this.model }));
                this.getRegion("queryLangSliderView").show(new QueryLangSliderView.ItemView({ model: this.model }));
                this.serializeData();
            },
            queryLangSwitch: function(query) {
                    //when slider is clicked and functional, clear out existing restriction model and start anew with the other language
                    //then render new layout
                    this.query = query;
                    this.model.set("currentQueryLang", query);
                    this.model.set('restriction', new Backbone.Collection());
                    this.getRegion("groupSelectionItemView").show(new AvailableGroupSelect.ItemView({ model: this.model }));
                    this.getRegion("groupCollectionView").show(new SelectedGroupCollection.CollectionView({ collection: this.model.get('restriction'), model: this.model }));
                    this.getRegion("queryLangSliderView").show(new QueryLangSliderView.ItemView({ model: this.model }));
                }
                //KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
                //onShow: function(){
                //This doesn't work because manage has to be true for this to work.
                //Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
                //on the view.  Consider the 'listenTo' above to be the 'onShow()'
                //},
        });

        return SearchRestrictionConfig;
    });