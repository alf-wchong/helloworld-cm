// Advanced Search module
define([
	"app",
	"handlebars"
],
function(app, Handlebars) {

	// Create a new module.
	var QueryEdit = {};

	QueryEdit.ItemView = Backbone.Marionette.ItemView.extend({
		template: "hpiadmin/searchconfig/searchrestrictionconfig/queryeditview",
		className: "typeSelect",		
        manage: false,
        events: {
        	'blur .queryEditArea' : "updateCode"
        },
		initialize: function(options) {
			var self = this;
			if(options){
				this.model = options.model;
				self.queryString = this.model.get('queryString');
				this.group = this.model.get('group');
				this.type = this.model.get('type').typeName;
			}
			this.listenTo(app, "queryEditView:renderView"+this.group+this.type, this.renderView);
		},
		onBeforeShow: function(){
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				groupName: this.group,
				typeName: this.type,
				queryString: this.queryString
			};
		},
		showNewGroup: function() {
	    },
	    renderView: function(queryString) {
	    	//Re-render the view when an attribute or operator is clicked with updated query view
	    	this.queryString = queryString;
	    	this.render();
	    },
	    updateCode: function(evt) {
	    	//update the query string in the model when the view is updated manually
	    	var self = this;
	    	var newQuery = evt.currentTarget.value;
	    	self.model.set('queryString', newQuery);
	    }
		//KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
        //onShow: function(){
        	//This doesn't work because manage has to be true for this to work.
			//Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
			//on the view.  Consider the 'listenTo' above to be the 'onShow()'
        //},
    });

	return QueryEdit;
});