define([
        "app",
        "handlebars"
    ],
    function(app, Handlebars) {

        // Create a new module.
        var QueryLangSliderView = {};

        QueryLangSliderView.ItemView = Backbone.Marionette.ItemView.extend({
            //el: "#fb-sidebar-outlet",
            template: "hpiadmin/searchconfig/searchrestrictionconfig/querylangsliderview",
            className: "typeSelect",
            manage: false,
            events: {
                'change .ftsQuerySlider': "changeFtsValue",
                'click #proceedTypeChange': "proceedTypeChange",
                'click #stopTypeChange': "stopTypeChange"
            },
            initialize: function(options) {
                if (options) {
                    this.model = options.model;
                    this.queryLang = this.model.get("currentQueryLang");
                }
                //slider helper, set slider based on current query language
                Handlebars.registerHelper("isChecked", function(bool, fts) {
                    if (bool === fts) {
                        return "checked";
                    } else {
                        return "";
                    }
                });
            },
            changeFtsValue: function(evt) {
                this.typeToChangeTo = evt.target.id;
                $("#querySwitchWarningModal").modal("show");

            },
            stopTypeChange: function() {
                if ($("#dql").attr("checked")) {
                    $("#fts").attr("checked", true);
                } else {
                    $("#dql").attr("checked", true);
                }
            },
            proceedTypeChange: function() {
                $("#querySwitchWarningModal").modal("hide");
				$('body').removeClass('modal-open');
                app.trigger("searchrestrictionconfig:switchQuery", this.typeToChangeTo);
            },
            onBeforeShow: function() {},
            onShow: function() {
                this.serializeData();
            },
            onRender: function() {},
            serializeData: function() {
                    return { ftsQuery: this.queryLang };
                }
                //KEEP THIS COMMENT HERE BECAUSE IT IS IMPORTANT TO REALIZE HOW BACKBONE LAYOUT MANAGER AND MARIONETTE INTERACT TOGETHER
                //onShow: function(){
                //This doesn't work because manage has to be true for this to work.
                //Backbone.layout manager is the cause of this.  It is telling this view to render so we can't seem to set manage:false
                //on the view.  Consider the 'listenTo' above to be the 'onShow()'
                //},
        });

        return QueryLangSliderView;
    });