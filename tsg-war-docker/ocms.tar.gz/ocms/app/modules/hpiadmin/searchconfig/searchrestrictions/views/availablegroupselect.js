// Advanced Search module
define([
	"app",
	"modules/search/advancedsearch/models/abstractmodel",
	"modules/search/advancedsearch/views/abstractview",
	"modules/search/advancedsearch/factory/modelfactory",
	"modules/hpiadmin/searchconfig/searchrestrictions/restrictiongroup",
	"modules/hpiadmin/searchconfig/searchrestrictions/restrictiontype"
],
function(app, AbstractModel, AbstractView, ModelFactory, RestrictionGroup, RestrictionType) {

	// Create a new module.
	var AvailableGroupSelect = {};

	AvailableGroupSelect.ItemView = Backbone.Marionette.ItemView.extend({
		template: "hpiadmin/searchconfig/searchrestrictionconfig/availablegroupselect",
		className: "availableGroupSelect well well-light",		
        manage: false,
		events: {
			'click .availableGroup' : 'createNewGroup'
		},
		initialize: function(options) {
			var self = this;
			//set our model to the restriction part of the model, but keep full model around for setting our model
			if(options){
				this.model = options.model.get("restriction");
				this.fullModel = options.model;
				this.queryLang = options.model.get('currentQueryLang');
			}
			
			
		 
			var requestGroupObject = {
				"authorityType": "group",
				"criterion": {
								"attrToSearch": "displayName", 
								"matchType": "startsWith", 
								"searchTerm": "*"
							}
			};
			
			this.groupList = [];

			$.ajax(
				{
				url: app.serviceUrlRoot + "/authorities/search", 
				type: "POST",
				contentType: "application/json",
				data: JSON.stringify(requestGroupObject),
				success: function (groups){
					_.each(groups, function(group) {
						self.groupList.push({groupName: group.authorityId, groupLabel: group.displayName});
					});
					
					//for each already configured group in the model, remove it from the group list
					_.each(self.model.models, function(model) {
						self.groupList = _.filter(self.groupList, function(listGroup){
							return listGroup.groupName != model.get('group').groupName;
						});
					});
					self.render();
				},
				error: function(jqXHR, textStatus, errorThrown) {
					app.log.error(window.localize("modules.hpiAdmin.searchConfig.searchRestrictions.views.availableGroupSelect.userGroups"));
				}
			});

			this.listenTo(app, "availableGroupSelect:addDeletedGroup", this.addDeletedGroup);
		},
		onShow: function(){
			this.serializeData();
		},
		addDeletedGroup: function(group) {
			//Adds deleted group back into the available group selection view
			this.groupList.push({groupName: group.groupName, groupLabel: group.groupLabel});
			this.serializeData();
			this.render();
		},
		serializeData: function(){
			return {
				groupList : this.groupList
			};
		},
		createNewGroup: function(event) {
			var self = this;
			//group will have both group label and ocName accessible through jquery on click of an available group
			var group = {'groupLabel' : event.target.textContent,
						 'groupName' : event.target.attributes.value.value};
			//create new Backbone model, with types as a backbone collection
			var newModel = new RestrictionGroup.Model({
	    		'group' : group,
	    		'types'	: undefined,
	    		'currentQueryLang': self.queryLang
	    	});
			self.model.add(newModel);
			self.fullModel.set('restriction', self.model);
			//take the group that was just clicked off the available group list
			self.groupList = _.filter(self.groupList, function(listGroup){
				return listGroup.groupName != group.groupName;
			});
			self.render();
	    }
		
    });

	return AvailableGroupSelect;
});