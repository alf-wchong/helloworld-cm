define([
	// Application.
	"app",
	"knockout",
	"knockback",

	"modules/hpiadmin/stageconfig/submenu"
],

// Map dependencies from above array.
function(app, ko, kb, Submenu) {

	// Create a new module.
	var Menu = app.module();

	// Relatedobjects.
	Menu.Model = Backbone.RelationalModel.extend({
		defaults:  function() {
            return {
				"menuId" : "",
				"label" : "",
				"groups" : ""
			};
		},

		relations: [{
			type : Backbone.HasMany,
			key : "subMenus",
			relatedModel : Submenu.Model,
			collectionType : Submenu.Collection
		}]
	});

	// Default Collection.
	Menu.Collection = Backbone.Collection.extend({
		model: Menu.Model
	});
	
	// Return the module for AMD compliance.
	return Menu;

});
