define([
	// Application.
	"app",
	"knockout",
	"knockback"
],

// Map dependencies from above array.
function(app, ko, kb) {

	// Create a new module.
	var Submenu = app.module();

	// Relatedobjects.
	Submenu.Model = Backbone.RelationalModel.extend({
		defaults:  function() {
            return {
				"subMenuId" : "",
				"label" : "",
				"groups" : ""
			};
		}
	});

	// Default Collection.
	Submenu.Collection = Backbone.Collection.extend({
		model: Submenu.Model
	});
	
	// Return the module for AMD compliance.
	return Submenu;

});
