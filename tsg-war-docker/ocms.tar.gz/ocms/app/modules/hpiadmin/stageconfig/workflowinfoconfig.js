define([
	"app",
	"modules/hpiadmin/hpiadmin"
],
function(app, Hpiadmin) {

	var WorkflowInfoConfig = app.module();
    
    // Default Model.
    WorkflowInfoConfig.Model = Backbone.Model.extend({
        defaults : function() {
            return {
                "type"     		       : "WorkflowInfoConfig",
                "label"		           : "WorkflowInfo",
                "enabled"	           : false
            };
        }
    });
    
    function ConfigViewModel(model, options) {
        var self = this;
        //enabled is configurable so we'll have to declare it here
        self.enabled = ko.observable();
        if (model.get("enabled")) {self.enabled("true");}
        else {self.enabled("false");}
        self.enabled.subscribe(function() {
            if (self.enabled() === "true") {
                model.set('enabled', true);
            } else {
                model.set('enabled', false);
            }
        });
        
        return self;
    }
    
    WorkflowInfoConfig.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/stageconfig/workflowinfoconfig",
        initialize: function() {
            this.viewModel = new ConfigViewModel(this.model, this.options);
        },
        afterRender: function() {		
            kb.applyBindings(this.viewModel, this.$el[0]);
        }
    });

	
	// Return the module for AMD compliance.
	return WorkflowInfoConfig;

});