define([
        "app",
        "modules/hpiadmin/hpiadmin"
    ],
    function(app, Hpiadmin, TossAcross) {

        var SearchResultTraversalConfig = app.module();

        SearchResultTraversalConfig.StageInfoConfigVent = _.extend({}, Backbone.Events);

        SearchResultTraversalConfig.Model = Backbone.Model.extend({
            type: "SearchResultTraversal",
            defaults: function() {
                return {
                    "type": "SearchResultTraversalConfig",
                    "label": window.localize("modules.hpiAdmin.stageConfig.searchResultTraversalConfig.searchResultTraversal"),
                    "enabled": false
                };
            }
        });

        function ConfigViewModel(model, options) {
            var self = this;
            //enabled is configurable so we'll have to declare it here
            self.enabled = ko.observable();
            if (model.get("enabled")) {
                self.enabled("true");
            } else {
                self.enabled("false");
            }
            self.enabled.subscribe(function() {
                if (self.enabled() === "true") {
                    model.set('enabled', true);
                } else {
                    model.set('enabled', false);
                }
            });

            return self;
        }

        SearchResultTraversalConfig.View = Backbone.Layout.extend({
            template: "hpiadmin/stageconfig/searchresulttraversalconfig",
            initialize: function() {
                this.viewModel = new ConfigViewModel(this.model, this.options);
            },
            afterRender: function() {
                kb.applyBindings(this.viewModel, this.$el[0]);
            }
        });

        // Return the module for AMD compliance.
        return SearchResultTraversalConfig;

    });