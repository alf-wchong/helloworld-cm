define([
	// Application.
	"app",
	"knockout",
	"knockback",
	"modules/hpiadmin/hpiadmin",
	"modules/hpiadmin/actionconfig/hpiactionconfig"
	
],

// Map dependencies from above array.
function(app, ko, kb, Hpiadmin, ActionConfig) {
	'use strict';

	var FolderActionConfig = app.module();

    FolderActionConfig.GroupModel = Backbone.Model.extend({
        defaults: function() {
            return {
                "label": "",
                "showLabel": true
            };
        },
        initialize: function(options){
            if(options && options.actions){
                this.set("actions", new ActionConfig.Collection(options.actions));
            } else {
                this.set("actions", new ActionConfig.Collection());
            }
        }
    });

    FolderActionConfig.GroupCollection = Backbone.Collection.extend({
        model: FolderActionConfig.GroupModel
    });

	FolderActionConfig.Model = Backbone.Model.extend({
		defaults: function() {
			return {
				"type": "Folderactionconfig",
				"observable": "container"
			};
		},
        initialize: function(options){
            if(options && options.actionGroups){
                this.set("actionGroups", new FolderActionConfig.GroupCollection(options.actionGroups));
            } else {
                this.set("actionGroups", new FolderActionConfig.GroupCollection());
            }
        }
	});


	FolderActionConfig.ViewModel = function(model, options) {
		var self = this;

        self.newGroupLabel = ko.observable();
        self.addingGroup = ko.observable(false);
        self.addGroup = function() {
            self.addingGroup(true);
        };

        self.submitAddGroup = function() {
            var groupToAdd = new FolderActionConfig.GroupModel({label: self.newGroupLabel()});
            model.get("actionGroups").push(groupToAdd);
            self.newGroupLabel(undefined);
            self.addingGroup(false);
        };

        self.cancelAddGroup = function() {
            self.newGroupLabel(undefined);
            self.addingGroup(false);
        };

        self.groups = kb.collectionObservable(model.get("actionGroups") || new Backbone.Collection(),
        {
            view_model: kb.ViewModel.extend({
                constructor: function(groupModel) {
                    var self = this;
                    kb.ViewModel.prototype.constructor.apply(this, arguments);
                    //actions need the trac name as the name...another weird thing
                    self.name = ko.observable(options.tracName);
                    //this is a really weird case b/c non of the other action configs have groups like this
                    //so the view is put on the markup below, but the actual individual vms are augmented here.

                    self.nothing = new ActionConfig.View({viewmodel: self, model : groupModel, showGroupActions: false });
                    return self;
                }
            })
        });
        self.selectedGroup = ko.observable();

        self.deleteGroup = function(groupVM) {
            _.each(model.get("actionGroups").models, function(group) {
                if (group.get("label") === groupVM.label()) {
                    model.get("actionGroups").remove(group);
                }
            });
            self.selectedGroup(undefined);
        };
        self.closeGroup = function() {
            self.selectedGroup(undefined);
        };
        self.editGroup = function(groupVM) {
            self.selectedGroup(groupVM);
        };

        
        return self;
	};

	FolderActionConfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/stageconfig/folderactionconfig",
        initialize: function(){
            this.viewModel = new FolderActionConfig.ViewModel(this.model, {tracName: this.options.tracName});
            //this sets the view and puts the template markup on the dom, the actual augmenting of the viewmodels occurs inside each group
            this.viewModel.name = ko.observable(this.options.tracName);
            this.setView("#action-config-template-outlet", new ActionConfig.View({viewmodel: this.viewModel, model : this.model, showGroupActions: false }));
        },
		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
		}
	});

	return FolderActionConfig;
});