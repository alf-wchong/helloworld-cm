define([
	// Application.
	"app"
],

// Map dependencies from above array.
function(app) {

	// Create a new module.
	var Relationtype = app.module();

	// Relatedobjects.
	Relationtype.Model = Backbone.Model.extend({
		defaults:  function() {
            return {
				"label" : "" ,
				"relationDirection": "",
				"relationName" :"",
				"relationType": "",
				"relationConfigType" : "" ,  
				"childType": "",
				"optionAutoExpand"  : "true",
				"optionsShowInfoBlock": "true", 
				"optionsShowAnnotations": "true", 
				"optionsShowMimeIcon": "true", 
				"optionsShowDualScreen": "true",
				"optionsShowExternalLaunch": "false", 
				"optionsDefaultOpen": "true", 
				"optionsExpandWithTags": "false",
				"optionsShowExportDoc": "false",
				"optionsHideEmptyRelations": "true",
				"optionsDisplaySize": "25", 
				"displayValue": "", 
				"andOr" : "",
				"infoBlock" : [],
				"displayAttr" : "",
				"additionalDisplayAttrs": [],
				"externalRelationEndpoint": "",
				"sortAttr" : "",
				"operator" : "",
				"criteria" : [{attribute: "", operator:"", type:"", value:"", termLogic:""}],
				"sortOrder" : "ascending",
				"resolver" : "stage",
				"resolverTrac" : "Do not Switch Tracs",
				"useResolverTrac" : true
			};
		}
	});

	// Default Collection.
	Relationtype.Collection = Backbone.Collection.extend({
		model: Relationtype.Model
	});
	
	// Return the module for AMD compliance.
	return Relationtype;

});
