// Stageconfig module
define([
	// Application.
	"app",
	"knockout",
	"knockback",
	"modules/hpiadmin/hpiadmin",
	
	"modules/hpiadmin/hpiadmin-switcher",

	//modules
	"modules/common/alert/alert",
	"modules/hpiadmin/stageconfig/searchresulttraversalconfig",
	"modules/hpiadmin/stageconfig/stageinfoconfig",
	"modules/hpiadmin/stageconfig/workflowinfoconfig",
	"modules/hpiadmin/stageconfig/relatedobjectsconfig",
	"modules/hpiadmin/stageconfig/docviewerconfig",
	"modules/hpiadmin/stageconfig/folderactionconfig"
],

// Map dependencies from above array.
function(app, ko, kb, Hpiadmin, Switcher, Alert, SearchResultTraversalConfig, Stageinfoconfig, WorkflowInfoConfig, Relatedobjectsconfig, Docviewerconfig, Folderactionconfig) {
	"use strict";

	// Create a new module.
	var Stageconfig = app.module();

		// This is based on an hpiadmin config.
		Stageconfig.Model = Hpiadmin.Config.extend({
				type: "StageConfig",
				initialize: function(options){
					if(options && options.searchResultTraversalConfig){
						this.set("searchResultTraversalConfig", new SearchResultTraversalConfig.Model(options.stageInfoConfig));
					} else {
						this.set("searchResultTraversalConfig", new SearchResultTraversalConfig.Model());
					}					
					
					if(options && options.stageInfoConfig){
						this.set("stageInfoConfig", new Stageinfoconfig.Model(options.stageInfoConfig));
					} else {
						this.set("stageInfoConfig", new Stageinfoconfig.Model());
					}

					if(options && options.relatedObjectsConfig){
						this.set("relatedObjectsConfig", new Relatedobjectsconfig.Model(options.relatedObjectsConfig));
					} else {
						this.set("relatedObjectsConfig", new Relatedobjectsconfig.Model());
					}

					if(options && options.workflowInfoConfig){
						this.set("workflowInfoConfig", new WorkflowInfoConfig.Model(options.workflowInfoConfig));
					} else {
						this.set("workflowInfoConfig", new WorkflowInfoConfig.Model());
					}

					if(options && options.folderActionConfig){
						this.set("folderActionConfig", new Folderactionconfig.Model(options.folderActionConfig));
					} else {
						this.set("folderActionConfig", new Folderactionconfig.Model());
					}

					if(options && options.docViewerConfig){
						this.set("docViewerConfig", new Docviewerconfig.Model(options.docViewerConfig));
					} else {
						this.set("docViewerConfig", new Docviewerconfig.Model());
					}

					if(options && options.docErrorHelpText) {
						this.set("docErrorHelpText", options.docErrorHelpText);
					} else {
						this.set("docErrorHelpText", "We are unable to access this document. Please return to your dashboard and try again, or contact your system administrator.");
					}
					if(options && options.docErrorHelpLabel) {
						this.set("docErrorHelpLabel", options.docErrorHelpLabel);
					} else {
						this.set("docErrorHelpLabel", "Document Not Found");
					}
					if(options && options.docPermissionHelpText) {
						this.set("docPermissionHelpText", options.docPermissionHelpText);
					} else {
						this.set("docPermissionHelpText", "You don't have permission to access this document's content. If you believe you should have access, please contact your system administrator.");
					}
					if(options && options.docPermissionHelpLabel) {
						this.set("docPermissionHelpLabel", options.docPermissionHelpLabel);
					} else {
						this.set("docPermissionHelpLabel", "Unauthorized");
					}
				},
				parseResponse: function(response){
					if(this.id){
						//just want the id
						response = _.pick(response, "id");
					} else if(response){
						if(response.searchResultTraversalConfig){
							this.set("searchResultTraversalConfig", new SearchResultTraversalConfig.Model(response.searchResultTraversalConfig));
							delete response.searchResultTraversalConfig;
						}
						if(response.stageInfoConfig){
							this.set("stageInfoConfig", new Stageinfoconfig.Model(response.stageInfoConfig));
							delete response.stageInfoConfig;
						}
						if(response.workflowInfoConfig){
							this.set("workflowInfoConfig", new WorkflowInfoConfig.Model(response.workflowInfoConfig));
							delete response.workflowInfoConfig;
						}
						if(response.relatedObjectsConfig){
							this.set("relatedObjectsConfig", new Relatedobjectsconfig.Model(response.relatedObjectsConfig));
							delete response.relatedObjectsConfig;
						}
						if(response.docViewerConfig){
							this.set("docViewerConfig", new Docviewerconfig.Model(response.docViewerConfig));
							delete response.docViewerConfig;
						}
						if(response.folderActionConfig){
							this.set("folderActionConfig", new Folderactionconfig.Model(response.folderActionConfig));
							delete response.folderActionConfig;
						}
					}

					return response;
				},
				
				defaults : {
						type : "StageConfig",
						searchResultTraversalConfig : new SearchResultTraversalConfig.Model(),
						stageInfoConfig : new Stageinfoconfig.Model(),
						workflowInfoConfig : new WorkflowInfoConfig.Model(),
						relatedObjectsConfig: new Relatedobjectsconfig.Model(),
						folderActionConfig: new Folderactionconfig.Model(),
						docViewerConfig: new Docviewerconfig.Model(),
						docErrorHelpText: window.localize("modules.hpiAdmin.stageConfig.stageConfig.thisDocumentDoesnt"),
						docPermissionHelpText: window.localize("modules.hpiAdmin.stageConfig.stageConfig.youDontHave"),
						docErrorHelpLabel: window.localize("modules.hpiAdmin.stageConfig.stageConfig.documentNotFound"),
						docPermissionHelpLabel: window.localize("modules.hpiAdmin.stageConfig.stageConfig.unauthorized") 
				}
		});
	
		Stageconfig.ViewModel = kb.ViewModel.extend( {
				constructor: function(model){
						//use super constructor to create id, name and type observables
						kb.ViewModel.prototype.constructor.call(this, model, {
								factories: {
										"modules.relatedobjectsconfig" : Relatedobjectsconfig.RelatedobjectsconfigViewModel,
										"modules.docviewerconfig" : Docviewerconfig.DocviewerconfigViewModel,
										"modules.folderactionconfig" : Folderactionconfig.ViewModel
								},
								requires: ["id", "name"]
						});
						this.label = kb.observable(model, "label");
						this.docErrorHelpText = kb.observable(model, "docErrorHelpText");
						this.docPermissionHelpText = kb.observable(model, "docPermissionHelpText");
						this.errorConfig = kb.observable(model, "errorConfig");
						this.elevateFolderPriority = kb.observable(model, "elevateFolderPriority");

						if (!this.elevateFolderPriority()) {
							this.elevateFolderPriority("false");
						}

						//view related model properties
						this.onCreateConfig = function(){
							model.save(model.toJSON(), {
								success: function(){
									app.trigger("modelSaveOrDestroy");
									Backbone.history.navigate("admin/StageConfig/" + model.get("name"), {replace: true, trigger: true} );
									app.trigger("alert:changeNotification", "alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
								},
								error: function(){
									app.trigger("alert:error", {
									header : window.localize("generic.errorSavingConfig"),
									message : window.localize("generic.configSaveFailed")
									});
								}
							});
						};
						
						this.subConfig = ko.observable();
						return this;
				}

		});

	// Default Collection.
    Stageconfig.Collection = Hpiadmin.ConfigTypeCollection.extend({
        model: Stageconfig.Model,
        initialize: function(model, options) {
            this.type = "StageConfig";         
        }
    });

	// Default View.
	Stageconfig.Views.Layout = Backbone.Layout.extend({
		template: "hpiadmin/stageconfig/stageconfig-mainlayout",
		initialize: function() {
			this.listenTo(app, "saveStageInfoConfig", function(stageInfoConfig){
				//update this.model
				this.model.set("stageInfoConfig", stageInfoConfig);
				
				this.model.save({}, {
					success: function(results){
						app.trigger("modelSaveOrDestroy");
						app.trigger("alert:changeNotification", "admin alert-success", window.localize("generic.changesPushedToServer"), "#content-outlet");
					},
					error: function(){
						app.trigger("alert:error", {
							header : window.localize("generic.errorSavingConfig"),
							message : window.localize("generic.configSaveFailed")
						});
					},
					wait: false
				});
			});
		},
	    beforeRender: function() { 
	        var switcher = new Switcher.Views.Layout({config: this.model, configClass: this.options.configClass });
	        this.setView("#config-switcher-outlet", switcher);
	    },
		afterRender: function(){
			var that = this;
			if(this.viewModel){
					app.trigger("alert:error", {
						header: window.localize("generic.alert"),
						message: window.localize("modules.hpiAdmin.memoryLeak")
					});
					//ko.cleanNode(this.$el[0]);
					//kb.release(this.viewModel);
			}
			this.viewModel = new Stageconfig.ViewModel(this.model, this);
			this.viewModel.subConfig.subscribe(function(value){
					switch(value){
						case window.localize("stageConfig.stageConfigMainLayout.searchResults") :
							that.setView("#subConfigHolder", new SearchResultTraversalConfig.View(
							{ model: that.model.get("searchResultTraversalConfig"), tracName : that.model.get("name") }    
							)).render();
							break;  
						case window.localize("stageConfig.stageConfigMainLayout.stageInfo") :
							that.setView("#subConfigHolder", new Stageinfoconfig.Views.StageInfoConfig(
							{ model: that.model.get("stageInfoConfig"), tracName : that.model.get("name") }    
							)).render();
							break; 
						case window.localize("stageConfig.stageConfigMainLayout.workflowInfo") :
							that.setView("#subConfigHolder", new WorkflowInfoConfig.Views.Layout(
							{ model: that.model.get("workflowInfoConfig"), tracName : that.model.get("name") }    
							)).render();
							break; 	 
						case window.localize("stageConfig.stageConfigMainLayout.relatedObject") :
							that.setView("#subConfigHolder", new Relatedobjectsconfig.View(
							{ model: that.model.get("relatedObjectsConfig"), tracName : that.model.get("name") }
							)).render();
							break;
						case window.localize("stageConfig.stageConfigMainLayout.docViewer") :
							that.setView("#subConfigHolder", new Docviewerconfig.Views.Layout(
							{ model: that.model, tracName : that.model.get("name")}
							)).render();
							break;
						case window.localize("stageConfig.stageConfigMainLayout.folderActions") :
							that.setView("#subConfigHolder", new Folderactionconfig.Views.Layout(
							{ model: that.model.get("folderActionConfig"), tracName : that.model.get("name")}
							)).render();
							break;
					}
			});
			
			kb.applyBindings(this.viewModel, this.$el[0]);
		}
	
	});


 
		
	// Return the module for AMD compliance.
	return Stageconfig;

});
