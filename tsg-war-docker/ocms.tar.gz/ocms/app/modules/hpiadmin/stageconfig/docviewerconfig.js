define([
		// Application.
		"app",
		"knockout",
		"knockback",
		"modules/hpiadmin/hpiadmin",
		"modules/hpiadmin/actionconfig/hpiactionconfig",
		"modules/hpiadmin/oamodeselect",
		"modules/hpiadmin/common/iosswitch",
		"modules/hpiadmin/common/admindropdown",
		"modules/common/tossacross"
	],

	function(app, ko, kb, Hpiadmin, ActionConfig, OAModeSelect, iOSSwitch, AdminDropdown, TossAcross) {
		"use strict";

		var DocViewer = app.module();

		DocViewer.Model = Backbone.Model.extend({
			defaults: function() {
				return {
					"statusBarConfig": [],
					"observable": "activeDocument",
					"type": "docViewerConfig",
					"videojs": "true",
					"viewerjs": "true",
					"imageviewer": "true",
					"hideOpenFileBtn" : "true",
					"hidePrintBtn" : "true",
					"hideDownloadBtn": "true",
					"hideBookmarkBtn": "true",
					"hideDocumentPropertiesBtn": "true",
					"htmlviewer": "true",
					"legacyviewer": "true",
					"oaviewer": "true",
					"oaviewerMode": "false",
					"auditView" : false,
					"renditioningCheckPeriod": 10000,
					"attrToShow" : "",
					"propertiesToShow" : "",
					"selectedOTC" : "",
					"selectedPicklist" : "",
					"associationName" : ""
				};
			},
			initialize: function(options){
				if(options && options.actions){
					this.set("actions", new ActionConfig.Collection(options.actions));
				} else {
					this.set("actions", new ActionConfig.Collection());
				}
			}
		});

		DocViewer.ViewModel = kb.ViewModel.extend({
			constructor: function (model) {
				var self = this;

				self.noleftpane = kb.observable(model, "noleftpane");

				self.hideOpenFileBtn = kb.observable(model, "hideOpenFileBtn");
				self.hidePrintBtn = kb.observable(model, "hidePrintBtn");
				self.hideDownloadBtn = kb.observable(model, "hideDownloadBtn");
				self.hideBookmarkBtn = kb.observable(model, "hideBookmarkBtn");
				self.hideDocumentPropertiesBtn = kb.observable(model, "hideDocumentPropertiesBtn");
				self.renditioningCheckPeriod = kb.observable(model, "renditioningCheckPeriod");
				if(!self.renditioningCheckPeriod()) {
					self.renditioningCheckPeriod(10000);
				}

				self.viewerjs = kb.observable(model, "viewerjs");
				if(!self.viewerjs()) {
					self.viewerjs("true");
				}
				self.videojs = kb.observable(model, "videojs");
				if(!self.videojs()) {
					self.videojs("true");
				}
				self.vaviewer = kb.observable(model, "vaviewer");
				if(!self.vaviewer()) {
					self.vaviewer("true");
				}
				self.imageviewer = kb.observable(model, "imageviewer");
				if(!self.imageviewer()) {
					self.imageviewer("true");
				}
				self.htmlviewer = kb.observable(model, "htmlviewer");
				if(!self.htmlviewer()) {
					self.htmlviewer("true");
				}
				self.legacyviewer = kb.observable(model, "legacyviewer");
				if(!self.legacyviewer()) {
					self.legacyviewer("true");
				}
				self.oaviewer = kb.observable(model, "oaviewer");
				if(!self.oaviewer()) {
					self.oaviewer("true");
				}

				self.xmlviewer = kb.observable(model, "xmlviewer");
				if(!self.xmlviewer()) {
					self.xmlviewer("true");
				}

           	  	self.oaviewer.subscribe(function() {
			 	// Check if we need to show the mode select button.
             		model.set('oaviewer', self.oaviewer());
            	});

                self.oaviewerMode = ko.observable(model.get("oaviewerMode"));
          		self.oaviewerMode.subscribe(function() {
                	model.set('oaviewerMode', self.oaviewerMode());
            	});

				self.viewTimeRendition = kb.observable(model, "viewTimeRendition");
				if(!self.viewTimeRendition()) {
					self.viewTimeRendition("false");
				}

                self.externalLaunch = kb.observable(model, "externalLaunch");
                self.externalLaunchConfig = kb.observable(model, "externalLaunchConfig");
                self.externalLaunch.subscribe(function(value){
                    self.externalLaunchConfig(false);
                    if(value === "true" || value === true){
                        self.externalLaunchConfig(true);
                    }
                });
                if (!self.externalLaunch()) {
                    self.externalLaunch("true");
                }

				// The tooltip message that will show when hovering over the icon.
				self.externalLaunchMessage = kb.observable(model, "externalLaunchMessage");
				if(!self.externalLaunchMessage()){
					self.externalLaunchMessage(window.localize('stage.docviewer.launchNewWindow'));
				}

                self.launchDocViewerFromArrow = kb.observable(model, "launchDocViewerFromArrow");
                if (!self.launchDocViewerFromArrow()) {
                    self.launchDocViewerFromArrow("true");
				}
				
				self.launchPrintView = kb.observable(model, "launchPrintView");
                if (!self.launchPrintView()) {
                    self.launchPrintView("false");
				}

				self.auditView = kb.observable(model, "auditView");

				self.attrToShow = kb.observable(model, "attrToShow");

				
				self.enableDocumentInfo = kb.observable(model, "enableDocumentInfo");
				if(!self.enableDocumentInfo()) {
					self.enableDocumentInfo(false);
				}

				self.displayAttributes = kb.observable(model, "displayAttributes");
				if(!self.displayAttributes()) {
					self.displayAttributes(true);
				}

				self.enableAdditionalRestrictions = kb.observable(model, "enableAdditionalRestrictions");
				if(!self.enableAdditionalRestrictions()) {
					self.enableAdditionalRestrictions(false);
				}

				self.displayAssociations = kb.observable(model, "displayAssociations");
				if(!self.displayAssociations()) {
					self.displayAssociations(false);
				}
				
				self.propertiesToShow = kb.observable(model, "propertiesToShow");
				self.selectedOTC = kb.observable(model, "selectedOTC");
				self.selectedPicklist = kb.observable(model, "selectedPicklist");
				self.associationName = kb.observable(model, "associationName");
			}
		});

		// Default View
		DocViewer.Views.Layout = Backbone.Layout.extend({
			template: "hpiadmin/stageconfig/docviewerconfig",

			initialize: function(){
				var self = this;
				this.docViewerConfig = this.model.get("docViewerConfig");
				this.viewModel = new DocViewer.ViewModel(this.docViewerConfig, this.options);
				// Need the trac name on model
				this.viewModel.name = ko.observable(this.options.tracName);
				this.viewModel.availableAttributes = new Backbone.Collection();
				this.viewModel.selectedAttributes = new Backbone.Collection();
				this.ui = {};

				// Deferred object to get all oc types to create subviews when triggering document info views
				this.allOCTypes = [];
				this.fetchOCTypesAttributesDeferred = $.Deferred();
				app.context.configService.getAdminOTC(function(adminOTC){
					self.allOCTypes = adminOTC.get("configs").models;
					self.fetchOCTypesAttributesDeferred.resolve();
				});

				// Getting the current picklist config
				if (!app.context.currentPicklistConfig()) {
					app.context.configService.getPicklistServices();
				}

				this.getPreviousProperties();
				this.triggerDocumentInfoViews();
				this.startListening();
			},
			startListening: function() {
				// Need to add listeners for separate changes because if we do one overal change event listener, it'll rerender
				// the whole view each time an attribute is clicked on the toss across which we do not want
				this.listenTo(this.docViewerConfig, "change:enableDocumentInfo", this.triggerDocumentInfoViews);
				this.listenTo(this.docViewerConfig, "change:displayAttributes", this.triggerDocumentInfoViews);
				this.listenTo(this.docViewerConfig, "change:objectTypeDropdown", this.updateSelectedOTConfig);
				this.listenTo(this.docViewerConfig, "change:enableAdditionalRestrictions", this.triggerDocumentInfoViews);
				this.listenTo(this.docViewerConfig, "change:displayAssociations", this.render);
			},
			beforeRender: function() {
				var actionConfig = new ActionConfig.View({viewmodel: this.viewModel, model : this.model.get("docViewerConfig"), showGroupActions: false });
				var oaModeSlider = new OAModeSelect.SwitchView({viewModel: this.viewModel});

				this.documentInfoConfigView = new iOSSwitch.View({
					model: this.docViewerConfig,
					configModelKey: "enableDocumentInfo",
					switchTitle: window.localize("stageConfig.docViewerConfig.enableView")
				});
				
				// Need to rebuild toss across with each render to "save" any changes to the attribute columns
				this.buildAttributeTossAcross();

				this.setViews({
					"#action-config-template-outlet": actionConfig,
					"#oa-mode-select": oaModeSlider,
					"#documentInfoSwitch": this.documentInfoConfigView
				});
			},
			getPreviousProperties: function() {
				if (this.docViewerConfig.get("propertiesToShow")) {
					_.each(this.docViewerConfig.get("propertiesToShow"), function(attr) {
						// Need to check which exists to determine if using Backbone model or array
						var attributes = attr.attributes ? attr.attributes : attr;
						this.viewModel.selectedAttributes.add({
							'attrName': attributes.attrName,
							'attrValue': attributes.attrValue,
							'attrDataType': attributes.attrDataType,
							'attrFilter': attributes.attrFilter
						});
					}, this);
				} else {
					this.docViewerConfig.set("propertiesToShow", {});
				}
			},
			triggerDocumentInfoViews: function() {
				if (this.docViewerConfig.get("enableDocumentInfo")) {
					// Only create subviews when we've gotten all oc types
					this.fetchOCTypesAttributesDeferred.done(_.bind(function(){
						this.createSubViews();

						// Need to call render because deferred is asynchronous
						this.render();
					}, this));
				} else {
					this.render();
				}
			},
			triggerDisplayAttributesView: function() {
				if (this.docViewerConfig.get("displayAttributes")) {

					this.otConfig = [];

					_.each(this.allOCTypes, function(model) {
						this.otConfig.push({
							'displayValue': model.get("label"),
							'value': model.get("ocName")
						});
					}, this);
					
					this.objectTypeDropdownConfigView = new AdminDropdown.View({
						model: this.docViewerConfig,
						configModelKey: "objectTypeDropdown",
						title: window.localize("stageConfig.docViewerConfig.objectType"),
						optionObjects: this.otConfig
					});

					this.setView("#objectTypeDropdown", this.objectTypeDropdownConfigView);

					var selectedOption = this.docViewerConfig.get("objectTypeDropdown");

					// Set the selected option as the first option for the first time otc dropdown is opened and nothing is previously selected
					if (_.isUndefined(selectedOption)) {
						this.objectTypeDropdownConfigView.optionObjects[0].selected = true;
						selectedOption = this.objectTypeDropdownConfigView.optionObjects[0].value;
					}

					this.docViewerConfig.set("selectedOTC", selectedOption);
				}
			},
			triggerAdditionalRestrictionsView: function() {
				if (this.docViewerConfig.get("enableAdditionalRestrictions")) {
					this.availablePicklists = [];

					_.each(app.context.currentPicklistConfig().get('picklists').models, _.bind(function(picklist){
						this.availablePicklists.push({
							displayValue: picklist.get('label'),
							value: picklist.get('label')
						});
					}, this));

					this.columnPairsPicklistSelector = new AdminDropdown.View({
						model: this.docViewerConfig,
						configModelKey: 'columnPicklist',
						title: window.localize('stageConfig.docViewerConfig.selectAPicklist'),
						showDescription: true,
						optionObjects: this.availablePicklists
					});

					this.setView("#columnPicklist", this.columnPairsPicklistSelector);

					this.docViewerConfig.set("selectedPicklist", this.docViewerConfig.get("columnPicklist"));
				}
			},
			createSubViews: function() {
				this.displayAttributesConfigView = new iOSSwitch.View({
					model: this.docViewerConfig,
					configModelKey: "displayAttributes",
					switchTitle: window.localize("stageConfig.docViewerConfig.displayAttributes"),
					configDescription: window.localize("stageConfig.docViewerConfig.displayAttributes.description")
				});

				this.triggerDisplayAttributesView();

				this.additionalRestrictionsConfigView = new iOSSwitch.View({
					model: this.docViewerConfig,
					configModelKey: "enableAdditionalRestrictions",
					switchTitle: window.localize("stageConfig.docViewerConfig.additionalRestrictions"),
					configDescription: window.localize("stageConfig.docViewerConfig.additionalRestrictions.description")
				});

				this.triggerAdditionalRestrictionsView();

				this.displayAssociationsConfigView = new iOSSwitch.View({
					model: this.docViewerConfig,
					configModelKey: "displayAssociations",
					switchTitle: window.localize("stageConfig.docViewerConfig.displayAssociations"),
					configDescription: window.localize("stageConfig.docViewerConfig.displayAssociations.description")
				});

				this.setViews({
					"#displayAttributesSwitch": this.displayAttributesConfigView,
					"#additionalRestrictionsSwitch": this.additionalRestrictionsConfigView,
					"#displayAssociationsSwitch": this.displayAssociationsConfigView
				});
			},
			updateSelectedOTConfig: function() {
				this.docViewerConfig.set("selectedOTC", this.docViewerConfig.get("objectTypeDropdown"));
				this.viewModel.availableAttributes.reset();
				this.viewModel.selectedAttributes.reset();
				this.render();
			},
			populateAvailableAttributes: function(){
				var self = this;
				this.viewModel.availableAttributes.reset();

				var selectedOption = this.docViewerConfig.get("selectedOTC");
			
				if (selectedOption){
					//Getting all potential attributes from the OTC
					app.context.configService.getAdminTypeConfig(selectedOption, function(typeConfig){
						_.each(typeConfig.get("attrs").models, function(attr) {
							if ( !_.contains(_.pluck(self.docViewerConfig.get("propertiesToShow"), 'attrValue'), attr.get("ocName")) ) {
								self.viewModel.availableAttributes.push({
									'attrName': attr.get("label"),
									'attrValue': attr.get("ocName"),
									'attrDataType': attr.get("dataType"),
									'attrFilter': attr.get("filter")
								});
							}
						});
					});
				}
			},
			populateSelectedAttributes: function() {
				var self = this;
				var newObjectProps = [];
				_.each(self.viewModel.selectedAttributes.models, function(model){
					// Need to check which exists to determine if using Backbone model or array
					if (model.attrName){
						newObjectProps.push({attrName: model.attrName, attrValue: model.attrValue, attrDataType: model.attrDataType, attrFilter: model.attrFilter});
					} else if (model.get('attrName')) {
						newObjectProps.push({attrName: model.get('attrName'), attrValue: model.get('attrValue'), attrDataType: model.get('attrDataType'), attrFilter: model.get('attrFilter')});
					}
				});
				this.docViewerConfig.set("propertiesToShow", _.extend([], newObjectProps));
			},
			buildAttributeTossAcross: function(){
				this.stopListening(this.viewModel.selectedAttributes, 'add remove reset');
				this.listenTo(this.viewModel.selectedAttributes, 'add remove reset', this.populateSelectedAttributes);
				this.populateAvailableAttributes();
				var tossAcross = new TossAcross.Layout({
					srcCollection: {
						title: window.localize("modules.common.tossAcross.availableAttributes"),
						filter: true,
						labelAttr: 'attrName',
						collection: this.viewModel.availableAttributes
					},
					targetCollections: [
						{
							title: window.localize("modules.common.tossAcross.selectedAttributes"),
							labelAttr: 'attrName',
							collection: this.viewModel.selectedAttributes
						}
					]
				});

				this.setView("#attributesTossAcross", tossAcross);
			},
			afterRender: function() {
				kb.applyBindings(this.viewModel, this.$el[0]);
				
				this.ui.tooltip = this.$(".oa-mode-select-tooltip");
          		//add popover to icon for glyphicons
          		this.ui.tooltip.popover({
            	    placement: 'right',
            	    trigger: 'hover',
                	title: window.localize("stageConfig.docViewerConfig.oaModeSelect.title"),
        	        html : true,
            	    content: "<p>"+window.localize("stageConfig.docViewerConfig.oaModeSelect.info")+ "<ul><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.annotationMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.redactMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.signatureMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.openViewerMode") + "</li> <li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.indexerMode") + "</li></ul></p>",
                	delay: {show: 500}
            	});

			},
			serialize: function() {
				return {
					enableDocumentInfo: this.docViewerConfig.get("enableDocumentInfo") === true,
					displayAttributes: this.docViewerConfig.get("displayAttributes") === true,
					enableAdditionalRestrictions: this.docViewerConfig.get("enableAdditionalRestrictions") === true,
					displayAssociations: this.docViewerConfig.get("displayAssociations") === true
				};
			}
		});

		return DocViewer;
    });