define([
	"app",
	"modules/hpiadmin/hpiadmin",
	"modules/common/tossacross"
],
function(app, Hpiadmin, TossAcross) {

	var StageInfoConfig = app.module();

	StageInfoConfig.StageInfoConfigVent = _.extend({}, Backbone.Events);

	StageInfoConfig.Model = Backbone.Model.extend({
		type: "StageInfo",
		defaults: function() {
			return {
				label: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.defaultLabel"),
				observable: "container",
				visibleProperties: [],
				webProperties: {}
			};
		}
	});

	StageInfoConfig.Views.StageInfoConfig = Backbone.Layout.extend({
		template: "hpiadmin/stageconfig/stageinfoconfig",

		className: "stageInfoConfig",

		events: {
			"change #types-select": "addType",
			"change #observable-select": "webServiceView",
			"click #configuredtypes-list .glyphicon-edit": "editType",
			"click #configuredtypes-list .glyphicon-remove-circle": "removeType",
			"click #webServicePathBtn": "updateConfigPath",
			"keyup #stageinfoconfig-header-input" : "updateLabel"
		},

		initialize: function() {
			var that = this;

			this.observableOptions = [{
				label: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.folder"),
				value: "container",
				selected: false
			}, {
				label: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.document"),
				value: "activeDocument",
				selected: false
			}, {
				label: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.webService"),
				value: "webservice",
				selected: false
			}];

			this.types = [];

			app.context.configService.getAdminOTC(function(adminOTC) {
				//remove the ones that are already in the visible properties if there are any
				that.types = [];
				that.tempTypes = _.map(adminOTC.get("configs").models, function(type){
                    return {"ocName" : type.get("ocName"), "label" : type.get("label")};
                });
                //Take out any visible properties from non-configured types
				if (that.model.get("visibleProperties").length > 0) {
                    var tempOcList = _.difference(adminOTC.get("configs").pluck("ocName"),
                            _.pluck(that.model.get("visibleProperties"), "objectType"));

                    that.tempTypes = _.filter(adminOTC.get("configs").models,function(model){
                        return tempOcList.indexOf(model.get("ocName")) !== -1;
                    });
	                
	                that.types = _.map(that.tempTypes, function(type){
	                    return {"ocName" : type.get("ocName"), "label" : type.get("label")};
	                });
            	} else {
            		that.types = that.tempTypes;
            	}
                //return just ocName and label
                
                //check for legacy configs (only have object type and no label)
                _.each(that.model.get("visibleProperties"), function(object){
                	if(!object.label){
                		object.label = adminOTC.get("configs").where({ocName: object.objectType})[0].get("label");
                	}
                });

				that.render();
			});

			this.listenTo(StageInfoConfig.StageInfoConfigVent, 'updateVisibleProperties', function(objectType, label, attrs, pattern){
				that.updateVisibleProperties(objectType, label, attrs, pattern);
			});
		},
		updateVisibleProperties: function(objectType, label, attrs, pattern){
			var currentObjectType = _.findWhere(this.model.get("visibleProperties"), { 'objectType': objectType , 'label':label });
			var correctAttrs = attrs;
			if(attrs && attrs.length > 0 && attrs[0] instanceof Backbone.Model){
				// Plucking twice because attrs is an array of backbone models.
				correctAttrs = _.pluck(_.pluck(attrs, "attributes"), "attrName");
			}
			currentObjectType.attrs = _.extend([], correctAttrs);
			currentObjectType.tabTitlePattern = pattern;
		},
		//alter display to show only elements related to observableOption selected
		webServiceView: function(event){
			//configure for folder/document vs. webservice
			var that = this;
			
			//hide/show sections as observableOptions changes: 
			$(event.target).find("option:selected").each(function() {
				var typeName = $(this).val();
				
				//Making sure that what is selected on the dropdown is persisted.
				that.model.set('observable', _.findWhere(that.observableOptions, {'value' : typeName}).value);
				
				if (typeName === "webservice") {
					$("#types-select-header").hide();
					$("#types-select").hide();
					$("#configuredtypes-header").hide();
					$("#webservices-url").show();
					//set if webservice is selected and not already configured
					var isWebServiceSet = that.model.get('webProperties').objectType;
					if (!isWebServiceSet) {
						that.model.set('webProperties', {
							"objectType": typeName,
							"properties": {
								"webServiceUrl": $("#url-textbox")
							}
						});
					}
				}
				//If Folder or Document
				else {
					$("#types-select-header").show();
					$("#types-select").show();
					$("#configuredtypes-header").show();
					$("#webservices-url").hide();
					that.model.set('webProperties', {});
				}
			});
		},

		addType: function(event) {
			var self = this;
			$(event.target).find("option:selected").each(function() {
				var typeName = $(this).val();
				var label = $(this).context.label;
				self.model.get("visibleProperties").push({
					"objectType": typeName,
					"label": label,
					"attrs": [],
					"tabTitlePattern":""
				});

				self.tempTypes = _.reject(self.types, function(type) {
					return type.ocName === typeName;
				});

				self.types = self.tempTypes;

				self.editType("dummy", typeName, label);
			});
		},

		editType: function(event, typeName, label) {
			var that = this;
			this.currentTypeName = typeName ? typeName : 
					event.target.parentElement.id.split("-")[1];

			app.context.configService.getAdminTypeConfig(this.currentTypeName, function(typeConfig) {
				that.currentLabelName = typeConfig.get("label");

				that.currentTypeAttrs = _.find(that.model.get("visibleProperties"), function(type) {
					return that.currentTypeName === type.objectType;
				}).attrs;

				that.currentTypeObj = _.findWhere(that.model.get("visibleProperties"), {objectType: that.currentTypeName});
				
				that.setViews({
					"#currenttypeattrs": new StageInfoConfig.Views.CurrentTypeConfig({
							allAttrs: typeConfig.get("attrs").models,
							currentLabelName: that.currentLabelName,
							currentTypeAttrs: that.currentTypeAttrs,
							currentTypeName: that.currentTypeName,
							currentTypeObj: that.currentTypeObj
						})
				}).render();
			});
		},

		removeType: function(event) {
			var typeName = event.target.parentElement.id.split("-")[1];
			var that = this;
			_.each(this.model.get("visibleProperties"), function(type) {
				if(type.objectType === typeName) {
					var tempType = {ocName: type.objectType, label: type.label};
					that.types.push(tempType);
				}
			});

			this.model.set("visibleProperties", _.reject(this.model.get("visibleProperties"),
				function(type) {
					return typeName === type.objectType;
				})
			);

			if (this.currentTypeName === typeName) {
				this.removeView("#currenttypeattrs");
			}

			this.render();
		},

		updateConfigPath: function(){
			//specify absolute path to endpoint to retrieve json from
			var newRootPath = $("#url-textbox").val();
            //set new endpoint path
            if(this.model.attributes.webProperties.properties.webServiceUrl){
				this.model.attributes.webProperties.properties.webServiceUrl = newRootPath;
			}
			else if (this.model.webProperties.properties.webServiceUrl){
				this.model.webProperties.properties.webServiceUrl = newRootPath;
			}
            app.trigger("alert:changeNotification","alert-success",
            	window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.yourConfigPath") + newRootPath +window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.pleaseClear") ,
           		"#configPathSuccessMsg");
		},

		updateLabel: function(){
			this.model.attributes.label = $("#stageinfoconfig-header-input").val();
		},

		beforeRender: function() {
			var that = this;

			_.each(this.observableOptions, function(option) {
				//to ensure that two options are not selected at once
				option.selected = false;
			});

			_.each(this.observableOptions, function(option) {
				//set render for value currently in observableOptions dropdown
				if (option.value === $("#observable-select").val()){
					option.selected = true;
				}
				//this is for the initial beforeRender
				else if(!$("#observable-select").val()){
					//render based on saved config value
					if (option.value === that.model.get("observable")) {
						option.selected = true;
					}
				}
			});
		},

		serialize: function() {
			return {
				stageInfoConfig: this.model.attributes,
				observableOptions: this.observableOptions,
				types: this.types
			};
		}, 

		afterRender: function() {
			//initially show display for saved observableOption
			for (var i = 0; i < this.observableOptions.length; i++){
				if (this.observableOptions[i].value === "webservice" && this.observableOptions[i].selected){
					$("#types-select-header").hide();
					$("#types-select").hide();
					$("#configuredtypes-header").hide();
					$("#webservices-url").show();
				}
				else if (this.observableOptions[i].selected) {
					$("#types-select-header").show();
					$("#types-select").show();
					$("#configuredtypes-header").show();
					$("#webservices-url").hide();
				}
			}
			self.$('[data-toggle="tooltip"]').tooltip();
		}
	});

	StageInfoConfig.Views.CurrentTypeConfig = Backbone.Layout.extend({
		template: "hpiadmin/stageconfig/currenttypeattrs",
		events: {
			"click #tabTitleAttrs-button": "updateTabTitlePattern",
			"change #tabTitlePattern": "savePattern",
			"click .stageInfoConfig glyphicon.glyphicon-plus" : "addAttr",
			"click .stageInfoConfig glyphicon.glyphicon-minus" : "removeAttr",
			"updateOtherArray": "updateOtherArray",
			"updateSameArray": "updateSameArray"
		},
		initialize: function() {
			var self = this;
			this.allAttrsCollection = this.options.allAttrs;
			this.currentTypeName = this.options.currentTypeName;
			this.currentLabelName = this.options.currentLabelName;
			this.tabTitlePattern = this.options.currentTypeObj.tabTitlePattern ? this.options.currentTypeObj.tabTitlePattern : "";
			this.configuredAttrsCollection = new Backbone.Collection();

			var deferreds = [];

			_.each(this.options.currentTypeAttrs, function(attrName){
				
				var tempObj = {};
				// Legacy (no label)
				if(!(attrName instanceof Object)){
					deferreds.push(self.addLegacyAttr(attrName));
				} 
				else{
					if(attrName.attrName) {
						tempObj = {'attrName':attrName.attrName,
								   'attrLabel':attrName.attrLabel};
					} else {
						tempObj = {'attrName':attrName.get('attrName'),
								   'attrLabel':attrName.get('attrLabel')};
					}
					self.configuredAttrsCollection.add(tempObj);
					// If we don't need to fetch the labels add a resolved deferred to the deferred array.
					var deferred = $.Deferred();
					deferreds.push(deferred);
					deferred.resolve();
				}
			});

			$.when.apply($, deferreds).done(function() {
				self.unconfiguredAttrsCollection = new Backbone.Collection();
				var unconfiguredAttrs = _.reject(self.allAttrsCollection, function(attr) {
					return _.contains(self.options.currentTypeAttrs, attr.get("ocName"));
				});
				_.each(unconfiguredAttrs, function(attr){
					self.unconfiguredAttrsCollection.add({
						'attrName' : attr.get("ocName"),
						'attrLabel': attr.get("label")
					});
				});
					

				self.listenTo(self.configuredAttrsCollection, 'add remove reset', function(event){
					self.options.currentTypeAttrs = self.configuredAttrsCollection.models;
					StageInfoConfig.StageInfoConfigVent.trigger('updateVisibleProperties', self.currentTypeName, self.currentLabelName, self.options.currentTypeAttrs, self.tabTitlePattern);
				});

				self.typesTossAcross = new TossAcross.Layout({
					srcCollection: {
						title: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.attrNotIn") + self.currentLabelName,
						filter: true,
						labelAttr: 'attrLabel',
						valueAttr: 'attrName',
						collection: self.unconfiguredAttrsCollection
					},
					targetCollections: [
						{
							title: window.localize("modules.hpiAdmin.stageConfig.stageInfoConfig.attrsInStage") + self.currentLabelName,
							labelAttr: 'attrLabel',
							valueAttr: 'attrName',
							collection: self.configuredAttrsCollection
						}
					]
				});
			});
		},
		beforeRender: function() {
			this.unconfiguredAttrsCollection = _.difference(this.allAttrs, this.currentTypeAttrs);
			this.setView(".toss-across-clearfix", this.typesTossAcross);
		},
		addLegacyAttr: function(attrName){
			var self = this;

			var deferred = $.Deferred();

			app.context.configService.getLabels(this.currentTypeName, attrName).done(function(attrLabel) {
				var tempObj = {'attrName':attrName,
						   'attrLabel':attrLabel};
				self.configuredAttrsCollection.add(tempObj);
				deferred.resolve();
			});

			return deferred;
		},
		addAttr: function(event){
			app.trigger("StageInfoConfig:addAttr", 
					this.currentTypeName, event.target.parentElement.id);
		},
		removeAttr: function(event){
			app.trigger("StageInfoConfig:removeAttr", 
					this.currentTypeName, event.target.parentElement.id);
		},
		updateOtherArray: function(event, index, value, targetList) {
			if (targetList === "configuredtypeattrs") {
				app.trigger("StageInfoConfig:sortAttr", this.currentTypeName, value, index);
			} else {
				app.trigger("StageInfoConfig:removeAttr", this.currentTypeName, value);
			}
		},
		updateSameArray: function(event, index, value, targetList) {
			if (targetList === "configuredtypeattrs") {
				app.trigger("StageInfoConfig:sortAttr", this.currentTypeName, value, index);
			}
		},
		updateTabTitlePattern: function(event) {
			var that = this;

			this.tabTitlePattern += "$" + 
				that.$("#tabTitleAttrs").find(":selected").val() + "$";
			
			StageInfoConfig.StageInfoConfigVent.trigger("updateVisibleProperties", 
														this.currentTypeName, 
														this.currentLabelName, 
														this.currentTypeAttrs, 
														this.tabTitlePattern);
		
			this.render();

			// make sure we dont bubble up to the parent view or it will re-render this whole thing.
			event.stopPropagation();
		},

		savePattern: function(event){
			this.tabTitlePattern = event.srcElement.value;
			StageInfoConfig.StageInfoConfigVent.trigger("updateVisibleProperties", this.currentTypeName, this.currentLabelName, this.currentTypeAttrs, event.srcElement.value);
		},
		
		serialize: function() {
			var stageInfoProps = [];
			_.each(this.allAttrsCollection, function(attrObj){
				stageInfoProps.push(attrObj.toJSON());
			})
			return {
				unconfiguredAttrs: this.unconfiguredAttrs,
				currentTypeAttrs: this.currentTypeAttrs,
				currentTypeName: this.currentTypeName,
				currentLabelName: this.currentLabelName,
				tabTitlePattern: this.tabTitlePattern,
				stageInfoProps: stageInfoProps
				
			};
		},
		afterRender : function() {
			//make the attribute boxes sortable
			this.$(".sortable-attributes").sortable({
				connectWith: ".sortable-attributes",
				receive: function(event, ui){
					ui.item.trigger("updateOtherArray", [ui.item.index(), ui.item[0].textContent,
							ui.item.parent()[0].id.split("-")[0]]);
				},
				stop: function(event, ui) {
					if(this === ui.item.parent()[0]){
						ui.item.trigger("updateSameArray", [ui.item.index(), ui.item[0].textContent,
								ui.item.parent()[0].id.split("-")[0]]);
					}
				}
			});
		}
	});
	
	// Return the module for AMD compliance.
	return StageInfoConfig;

});