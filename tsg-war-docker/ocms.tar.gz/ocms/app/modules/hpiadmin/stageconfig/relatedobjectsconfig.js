define([
	"app",
	"modules/hpiadmin/stageconfig/relationtype"
],
function(app, Relationtype) {

	// Create a new module.
	var Relatedobjectsconfig = app.module();

	Relatedobjectsconfig.Model = Backbone.Model.extend({
		defaults : function() {
			return {
				"type": "Relatedobjectsconfig"
			};
		},
		initialize: function(options){
			if(options && options.relationTypes){
				if(options.relationTypes instanceof Backbone.Collection){
					this.set("relationTypes", options.relationTypes);
				} else {
					this.set("relationTypes", new Relationtype.Collection(options.relationTypes));
				}
			} else {
				this.set("relationTypes", new Relationtype.Collection());
			}
		}
	});

	var EditRelationConfigViewModel = Relatedobjectsconfig.EditRelationConfigViewModel = function(editRelationConfigModel, thisTracName, potentialRelationConfigChildTypes, availableTracs) {
		var self = this;

		/**********************************************************
		********************** RELATION INFORMATION ***************
		**********************************************************/
		// the label of the relation
		self.relationConfigLabel = kb.observable(editRelationConfigModel, "label");
		// the selected child type - not editable
		self.relationConfigChildType = editRelationConfigModel.get("childType");
		// the selected relation config type (Query, Relation, Folder Tags) - not editable
		self.relationConfigType = editRelationConfigModel.get("relationConfigType");
		// used to display a human readable form of the relationConfigType
		self.displayRelationConfigType = "";
		if(self.relationConfigType === 'queryBasedTemplate') {
			self.displayRelationConfigType = 'Query Based';
		} else if(self.relationConfigType === 'relationBasedTemplate') {
			self.displayRelationConfigType = 'Relation Based';
		} else if(self.relationConfigType === 'folderTagsTemplate') {
			self.displayRelationConfigType = 'Folder Tags';
		} else if(self.relationConfigType === 'externalRelationTemplate') {
			self.displayRelationConfigType = 'External Relation';
		}

		/**********************************************************
		********************** RELATION CONFIGURATION *************
		**********************************************************/
		self.criteria = kb.observable(editRelationConfigModel, "criteria");
		self.relationDirection = kb.observable(editRelationConfigModel, "relationDirection");
		self.relationName = kb.observable(editRelationConfigModel, "relationName");
		self.parameterLogic = kb.observable(editRelationConfigModel, "parameterLogic");
		self.externalRelationEndpoint = kb.observable(editRelationConfigModel, "externalRelationEndpoint");
		self.externalRelationUrl = ko.computed(function() {
			var endpoint = self.externalRelationEndpoint() ? self.externalRelationEndpoint() : "";
			return app.serviceUrlRoot + "/" + endpoint;
		});

		self.allAttrs = ko.observableArray([]);

		self.addCriteria = function() {
			var array = editRelationConfigModel.get("criteria").splice(0);
			array.push({attribute: "", operator:"", type:"", value:"", termLogic:""});
			self.criteria(array);
		};

		self.removeCriteria = function(criteriaToRemove) {        
			self.criteria(_.without(self.criteria(), criteriaToRemove));
		};

		self.addAdditionalDisplayAttr = function() {
			self.additionalDisplayAttrs.push({
				prefixText: "",
				propertyName: ""
			});
		};
		self.removeAdditionalDisplayAttr = function() {
			self.additionalDisplayAttrs.pop();
		};




		/**********************************************************
		************ RESULTS DISPLAY AND SORT OPTIONS *************
		**********************************************************/
		// number of results to display
		self.optionsDisplaySize = kb.observable(editRelationConfigModel, "optionsDisplaySize");
		// attribute to display for each result (clickable)
		self.displayAttr = kb.observable(editRelationConfigModel, "displayAttr");
		// the attribute to sort results by
		self.sortAttr = kb.observable(editRelationConfigModel, "sortAttr");
		// sort order - ascending or descending
		self.sortOrder = kb.observable(editRelationConfigModel, "sortOrder");
		// Additional attributes to display for each result
		self.additionalDisplayAttrs = ko.observableArray(editRelationConfigModel.get("additionalDisplayAttrs") || []);
		self.additionalDisplayAttrs.subscribe(function(newAttrs) {
			editRelationConfigModel.set("additionalDisplayAttrs", newAttrs);
		});


		/**********************************************************
		********************** LINK RESOLVER **********************
		**********************************************************/
		// setting the resolver to use - Stage, Wizard, Detailview
		self.resolver = kb.observable(editRelationConfigModel, "resolver");
		// setting the resolver trac to use
		self.resolverTrac = kb.observable(editRelationConfigModel, "resolverTrac");
		// the list of available tracs to choose from
		self.availableTracs = availableTracs;

		if(!_.contains(self.availableTracs(), self.resolverTrac())) {
			app.log.warn(window.localize("modules.hpiAdmin.stageConfig.relatedObjectsConfig.trac") + self.resolverTrac() + window.localize("modules.hpiAdmin.stageConfig.relatedObjectsConfig.wasNot"));
			self.resolverTrac("Do not Switch Tracs");
		}


		/**********************************************************
		********************** INFO BLOCK *************************
		**********************************************************/
		self.optionsShowInfoBlock = kb.observable(editRelationConfigModel, "optionsShowInfoBlock");
		self.infoBlockAttrs = ko.observableArray(editRelationConfigModel.get("infoBlock") || []);
		self.infoBlockAttrs.subscribe(function(newInfoBlockAttrs) {
			editRelationConfigModel.set("infoBlock", newInfoBlockAttrs);
		});
		self.availableInfoBlockAttrs = ko.observableArray([]);


		/**********************************************************
		********************** ADDITIONAL OPTIONS *****************
		**********************************************************/
		self.optionsAutoExpand = kb.observable(editRelationConfigModel, "optionsDefaultOpen" );
		self.optionsShowAnnotations = kb.observable(editRelationConfigModel, "optionsShowAnnotations" );
		self.optionsShowMimeIcon = kb.observable(editRelationConfigModel, "optionsShowMimeIcon");
		self.optionsShowDualScreen = kb.observable(editRelationConfigModel, "optionsShowDualScreen");
		self.optionsShowExternalLaunch = kb.observable(editRelationConfigModel, "optionsShowExternalLaunch");
		self.optionsShowExportDoc = kb.observable(editRelationConfigModel, "optionsShowExportDoc");
		self.optionsHideEmptyRelations = kb.observable(editRelationConfigModel, "optionsHideEmptyRelations");
		self.optionsExpandWithTags = kb.observable(editRelationConfigModel, "optionsExpandWithTags");


		// loop over the potential configs to find the one that is our expected child type
		_.each(potentialRelationConfigChildTypes(), function(relationConfigChildType) {
			if(relationConfigChildType.get("ocName") === self.relationConfigChildType) {
				var attrsByOcName = relationConfigChildType.get("attrs").pluck("ocName");
				var attrsByLabel = relationConfigChildType.get("attrs").pluck("label");
				
				//This is for the 'RESULTS DISPLAY AND SORT OPTIONS'
				var attrMap = [];
				for(var i = 0; i < attrsByOcName.length; i++){
					attrMap.push({
					     'valueAttr' : attrsByOcName[i],
					     'displayAttr' : attrsByLabel[i]
					});
				}
				
				self.allAttrs(attrMap);
				
				//This is for the "INFO BLOCK OPTIONS"
				var filteredAttrs = [];
				for(var j = 0; j < attrsByOcName.length; j++){
					filteredAttrs.push({
					     'text' : attrsByLabel[j],
					     'value' : attrsByOcName[j]
					});
				}
				_.each(self.infoBlockAttrs(), function(obj){
					//resetting the configs if they are old
					if(typeof obj !== "object"){
						self.infoBlockAttrs.remove(obj);
					} else{
						filteredAttrs = _.without(filteredAttrs, _.findWhere(filteredAttrs, {'value' : obj.value}));	
					}
				});				
				self.availableInfoBlockAttrs(filteredAttrs);	
			}
		});
	};

	Relatedobjectsconfig.RelatedobjectsconfigViewModel = function(model, thisTracName) {
		var self = this;

		// the label of the new relation config
		self.relationConfigLabel = ko.observable();
		// the config type of the new relation config (Query Based, Relation Based, Folder Tags)
		self.relationConfigType = ko.observable();
		// the expected child type of the new relation config
		self.relationConfigChildType = ko.observable();
		
		// a marker for whether or not the user needs to enter a relation label before they can create the relation
		self.showNeedLabelError = ko.observable(false);

		// array for all the available tracs as well as a no trac resolving option and a Trac Resolver
		// this does not change based on object type so calculate it here
		var tracResolver = "Trac Resolver";
		var noTracResolving = "Do not Switch Tracs";
		self.availableTracs = ko.observableArray([noTracResolving,tracResolver]);

		// an array of types the user can choose as the expected child type of a new relation config
		self.potentialRelationConfigChildTypes = ko.observableArray([]);
		// populate the list of types the user can choose as the expected child type of a new relation config
		app.context.configService.getAdminOTC(function(otc) {
			otc.get("configs").each(function(config) {
				// fetch the deep config so we can get the attrs for the types
				app.context.configService.getAdminTypeConfig(config.get("ocName"), function(typeConfig) {
					self.potentialRelationConfigChildTypes.push(typeConfig);
				});
			});
		});

		// the collection of already existing relation configs
		self.existingRelationConfigs = kb.collectionObservable(model.get("relationTypes"));

		self.editRelationConfigViewModel = ko.observable(undefined);

		// adds a new relation config 
		this.addRelationConfig = function() {
			self.showNeedLabelError(false);
			// need to have a label defined for the relation
			if(self.relationConfigLabel() === "") {
				self.showNeedLabelError(true);
			} else {
				// create a new relation type model with the values entered by the user
				var relationConfigToAdd = new Relationtype.Model({
					label: self.relationConfigLabel(),
					relationConfigType: self.relationConfigType(),
					childType: self.relationConfigChildType()
				});
				// If the label is the same, remove that object and re-add, essentially updating the object.
				model.get("relationTypes").remove(model.get("relationTypes").where({ label: self.relationConfigLabel() }));
				// add our new relation to the list of configured relations on our model
				model.get("relationTypes").add(relationConfigToAdd);
				// clear out the relation config label on the "New Relation" section
				self.relationConfigLabel("");
			}
		};

		// removes a relation config
		this.removeRelationConfig = function(removeRelationConfig) {
			// remove the relation config from the list of exisiting relation configs
			self.existingRelationConfigs(_.without(self.existingRelationConfigs(), removeRelationConfig));

			// if the relation config to delete is currently in the edit relation view, remove it from that view
			if(self.editRelationConfigViewModel() && self.editRelationConfigViewModel().relationConfigLabel() === removeRelationConfig.model().get("label")) {
				self.editRelationConfigViewModel(undefined);	
			}
		};

		// sets a relation config to be edited, causing the editRelationViewModel computed to be triggered
		this.editRelationConfig = function(editRelationConfig) {
			// want a deferred so we don't create the edit view model until the tracs are done fetching
			var doneFetchingTracs = $.Deferred();
			if(self.availableTracs().length === 2) {
				// fetch the available tracs based on which stage configs there are
				app.context.configService.getTracConfigs(function(allConfigs) {
					// we want all tracs except the one they're currently on in the admin
					self.availableTracs(_.union(self.availableTracs(), _.without(allConfigs.pluck("name"), thisTracName)));
					doneFetchingTracs.resolve();		
				}, function() {}, true);
			} else {
				// already fetched the tracs once, don't need to do it again
				doneFetchingTracs.resolve();
			}

			// Handle legacy relation configs that don't have the termLogic
			_.each(editRelationConfig.model().get("criteria") , function(individualQueryCriteria) {
				if (!individualQueryCriteria.termLogic) {
					individualQueryCriteria.termLogic = "OR";
				}
			});

			// wait until the tracs are done fetching to pass them to the edit view model
			$.when(doneFetchingTracs).done(function() {
				self.editRelationConfigViewModel(new EditRelationConfigViewModel(editRelationConfig.model(), thisTracName, self.potentialRelationConfigChildTypes, self.availableTracs));
			});
		};
	};

	Relatedobjectsconfig.View = Backbone.Layout.extend({
		template: "hpiadmin/stageconfig/relatedobjectsconfig",

		initialize: function() {
			if (this.viewModel) {
				app.trigger("alert:error", {
					header: window.localize("generic.alert"),
					message: window.localize("modules.hpiAdmin.memoryLeak")
				});
			}

			this.viewModel = new Relatedobjectsconfig.RelatedobjectsconfigViewModel(this.model, this.options.tracName);
		},
		
		afterRender: function() {
			var self = this;

			kb.applyBindings(this.viewModel, this.$el[0]);

			self.$('[data-toggle="tooltip"]').tooltip();

			// this finds the expand icon for the heading and toggles its class to change it from plus to minux or vice versa
			this.$el.on('click', 'h3.accordion-toggle', function() {
				var siblingExpandButton = $(this).next();
				self.toggleExpandButton(siblingExpandButton);
			});

			// this toggles the expandOption clicked on to change its class from plus to minux or vice versa
			this.$el.on('click', '.expandOption', function() {
				self.toggleExpandButton($(this));
			});

			self.toggleExpandButton = function(expandOption) {
				// store if the clicked on button was expanded previously
				var wasExpanded = expandOption.hasClass("icon-minus-sign");

				// make all the expand buttons "closed"
				$(".expandOption").removeClass("icon-minus-sign").addClass("icon-plus-sign");

				// toggle the class for the clicked on expand button
				if(wasExpanded) {
					expandOption.removeClass("icon-minus-sign").addClass("icon-plus-sign");
				} else {
					expandOption.addClass("icon-minus-sign").removeClass("icon-plus-sign");
				}
			};
		}
	});

	// Return the module for AMD compliance.
	return Relatedobjectsconfig;

});
