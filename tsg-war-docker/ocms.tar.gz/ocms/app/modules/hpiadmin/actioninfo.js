define([
    "app",
    "module"
],
function(app) {
    "use strict";

    // Create a new module.
    var ActionInfo = app.module();

    ActionInfo.Views = {};

    ActionInfo.Views.Layout = Backbone.Layout.extend({
        template: "hpiadmin/actionandconditioninfo",
        initialize: function() {
            var self = this;

            var actionDeferred = $.Deferred();
            var conditionDeferred = $.Deferred();

            app.context.util.loadActionDefinitions().then(function(actionDefs) {
                self.sortedActionData = actionDefs;
                actionDeferred.resolve();
            });

            app.context.util.loadConditionDefinitions().then(function(conditionDefs) {
                self.sortedConditionData = conditionDefs;
                conditionDeferred.resolve();
            });

            $.when.apply($, [actionDeferred, conditionDeferred]).then(function() {
                self.render();
            });
        },
        afterRender: function() {
            this.rendered = true;
        },
        serialize: function() {
            return {
                actionData : this.sortedActionData,
                conditionData : this.sortedConditionData
            };
        }
    });

    return ActionInfo;

});