define([
        "app",
        "modules/common/spinner"
    ],
    function(app, HPISpinner) {

        var Switcher = app.module();

        Switcher.Views.NewConfig = Backbone.Layout.extend({
            template: "hpiadmin/newconfig",
            events: {
                "click #new-config-save": "saveConfig",
                "keyup #new-config-name": "setConfigName",
                "change #new-config-name": "setConfigName"
            },
            initialize: function(options) {
                this.configType = this.options.configType;
                this.config = new this.configType.Model();
                this.ui = {};
            },
            afterRender: function() {
                this.ui.configNameInput = this.$("#new-config-name");
                this.ui.savebutton = this.$("#new-config-save");
                this.validate();
            },
            serialize: function() {
                return {
                    "configName": this.config.get("type")
                };
            },
            setConfigName: function(e) {
                this.config.set("name", this.ui.configNameInput.val());
                this.validate();
            },
            saveConfig: function(e) {
                this.config.save({}, {
                    success: function(model, response, options) {
                        app.log.debug("Created Config");
                        app.trigger("alert:close");
                    Backbone.history.navigate("admin/" + model.get("type") + "/" + model.get("name"), {trigger: true} );
                    },
                    error: function(model, response, options) {
                        app.trigger("alert:close");
                        app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.hpiAdmin.hpiAdmin-Switcher.failedTo"), ".config-container");
                    }
                });
            },
            validate: function() {
                if (this.config.get("name") === "" || this.config.get("name") === undefined) {
                    // just disable the button, this is simple enough
                    this.ui.savebutton.prop("disabled", true);
                    return false;
                }
                this.ui.savebutton.prop("disabled", false);
                return true;
            }
        });

        Switcher.Views.CopyConfig = Backbone.Layout.extend({
            template: "hpiadmin/copyconfig",
            events: {
                "click #new-config-save": "saveConfig",
                "keyup #new-config-name": "setConfigName",
                "change #new-config-name": "setConfigName"
            },
            initialize: function(options) {
                this.configType = this.options.configType;
                this.config = this.options.config ? this.options.config : new this.configType.Model();
                this.ui = {};
            },
            afterRender: function() {
                this.ui.configNameInput = this.$("#new-config-name");
                this.ui.savebutton = this.$("#new-config-save");
                this.validate();
            },
            serialize: function() {
                return {
                    "configName": this.config.get("type")
                };
            },
            setConfigName: function(e) {
                this.config.set("name", this.ui.configNameInput.val());
                this.validate();
            },
            saveConfig: function(e) {
                //strip the id off the model to make a POST request
                delete this.config.id;
                this.config.save({}, {
                    type: 'post',
                    success: function(model, response, options) {
                        app.log.debug("Copied Config");
                        app.trigger("alert:close");
                    Backbone.history.navigate("admin/" + model.get("type") + "/" + model.get("name"), {trigger: true} );
                    },
                    error: function(model, response, options) {
                        app.trigger("alert:close");
                        app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.hpiAdmin.hpiAdmin-Switcher.failedTo"), ".config-container");
                    }
                });
            },
            validate: function() {
                if (this.config.get("name") === "" || this.config.get("name") === undefined) {
                    // just disable the button, this is simple enough
                    this.ui.savebutton.prop("disabled", true);
                    return false;
                }
                this.ui.savebutton.prop("disabled", false);
                return true;
            }
        });

        Switcher.Views.TracCrossRef = Backbone.Layout.extend({
            template: "hpiadmin/trac-crossref",

            initialize: function(options) {
                this.referencedTracs = [];
                this.tracs = [];
                this.config = options.config || null;
                this.configClass = options.configClass || null;
                app.context.tracConfigs = undefined; //flush any old tracs and force a fetch
                app.context.configService.getTracConfigs($.proxy(this.getReferencedTracs, this));

            },
            //get any tracs that use this type of config, for example,
            //all referenced stage configs
            getReferencedTracs: function(tracs) {
                var query = {};
                query[this.config.get('type')] = this.config.get('name');
                this.referencedTracs = tracs.where(query);
                _.each(this.referencedTracs, function(trac) {
                    this.tracs.push(trac.attributes);
                }, this);
                //sort alphabetically
			this.tracs = _.sortBy(this.tracs, function(trac){ return trac.displayName; });
                this.render();
            },
            serialize: function() {
                return {
                    refrencedTracs: this.refrencedTracs,
                    tracs: this.tracs
                };
            }
        });

        Switcher.Views.Layout = Backbone.Layout.extend({
            template: "hpiadmin/admin-switcher",

            events: {
                "click #new-config-button": "createConfig",
                "click #delete-config-button": "deleteConfig",
                "click #copy-config-button": "copyConfig"
            },

            initialize: function(options) {
                var config = options.config || null;
                var configClass = options.configClass || null;
                // ui element object for storage
                this.ui = {};
                this.confignames = [];
                this.isNotFormConfig = true;
                this.isNotTemplateConfig = true;

                if (config === null || configClass === null) {
				app.trigger("alert:error", {message: window.localize("modules.hpiAdmin.hpiAdmin-Switcher.configSwitcher")});
			}
			else { 
                    this.config = options.config;
                    this.configClass = options.configClass;
                }

                this.crossRef = new Switcher.Views.TracCrossRef({
                    config: this.config,
                    configClass: this.configClass
                });
            },
            beforeRender: function() {
                if (this.config.get("type") !== "FormConfig") {
                    this.setView("#traccrossref", this.crossRef);
                } else {
                    this.isNotFormConfig = false;
                }

                if (this.config.get("type") === "TemplateManagementConfig") {
                    this.isNotTemplateConfig = false;
                }
            },
            serialize: function() {
                return {
                    isNotFormConfig: this.isNotFormConfig,
                    isNotTemplateConfig: this.isNotTemplateConfig
                };
            },
            afterRender: function() {
                // set ui elements
                this.ui.crossRef = this.$("#traccrossref");
                this.ui.dropdown = this.$("#config-dropdown");
                this.ui.dropdown.btn = this.ui.dropdown.find("a.dropdown-toggle");
                this.ui.dropdown.ul = this.ui.dropdown.find("ul");
                this.ui.spinner = this.$(".spinner");
                this.ui.deleteButton = this.$("#delete-config-button");
                this.ui.copyButton = this.$("#copy-config-button");

                // call helper functions after render
                this.populateDropdown();
                this.displayModButtons();
                this.displayCrossRef();
            },

            populateDropdown: function() {
                var self = this;

                // clear existing html and hide the dropdown
                self.ui.dropdown.ul.html("");
                self.ui.dropdown.hide();

                // create our loading spinner
                var spinner = HPISpinner.createSpinner({
                    lines: 9, // The number of lines to draw
                    length: 4, // The length of each line
                    width: 2, // The line thickness
                    radius: 5, // The radius of the inner circle
                    trail: 25, // Afterglow percentage
                    shadow: true // Whether to render a shadow
                }, self.ui.spinner[0]);


                // get the list of available config names
                var configCollection = new this.configClass.Collection();
                configCollection.fetch({
                    success: function(models) {
                        // Avoid Duplicates in the DropDown menu
                        self.ui.dropdown.find("ul").children().remove();

                        //sort drop down alphabetically
						models = models.sortBy(function(model){ return model.get('name').toLowerCase(); });					
                        //don't keep a record of this call in the store
                        _.each(models, function(model) {
                            var active = null;
                            // determine if we should highlight the current config in the menu dropdown
                            if (self.config.id && self.config.get("name") === model.get("name")) {
                                active = "active";
                            }
                            self.ui.dropdown.find("ul").append("<li class='" + active + "'><a href='admin/" + self.config.get("type") + "/" + model.get("name") + "''>" + model.get("name") + "</a></li>");
                        });

                        // stop the loading spinner
                        HPISpinner.destroySpinner(spinner);
                        // hide the div that contains the spinner
                        self.ui.spinner.hide();

                        // show the now populated dropdown
                        self.ui.dropdown.show();
                    }
                });

                // set the dropdown title to the name of the current config (or "Please Choose a Config" if none)
                if (this.config.id) {
                    this.ui.dropdown.btn.find("span#current-config").html(this.config.get("name"));
                }


            },

            createConfig: function(e) {
                // todo: if you needed a custom view (creator) for a particular config type, you could check for the existence of a this.configClass.[yourview], and then inject it as the subview if needed
                // try to stick to convention and make it a standardized "NewConfig" view name though

			var view = new Switcher.Views.NewConfig({ configType: this.configClass });
			app.trigger("alert:custom", { view: view });
            },
            copyConfig: function(e) {
                // todo: if you needed a custom view (creator) for a particular config type, you could check for the existence of a this.configClass.[yourview], and then inject it as the subview if needed
                // try to stick to convention and make it a standardized "NewConfig" view name though

			var view = new Switcher.Views.CopyConfig({ configType: this.configClass, config: this.config });
			app.trigger("alert:custom", { view: view });
            },
            displayModButtons: function() {
                if (this.config.id) {
                    this.ui.deleteButton.removeClass("hide");
                    this.ui.copyButton.removeClass("hide");
			}
			else { 
                    this.ui.deleteButton.addClass("hide");
                    this.ui.copyButton.addClass("hide");
                }
            },
            displayCrossRef: function() {
                if (this.config.id) {
                    this.ui.crossRef.show();
                } else {
                    this.ui.crossRef.hide();
                }
            },
            deleteConfig: function() {
                var self = this;
                app.trigger("alert:confirmation", {
                    header: window.localize("modules.hpiAdmin.hpiAdmin-Switcher.areYouSure"),
                    message: window.localize("modules.hpiAdmin.hpiAdmin-Switcher.pleaseConfirm"),
                    confirm: function() {
                        self.config.destroy({
                            success: function(model, response) {
                                app.log.debug("Removed Config");
							Backbone.history.navigate("admin/" + model.get("type"), {trigger: true} );
                            },
                            error: function(model, response) {
                                app.trigger("alert:changeNotification", "alert-danger", window.localize("modules.hpiAdmin.hpiAdmin-Switcher.failedTo"), ".config-container");
                            }
                        });
                    }
                });
            }
        });

        return Switcher;

    });