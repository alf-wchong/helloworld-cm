// ActionViewer module
define([
    "app",
    "modules/common/actionservice",
    "modules/common/rightsideactionhandler"
],

// Map dependencies from above array.
function(app, ActionService, Rightsideactionhandler) {
    // Create a new module.
    var ActionViewer = app.module();

    ActionViewer.Views.Layout = Backbone.Layout.extend({
        template: "actionviewer/actionlayout",
        initialize: function(options) {
            // passed in from router
            this.trac = options.trac;
            this.containerId = options.containerId;
            this.pathParams = options.pathParams;

            this.isRendered = false;
            this.actionLauncher = new ActionService.ActionLauncher();
            this.tracConfig = app.context.tracConfigs.findWhere({ name: app.context.configName() });

            // turn on the replace anchor tags registered helper dynamicOcmsAnchorTags
            app.replaceAnchorTags = true;
            
            // get the folderAction config based on the trac we are in. Set up the sub views
            this.getStageConfig();
        },
        getStageConfig: function() {
            var that = this;
            app.context.configService.getStageConfigByName(this.tracConfig.get("StageConfig"), function(stageConfig) {
                that.config = stageConfig.get("folderActionConfig");

                // Set the view
                that.setViews({
                    "#rightSideActionHandler": new Rightsideactionhandler.View()
                });

                app.context.util.renderSubViews(that);
            });
        },
        /**
         * Uses the action launcher to find the available folder actions for this container. Of those actions,
         * the name that matches the url parameter's id (folderActionId=actionId) is selected. An action view is
         * created from the action and its config. In our case all actions should use the right side action handler
         * so the action config is updated to reflect that.
         */
        buildActionViews: function() {
            this.actionGroups = [];
            this.actionGroupDeferreds = [];

            // check if param is viewAllDocuments, short circuits to prevent using undefined value
            if (!this.pathParams || !this.pathParams.folderActionId) {
                $('#actionErrorMessage').html(window.localize("modules.actionViewer.error.invalidUrlParams"));
                $('#actionErrorMessage').show();
                return;
            }
            if (this.pathParams.folderActionId === "viewAllDocuments") {
                $('#actionErrorMessage').html(window.localize("modules.actionViewer.error.actionNotSupported"));
                $('#actionErrorMessage').show();
                return;
            }

            //Iterate over all configured action groups
            _.each(this.config.get("actionGroups").models, function(actionGroup, index){
                //Create actionGroup object with extended props in the actionGroups array, adding a new prop called 'evaluate' which will store the 'getAvailableActions' deferred
                // update action handler on each action config
                var actionFound = false;
                _.each(actionGroup.attributes.actions.models, function(action) {
                    action.set("handler", "rightSideActionHandler");
                    if (action.get("actionId") === this.pathParams.folderActionId) {
                        actionFound = true;
                    }
                }, this);

                // if the url param is not an action quit here to prevent default action behavior
                if(!actionFound) {
                    $('#actionErrorMessage').html(window.localize("modules.actionViewer.error.actionNotFound"));
                    $('#actionErrorMessage').show();
                    return;
                }

                this.actionGroups[index] = _.extend({}, actionGroup.attributes, {
                    evaluate: this.actionLauncher.getAvailableActions(actionGroup, this.containerId)
                });

                //Set returned deferred on our actionGroupDeferreds array for later evaluation
                this.actionGroupDeferreds.push(this.actionGroups[index].evaluate);

                //Once a single deferred is resolved, set filterd actions on actionGroup object in array
                //and iterate over each action returned to create the action views
                $.when(this.actionGroups[index].evaluate).done($.proxy(function(filteredActions){
                    this.actionGroups[index].actions = filteredActions; 
                    _.each(this.actionGroups[index].actions.models, _.bind(function(action, actionIdx){
                        // confirm this is the past action
                        if(this.pathParams.folderActionId === action.get("actionId")) { 
                            var actionConfig = this.actionGroups[index].actions.configs[actionIdx];

                            this.actionView = new ActionViewer.Action({ model: action, config: actionConfig, actionLauncher: this.actionLauncher });
                            // if idLabel prop has spaces, replace with _ 
                            this.actionGroups[index].idLabel = this.actionGroups[index].label.replace(/ /g,"_");

                            return; // execute once then return
                        }
                    }, this));
                }, this));
            }, this);
        },
        cleanup: function() {
            // turn off the replace anchor tags registered helper when destroying this view
            app.replaceAnchorTags = false;
        },
        afterRender: function() {
            if (!this.isRendered) {
                this.buildActionViews();
                this.isRendered = true;
                this._startListening();
            }
        },
        _startListening: function() {
            // triggered when the right side action handler is completed
            this.listenTo(app, "toggleRSAH", this.toggleRSAH);

            // listens for our custom trigger and calls togglePane3()
            this.listenTo(app, "action.refresh.togglePane3", this.togglePane3, this);
        },
        toggleRSAH: function (showRSAH) {
            // trigger togglePane3() to showing the pane if the RSAH is ready
            app.trigger("action.refresh.togglePane3", showRSAH);

            // remove the `x` in the corner of the RSAH, preventing navigation
            $('#close-rsah').hide();
        },
        togglePane3: function(makeVisible) {
            if (makeVisible) { $('#pane3').show(); }
            else { $('#pane3').hide(); }
        }
    });

    ActionViewer.Action = Backbone.Model.extend({
        initialize: function(options) {
            this.actionModel = options.model;
            this.actionConfig = options.config;
            this.actionLauncher = options.actionLauncher;

            // on initialization, launch the action that has been passed into this view
            this.actionLauncher.launchAction(this.actionModel, this.actionConfig);
        }
    }); 

    return ActionViewer;

});