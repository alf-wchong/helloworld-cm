define([
    'app',
    'tsgUtils',
    'modules/common/hpiconstants'
], function(app, tsgUtils, HPIConstants){
    
    var OAContainer = {
        'MODAL': 'modal',
        'DIV': 'div',
        'SELECT_ALL_PAGES': 'ALL',
        'POPOVER' : 'popover'
    };

    // TODO This should be refactored in a general OA iframe that could be used throughout OCMS
    OAContainer.SelectedPages = Backbone.Layout.extend({
        //We set the template in the initalize
        template: null,
        events: {
            'hide.bs.modal #selected-pages-modal': 'handleSelectedPagesClose',
            'click #selected-pages-select-btn' : 'triggerSelectedPagesDone'// event only for when in div or popover  mode
        },
        initialize: function(options){
            this.modalSize = options.modalSize || "modal-xl";
            this.parsedPageSelections = this.model.get('pages') === "" ? OAContainer.SELECT_ALL_PAGES : this.model.get('pages');
            this.oaUrl = app.openAnnotateURL + "/login/external.htm?docId=" +  this.model.get('objectId') +
                    "&username=" + app.user.get("loginName") +
                    "&pageSelectMode=" + this.parsedPageSelections;
            this.stopListening(app, 'stage.windowResizePanes');
            this.applyListeners();
            this.mode = options.mode;
            if(this.mode === OAContainer.DIV || this.mode === OAContainer.POPOVER){
                this.template = 'openannotate/selectedpages-div-popover';
            }else{
                this.template = 'openannotate/selectedpages-modal';
            }
        },
        applyListeners: function(){
            this.stopListening(app.openAnnotate);
            this.listenTo(app.openAnnotate, 'change:selectedPages', this.selectedPagesChanged);
            // Handles enabling/disabling the Select Pages button based on the validity of the page range
            this.listenTo(app.openAnnotate, 'change:pageRange', this.handleNewPageRangeValidity);
        },
        selectedPagesChanged: function(selectedPages){
            this.model.set('pages', selectedPages);
        },
        handleSelectedPagesClose: function() {
            // The modal is closed, we need to remove it from the DOM and cleanup
            this.remove();
            if(this.mode === OAContainer.POPOVER){
                app.popoverHandler.trigger("hide");
            }
        },
        enableSelectButton: function(){
            this.$("#selected-pages-select-btn").removeClass("disabled");
            this.$("#selected-pages-select-btn-div").tooltip("disable");
        },
        disableSelectButton: function(tooltipMessage){
            this.$("#selected-pages-select-btn").addClass("disabled");
            this.$("#selected-pages-select-btn-div").attr("data-original-title", tooltipMessage);
            this.$("#selected-pages-select-btn-div").tooltip("enable");
        },
        triggerSelectedPagesDone: function() {
            this.trigger('done:selectedPages', this.model.get('pages'));
            this.handleSelectedPagesClose();
        },
        handleNewPageRangeValidity: function(pageRangeValid){
            if(pageRangeValid){
                this.enableSelectButton();
            } else{
                this.disableSelectButton(window.localize("modules.openannotate.oacontainer.invalidPageRangeTooltipText"));
            }
        },
        afterRender: function(){
            this.stopListening(app);
            if(this.mode === OAContainer.MODAL || this.mode === OAContainer.POPOVER){
                this.resizeModal();
                this.listenTo(app, 'stage.windowResizePanes', this.resizeModal);
                if(this.mode === OAContainer.MODAL){
                    this.$('#selected-pages-modal').modal();
                }
            }
            this.$('#oa-selected-pages-iframe-' + this.cid).attr('src', this.oaUrl);
        },
        resizeModal: function() {
            //Static - accounts for the height of the header and footer in the modal
            var headerHeight = 56; 
            var footerHeight = 65; 

            //Need to grab the right selector based on if we are in popover mode or modal mode
            var modalBodyPaddingSelector = this.mode === OAContainer.MODAL ? $("#oa-modal-outlet") : $("#popoverHandler-content");

            //30px comes from the modal-description height and the margin-bottom applied
            var modalBodyPadding = (modalBodyPaddingSelector.css("padding-top").replace("px", "") * 2) + 30; 

            //20px accounts for the margin-top / margin-bottom and the 15px accounts for any possible borders
            var newHeight = window.innerHeight - headerHeight - footerHeight - modalBodyPadding - 20 - 15;

            if (window.innerWidth > HPIConstants.WindowSize.Small) {
                //Subtract an extra 40px that acounts for the change in margin-top / margin-bottom from 20px (subtracted above) to 60px total
                newHeight = newHeight - 40; 
            }

            // show the modal with the adjusted height
            $('#oa-selected-pages-iframe-' + this.cid).height(newHeight);
        },
        serialize: function(){
            return {
                cid: this.cid,
                iframeStyling: this.mode === OAContainer.DIV ? "oa-div-iframe" : "oa-modal-iframe",
                modalSize: this.modalSize
            };
        },
        cleanup: function(){
            // triggering a cleanup if iframe is destroyed - this was previously called from tableview ,
            // however we could possibly run into issues where the iframe wasn't removed from the DOM 
            if(app.openAnnotate) {
                app.openAnnotate.trigger("cleanup");
            }
        }
    });
    
    OAContainer.Model = Backbone.Model.extend({
        defaults:{
            objectId: '',
            pages: ''
        },
        initialize: function(options){
            this.options = _.defaults(options,this.defaults);
        }
    });
    
    return OAContainer;
    
});