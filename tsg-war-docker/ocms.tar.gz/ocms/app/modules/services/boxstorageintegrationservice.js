define([
    "app",
    "module",
    "boxIntegration"
],
function(app, module) {

	var BoxStorageIntegrationService = app.module();

	
	var boxSelect;

	BoxStorageIntegrationService.setup = function(config) {
		/* jshint ignore:start */
		var options = {
		    clientId: config.boxIntegrationClientId,
		    linkType: config.boxIntegrationLinkType,
		    multiselect: config.boxIntegrationSelectMultiple
		};
		
		boxSelect = new BoxSelect(options);
		/* jshint ignore:end */

		// Register a success callback handler
		boxSelect.success(function(response) {
			var files =[];

		    _.each(response, function(object) {
				// build our oco
		    	var documentOco = {
                    name: object.name,
                    downloadUrl: object.url,
                    cloudDoc: true,
                    mimeType: object.name.split('.').pop().toLowerCase()
		    	};
		    	files.push(documentOco);
		    });
		    app.trigger("bulkupload:filesUploaded", files);
		});

	};

	BoxStorageIntegrationService.fileSelect = function() {
		boxSelect.launchPopup();

	};

	return BoxStorageIntegrationService;

});