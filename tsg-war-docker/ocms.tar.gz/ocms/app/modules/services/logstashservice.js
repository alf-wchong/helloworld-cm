define([
    "app",
    "modules/common/hpiconstants",
    "tsgUtils"
],
function(app, HPIConstants, TSGUtils) {

    var LogStashService = {};
    
    LogStashService.events = _.extend({}, Backbone.Events);

    //Checks that performance logging is configured for OCMS before sending the performance log through TSGUtils
    LogStashService.sendMetrics = function(performanceLog) {
        app.context.configService.getLoggingConfig(function () {
            if (app.context.currentLoggingConfig().get(HPIConstants.Logging.Events.PerformanceLogging)) {
                TSGUtils.sendPerformanceLog({
                    requestUrl: app.serviceUrlRoot,
                    data: performanceLog
                });
            }
        });
    };

    LogStashService.PerformanceLog = Backbone.Model.extend({
        //keys are docCount, eventTitle, browser, events, user
        defaults: {
            'docCount': 0,
            'events': {}
        },
        initialize: function() {
            this.set("user", app.user.get("loginName"));

            var browser = TSGUtils._getBrowser();
            this.set("browser", browser.name + "-v" + browser.version);
        }
    });
    
    return LogStashService;
});
