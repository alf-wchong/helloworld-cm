define([
    "app"
],
function(app) {

    var GoogleAnalyticsService = {};

    GoogleAnalyticsService.events = _.extend({}, Backbone.Events);

    GoogleAnalyticsService.sendAnalytics = function (action) {

        // try/catch used to check if 'ga' namespace is on the window. If not, do nothing (Google Analytics is not configured for the current HPI build...)
        // To configure, add Google Analytic script to your project's 'index.jsp'
        try{
            window.ga('set', 'page', action);
            window.ga('send', 'pageview');
        }
        catch(err){
            // nothing for now...
        }
    };

    window.GoogleAnalyticsService = GoogleAnalyticsService;

    window.GoogleAnalyticsService.events.listenTo(app, "googleanalytics.logaction", window.GoogleAnalyticsService.sendAnalytics);

    return GoogleAnalyticsService;
});
