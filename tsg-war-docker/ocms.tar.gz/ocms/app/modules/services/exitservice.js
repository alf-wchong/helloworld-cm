define([
    'app'
], function(app){
    //Service for maintaining multiple window.onbeforeunload routines
    var ExitService = {};

    ExitService.beforeunload = "beforeunload";

    ExitService.Routine = Backbone.Model.extend({
        idAttribute: 'key',
        defaults: {
            'key': '',
            'func': function(){},
            'message': undefined
        },
        showMessage: function(){
            //by default any message configured will be shown to the end user
            //override this when registering this function for special cases (like Active Wizard)
            return this.get('message');
        }
    });

    ExitService.Routines = Backbone.Collection.extend({
        model: ExitService.Routine
    });

    ExitService.register = function(key, func, message, showMessage){
        if(!ExitService.events){
            ExitService.events = new ExitService.Routines();
        }

        var routine = new ExitService.Routine({
            'key': key,
            'message': message
        });
        //do we override showMessage? - show message by default
        routine.showMessage = showMessage !== undefined ? showMessage : routine.showMessage;
        //assign custom function
        routine.func = func;
        ExitService.events.add(routine);
        //update registered events
        window.ExitService = ExitService;
        //register events
        ExitService.registerEvents();
    };

    ExitService.deregister = function(key){
        if(!ExitService.events){
            return;
        }
        ExitService.events.remove(key);
        //update registered events
        window.ExitService = ExitService;

        //register events
        ExitService.registerEvents();
    };

    ExitService.getKeys = function(){
        if(!ExitService.events){
            return [];
        }
        return ExitService.events.pluck('key');
    };

    //cross-browser onbeforeunload registration
    //https://developer.mozilla.org/en-US/docs/Web/Events/beforeunload
    ExitService.registerEvents = function(){
        //Remove previous bindings (to prevent duplicates since all events are re-added)
        $(window).off(ExitService.beforeunload);

        if(!window.ExitService.events){
            return;
        }

        window.ExitService.events.each(function(routine){
            //Add all events
            $(window).on(ExitService.beforeunload, function (evt) {
                routine.func(evt);
                var confirmationMessage = routine.get('message');
                if(routine.showMessage()){
                    evt.returnValue = confirmationMessage;     // Gecko, Trident, Chrome 34+
                    return confirmationMessage;              // Gecko, WebKit, Chrome <34
                }
            });
        }, this);
    };

    //clear off any functions bound to onbeforeunload
    window.onbeforeunload = undefined;

    return ExitService;
});
