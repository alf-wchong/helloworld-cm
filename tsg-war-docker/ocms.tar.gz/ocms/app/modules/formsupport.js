// Formsupport module
define([
        // Application.
        "app",
        "knockout",
        "knockback",
        "modules/tsg",
        "moment",
        "handlebars",
        "modules/conditions/condition",
        "tsgUtils",
        "momentTimezone",
        "datetimePicker",
        "plugins/knockout.validation"        
    ],

    // Map dependencies from above array.
    function(app, ko, kb, TSG, moment, Handlebars, Condition, tsgUtils) {

        // Create a new module.
        var Formsupport = app.module();
        Formsupport.tsgFormSupport = function(viewModel, options) {
            //This function can be used to augment an arbitrary view model so that it can be bound against
            //our standard form templates
            viewModel.positionalData = ko.observable(options.positionData);

            viewModel.isSearchMode = options.searchMode || false;

            //Checking if this is a WF form
            var isWorkflowForm = options.isWorkflowForm || false;

            var disableDefaults = options.disableDefaults || false;
            // flag to determine if we are currently retreiving a form for context.getFormConfig
            viewModel.formIsFetching = ko.observable(false);

            /* This event manager is used to coordinate interaction between
             * form elements. It is a backbone event manager that has a dispose function
             * which causes the knockback release method to call it when the associated view
             * is removed. We can then remove all subscriptions
             */
            var eventManager = viewModel.eventManager = {
                dispose: function() {
                    this.stopListening();
                }
            };
            _.extend(eventManager, Backbone.Events);

            //you must set the objectType on the view model
            viewModel.objectType = ko.observable();

            //you must set formName on the view model
            viewModel.formName = ko.observable(options.formName);

            //we are going to fetch the form once in form support
            //and cache it on this
            viewModel.form = ko.observable();

            viewModel.readOnly = ko.observable(false);

            // allows a user to specify which trac to pull OTCs from
            viewModel.tracToUse = ko.observable(options.tracToUse === undefined ? app.context.configName() : options.tracToUse);

            viewModel.isFormValidationComplete = ko.observable(true);

            //enable required by default if the param is not set
            viewModel.enableRequired = ko.observable(options.enableRequired === undefined ? true : options.enableRequired);

            //enable validation by default if the param is not set
            viewModel.enableReadonly = ko.observable(options.enableReadonly === undefined ? false : options.enableReadonly);

            //enable validation by default if the param is not set
            viewModel.enableAppendOnly = ko.observable(options.enableAppendOnly === undefined ? false : options.enableAppendOnly);

            viewModel.controls = ko.observable([]);

            viewModel.quickSelectControls = ko.observable([]);

            /**build up the grouped controls if groupings were provided
             *  This attributeGroups object should be map:
             * {objectType : [group1, group2], objectType2: [group3, group4]}
             * where a group looks like:
             * {label : LABEL, isDefault: boolean, attributes: [name, modifiedDate, etc]}
             **/

            viewModel.attributeGroups = ko.observable({});

            if (options.attributeGroups) {
                viewModel.groupedControls = ko.observableArray([]);
                var buildGroupedControls = function(newControls) {
                    var groupedControls = [];
                    var attributeGroupsForThisObjectType = viewModel.attributeGroups()[viewModel.objectType()];
                    if (attributeGroupsForThisObjectType) {
                        //Loop over attrs in each attribute group and grab the corresponding control.
                        $.each(attributeGroupsForThisObjectType, function(idx, group) {
                            var oneGroup = {
                                label: group.label,
                                controls: [],
                                isDefault: group.isDefault || false
                            };
                            $.each(group.attributes, function(idx, attribute) {

                                //Get the corresponding control for the attr
                                $.each(newControls, function(idx, control) {
                                    if (attribute === control.id) {
                                        oneGroup.controls.push(control);
                                        return false;
                                    }
                                });
                            });
                            groupedControls.push(oneGroup);
                        });
                    }
                    viewModel.groupedControls(groupedControls);
                };
                viewModel.controls.subscribe(buildGroupedControls);
            }


            viewModel.getValues = function(getValidControls) {
                //getValidControls is an optional parameter
                var vals = {};
                _.each(viewModel.controls(), function(control) {
                    //if getValidControls is true and the value of the control isn't valid
                    //don't return it - return does not break out of a underscore loop, it continues it
                    if (getValidControls && !control.value.isValid()) {
                        return;
                    }

                    // if not visibilityDependencyValid we want to return an empty or return value so the value doesn't persist on the backend
                    if (!control.visibilityDependencyValid() || !control.enableDependencyValid()) {
                        if (control.isRepeating) {
                            if (control.value()) {
                                vals[control.id] = null;
                            }
                        } else {
                            if (control.dataType === "boolean") {
                                vals[control.id] = false;
                            } else {
                            	vals[control.id] = null;
                        	}
                        }
                    } else {
                        if ((control.value() !== 0 && control.value() !== false && !control.value()) || control.value().length === 0) {
                            //lets send null
                            vals[control.id] = null;
                        } else {
                            vals[control.id] = control.value();
                        }
                    }
                });

                return vals;
            };

            viewModel.getFormLabels = function() {           
                var formLabels = {};

                for (var i=0; i < viewModel.controls().length; i ++) {
                        formLabels[viewModel.controls()[i].id] = viewModel.controls()[i].label;
                }

                return formLabels;
            };

            eventManager.on("fs:requestingAllValues", function() {
                eventManager.trigger("fs:allValues", viewModel.getValues());
            });

            /** See right below for the code that subscribes to this function **/
            var working; //prevent overlaps of the control generator
            viewModel.controlGenerator = function() {

                /***** All needed to continue. *****/
                var objectTypeName = viewModel.objectType();
                var enableRequired = viewModel.enableRequired();
                var enableReadonly = viewModel.enableReadonly();
                var enableAppendOnly = viewModel.enableAppendOnly();

                /**************************************************************************/

                if (working) {
                    //to prevent the controls from building over them selves
                    return;
                }
                //when we change our object type, we want to
                //have the event manager quit listening to old events
                //so we don't get infinite loops
                viewModel.eventManager.stopListening();

                //only build controls if an objectType is set
                if (objectTypeName) {
                    if (!isWorkflowForm) {
                        app.log.debug("Controls building.");
                        working = true;

                        var formForType = _.find(viewModel.form().get("configuredTypes").models, function(formType) {
                            return formType.get("ocName") === objectTypeName;
                        });

                        if (!formForType) {
                            app.log.debug("No form config found for object type " + objectTypeName + "on form " + viewModel.form().get("name"));
                            return;
                        }

                        //we allow type's form to be overwritten - check if this is the case here, and if so pull the new formForType
                        if (formForType.get("overrideType")) {
                            var overrideForm = _.find(viewModel.form().get("configuredTypes").models, function(formType) {
                                return formType.get("ocName") === formForType.get("overrideType");
                            });

                            var origAttrsOcNames = _.union(formForType.get('configuredAttrsPri').pluck('ocName'), formForType.get('configuredAttrsSec').pluck("ocName"));
                            var attrsToAddOcNames = _.union(overrideForm.get('configuredAttrsPri').pluck("ocName"), overrideForm.get('configuredAttrsSec').pluck("ocName"));

                            //These are the ocNames that are on the "override" but not the "original"..  We will need to add them to the original types collection.
                            var ocNameToAddToOrig = _.difference(_.union(origAttrsOcNames, attrsToAddOcNames), origAttrsOcNames);
                        
                            app.log.debug("There is an override for this form and there are differences of: " + ocNameToAddToOrig);

                            //If it's in the primary attributes of the override, put it in the primary attributes for the  original type. Same for secondary attrs.
                            _.each(ocNameToAddToOrig, function(attrToAdd) {
                                if (overrideForm.get('configuredAttrsPri').findWhere({ 'ocName': attrToAdd })) {
                                    formForType.get('configuredAttrsPri').add(overrideForm.get('configuredAttrsPri').findWhere({ 'ocName': attrToAdd }));
                                } else {
                                    formForType.get('configuredAttrsSec').add(overrideForm.get('configuredAttrsSec').findWhere({ 'ocName': attrToAdd }));
                                }
                            });
                        }
                    }
                    //get form for this type
                    app.context.configService.getAdminTypeConfig(objectTypeName, function(otc) {
                        app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat) {
                            if (otc) {
                                //Getting the controls from the WF form config
                                if (formForType) {
                                    viewModel.externalFormRules = formForType.get('externalFormRules');
                                    viewModel.externalFormMessage = formForType.get('formFailureMessage');
                                    viewModel.externalFormValidationMessage(viewModel.externalFormMessage);
                                }

                                var allConfiguredAttrs;
                                var controlsBeingBuilt = [];
                                if (isWorkflowForm) {
                                    allConfiguredAttrs = viewModel.form();
                                } else {
                                    allConfiguredAttrs = formForType.get("configuredAttrsPri").models;
                                    //only add secondary attrs for search
                                    if (viewModel.isSearchMode) {
                                        allConfiguredAttrs = _.union(formForType.get("configuredAttrsPri").models, formForType.get("configuredAttrsSec").models);
                                    }
                                }

                                // If we're in search mode or if there's no associated document we don't care about
                                // applied aspects
                                if (!viewModel.isSearchMode && !options.isCreate && viewModel.objectId) {
                                    app.context.util.getAppliedAspects(viewModel.objectId, function(aspects) {
                                        viewModel.aspects = aspects;
                                    });
                                } else {
                                    viewModel.aspects = [];
                                }

                                _.each(allConfiguredAttrs, function(availableAttribute) {

                                    var otcAttr = _.find(otc.get("attrs").models, function(theAttr) {
                                        return availableAttribute.get("ocName") === theAttr.get("ocName");
                                    });

                                    if (otcAttr) {
                                        availableAttribute.set("label", otcAttr.get("label"));
                                    }

                                    availableAttribute.set('appliedAspects', viewModel.aspects);
                                    
                                    //in the below if (!enableRequired), we change required
                                    //on availableAttribute, which changes the config, which is bad
                                    //so we have to temporarily store it and reassign below to the correct
                                    //value
                                    var tempFormEditable = availableAttribute.get("formEditable");
                                    var tempRepoEditable = availableAttribute.get("editable");
                                    var tempRequired = availableAttribute.get("required");
                                    var tempImporting = availableAttribute.get("importing");
                                    if (!enableRequired) {
                                        //further, if enableReadonly is we want the object to
                                        // retain its editablity, so that we can have non-validated
                                        // read-only attributes on forms that want them (currently only BulkProperties).
                                        if (!enableReadonly) {
                                            availableAttribute.set("formEditable", true);
                                            availableAttribute.set("editable", true);
                                        }

                                        if (enableAppendOnly) {
                                            availableAttribute.set("appendOnly", true);
                                        }

                                        availableAttribute.set("required", false);
                                    }

                                    //get correct type of formControl based on controlType
                                    var formControl;

                                    availableAttribute.set("objectType", objectTypeName);
                                    switch (availableAttribute.get("controlType")) {
                                        case 'MultiSelect':
                                            formControl = Formsupport.modelForm.multiElementValidatedFormControl(availableAttribute, viewModel.eventManager);
                                            break;
                                        case 'DropDown':
                                            formControl = Formsupport.modelForm.singleSelectValidatedFormControl(availableAttribute, viewModel.eventManager, disableDefaults, viewModel.readOnly());
                                            break;
                                        case 'RadioButton':
                                            formControl = Formsupport.modelForm.radioButtonValidatedFormControl(availableAttribute, viewModel.eventManager, disableDefaults, viewModel.readOnly());
                                            break;
                                        case 'CheckBox':
                                            formControl = Formsupport.modelForm.checkBoxValidatedFormControl(availableAttribute, viewModel.eventManager, disableDefaults, viewModel.readOnly());
                                            break;
                                        case 'AutoComplete':
                                            formControl = Formsupport.modelForm.autoCompleteValidatedFormControl(availableAttribute, viewModel.eventManager, disableDefaults, viewModel.readOnly(), viewModel.isAttributeDeletable);
                                            break;
                                        case 'Cascading':
                                            formControl = Formsupport.modelForm.singleSelectValidatedFormControl(availableAttribute, viewModel.eventManager, disableDefaults, viewModel.readOnly(), viewModel.isAttributeDeletable);
                                            break;
                                        case 'TextArea':
                                            formControl = Formsupport.modelForm.simpleValidatedFormControl(availableAttribute, viewModel.eventManager, viewModel.isAttributeDeletable, viewModel.setValues);
                                            break;
                                        case 'TextAreaList':
                                            formControl = Formsupport.modelForm.simpleTextAreaListFormControl(availableAttribute, viewModel.eventManager, viewModel.isAttributeDeletable);
                                            break;
                                        case 'DateBox':
                                            availableAttribute.set("dateFormat", dateTimeFormat.dateFormat);
                                            availableAttribute.set("timezoneFormat", dateTimeFormat.timezoneFormat);
                                            if (viewModel.isSearchMode) {
                                                formControl = Formsupport.modelForm.dateSearchControl(availableAttribute, viewModel.eventManager);

                                            } else {
                                                formControl = Formsupport.modelForm.dateBoxValidatedFormControl(availableAttribute, viewModel.eventManager, viewModel.isAttributeDeletable);
                                            }
                                            break;
                                        case 'DatetimeBox':
                                            if (dateTimeFormat.dateFormat.indexOf('z') > -1) {
                                                availableAttribute.set("dateFormat", dateTimeFormat.dateFormat.replace(' z', ''));
                                            } else {
                                                availableAttribute.set("dateFormat", dateTimeFormat.dateFormat);
                                            }

                                            if (dateTimeFormat.timeFormat.indexOf('z') > -1) {
                                                availableAttribute.set("timeFormat", dateTimeFormat.timeFormat.replace(' z', ''));
                                            } else {
                                                availableAttribute.set("timeFormat", dateTimeFormat.timeFormat);
                                            }

                                            availableAttribute.set("timezoneFormat", dateTimeFormat.timezoneFormat);
                                            if (viewModel.isSearchMode) {
                                                formControl = Formsupport.modelForm.dateSearchControl(availableAttribute, viewModel.eventManager);
                                            } else {
                                                formControl = Formsupport.modelForm.dateBoxValidatedFormControl(availableAttribute, viewModel.eventManager, viewModel.isAttributeDeletable);
                                            }
                                            break;
                                        case 'ProximityDateSearch':
                                            formControl = Formsupport.modelForm.proximityDateFromControl(availableAttribute, viewModel.eventManager);
                                            break;
                                        case 'Computed':
                                            if (viewModel.isSearchMode) {
                                                formControl = Formsupport.modelForm.simpleValidatedFormControl(availableAttribute, viewModel.eventManager);
                                            } else {
                                                formControl = Formsupport.modelForm.computedFormControl(availableAttribute, viewModel.eventManager);
                                            }
                                            break;
                                        case 'NumericRange':
                                            if (viewModel.isSearchMode) {
                                                formControl = Formsupport.modelForm.numericRangeSearchControl(availableAttribute, viewModel.eventManager);
                                            } else {
                                                formControl = Formsupport.modelForm.simpleValidatedFormControl(availableAttribute, viewModel.eventManager);
                                            }
                                            break;
                                        case 'Authentication':
                                            formControl = Formsupport.modelForm.authenticationValidatedFormControl(availableAttribute, viewModel.eventManager);
                                            break;
                                        case 'ApproveOrReject':
                                            formControl = Formsupport.modelForm.approveOrRejectValidatedFormControl(availableAttribute, viewModel.eventManager);
                                            break;
                                        default:
                                            formControl = Formsupport.modelForm.simpleValidatedFormControl(availableAttribute, viewModel.eventManager, viewModel.isAttributeDeletable, viewModel.setValues);
                                    }

                                    if (viewModel.readOnly() === true) {
                                        formControl.readOnly(true);
                                    }

                                    //make the field read only if it is locked
                                    if(formControl.isLocked){
                                        formControl.readOnly(true);
                                        //init boolean for successful authentication
                                        formControl.authSuccess = false;
                                    }

                                    //setting isSearchMode to fix styling issues with controls in Attribute Search
                                    if (viewModel.isSearchMode) {
                                        formControl.isSearchMode = ko.observable(viewModel.isSearchMode);
                                    }

                                    //For WF Form Config
                                    formControl.willImport = tempImporting;

                                    availableAttribute.set("formEditable", tempFormEditable);
                                    availableAttribute.set("editable", tempRepoEditable);
                                    availableAttribute.set("required", tempRequired);
                                    controlsBeingBuilt.push(formControl);
                                });

                                this.setUpQuickSelect = function() {
                                    var nextInputId = "";
                                    var tempInputArray = [];

                                    _.each(controlsBeingBuilt, function(control) {
                                        if ((control.controlType === "TextBox" || control.controlType === "TextArea" || control.controlType === "DateBox") && !control.readOnly._latestValue) {
                                            control.previousInput = nextInputId;
                                            nextInputId = control.id;
                                            tempInputArray.push(control);
                                        }
                                    });

                                    return tempInputArray;
                                };

                                viewModel.quickSelectControls(this.setUpQuickSelect());

                                viewModel.controls(controlsBeingBuilt);

                                // if tempValues is not undefined, this indicates setValues was called before controls were generated
                                // so we want to recall setValues with the cached tempValues and then clear out tempValues
                                if (viewModel.tempValues !== undefined) {
                                    viewModel.setValues(viewModel.tempValues);
                                    viewModel.tempValues = undefined;
                                }
                                working = false;
                            }
                        }); //end getDateFormat
                    }); // end getAdminTypeConfig

                } else {
                    app.log.debug(window.localize("modules.formSupport.noControlsBuilt"));
                    viewModel.controls([]);
                }

            };

            viewModel.buildFormSupportControls = function() {
                //this is an intermediate step between the caller and controlGenerator
                //to ensure we have our form before we try to generate controls
                //Note that if a form is fetching and this logic is skipped, controlGenerator
                //will still be called, since another subscribe has triggered the logic first
                if (viewModel.form() && !viewModel.formIsFetching()) {
                    //we have the form, so just call the control generator
                    viewModel.controlGenerator();
                } else if (!viewModel.form() && !viewModel.formIsFetching()) {
                    // we don't want another subscribe to trigger go through this logic before we
                    // retrieve our form, so set this flag to true
                    viewModel.formIsFetching(true);
                    //we don't, so we need to fetch it
                    if (isWorkflowForm) {
                        app.context.configService.getAdHocFormConfig(viewModel.formName(), function(form) {
                            //cache our form
                            viewModel.form(form.get('controls'));
                            //no longer fetching form. another subscribe trigger can proceed
                            viewModel.formIsFetching(false);
                            //call control generator
                            viewModel.controlGenerator();
                        });
                    } else {
                        app.context.configService.getFormConfig(viewModel.formName(), function(retrievedForm) {
                            //cache our form
                            viewModel.form(retrievedForm);
                            //no longer fetching form. another subscribe trigger can proceed
                            viewModel.formIsFetching(false);
                            //call control generator
                            viewModel.controlGenerator();
                        });
                    }
                }
            };

            /** Subscriptions for when to regenerate the form **/
            viewModel.objectType.subscribe(viewModel.buildFormSupportControls);
            viewModel.enableRequired.subscribe(viewModel.buildFormSupportControls);
            viewModel.readOnly.subscribe(viewModel.buildFormSupportControls);
            /********   **************/

            viewModel.isAttributeDeletable = Formsupport.Utils._isAttributeDeletable;

            viewModel.setValues = function (valueMap) {
                // it's possible setValues can be called before any controls are generated due to async calls in control generator
                // therefore, if there are no controls, let's cache the passed in valueMap to be used when controls have been generated
                if (viewModel.controls().length === 0) {
                    viewModel.tempValues = valueMap;
                }

                // Save the existing attribute values map
                viewModel.existingValues = valueMap;
                var posData = viewModel.positionalData();
                _.each(viewModel.controls(), function (control) {
                    // Store attribute data
                    if (posData && posData[control.id]) {
                        control.showPositionData(posData[control.id]);
                    }
                    var valueToSet = valueMap[control.id];

                    //keeping track of the original value
                    if (valueToSet !== undefined && valueToSet !== "" && valueToSet !== null) {
                        if (control.controlType === "DateBox" || control.controlType === "DatetimeBox") {
                            // it's a date box, so let's grab the date format and then parse this date
                            if (!control.isRepeating) {
                                var unixDate = valueToSet;
                                if (unixDate !== null) {
                                    //date format will be something like "D MMM YYYY h:mm:ss A"
                                    var dateValue;
                                    if (control.controlType === "DateBox") {
                                        if (!control.timezoneFormat) {
                                            dateValue = moment(unixDate).format(control.dateFormat);
                                        } else {
                                            dateValue = moment(unixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                        }
                                    } else {
                                        if (!control.timezoneFormat) {
                                            dateValue = moment(unixDate).format(control.dateFormat + " " + control.timeFormat);
                                        } else {
                                            dateValue = moment(unixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                        }
                                    }
                                    control.dateDisplay(dateValue);
                                    control.value(unixDate);
                                }
                            } else {
                                var unixDates = valueToSet;
                                if (unixDates !== null) {
                                    if (control.value()) {
                                        control.value.removeAll();
                                    }

                                    control.repeatingDateDisplay.removeAll();
                                    _.each(unixDates, function (unixDate) {
                                        var dateValue;
                                        if (control.controlType === "DateBox") {
                                            if (!control.timezoneFormat) {
                                                dateValue = moment(unixDate).format(control.dateFormat);
                                            } else {
                                                dateValue = moment(unixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                            }
                                        } else {
                                            if (!control.timezoneFormat) {
                                                dateValue = moment(unixDate).format(control.dateFormat + " " + control.timeFormat);
                                            } else {
                                                dateValue = moment(unixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                            }
                                        }

                                        control.repeatingDateDisplay.push(dateValue);
                                        control.value.push(unixDate);
                                    });
                                }
                            }
                        } else if (control.controlType === "DateSearch" || control.controlType === "DatetimeSearch") {
                            var dateSplit = valueToSet.split("|");
                            var startUnixDate, endUnixDate, startDateValue, endDateValue;
                            if (valueToSet.indexOf("|") === valueToSet.length - 1) { //no to date
                                startUnixDate = parseInt(dateSplit[0], 10);
                                if (control.controlType === "DateSearch") {
                                    if (!control.timezoneFormat) {
                                        startDateValue = moment(startUnixDate).format(control.dateFormat);
                                    } else {
                                        startDateValue = moment(startUnixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                    }
                                } else {
                                    if (!control.timezoneFormat) {
                                        startDateValue = moment(startUnixDate).format(control.dateFormat + " " + control.timeFormat);
                                    } else {
                                        startDateValue = moment(startUnixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                    }
                                }
                                control.from(startDateValue);
                            } else if (valueToSet.indexOf("|") === 0) { //no from date
                                endUnixDate = parseInt(dateSplit[1], 10);
                                if (control.controlType === "DateSearch") {
                                    if (!control.timezoneFormat) {
                                        endDateValue = moment(endUnixDate).format(control.dateFormat);
                                    } else {
                                        endDateValue = moment(endUnixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                    }
                                } else {
                                    if (!control.timezoneFormat) {
                                        endDateValue = moment(endUnixDate).format(control.dateFormat + " " + control.timeFormat);
                                    } else {
                                        endDateValue = moment(endUnixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                    }
                                }
                                control.to(endDateValue);
                            } else { //has from and to date
                                startUnixDate = parseInt(dateSplit[0], 10);
                                endUnixDate = parseInt(dateSplit[1], 10);
                                if (control.controlType === "DateSearch") {
                                    if (!control.timezoneFormat) {
                                        startDateValue = moment(startUnixDate).format(control.dateFormat);
                                        endDateValue = moment(endUnixDate).format(control.dateFormat);
                                    } else {
                                        startDateValue = moment(startUnixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                        endDateValue = moment(endUnixDate).tz(control.timezoneFormat).format(control.dateFormat);
                                    }
                                } else {
                                    if (!control.timezoneFormat) {
                                        startDateValue = moment(startUnixDate).format(control.dateFormat + " " + control.timeFormat);
                                        endDateValue = moment(endUnixDate).format(control.dateFormat + " " + control.timeFormat);
                                    } else {
                                        startDateValue = moment(startUnixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                        endDateValue = moment(endUnixDate).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                    }
                                }
                                control.from(startDateValue);
                                control.to(endDateValue);
                            }
                        } else if (control.controlType === "AutoComplete" && control.isRepeating) {
                            // this check is for values coming from attribute search, which are strings delimited by "~|~"
                            // everything else should come in as an array
                            if (!_.isArray(valueToSet) && valueToSet !== null) {
                                valueToSet = valueToSet.split("~|~");
                            }
                            if (valueToSet && valueToSet.length > 0) {
                                // reset the values to make sure no repeats
                                if (control.value()) {
                                    control.value.removeAll();
                                }

                                if (!control.value()) {
                                    control.value([]);
                                }

                                _.each(valueToSet, function (attrVal) {
                                    control.value().push(attrVal);
                                });
                                control.value.valueHasMutated();
                            }
                        } else if (control.controlType === "RadioButton") {
                            if (valueToSet === null) {
                                control.value(undefined);
                            } else {
                                control.value(valueToSet);
                            }
                        } else if (control.controlType === "ProximityDateSearch") {
                            if (valueToSet !== null && valueToSet.indexOf("$*prx*$") > 0) {
                                var inputParams = valueToSet.split('$*prx*$')[1];
                                // input params should be inthe format of proximityType|proximityNumber|proximityTimeSpan
                                inputParams = inputParams.split('|');
                                control.proximityType(inputParams[0]);
                                control.proximityNumber(inputParams[1]);
                                control.proximityTimeSpan(inputParams[2]);
                            }
                        } else if (control.controlType === "NumericRange") {
                            if (valueToSet !== null) {
                                var numberSplit = valueToSet.toString().split("|");
                                if (valueToSet.toString().indexOf("|") === valueToSet.toString().length - 1) { //no to number
                                    control.fromNumber(numberSplit[0].toString());
                                } else if (valueToSet.toString().indexOf("|") === 0) { //no from number
                                    control.toNumber(numberSplit[1].toString());
                                } else { //has from and to number
                                    control.fromNumber(numberSplit[0].toString());
                                    control.toNumber(numberSplit[1].toString());
                                }
                            }
                        }
                        //only put value on object if not an array
                        //it trips the validation message flag if not
                        else if (!control.isRepeating) {
                            if (valueToSet === null) {
                                control.value(undefined);
                            } else {
                                control.value(valueToSet);
                            }
                            // force a change event for the scenario of computed values that were set in bulk edit page
                            control.value.valueHasMutated();
                        }
                        //repeating attributes have their values stored in 'repeating array'
                        else if (control.isRepeating) {
                            // this check is for values coming from attribute search, which are strings delimited by "~|~"
                            // everything else should come in as an array
                            if (!_.isArray(valueToSet) && valueToSet !== null) {
                                valueToSet = valueToSet.split("~|~");
                            }
                            if (control.value()) {
                                control.value.removeAll();
                            }
                            if (!control.value()) {
                                control.value([]);
                            }
                            _.each(valueToSet, function (repeatingAttr) {
                                control.value().push(repeatingAttr); // unwrapping this so that we only load once
                            });


                            // sorting
                            if (control.sortRepeatingAttrs) {
                                Formsupport.Utils.sortAndPrepend(control.value(), control.valuesToPrependWhenSorting);
                            }
                            control.value.valueHasMutated();
                        }

                        // If its dropdown or autocomplete, it keeps track of the Orginal Value(s)
                        if (control.controlType == "AutoComplete" || control.controlType == "DropDown") {

                            control.origValue = valueToSet;
                            // force a change event for the scenario of computd values that were set in bulk edit page
                            control.value.valueHasMutated();
                        }
                    }
                });
            };

            viewModel.setValuesPreserveLocationData = function (valueMap) {

                //Set flag on each affected control to preserve location data
                _.each(viewModel.controls(), function(control) {
                    if(_.has(valueMap, control.id)) {
                        control._preserveLocationData = true;
                    }
                });

                //Call setValues
                viewModel.setValues(valueMap);

                //Reset flag on each affected control
                _.each(viewModel.controls(), function(control) {
                    if(_.has(valueMap, control.id)) {
                        control._preserveLocationData = false;
                    }
                });
            };

            //Clear out all the values without deleting the controls completely.
            viewModel.clearValues = function() {

                _.each(viewModel.controls(), function(control) {

                    if (control.controlType === "DropDown") {
                        control.value("");
                    } else if (control.controlType === "DateBox") {
                        control.value(null);
                        //clear out display value as well
                        control.dateDisplay(null);
                    } else if (control.controlType === "DatetimeBox") {
                        control.value(null);
                        //clear out display value as well
                        control.dateDisplay(null);
                    } else if (control.controlType === "AutoComplete") {
                        // control.$el.val(undefined);
                        if (control.isRepeating) {
                            control.value([]);
                        } else {
                            control.value(undefined);
                        }
                    } else if (control.controlType === "DateSearch") {
                        control.from(null);
                        control.to(null);
                    } else if (control.controlType === "ProximityDateSearch") {
                        control.proximityType('');
                        control.proximityNumber(null);
                        control.proximityTimeSpan('');
                    } else if (control.controlType === "DatetimeSearch") {
                        control.from(null);
                        control.to(null);
                    } else if (control.controlType === "NumericRange") {
                        control.fromNumber(null);
                        control.toNumber(null);
                    } else {
                        if (_.isArray(control.value())) {
                            control.value([]);
                        } else {
                            control.value(undefined);
                        }
                    }
                });
            };

            viewModel.showExternalValidityMessage = ko.observable(false);
            viewModel.externalFormValidationMessage = ko.observable("External Form Validation is not passing.");

            var validateExternalFormRules = function() {
                var externalValidity = true;
                var conditions = _.pluck(viewModel.externalFormRules, 'ruleValue');
                var parameters = {};
                parameters.values = viewModel.getValues();
                parameters.objectType = viewModel.objectType();
                var conditionCollection = new Condition.Collection({
                    conditions: conditions,
                    parameters: parameters
                });

                conditionCollection.fetch({
                    global: false,
                    async: false,
                    success: function() {
                        externalValidity = conditionCollection.validateCollection();
                    }
                });

                return externalValidity;
            };

            viewModel.isValid = ko.computed(function() {
                //TODO: explain why external validation runs first
                var externalValidity = true;
                if (viewModel.externalFormRules && viewModel.externalFormRules.length > 0 && !viewModel.isSearchMode) {
                    externalValidity = validateExternalFormRules();
                }

                viewModel.showExternalValidityMessage(!externalValidity);
                viewModel.externalFormValidationMessage(viewModel.externalFormMessage);

                var attributes = viewModel.controls();
                for (var i = 0; i < attributes.length; i++) {
                    
                     // Checking if external validation is currently running 
                     if (attributes[i].isExternalValidationRunning() === true) {
                        viewModel.isFormValidationComplete(false);
                        return false;
                    }

                    // form has finishing validation
                    viewModel.isFormValidationComplete(true);
                    if(!attributes[i].isExternalRuleValid()) {
                        return false;
                    }

                    if (attributes[i].readOnly() === false) {
                        //attribute is required and is blank (including empty arrays)
                        if (attributes[i].required && ((attributes[i].value() !== 0 && !attributes[i].value()) || (_.isArray(attributes[i].value()) && attributes[i].value().length === 0))) {
                            return false;
                        } else if (attributes[i].controlType === 'NumericRange') {
                            if (attributes[i].value() && attributes[i].fromNumber.isValid && (!attributes[i].fromNumber.isValid() || !attributes[i].toNumber.isValid())) {
                                return false;
                            }
                        } else if (attributes[i].controlType === 'Authentication') {
                            if (attributes[i].value().username.length <= 0 || attributes[i].value().password.length <= 0 ) {
                                return false;
                            }
                        } else if (attributes[i].value() &&
                            (!_.isArray(attributes[i].value()) || (_.isArray(attributes[i].value()) && attributes[i].value().length > 0)) &&
                            attributes[i].value.isValid && !attributes[i].value.isValid() &&
                            !attributes[i].clearInvalidValueEnabled) {
                                return false;
                        }
                    }

                }
                return externalValidity;
            });


            viewModel.templateChooser = function(item) {
                return item.controlType;
            };

            viewModel.afterRender = function(element, data) {
                var jqueryDateFormat, jqueryTimeFormat;

                // activate the bootstrap tooltip, for help text
                $('[data-toggle="tooltip"]').tooltip();

                //flag for editable computed controls
                var maxASCIICharNum = 127;
                //if we have already determined this is a date, it will have at least a dateFormat
                if (data.dateFormat) {
                    jqueryDateFormat = app.context.dateService.getJQueryDateFormat(data.dateFormat);
                    jqueryTimeFormat = app.context.dateService.getJQueryTimeFormat(data.timeFormat);
                }

                // add a wysiwyg if it is configured
                if (data.controlType === "TextArea" && data.isWysiwyg === true) {
                    CKEDITOR.replace(data.id, data.wysiwygConfig, '');
                }
                //Create datepickers after render
                if (data.controlType === "DateBox") {
                    // Allow any date
                    $(element).find('input').datepicker({
                        yearRange: "c-65:c+13",
                        changeMonth: true,
                        changeYear: true,
                        dateFormat: jqueryDateFormat
                    });
                    if (data.enforceDateBeforeToday()) {
                        // Max date allowed is today
                        $(element).find('input').datepicker("option", "maxDate", new Date());
                    } else if (data.enforceDateAfterToday()) {
                        // Min date allowed is today
                        $(element).find('input').datepicker("option", "minDate", new Date());
                    }
                } else if (data.controlType === "DatetimeBox") {
                    // Allow any dates
                    $(element).find('input').datetimepicker({
                        yearRange: "c-65:c+13",
                        changeMonth: true,
                        changeYear: true,
                        dateFormat: jqueryDateFormat,
                        timeFormat: jqueryTimeFormat
                    });
                    if (data.enforceDateBeforeToday()) {
                        // Max date allowed is today
                        $(element).find('input').datetimepicker("option", "maxDate", new Date());
                    } else if (data.enforceDateAfterToday()) {
                        // Min date allowed is today
                        $(element).find('input').datetimepicker("option", "minDate", new Date());
                    }
                } else if (data.controlType === "Computed" && !data.readOnly()) {
                    data.warned = false;
                    data.onKeyUp = function(event) {
                        //stop listening if a normal character is entered
                        if (event.charCode < maxASCIICharNum) {
                            data.value(event.target.value);
                            data.eventManager.stopListening();
                            if (!data.warned) {
                                var computedFormGroup = $('#' + data.id)[0].parentNode.parentNode;
                                var input = $('#' + data.id)[0];
                                $(input).attr('title', window.localize("modules.formSupport.warningTheComputedFunctionality"));
                                $(input).tooltip('show');
                                $(computedFormGroup).addClass(" has-warning has-feedback");
                                data.warned = true;
                            }
                        }
                    };

                    $('#' + data.id).bind('keyup', data.onKeyUp);

                }
                //fix stupid IE8
                else if (data.controlType === "DropDown") {
                    //for ie8 select display
                    if (navigator.userAgent.match(/MSIE\s((6.0)|(7.0)|(8.0))/)) {
                        var el;
                        $(element).find("select").each(function() {
                            el = $(this);
                            el.data("origWidth", el.outerWidth());
                        }).mouseenter(function() {
                            $(this).css("width", "auto");
                        }).bind("blur change", function() {
                            el = $(this);
                            el.css("width", el.data("origWidth"));
                        });
                    }
                } else if (data.controlType === "DateSearch" || data.controlType === "DatetimeSearch") {

                    var toElement = $(element).find("#" + data.id + "to");
                    var fromElement = $(element).find("#" + data.id + "from");

                    if (data.controlType === "DateSearch") {
                        // Allow any date
                        toElement.datepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: jqueryDateFormat,
                            onClose: function(selectedDate) {
                                if (data.controlType === "DateSearch") {
                                    if (data.enforceDateBeforeToday()) {
                                        $(element).find("#" + data.id + "from").datepicker("option", "maxDate", new Date());
                                    } else {
                                        $(element).find("#" + data.id + "from").datepicker("option", "maxDate", selectedDate);
                                    }
                                } else {
                                    $(element).find("#" + data.id + "from").datetimepicker("option", "maxDate", selectedDate);
                                }
                            },
                            onSelect: function() {
                                $(this).change();
                            }
                        });

                        if (data.enforceDateBeforeToday()) {
                            // Max date allowed is today
                            toElement.datepicker("option", "maxDate", new Date());
                        } else if (data.enforceDateAfterToday()) {
                            // Min date allowed is today
                            toElement.datepicker("option", "minDate", new Date());
                        }
                    } else { // Control type is DatetimeSearch
                        toElement.datetimepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: jqueryDateFormat,
                            timeFormat: jqueryTimeFormat,
                            onClose: function(selectedDate) {
                                if (data.controlType === "DateSearch") {
                                    $(element).find("#" + data.id + "from").datepicker("option", "maxDate", selectedDate);
                                } else {
                                    $(element).find("#" + data.id + "from").datetimepicker("option", "maxDate", selectedDate);
                                }
                            },
                            onSelect: function() {
                                $(this).change();
                            }
                        });

                        if (data.enforceDateBeforeToday()) {
                            // Max date allowed is today
                            toElement.datetimepicker("option", "maxDate", new Date());
                        } else if (data.enforceDateAfterToday()) {
                            // Min date allowed is today
                            toElement.datetimepicker("option", "minDate", new Date());
                        }
                    }

                    if (data.controlType === "DateSearch") {
                        fromElement.datepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: jqueryDateFormat,
                            onClose: function(selectedDate) {
                                if (data.controlType === "DateSearch") {
                                    if (data.enforceDateBeforeToday()) {
                                        $(element).find("#" + data.id + "to").datepicker("option", "maxDate", new Date());
                                    }
                                    $(element).find("#" + data.id + "to").datepicker("option", "defaultDate", selectedDate);
                                    $(element).find("#" + data.id + "to").datepicker("option", "minDate", selectedDate);
                                    //start the to date picker at the same date
                                    $(element).find("#" + data.id + "to").datepicker("option", "defaultDate", selectedDate);
                                } else {
                                    if (data.enforceDateBeforeToday()) {
                                        $(element).find("#" + data.id + "to").datetimepicker("option", "maxDate", new Date());
                                    }
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "defaultDate", selectedDate);
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "minDate", selectedDate);
                                    //start the to date picker at the same date
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "defaultDate", selectedDate);
                                }
                            },
                            onSelect: function() {
                                $(this).change();
                            }
                        });

                        if (data.enforceDateBeforeToday()) {
                            fromElement.datepicker("option", "maxDate", new Date());
                        } else if (data.enforceDateAfterToday()) {
                            fromElement.datepicker("option", "minDate", new Date());
                        }
                    } else { // Control type is DatetimeSearch
                        fromElement.datetimepicker({
                            yearRange: "c-65:c+13",
                            changeMonth: true,
                            changeYear: true,
                            dateFormat: jqueryDateFormat,
                            timeFormat: jqueryTimeFormat,
                            onClose: function(selectedDate) {
                                if (data.controlType === "DateSearch") {
                                    $(element).find("#" + data.id + "to").datepicker("option", "defaultDate", selectedDate);
                                    $(element).find("#" + data.id + "to").datepicker("option", "minDate", selectedDate);
                                    //start the to date picker at the same date
                                    $(element).find("#" + data.id + "to").datepicker("option", "defaultDate", selectedDate);
                                } else {
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "defaultDate", selectedDate);
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "minDate", selectedDate);
                                    //start the to date picker at the same date
                                    $(element).find("#" + data.id + "to").datetimepicker("option", "defaultDate", selectedDate);
                                }
                            },
                            onSelect: function() {
                                $(this).change();
                            }
                        });

                        if (data.enforceDateBeforeToday()) {
                            fromElement.datetimepicker("option", "maxDate", new Date());
                        } else if (data.enforceDateAfterToday()) {
                            fromElement.datetimepicker("option", "minDate", new Date());
                        }
                    }
                } else if (data.controlType === "AutoComplete") {

                    //store typeahead reference on the control so
                    //the list of items can be updated later
                    var options = {
                        minLength: 1,
                        highlight: true
                    }; //must provide all defaults because an issue with the no conflict
                    if (data.asyncEnabled && !data.lookupValuesEnabled()) {
                        options.minLength = data.minCharBeforeQuery; 
                    }
                    if (data.lookupValuesEnabled()) {
                        options.hint = false;
                    }
                    //hacking in typeahead plugin styles for consistancy
                    var searchResultTemplate = Handlebars.compile('<p class="list-group-item typeahead-result typeahead-item" data-value="{{value}}">{{label}}</p>');

                    var noResultTemplate;
                    if (data.isGrowable) {
                        noResultTemplate = Handlebars.compile('<p class="list-group-item typeahead-item">' + window.localize("modules.formSupport.sorryNoOptionsFound") + ' Click <b>Add</b> to add.</p>');
                    } else {
                        noResultTemplate = Handlebars.compile('<p class="list-group-item typeahead-item">' + window.localize("modules.formSupport.sorryNoOptionsFound") + '</p>');
                    }


                    data.$el = $('#' + data.id + data.uuid);
                    data.typeahead = data.$el.typeahead(options, {
                        name: 'formsupport',
                        displayKey: 'label',
                        source: data.getSource,
                        templates: {
                            empty: noResultTemplate,
                            suggestion: searchResultTemplate
                        }
                    });

                    if (data.displayLabel && data.displayLabel()) {
                        data.typeahead.typeahead("val", data.displayLabel());
                    }

                    //when the input is cleared we need to fire the set set selection
                    data.$el.change(function() {
                        //we want the normal flow of events to happen unless the text box is blank
                        //ie cleared. If that happens we have to trigger a set selection by label
                        data.setSelectionByLabel(data.$el.val());
                    });
                    if (data.isRepeating) {
                        data.typeahead.on('typeahead:selected', function(evt, selectedItem) {
                            data.setSelectionByLabel(selectedItem.label);
                            //clear the input box when a user selects a value
                            data.typeahead.typeahead('val', '');
                        });
                        data.typeahead.on('typeahead:autocompleted', function(evt, selectedItem) {
                            data.setSelectionByLabel(selectedItem.label);
                            //clear the input box when a user selects a value
                            data.typeahead.typeahead('val', '');
                        });
                    } else {
                        data.typeahead.on('typeahead:selected', function(evt, selectedItem) {
                            data.setSelectionByLabel(selectedItem.label);
                        });
                        data.typeahead.on('typeahead:autocompleted', function(evt, selectedItem) {
                            data.setSelectionByLabel(selectedItem.label);
                        });

                        if (data.picklistItemsArr().length > 0) {
                            if (data.value()) {
                                var setValIfExists = function() {
                                    var objInPicklist = _.findWhere(data.picklistItemsArr(), { value: data.value() });
                                    //We need to do this check because if the value has changed for an async picklist, the picklist
                                    //will be fetched.  An object with blank strings as value and lable is pushed on the picklist by default
                                    //so we will want to make sure that there actually is a meaningful value here, instead of assuiming there
                                    //will always be one.
                                    if (objInPicklist && objInPicklist.label) {
                                        data.typeahead.typeahead("val", objInPicklist.label);
                                    }
                                };
                                //only bother to set the val when the picklist has fully loaded; not always the case
                                //(for example, async picklists)
                                if (data.picklistLoadDeferred) {
                                    data.picklistLoadDeferred.done(setValIfExists);
                                } else {
                                    setValIfExists();
                                }
                            }
                        }
                    }

                    if (data.isGrowable) {
                        $(document).on('mousedown', 'ul.typeahead', function(e) {
                            e.preventDefault();
                        });
                    }
                    if (data.lookupValuesEnabled()) {
                        //helper function that will call setShadowValue on whatever the typeahead is populated with
                        var setShadowValueToTypeahead = function() {
                            data.setShadowValue(data.displayLabel());
                        };
                        $(document).on("typeahead:autocompleted", "#" + data.id + data.uuid, setShadowValueToTypeahead);
                        $(document).on("typeahead:selected", "#" + data.id + data.uuid, setShadowValueToTypeahead);
                        data.setLookupTypeaheadCSS();

                        //load any initial value populated from the URL
                        data.setShadowValue(data.value());

                        data.lookupValues = function() {
                            //set the "parent" elm into focus, to trigger the actual typeahead
                            //autocomplete behavior.
                            $("#" + data.id + data.uuid).focus();
                        };

                        data.removeLookupValues = function() {
                            data.value(null);
                            data.$el.val("");
                            data.typeahead.typeahead("val", "");
                            //force mutation, in case that no value was entered,
                            //but was wiped anyway(ie. didn't select a value)
                            data.value.valueHasMutated();
                        };

                        //each time the "parent" elm gets focus (on lookup),
                        //we want to make sure the lookup value is successfully loaded immediately. 
                        $("#" + data.id + data.uuid).focus(function(e) {
                            var valToLookup = $("#" + "shadow" + data.id + data.uuid).val();
                            if (!valToLookup) {
                                return;
                            }
                            e.stopPropagation();
                            data.typeahead.typeahead("val", valToLookup);
                        });
                        //make sure we know when the first & correct value and display label combo is loaded
                        //rather than just the value; necessary to have this for first load
                        //as the picklist will -not- have loaded by now. 
                        var setDisplayValueForShadow = function() {
                            data.loadPicklist(data.value()).done(function() {
                                data.loadDisplayLabel(data.value());
                                data.setShadowValue(data.displayLabel());
                            });
                        };

                        if (data.picklistDeferred) {
                            data.picklistDeferred.done(setDisplayValueForShadow);
                        } else {
                            setDisplayValueForShadow();
                        }

                        var initSubscription = data.value.subscribe(function(initVal) {
                            // First value change will be to clear the values so ignore that
                            if(initVal){
                                data.picklistDeferred.done(function() {
                                    data.loadPicklist(initVal).done(function() {
                                        data.loadDisplayLabel(initVal);
                                        setShadowValueToTypeahead();
                                    });
                                });
                                initSubscription.dispose();
                            }
                        });

                        //on future changes, change label:
                        data.value.subscribe(function() {
                            data.setShadowValue(data.displayLabel());
                        });
                        
                        $(document).on("click", "#lookup" + data.id + data.uuid, data.lookupValues);
                        $(document).on("click", "#delete" + data.id + data.uuid, data.removeLookupValues);
                    }
                }
            };

            // we only want to prepopulation the form in the action viewer
            if (Backbone.history.location.pathname.indexOf("/Action/") !== -1) {
                // pull off the properties set on the url and pass them along to setValues
                // this functionality is only supported for actions that use blank forms (bulk upload and folder notes). Properties populated from OC take priority over url properties
                var urlParamsString = Backbone.history.location.search; // returns the params on the url
                if (urlParamsString) {
                    var urlParams = $.deparam(urlParamsString.substring(1)); // don't include the ?
                    var folderActionParam = urlParams.folderActionId;
                    delete urlParams.folderActionId; // remove folder action id off the params, this skips if it doesnt exist

                    if (JSON.stringify(urlParams) !== "{}") { // has other url params for setting on the form
                        viewModel.setValues(urlParams);

                        // update the url to remove the params pulled in, keep folderActionId if existed on url
                        var newURI = Backbone.history.location.pathname.substring(app.root.length-1);
                        if (folderActionParam) {
                            newURI = newURI + "?folderActionId=" + folderActionParam;
                        }
                        app.trigger("actionService:updateURI", newURI);
                        Backbone.history.navigate(newURI, {replace: true});

                    }
                }
            }
        };

        //FORMs
        Formsupport.modelForm = function() {
            //we declare this as var so it is not visible on the form object
            var abstractFormControl = function(config, eventManager) {
                var that = {};

                that.forceNullObservable = function(obs) {
                    return ko.computed({
                        read: function() {
                            return obs();
                        },
                        write: function(val) {
                            if (!val) {
                                //!val will cover empty string, undefined, null, and empty array. making them all null
                                val = null;
                            }
                            obs(val);
                        }
                    });
                };

                that.showPositionData = ko.observable(false);
                that.label = window.localize(config.get("label"));
                that.controlType = config.get("controlType");
                that.dataType = config.get("dataType");
                that.id = config.get("ocName");
                that.uuid = new Date().valueOf(); //sometimes for dom id purposes this is useful //IE<IE9 don't support Date.now()
                that.readOnly = ko.observable();
                that.visibilityDependencyValid = ko.observable();
                that.enableDependencyValid = ko.observable();
                that.helptext = ko.observable(config.get("helptext"));
                that.helptextEnabled = ko.observable(config.get("helptext") !== "");
                that.isExternalRuleValid = ko.observable(true);
                that.isExternalValidationRunning = ko.observable(false);
                that.delimitedListSelectEnabled = ko.observable(config.get("delimitedListSelectEnabled"));
                that.listDelimiter = config.get("listDelimiter");

                //If no label is set, use the id instead.
                if (!that.label) {
                    that.labelOrId = that.id;
                } else {
                    that.labelOrId = that.label;
                }

                //both repo-editable and form-configured to be editable
                if (config.get("formEditable") && config.get("editable")) {
                    that.readOnly(false);
                } else {
                    that.readOnly(true);
                }

                if (config.get('appendOnly')) {
                    that.isAppendOnly = true;
                }

                that.sortRepeatingAttrs = config.get('sortRepeatingAttrs');

                if(that.sortRepeatingAttrs) {
                    that.valuesToPrependWhenSorting = config.get("valuesToPrependWhenSorting");
                }

                if (config.get("repeating")) {

                    that.isRepeating = true;
                    //repeating placeholder shows the values in value array
                    that.repeatingPlaceholder = ko.observable();
                    that.value = ko.observableArray();
                    that.value(null);
                    that.value.destroy = function () {
                        that.value = undefined;
                    };
                    //Adds values to repeatable attributes when clicked off text box
                    that.addValueOnBlur = function (value) {
                        if (that.isSearchMode()) {
                            that.addValue(value);
                        }
                        return true;
                    };

                    that.checkForEnter = function (data, event) {
                        if (that.isSearchMode) {
                            if (event.which == 13) {
                                data.repeatingPlaceholder(event.currentTarget.value);
                                that.addValue(data);
                            }
                        }
                        return true;
                    };
                    //repeating values need two extra functions for adding and removing from value
                    that.addValue = function (formControl) {
                        //don't add anything if it already exists in value, make sure that
                        //only whitespace is not entered, and ensure the value is properly
                        //trimmed when added to the array
                        if (_.indexOf(that.value(), formControl.repeatingPlaceholder()) < 0 &&
                            formControl.repeatingPlaceholder() &&
                            $.trim(formControl.repeatingPlaceholder()) !== "") {

                            if (!that.value()) {
                                //if that.value doesnt exist, we need it to.
                                that.value([]);
                            }

                            that.value.push($.trim(formControl.repeatingPlaceholder()));
                            if (that.sortRepeatingAttrs) {
                                Formsupport.Utils.sortAndPrepend(that.value(), that.valuesToPrependWhenSorting);
                            }
                            that.value.valueHasMutated();
                        }
                        formControl.repeatingPlaceholder("");
                    };

                    that.removeValue = function (item) {
                        that.value.remove(item);
                        if (that.value().length === 0) {
                            //if were empty now, lets null out
                            that.value(null);
                        }

                    };
                } else {
                    that.isRepeating = false;
                    that.value = ko.observable();
                }
                if (config.get("required")) {
                    that.required = true;
                    that.configRequired = true;
                } else {
                    that.required = false;
                    that.configRequired = false;
                }
                if (config.get("growable")) {
                    that.isGrowable = true;
                } else {
                    that.isGrowable = false;
                }
				//default to minimum number of characters if it can't be parsed or is less than zero
                if(config.get("minCharBeforeQuery") !== undefined){
                    that.minCharBeforeQuery = isNaN(parseInt(config.get("minCharBeforeQuery"))) ? app.minCharBeforeQuery : parseInt(config.get("minCharBeforeQuery"));
                    if(that.minCharBeforeQuery <= 0) {
                        that.minCharBeforeQuery = app.minCharBeforeQuery;
                    }
                }
                if (config.get('autoSelect')) {
                    that.isAutoSelect = true;
                } else {
                    that.isAutoSelect = false;
                }

                if (config.get('hidden')) {
                    that.isHidden = true;
                } else if (config.get('hideWhenNoAspect')) {
                    if (!config.get('appliedAspects') ||config.get('appliedAspects').length < 1) {
                        that.isHidden = true;
                    } else if (config.get('appliedAspects').indexOf(config.get('parentAspect')) > -1) {
                        that.isHidden = false;
                    } else {
                        that.isHidden = true;
                    }
                } else {
                    that.isHidden = false;
                }

                if (config.get("allowDropdown")) {
                    that.allowDropdown = true;
                } else {
                    that.allowDropdown = false;
                }

                if (config.get("isWysiwyg")) {
                    that.isWysiwyg = true;
                } else {
                    that.isWysiwyg = false;
                }

                if (config.get('isSearchMode')) {
                    that.isSearchMode = ko.observable(true);
                } else {
                    that.isSearchMode = ko.observable(false);
                }

                if (config.get("picklist")) {
                    that.picklistName = config.get("picklist");
                }
                if (config.get("computedPattern")) {
                    that.pattern = config.get("computedPattern");
                }
                that.value.subscribe(function(newValue) {
                    // Make sure the text the user types obeys the sterilization rules
                    if (that.id === "objectName" && !that.isSearchMode()) {
                        app.context.configService.getApplicationConfig(function (configs) { 
                            if (configs.attributes.shouldSterilizeFilenames === "true") { 
                                that.value(tsgUtils.sterilizeFilename(newValue, configs.attributes));
                            }                    
                        });
                    }
                
                    var emptyValue = false;
    
                    if (that.isRepeating) {
                        if (_.isEmpty(newValue) || newValue[newValue.length - 1] === "") {
                            emptyValue = true;
                        }
                    } else {
                        if (newValue === "") {
                            emptyValue = true;
                        }
                    }
    
                    if (!emptyValue && config.get("externalRules") && config.get("externalRules").length > 0) {
                        that.isExternalValidationRunning(true);
                    }
    
                    if (that.dataType === "boolean" && _.isBoolean(newValue)) {
                        that.value(newValue);
                    } else if (config.get("upperCase")) {
                        if(newValue) {
                            if(Array.isArray(newValue) && that.isRepeating) {
                                for(var i = 0; i < newValue.length; i++) {
                                    newValue[i] = newValue[i].toUpperCase();
                                }
                            } else {
                                that.value(newValue.toUpperCase());
                            }
                        }
                    }
                    if ((that.dataType === "double" || that.dataType === "integer") && newValue === "") {
                        that.value(null);
                    }
    
                    eventManager.trigger("fs:change:" + that.id, newValue, that);
                    eventManager.trigger("fs:change", newValue, that);
                    
                });
  
                // This field depends on another field to be enabled, disable it until other field is changed to "true" 
                if (config.get('enableDependent')) {
                    that.enableDependencyValid(false);
                } else {
                    that.enableDependencyValid(true);
                }

                if (config.get('enableDependent') && config.has('enableDependentAttr') && config.get('enableDependentAttrVal')) {
                    eventManager.listenTo(eventManager, 'fs:change:' + config.get('enableDependentAttr'), function(newValue) {
						// The field that this control depends for determining whether or not the control is enabled has changed.
						// Use the helper function processDependentField to determine whether or not the newValue is valid
                        Formsupport.Utils._processDependentField(that, that.enableDependencyValid, newValue, 'enableDependentAttrVal', config);
                    });
                }

                // This field depends on another field to be shown, hide it until the other field is changed to be truthy
                if (config.get('visibilityDependent')) {
                    that.visibilityDependencyValid(false);
                } else {
                    that.visibilityDependencyValid(true);
                }

                if (config.get('visibilityDependent') && config.has('visibilityDependentAttr') && config.has('visibilityDependentAttrVal')) {
                    eventManager.listenTo(eventManager, 'fs:change:' + config.get('visibilityDependentAttr'), function(newValue) {
                        // The field that this control depends for determining whether or not the control is visible has changed.
						// Use the helper function processDependentField to determine whether or not the newValue is valid
						Formsupport.Utils._processDependentField(that, that.visibilityDependencyValid, newValue, 'visibilityDependentAttrVal', config);
                    });
                }
            
                if(config.get('lock')){
                    //lockgroups = configed groups
                    //lockauth = require auth checkbox
                    //authsuccess = boolean for login success
                    that.isLocked = true;
                    var lockedGroups = config.get("allowedUnlockGroups").split(",");

                    if(config.get("lockAuth")){
                        that.lockAuthRequired = true;
                    }
                    
                    //boolean to show/hide the lock button used in the view
                    //if a user is not a member of one or more of the configured groups
                    //the lock button will not be shown and the field will be set to read only
                    that.showLockButton = false;
                
                    app.user.getGroups().done(function() {
                        //compare configured groups with groups user is in
                        if (_.intersection(lockedGroups, app.user.get("groupNames")).length > 0) {
                            //tell the view that the lock button needs to be shown
                            that.showLockButton = true;
                        }else{
                            that.showLockButton = false;
                        }
                    });

                    that.alertAuth = function(formControl) {
                    
                        app.listenTo(app, "alert:authSuccess", function(options){
                            formControl.authSuccess = options.authSuccess;
                            //unlocks the currently locked field
                            formControl.isLocked = false;
                            formControl.readOnly(false);

                            //ensure all active listeners are cleaned up
                            app.stopListening(app, "alert:authSuccess");
                            app.stopListening(app, "alert:authentication");
                        });

                        if(formControl.lockAuthRequired && !formControl.authSuccess){
                            //prompt with modal to confirm removal
                            app.trigger("alert:authentication", {
                                message: "",
                                header: "Login",
                                confirm: function(){
                                    return;
                                }
                            });
                        } else{
                            // if auth not required, skip direct to this trigger as if 
                            // auth was successful
                            app.trigger("alert:authSuccess", {
                                authSuccess : true
                            });
                        }
                    };
                } else{
                    that.isLocked = false;
                    that.showLockButton = false;
                }

                if (config.get("externalRules") && config.get("externalRules").length > 0) {
                    that.externalRules = config.get("externalRules");

                    var message;
                    if (config.get("failureMessage")) {
                        message = config.get("failureMessage");
                    } else {
                        message = window.localize("modules.formSupport.thisAttributeMustHave");
                    }

                    if (config.get("clearInvalidValueEnabled")) {
                        that.clearInvalidValueEnabled = config.get("clearInvalidValueEnabled");
                    } else {
                        that.clearInvalidValueEnabled = false;
                    }

                    that.value.extend({
                        validation: {
                            validator: _.debounce(validateExternalRule, 1500),
                            message: message,
                            params: that,
                            async: true
                        }
                    });
                }

                //helper function to clear the value loaded into the control, be it multivalued or singlevalued
                that.clearValue = function() {
                    if (that.isRepeating) {
                        if (that.value() && that.value().length > 0) {
                            that.value.removeAll();
                        }
                    } else {
                        that.value("");
                    }
                };

				// Setting up delimited list functionality if it is enabled
                if (that.delimitedListSelectEnabled()) {
                    that.selectValuesFromDelimitedList = function() {
                        // Instantiate a DelimitedListSelectionView
                        var delimitedListSelectionView = new Formsupport.DelimitedListSelectionView({control: that});

                        // Trigger the popoverHandler to show the view
                        app.popoverHandler.trigger("show", {
                            view: delimitedListSelectionView,
                            title: window.localize("modules.formSupport.delimitedList.popover.title") + that.listDelimiter,
                            size: 'small'
                        });
                    };
                }

                //Location metadata preserving keys/functions
                that._preserveLocationData = false;
                that.setValuePreserveLocationData = function(newValue) {
                    that._preserveLocationData = true;
                    that.value(newValue);
                    that._preserveLocationData = false;
                };

                that.setDatePreserveLocationData = function(newDate) {
                    that._preserveLocationData = true;
                    that.dateDisplay(newDate);
                    that._preserveLocationData = false;
                };

                that.preserveLocationData = function() {
                    return that._preserveLocationData;
                };

                return that;
            };

            var dateBoxFormControl = function(config, eventManager) {
                //just add the dateFormat to the object created
                //in the abstractFormControl() method
                var that = abstractFormControl(config, eventManager);
                that.dateFormat = config.get("dateFormat");
                that.timeFormat = config.get("timeFormat");
                that.timezoneFormat = config.get("timezoneFormat");
                that.canTypeInBox = config.get("canTypeInBox");
                that.enforceDateBeforeToday = ko.observable(config.get("enforceDateBeforeToday"));
                that.enforceDateAfterToday = ko.observable(config.get("enforceDateAfterToday"));
                that.displayFormat = window.localize("modules.formSupport.dateFormat") + that.dateFormat;
                // Variables for date validation
                that.invalidTypeableDateString = window.localize("modules.formSupport.pleaseEnterADateInThe") + config.get("dateFormat");
                that.enforceDateBeforeTodayString = window.localize("modules.formSupport.pleaseEnterADatePrior");
                that.enforceDateAfterTodayString = window.localize("modules.formSupport.pleaseEnterADateAfter");
                that.showDateValidation = ko.observable(false);
                that.dateMessage = ko.observable();
                
                if (that.timeFormat) {
                    that.displayFormat += " " + that.timeFormat;
                    that.invalidTypeableDateString += " " + that.timeFormat;
                }
                that.getIsoDate = function(formattedDate) {
                    var isoDateVar, trueOffset;
                    if (that.controlType === "DateBox" || that.controlType === "DateSearch") {
                        if (!that.timezoneFormat) {
                            isoDateVar = moment(formattedDate, that.dateFormat, true);
                            if (isoDateVar.isValid()) {
                                isoDateVar = moment(formattedDate, that.dateFormat, true).toDate().getTime();
                            } else {
                                isoDateVar = undefined;
                            }
                        } else {
                            trueOffset = moment(formattedDate, that.dateFormat, true).utcOffset() - moment(formattedDate, that.dateFormat).tz(that.timezoneFormat).utcOffset();
                            isoDateVar = moment(formattedDate, that.dateFormat, true);
                            if (isoDateVar.isValid()) {
                                isoDateVar = moment(formattedDate, that.dateFormat, true).utcOffset(trueOffset)._d.getTime();
                            } else {
                                isoDateVar = undefined;
                            }
                        }
                    } else {
                        if (!that.timezoneFormat) {
                            isoDateVar = moment(formattedDate, that.dateFormat + " " + that.timeFormat, true);
                            if (isoDateVar.isValid()) {
                                isoDateVar = moment(formattedDate, that.dateFormat + " " + that.timeFormat, true).toDate().getTime();
                            } else {
                                isoDateVar = undefined;
                            }

                        } else {
                            isoDateVar = moment(formattedDate, that.dateFormat + " " + that.timeFormat, true);
                            trueOffset = isoDateVar.utcOffset() - isoDateVar.tz(that.timezoneFormat).utcOffset();

                            if (isoDateVar.isValid()) {
                                isoDateVar = isoDateVar.utcOffset(trueOffset)._d.getTime();
                            } else {
                                isoDateVar = undefined;
                            }
                        }
                    }
                    return isoDateVar;
                };
                return that;
            };

            var pickListEnabledFormControl = function(config, eventManager, disableDefaults, isReadOnly, isAttributeDeletable) {
                // in order to work with backwards compatablilty where the dependsOn attribute was a string we
                // need to convert it to an array if it wasn't already
                if (config.get("dependsOn") && !(config.get("dependsOn") instanceof Array)) {
                    var curDependsOn = config.get("dependsOn");
                    config.set("dependsOn", [curDependsOn]);
                }

                var that = abstractFormControl(config, eventManager);
                that.loading = ko.observable(false); //show spinner when loading items

                if (isAttributeDeletable) {
                    that.isAttributeDeletable = isAttributeDeletable;
                }

                // this is NOT an async call, simply checks the context for the current picklist config
                that.picklistConfig = app.context.picklistService.getPicklistConfig(that.picklistName);
                that.asyncEnabled = that.picklistConfig.get("async");
                that.picklistItemsArr = ko.observableArray();
                that.defaultValues = ko.observableArray();
                that.selectAllEnabled = ko.observable(config.get("selectAllEnabled"));
                that.lookupValuesEnabled = ko.observable(that.picklistConfig.get("lookupValues"));
                //make default values work without making the picklist look wonky (technical term)
                //and still have a blank option
                //aslo, default values will NOT work in the search page
                that.picklistItemsArr.subscribe(function() {
                    // if the enableDependency is configured off or configured on and valid, use the default values
                    if (that.enableDependencyValid()) {
                        if (that.defaultValues && that.defaultValues() && that.defaultValues().length > 0 && 
                                that.defaultValues()[0] && !that.isRepeating && !that.value() && that.value() !== false && that.value() !== 0 && !disableDefaults) {
                            that.value(that.defaultValues()[0]);
                        } else if (that.defaultValues && that.defaultValues() && that.defaultValues().length > 0 && 
                                that.isRepeating && that.value() && that.value().length > 0 && !disableDefaults) {
                            that.value(that.defaultValues());
                        }
                    } else if (that.dataType === "boolean") {
                        // else if boolean default to false
                        that.value(false);
                    }
                });
                
                that.loadPicklist = function(query) {
                    //If we have a dropdown picklist enabled, we only want/need to reload the picklist once, not on every click.
                    if (!config.get("allowDropdown") || (!that.loaded && !that.loading())) {
                        that._latestValue = that.value();
                        if (that.loading()) {
                            return that.picklistDeferred;
                        }
                        that.loading(true);
                        var tokens = that.tokens || {};
                        //Need to check if query exists & is a string (used with async picklists)
                        //otherwise, query is always getting pushed onto tokens when not needed
                        if (query && _.isString(query)) {
                            tokens.query = query;
                        }
                        if (that.asyncEnabled && that.$el !== undefined) {
                            that.setReadOnlyProperty(true);

                        }

                        that.picklistDeferred = app.context.picklistService.getPicklist(that.picklistName, function(data, defaultValues) {

                            if (that.reload) {
                                that.reload = false;
                                that.loading(false);
                                that.loadPicklist();
                            } else {
                                //sometimes the change event of a picklist something is dependent on is hit BEFORE the value.subscribe of the
                                //dependant value, meaning the _latestValue was originally set with nothing. check and see is value()
                                //has something now if _latestValue is nothing
                                if (that.value() && that.value().length) {
                                    var defaultValuesExist = defaultValues && defaultValues.length > 0 ? true : false;

                                    if (!that._latestValue || that._latestValue.length === 0 ||
                                        (defaultValuesExist && !_.isArray(that._latestValue) && that._latestValue === defaultValues[defaultValues.length - 1]) || // Always compare to the last item of defaults.
                                        (defaultValuesExist && _.isArray(that._latestValue) && _.isEqual(that._latestValue, defaultValues))) {
                                        that._latestValue = that.value();
                                    }
                                }

                                that.defaultValues(defaultValues);
                                that.picklistItemsArr().length = 0;
                                _.each(data, function(item) {
                                    item.label = window.localize(item.label);
                                    that.picklistItemsArr().push(item);
                                });

                                //repeating attributes that don't use a repeating control need
                                //to use just the first value in the array to compare
                                if (!that.isRepeating && that._latestValue && _.isArray(that._latestValue) && that._latestValue.length > 0) {
                                    that._latestValue = that._latestValue[0];
                                }


                                //This block of code will set/unset value based on the values in our new picklist
                                if (!that.isRepeating) {
                                    if (!that.isGrowable) {
                                        //we have a non-growable, non-repeating control
                                        //we need to find our current value in our picklist
                                        //if it exists
                                        if (!_.find(that.picklistItemsArr(), function(item) { return item.value === that._latestValue; })) {
                                            //we didn't find our value in the picklist
                                            //check if the value is equal to the original value, if it is we add that to the picklist
                                            if (that.origValue && that._latestValue === that.origValue) {
                                                if (!that.asyncEnabled) {
                                                    var newPickListMember = { label: that.origValue, value: that.origValue };
                                                    that.picklistItemsArr().push(newPickListMember);
                                                    that.value(that._latestValue);
                                                }
                                            } else {
                                                //clear out the value
                                                that.value(undefined);
                                            }

                                        } else {
                                            //we found our value in the picklist!
                                            // set value
                                            if (config.get("dependsOn").length > 0 || !that.asyncEnabled) {
                                                that.value(that._latestValue);
                                            } else {
                                                that.loading(false);
                                                return;
                                            }

                                        }
                                    } else {
                                        //we have a growable control, so always set value
                                        that.value(that._latestValue);
                                    }
                                } else {
                                    if (!that.isGrowable) {
                                        //we have a non-growable, repeating control
                                        //we need to find our current values in our picklist
                                        //if they exist

                                        var valArray = [];
                                        _.each(that._latestValue, function(item) {
                                            //we try to find if the value is in the picklist. if it is we add it to valArray.
                                            if (_.find(that.picklistItemsArr(), function(newItem) { return item === newItem.value; })) {
                                                valArray.push(item);
                                            } else {
                                                if (that.origValue && !that.isAutoSelect && _.find(that.origValue, function(newItem) { return item === newItem; })) {
                                                    var newPickListMember = { label: item, value: item };
                                                    that.picklistItemsArr().push(newPickListMember);
                                                    valArray.push(item);
                                                } else if (that.asyncEnabled) {
                                                    // if it's an async picklist chances are it won't be in the newly fetched picklistItemsArr
                                                    valArray.push(item);
                                                }
                                            }

                                        });

                                        //when we are loading the picklist, we shouldn't be setting anything to the value unless something was
                                        //actually found, since it kicks off the value.subscribe which runs other logic like validation
                                        if (!_.isEmpty(valArray)) {
                                            that.value(valArray);
                                        }


                                    } else {
                                        //this is a growable picklist control, so just slap our
                                        //old values back in there
                                        that.value(that._latestValue);
                                    }

                                }

                                //no matter what. always clear out that._latestValue
                                that._latestValue = undefined;

                                // if picklist has one value and attribute is required, autopopulate value
                                if (that.picklistItemsArr().length === 2 && that.required) {
                                    if (!that.isRepeating) {
                                        that.value(that.picklistItemsArr()[1].value);
                                    } else {
                                        that.value([that.picklistItemsArr()[1].value]);
                                    }
                                }

                                // check and see if auto select is on, if so auto populate the value with all the picklist options
                                if (that.isAutoSelect) {
                                    // if not repeating, just use first option
                                    if (!that.isRepeating) {
                                        if (that.picklistItemsArr().length > 1) {
                                            that.value(that.picklistItemsArr()[1].value);
                                        }
                                    } else {
                                        that.value(_.map(that.picklistItemsArr(), function(item) {
                                            if (item.value) {
                                                return item.value;
                                            }
                                        }));
                                    }
                                }

                                that.picklistItemsArr.valueHasMutated();
                                that.loading(false);
                                that.loaded = true;
                                var parentWidth = $(that.$el).parents(".typeahead-group").width();
                                $(".typeahead-dropdown").css({ "min-width": parentWidth });
                            }

                        }, tokens);

                        if (that.picklistDeferred) {
                            that.picklistDeferred.done(function() {
                                if (that.asyncEnabled && that.$el !== undefined) {
                                    that.setReadOnlyProperty(false);
                                }

                            });
                        }


                        return that.picklistDeferred;

                    } else {
                        return that.picklistDeferred;
                    }
                };

                that.setReadOnlyProperty = function(readonlyBoolean) {
                    that.$el.prop('readonly', readonlyBoolean);
                };

                if (config.get("dependsOn").length > 0) {
                    that.cb = function() {
                        //if we're not loaded, but loading just blow off the change
                        if (!that.loaded && that.loading()) {
                            that.reload = true;
                        }

                        // Check to see if we should set readOnly to false or true
                        if ((disableDefaults || (config.get("formEditable") && config.get("editable"))) && !isReadOnly) {
                            that.readOnly(false);
                        } else {
                            that.readOnly(true);
                        }

                        that.clearValue();
                        that.loaded = false; // if we were loaded now we're not since we have new dependecies

                        eventManager.listenToOnce(eventManager, 'fs:allValues', function(allValues) {
                            that.tokens = allValues;

                            // iterate over that.tokens
                            // if there is a repeating attribute, tokenize and comma separate them for the query.
                            _.each(that.tokens, function(value, key) {
                                if (_.isArray(value) && value.length > 0) {
                                    that.tokens[key] = "";

                                    _.each(value, function(value) {
                                        // Put each value in single quotes so it can be use in a query's IN statement.
                                        that.tokens[key] += "'" + value + "',";
                                    });

                                    // Remove the extra comma
                                    that.tokens[key] = that.tokens[key].substr(0, that.tokens[key].length - 1);
                                }
                            });

                            var dependantFieldsValid = Formsupport.Utils._validateDependantFieldsHelper(config, allValues);

							// readOnly should be true when dependant fields are not valid or the config says so
							// the case where a field IS read only (non-editable) and dependent fields are valid is covered since the dependent 
                            // fields should inherit from the parent read only property
                            if (!that.readOnly() && !dependantFieldsValid) {
                                that.readOnly(true);
                            }
                                                
                            // Check that the dependsOn fields are all valid before we load the picklist 
                            if (!that.reload && dependantFieldsValid) {
                                that.loadPicklist();
                            }
                        });
                        
                        eventManager.trigger("fs:requestingAllValues");

                    };
                    
                    // Disable the input until the dependecies are fufilled
                    that.readOnly(true); 
                    
                    // Make sure to listent to each dependant value for a change
                    _.each(config.get("dependsOn"), function(value) {
                        eventManager.listenTo(eventManager, "fs:change:" + value, that.cb);
                    });
                }
                
                return that;
            };

            var validateExternalRule = function(value, control, callback) {
                // Basic check to see if anything has been selected or if this is the init stage
                if (!_.isEmpty(value)) {
                    var options = Formsupport.Utils._validateExternalRuleHelper(value, control);
                    var isArray = options.isArray;
                    var parameters = options.parameters;
                    var fetchOptions = options.fetchOptions;
                    var clearInvalidValueEnabled = options.clearInvalidValueEnabled;
                    var conditionCollection = options.conditionCollection;

                    //don't want the stage to re-render for every condition call..
                    $.when(conditionCollection.fetch(fetchOptions)).done(function() {
                        var returnValue = conditionCollection.validateCollection();

                        Formsupport.clearInvalidValue(isArray, returnValue, clearInvalidValueEnabled, parameters, control);
                        control.isExternalRuleValid(returnValue);
                        control.isExternalValidationRunning(false);
                        callback(returnValue);
                    }).fail(function(data) {
						Formsupport.Validation._processConditionFailure(data, control, callback);
                    });
                }
            };

            return {

                //all the rest of our formControl objects are visible
                simpleFormControl: function(config, eventManager) {
                    return abstractFormControl(config, eventManager);
                },

                simpleValidatedFormControl: function(config, eventManager, isAttributeDeletable, setValues) {
                    var that = abstractFormControl(config, eventManager);
                    if (that.controlType === "NumericRange") {
                        that.controlType = "TextBox";
                    }
                    
                    if (that.controlType === "TextArea") {
                        if (config.get("isWysiwyg")) {
                            that.isWysiwyg = true;
                            that.wysiwygConfig = {
                                // TODO make this config.get()
                                toolbar: "HPIMinimal",
                                disableNativeSpellChecker: false
                            };
                        }
                    }

                    var minCharacters = config.get("minChars");
                    var maxCharacters = config.get("maxChars");
                    var regex = config.get("regex");
                    var regexRule = config.get("regexRule");
                    var externalUrl = config.get("externalValueURL");
                    if (regex) {
                        //If form field has a value create a listener for changes to that field
                        if(externalUrl){
                            eventManager.listenTo(eventManager, "fs:change:" + that.id, function(fieldVal){
                                //If the entry meets the regex requirement, append it to the url and get the data
                                var patt = new RegExp(regex);
                                if(patt.test(fieldVal)){
                                    var targetUrl = externalUrl.replace('${value}', fieldVal);
                                    Formsupport.Utils._externalValueURLHelper(targetUrl, setValues);
                                    }
                            });
                        }
                        if (regexRule) {
                            that.value.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeFormatted") + regexRule, params: regex } });
                        } else {
                            that.value.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustMatchPattern"), params: regex } });
                        }
                    }

                    if (!that.readOnly() && minCharacters && maxCharacters) {
                        if (minCharacters === maxCharacters) {
                            that.value.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + minCharacters + ' characters' } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + maxCharacters + ' characters' } });
                        } else {
                            that.value.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + ' characters' } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + ' characters' } });
                        }
                    } else if (!that.readOnly() && maxCharacters) {
                        that.value.extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + window.localize("modules.formSupport.characters") } });

                    } else if (!that.readOnly() && minCharacters) {
                        that.value.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + window.localize("modules.formSupport.characters") } });

                    } 

                    //add validation if an attribute is required and editable by the user
                    if (that.required && !that.readOnly()) {
						// OnlyIf functionality in KO validation utilizes a function to determine
						// if the value should be validated. In this case we only want validation to
						// kick off if the enableDependencyValid observable has a value of true
                        that.value.extend({ 
                            required: {
                                params: true,
                                message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label,
                                onlyIf: function() {
                                    return that.enableDependencyValid();
                                }
                            }
                        });
                    }

                    that.className = "simpleValidatedFormControl";
                    that.objectType = config.get("objectType");


                    if (config.get("defaultValue")) {
                        that.value(config.get("defaultValue"));
                    }

                    if (isAttributeDeletable) {
                        that.isAttributeDeletable = isAttributeDeletable;
                    }

                    return that;
                },

                simpleTextAreaListFormControl: function(config, eventManager, isAttributeDeletable) {
                    var that = abstractFormControl(config, eventManager);
                    that.className = "textAreaListFormControl";
                    that.original = [];
                    // then everything added since will not be a part of the original array
                    if (config.get("timestamped")) {
                        that.isTimestamped = true;
                    } else {
                        that.isTimestamped = false;
                    }
                    if (config.get("onlyNewEntries")) {
                        that.onlyNewEntries = true;
                    } else {
                        that.onlyNewEntries = false;
                    }

                    that.removeValue = function(value) {
                        that.value.remove(value);
                    };

                    if (isAttributeDeletable) {
                        that.isAttributeDeletable = isAttributeDeletable;
                    }

                    // timestampping
                    if (that.isTimestamped && that.isRepeating) {
                        // if this is the case we wanna cheese our addValue to also do some timestammping shenanigans
                        //repeating values need two extra functions for adding and removing from value
                        that.addValue = function(formControl) {
                            //don't add anything if it already exists in value, make sure that
                            //only whitespace is not entered, and ensure the value is properly
                            //trimmed when added to the array
                            if (_.indexOf(that.value(), formControl.repeatingPlaceholder()) < 0 &&
                                formControl.repeatingPlaceholder() &&
                                $.trim(formControl.repeatingPlaceholder()) !== "") {
                                // here we add our timestampin
                                var originalMessage = $.trim(formControl.repeatingPlaceholder());
                                var timestampMessage = " - " + app.user.get("displayName") + " @ " + moment().format();
                                that.value.push(originalMessage + timestampMessage);
                                that.value.valueHasMutated();
                            }
                            formControl.repeatingPlaceholder("");
                        };
                    }

                    return that;
                },

                dateBoxValidatedFormControl: function(config, eventManager, isAttributeDeletable) {
                    var that = dateBoxFormControl(config, eventManager);
                    var isoDateVal;
                    var requiredDateString = window.localize("modules.formSupport.pleaseEnterADateFor") + that.label;

                    that.className = "dateBoxValidatedFormControl";
                    that.dateDisplay = ko.observable();
                    that.showDateValidation(false);
                    that.value.isValid = ko.observable(false);
                    that.dateDisplay.subscribe(function(newDateVal) {
                        if (that.canTypeInBox) {
                            that.dateMessage(that.invalidTypeableDateString);
                        }

                        if (newDateVal) {
                            isoDateVal = that.getIsoDate(newDateVal);
                            // Need current date if there are date restrictions (as a date object not a string)
                            var currentDate = moment();
                            if (isoDateVal === undefined) {
                                that.value(undefined);
                                that.dateDisplay(null);
                                if (that.required) {
                                    that.value.isValid(false);
                                    that.showDateValidation(true);
                                }
                                if (that.canTypeInBox) {
                                    that.showDateValidation(true);
                                }
                            } else {
                                // Check date restrictions (as a date object not a string)
                                var formattedNewDateVal = moment(newDateVal, that.dateFormat);
                                if (that.enforceDateBeforeToday() && (formattedNewDateVal > currentDate)) {
                                    that.value(undefined);
                                    that.dateDisplay(null);
                                    that.dateMessage(that.enforceDateBeforeTodayString);
                                    that.showDateValidation(true);
                                    that.value.isValid(false);
                                } else if (that.enforceDateAfterToday() && (formattedNewDateVal < currentDate)) {
                                    that.value(undefined);
                                    that.dateDisplay(null);
                                    that.dateMessage(that.enforceDateAfterTodayString);
                                    that.showDateValidation(true);
                                    that.value.isValid(false);
                                } else {
                                    that.showDateValidation(false);
                                    that.value(isoDateVal);
                                    that.value.isValid(true);
                                }
                            }
                        } else {
                            that.value(undefined);
                            if (that.required) {
                                that.value.isValid(false);
                                that.showDateValidation(true);
                            }
                            if (that.canTypeInBox) {
                                that.showDateValidation(true);
                            }
                        }
                    });

                    that.repeatingDateDisplay = ko.observableArray();

                    that.addValue = function(formControl) {
                        var isoDateVal;
                        //Get the current date as a date object
                        var currentDate = moment();
                        isoDateVal = that.getIsoDate(formControl.repeatingPlaceholder());
                        if (isoDateVal !== undefined) {
                            // Check if there are any date restrictions (as a date objcet not a string)
                            var formattedDate = moment(formControl.repeatingPlaceholder(), that.dateFormat);
                            if (that.enforceDateBeforeToday() && (formattedDate > currentDate)) {
                                that.dateMessage(that.enforceDateBeforeTodayString);
                                that.showDateValidation(true);
                            } else if (that.enforceDateAfterToday() && (formattedDate < currentDate)) {
                                that.dateMessage(that.enforceDateAfterTodayString);
                                that.showDateValidation(true);
                            } else {
                                that.repeatingDateDisplay.push(formControl.repeatingPlaceholder());
                                if (!that.value()) {
                                    that.value([]);
                                }
                                that.value.push(isoDateVal);
                                that.showDateValidation(false);
                            }
                        } else {
                            if (that.canTypeInBox) {
                                that.dateMessage(that.invalidTypeableDateString);
                                that.showDateValidation(true);
                            }
                        }
                        formControl.repeatingPlaceholder("");
                    };

                    that.removeValue = function(item) {
                        that.repeatingDateDisplay.remove(item);
                        that.value.remove(that.getIsoDate(item));
                        if (that.value.length < 1 && that.required) {
                            that.dateMessage(requiredDateString);
                            that.showDateValidation(true);
                        }
                        if (that.value() && that.value().length === 0) {
                            // lets null it
                            that.value(null);
                        }
                    };

                    if (isAttributeDeletable) {
                        that.isAttributeDeletable = isAttributeDeletable;
                    }

                    that.clearNonRepeatingValue = function() {
                        //clear out the display, will trigger the value to be
                        //set to undefined (see above like 20 lines)
                        that.dateDisplay(undefined);
                        that.value(null);
                        if (!that.required) {
                            that.showDateValidation(false);
                        } else {
                            that.dateMessage(requiredDateString);
                            that.showDateValidation(true);
                        }
                    };

                    //add validation if an attribute is required and editable by the user
                    if (that.required && !that.readOnly()) {
                        that.dateMessage = ko.observable(requiredDateString);
                    }
                    var dateValue;
                    var unixDate;
                    if (config.get("defaultValueCurrentDate")) {
                        if (that.controlType === "DateBox") {
                            app.context.dateService.getFormattedDate(new Date()).done(function(formattedDate) {
                                dateValue = formattedDate;
                                unixDate = that.getIsoDate(formattedDate);
                            });
                        } else {
                            app.context.dateService.getFormattedDatetime(new Date()).done(function(formattedDate) {
                                // remove timezone 
                                formattedDate = formattedDate.replace(" " + moment().tz(that.timezoneFormat).format('z'), "");
                                dateValue = formattedDate;
                                unixDate = that.getIsoDate(formattedDate);
                            });
                        }
                        that.value(unixDate);
                        that.dateDisplay(dateValue);
                    } else if (config.get("defaultValue")) {
                        //default to date
                        if (that.controlType === "DateBox") {
                            app.context.dateService.getFormattedDate(config.get("defaultValue")).done(function(formattedDate) {
                                dateValue = formattedDate;
                                unixDate = that.getIsoDate(formattedDate);
                            });
                        } else {
                            app.context.dateService.getFormattedDatetime(config.get("defaultValue")).done(function(formattedDate) {
                                dateValue = formattedDate;
                                unixDate = that.getIsoDate(formattedDate);
                            });
                        }
                        that.value(unixDate);
                        that.dateDisplay(dateValue);
                    }

                    return that;
                },

                numericRangeSearchControl: function(config, eventManager) {
                    var that = abstractFormControl(config, eventManager);
                    that.toNumber = ko.observable();
                    that.fromNumber = ko.observable();

                    var minCharacters = config.get("minChars");
                    var maxCharacters = config.get("maxChars");
                    var regex = config.get("regex");
                    var regexRule = config.get("regexRule");

                    if (regex) {
                        if (regexRule) {
                            that.toNumber.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeFormatted") + regexRule, params: regex } });
                            that.fromNumber.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeFormatted") + regexRule, params: regex } });
                        } else {
                            that.toNumber.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustMatchPattern"), params: regex } });
                            that.fromNumber.extend({ pattern: { message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustMatchPattern"), params: regex } });
                        }
                    }

                    if (that.required && !that.readOnly() && minCharacters && maxCharacters) {
                        if (minCharacters === maxCharacters) {
                            that.toNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + minCharacters + ' characters' } })
                                .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + maxCharacters + ' characters' } });
                            that.fromNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + minCharacters + ' characters' } })
                                .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + ' must be ' + maxCharacters + ' characters' } });
                        } else {
                            that.toNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + ' characters' } })
                                .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + ' characters' } });
                            that.fromNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + ' characters' } })
                                .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } })
                                .extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + ' characters' } });
                        }
                    } else if (that.required && !that.readOnly() && maxCharacters) {
                        that.toNumber.extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + window.localize("modules.formSupport.characters") } })
                            .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                        that.fromNumber.extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + window.localize("modules.formSupport.characters") } })
                            .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                    } else if (that.required && !that.readOnly() && minCharacters) {
                        that.toNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + window.localize("modules.formSupport.characters") } })
                            .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                        that.fromNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + window.localize("modules.formSupport.characters") } })
                            .extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                    } else if (that.enableRequired && !that.readOnly() && minCharacters) {
                        that.toNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + window.localize("modules.formSupport.characters") } });
                        that.fromNumber.extend({ minLength: { params: minCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.mustBeAtLeast") + minCharacters + window.localize("modules.formSupport.characters") } });
                    } else if (that.enableRequired && !that.readOnly() && maxCharacters) {
                        that.toNumber.extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + window.localize("modules.formSupport.characters") } });
                        that.fromNumber.extend({ maxLength: { params: maxCharacters, message: window.localize("modules.formSupport.valueFor") + that.label + window.localize("modules.formSupport.cannotExceed") + maxCharacters + window.localize("modules.formSupport.characters") } });
                    } else if (that.required && !that.readOnly()) {
                        that.toNumber.extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                        that.fromNumber.extend({ required: { params: true, message: window.localize("modules.formSupport.pleaseEnterAValueFor") + that.label } });
                    } //add validation if an attribute is required and editable by the user

                    that.value = ko.computed(function() {
                        var from, to, numericRangeString = "";
                        if (that.fromNumber()) {
                            from = that.fromNumber();
                            numericRangeString = from;
                        }
                        numericRangeString += "|";
                        if (that.toNumber()) {
                            to = that.toNumber();
                            numericRangeString += to;
                        }

                        //if it's nothing return nothing
                        if (numericRangeString === "|") {
                            return null;
                        }

                        return numericRangeString;
                    });

                    that.className = "numericRangeSearchControl";
                    that.objectType = config.get("objectType");

                    that.value.subscribe(function(newValue) {
                        eventManager.trigger("fs:change:" + that.id, newValue, that);
                        eventManager.trigger("fs:change", newValue, that);
                    });

                    return that;
                },

                dateSearchControl: function(config, eventManager) {
                    var that = dateBoxFormControl(config, eventManager);
                    if (that.controlType === "DateBox") {
                        that.controlType = "DateSearch";
                    } else {
                        that.controlType = "DatetimeSearch";
                    }

                    that.to = ko.observable();
                    that.from = ko.observable();

                    // Variables used for date validation
                    var validTo = true;
                    var validFrom = true;

                    if (that.canTypeInBox) {
                        that.dateMessage(that.invalidTypeableDateString);
                    }

                    that.clearFrom = function() {
                        validFrom = true;
                        if (!validTo && that.canTypeInBox) {
                            that.showDateValidation(true);
                        } else {
                            that.showDateValidation(false);
                        }
                        that.from('');
                        //reset the lower bound of from dates
                        if (that.controlType === "DateSearch") {
                            if (that.enforceDateBeforeToday()) {
                                $("#" + that.id + "from").datepicker("option", "minDate", "");
                                $("#" + that.id + "from").datepicker("option", "maxDate", new Date());
                            }
                            if (that.enforceDateAfterToday()) {
                                $("#" + that.id + "from").datepicker("option", "minDate", new Date());
                                $("#" + that.id + "from").datepicker("option", "maxDate", "");
                            } else {
                                $("#" + that.id + "from").datepicker("option", "minDate", "");
                            }
                            $("#" + that.id + "to").datepicker("option", "minDate", "");
                        } else {
                            if (that.enforceDateBeforeToday()) {
                                $("#" + that.id + "from").datetimepicker("option", "minDate", "");
                                $("#" + that.id + "from").datetimepicker("option", "minDate", new Date());
                            }
                            if (that.enforceDateAfterToday()) {
                                $("#" + that.id + "from").datetimepicker("option", "minDate", new Date());
                                $("#" + that.id + "from").datetimepicker("option", "maxDate", "");

                            } else {
                                $("#" + that.id + "from").datetimepicker("option", "minDate", "");
                            }
                            $("#" + that.id + "to").datetimepicker("option", "minDate", "");
                        }

                    };

                    that.clearTo = function() {
                        validTo = true;
                        if (!validFrom && that.canTypeInBox) {
                            that.showDateValidation(true);
                        } else {
                            that.showDateValidation(false);
                        }
                        that.to('');
                        //reset the upper bound of to dates
                        if (that.controlType === "DateSearch") {
                            if (that.enforceDateBeforeToday()) {
                                $("#" + that.id + "to").datepicker("option", "maxDate", new Date());
                            } else {
                                $("#" + that.id + "to").datepicker("option", "maxDate", "");
                            }
                        } else {
                            if (that.enforceDateBeforeToday()) {
                                $("#" + that.id + "to").datetimepicker("option", "maxDate", new Date());
                            } else {
                                $("#" + that.id + "to").datetimepicker("option", "maxDate", "");
                            }
                        }
                    };

                    //calculates values as fromDate|toDate. Allowing fromDate| and toDate| as well.
                    that.value = ko.computed({
                        read: function() {
                            var to, from, isoString = "";
                            //Get the current date as a date object
                            var currentDate = moment();
                            if (that.from()) {
                                from = that.getIsoDate(that.from());
                                if (from === undefined) {
                                    if (that.canTypeInBox) {
                                        that.dateMessage(that.invalidTypeableDateString);
                                    }
                                    that.clearFrom();
                                    validFrom = false;
                                } else {
                                    // Check date restrictions (as a date object not a string)
                                    // Compare date only - not time if this is a datetime picker
                                    var formattedFrom = moment(that.from(), that.dateFormat);
                                    if (that.enforceDateBeforeToday() && formattedFrom > currentDate) {
                                        that.dateMessage(that.enforceDateBeforeTodayString);
                                        that.clearFrom();
                                        validFrom = false;
                                    } else if (that.enforceDateAfterToday() && formattedFrom < currentDate) {
                                        that.dateMessage(that.enforceDateAfterTodayString);
                                        that.clearFrom();
                                        validFrom = false;
                                    } else {
                                        validFrom = true;
                                        isoString += from;
                                    }
                                }

                            } else {
                                validFrom = true;
                            }

                            isoString += "|";

                            if (that.to()) {
                                // Sets the "to" date to 11:59 of the same day
                                var sameDateOffset = 86400000 - 1;
                                to = that.getIsoDate(that.to());
                                if (to === undefined) {
                                    that.clearTo();
                                    validTo = false;
                                } else {
                                    // Compare date only - not time if this is a datetime picker (as a date object not a string)
                                    var formattedTo = moment(that.to(), that.dateFormat);
                                    if (that.enforceDateBeforeToday() && formattedTo > currentDate) {
                                        that.dateMessage(that.enforceDateBeforeTodayString);
                                        that.clearTo();
                                        validFrom = false;
                                    } else if (that.enforceDateAfterToday() && formattedTo < currentDate) {
                                        that.dateMessage(that.enforceDateAfterTodayString);
                                        that.clearTo();
                                        validFrom = false;
                                    } else {
                                        validTo = true;
                                        if (that.controlType === "DateSearch") {
                                            isoString += to + sameDateOffset;
                                        } else {
                                            isoString += to;
                                        }
                                    }
                                }
                            } else {
                                validTo = true;
                            }

                            if ((!validFrom || !validTo) && that.canTypeInBox) {
                                that.showDateValidation(true);
                            } else {
                                that.showDateValidation(false);
                            }

                            //if it's nothing return nothing
                            if (isoString === "|") {
                                return undefined;
                            }
                            return isoString;
                        },
                        write: function(value) {
                            //never expect this value to not be undefined
                            if (!value) {
                                that.from(undefined);
                                that.to(undefined);
                            }
                        }
                    });
                    that.value.subscribe(function(newValue) {
                        eventManager.trigger("fs:change:" + that.id, newValue, that);
                        eventManager.trigger("fs:change", newValue, that);
                    });
                    return that;
                },

                singleSelectValidatedFormControl: function(config, eventManager, disableDefaults, isReadOnly, isAttributeDeletable) {
                    var that = pickListEnabledFormControl(config, eventManager, disableDefaults, isReadOnly);
                    that.className = "singleSelectValidatedFormControl";
                    that.loadPicklist();

                    if (isAttributeDeletable) {
                        that.isAttributeDeletable = isAttributeDeletable;
                    }

                    if (that.required && !that.readOnly()) {
						// OnlyIf functionality in KO validation utilizes a function to determine
						// if the value should be validated. In this case we only want validation to
						// kick off if the enableDependencyValid observable has a value of true
                        that.value.extend({ 
                            required: {
                                params: true,
                                message: window.localize("modules.formSupport.pleaseSelectAValueFor") + that.label,
                                onlyIf: function() {
                                    return that.enableDependencyValid();
                                }
                            }
                        });
                    }
                    that.value.subscribe(function(newVal) {
                        //seed picklist before its been loaded
                        if (that.picklistItemsArr().length < 1) {
                            that.picklistItemsArr().push({ 'label': newVal, 'value': newVal });
                        }
                        if (!that.loaded && !that.loading()) {
                            //wait until the picklist array
                            //has been loaded, and we'll set the value
                            //since the picklist now contains it.
                            that.loadPicklist().done(function() {
                                if (newVal.length === 0) {
                                    newVal = null;
                                }
                                that.value(newVal);
                            });
                        }
                    });
                    if (!that.value() || that.value().length === 0) {
                        that.value(null);
                    }

                    return that;
                },

                checkBoxValidatedFormControl: function(config, eventManager, disableDefaults, isReadOnly) {
                    var that = pickListEnabledFormControl(config, eventManager, disableDefaults, isReadOnly);
                    that.picklistItemsArr.subscribe(function(newArray) {
                        //when we retrieve a picklist, the empty val is always
                        //put as the first element in the array. We don't want
                        //this for checkbox controls, so remove it from the picklist array
                        if (newArray[0].value === "" && newArray[0].label === "") {
                            that.picklistItemsArr(newArray.splice(1, newArray.length));
                        }
                    });

                    if (that.isRepeating) {
                        //need this to be an observable array
                        //for the checked binding to work appropriately
                        that.value = ko.observableArray();
                    }
                    that.loadPicklist();
                    if (that.required && !that.readOnly()) {
                        that.value.extend({ minLength: { params: 1, message: +that.label } });
                    }

                    return that;

                },

                radioButtonValidatedFormControl: function(config, eventManager, disableDefaults, isReadOnly) {
                    var that = pickListEnabledFormControl(config, eventManager, disableDefaults, isReadOnly);

                    that.value.uiValue = ko.computed({
                        read: function() {
                            if(this.value() !== undefined && this.value() !== null) {
                                return this.value().toString();
                            }
                            return this.value();
                        },
                        write: function(newValue) {
                            if(newValue === "true") {
                                this.value(true);
                            } else if(newValue === "false") {
                                this.value(false);
                            } else {
                                this.value(newValue);
                            }
                        },
                        owner: that
                    });

                    that.loadPicklist();
                    if (that.required && !that.readOnly()) {
                        that.value.extend({ minLength: { params: 1, message: window.localize("modules.formSupport.pleaseSelectAtLeast") + that.label } });
                    }

                    //if we have a radio button control and on the search page, we want to
                    //be able to clear the value after anything is selected
                    that.radioClearCheck = ko.observable(disableDefaults);
                    that.radioClear = function() {
                        that.value(undefined);
                    };

                    return that;

                },

                autoCompleteValidatedFormControl: function(config, eventManager, disableDefaults, isReadOnly, isAttributeDeletable) {
                    var that = pickListEnabledFormControl(config, eventManager, disableDefaults, isReadOnly, isAttributeDeletable);
                    that.className = "autoCompleteValidatedFormControl";

                    //assuming dependent controls always get validated
                    if (that.required && (config.get("dependsOn").length > 0 || !that.readOnly())) {
                        // OnlyIf functionality in KO validation utilizes a function to determine
						// if the value should be validated. In this case we only want validation to
						// kick off if the enableDependencyValid observable has a value of true
						that.value.extend({ 
                            required: {
                                params: true,
                                message: window.localize("modules.formSupport.pleaseSelectAValueFor") + that.label,
                                onlyIf: function() {
                                    return that.enableDependencyValid();
                                }
                            }
                        });
                    }

                    //see bootstrap typeahead docs for the 'source' options
                    that.getSource = _.debounce(function(query, process) {
                        //if this is async we need to run the query everytime
                        if (that.asyncEnabled || !that.loaded) {
                            //expose the picklist load deferred so other functions can wait for it
                            that.picklistLoadDeferred = that.loadPicklist(query);
                            that.picklistLoadDeferred.done(function() {
                                that.loaded = true;
                                //we know the internal picklistitemsarray is ready
                                //filter the results we send back based on the query value
                                var matchingResults = _.filter(that.picklistItemsArr(), function(item) {
                                    //case-insensitive search
                                    return item.label.toUpperCase().indexOf(query.toUpperCase()) !== -1;
                                });
                                process(matchingResults);
                            });
                        } else {
                            //assume we're already loaded
                            var matchingResults = _.filter(that.picklistItemsArr(), function(item) {
                                //case-insensitive search
                                return item.label.toUpperCase().indexOf(query.toUpperCase()) !== -1;
                            });
                            process(matchingResults);
                        }
                    }, (that.asyncEnabled ? 750 : 0));

                    if (!that.isRepeating) {
                        // A non-repeating attr must have a string for a default value. This logic achieves that.
                        var defaultItems = that.picklistConfig.get('defaultItems');
                        if (defaultItems && !disableDefaults) {
                            // we only want to add default values if they exist and if it is not an empty string
                            // we used to set an empty string here, but that kicks off the value.subscirbe which then
                            //runs validation, which we don't want - the autocomplete can be submitted without a value
                            if (defaultItems.length > 0 && defaultItems[defaultItems.length - 1]) {
                                // Select one default item from the array since this attribute is not repeating. To keep it consistent everywhere,
                                // select the last value the user picked.
                                that.value(defaultItems[defaultItems.length - 1]);
                            }
                        }

                        //we need this to update the value/label correctly for our control
                        that.picklistItemsArr.subscribe(function(newArray) {
                            if (that.value()) {
                                var foundItem = _.findWhere(newArray, { value: that.value() });
                                if (foundItem) {
                                    if (!that.asyncEnabled) {
                                        that.setSelectionByLabel(foundItem.label);
                                    }
                                }
                            }
                        });

                        that.validateInput = function() {
                            if (!that.isGrowable) {
                                var foundItem = _.findWhere(that.picklistItemsArr(), { value: that.value() });
                                if (!foundItem) {
                                    that.$el.val(undefined);
                                    that.value(undefined);
                                    if (that.typeahead) {
                                        that.typeahead.typeahead("val", "");
                                        $("#" + "shadow" + that.id + that.uuid).val("");
                                    }
                                }
                            }
                        };

                        that.displayLabel = ko.observable();


                        that.displayLabel.subscribe(function(newLabel) {

                            var labelChange = that.id + "-label";

                            eventManager.trigger("fs:labelChange:" + labelChange, newLabel, that);
                        });



                        that.loadDisplayLabel = function(value) {
                            that.displayLabel(undefined);
                            if (that.typeahead) {
                                var picklistItem = _.find(that.picklistItemsArr(), function(item) { 
                                    var itemVal = item.value;
                                    if(!_.isUndefined(itemVal) && !_.isUndefined(value) &&
                                        !_.isNull(itemVal) && !_.isNull(value)){
                                        return itemVal.toString() === value.toString(); 
                                    }
                                });
                                //this should always be the case, if it isn't... well... who knows
                                if (picklistItem) {
                                    that.displayLabel(picklistItem.label);
                                    //we also need to make sure that the typeahead input gets the correct value
                                    that.typeahead.typeahead("val", picklistItem.label);
                                } else {
                                    app.log.debug(window.localize("modules.formSupport.didntFind") + value + window.localize("modules.formSupport.inPicklistItem") + that.label);
                                    //just add the value?
                                    that.displayLabel(value);
                                    //we also need to make sure that the typeahead input gets the correct value
                                    that.typeahead.typeahead("val", value);
                                }
                                
                            }

                        };


                        that.value.subscribe(function(value) {
                            //we need to reset our displayLabel if the value changes
                            if ((that.picklistItemsArr().length === 0 && !that.loading() && !that.loaded && !that.allowDropdown) ||
                                (value && !that.loading() && !that.loaded)) {
                                //if we don't have a picklist and we need to load it
                                //to check against a real value, we need to call loadPicklist
                                that.loadPicklist().done(function() {
                                    that.loadDisplayLabel(value);
                                });
                            } else {
                                //we have a picklist, so set the display label as normal
                                that.loadDisplayLabel(value);
                            }
                        });

                        //see bootstraptype ahead for the 'updater' option
                        that.setSelectionByLabel = function(selectedLabel) {
                            //if someone passed us {label: foo, value: bar} instead
                            //of just the label
                            if (_.isObject(selectedLabel)) {
                                selectedLabel = selectedLabel.label;
                            }

                            //if the label is in our picklist, then we are golden, set the value and
                            //get out of here
                            var picklistItem = _.find(that.picklistItemsArr(), function(item) { return item.label === selectedLabel; });
                            if (that.isGrowable && !picklistItem) {
                                picklistItem = { "label": selectedLabel, "value": selectedLabel };
                                that.picklistItemsArr().push(picklistItem);
                            }
                            if (picklistItem && (picklistItem.value !== undefined && picklistItem.value !== null && picklistItem.value !== "")) {
                                that.value(picklistItem.value); //i actually think this is not necessary since the text box is bound to value
                                that.displayLabel(picklistItem.label);
                                //we also need to make sure that the typeahead input gets the correct value
                                if (that.typeahead) {
                                    that.typeahead.typeahead("val", picklistItem.label);
                                }
                                return picklistItem.label;
                            } else if (picklistItem && (picklistItem.value === "") && that.$el !== undefined) {
                                that.value("");
                                that.displayLabel("");
                                //we also need to make sure that the typeahead input gets the correct value
                                that.typeahead.typeahead("val", "");
                            } else if (picklistItem && (picklistItem.value === "") && that.$el === undefined) {
                                that.value("");
                            } else {
                                that.value(undefined);
                                that.displayLabel(undefined);
                                //we also need to make sure that the typeahead input gets the correct value
                                that.typeahead.typeahead("val", "");
                            }
                        };

                        if (that.lookupValuesEnabled()) {
                            //put in this repeating block for now, as lookup explicitly DOES NOT support repeating (for now?)
                            //we have to load this css dynamically when relevant, as the typeahead itself
                            //sets it dynamically, overwriting any of our stylesheets.
                            that.setLookupTypeaheadCSS = function() {
                                that.typeahead.css("position", "absolute");
                                that.typeahead.css("cursor", "default");
                                that.typeahead.prop("readonly", "readonly");
                                that.typeahead[0].style.setProperty("min-height", "0px", "important");
                                that.typeahead[0].style.setProperty("max-height", "0px", "important");
                                that.typeahead[0].style.setProperty("height", "0px", "important");
                                that.typeahead[0].style.setProperty("padding-top", "1px", "important");
                                var dropdown = that.typeahead.siblings(".tt-dropdown-menu");
                                if (dropdown.length) {
                                    dropdown[0].style.setProperty("top", "0px", "important");
                                }
                            };
                            that.setShadowValue = function(value) {
                                $("#" + "shadow" + that.id + that.uuid).val(value);
                            };
                        }

                    } else {
                        // A repeating attr will receive the array gotten from the defaultItems as its value. No need to modify the data.
                        // This could be an empty array though, and if that is the case, we dont want to kick off the value.subscribe
                        if (!disableDefaults && that.picklistConfig.get('defaultItems') && !_.isEmpty(that.picklistConfig.get('defaultItems'))) {
                            that.value(_.clone(that.picklistConfig.get('defaultItems')));
                        }

                        //if the control becomes readonly (dependent control cleared) emtpy the query box
                        that.readOnly.subscribe(function(bool) {
                            if (bool) {
                                that.repeatingPlaceholder([]);
                            }
                        });

                        that.picklistItemsArr.subscribe(function(newArray) {
                            if (!that.isGrowable && !that.asyncEnabled) {
                                var newLabeledItems = _.filter(newArray, function(picklistItem) { return _.indexOf(that.value(), picklistItem.value) !== -1; });
                                //don't want to deal with value directly since it would trigger ko
                                //subscribes with each change which screws up dependent picklists
                                var newValueArr = [];
                                _.each(newLabeledItems, function(item) {
                                    newValueArr.push(item.value);
                                });

                                if (newValueArr.length === 0) {
                                    newValueArr = null;
                                }
                                //after we have our new value array, set it all at once
                                that.value(newValueArr);
                            }
                        });

                        that.displayArray = ko.observableArray([]);

                        that.loadDisplayLabels = function (valueArray) {
                            that.displayArray().length = 0;
                            _.each(valueArray, function (value) {
                                var picklistItem = _.find(that.picklistItemsArr(), function(item) { return item.value === value; });
                                //this should always be the case, if it isn't... well... who knows
                                if (picklistItem) {
                                    that.displayArray().push(picklistItem.label);
                                } else {
                                    app.log.debug(window.localize("modules.formSupport.didntFind") + value + window.localize("modules.formSupport.inPicklistItem") + that.label);
                                    //just add the value?
                                    that.displayArray().push(value);
                                }

                            });

                            if (that.sortRepeatingAttrs) {
                                Formsupport.Utils.sortAndPrepend(that.displayArray(), that.valuesToPrependWhenSorting);
                            }

                            that.displayArray.valueHasMutated();
                        };



                        that.value.subscribe(function(valueArray) {
                            //so, whenever value changes, we are going to redo our displayArray
                            if (that.picklistItemsArr().length === 0 && !that.loading() && !that.loaded && !that.allowDropdown) {
                                that.loadPicklist().done(function() {
                                    that.loadDisplayLabels(valueArray);
                                });
                            } else {
                                that.loadDisplayLabels(valueArray);
                            }

                            if (that.selectAllEnabled()) {
                                //meaning if all items are selected(sans the blank option)
                                if (valueArray && valueArray.length === that.picklistItemsArr().length - 1) {
                                    that.selectedAll(true);
                                } else if (that.selectedAll) {
                                    that.selectedAll(false);
                                }
                            }


                        });
                        //see bootstraptype ahead for the 'updater' option
                        that.setSelectionByLabel = function(selectedLabel) {

                            //if someone passed us {label: foo, value: bar} instead
                            //of just the label
                            if (_.isObject(selectedLabel)) {
                                selectedLabel = selectedLabel.label;
                            }

                            //if the label is in our picklist, then we are golden, set the value and
                            //get out of here
                            var picklistItem = _.find(that.picklistItemsArr(), function(item) { return item.label === selectedLabel; });
                            if (picklistItem && picklistItem.value) {
                                if (_.indexOf(that.value(), picklistItem.value) < 0) {
                                    if (!that.value()) {
                                        //if were nulled out, lets become an empty array real quickSelectControls
                                        that.value([]);
                                    }
                                    that.value.push(picklistItem.value);
                                }
                                that.repeatingPlaceholder("");
                            } else {
                                if (!that.isGrowable) {
                                    that.repeatingPlaceholder("");
                                    that.$el.val(undefined);
                                    that.$el.typeahead('val', "");
                                }
                            }
                        };

                        that.removeValue = function(data) {
                            var picklistItem = _.find(that.picklistItemsArr(), function(item) { return item.label === data; });
                            if (picklistItem) {
                                that.value.remove(picklistItem.value);
                            } else {
                                //otherwise is if data is there and remove
                                if (_.indexOf(that.value(), data) !== -1) {
                                    that.value.remove(data);
                                }
                            }
                            if (that.selectedAll && that.selectedAll()) {
                                that.selectedAll(false);
                            }
                            if (that.value().length === 0) {
                                //if were empty now, lets null out
                                that.value(null);
                            }

                        };

                        if (isAttributeDeletable) {
                            that.isAttributeDeletable = isAttributeDeletable;
                        }

                        if (that.selectAllEnabled()) {
                            that.selectAllValues = function() {
                                if (!that.selectedAll()) {
                                    var vals = [];
                                    //we should just use _.pluck here, but
                                    //since we don't want the blank value, let's just do it the old-fashioned way
                                    _.each(that.picklistItemsArr(), function(item) {
                                        if (item.value !== "") {
                                            vals.push(item.value);
                                        }
                                    });
                                    that.value(vals);
                                    that.selectedAll(true);
                                } else {
                                    _.each(that.picklistItemsArr(), function(item) {
                                        that.removeValue(item.label);
                                    });
                                }
                            };
                            that.selectedAll = ko.observable(false);
                            that.selectedAll.subscribe(function(newVal) {
                                $("#" + "selectAll" + that.id + that.uuid).children().toggleClass("glyphicons-plus", !newVal);
                                $("#" + "selectAll" + that.id + that.uuid).children().toggleClass("glyphicons-remove", newVal);
                                that.toggleSelectAllLabel(newVal, $("#" + "selectAll" + that.id + that.uuid));
                            });
                        }
                        that.toggleSelectAllLabel = function(boolVal, htmlElm) {
                            if (boolVal) {
                                htmlElm.attr('title', window.localize("remove.all.options"));
                            } else {
                                htmlElm.attr('title', window.localize("select.all.options"));
                            }
                        };
                    }

                    //if this picklist has a default value, we want
                    //to load the picklist immediately so that value can
                    //be set when form support loads
                    if ((that.picklistConfig.get("defaultItems") && that.picklistConfig.get('defaultItems').length > 0) || !that.asyncEnabled) {
                        that.loadPicklist();
                    }

                    that.value.subscribe(function() {
                        if (!that.loaded && !that.loading() && !that.allowDropdown) {
                            that.loadPicklist();
                        }
                    });

                    return that;

                },

                multiElementValidatedFormControl: function(config, eventManager) {

                    var that = abstractFormControl(config, eventManager);
                    //add validation if an attribute is required and editable by the user
                    if (that.required && !that.readOnly()) {
                        that.value.extend({ minLength: { params: 1, message: window.localize("modules.formSupport.pleaseSelectAtLeast") + that.label } });
                    }
                    that.itemToAdd = ko.observable();
                    that.selectedToDelete = ko.observableArray();
                    that.deleteSelectedItems = function() {
                        if (that.selectedToDelete()) {
                            while (that.selectedToDelete().length > 0) {
                                var itemToRemove = that.selectedToDelete.pop();
                                that.value.remove(itemToRemove);
                            }
                        }
                    };
                    that.addItem = function() {
                        if (that.itemToAdd()) {
                            that.value.push(that.itemToAdd());
                            that.itemToAdd("");
                            $('#' + that.id + "-input").focus();
                        }
                    };

                    $('#' + that.id + "-addButton").keypress(function(e) {
                        if (e.which === 13) {
                            that.addItem();
                        }
                    });

                    return that;

                },

                proximityDateFromControl: function(config, eventManager) {
                    var that = abstractFormControl(config, eventManager);
                    that.proximityType = ko.observable();
                    that.proximityNumber = ko.observable();
                    that.proximityTimeSpan = ko.observable();

                    that.proximityType.subscribe(function() {
                        computeValue();
                    });
                    that.proximityNumber.subscribe(function() {
                        computeValue();
                    });
                    that.proximityTimeSpan.subscribe(function() {
                        computeValue();
                    });

                    var computeValue = function() {
                        // we only want to compute the value if all of the values have been filled in
                        if (!that.proximityType() || !that.proximityNumber() || !that.proximityTimeSpan()) {
                            // clear out the value when any of the fields are reset
                            that.value('');
                            return;
                        }

                        var proximityNumberAsInt = parseInt(that.proximityNumber(), 10);
                        var startDate = moment().startOf('day');
                        var endDate = moment().startOf('day');

                        if (that.proximityType().toLowerCase() === 'within') {
                            startDate = startDate.subtract(proximityNumberAsInt, that.proximityTimeSpan());
                            endDate = endDate.add(proximityNumberAsInt, that.proximityTimeSpan()).endOf('day');
                        } else if (that.proximityType().toLowerCase() === 'past') {
                            startDate = startDate.subtract(proximityNumberAsInt, that.proximityTimeSpan());
                            endDate = moment().endOf('day');
                        } else { // next
                            endDate = endDate.add(proximityNumberAsInt, that.proximityTimeSpan()).endOf('day');
                        }

                        var value = startDate.toDate().getTime() + '|' + endDate.toDate().getTime();

                        // need to tack on the actual user input parameters that way we will be able to repopulate from a different
                        // day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
                        var proximityParams = '$*prx*$' + that.proximityType() + '|' + that.proximityNumber() + '|' + that.proximityTimeSpan();

                        that.value(value + proximityParams);
                    };

                    return that;
                },

                computedFormControl: function(config, eventManager) {
                    var that = abstractFormControl(config, eventManager);
                    that.objectType = config.get('objectType');

                    that.eventManager = {
                        dispose: function() {
                            this.stopListening();
                        }
                    };
                    _.extend(that.eventManager, Backbone.Events);

                    if (that.required && !that.readOnly()) {
						// OnlyIf functionality in KO validation utilizes a function to determine
						// if the value should be validated. In this case we only want validation to
						// kick off if the enableDependencyValid observable has a value of true
                        that.value.extend({ 
                            required: {
                                params: true,
                                message: window.localize("modules.formSupport.pleaseSelectAValueFor") + that.label,
                                onlyIf: function() {
                                    return that.enableDependencyValid();
                                }
                            }
                        });
                    }

                    //function that will be run each time a dependent
                    //attribute changes
                    var computeAttributeValue = function() {
                        var newControlValue = that.attributeAndSeparatorsArray.join("");

                        //limit the size our our computed control to 245 characters
                        if (newControlValue.length > 245) {
                            that.value(newControlValue.substring(0, 246));
                        } else {
                            that.value(newControlValue);
                        }
                    };

                    //throttle the dependent attribute change function so it doesn't
                    //go crazy when setValues is run...
                    that.throttledComputeAttributeValue = _.throttle(computeAttributeValue, 100);

                    //go through the pattern and get the attributes from it
                    that.dependentAttributes = app.context.util.parsePatternForAttributes(config.get("computedPattern"));
                    that.attributeAndSeparatorsArray = that.pattern.split("$");
                    that.attributeToLocationMap = {};

                    //now lets create our map and make the array have empty strings as we go
                    _.each(that.attributeAndSeparatorsArray, function(attrOrSeparator, index) {
                        if (attrOrSeparator === '' && index !== that.attributeAndSeparatorsArray.length - 1) {
                            //empty string needs to be removed.
                            that.attributeAndSeparatorsArray.splice(index, 1);
                            //if we splice out an item not at the end, we dont want to miss an attr that has shifted left in the array
                            if (that.dependentAttributes.indexOf(that.attributeAndSeparatorsArray[index]) > -1) {
                                that.attributeToLocationMap[that.attributeAndSeparatorsArray[index]] = index;
                                //if this is an attribute array spot and not a separator make it an empty string so we dont have attr1-attr2 in the computed value to start
                                that.attributeAndSeparatorsArray[index] = "";
                            }
                        } else if (attrOrSeparator === '' && index === that.attributeAndSeparatorsArray.length - 1) {
                            //empty string can be popped if at the end
                            that.attributeAndSeparatorsArray.pop();
                        }
                        if (attrOrSeparator.indexOf("hpiTimeStamp") > -1) {
                            app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat) {
                                //we have a timestamp, lets figure out if there is a format.
                                if (attrOrSeparator.indexOf("-") > -1) {
                                    var format = attrOrSeparator.substring(attrOrSeparator.indexOf("-") + 1);
                                    that.attributeAndSeparatorsArray[index] = moment().format(format);
                                } else {
                                    that.attributeAndSeparatorsArray[index] = moment().format(dateTimeFormat.dateFormat);
                                }
                            });
                            that.attributeToLocationMap[attrOrSeparator] = index;
                        } else if (that.dependentAttributes.indexOf(attrOrSeparator) > -1) {
                            //set up map spot
                            that.attributeToLocationMap[attrOrSeparator] = index;
                            //if this is an attribute array spot and not a separator make it an empty string so we dont have attr1-attr2 in the computed value to start
                            that.attributeAndSeparatorsArray[index] = "";

                        }
                    });
                    that.attrChangeListener = function(newVal, control, isLabel) {

                        var changeAttrKey = control.id;
                        if (isLabel) {
                            changeAttrKey = changeAttrKey + "-label";

                        }
                        var tempIndex = that.attributeToLocationMap[changeAttrKey];
                        /*var tempUnixDate = null;
                        var tempTime = null;*/
                        //check if our value is a repeating attribute (an array)
                        //if it is, we will just use the first value of the array
                        if (_.isArray(newVal)) {
                            //format the date to the current format for that attribute
                            //because unix time is ugly and confusing
                            if (control.controlType === "DateBox" || control.controlType === "DatetimeBox") {
                                if (control.controlType === "DateBox") {
                                    if (!control.timezoneFormat) {

                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal[0]).format(control.dateFormat);
                                    } else {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal[0]).tz(control.timezoneFormat).format(control.dateFormat);
                                    }
                                } else {
                                    if (!control.timezoneFormat) {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal[0]).format(control.dateFormat + " " + control.timeFormat);
                                    } else {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal[0]).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                    }
                                }
                            } else {
                                that.attributeAndSeparatorsArray[tempIndex] = newVal[0];
                            }
                        } else {
                            //format the date to the current format for that attribute
                            //because unix time is ugly and confusing
                            if (control.controlType === "DateBox" || control.controlType === "DatetimeBox") {
                                if (control.controlType === "DateBox") {
                                    if (!control.timezoneFormat) {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal).format(control.dateFormat);
                                    } else {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal).tz(control.timezoneFormat).format(control.dateFormat);
                                    }
                                } else {
                                    if (!control.timezoneFormat) {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal).format(control.dateFormat + " " + control.timeFormat);
                                    } else {
                                        that.attributeAndSeparatorsArray[tempIndex] = moment(newVal).tz(control.timezoneFormat).format(control.dateFormat + " " + control.timeFormat);
                                    }
                                }
                            } else {
                                that.attributeAndSeparatorsArray[tempIndex] = newVal;
                            }
                        }
                        that.throttledComputeAttributeValue();
                    };


                    //get all kinds of weird AND create event listeners for each of the dependent attributes
                    _.each(that.dependentAttributes, function(attrName) {
                        if (attrName.indexOf("hpiTimeStamp") <= 0) {


                            //if its not the hpiTimeStamp, listen to change.If it has -label in it

                            if (attrName.indexOf("-label") > -1) {

                                //using underscore.js function called partial to pass in an argument to attrChangeListener if it is a labelChange
                                that.eventManager.listenTo(eventManager, "fs:labelChange:" + attrName, _.partial(that.attrChangeListener, _, _, true));

                            } else {

                                that.eventManager.listenTo(eventManager, "fs:change:" + attrName, that.attrChangeListener);
                            }

                        }
                    });

                    return that;
                },

                authenticationValidatedFormControl: function(config, eventManager) {
                    var that = abstractFormControl(config, eventManager);
                    that.value({
                        "username": "",
                        "password": "",
                        "applySignature": config.get("applySignature")
                    });

                    that.applySignature = that.value()["applySignature"];

                    that.eSigUsername = ko.observable("");
                    that.eSigPassword = ko.observable("");

                    that.eSigUsername.subscribe(function(newValue) {
                        that.value({
                            "username": newValue,
                            "password": that.eSigPassword(),
                            "applySignature": that.applySignature
                        });
                    });

                    that.eSigPassword.subscribe(function(newValue) {
                        that.value({
                            "username": that.eSigUsername(),
                            "password": newValue,
                            "applySignature": that.applySignature
                        });
                    });

                    return that;
                },

                approveOrRejectValidatedFormControl: function(config, eventManager) {
                    var that = abstractFormControl(config, eventManager);
                    that.formAction = ko.observable();

                    //approve or reject
                    that.formAction.subscribe(function(newValue) {
                        that.value(newValue);
                    });
                    
                    that.onSliderToggle = function() {
                        if($.browser.msie && $.browser.version < 9){
                            $('#approve-status-slider-element').removeClass("red");
                            $('#approve-status-slider-element').removeClass("green");

                            $('#enableTitle').removeClass("approve-status-element-white");
                            $('#disableTitle').removeClass("approve-status-element-white");

                            $('#enableTitle').addClass("approve-status-element-black");
                            $('#disableTitle').addClass("approve-status-element-black");

                            $('#approve-status-slider div').removeClass("switch ios");

                            $('#approve-status-slider label').css("display", "inline");
                            $('#approve-status-slider input').css("display", "inline");
                        } else {
                            if(that.formAction() === "Approve") {
                                //Add or remove css classes based on slider position
                                $('#approve-status-slider-element').addClass("slide-button green");
                                $('#enableTitle').addClass("approve-status-element-white");
                                $('#disableTitle').addClass("approve-status-element-black");

                                $('#approve-status-slider-element').removeClass("red");
                                $('#enableTitle').removeClass("approve-status-element-black");
                                $('#disableTitle').removeClass("approve-status-element-white");
                            } else if (that.formAction()=== "Reject") {
                                $('#approve-status-slider-element').addClass("slide-button red");
                                $('#enableTitle').addClass("approve-status-element-black");
                                $('#disableTitle').addClass("approve-status-element-white");

                                $('#approve-status-slider-element').removeClass("green");
                                $('#enableTitle').removeClass("approve-status-element-white");
                                $('#disableTitle').removeClass("approve-status-element-black");
                            }
                        }
                    };

                    return that;
                }
            };
        }();

        Formsupport.DelimitedListSelectionView = Backbone.Layout.extend({
            //We set the template in the initalize
            template: 'search/delimitedlist-popover',
            events: {
                'click #delimited-items-select-btn' : 'triggerSelectedItemsDone',
                'keyup #delimited-list-content': 'validateInput',
            },
            initialize: function(options) {
                this.activeControl = options.control;
            },
            validateInput: function() {
                // Getting the content from the associated textbox
                var delimitedText = $("#delimited-list-content").val().trim();

                // If there is no text, don't let the user click the add button
                if (delimitedText.length === 0) {
                    this.disableAddButton();
                } else {
                    this.enableAddButton();
                }
            },
            enableAddButton: function() {
                this.$("#delimited-items-select-btn").removeClass("disabled");
            },
            disableAddButton: function() {
                this.$("#delimited-items-select-btn").addClass("disabled");
            },
            triggerSelectedItemsDone: function() {
                // Getting the content from the associated textbox
                var delimitedText = $("#delimited-list-content").val();
                // Split each element off by the appropriate delimiter (defaults to ',')
                var selectedItems = delimitedText.split(this.activeControl.listDelimiter);
                // Trim all the elements in the array
                selectedItems = selectedItems.map(function (item) {
                    return item.trim();
                });

                // Merge the values being added and the values of the control as it stands
                // This also removes duplicates
                selectedItems = _.union(this.activeControl.value(), selectedItems);

                // Reject any empty values ("", null, etc)
                selectedItems = _.reject(selectedItems, _.isEmpty);

                // Set the values on the control
                this.activeControl.value(selectedItems);

                // Trigger the hide on the popoverHandler
                app.popoverHandler.trigger("hide");
            }
        });

        Formsupport.Utils = {};
        Formsupport.Validation = {};

        Formsupport.Utils.sortAndPrepend = function(value, valuesToPrepend){
            var moveElement = function (arr, from, to) {
                arr.splice(to, 0, arr.splice(from, 1)[0]);
            };

            // sort first
            value.sort();
            if (valuesToPrepend) {
                // we want to reverse these values because we are looping through
                // each one and moving those values to the front. we want the first
                // one in the config to be moved (to the front) last. hence the reverse()
                var reversedValues = valuesToPrepend.split(",").reverse();
                _.each(reversedValues, function (valueToPrepend) {
                    if (value.indexOf(valueToPrepend) > 0) {
                        var currentIndex = value.indexOf(valueToPrepend);
                        // moving value from its current index to the front
                        moveElement(value, currentIndex, 0);
                    }
                });
            }
        };

        // This function was put here for unit testing purposes
        Formsupport.Utils._validateExternalRuleHelper = function(value, control){
            var isArray = false;
            var clearInvalidValueEnabled = control.clearInvalidValueEnabled;
            var conditions = _.pluck(control.externalRules, 'ruleValue');
            var parameters = {};
            var fetchOptions = { global: false, async: true, type:'POST', contentType: 'application/json' };

            if (_.isArray(value)) {
                isArray = true;
                parameters.attrVal = value[value.length - 1];
            } else {
                parameters.attrVal = value;
            }

            parameters.objectType = control.objectType;
            parameters.attrId = control.id;
            // Assuming the parentID is the active folder in the stage
            // Therefore, will not work with bulk upload as a header action
            parameters.parentId = app.context.container.get("objectId");

            var conditionCollection = new Condition.Collection({
                nodeId: app.context.document.get("objectId"),
                conditions: conditions,
                parameters: parameters
            });

            fetchOptions.data = JSON.stringify(parameters);

            var options = {
                isArray : isArray,
                parameters : parameters,
                fetchOptions : fetchOptions,
                clearInvalidValueEnabled : clearInvalidValueEnabled,
                conditionCollection: conditionCollection
            };

            return options;
        };

		// Helper function that determines whether a particular field is valid based on FS configuration
        Formsupport.Utils._processDependentField = function(control, dependencyValidObservable, newValue, dependentAttrValName, config) {
            if (_.isUndefined(newValue)) {
                Formsupport.Utils._disableDependentControlHelper(control, dependencyValidObservable);
            } else {
                // radio buttons pass their new value in as a string instead of a bool, so need to check if string is false
                var regexAttrVal = new RegExp(config.get(dependentAttrValName));

                // Updates to accept multiple default values require us to check for values in arrays.
                if (_.isArray(newValue)) {
                    if (newValue.length > 0) {
                        // Get a match from the regex provided in the dependenAttrVal field.
                        var foundValue = _.find(newValue, function(value) {
                            return value.toString().match(regexAttrVal) !== null;
                        });
                        if (foundValue) {
                            Formsupport.Utils._enableDependentControlHelper(control, dependencyValidObservable);
                        } else {
                            Formsupport.Utils._disableDependentControlHelper(control, dependencyValidObservable);
                        }
                    } else { // Empty array means no value.
                        Formsupport.Utils._disableDependentControlHelper(control, dependencyValidObservable);
                    }
                } else if (newValue !== null && newValue !== undefined && newValue.toString().match(regexAttrVal) !== null) {
                    Formsupport.Utils._enableDependentControlHelper(control, dependencyValidObservable);
                } else {
                    Formsupport.Utils._disableDependentControlHelper(control, dependencyValidObservable);
                }
                
                if (!control.isSearchMode()) {
					control.value.valueHasMutated();
                }
            }
        };

        Formsupport.Utils._enableDependentControlHelper = function(control, dependencyValidObservable) {
            if (!control.enableDependencyValid()) {
                // We are changing from disabled to enabled, default if applicable
                if (control.defaultValues && control.defaultValues() && control.defaultValues().length > 0 && !control.isRepeating) {
                    control.value(control.defaultValues()[0]);
                }
            }
            
            //if enableDependencyValid is true, we need reapply the required variable that came in on the config
            control.required = control.configRequired;
            dependencyValidObservable(true);
        };

        Formsupport.Utils._disableDependentControlHelper = function(control, dependencyValidObservable) {
            //if we are disabling this field, clear out the value so something there doesn't get saved to repo on accident
            if (control.isRepeating) {
                control.value([]);
            } else {
                if (control.dataType === "boolean") {
                    control.value(false);
                } else if (control.defaultValues && control.defaultValues() && control.defaultValues().length > 0) {
                    control.value(control.defaultValues()[0]);
                } else {
                    control.value(null);
                }
            }

            //disabled fields should NEVER be required, so always when disabled, set required to false
            control.required = false;
            dependencyValidObservable(false);
        };

        // This function was put here for unit testing purposes
        Formsupport.Utils._validateDependantFieldsHelper = function(config, allValues){            
            // Flag that we assume to be true unless we run into an invalid dependant field
            var dependantFieldsValid = true;

            //if there is still a value that this attribute depends on that is
            //not filled in, we want to keep this attribute as readOnly until
            //the all the fields it depends on are filled
            _.each(config.get("dependsOn"), function(attr) {
				// If there is a value for the attribute in the form (allValues) we will check to see 
				// if it depends on a regex and that the attr value is valid 
                if (allValues[attr]) {
                    // We may have a regex on this attr field, we will only load the picklist if the 
                    // value of the attr matches the regex
                    var regex = _.find(config.collection.models, function(field) {
                        return field.get("ocName") === attr;
                    }).get("regex");

                    // If there is a regex and the value of the form doesn't match, don't load the picklist
                    if (regex && !allValues[attr].match(regex)) {
                        dependantFieldsValid = false;
                    }

                } else {
                    // If the field is empty it has to be invalid following the cascading picklist paradigm
                    dependantFieldsValid = false;
                }
            });
            
            return dependantFieldsValid;
        };

        Formsupport.Utils._isAttributeDeletable = function(value, control, viewModel) {
            // Attributes may not be deleted if they have already been saved and is append only is true or if readOnly is false and appendOnly is false
            var readOnly = control.readOnly();

            if (control.appendOnly) {
                var existingValues = viewModel.existingValues[control.id];
                var isExistingAttribute = _.isArray(existingValues) ? _.contains(existingValues, value) : existingValues === value;
                return !isExistingAttribute && !readOnly;
            }

            return !readOnly;
        };
        Formsupport.Utils._externalValueURLHelper = function(url, setValues){
            //Calls the URL to obtain external data packet. On success, it appends the data to the form 
            $.ajax({
                url: url, 
                type: "GET",
                async: false,
                success: function(resp){
                    setValues(resp);
                }
            });
        };

        Formsupport.Validation._processConditionFailure = function(errorObj, control, callback) {
            control.isExternalValidationRunning(false);
            
            var responseObj = JSON.parse(errorObj.responseText);
            var failureObject = {
                message: responseObj.message,
                isValid: false
            };
            
            callback(failureObject);
        };

        Formsupport.View = Backbone.Layout.extend({
            template: "formsupport"
        });

        Formsupport.ColumnView = Formsupport.View.extend({
            template: "formsupport-columns"
        });
		
        Formsupport.clearInvalidValue = function(isArray, returnValue, clearInvalidValueEnabled, parameters, control) {
            // If invalid and clearInvalidValue has been configured
            if (!returnValue && clearInvalidValueEnabled) {
                if (isArray) {
                    control.removeValue(parameters.attrVal);
                } else {
                    control.value("");
                }
            }
        };
        // Return the module for AMD compliance.
        return Formsupport;

    });
