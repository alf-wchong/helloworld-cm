define("managelegalhold",[
    "app",
    "oc",
    "modules/actions/actionmodules",
    "modules/hpiadmin/common/iosswitch",
    "modules/formsupport",
    "modules/hpiadmin/actionconfig/actions/managelegalhold/managelegalholdconfig",
    "modules/common/hpiconstants",
  ],
  
function(app, OC, actionModules, iOSSwitch, Formsupport, ManageLegalHoldCustomConfigView,HPIConstants) {
    "use strict";

    var ManageLegalHold = {};

    ManageLegalHold.CustomConfigView = ManageLegalHoldCustomConfigView.View;

    ManageLegalHold.View = Backbone.Layout.extend({
		template: "actions/managelegalhold/managelegalhold",
        events: {
            "click #onSubmit": "submitDocs"
        },

		initialize: function(options) {
            this.action = options.action;
            this.config = options.config;
            this.myHandler = this.config.get("handler");
			this.formName = this.config.get("formName");

            if(this.action.get("actionId").indexOf("group")!==-1){
                this.objectIds = this.action.attributes.parameters.objectIds;
            }else{
                this.objectIds = [this.action.attributes.parameters.objectId];
            }
            
            this.applyOrRemoveSwitch = new iOSSwitch.View({
				model: this.config,
				configModelKey: "applyOrRemoveSwitch",
				onLabel: window.localize("generic.apply"),
                offLabel: window.localize("generic.remove")
            });
            var self = this;
            app.context.configService.getFormConfig(self.formName, function(formConfig) {
                self.formView = new ManageLegalHold.FormView({
                    "formName": self.formName,
                    "objectType": formConfig.get("configuredTypes").models[0].get("ocName")
                });
                self.setViews({
                    '#hpi-config-switch': self.applyOrRemoveSwitch,
                    '#formDiv' : self.formView
                });
                self.render();
            });
        },
        submitDocs: function(){

			app[this.myHandler].trigger("loading", true); 
            app[this.myHandler].trigger("showMessage", window.localize("action.manageLegalHold.pleaseWait"));

            this.action.get("parameters").legalProps = this.formView.options.propertiesViewModel.getValues();
            this.action.get("parameters").applyHold =  this.config.get("applyOrRemoveSwitch");
            this.action.get("parameters").objectIds = this.objectIds;
            this.action.get("parameters").legalHoldPropName =  this.config.get("legalHoldAttr");


            this.action.execute({
                context:this,
                success: this.successfulLegalHoldSetting,
                error: this.failedLegalHoldSetting
            });
        },
        failedLegalHoldSetting:function(){
            app[this.myHandler].trigger("loading", false);
            app[this.myHandler].trigger("showError", window.localize("action.manageLegalHold.failedToApplyHold"));
        },
        successfulLegalHoldSetting: function(data){

            if(this.searchResultsViewController){
    
                var ocoArray =[];
                var deferredArray = [];
                var self= this;
                _.each(data.result.success, function(objId){
                    var oco = new OC.OpenContentObject({
                        objectId: objId
                    });
 
                    var deferred = oco.fetch({	success: function() {
                        ocoArray.push(oco);
                    }});
                    
                    deferredArray.push(deferred);
                });

                $.when.apply($, deferredArray).then(function(){
                   var args = {'newOcos': {'models': ocoArray}};
                   self.searchResultsViewController.tableEventsRef.trigger('action:object-modified', args); 
                });

            }

            if(this.action.get("actionId").indexOf("group")===-1){
                app.trigger("stage.refresh.documentId", this.action.attributes.parameters.objectId);
            }
            app[this.myHandler].trigger("loading", false);

            var addOrRemove="";
            if(this.config.get("applyOrRemoveSwitch")){
                addOrRemove = window.localize("action.manageLegalHold.applied");
            }else{
                addOrRemove = window.localize("action.manageLegalHold.removed");
            }

            if(data.result.success.length > 0){
                var picklistLabelListToDisplay = [];
                var addedPropVals = data.result.addedProps;
                self = this;
                _.each(addedPropVals, function(picklistValue){
                    var pickListProps = _.findWhere(self.formView.options.propertiesViewModel.controls()[0].picklistConfig.get("options"), {value: picklistValue});
                    picklistLabelListToDisplay.push(pickListProps.label); 
                });

                var successDocs = {
                    message: window.localize("action.manageLegalHold.legalHolds") + addOrRemove,
                    values: picklistLabelListToDisplay
                };

                var succeededDocsView = new ManageLegalHold.DocErrorFailView({
                    docs: successDocs
                });

                app[this.myHandler].trigger("showMessage", succeededDocsView);
            }

            if(data.result.failed.length > 0){
                
                var errorDocs = {
                    message: window.localize("action.manageLegalHold.documentsFailed"),
                    values: data.result.failed
                };
            
                var erroredDocsView = new ManageLegalHold.DocErrorFailView({
                    docs: errorDocs
                });
                
                app[this.myHandler].trigger("showError", erroredDocsView, true);
            }

        },
        serialize:function(){
            return {
                modal : this.myHandler === HPIConstants.Handlers.ModalActionHandler
            };
        }
        
    });

    ManageLegalHold.DocErrorFailView = Backbone.Layout.extend({

        template: "actions/managelegalhold/docerrorfailview",
        initialize: function(options) {
            this.docs = options.docs;
        },
        serialize: function() {
            return {
                docs: this.docs
            };
        }
    });
    

    // Container for form support - modeled after bulkupload
	ManageLegalHold.FormView = Backbone.Layout.extend({
        template: "actions/managelegalhold/fs-template",
		initialize: function() {
			var self = this;
			// we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
			// on the bulk properties page)
			var defaults = {
				properties: {},
				enableRequired: true
			};

			var opts = this.options = _.extend(defaults, this.options);

			// this properties view model is what form support uses to put its controls on and other functions
			var propertiesViewModel = this.options.propertiesViewModel = {};

			// init form support - we only want atCreation attributes to show up
			Formsupport.tsgFormSupport(propertiesViewModel, { 
				'isCreate': true, 
				'enableRequired': opts.enableRequired,
				'formName': opts.formName 
			});

			// set the form control properties once the controls have finished building
			propertiesViewModel.controls.subscribe(function() {
				// set our initial values once the controls have built
				propertiesViewModel.setValues(opts.properties);
			});

			// emit an event whenever the form's validity changes
			propertiesViewModel.isValid.subscribe(function(isValid) {
				self.trigger('formIsValid', isValid);
			});

            // set the object type which will trigger the controls to be generated
            propertiesViewModel.objectType(opts.objectType);
            
        },
		afterRender: function() {
			// form support uses knockout so let's apply those bindings
			kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
		},
		getValues: function() {
			return this.options.propertiesViewModel.getValues();
		},
		isValid: function() {
			return this.options.propertiesViewModel.isValid();
		
        },
        serialize: function() {
            return {
                objectType: this.options.objectType,
                // whether or not we're on the bulk properties page - used to display user instructions about what happens
                // with these bulk properties
                bulkProperties: this.options.bulkProperties,
                // only used if we're not in bulk properties page - to display the original document name of the document
                // currently being edited
                title: this.options.title
            };
        }
    });
    
    actionModules.registerAction("manageLegalHold", ManageLegalHold, {
        "actionId" : "manageLegalHold",
        "label" : "Manage Legal Hold",
        "icon" : "file-minus"
    });

    actionModules.registerAction("manageLegalHold-group", ManageLegalHold, {
		"actionId" : "manageLegalHold-group",
		"label" : "Manage Legal Hold",
		"icon" : "forward"
	});
  
    return ManageLegalHold;
});


  
require(["managelegalhold"]);