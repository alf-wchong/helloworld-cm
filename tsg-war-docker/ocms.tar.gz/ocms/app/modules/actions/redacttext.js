define("redacttext", [
		"app",
		"modules/actions/actionmodules",
		"oc"
	],
	function (app, actionModules, OC) {
		"use strict";

		var RedactText = {};

		RedactText.FolderView = Backbone.View.extend({
			template: "actions/redacttext/redacttextfolderview",
			events: {
				"change .redact-text-folder-properties": "folderPropertySelected",
				"click #add-custom-text-btn": "addCustomText",
				"keyup #custom-text-input": "checkInputLengthAndUpdateValue",
				"click #unselect-prop": "unSelectProperty",
				"keydown #custom-text-input": "checkForEnter"
			},
			initialize: function (options) {
				var self = this;
				this.action = options.action;
				this.selectedPropertyAttrs = [];
				//remove any Property that has a value of null
				this.potentialPropertyAttrs = _.reject(_.keys(app.context.container.get("properties")), function (val) {
					return app.context.container.get("properties")[val] === null ||
						//eliminate properties with boolean values
						app.context.container.get("properties")[val] === false ||
						app.context.container.get("properties")[val] === true;
				});

				//Converting to ocName and populating list with the dropdown with these names
				app.context.configService.getLabels(app.context.container.get("objectType"), this.potentialPropertyAttrs).done(function (typeLabels) {
					self.potentialPropertyAttrs = typeLabels.sort(self.sortLabelsAlphabetically);
					self.render();
				});
			},
			sortLabelsAlphabetically: function (a, b) {
				if (a.label.toUpperCase() < b.label.toUpperCase()) {
					return -1;
				} else {
					return 1;
				}
			},
			unSelectProperty: function (evt) {
				//gets ocName of the selected property
				var key = $(evt.currentTarget).attr('key');
				var propertySelected = (_.findWhere(this.selectedPropertyAttrs, {
					'key': key
				}));
				
				this.selectedPropertyAttrs = _.without(this.selectedPropertyAttrs, _.findWhere(this.selectedPropertyAttrs, {
					'key': key
				}));

				this.action.get("parameters").stringsToRedact = _.without(this.action.get("parameters").stringsToRedact, propertySelected.value);
				
				if (!propertySelected.custom) {
					this.potentialPropertyAttrs.push({
						"label":  propertySelected.key,
						"ocName":  propertySelected.ocName
					});
					//sort dropdown alphabetically
					this.potentialPropertyAttrs.sort(this.sortLabelsAlphabetically);	
				} 
				this.render();
			},
			addCustomText: function () {

				//Don't do anything if no text is entered in the textbox
				if(!this.currentInputValue) {
					return;
				}

				//doesn't allow more than one string of the same name
				if (!(_.contains(_.pluck(this.selectedPropertyAttrs, 'value'), this.currentInputValue))) {
					this.selectedPropertyAttrs.push({
						"key": this.currentInputValue.replace(/ /g,"_"),
						"value": this.currentInputValue,
						"custom": true
					});

					//sends customText to Java
					this.action.get("parameters").stringsToRedact.push(this.currentInputValue);
				} else {
					alert(window.localize("action.redactText.textAlreadyRedacted"));
				}

				this.render();
			},
			folderPropertySelected: function (evt) {
				var propertySelected = evt.currentTarget.value;
				var valueOfSelectedProperty = app.context.container.get("properties")[propertySelected];
				//removes selected property from dropdown and pushes it to the right
				this.potentialPropertyAttrs = _.without(this.potentialPropertyAttrs, _.findWhere(this.potentialPropertyAttrs, {
					'ocName': propertySelected
				}));
				this.selectedPropertyAttrs.push({
					"key": propertySelected,
					"value": valueOfSelectedProperty.toString(),
					"ocName": propertySelected,
					"custom": false
				});
				//Sends the parameter as a string to redact from file
				this.action.get("parameters").stringsToRedact.push(valueOfSelectedProperty.toString()); //This line needs to convert bool to true or false

				this.render();
			},
			checkInputLengthAndUpdateValue: function (evt) {
				//keeps track of the input value of the text box
				this.currentInputValue = evt.currentTarget.value;

				//catch the enter key to prevent the query text being set as the selected user
				var code = evt.keyCode || evt.which;
				if (code == 13) {
					//prevent default for enter key only
					this.addCustomText();
				}
			},
			afterRender: function () {
				// focus on the input for a better user experience
				$("#custom-text-input").focus();
				$('#btn-redact').attr('disabled', this.selectedPropertyAttrs.length === 0);
				this.currentInputValue = "";
			},
			serialize: function () {
				return {
					potentialPropertyAttrs: this.potentialPropertyAttrs,
					selectedPropertyAttrs: this.selectedPropertyAttrs,
					customText: this.selectedPropertyAttrs.custom
				};
			}
		});

		RedactText.GroupedView = Backbone.View.extend({
			template: "actions/redacttext/redacttextgroupedview",
			events: {
				"click #add-custom-text-btn": "addCustomText",
				"keyup #custom-text-input": "checkInputLengthAndUpdateValue",
				"click #unselect-prop": "unSelectProperty",
				"keydown #custom-text-input": "checkForEnter"
			},
			initialize: function (options) {
				this.action = options.action;
				$('#btn-redact').attr('disabled', true);

				this.selectedPropertyAttrs = [];

				// TODO rename this ID
				this.initialSearchText = $("#quick-search-input").val();
			},
			checkInputLengthAndUpdateValue: function (evt) {
				this.currentInputValue = $("#custom-text-input").val();			
				if (evt && evt.keyCode  == 13) {
					//prevent default for enter key only
					this.addCustomText();
				}
			},

			unSelectProperty: function (evt) {
				var valueOfSelectedProperty = $(evt.currentTarget).attr('val');
				//remove selected property from list
				this.selectedPropertyAttrs = _.without(this.selectedPropertyAttrs, _.findWhere(this.selectedPropertyAttrs, {
					'value': valueOfSelectedProperty
				}));

				this.action.get("parameters").stringsToRedact = _.without(this.action.get("parameters").stringsToRedact, valueOfSelectedProperty);
				
				this.render();
			},

			addCustomText: function () {

				//Don't do anything if no text is entered in the textbox
				if(!this.currentInputValue) {
					return;
				}

				//doesn't allow more than one string of the same name
				if (!(_.contains(_.pluck(this.selectedPropertyAttrs, 'value'), this.currentInputValue))) {
					this.selectedPropertyAttrs.push({
						"key": this.currentInputValue.replace(/ /g,"_"),
						"value": this.currentInputValue
					});

					//sends customText to Java
					this.action.get("parameters").stringsToRedact.push(this.currentInputValue);
				} else {
					alert("Text is already being redacted, please enter a new term.");
				}
				this.render();
			}, //copied in from the folderview
			afterRender: function () {
				if(this.initialSearchText && this.initialSearchText.length > 0) {
					$("#custom-text-input").val(this.initialSearchText);
					this.checkInputLengthAndUpdateValue();
					this.initialSearchText = "";
				}
				$("#custom-text-input").focus();
				$('#btn-redact').attr('disabled', this.selectedPropertyAttrs.length === 0);
				this.currentInputValue = "";
			},
			serialize: function () {
				return {
					selectedPropertyAttrs: this.selectedPropertyAttrs
				};

			}
		});

		RedactText.View = Backbone.Layout.extend({
			template: "actions/redacttext/redacttextbaseview",
			events: {
				"click #btn-redact": "submitAction"
			},
			initialize: function (options) {
				this.config = options.config;
				this.action = options.action;
				this.myHandler = options.config.get("handler");
				this.redactedText = "";
				this.failedBulkRedactIDs = [];
				
				this.action.get("parameters").stringsToRedact = [];
			},
			submitAction: function () {
				var self = this;
				var quickViewSearchValue = $("#redactedText").val();
				
				// auto populates the redact text box on launch with what the user
				// searches in "quick search"
				if (quickViewSearchValue) {
					this.redactedText = quickViewSearchValue;
				}

				if (this.action.get("parameters").context === "searchResultControls") {
					this.action.get("parameters").actionContext = "searchResults";
				} else {
					this.action.get("parameters").actionContext = "folder";
				}
				
				// This specifies the redaction "mode" (either "permanent" or "as copy")
				this.action.get("parameters").redactionMode = self.config.get("redactionMode");

				// execute this action
				this.action.execute({
					success: function (data) {
						if(data.result.length > 0){
							var ocoArray =[];
							var deferredArray = [];
							var errorText = '';
							_.each(data.result, function(result){
								var oco = new OC.OpenContentObject({
									objectId: result
								});
								var deferred = oco.fetch({	success: function() {
									ocoArray.push(" " + oco.attributes.properties.objectName);
									errorText += "<li>" + oco.attributes.properties.objectName + "</li>";
								}});
								
								deferredArray.push(deferred);							
							});

							$.when.apply($, deferredArray).then(function(){
								if(ocoArray.length > 0){
									app[self.myHandler].trigger("showMessage", "Redaction completed. The following documents could not be redacted:" + "<ul>" + errorText + "</ul>");
								}else {
									app[self.myHandler].trigger("showMessage", "Redaction completed.");	
								}
							 });
						}
						app[self.myHandler].trigger("loading", false);
						app.trigger("stage.refresh.bothIds", true, true);
					}
				});
			},

			afterRender: function () {
				// based on where we are launching the action, 
				if (this.action.get("parameters").context === "searchResultControls") {
					this.insertView("#view-container", new RedactText.GroupedView({
						action: this.action
					})).render();
				} else {
					this.insertView("#view-container", new RedactText.FolderView({
						action: this.action
					})).render();
				}
			},

			serialize: function () {
				var modal = false;
				var rightSide = false;
				if (this.myHandler === "modalActionHandler") {
					modal = true;
				} else if (this.myHandler === "rightSideActionHandler") {
					rightSide = true;
				}

				return {
					modal: modal,
					rightSide: rightSide
				};

			}
		});

		RedactText.CustomConfigView = Backbone.Layout.extend({
			template: "actions/redacttext/redacttextconfig",

			initialize: function () {
				var self = this;
				this.documentTypeVent = _.extend({}, Backbone.Events);

				this.viewModel = self.options.viewModel;
				this.model = this.viewModel.model();
				this.options.viewModel.redactionMode = kb.observable(this.options.viewModel.model(), "redactionMode");
			},

			afterRender: function () {
				kb.applyBindings(this.options.viewModel, this.$el[0]);
			}
		});

		actionModules.registerAction("redactFolderDocuments", RedactText, {
			"actionId": "redactFolderDocuments",
			"label": "Redact Text",
			"icon": "fingerprint-remove",
			"handler": "modalActionHandler"
		});

		actionModules.registerAction("redactDocuments", RedactText, {
			"actionId": "redactDocuments",
			"label": "Redact Text",
			"icon": "fingerprint-remove",
			"handler": "modalActionHandler"
		});

		return RedactText;
	});
require(["redacttext"]);