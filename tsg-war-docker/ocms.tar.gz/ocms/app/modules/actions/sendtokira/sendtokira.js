//@author: Graham Singer
define("sendtokira", [
        // Application.
        "app",
        "modules/actions/actionmodules",
        "modules/hpiadmin/actionconfig/actions/sendtokira/sendtokiracustomactionconfig",
    ],

    // Map dependencies from above array.
    function (app, actionModules, SendToKiraCustomConfigView) {
        "use strict";
        var SendToKira = {};

        // setting our custom config view
        SendToKira.CustomConfigView = SendToKiraCustomConfigView.CustomConfigView;

        SendToKira.View = Backbone.Layout.extend({
            template: "actions/sendtokira/sendtokira",
            events: {
                "click #sendToKiraSubmit": "executeAction",
                "change #kiraProjectSelector": "updateProjectNumber"
            },
            initialize: function (options) {
                this.action = options.action;

                this.myHandler = this.options.config.get("handler");

                // grabbing the configured projects from the config
                this.kiraProjects = this.options.config.get("configuredProjects");
            },

            executeAction: function () {
                var self = this;

                // the action parameters 
                var params = {
                    objectId: app.context.document.get("objectId"),
                    projectId: this.projectNumber
                };

                // setting the action params
                this.action.set("parameters", params);
                this.action.execute({
                    success: self._success,
                    context: this
                });
            },

            _success: function () {
                app[this.myHandler].trigger("showMessage", (window.localize("action.sendToKira.success")));
            },

            // event that updates the 'projectNumber' variable
            updateProjectNumber: function (e) {
                this.projectNumber = $(e.currentTarget).val();
                $("#sendToKiraSubmit").prop("disabled", false);
            },

            serialize: function () {
                return {
                    modal: this.myHandler === "modalActionHandler",
                    rightSide: this.myHandler === "rightSideActionHandler",
                    kiraProjects: this.kiraProjects
                };
            }
        });

        actionModules.registerAction("sendToKira", SendToKira, {
            "actionId": "sendToKira",
            "label": "Send to Kira",
            "icon": "send"
        });


        actionModules.registerAction("sendToKira-group", SendToKira, {
            "actionId": "sendToKira-group",
            "label": "Send to Kira",
            "icon": "send"
        });

        return SendToKira;
    });
require(["sendtokira"]);