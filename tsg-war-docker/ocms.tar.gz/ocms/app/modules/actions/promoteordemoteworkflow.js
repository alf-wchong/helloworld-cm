define("promoteordemoteworkflow", [
	'app',
	"module",
	"promoteordemote",
	"modules/actions/actionmodules",
	"modules/common/spinner",
	"modules/common/hpiconstants"

],
function(app, module, PromoteOrDemote, actionModules, HPISpinner, HPIConstants){
	"use strict";

	var PromoteOrDemoteWorkflow = _.extend({}, PromoteOrDemote);

	PromoteOrDemoteWorkflow.View = PromoteOrDemote.View.extend({
		initialize: function(){
			var self = this;
			this.action = this.options.action;
			this.objectId = this.action.get("parameters").objectId;
			this.myHandler = this.options.config.get("handler");

            $.when(this.setObjectIds()).done(function(){        	
				self.tableView = new PromoteOrDemote.TableView({
					'objectIds': self.objectIds,
					'config': self.options.config
				});
				self.listenTo(self.tableView,"showTypeahead",self.createTypeahead);
				self.toggleLoader = function(bool) {
					app[self.myHandler].trigger("loading", bool);
				};
				self.render();
            });
		},
		setObjectIds: function(){
			// create spinner
			var spinElem = this.$el.find("#pd-container");
			this.spinner = HPISpinner.createSpinner({
				color: '#fff',
				shadow: true
			}, spinElem);

            return $.ajax({
	            type : "GET",
	            contentType: "application/json",
	            url: app.serviceUrlRoot + "/aw-workflow/getWFDocs?formId=" + this.objectId,
	            context:this,
	            success: function (result) {
		           this.objectIds = result;
		           // destroy spinner
		           HPISpinner.destroySpinner(this.spinner);
                },
                error: function() {
	      		   // destroy spinner and throw an error
	               HPISpinner.destroySpinner(this.spinner);
	               app[this.myHandler].trigger("showError", window.localize("action.promoteordemoteworkflow.errorGettingIds"));
                }
            });
		},
		beforeRender: function() { 
			if (!this.spinner.el){
				this.setView(".table-outlet",this.tableView);
			}
		},
		afterRender: function() {
			if (!this.spinner.el){
				this.tableView.render();
				this.rendered = true;
				this.trigger('rendered');
			}
		},
		serialize: function() {
        	if (!this.spinner.el){
	            var modal = false;
	            var rightSide = false;
	            if (this.myHandler === HPIConstants.Handlers.ModalActionHandler) {
	                modal = true;
	            } else if (this.myHandler === HPIConstants.Handlers.RightSideActionHandler) {
	                rightSide = true;
	            }
	            return {
	                modal : modal,
	                rightSide : rightSide,
	                allSameType : this.tableView.allSameType,
	                submitButton : this.getLocalizations().submitButton,
	                cancelButton : this.getLocalizations().cancelButton,
	                instructions : this.getLocalizations().instructions

	            };
	        }
        }
	});

	actionModules.registerAction("promoteOrDemoteWorkflow", PromoteOrDemoteWorkflow, {
	    "actionId" : "promoteOrDemoteWorkflow",
	  	"label" : (window.localize("modules.actions.promoteOrDemote.promoteOrDemote")),
	  	"icon" : "fast-forward"
	});

	return PromoteOrDemoteWorkflow;
});
require(["promoteordemoteworkflow"]);
