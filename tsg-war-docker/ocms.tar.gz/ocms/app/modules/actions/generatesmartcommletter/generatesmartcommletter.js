define("generatesmartcommletter",[
	"app",
	"modules/actions/actionmodules",
	'modules/common/hpiconstants',
	"modules/formsupport",
	'sendsmartcomm',
	'modules/hpiadmin/actionconfig/actions/generatesmartcommletter/generatesmartcommlettercustomactionconfig'
],

function(app, actionModules, HPIConstants, Formsupport, SendSmartcomm, GenerateSmartcommLetterCustomConfigView) {
	"use strict";
	
	var GenerateSmartcommLetter = {
		'Events': _.extend({}, Backbone.Events)
	};

	GenerateSmartcommLetter.TemplatesView = SendSmartcomm.TemplatesView.extend({});

	GenerateSmartcommLetter.LetterBodyView = SendSmartcomm.EmailBodyView.extend({});

	GenerateSmartcommLetter.CustomConfigView = GenerateSmartcommLetterCustomConfigView.View;

	// Model containing all of the information needed to make any SmartComm requests
	GenerateSmartcommLetter.Model = Backbone.Model.extend({
		defaults: function() {
			return {
				attributesToDisplay: []
			};
		},
		// This should be updated to properly use sets and gets 
		// Must be changed in sendsmartcomm too if this is changed since we extend templatesView from there
		initialize: function(config, action) {
			this.config = config;
			this.action = action;

			/***** smartcomm configs ******/
			this.projectId = this.config.get("smartCommProjectId");
			this.dataModelResId = this.config.get("smartCommDataModelId");
			this.batchConfigResId = this.config.get("smartCommBatchConfigResId");

			// get configured folder attributes
			this.configuredFolder = this.config.get("selectedFolderTypeSmartComm");
			this.smartCommAttrs = this.config.get("smartCommAttrsToDisplay");
			this.attributesToDisplay = this.config.get('attrsToDisplay') ? this.config.get('attrsToDisplay') : [];
			this.form = this.config.get("form");
			this.objectType = this.config.get("selectedDocumentType");
		}
	});

	GenerateSmartcommLetter.View = Backbone.Layout.extend({
		template: "actions/generatesmartcommletter/generatesmartcommletter",
		events: {
			"click #generateLetterButton": "executeAction"
		},
		initialize: function(){
			this.handler = this.options.config.get("handler");

			this.model = new GenerateSmartcommLetter.Model(this.options.config, this.options.action);

			// Set up views
			this.bodyView = new GenerateSmartcommLetter.LetterBodyView();
			this.propertiesView = new GenerateSmartcommLetter.View.Properties({
				'objectType': this.model.objectType,
				'properties': app.context.container.get("properties"),
				'formName': this.model.form
			});
			this.setViews({
				'#letterBody-outlet': this.bodyView,
				'#letterProperties-outlet': this.propertiesView
			});

			// Set up the available templates
			this.fetchPrintTemplates();
			this.startListening();
		},

		startListening: function(){
			// Validate any time the properties in the properties view change
			this.listenTo(GenerateSmartcommLetter.Events, 'properties:changed', this.validate);
		},

		validate: function(){
			// Properties need to be valid as determined by formsupport
			var propertiesValid = this.propertiesView.isValid();

			// Need a template loaded into the editor in order to generate the document
			// Changing properties can trigger validate before the templates are loaded in
			var templateValid = false;
			if(this.templatesView){
				templateValid = this.templatesView.selectedTemplate != null;
			}

			this.$('#generateLetterButton').prop('disabled', !templateValid || !propertiesValid);
		},

		fetchPrintTemplates: function(){
			var body = {"dataModelResId": this.model.dataModelResId};
			var getTemplateIdsOCUrl = "smartcomm/getTemplateIds";
			var getTemplateIdsUrl = app.serviceUrlRoot + "/" + getTemplateIdsOCUrl;

			Backbone.ajax({
				context: this,
				type: "POST",
				url: getTemplateIdsUrl,
				data: JSON.stringify(body),
				contentType: "application/json",
				success: function(response) {
					this.templates = new Backbone.Collection(response.templateIds);
				},
				error: function() {
					this.templates = new Backbone.Collection([]);
				},
				complete: this.createAndRenderTemplatesView
			});
		},

		createAndRenderTemplatesView: function () {
			this.templatesView = new GenerateSmartcommLetter.TemplatesView({
				templates: this.templates,
				smartCommModel: this.model
			});
			this.setView("#templates-outlet", this.templatesView).render();

			// Listen for a new template being loaded in 
			this.listenToOnce(this.templatesView, 'sendEmail:emailSubjectView:insertSubjectText', this.validate);
		},

		executeAction: function() {
			var self = this;
			
			app[self.handler].trigger("loading", true);

			// Get properties that were set for the new object
			var unwrappedPropertiesMap = {};
			_.each(self.propertiesView.getValues(), function(item, key) {
				unwrappedPropertiesMap["prop-" + key] = item;
			});
			this.model.action.get("parameters").properties = unwrappedPropertiesMap;
			this.model.action.get("parameters").objectType = this.model.objectType;
			this.model.action.get("parameters").folderId = app.context.container.id;

			window.ThunderheadEditor._sendCommand('getString', {forceSave: false}, function(success, XMLofLetterBody){
				// Once we call this callback, use the body returned here
				self.model.action.get("parameters").body = XMLofLetterBody;
				self.model.action.execute({
					success: function(result){
						app[self.handler].trigger("loading", false);

						// Show a link to the newly created document
						var url = "StageSimple/" + result.result;
						var message = '<label>'+ (window.localize("modules.actions.generateSmartcommLetter.generateSuccessful")) +'</label><a style="padding: 5px" data-bypass href=' + url +
							'>' + self.model.action.get("parameters").properties["prop-objectName"] + '</a>';
						app[self.handler].trigger("showMessage", message);
					},
					error: function(jqXHR){
						app[self.handler].trigger("loading", false);
						app[self.handler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) + jqXHR.responseText);
					}
				});
			}, window.ThunderheadEditor);
		},

		serialize: function() {
			return {
				modal: this.handler === HPIConstants.Handlers.ModalActionHandler
			};
		}
	});

	GenerateSmartcommLetter.View.Properties = Backbone.Layout.extend({
		template: "actions/generatesmartcommletter/generatesmartcommletterproperties",
		initialize: function() {
			var self = this;
			// Get the folder properties to populate properties form
			this.options.propertiesViewModel = {};

			Formsupport.tsgFormSupport(this.options.propertiesViewModel, {
				'isCreate':true,
				'formName':this.options.formName
			});

			// Set the form control properties once the controls have finished building
			this.options.propertiesViewModel.controls.subscribe(function() {
				// Set our initial values once the controls have built
				self.options.propertiesViewModel.setValues(self.options.properties);
			});

			// Emit an event whenever the form's validity changes
			this.options.propertiesViewModel.isValid.subscribe(function(isValid) {
				GenerateSmartcommLetter.Events.trigger('properties:changed', isValid);
			});

			// Set the object type which will trigger the controls to be generated
			this.options.propertiesViewModel.objectType(this.options.objectType);

		},
		getValues: function() {
			return this.options.propertiesViewModel.getValues();
		},
		isValid: function() {
			return this.options.propertiesViewModel.isValid();
		},
		afterRender: function() {
			// Form support uses knockout so let's apply those bindings
			kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("generateSmartcommLetter", GenerateSmartcommLetter, {
		"actionId" : "generateSmartcommLetter",
		"label" : "Generate SmartComm Letter",
		"icon" : "envelope"
	});

	return GenerateSmartcommLetter;

});
require(["generatesmartcommletter"]);