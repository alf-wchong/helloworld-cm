define("permanentredact",[
    "app",
    "modules/actions/actionmodules"
],
function(app, actionModules) {
    "use strict";

    var PermanentRedact = {};
    
    PermanentRedact.View = Backbone.Layout.extend({
        template: "actions/permanentredact",
        initialize: function() {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
            window.open(app.openAnnotateURL +
             "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&parentId=" + app.context.container.get('properties').objectId +
             "&username=" + app.user.get("loginName") + "&mode=redact");
        },
        events: {
            "click #redact-ok" : "dismiss"
        },
        serialize: function() {            
            return {
                message: (window.localize("modules.actions.permanentRedact.wereOpening")),
                modal: this.myHandler === "modalActionHandler"
            };
        },
        dismiss: function() {
            app.trigger("stage.refresh.documentId", true);
        }

    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("permanentRedact", PermanentRedact, {
       "actionId": "permanentRedact",
       "label": "Redact",
       "icon": "exclamation-sign"
    });

    return PermanentRedact;
});
require(["permanentredact"]);
