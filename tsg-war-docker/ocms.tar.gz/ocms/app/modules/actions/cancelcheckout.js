// Advancedsearch module
define("cancelcheckout",[
  // Application.
  "app",
  "modules/common/action",
  "modules/actions/actionmodules",
  "modules/hpiadmin/common/iosswitch",
  "cloudserviceauthentication",
  
],

// Map dependencies from above array.
function(app, Action, actionModules, iOSSwitch, CloudServiceAuthentication) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var CancelCheckOut = {};

    CancelCheckOut.View = Backbone.Layout.extend({
        template: "actions/cancelcheckout",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
			
			//Checking cloudMode slider in config
            this.cloudModeChecked = this.options.config.get("cloudModeChecked");
			
			if(this.cloudModeChecked === "true") {
				this.cloudMode = this.options.config.get("cloudMode");
				if(this.cloudMode === "googleDrive") {
					this.clientId = this.options.config.get("googleDriveClientId");
					this.repositoryVariable = this.options.config.get("repositoryVariable");
				}else{
					this.clientId = this.options.config.get("oneDriveClientId");
					this.redirectUrl = this.options.config.get("oneDriveRedirectUrl");
                    this.oneDriveType = this.options.config.get("oneDriveType");
				}
			}   
        },
        toggleLoader: function(bool){
            app[this.myHandler].trigger("loading", bool);
        },
        beforeRender: function() {
            var self = this;
            this.viewModel = {
                cancelCheckout: function() {
                    //taskId must be on the action
                    var objectId = self.action.get("parameters").objectId;
                    self.action.get("parameters").accessToken = self.accessToken;
					self.action.get("parameters").cloudMode = self.cloudMode;
					self.action.get("parameters").repositoryVariable = self.repositoryVariable;
                    self.action.get("parameters").oneDriveType = self.oneDriveType;

                    if(objectId === undefined){
                        app[self.myHandler].trigger( "showError", (window.localize("modules.actions.cancelCheckout.unableToCancel")));
                    }else{
                        self.toggleLoader(true);
                        self.action.execute({
                            success: function(data) {
                                self.toggleLoader(false);
                                app[self.myHandler].trigger( "showMessage",(window.localize("modules.actions.cancelCheckout.cancelledCheckout")));

                                self.listenToOnce( app.modalActionHandler, "hide", function(){
                                    app.trigger("stage.refresh.documentId", data.result);
                                });
                            },
                            error : function(jqXHR) {
                                self.toggleLoader(false);
                                app[self.myHandler].trigger( "showError", (window.localize("modules.actions.cancelCheckout.failedToCancel")) +
                                        jqXHR.status + " " + jqXHR.responseText);
                            }
                        });
                    }
                }
            };
        },
        afterRender: function() {
			if (this.cloudModeChecked === "true"){
				if (this.cloudMode === "googleDrive") {
					//googleDrive
					this.listenTo(app, "cloudservicesauthentication:google:authenticated", function(result){
						this.accessToken = result.access_token;
						$('#cancelCheckoutButton').prop('disabled', false);
					});
    
					CloudServiceAuthentication.googleDrive.authenticate({
						client_id: this.clientId,
						scope: "https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/drive.file",
						immediate: false
					});
				} else{
					//oneDrive
					this.listenTo(app, "cloudservicesauthentication:microsoft365:authenticated", function(accessToken){
						this.accessToken = accessToken;
						$('#cancelCheckoutButton').prop('disabled', false);
					});

					CloudServiceAuthentication.microsoft365.authenticate({
						clientId: this.clientId,
						redirectUrl: this.redirectUrl
					});	
				}
            } else {
                $('#cancelCheckoutButton').prop('disabled', false);
            }

            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function(){
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
    });
    
    CancelCheckOut.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/cancelcheckoutconfig",
        initialize: function(){
            var viewModel = this.options.viewModel;
            
            viewModel.cloudModeChecked = kb.observable(this.viewModel.model(), 'cloudModeChecked');
			viewModel.cloudMode = kb.observable(this.viewModel.model(), 'cloudMode');
            viewModel.oneDriveClientId = kb.observable(this.viewModel.model(),"oneDriveClientId");
            viewModel.oneDriveType = kb.observable(this.viewModel.model(),"oneDriveType");
            viewModel.oneDriveRedirectUrl = kb.observable(this.viewModel.model(),"oneDriveRedirectUrl");
			viewModel.googleDriveClientId = kb.observable(this.viewModel.model(),"googleDriveClientId");
			viewModel.repositoryVariable = kb.observable(this.viewModel.model(), 'repositoryVariable');
			
            if(viewModel.cloudModeChecked() === null){
                viewModel.cloudModeChecked(false);
            }
			
			if (viewModel.repositoryVariable() === null) {
				viewModel.repositoryVariable('hpi_googleDriveId');
			}

            this.oneDriveType = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "oneDriveType",
                switchTitle: window.localize("customConfig.oneDriveConfig.oneDriveOneDriveTypeTitle"),
                configDescription: window.localize("customConfig.oneDriveConfig.oneDriveOneDriveTypeGlyphiconTitle"),
                onLabel: window.localize("customConfig.oneDriveConfig.oneDrivePersonal"),
                trueVal: "Personal",
                offLabel: window.localize("customConfig.oneDriveConfig.oneDriveOrganization"),
                falseVal: "Organization",
                defaultSwitchValue: true,
                customClass: "switch-200w"
            });

            this.setViews({
                "#oneDriveType": this.oneDriveType
            });
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    CancelCheckOut.Service = {
         execute:function(options){
            var defaultSuccess = function(){
                app.log.debug("Cancel Checkout executed successfully");
            };
            var defaultError =  function(){
                app.log.debug("Cancel Checkout executed with an error");
            };
            var action = new Action.Model({
                name:"cancelCheckout",
                parameters: options.parameters
            });
            action.execute({
                success: options.successFunction || defaultSuccess,
                error: options.errorFunction || defaultError,
                global: options.global || false,
                async: options.async || true
            });
        }
    };
    actionModules.registerAction("cancelCheckout", CancelCheckOut, {
        "actionId" : "cancelCheckout",
        "label" : "Cancel Checkout",
        "icon" : "remove"
    });
    
    return CancelCheckOut;

});
require(["cancelcheckout"]);