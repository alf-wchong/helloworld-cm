define([
    "app",
  // All actions must be registered here for bundling and overriding.
], function(app){
    var theModule = {};
    var actionMapping = {};
    var actionDynamicParams = {};
    var defaultActionConfigs = { "mock" : {
        "label" : "",
        "icon" : "",
        "handler" : "modalActionHandler",
        "subTitle" : ""
      }
};

  /*
  * This function looks at the given id and ignores anything after the dash.
  * The purpose of this is that in oc you could configure two similiar actions
  * that are suppose to use the same interface, but will do different things on the backend
  */

  theModule.getAction = function(actionId){
    var actionUIName;
    if(actionId.indexOf("-") !== -1){
        actionUIName = actionId.substr(0, actionId.indexOf("-")); 
    }else{
        actionUIName = actionId;
    }
    app.trigger("googleanalytics.logaction", actionUIName);
    return actionMapping[actionUIName];
  };

  //this function adds modules to actionMapping and defaultActionConfigs
  theModule.registerAction = function(actionId, actionModule, defaultConfig, dynamicParams){
    actionMapping [actionId] = actionModule;
    defaultConfig = _.defaults(defaultConfig, {"modalSize" : "large", "handler" : "modalActionHandler", "groups" : [], "subTitle": ""}); //Set the default for groups to an empty array
    defaultActionConfigs [actionId] = defaultConfig;
    if(dynamicParams){
      actionDynamicParams [actionId] = dynamicParams;
    }
  };

  //return default config if exists in defaultActionConfigs, else return the 'mock' config
  theModule.getDefaultConfig = function(actionId){
    var splitActionId = actionId.split("-");
    var defaultActionName = splitActionId[0];
    for(var i=1; i<splitActionId.length; i++){
      var part = splitActionId[i];
      if(!(part === "noContext" || part === "group")){
        defaultActionName += "-";
        defaultActionName += part;
      }
    }

    if(defaultActionConfigs[defaultActionName]){
      var defaultActionConfig = defaultActionConfigs[defaultActionName];
      //set actionId to full name
      defaultActionConfig.actionId = actionId;
      return defaultActionConfig;
    }
    return defaultActionConfigs.mock;
  };
 
  theModule.getAllRegisteredActionConfigs = function(){
    return defaultActionConfigs;
  };

  //Filters a list of actions by groups. Return any action that contains every group in our filter
  theModule.filterByGroupMatchingAll = function(filters, actions){
	   //If we didn't pass in an actions array, use the entire defaultActionConfiguration array
    actions = (typeof actions !== 'undefined') ?  actions : defaultActionConfigs;
    var matchingActions = _.filter(actions, function (action) {
	    //Intersect our filters array to our group array. If we get the same length as our filters array, our group contains every group in filters
      return (_.intersection(action.groups, filters).length ===  filters.length);
    });
    return matchingActions;
  };
  //Filters a list of actions by groups. Return any action that contains at least one group in our filter
  theModule.filterByGroupMatchingAny = function(filters, actions){
    //If we didn't pass in an actions array, use the entire defaultActionConfiguration array
    actions = (typeof actions !== 'undefined') ?  actions : defaultActionConfigs;
    var matchingActions = _.filter(actions, function (action) {
      //Intersect our filters array to our group array. If we get at least one result, our group contains at least one group in our filter
      return (_.intersection(action.groups, filters).length !== 0);
    });
    return matchingActions;
  };



  theModule.getDynamicParams = function(actionId){
    return actionDynamicParams[actionId];
  };

  return theModule;
});
