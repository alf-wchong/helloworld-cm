// Advancedsearch module
define("createrelationships",[
  // Application.
  "app",
  "modules/common/ocquery",
  "modules/actions/actionmodules"
],

function(app, Ocquery, actionModules) {
	"use strict";

	var CreateRelationships = app.module();

	CreateRelationships.ViewModel = function(query, options){
		var self = this;
		kb.ViewModel.prototype.constructor.call(this, query, options);  

		self.query = query;
		self.action = options.action;
		self.action.get("parameters").relatedId = [];
		self.config = options.config;

		self.searchCriteria = ko.observable();
		self.results = kb.collectionObservable(query);	// all available items
		self.selectedResults = ko.observableArray();	// list of items selected
		// the list of available types - gathered (for now) from additional props on the action
		self.relationshipTypes = ko.observableArray();
		self.relationshipType = ko.observable();		// the set relationship type that will be added

		// filter the results observable array to filter out results that should not be shown, etc.
		self.filteredResults = ko.computed(function() {
			var results = [];
			$.each(self.results(), function(itx, result) { 
				// check conditions here
				if(result.objectId() !== self.action.get("parameters").objectId) { 
					// get the result thumbnailurl
					result.thumbnailUrl = ko.observable();
					result.model().getThumbnail("small", function(thumbUrl){
						result.thumbnailUrl(thumbUrl);
					});
					results.push(result);
				}
			});
			return results;
		});

		// get the avilable relationship types from the config
		var otherProps = self.config.get("otherProperties");
		var relationshipTypes = otherProps.filter(function(prop) { 
			return prop.get("key") === "relationshipTypes";
		});
		if(!relationshipTypes || relationshipTypes.length < 1) { 
			app[self.config.get("handler")].trigger("showMessage", window.localize("modules.actions.createRelationships.warning"));
		}
		else { 
			var types = relationshipTypes[0].get("value");
			// since were just getting a comma separated list and not an array, we'll need to split and iterate
			var typesArray = types.split(",");
			_.each(typesArray, function(type) {
				// get rid of any whitespace and plop in the observableArray
				self.relationshipTypes.push(type.trim());
			});
		}

		self.search = function() { 
			
			var sp;

			// remove any old type/property/allproperties params
			query.searchParameters = _.filter(query.searchParameters, function(sParam){
				if(sParam.paramType !== 'property' && sParam.paramType !== 'type' && sParam.paramType !== 'allproperties'){
					//TODO is this appropriate to do here, or should facets clean them selves based on some event?
					sParam.paramValue = "";
					return true;
				}
				return false;
			});	

			// add a search parameter for searching upon all attributes	
			sp = {
				paramName: "allproperties",
				paramValue: self.searchCriteria(),
				paramType : "allproperties"
			};
			query.searchParameters.push(sp);

			sp = {
				// todo: fix to be configurable
				paramName: "cmhr_content",
				paramValue: "cmhr_content",
				paramType : "type"
			};
			query.searchParameters.push(sp);

			query.fetch();

		};

		/** 
			validation for submit button to be activated or not
		**/
		self.validate = ko.computed(function() { 
			var isValid = true;
			
			if(self.selectedResults().length < 1) {
				return false;
			}

			if(self.relationshipType === "" || self.relationshipType === null) {
				return false;
			}

			return isValid;
		});

		self.select = function(item) { 

			if (self.action.get("parameters").relatedId.indexOf(item.objectId()) === -1)
			{
				self.action.get("parameters").relatedId.push(item.objectId());
				// push it into the selectedResults array
				self.selectedResults.push(item);
				app.log.debug("Asset selected.");
			}
			else
			{
				app.log.debug(window.localize("modules.actions.createRelationships.cannotAdd"));
			}
				
			// add the relation type

		};

		self.selectedResults.subscribe(function(results){
			// whenever the selected results change, make sure we scroll to top
			$(".modal-body").animate({
				scrollTop: 0
			}, 400);
		});

		/** 
		* Remove a selected item from the selected items array
		**/
		self.remove = function(item) { 

			var removedResult = self.selectedResults.remove(item);
			var indexOfRemoved = self.action.get("parameters").relatedId.indexOf(item.objectId());
			if (indexOfRemoved != -1)
			{
				self.action.get("parameters").relatedId.splice(indexOfRemoved, 1);
			}
			//self.action.get("parameters").relatedId = null;
			if(removedResult) { 
				app.log.debug(window.localize("modules.actions.createRelationships.itemRemoved"));
			}

		};
		
		// relation objects that can be built up if returning the data back to the caller
		self.relation = function(id, relatedIds, relationName) { 
			return {
				id: id,
				relatedIds: relatedIds,
				relationName: relationName
			};
		};

		self.submit = function() { 

			// IF WE ARE IN RETURN MODE - THIS ACTION WON'T POST, IT JUST SETS THINGS UP ON THE "returnObject" THAT IS PASSED IN
			if(options.returnMode) {

				var targetObject = null;
				if(options.overrideIds.length > 0) {
					targetObject = options.overrideIds;
					// create a new relation for each of the override ids
					_.each(options.overrideIds, function(id) { 
						var relation = new self.relation(id, self.action.get("parameters").relatedId, self.relationshipType());

						// TODO: CHeck if this objectId already has a relation created for it, if so .. replace the existing set.
						options.returnObject.push(relation);
					});

				} else { 
					targetObject = self.action.get("parameters").objectId;
					var relation = new self.relation(targetObject, self.action.get("parameters").relatedId, self.relationshipType()); 
					options.returnObject.push(relation);
				}
	
				app[self.config.get("handler")].trigger("hide");
			}
			// HERE'S WHERE IT WILL ACTUALLY POST IF WE DONT SPECIFY RETURN MODE
			else { 
				self.action.get("parameters").relationType = self.relationshipType();
				self.action.execute({
					success: function(data) {
						// todo: simplify this response message, didnt know it would be used
						if(data.result === window.localize("modules.actions.createRelationships.successfullyAdded")) {  //maybe unlocalize
							app[self.config.get("handler")].trigger("showMessage", window.localize("modules.actions.createRelationships.relationship"));
							app.log.debug(window.localize("modules.actions.createRelationships.riggering"));
							app.trigger("refreshRelationships");
						}
					},
					error: function(jqXHR, textStatus, errorThrown) { 
						app[self.config.get("handler")].trigger("showError", window.localize("modules.actions.createRelationships.failedToCreate") +
						jqXHR.status + " " + jqXHR.statusText);
					}
				});
			}
		};

	};

	CreateRelationships.View = Backbone.Layout.extend({
		template: "actions/createrelationships",

		initialize: function(){
			var self = this;
            this.action = this.options.action;

            // return mode allows us to avoid submitting the data to the server, rather it will return it for local use or further processing
            this.returnMode = this.options.returnMode || false;
            this.returnObject = this.options.returnObject || ko.observableArray();
            this.overrideIds = this.options.overrideIds || [];

            /** Q U E R Y  S E T U P **/
            self.query = new Ocquery.Collection([]);

            self.vm = new CreateRelationships.ViewModel(self.query, { 
				action: this.action, 
				config: this.options.config, 
				returnMode: this.returnMode, 
				returnObject: this.returnObject,
				overrideIds: this.overrideIds
            });

        },
        afterRender: function() { 
			var self = this;
			kb.applyBindings(self.vm, this.$el[0]);
        },	 
        serialize: function() { 
			var self = this;
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return { 
				objectId: self.objectId,
				modal: modal
			};
        }
	});

	actionModules.registerAction("createRelationships", CreateRelationships, {
        "actionId" : "createRelationships",
      	"label": "Create Content Relationship",
      	"icon": "plus"
    });

	return CreateRelationships;

});
require(["createrelationships"]);