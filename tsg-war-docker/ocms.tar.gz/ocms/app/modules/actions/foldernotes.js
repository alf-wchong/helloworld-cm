define("foldernotes", [
	"app",
	"oc",
	"modules/actions/actionmodules",
	"handlebars",
	"modules/formsupport",
	"modules/common/downloadutils",
	"modules/common/linkformatterutil",
	"modules/common/alert/alert",
	"modules/common/action",
	"modules/hpiadmin/actionconfig/actions/foldernotes/foldernotesconfig",
	"jqueryDownload",
	"ckeditorcore"
],
	function (app, OC, actionModules, Handlebars, Formsupport, downloadUtils, LinkFormatter, Alert, Action, FolderNotesConfig) {
		"use strict";

		var FolderNotes = {};

		FolderNotes.CustomConfigView = FolderNotesConfig.View;


		// putting this function on the FolderNotes object for unit testing
		// in the view model use a bind to set up renderNoteView
		FolderNotes.renderNoteView = function () {
			var self = this;
			//set the object type from the 'otherProperties' on the config
			//looking for key 'noteObjectType'
			//defaults to HPI Note
			if (this.config.get('noteObjectType') && !this.objectType()) {
				this.objectType(this.config.get('noteObjectType'));
			} else if (!this.objectType()) {
				this.objectType("HPI Note");
			}

			//if the passed in note has an objectId, we're modifying a note, otherwise creating a new one
			// only make content call if the note we are not in contentless mode
			if (this.note() && !app.enableContentlessMode) {
				this.setValues(this.note().properties);
				//this ajax call is to return the note content
				$.ajax({
					type: 'GET',
					url: app.serviceUrlRoot + '/content/content',
					data: {
						id: this.noteId()
					},
					context: this,
					async: false,
					success: function (noteData) {
						var div = document.createElement("div");
						div.innerHTML = noteData;
						var html = div.innerHTML;
						CKEDITOR.instances.messageContent.setData(html, function () {
							$("#CKEditorDiv").show();
						});
						this.noteContent(html);
					}
				});
			// if we are in contentless mode all of the "content" resides in note_detail since we shouldn't have to worry about truncation
			} else if(this.note() && app.enableContentlessMode) {
				CKEDITOR.instances.messageContent.setData(this.note().properties.note_detail, function() {
					self.noteContent(self.note().properties.note_detail);
					$("#CKEditorDiv").show();
				});
			} else {
				CKEDITOR.instances.messageContent.setData('', function () {
					self.noteContent('');
					$("#CKEditorDiv").show();
				});
			}

			app[this.myHandler].trigger("loading", false);
			this.showIndividualNote(true);
		};

		// in the view model use a bind to set up populateNotesList
		FolderNotes.sortNotes = function (columnAttribute) {
			var self = this;
			this.list(this.list().sort(function (left, right) {
				var leftProp = left.properties[columnAttribute].toString(); // .toString() prevents errors with .toLowerCase() later if fields aren't strings
				var rightProp = right.properties[columnAttribute].toString();

				// for dates we should be comparing using the epoc time (the dateProperty + "-orig"),
				// not whatever string it gets convereted to based on the application config for date/datetimes
				if (columnAttribute.toLowerCase().search(/date/) !== -1) {
					if(columnAttribute.indexOf("-orig") == -1) {
						columnAttribute = columnAttribute + "-orig";
					}
					leftProp = window.moment(left.properties[columnAttribute]).valueOf();
					rightProp = window.moment(right.properties[columnAttribute]).valueOf();
				}
				else { // we don't want to change the case of the dates
					leftProp = leftProp.toLowerCase();
					rightProp = rightProp.toLowerCase();
				}
				var reverseModifier = (self.reverseSort ? -1 : 1); // if true ? reverse sort

				return leftProp === rightProp ? 0 : leftProp > rightProp ? 1 * reverseModifier : -1 * reverseModifier;
			}));
			this.reverseSort = !this.reverseSort; // switch the sort for next time
		};

		// in the view model use a bind to set up findAdminOTCFormat
		FolderNotes.findAdminOTCFormat = function(oc_prop, oc_value) {
			// gets the appropriate formatting for the oc_prop passed in and updates the oc_value
			app.context.configService.getAdminOTC(function(otc) { 
				var folder = otc.get("configs").findWhere({"ocName": app.context.container.get("objectType")});
				if (folder) {
					var attr = folder.get("attrs").findWhere({"ocName": oc_prop});
					if (attr && attr.get("dataType") === "date") {
						if(attr.get("filter") === "date") {
							app.context.dateService.getFormattedDate([oc_value])
								.done(function(formattedDates) {
									oc_value = formattedDates[0];
								});
						} else if (attr.get("filter") === "datetime") {
							app.context.dateService.getFormattedDatetime([oc_value])
								.done(function(formattedDates) {
									oc_value = formattedDates[0];
								});
						}
					}
				}
			});

			return oc_value;
		};

		// in the view model use a bind to set up setupTableHeader
		FolderNotes.setupTableHeader = function() {
			// when initalized, add the note icon to the first column of the table
			var noteJSON = {"attrName": "", "ocName": "noteIcon", "sortable": false};
			if (JSON.stringify(this.tableHeader()[0]) !== JSON.stringify(noteJSON)) {
				this.tableHeader.unshift(noteJSON);
			}
			for (var index = 0; index < this.tableHeader().length; ++index) {
				if (this.tableHeader()[index]["ocName"] === "note_attachment" || this.tableHeader()[index]["ocName"] === "note_detail" || this.tableHeader()[index]["ocName"] === "noteIcon") {
					// these three columns should have sort disabled
					this.tableHeader()[index]["sortable"] = false;
				}
				else {
					this.tableHeader()[index]["sortable"] = true;
				}
			}
		};

		// primary view model
		FolderNotes.ViewModel = function(action, myHandler, config) {
			var self = this;
			this.reverseSort = false;
			var conditions = action.get("conditions");

			this.config = config;
			this.myHandler = myHandler;
			
			this.canWrite = ko.observable(false);
			this.pageSize = ko.observable(10);
			this.pageIndex = ko.observable(0);
			this.list = ko.observableArray();
			this.filter = ko.observable('');
			this.filteredNotes = ko.observableArray([]);
			this.lastFilter = ko.observable();
			this.canCreate = ko.observable(true);
			this.canPrint = ko.observable(true);

			this.noteRemoved = ko.observable(false);
			this.noteVisiblityConfiguredValue = config.get("noteVisibility");
			this.noteVisibilityEnabled = ko.observable();
			this.noteVisibilityType = ko.observable("public");
			this.hideDocList = ko.observable(false);
			this.hideDocListConfiguredValue = config.get("hideDocList");
			this.docNotesEnabled = ko.observable();
			this.isEditable = ko.observable();

			this.docToIndicatorMap = {};
			this.attrToShow = config.get("attrToShow") ? config.get("attrToShow") : "objectName";
			this.availableDocuments = ko.observableArray([]);
			this.selectedDocuments = ko.observableArray([]);
			this.showIndividualNote = ko.observable(false);
			this.noteId = ko.observable();
			this.noteContent = ko.observable("");
			this.note = ko.observable();
			this.showNotes = ko.observable(true);
			this.currentNoteIsEditable = ko.observable(false);

			// Clean up logic
			this.noteVisiblityConfiguredValue = (this.noteVisiblityConfiguredValue === "true" || this.noteVisiblityConfiguredValue === true);
			this.hideDocListConfiguredValue = ((this.hideDocListConfiguredValue === "true" || this.hideDocListConfiguredValue === true) ? true : false);

			// If the notes are editable, set isEditable to true and noteVisibilityEnabled to the configured value
			if (config.get('noteEditable') && config.get('noteEditable') === "false") {
				this.isEditable(false);
				this.noteVisibilityEnabled(false);
			} else {
				this.isEditable(true);
				this.noteVisibilityEnabled(this.noteVisiblityConfiguredValue);
			}

			// If the action is configured as documentNotes or the action is folderNotes but has enableDocNotes
			// set to true, set docNotesEnabled to true
			if (config.isDocumentNotes || config.get('enableDocNotes') === "true") {
				this.docNotesEnabled(true);
			} else {
				this.docNotesEnabled(false);
			}

			// If docNotesEnabled is true and hideDocListConfiguredValue is true, set hideDocList to true
			if (this.docNotesEnabled() && this.hideDocListConfiguredValue) {
				this.hideDocList(true);
			}

			//set canCreate based on config value
			if (config.get("canCreate") === "false") {
				this.canCreate(false);
			}

			//this resets the pageIndex when the filter query changes
			this.filter.subscribe(function () {
				self.pageIndex(0);
				if (self.filter() === '') {
					//flush filteredNotes
					self.filteredNotes([]);
				}
			});


			var options = {
				enableRequired: true,
				formName: config.get("form")
			};

			Formsupport.tsgFormSupport(this, options);

			this.isValid.subscribe(function () {
				self.checkValidation();
			});

			this.resetBindings = function () {
				//start from a clean slate, clear all the values
				CKEDITOR.instances.messageContent.setData('', function () {
					self.objectType(undefined);
					self.noteContent('');
					$("#CKEditorDiv").hide();
					self.noteId("");
					self.note(undefined);
					self.showNotes(true);
					self.showIndividualNote(false);
				});
			};

			/* Removes the selected document from the list. If there are no more 
			 * selected documents, then show the tab containing all the documents.
			 */
			this.removeSelectedDocument = function (id) {
				self.selectedDocuments.remove(id);
				if (self.selectedDocuments().length === 0) {
					$("#documentsTab a:first").tab("show");
				}
			};

			/* Returns the configured attribute to display of the document whose id
			 *  is passed in the function.
			 */
			this.getAttributeToDisplayFromId = function (id) {
				self = this;
				var result = null;
				_.each(self.availableDocuments(), function (doc) {
					if (doc.objectId === id) {
						result = doc.properties[self.attrToShow];
					}
				});
				return result;
			};

			/* Returns the current objectType of our document.
			*/
			this.getDocObjectTypeFromDocList = function() {
				var docObjectType = "";
				_.each(self.availableDocuments(), function(doc) {
					if (doc.objectId === action.get("parameters").objectId) {
						docObjectType = doc.objectType;
					}
				});
				return docObjectType;
			};

			this.getDocuments = function() {
				var folderId = "";
				var documentId = "";
				var actionObjectId = action.get("parameters").objectId;

				if (!config.isDocumentNotes) {
					// If this is not the configured document notes action 
					// we know that the action objectId is going to be the folder we need
					folderId = actionObjectId;
					self.populateDocumentsList(folderId);
				} else {	
					// If we have access to the container objectId (folder), use that
					// otherwise attempt to get the primary parent
					// TODO: Fix issue with linked documents if the container objectId
					// Isn't set
					documentId = actionObjectId;

					if (app.context.container.get('properties').objectId) {
						folderId = app.context.container.get('properties').objectId;
						self.populateDocumentsList(folderId);
					} else {
						app.context.util.getParents(documentId, function (data) {
							folderId = data[0].objectId;
							self.populateDocumentsList(folderId);
						});
					}
				}			
			};

			this.populateDocumentsList = function (folderId) {
				self = this;
				var typesToExclude = ["Note", "Folder"];
				var folderObject = new OC.OpenContentObject({
					objectId: folderId
				});

				var jqxhr = folderObject.getChildren();

				jqxhr.done(function (documents) {
					app.context.configService.getAdminOTC(function (otc) {
						_.each(documents, function (doc) {
							if (_.indexOf(typesToExclude, doc.objectType) === -1) {
								doc.attributeToDisplay =
									doc.properties[self.attrToShow];
								doc.isSelected = ko.observable(false);
								self.availableDocuments.push(doc);

								// If action was called from Doc Viewer, make sure the 
								// the box of the current document is checked.
								if (doc.objectId === action.get("parameters").objectId &&
									!_.contains(self.selectedDocuments(), doc.objectId)) {
									self.selectedDocuments.push(doc.objectId);
								}

								if (config.get('docIndicatorAttribute') && config.get('docIndicatorAttribute').attr) {
									//now lets put together our map for doc notes indicator
									var typeModel = otc.get("configs").where({ ocName: doc.objectType })[0];
									var docAttrs = typeModel.get('attrs');

									var foundIndicatorAttr = _.find(docAttrs.models, function (attr) {
										return attr.get('ocName') === config.get('docIndicatorAttribute').attr;
									});

									if (foundIndicatorAttr) {
										self.docToIndicatorMap[doc.objectId] = true;
									}

									//if we have the docIndicatorAttribute configured, we need to send this to OC to use
									action.get("parameters").has_doc_notes_field = config.get('docIndicatorAttribute').attr;

								}//if we are looking to have an indicator, we will be in this if


							} // end if
						}); // end each
						//all the documents should be loaded into the document list accordingly so set the document list fully populated tag to true 
						//and call the checkValidationto check if the submit button can be enabled
						self.documentListPopulated = true;
						self.checkValidation();
					});// end otc
				}); // end done
			};

			// for the ViewModel bind this context to the renderNoteView function defined on the FolderNotes object
			this.renderNoteView = _.bind(FolderNotes.renderNoteView, this);

			this.displayCreateEditNote = function (note) {
				//set the document list populated flag back to false since the docs have not been populated yet
				self.documentListPopulated = false;
				//create a keyup event on the ckeditor textbox so we can check to make sure there is content
				CKEDITOR.instances.messageContent.on('contentDom', function () {
					var editable = CKEDITOR.instances.messageContent.editable();
					editable.attachListener(CKEDITOR.instances.messageContent.document, 'keyup', function () {
						self.checkValidation();
					});
				});

				//if the passed in note has an objectId, we're modifying a note, otherwise creating a new one
				if (note.objectId) {
					CKEDITOR.instances.messageContent.setReadOnly(!note.editable);

					self.noteId(note.objectId);
					self.note(note); //bind passed in note to ko binding
					self.showNotes(false);
					self.currentNoteIsEditable(note.editable);
					$("#CKEditorDiv").hide();

					/* if (!note.editable) {
						$("#documentsTab li:last-child").addClass("active");
						$("#folderAttach").hide();
						$("#selectedDocuments").addClass("active");
					}  */

					if (self.noteVisibilityEnabled()) {
						if (note.properties.note_visibilityType) {
							self.noteVisibilityType(note.properties.note_visibilityType);
						}
					}
					// Add already selected documents onto tab.
					if (note.properties.note_attachment) {
						self.selectedDocuments(note.properties.note_attachment);
					}
				} else {
					self.currentNoteIsEditable(true);
					CKEDITOR.instances.messageContent.setReadOnly(false);
				}

				// Fetch all available documents if adding a note on the folder and if the document list dropdown is not hidden
				if (self.docNotesEnabled() && !self.hideDocList()){
					self.getDocuments();
				}

				self.renderNoteView();
			};

			//controls the modals that are displayed
			this.backToNotes = function () {
				self.availableDocuments([]);
				self.selectedDocuments([]);
				if ($('#attachments').hasClass('collapse in')) {
					$('#attachments').collapse('toggle');
				}
				//we want to reset everything to their defaults
				self.resetBindings();
			};

			this.sortNotes = _.bind(FolderNotes.sortNotes, this);

			this.renderPrintView = function (notes) {
				var data = {
					folder: app.context.container.get('properties').objectName,
					currentUser: app.user.get("displayName"),
					notes: []
				};
				_.each(notes, function (note) {
					var noteDetail = (note.properties.textContent !== undefined ? note.properties.textContent : note.properties.note_detail);
					data.notes.push({
						properties: note.properties,
						creationDate: note.properties.creationDate,
						noteDetail: CKEDITOR.instances.messageContent.getData() ? CKEDITOR.instances.messageContent.getData() : noteDetail
					});
				});
				$.ajax({
					url: app.root + "assets/templates/folder_notes_print_view.html",
					async: false
				}).done(function (template) {
					// Craft the url that would be associated with the index.css used on the rest of the site
					var dynamicHeadTag = document.URL.substring(0, document.URL.indexOf("/Stage")) + "/assets/css/index.css";
					// Create the head tag that will be used to access the baseline css used for the rest of hpi
					dynamicHeadTag = '<head><link rel="stylesheet" type="text/css" href="' + dynamicHeadTag + '"></head>';

					// The Handlebars.compile function returns a function to theTemplate variable
					var hbt = Handlebars.compile(template);

					// Open a new window - will open as about:blank
					var w = window.open();
					//Replace the document head tag with the crafted head tag
					$(w.document.head).html(dynamicHeadTag);
					// Replace the document body tag with the handlebars compiled template
					$(w.document.body).html(hbt(data));
					// Force the background color to be white for simplicity and reading ease.
					$(w.document.body).css("background-color", "#FFFFFF");
				});
			};

			this.toggleLoader = function (bool) {
				app[myHandler].trigger("loading", bool);
			};

			this.printNote = function () {
				//build list of printable notes
				var note = [{
					properties: self.note().properties
				}];

				//pass current noteContent onto the list
				note[0].properties.note_detail = self.noteContent();
				note[0].properties.objectId = self.noteId();

				if (config.get("singleNotePdf") && config.get("singleNotePdf") === 'true') {
					self.exportNoteToPdf(note);
				} else {
					self.renderPrintView(note);
				}
			};

			this.printNotes = function () {
				var notes = self.list();
				if (self.filteredNotes().length > 0) {
					notes = self.filteredNotes();
				}
				if (config.get("exportNotesExcel") && config.get("exportNotesExcel") === 'true') {
					self.exportNotesToExcel(notes);
				} else {
					self.renderPrintView(notes);
				}
			};

			this.exportNotesToExcel = function (notes) {

				var objectIds = [];
				_.each(notes, function (note) {
					objectIds.push(note.objectId);
					//im also going to prep my note for the link resolving util
					note.objectType = "HPI Note";
				});

				//turning off printPdf in case we just came from there
				delete action.get("parameters").printToPDF;
				//end turn off printpdf
				action.get("parameters").exportToExcel = "true";
				action.get("parameters").ocNameList = ['creator', 'creationDate', 'note_detail', 'note_type', 'objectName'];
				action.get("parameters").propertyLabels = ['Author', 'Creation Date', 'Note Detail', 'Note Type', 'Name'];
				action.get("parameters").objectIds = objectIds;

				//Adding these in because they are mandatory params.
				action.get("parameters").parentID = app.context.container.get('properties').objectId;
				action.get("parameters").property_map = {};
				action.get("parameters").urlRoot = window.location.protocol + "//" + window.location.host + app.root + "Stage/" + app.context.configName() + "/";



				var dt = moment().format();
				var dtFormat = dt.replace(/:/g, "-");
				action.get("parameters").fileName = 'Note-Export-Results' + "-" + dtFormat + ".xls";


				var callback = function () {
					self.toggleLoader(false);
					app[myHandler].trigger("showMessage", window.localize("modules.actions.folderNotes.theNotesFile"));
				};

				app.context.dateService.getDateFormat().done(function (dateFormat) {
					action.get("parameters").dateFormat = moment().toJDFString(dateFormat);

					// Since the getting of configs is asynchronous, we launch our action within the callback.
					downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, callback);
				});

			};

			this.exportNoteToPdf = function (note) {

				note.objectType = "HPI Note";
				action.get("parameters").printToPDF = "true";
				//turning off export to excel in case we just came from there
				delete action.get("parameters").exportToExcel;
				delete action.get("parameters").objectIds;
				//end turn off excel
				action.get("parameters").ocNameList = ['creator', 'creationDate', 'note_detail', 'note_type', 'objectName'];
				action.get("parameters").propertyLabelsMap = {
					'creator': 'Author',
					'creationDate': 'Creation Date',
					'note_detail': 'Note Detail',
					'note_type': 'Note Type',
					'objectName': 'Name'
				};
				action.get("parameters").noteId = note[0].properties.objectId;

				action.get("parameters").urlRoot = window.location.protocol + "//" + window.location.host + app.root + "Stage/" + app.context.configName() + "/";

				//Adding these in because they are mandatory params.
				action.get("parameters").parentID = app.context.container.get('properties').objectId;
				action.get("parameters").property_map = {};



				var dt = moment().format();
				var dtFormat = dt.replace(/:/g, "-");
				action.get("parameters").fileName = 'Note-Print-Results' + "-" + dtFormat + ".pdf";


				var callback = function () {
					self.toggleLoader(false);
					app[myHandler].trigger("showMessage", window.localize("modules.actions.folderNotes.theNotesFile"));
				};

				app.context.dateService.getDateFormat().done(function (dateFormat) {
					action.get("parameters").dateFormat = moment().toJDFString(dateFormat);

					// Since the getting of configs is asynchronous, we launch our action within the callback.
					downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, callback);
				});
			};

			/* takes the array of objects and adds them to the table. 
			This works by getting the objects related to the parent folder */
			this.getNotes = function (folderId, documentId) {
				self = this;
				app[myHandler].trigger("loading", true);

				// we want to use the 'hpi_folder_note' relation to get the notes for this folder object
				var oCObject = new OC.PageableRelatedObjects();
				if (config.isDocumentNotes) {
					oCObject.id = documentId;
				} else {
					oCObject.id = folderId;
				}

				oCObject.parentOrChild = "Children"; // notes are the children in the folder notes relation
				oCObject.relationName = config.get("noteRelationship");

				// backend expects string - in contentless mode we do not want to make the request so if enabled pass false
				oCObject.textContentRequest = app.enableContentlessMode ? "false" : "true";

				oCObject.fetch().done(function (notes) {
					app[myHandler].trigger("loading", false);
					self.list.removeAll();

					// this loop goes through each element in all data and converts the contents to the list observable
					_.each(notes, function (note) {
						var dontDisplayDocNote = false;
						var promise;
						if(config.get('authorDisplayName')) {
							promise	= app.context.filterService.getUserDisplayName(note.properties.creator, function (displayName) {
								note.properties.creator = displayName;
							});
						} else {
							promise = new $.Deferred().resolve();
						}
						 

						$.when.apply(null, [promise]).done(function () {
							if (self.noteVisibilityEnabled()) {
								if (note.properties.note_visibilityType === 'private') {
									if(config.get('authorDisplayName')){
										if (note.properties.creator !== app.user.get("displayName")) {
											dontDisplayDocNote = true;
											self.noteRemoved(true);
										}
									} else {
										if (note.properties.creator !== app.user.get("loginName")) {
											dontDisplayDocNote = true;
											self.noteRemoved(true);
										}
									}	
								}
							}

							if (!dontDisplayDocNote) {
								// check if documents associated with note exist
								if (note.properties.note_attachment) {
									// fetch for other documents associated with note
									var docCollection = new OC.OpenContentObjectCollection({
										ids: note.properties.note_attachment
									});

									var fetchDeferred = docCollection.fetch({
										success: function (ocos) {
											var docArray = [];
											// put each oco on note.properties
											_.each(ocos.models, function (oco) {
												if(oco.get("properties")[self.attrToShow]){
													// adds the attribute to display if attrToshow exists on the oco
													oco.attributeToDisplay = oco.get("properties")[self.attrToShow];
												}
												else{
													// adds the objectName on attribute to display if attrToShow isn't specified
													oco.attributeToDisplay = oco.attributes.properties.objectName;
												}
												
												docArray.push(oco);
											});
											docArray.sort(function (a, b) {
												return a.attributeToDisplay > b.attributeToDisplay;
											});
											note.properties.attachments = docArray;
										}
									});

									$.when.apply(null, [fetchDeferred]).done(function () {
										self.populateNotesList(note);
									});
								} else {
									self.populateNotesList(note);
								}
							} // end if
						});
					}); // end each
				}); // end fetch
			}; // end self.getNotes

			this.populateNotesList = function (note) {
				// this removes the html from the note and creates the plaintext var "text" for filtering
				var div = document.createElement("div");
				div.innerHTML = note.properties.note_detail;
				var text = div.textContent || div.innerText || "";

				// format the note properties based on the admin otc
				// formatting here to prevent sorting issues after dates are formatted
				_.each(note.properties, function(propValue, ocName){
					var formattedKey = self.findAdminOTCFormat(ocName, propValue);
					note.properties[ocName] = formattedKey;
					note.properties[ocName + "-orig"] = propValue;
				});

				// add notes to list
				self.list().push({
					objectId: note.objectId,
					properties: note.properties,
					editable: self.isEditable() ? config.writePermissionEvaluator(note) : false,
					hidden: text // this is a hidden element on the table for sorting by notes
				});

				// sort list when first populated using the first column after the note icon column
				var firstSortColumn =self.tableHeader()[1].ocName;
				if (firstSortColumn.toLowerCase().search(/date/) !== -1) { this.reverseSort = true; } // switches to a reverse sort if it is a date field
				self.sortNotes(firstSortColumn);
				
				self.list.valueHasMutated();
			};

			/* adds the wizywig results to dctm */
			this.submit = function () {
				var instance = CKEDITOR.instances.messageContent;
				var currentDate = DateFormat.format.date(new Date(), "E, d MMM yyyy hh-mm-ss a");
				var folderNotePropMap = self.getValues(); //from formsupport
				folderNotePropMap.objectName = "Folder Note - " + currentDate;
				instance.updateElement();
				var tempString = instance.getData();
				var whiteReplaced;
				//These next three lines sucesfully take out the html, spaces, and carriage returns, so we can
				//effectively decided if the note is blank or not.
				whiteReplaced = tempString.replace(/&nbsp;/g, '');
				whiteReplaced = $('<p>' + whiteReplaced + '</p>').text();
				whiteReplaced = whiteReplaced.split(' ').join('');
				whiteReplaced = $.trim(whiteReplaced);
				if (whiteReplaced.length > 0) {
					// in contentless mode we do not care about the data length
					if (instance.getData().length < 6000 || app.enableContentlessMode) {
						if (self.docToIndicatorMap) {
							//if we have doc id's to truthy values, meaning we need to set their indicators to true, then lets send it
							action.get("parameters").doc_to_indicator_map = self.docToIndicatorMap;
						}

						if (self.noteVisibilityEnabled()) {
							folderNotePropMap.note_visibilityType = self.noteVisibilityType();
						}

						if (self.docNotesEnabled()) {

							if (self.hideDocList()) {
								folderNotePropMap.note_attachment = [action.get("parameters").objectId];
							} else {
								folderNotePropMap.note_attachment = self.selectedDocuments();
							}
						} else {
							folderNotePropMap.note_attachment = [];
						}

						var customNoteStoragePath = "";

						if(config.get('customNoteStorage') && config.get('customNoteStorage') === 'true' && config.get("customNoteStoragePath")) {
							if(config.get("customNoteStorageWithType") && config.get("customNoteStorageWithType") === "true"){
								//add on the type
								if(self.docNotesEnabled()){
									customNoteStoragePath = config.get("customNoteStoragePath") + "/" + self.getDocObjectTypeFromDocList();
								}else{
									customNoteStoragePath = config.get("customNoteStoragePath") + "/" +  app.context.container.get("objectType");
								}	
							}else{
								//dont add type just add the path
								customNoteStoragePath = config.get("customNoteStoragePath");
							}
						}
						
						action.get("parameters").customNoteStoragePath = customNoteStoragePath;
						action.get("parameters").note_id = self.noteId();
						action.get("parameters").note_content = instance.getData();
						action.get("parameters").note_object_type = self.objectType();
						action.get("parameters").note_rel_type = config.get("noteRelationship");
						action.get("parameters").parentID = app.context.container.get('properties').objectId;
						action.get("parameters").property_map = folderNotePropMap;

						app[myHandler].trigger("loading", true);
						action.execute({
							success: function () {
								//adds the note to dctm and refreshes the notes page.

								self.refreshNotes();
								self.pageIndex(0);
								self.backToNotes();
								if (self.docNotesEnabled()) {
									app.trigger("stage.refresh.bothIds", true, true);
								} else {
									app.trigger("stage.refresh.containerId", true);
								}
							},
							error: function (jqXHR) {
								app[myHandler].trigger("loading", false);
								app[myHandler].trigger("showError", "Failed to add note " + jqXHR.status + " " + jqXHR.statusText);
							}
						});
					} else {
						app.trigger("alert:info", {
							header: window.localize("stage.folderNotes.documentNotes"),
							message: window.localize("stage.folderNotes.over6000Chars")
						});
					}
				} else {
					app.trigger("alert:info", {
						header: window.localize("stage.folderNotes.documentNotes"),
						message: window.localize("stage.folderNotes.pleaseAddContent")
					});
				}
			};

			app[myHandler].trigger("loading", true);

			//checks write privileges  - can't create a folder note w/o write permissions
			_.each(conditions, function(condition){
				if (config.isDocumentNotes){
					if (condition.name === "condition-relate-conditionevaluator") {
						if (condition.status === "valid") {
							self.canWrite(true);
						}
					}
				} else {
					if (condition.name === "condition-write-conditionevaluator") {
						// check to see if the user has write permission on the specified path
						if (config.get('customNoteStorage') && config.get('customNoteStorage') === 'true' && config.get("customNoteStoragePath")){
							var pathAddOn = "/";
							
							if (config.isDocumentNotes){
								pathAddOn += self.setDocObjectTypeFromDocList();
							} else{
								pathAddOn += app.context.container.get("objectType");
							}
								
							$.ajax({
								type : "GET",
								contentType: "application/json",
								url: app.serviceUrlRoot + "/permission/write?id=" + config.get('customNoteStoragePath') + pathAddOn,
								success: function(canWrite) {
									if (canWrite){
										self.canWrite(true);
									}
								},
								error: function() {
								}
							});
						} else if (condition.status === "valid") {
							self.canWrite(true);
						}
					}
				}
			});
			
			this.refreshNotes = function () {
				var documentId = "";
				var folderId = "";
				var actionObjectId = action.get("parameters").objectId;

				if (config.isDocumentNotes) {
					// If we are in documentNotes action we know that the actionObjectId
					// is the document objectId
					documentId = actionObjectId;

					// If we have access to the container objectId (folder), use that
					// otherwise attempt to get the primary parent
					// TODO: Fix issue with linked documents if the container objectId
					// Isn't set
					if (app.context.container.get('properties').objectId) {
						folderId = app.context.container.get('properties').objectId;
					} else {
						app.context.util.getParents(documentId, function (data) {
							folderId = data[0].objectId;
						});
					}
				} else {
					// If we aren't in document notes, we know that the actionObjectId
					// is the folder objectId
					folderId = actionObjectId;
				}

				self.getNotes(folderId, documentId);
			};

			//lets populate the notes
			this.refreshNotes();

			this.hasAttachedDocs = ko.computed(function () {
				var hasAttachedDocs = false;
				_.each(self.list(), function (note) {
					if (note.properties.attachments) {
						hasAttachedDocs = true;
					}
				});
				return hasAttachedDocs;
			});

			this.pagedList = ko.computed(function () {
				var size = parseInt(self.pageSize(), 10);
				if (self.pageIndex() < 0) {
					self.pageIndex(0);
				}
				var start = self.pageIndex() * size;
				var filter = self.filter().toLowerCase();

				if (filter === '') {
					//If there's no filter, return all users.
					return self.list.slice(start, start + size);
				} else {
					if (filter !== self.lastFilter()) {
						self.filteredNotes([]);
						self.lastFilter(filter);
						// change filter to regex and escape reg ex chars
						var filterRegex = new RegExp(filter.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));

						ko.utils.arrayFilter(self.list(), function (note) {
							var noteContainsFilter = false;
							_.each(self.tableHeader(), function(headerProperty) {
								if (headerProperty.ocName === "note_detail") { // use the hidden field since html is stripped out
									if (note.hidden.toLowerCase().search(filterRegex) !== -1) {
										noteContainsFilter = true;
									}
								}
								else if (headerProperty.ocName === "note_attachment") { // use attachments attributeToDisplay for filtering
									_.each(note.properties.attachments, function(attachment) {
										if (attachment.attributeToDisplay.toLowerCase().search(filterRegex) !== -1) {
											noteContainsFilter = true;
										}
									});
								}
								else if (headerProperty.ocName !== "noteIcon") { // filter everything else except for noteIcon
									if (note.properties[headerProperty.ocName].toLowerCase().search(filterRegex) !== -1) {
										noteContainsFilter = true;
									}
								}
							});
							if(noteContainsFilter) { self.filteredNotes.push(note); }
						});
					}
					return self.filteredNotes.slice(start, start + size);
				}

			});

			this.tableHeader = ko.observableArray();

			// if the table has not been configured yet use these as the defaults
			var defaultAttrs = [
				{"attrName": "Creation Date", "ocName":"creationDate"},
				{"attrName": "Author", "ocName":"creator"},
				{"attrName": "Note Type", "ocName":"note_type"},
				{"attrName": "Note Detail", "ocName":"note_detail"},
				{"attrName": "Documents", "ocName":"note_attachment"}
			];
			if (_.isUndefined(config.get('attrsToDisplay'))) {
				this.tableHeader(defaultAttrs);
			}
			else {
				this.tableHeader(config.get('attrsToDisplay'));
			}
			this.setupTableHeader = _.bind(FolderNotes.setupTableHeader, this);
			this.setupTableHeader();

			this.findAdminOTCFormat = _.bind(FolderNotes.findAdminOTCFormat, this);

			this.tableBody = ko.computed(function () {
				//knockout doesn't clean up well, so we are going to
				//do a null check on pagedList to avoid a null error
				//when the foldernotes action view is removed
				if (self.pagedList && self.pagedList()) {
					return self.pagedList();
				} else {
					return [];
				}
			});

			this.maxPageIndex = ko.computed(function () {
				self.canPrint(true);
				if (self.filteredNotes().length > 0) {
					return Math.ceil(self.filteredNotes().length / self.pageSize()) - 1;
				} else if (self.filteredNotes().length === 0 && self.filter() !== '') {
					//if the filter is empty, disable printing
					self.canPrint(false);
					return 0;
				} else {
					return Math.ceil(self.list().length / self.pageSize()) - 1;
				}
			});

			this.previousPage = function () {
				if (self.pageIndex() > 0) {
					self.pageIndex(self.pageIndex() - 1);

				}
			};

			this.nextPage = function () {
				if (self.pageIndex() < self.maxPageIndex()) {
					self.pageIndex(self.pageIndex() + 1);
				}
			};

			this.allPages = ko.dependentObservable(function () {
				var pages = ko.observableArray([]);
				for (var i = 0; i <= self.maxPageIndex(); i++) {
					pages.push({
						pageNumber: (i + 1)
					});
				}
				return pages;
			});

			this.checkValidation = function () {
				// if the doc list is not hidden check that all required fields are filled out, the ckeditor has content,
				//and the document list if fully populated before making the submit button enabled
				if (self.docNotesEnabled() && !self.hideDocList()) {
					if (self.isValid() && CKEDITOR.instances.messageContent.getData().length > 0 && self.documentListPopulated) {
						$('#createNote').prop('disabled', false);
					} else {
						$('#createNote').prop('disabled', true);
					}
					//if the doc attachments list is hidden check that all required fields are filed out
					//and the ckeditor has content before making the sumbit button enabled
				} else {
					if (self.isValid() && CKEDITOR.instances.messageContent.getData().length > 0) {
						$('#createNote').prop('disabled', false);
					} else {
						$('#createNote').prop('disabled', true);
					}
				}
			};
		};

		FolderNotes.View = Backbone.Layout.extend({
			template: "actions/foldernotes",
			events: {
				'click a.fn-launchItemExternally': 'launchItemExternally'
			},
			initialize: function () {
				this.action = this.options.action;
				this.myHandler = this.options.config.get("handler");
				this.viewModel = new FolderNotes.ViewModel(this.action, this.myHandler, this.options.config);
				this.paneSize = this.options.config.get("paneSize");
			},
			afterRender: function () {
				var self = this;

				CKEDITOR.replace("messageContent", {
					toolbar: "HPISimple",
					disableNativeSpellChecker: false
				}, '');

				kb.applyBindings(this.viewModel, this.$el[0]);

			// this is a click handler for links inside the note detail - these are generated in bulk upload when audit
			// trail is turned on
				this.$el.on("click", "#viewNotes .stageLink",
					{
						handler: self.myHandler
					},
					function (event) {
						var docId = $(this).attr("documentId"),
							docName = $(this).text();
						self.clickHandler(event.data.handler, docId, docName);
					});
			},
			launchItemExternally: function (event) {
				var objectId = event.currentTarget.attributes.getNamedItem('docId').value;
				var attributeToDisplay = event.currentTarget.text;

				window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(attributeToDisplay) + "?id=" +
					objectId + "&overlay=true&contentType[]=contentType[]=pdf,txt,.*");
			},
			clickHandler: function (handler, docId, docName) {
				var message;
				$.ajax({
					type: "GET",
					contentType: "application/json",
					url: app.serviceUrlRoot + "/openContentObject?id=" + docId,
					success: function () {
						$.ajax({
							type: "GET",
							contentType: "application/json",
							url: app.serviceUrlRoot + "/permission/read?id=" + docId,
							success: function () {
								app[handler].trigger("hide");
								app.trigger("stage.refresh.documentId", docId);
							},
							error: function () {
								// app.trigger("alert:changeNotification", "alert-danger", "Error: User does not have permission to view '" + docName + "'. Document Id: " + docId, "#" + handler + "-info", false);
								message = "Error: User does not have permission to view '" + docName + "'. Document Id: " + docId;
								$("#" + handler + "-error").html(message);
								$("#" + handler + "-error").show().delay(5000).fadeOut();
							}
						});
					},
					error: function () {
						//app.trigger("alert:changeNotification", "alert-danger", "Error: Document '" + docName + "' doesn't exist. Document Id: " + docId, "#" + handler + "-info", false);
						message = "Error: Document '" + docName + "' doesn't exist. Document Id: " + docId;
						$("#" + handler + "-error").html(message);
						$("#" + handler + "-error").show().delay(5000).fadeOut();
					}
				});
			},
			serialize: function () {
				var modal = false;
				var rightSide = false;
				if (this.myHandler === "modalActionHandler") {
					modal = true;
				} else if (this.myHandler === "rightSideActionHandler") {
					rightSide = true;
				}
				return {
					modal: modal,
					rightSide: rightSide
				};
			}
		});

		FolderNotes.Service = {
			getParameters: function (options) {
				var currentDate = DateFormat.format.date(new Date(), "E, d MM yyyy hh-mm-ss a");
				return {
					note_id: options.note_id || "",
					parentID: options.parentID,
					objectId: options.objectId || options.parentID,
					note_content: options.note_content,
					note_rel_type: options.note_rel_type,
					note_object_type: options.note_object_type,
					property_map: {
						note_attachment: options.property_map.note_attachment,
						note_type: options.property_map.note_type || window.localize("modules.actions.exportFolder.folderNote"),
						objectName: options.property_map.objectName || "Folder Note - " + currentDate
					}
				};
			},
			execute: function (options) {
				var defaultSuccess = function () {
					app.log.debug("Folder notes executed successfully");
				};
				var defaultError = function () {
					app.log.debug("Folder notes executed with an error");
				};
				options.parameters = this.getParameters(options.parameters);
				var action = new Action.Model({
					name: "folderNotes",
					parameters: options.parameters
				});
				action.execute({
					success: options.successFunction || defaultSuccess,
					error: options.errorFunction || defaultError,
					global: options.global || false,
					async: options.async || true
				});
			}
		};

		//helper method to determine write-access
		//on a note. 
		var writePermissionEvaluator = function (note) {
			if (note.properties.note_type !== "Workflow Note" && app.user.get("displayName") === note.properties.creator) {
				return true;
			}
			else {
				return false;
			}
		};

		actionModules.registerAction("folderNotes", FolderNotes, {
			"actionId": "folderNotes",
			"label": "Folder Notes",
			"icon": "comments",
			"handler": "rightSideActionHandler",
			"paneSize": "fullPane",
			"autoLaunch": "false"
		},
			{
				"writePermissionEvaluator": writePermissionEvaluator,
				"isDocumentNotes": false
			}
		);

		actionModules.registerAction("documentNotes", FolderNotes, {
			"actionId": "documentNotes",
			"label": "Document Notes",
			"icon": "pencil",
			"handler": "rightSideActionHandler",
			"paneSize": "fullPane",
			"autoLaunch": "false"
		},
			{
				"writePermissionEvaluator": writePermissionEvaluator,
				"isDocumentNotes": true
			}
		);

		return FolderNotes;

	});
require(["foldernotes"]);