// Advancedsearch module
define("whycanti",[
  // Application.
  "app",
  "handlebars",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, Handlebars, actionModules) {
    "use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    action.View = Backbone.Layout.extend({
        template: "actions/whycanti",
        events: {
			"click h4.accordion-toggle": "toggleChevron"
		},
        initialize: function(){
        	//This helper determines what should be displayed for the reason the condition failed
			Handlebars.registerHelper("displayReason", function(options) {
				//options.hash.currentAction is the current action from the template
				
				return options.hash.currentAction.message ? options.hash.currentAction.message : options.hash.currentAction.name;
			});

            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
        },
        toggleChevron: function(event) {
			this.$(event.currentTarget.firstElementChild).toggleClass("glyphicon-chevron-up glyphicon-chevron-down");
		},
        serialize: function(){
             this.whyCantIActions = this.action.get("whyCantIActions");

             _.each(this.whyCantIActions, function(action) {
                    action.set("label", actionModules.getDefaultConfig(action.get("actionId")).label);
             });

             return {
            	whyCantIActions: this.whyCantIActions
            };
        }
    });

    actionModules.registerAction("whyCantI", action, {
        "actionId" : "whyCantI"
    });
    
	return action;

});
require(["whycanti"]);