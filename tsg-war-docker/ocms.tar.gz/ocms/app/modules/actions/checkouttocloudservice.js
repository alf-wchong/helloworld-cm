//Advancedsearch module
define("checkouttocloudservice",[
	//Application
	"app",
	"modules/actions/actionmodules",
    "modules/hpiadmin/common/iosswitch",
    "cloudserviceauthentication"
],

function(app, actionModules, iOSSwitch, CloudServiceAuthentication) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
	var action = {};

	action.View = Backbone.Layout.extend({
		template: "actions/checkouttocloudservice",
		events : {
        	"click #checkoutBtn": "uploadToCloudService"
        },
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.objectId = this.action.get("parameters").objectId;
            this.redirectUrl = this.options.config.get("oneDriveRedirectUrl");
            this.cloudMode = this.options.config.get("cloudMode");
			
			if (this.cloudMode === "officeOnline") {
				this.clientId = this.options.config.get("oneDriveClientId");
			} else {
				this.clientId = this.options.config.get("googleDriveClientId");
			}
        },
        afterRender: function() {
            var self = this;	

            if (this.cloudMode === "officeOnline") {
                this.listenTo(app, "cloudservicesauthentication:microsoft365:authenticated", function(accessToken){
                    self.accessToken = accessToken;
                    $('#checkoutBtn').prop('disabled', false);
                });
    
                CloudServiceAuthentication.microsoft365.authenticate({
                    clientId: this.clientId,
                    redirectUrl: this.redirectUrl
                });     
            } else {
                this.listenTo(app, "cloudservicesauthentication:google:authenticated", function(result){
                    self.accessToken = result.access_token;
                    $('#checkoutBtn').prop('disabled', false);
                });
    
                CloudServiceAuthentication.googleDrive.authenticate({
					client_id: this.clientId,
                    scope: "https://www.googleapis.com/auth/drive https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/drive.file",
                    immediate: false
                });
            }
        },
        uploadToCloudService: function(){
        	var self = this;
        	this.action.get("parameters").accessToken = this.accessToken;
            this.action.get("parameters").oneDriveSendPermissions = this.options.config.get("oneDriveSendPermissions");
            this.action.get("parameters").oneDriveSendPermissionsWithEmail = this.options.config.get("oneDriveSendPermissionsWithEmail");
            this.action.get("parameters").cloudMode = this.cloudMode;
            this.action.get("parameters").repositoryVariable = this.options.config.get("repositoryVariable");
            this.action.get("parameters").oneDriveType = this.options.config.get("oneDriveType");
            
        	this.action.execute({
				success : function(data) {
					app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.checkoutToCloudService.theDocument")));

					self.listenToOnce(app[self.myHandler], "hide", function() {
                        app.trigger("stage.refresh.documentId", self.action.get("parameters").objectId);
                    });
                    var updatedUrl = data.result; 
                    window.open(updatedUrl, '_blank');
				}
			});
		},
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
            }
            var cloudMode = this.cloudMode;            
			return {
				content: this.gotContent,
				accessToken: this.accessToken,
				modal : modal,
                rightSide : rightSide,
                cloudMode : cloudMode
            };
        }

	});

	action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/cloudserviceconfig",
        initialize: function(){
            this.viewModel = this.options.viewModel;
            this.viewModel.oneDriveClientId = kb.observable(this.viewModel.model(),"oneDriveClientId");
            this.viewModel.oneDriveRedirectUrl = kb.observable(this.viewModel.model(),"oneDriveRedirectUrl");
            this.viewModel.oneDriveSendPermissions = kb.observable(this.viewModel.model(), "oneDriveSendPermissions");
            this.viewModel.oneDriveSendPermissionsWithEmail = kb.observable(this.viewModel.model(), "oneDriveSendPermissionsWithEmail");
            this.viewModel.googleDriveClientId = kb.observable(this.viewModel.model(),"googleDriveClientId");
			this.viewModel.cloudMode = kb.observable(this.viewModel.model(), 'cloudMode');
            this.viewModel.repositoryVariable = kb.observable(this.viewModel.model(), 'repositoryVariable');
			
			if (!this.viewModel.cloudMode()) {
				this.viewModel.cloudMode('googleDrive');
            }            
			
			if (!this.viewModel.repositoryVariable()) {
				this.viewModel.repositoryVariable('hpi_googleDriveId');
			}

            this.oneDriveType = new iOSSwitch.View({
                model: this.viewModel.model(),
                configModelKey: "oneDriveType",
                switchTitle: window.localize("customConfig.oneDriveConfig.oneDriveOneDriveTypeTitle"),
                configDescription: window.localize("customConfig.oneDriveConfig.oneDriveOneDriveTypeGlyphiconTitle"),
                onLabel: window.localize("customConfig.oneDriveConfig.oneDrivePersonal"),
                trueVal: "Personal",
                offLabel: window.localize("customConfig.oneDriveConfig.oneDriveOrganization"),
                defaultSwitchValue: true,
                falseVal: "Organization",
                customClass: "switch-200w"
            });

            this.setViews({
                "#oneDriveType": this.oneDriveType
            });
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

	//action registers itself with getAction in actionModules
    actionModules.registerAction("checkoutToCloudService", action, {
        "actionId" : "checkoutToCloudService",
        "label" : (window.localize("modules.actions.checkoutToCloudService.editOnline")),
        "icon" : "share"
    });

	return action;
	
});
require(["checkouttocloudservice"]);