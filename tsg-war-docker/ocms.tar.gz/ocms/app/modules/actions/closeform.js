// Advancedsearch module
define("closeform",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    action.View = Backbone.Layout.extend({
		template: "actions/closeform",
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		},
		beforeRender: function() {
			var self = this;
			this.viewModel = {

				comments : ko.observable(),
				onSubmit : function() {
					app.log.debug("time to submit this form");
					//taskId must be on the action
					var formId = self.action.get("parameters").objectId;
					if(formId === undefined){
						app[self.myHandler].trigger("showError", (window.localize("modules.actions.closeForm.unableToCloseForm")));
					}else{			
						self.toggleLoader(true);
						self.action.get("parameters").formId = formId;
						self.action.get("parameters").comments = this.comments();

						self.action.execute({
							success : function(data) {
								self.toggleLoader(false);
								//TSG.stage.model.containerId.valueHasMutated();
								app.trigger("stage.refresh.bothIds", formId, formId);
								app[self.myHandler].trigger("showMessage", window.localize("modules.actions.closeForm.formClosedSuccess"));
							},
							error : function(jqXHR, textStatus, errorThrown) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showError", window.localize("modules.actions.closeForm.failedToClose") +
										jqXHR.status + " " + jqXHR.statusText);
							}
						});

					}
				}
			};
		},
		afterRender: function(){
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
		serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
	});

	actionModules.registerAction("closeForm", action, {
        "actionId" : "closeForm",
      	"label" : "Close Form",
      	"icon" : "remove-sign",
      	"groups" : ["wizard", "close", "form"]
    });

    return action;
});
require(["closeform"]);