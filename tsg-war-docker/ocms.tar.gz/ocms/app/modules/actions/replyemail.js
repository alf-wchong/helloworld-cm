define("replyemail",[
	// Application.
	"app",
	"oc",
	"modules/common/ocquery",
	"modules/actions/actionmodules",
	"jquery",
	"underscore",
	"ckeditorcore",
	"typeahead"
],

function(app, OC, Query, actionModules, $, _) {
	"use strict";

	var ReplyEmail = {};

	//primary view model
	function ViewModel(action, myHandler, config) {

		var self = this;
		var originalEmail = app.context.document;

		self.attachmentAttrToShow = ko.observable();
		//set the value to what's on the config if
		//it is there, else default to objectName
		if(config.get("attachmentAttrToShow")){
			self.attachmentAttrToShow(config.get("attachmentAttrToShow"));
		} else {
			self.attachmentAttrToShow("objectName");
		}

		self.folderId = ko.observable();
		//self.attachmentsShown = ko.observable(false);
		self.attachments = ko.observableArray();
		self.attachedDocs = ko.observableArray();
		self.typeAheadContactList = ko.observableArray();
		self.toCheckList = ko.observableArray().extend({minLength: {params: 1, message: (window.localize("modules.actions.replyEmail.atLeastOne"))}});
		self.ccCheckList = ko.observableArray();
		self.bccCheckList = ko.observableArray();
		self.subject = ko.observable().extend({required: true, maxLength: ( config.get("maxLength") ? parseInt(config.get("maxLength"), 10) : 255 ) });
		self.showCC	= ko.observable(false);
		self.showBCC = ko.observable(false);
		self.currentToEmail	= ko.observable().extend({email: {params: true, message: (window.localize("modules.actions.replyEmail.pleaseEnter"))}});
		self.currentCCEmail	= ko.observable().extend({email: {params: true, message: (window.localize("modules.actions.replyEmail.pleaseEnter"))}});
		self.currentBCCEmail = ko.observable().extend({email: {params: true, message: (window.localize("modules.actions.replyEmail.pleaseEnter"))}});
		self.emailBody = ko.observable('');
		self.integrateFolderNotes = ko.observable(false);
		self.loading = ko.observable(true);

		self.showAttached = ko.observable(false);
		self.showFolderDocs = ko.observable();
		self.showCollectionDocs = ko.observable();
		self.collectionType = ko.observable("private");
		self.collectionSearch = ko.observable();
		self.chosenCollection = ko.observable();
		self.collectionsAttachments = ko.observableArray();
		self.attachedCollectDocs = ko.observableArray();
		self.removeAnDocument = ko.observable();
		self.originalAttachments = ko.observableArray();
		self.collectionAttachmentsTab = ko.observable(true);

		if(config.get("integrateFolderNotes") === "true"){
			self.integrateFolderNotes(true);
		}

		if(config.get("collectionAttachmentsTab") === "false"){
			self.collectionAttachmentsTab(false);
		}

		self.removeToContact = function(item){
			self.toCheckList.remove(item);
		};
		
		self.removeBccContact = function(item){
			self.bccCheckList.remove(item);
		};
		
		self.removeCcContact = function(item){
			self.ccCheckList.remove(item);
		};

		//determine whether the object is an HPIEmailMessage else should be type .msg
		if(app.context.document.get("objectType") === "HPIEmailMessage"){
			if(originalEmail.get("properties").from){
				self.currentToEmail(originalEmail.get("properties").from);
				if(self.currentToEmail.isValid() && (self.currentToEmail() !== app.user.get("emailAddress"))) {
					self.toCheckList.push({"display":self.currentToEmail(), "val":self.currentToEmail()});
					self.currentToEmail("");
				}
			}

			if(originalEmail.get("properties").to){
				_.each(originalEmail.get("properties").to, function(toAddress){
					self.currentToEmail(toAddress);
					if(self.currentToEmail.isValid() && (self.currentToEmail() !== app.user.get("emailAddress"))){
						self.toCheckList.push({"display":self.currentToEmail(), "val":self.currentToEmail()});
						self.currentToEmail("");
					}
				});
			}

			if(originalEmail.get("properties").cc){
				_.each(originalEmail.get("properties").cc, function(ccAddress){
					self.currentCCEmail(ccAddress);
					if(self.currentCCEmail.isValid() && (self.currentCCEmail() !== app.user.get("emailAddress"))) {
						self.ccCheckList.push({"display":self.currentCCEmail(), "val":self.currentCCEmail()});
						self.currentCCEmail("");
					}
				});
			}

			if(originalEmail.get("properties").bcc){
				_.each(originalEmail.get("properties").bcc, function(bccAddress){
					self.currentBCCEmail(bccAddress);
					if(self.currentBCCEmail.isValid() && (self.currentBCCEmail() !== app.user.get("emailAddress"))) {
						self.bccCheckList.push({"display":self.currentBCCEmail(), "val":self.currentBCCEmail()});
						self.currentBCCEmail("");
					}
				});
			}

			self.subject("Re: " + originalEmail.get("properties").subject);
		}

		self.addTo = function(){
			if(self.currentToEmail()) {
				if(self.currentToEmail.isValid()) {
					self.toCheckList.push({"display":self.currentToEmail(), "val":self.currentToEmail()});
					self.currentToEmail("");
					//clear out typeahead too
					self.toTypeahead.typeahead('val', '');
				}
			}
		};

		self.addCC = function(){
			if(self.currentCCEmail()) {
				if(self.currentCCEmail.isValid()) {
					self.ccCheckList.push({"display":self.currentCCEmail(), "val":self.currentCCEmail()});
					self.currentCCEmail("");
					//clear out typeahead too
					self.ccTypeahead.typeahead('val', '');
				}
			}
		};

		self.addBCC = function(){
			if(self.currentBCCEmail()) {
				if(self.currentBCCEmail.isValid()) {
					self.bccCheckList.push({"display":self.currentBCCEmail(), "val":self.currentBCCEmail()});
					self.currentBCCEmail("");
					//clear out typeahead too
					self.bccTypeahead.typeahead('val', '');
				}
			}
		};

		self.addCollectDocument = function(){
			var document = {
				objectId: this.objectId,
				objectName: this.properties.objectName
			};
			for(var x=0; x<self.attachedCollectDocs().length; x++) {
				if(self.attachedCollectDocs()[x].objectId === this.objectId) {
					self.attachedCollectDocs.splice(x,1);
					return true;
				}
			}
			self.attachedCollectDocs.push(document);
			return true;
		};

		self.removeAttachedDocument = function() {
			self.attachedDocs.remove(this);
			if(self.attachedDocs().length === 0 && self.attachedCollectDocs().length === 0){
				self.showAttached(false);
				$('#attachmentTab a:first').tab('show');
			}
		};

		self.removeAttachedCollectDocument = function() {
			self.attachedCollectDocs.remove(this);
			if(self.attachedDocs().length === 0 && self.attachedCollectDocs().length === 0){
				self.showAttached(false);
				$('#attachmentTab li:eq(1) a').tab('show');
			}
			var id = "#collectionCheckBox-" + this.objectId;
			if($(id).length){
				$(id).prop('checked', false);
			}
		};

		self.getAttrFromId = function(id){
			var result = null;
			_.each(self.attachments(), function(object){
				if(object().objectId === id)
				{
					result = object().properties[self.attachmentAttrToShow()];
				}
			});
			return result;
		};
		
		/*self.showFolderDocs = function(){
			self.attachmentsShown(!self.attachmentsShown());
		};*/
		self.showHeaders = function(){
			if(self.attachedDocs().length !== 0){
				self.showFolderDocs(true);
			} else {
				self.showFolderDocs(false);
			}
			if(self.attachedCollectDocs().length !== 0){
				self.showCollectionDocs(true);
			} else {
				self.showCollectionDocs(false);
			}
		};

		self.showAttachedTab = ko.computed({
			read: function(){
				if(self.attachedDocs().length > 0 || self.attachedCollectDocs().length > 0){
					self.showAttached(true);
				}
				if(self.attachedDocs().length === 0 && self.attachedCollectDocs().length === 0){
					self.showAttached(false);
				}
			}
		});

		self.launchItemExternally = function() { 
			window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(this.properties.objectName) + "?id=" + this.objectId + "&overlay=true" + "&contentType[]=" + ["pdf","txt",".*"]);
		};

		self.sendEmail = function(){
			app[myHandler].trigger("loading", true);
			//Get the form info
			var toArray = [], ccArray = [],  bccArray =  [];

			//if user leaves a recipient in the input make sure they get added!
			self.addTo();
			self.addCC();
			self.addBCC();

			if(self.currentToEmail()){
				app[myHandler].trigger("loading", false);
				app.trigger("alert:info", {
					header: (window.localize("modules.actions.sendEmail.sendEmail")),
					message : (window.localize("modules.actions.replyEmail.invalidEmail"))
				});
				return;
			}

			if(self.currentCCEmail() && self.showCC()){
				app[myHandler].trigger("loading", false);
				app.trigger("alert:info", {
					header: (window.localize("modules.actions.sendEmail.sendEmail")),
					message : (window.localize("modules.actions.replyEmail.invalidEmail"))
				});
				return;
			}
						
			if(self.currentBCCEmail() && self.showBCC()){
				app[myHandler].trigger("loading", false);
				app.trigger("alert:info", {
					header: (window.localize("modules.actions.sendEmail.sendEmail")),
					message : (window.localize("modules.actions.replyEmail.invalidEmail"))
				});
				return;
			}
			
			//get the email recipients
			_.each(self.toCheckList(), function(address){
				toArray.push(address.val);
			});
			_.each(self.ccCheckList(), function(address){
				ccArray.push(address.val);
			});
			_.each(self.bccCheckList(), function(address){
				bccArray.push(address.val);
			});

			self.emailBody(CKEDITOR.instances.body.getData());
			
			//Adds folder and collection attachment ids into one array
			var attachmentIdArray = [];
			_.each(self.attachedDocs(), function(attachedDoc){
				if(!(_.contains(attachmentIdArray, attachedDoc))){
					attachmentIdArray.push(attachedDoc);
				}
			});
			_.each(self.attachedCollectDocs(), function(attachedCollectDoc){
				if(!(_.contains(attachmentIdArray, attachedCollectDoc.objectId))){
					attachmentIdArray.push(attachedCollectDoc.objectId);
				}
			});
			
			if(self.emailBody().length !== 0 && self.subject.isValid() && self.toCheckList.isValid()){
				
				action.get("parameters").to = toArray;
				action.get("parameters").cc = ccArray;
				action.get("parameters").bcc = bccArray;
				action.get("parameters").subject = self.subject();
				action.get("parameters").email_folder_name = config.get("emailStorageLocation");
				action.get("parameters").attachment_ids = attachmentIdArray;
				action.get("parameters").email_rel_type = config.get("emailRelationship");
				action.get("parameters").body = self.emailBody();
				action.get("parameters").from =  app.user.id;
				action.get("parameters").email_bean_name = config.get("emailObjectType");
				action.get("parameters").folderTags = config.get("folderTags");
				action.get("parameters").folderId = self.folderId();
				//if folder notes enabled
				if(self.integrateFolderNotes()){
					//get the parent container
					action.get("parameters").parentID = action.get("parameters").folderId;
					action.get("parameters").note_content = CKEDITOR.instances.emailNoteContent.getData() ? CKEDITOR.instances.emailNoteContent.getData() : self.subject();
					action.get("parameters").property_map = {
																'note_type': config.get('noteType')
															};
					action.get("parameters").note_object_type = config.get('noteObjectType');
					action.get("parameters").note_rel_type = config.get('noteRelationship');
					action.get("parameters").createNote = "true";
				}
				else{
					action.get("parameters").createNote = "false";
				}
				action.execute({
					success: function(data){
						app[myHandler].trigger("loading", false);
						app[myHandler].trigger( "showMessage",(window.localize("modules.actions.replyEmail.emailSuccessfully")) );
						//ensure we are doing a container refresh with the folder id
						app.trigger("stage.refresh.containerId", self.folderId());

					},
					error: function(jqXHR, textStatus, errorThrown){
						app[myHandler].trigger("loading", false);
						app[myHandler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) +
							" " + jqXHR.responseText);
					}

				});
			}
			else
			{	
				app[myHandler].trigger("loading", false);
				if(self.emailBody().length===0){
					app.trigger("alert:info", {
						header: (window.localize("modules.actions.sendEmail.sendEmail")),
						message : (window.localize("modules.actions.replyEmail.emailMessageMust"))
					});
				}
				else if(!self.subject.isValid()){
					app.trigger("alert:info", {
						header: (window.localize("modules.actions.sendEmail.sendEmail")),
						message : (window.localize("modules.actions.replyEmail.pleaseEnterA")) + ( config.get("maxLength") ? config.get("maxLength") : 225 ) + (window.localize("modules.actions.replyEmail.characters"))
					});
				}
				else{
					app.trigger("alert:info", {
						header: (window.localize("modules.actions.sendEmail.sendEmail")),
						message : (window.localize("modules.actions.replyEmail.pleaseAddAt"))
					});
				}
			}
		};
		
		self.toggleCC = function(){
			if(self.showCC() && self.ccCheckList().length===0 && !self.currentCCEmail()) {
				self.showCC(false);
			} else if(!self.showCC()) {
				self.showCC(true);
			}
		};
		
		self.toggleBCC = function(){
			if(self.showBCC() && self.bccCheckList().length===0 && !self.currentBCCEmail()) {
				self.showBCC(false);
			} else if(!self.showBCC()) {
				self.showBCC(true);
			}
		};

		$('#folderAttach').click(function (e) {
			e.preventDefault();
			$(this).tab('show');
		});
		$('#collectionAttach').click(function (e) {
			e.preventDefault();
			$(this).tab('show');
		});
		$('#allAttach').click(function (e) {
			e.preventDefault();
			$(this).tab('show');
		});

		self.collectionResults = [];
		self.lastAjaxQueryString = undefined;

        this.getSource = function(query, process){
        	//only kick off ajax search if we need to
        	if (self.lastAjaxQueryString && query.toUpperCase().indexOf(self.lastAjaxQueryString.toUpperCase()) > -1){
        		var results = _.filter(self.collectionResults, function(collection){
        			return collection.objectName.toUpperCase().indexOf(query.toUpperCase()) !== -1;
        		});
        		return process(results);
        	}

			var collectObjects = {
				paramName: "Collection",
				paramValue: "Collection",
				paramType: "type"
			};

			var collectionType = {
				paramName: "hpi_collectionVisibility",
				paramValue: self.collectionType(),
				paramType: "property",
				operator: "OPERATOR_EQUALS"
			};

			var textInput = {
				paramName: "objectName",
				paramValue: query,
				paramType: "property",
				operator: "LOGIC_LIKE"
			};

			var availableCollections = new Query.Collection([],{mode:"client"});
			availableCollections.searchParameters = [];
			availableCollections.searchParameters.push(collectObjects);
			availableCollections.searchParameters.push(collectionType);
			availableCollections.searchParameters.push(textInput);

			self.lastAjaxQueryString = query;

			availableCollections.fetch({
				success: function(queryResults){
					//map collection names to id's
					self.collectionResults = [];
					_.each(queryResults.fullCollection.models, function(result){
						self.collectionResults.push({
							"objectName": result.get("properties").objectName,
							"objectId": result.get("properties").objectId
						});
					});

					return process(self.collectionResults);
				}
			});
        };

		//Used to get the current available documents to display checked when loaded in collections tab
        self.updateCheck = function(){
			_.each(self.attachedCollectDocs(), function(attachedCollectDoc){
				_.each(self.collectionsAttachments(), function(availableAttachment){
					if(attachedCollectDoc.objectId === availableAttachment().objectId) {
						var id = "#collectionCheckBox-" + availableAttachment().objectId;
							if($(id)){
								$(id).prop('checked', true);
							}
					}
				});
			});
        };

		self.loadCollectionDocuments = function(item){
			var collectionId;
			if(item){
				self.chosenCollection(item.objectName);
				collectionId = item.objectId;
			}

			var oCObject = new OC.OpenContentObject({objectId : collectionId});

			var jqxhr = oCObject.getRelatedObjects("hpi_collection_item", "Children");

			jqxhr.done( function(children){
				self.collectionsAttachments.removeAll();

				_.each(children, function(child){
					//remove any sub folders
					if(child.objectType !== "Folder" && child.objectType !== "Note") {
						self.collectionsAttachments.push(ko.observable(child));
					}						
				});
			});

		};
		
		self.populateAttachmentList = function(){

			var oCObject = new OC.OpenContentObject({objectId: self.folderId()});

			var jqxhr = oCObject.getChildren();
			jqxhr.done( function(children) {

				self.attachments.removeAll();
						
				_.each(children, function(child){
					//remove any children that are of a 'bad' object type
					//default bad types are Folder and Note
					if(_.indexOf(config.badAttachmentObjectTypes, child.objectType) === -1)
					{
						self.attachments.push(ko.observable(child));
					}
				});
			});
		};

		self.loadFolderDocs = function(){
			//first, determine what our folder id is, then we can populate
			//the attachment list with the folder docs
			var oCObject = new OC.OpenContentObject({objectId : action.get("parameters").objectId});
			oCObject.fetch({
				success: function(object) {
					app.context.configService.isContainer(object.get("objectType"), function(result){
						if(result === "true"){
							self.folderId(action.get("parameters").objectId);
							self.populateAttachmentList();
						}
						else{
							//we have a document, so we need to get its parent
							//id and use that as the folder id.
							app.context.util.getParents(action.get("parameters").objectId, function(data){
								self.folderId(data[0].objectId);
								self.populateAttachmentList();
							});
						}
						self.loading(false);
					});
				}
			});
		};
	}

	ReplyEmail.View = Backbone.Layout.extend({
		template: "actions/replyemail",

		events: {
			"blur .toContacts" : "blurTo",
			"blur .ccContacts" : "blurCC",
			"blur .bccContacts" : "blurBCC"
		},

		blurTo: function() {
			this.viewModel.addTo();
		},

		blurCC: function() {
			this.viewModel.addCC();
		},

		blurBCC: function() {
			this.viewModel.addBCC();
		},
		addAddress: function(target, item){
			if(target.attr("class").indexOf("toContacts") !== -1)
			{
				this.viewModel.currentToEmail(item.val);
				this.viewModel.addTo();
			}
			else if(target.attr("class").indexOf("bccContacts") !== -1)
			{
				this.viewModel.currentBCCEmail(item.val);
				this.viewModel.addBCC();
			}
			else //ccContacts class
			{
				this.viewModel.currentCCEmail(item.val);
				this.viewModel.addCC();
			}
			target.val([]);
		},
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.viewModel = new ViewModel(this.action, this.myHandler, this.options.config);
			this.viewModel.loadFolderDocs();
		},
		afterRender: function(){
			var self = this;
			if(self.myHandler === "rightSideActionHandler"){
				CKEDITOR.replace("body", { toolbar: "HPISimple",
										disableNativeSpellChecker: false,
										height: 400 },'');
				CKEDITOR.replace("emailNoteContent", { toolbar: "HPIMinimal",
										disableNativeSpellChecker: false,
										height: 400 }, '');
			} else {
				//myHandler is modal
				CKEDITOR.replace("body", { toolbar: "HPISimple",
										disableNativeSpellChecker: false,
										height: 150 },'');
				CKEDITOR.replace("emailNoteContent", { toolbar: "HPIMinimal",
										disableNativeSpellChecker: false,
										height: 150 }, '');
			}
			// CKEDITOR.config.height = 150;

			if(self.viewModel.integrateFolderNotes()){
				$("#emailNoteContentDiv").toggle();
			}

			if(self.viewModel.collectionAttachmentsTab()){
				$("#collectionAttachTab").toggle();
			}

			var oCObjectAttachments = new OC.OpenContentObject({objectId : app.context.document.get("objectId")});

			var jqxhr = oCObjectAttachments.getRelatedObjects("hpi_emailed", "Children");

			jqxhr.done( function(children){
				self.viewModel.originalAttachments.removeAll();

				_.each(children, function(child){
					//remove any sub folders
					if(child.objectType !== "Folder" && child.objectType !== "Note") {
						self.viewModel.originalAttachments.push(ko.observable(child));
					}

					var addedToAttachments = false;
					var childAttachment = {
						objectId : child.objectId,
						objectName : child.properties.objectName
					};

					_.each(self.viewModel.attachments(), function(attachment){
						if(child.objectId === attachment().objectId){
							self.viewModel.attachedDocs.push(childAttachment);
							addedToAttachments = true;
						} 
					});
					
					if(addedToAttachments === false){
						self.viewModel.attachedCollectDocs.push(childAttachment);
					}				
				});
			});

			if(app.context.document.get("objectType") === "HPIEmailMessage" && app.context.document.get("objectId")){
				//this ajax call is to return the original email content
				$.ajax({ 
					type: 'GET',
					url: app.serviceUrlRoot + '/content/content',
					data: {
						id: app.context.document.get("objectId")
					},
					context: this,
					async: false,
					success: function (emailData) {
						emailData = "<br><hr>" + emailData;
						var div = document.createElement("div");
						div.innerHTML = emailData;
						var html = div.innerHTML;
						CKEDITOR.instances.body.setData(html, function(){
							$("#CKEditorDiv").toggle();
						});
					}
				});
			} else if (app.context.document.get("properties").a_content_type === "msg"){
				$.ajax({
					url: app.serviceUrlRoot + "/introspect/msgProperties" + "?id=" + app.context.document.get("objectId"),
					success: function(oco){	
						if(oco.properties.fromEmail){
							self.viewModel.currentToEmail(oco.properties.fromEmail);
							if(self.viewModel.currentToEmail.isValid() && (self.viewModel.currentToEmail() !== app.user.get("emailAddress"))) {
								self.viewModel.toCheckList.push({"display":self.viewModel.currentToEmail(), "val":self.viewModel.currentToEmail()});
							}
							self.viewModel.currentToEmail("");
						}

						if(oco.properties.toEmailArray){
							_.each(oco.properties.toEmailArray, function(toEmail){
								self.viewModel.currentToEmail(toEmail);
								if(self.viewModel.currentToEmail.isValid() && (self.viewModel.currentToEmail() !== app.user.get("emailAddress"))){
									self.viewModel.toCheckList.push({"display":self.viewModel.currentToEmail(), "val":self.viewModel.currentToEmail()});
								}
								self.viewModel.currentToEmail("");
							});
						}

						if(oco.properties.ccEmailArray){
							_.each(oco.properties.ccEmailArray, function(ccEmail){
								self.viewModel.currentCCEmail(ccEmail);
								if(self.viewModel.currentCCEmail.isValid() && (self.viewModel.currentToEmail() !== app.user.get("emailAddress"))) {
									self.viewModel.ccCheckList.push({"display":self.viewModel.currentCCEmail(), "val":self.viewModel.currentCCEmail()});
								}
								self.viewModel.currentCCEmail("");
							});
						}

						if(oco.properties.bccEmailArray){
							_.each(oco.properties.bccEmailArray, function(bccEmail){
								self.viewModel.currentBCCEmail(bccEmail);
								if(self.viewModel.currentBCCEmail.isValid() && (self.viewModel.currentToEmail() !== app.user.get("emailAddress"))) {
									self.viewModel.bccCheckList.push({"display":self.viewModel.currentBCCEmail(), "val":self.viewModel.currentBCCEmail()});
								}
								self.viewModel.currentBCCEmail("");
							});
						}

						if(self.viewModel.ccCheckList().length){
							self.viewModel.toggleCC();
						}
						if(self.viewModel.bccCheckList().length){
							self.viewModel.toggleBCC();
						}

						self.viewModel.subject("Re: " + oco.properties.subject);

						String.prototype.replaceAll=function(s1, s2) {
							return this.split(s1).join(s2);
						};
						var emailData = "<br /><p>" + oco.properties.messageBody + "</p>";
						emailData = emailData.replaceAll("\n", "<br />");
						var div = document.createElement("div");
						div.innerHTML = emailData;
						var html = div.innerHTML;
						CKEDITOR.instances.body.setData(html, function(){
							$("#CKEditorDiv").toggle();
						});
					}
				});
			}

			$.get(app.serviceUrlRoot + "/email/folderAddressBook", {"folderId": app.context.container.get("objectId")}, function(data){
				var contacts = data.contacts;
				if(contacts){
					_.each(contacts, function(contact){
						//allows typeahead for contacts against username or email
						if(contact.username) {
							contact.username = contact.username + " " + contact.emailAddress;
						} else {
							contact.username = contact.emailAddress;
						}
						self.viewModel.typeAheadContactList().push(contact);
					});
					self.viewModel.typeAheadContactList.valueHasMutated();

					_.each(self.$el.find(".toContacts, .ccContacts, .bccContacts"), function(object){
						var $this = $(object);

						$this.keypress(function(event){
							if(event.which === 13){ //ENTER key
								self.addAddress($this, {
									'display': $this.attr("value"),
									'val': $this.attr("value")
								});
							}
						});
					});
				}else{ // no pre-existing addresses
					_.each(self.$el.find(".toContacts, .ccContacts, .bccContacts"), function(object){
						var $this = $(object);
						$this.keypress(function(event){
							if(event.which === 13){ //ENTER key
								self.addAddress($this, {
									'display': $this.attr("value"),
									'val': $this.attr("value")
								});
							}
						});
					});
				}
				
			});
			
			self.viewModel.toTypeahead = $("#toContacts").typeahead({
								minLength: 1,
								highlight: true
							},{
								name: 'tocontactssearch',
								displayKey: 'emailAddress',
								source: function(whatusertyped, process)
								{
									var contactNames = _.filter(self.viewModel.typeAheadContactList(), function(contactsTrue){
										return contactsTrue.username.toUpperCase().indexOf(whatusertyped.toUpperCase()) !== -1;
									});
									process(contactNames);
								}	
							}
						);
			self.viewModel.toTypeahead.on('typeahead:selected', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#toContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.toTypeahead.typeahead('val', '');
			});
			self.viewModel.toTypeahead.on('typeahead:autocompleted', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#toContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.toTypeahead.typeahead('val', '');
			});

			self.viewModel.ccTypeahead = $("#ccContacts").typeahead({
								minLength: 1,
								highlight: true
							},{
								name: 'toCCcontactssearch',
								displayKey: 'emailAddress',
								source: function(whatusertyped, process)
								{
									var contactNames = _.filter(self.viewModel.typeAheadContactList(), function(contactsTrue){
										return contactsTrue.username.toUpperCase().indexOf(whatusertyped.toUpperCase()) !== -1;
									});
									process(contactNames);
								}	
							}
						);

			self.viewModel.ccTypeahead.on('typeahead:selected', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#ccContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.ccTypeahead.typeahead('val', '');
			});
			self.viewModel.ccTypeahead.on('typeahead:autocompleted', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#ccContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.ccTypeahead.typeahead('val', '');
			});

			self.viewModel.bccTypeahead = $("#bccContacts").typeahead({
								minLength: 1,
								highlight: true
							},{
								name: 'toBCCcontactssearch',
								displayKey: 'emailAddress',
								source: function(whatusertyped, process)
								{
									var contactNames = _.filter(self.viewModel.typeAheadContactList(), function(contactsTrue){
										return contactsTrue.username.toUpperCase().indexOf(whatusertyped.toUpperCase()) !== -1;
									});
									process(contactNames);
								}	
							}
						);

			self.viewModel.bccTypeahead.on('typeahead:selected', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#bccContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.bccTypeahead.typeahead('val', '');
			});
			self.viewModel.bccTypeahead.on('typeahead:autocompleted', function(evt, data)
			{
				var contact = _.findWhere(self.viewModel.typeAheadContactList(),{username : data.username} );
				self.addAddress($("#bccContacts"), {
					'display': contact.username,
					'val': contact.emailAddress
				});
				self.viewModel.bccTypeahead.typeahead('val', '');
			});


			self.collectionResults = [];
			self.lastAjaxQueryString = "";

			self.viewModel.collectionTypeahead = $("#collectionSearch").typeahead({
					minLength: 3,
					highlight: true
				},
				{
					name: 'sendemailcollectionsearch',
					displayKey: 'objectName',
					source: _.debounce(self.viewModel.getSource, 500)
				}
			);

			self.viewModel.collectionTypeahead.on('typeahead:selected', function(evt, data){
				self.viewModel.loadCollectionDocuments(data);
			});

			self.viewModel.expandIcon = ko.observable("glyphicon glyphicon-chevron-down");
			self.viewModel.toggleExpandIcon = function() {
				if (self.viewModel.expandIcon() === "glyphicon glyphicon-chevron-up") {
					self.viewModel.expandIcon("glyphicon glyphicon-chevron-down");
				} else {
					self.viewModel.expandIcon("glyphicon glyphicon-chevron-up");
				}
			};

			if(self.viewModel.ccCheckList().length){
				self.viewModel.toggleCC();
			}
			if(self.viewModel.bccCheckList().length){
				self.viewModel.toggleBCC();
			}

			// this updates the CSS on the attachments slide down div so that the overflow is visible when the attachments
			// div is expanded - this makes sure the dropdown for collections appears above the text area for entering the email body
			this.$("#attachments").on('shown', function() {
				self.$("#attachments").css("overflow", "visible");
			});

			// this updates the CSS on the attachments slide down div so that the overflow is hidden when the attachments
			// div STARTS to be hidden - this gives a much more intuitive look to the div sliding away into nothing
			this.$("#attachments").on('hide', function() {
				self.$("#attachments").css("overflow", "hidden");
			});

			// the attachments "collapse" bootstrap element triggers a hide event when we close it which will bubble
			// up and cause our modal to close as well...unless we stop it
			this.$("#attachments").on('hidden', function(event) {
				event.stopPropagation();
			});

			kb.applyBindings(self.viewModel, self.$el[0]);
		},
		serialize: function(){
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
		}
	});

	ReplyEmail.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/sendemail/sendemailconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;
			//check if folderTags already exists
			if(!viewModel.model().get('folderTags')){
				viewModel.model().set('folderTags', []);
			}
			viewModel.model().set('folderTags', viewModel.model().get('folderTags'));
			
			viewModel.maxLength = kb.observable(viewModel.model(), "maxLength");
			viewModel.maxLength("225");
			viewModel.emailStorageLocation = kb.observable(viewModel.model(), "emailStorageLocation");
			viewModel.emailObjectType = kb.observable(viewModel.model(), "emailObjectType");
			viewModel.emailRelationship = kb.observable(viewModel.model(), "emailRelationship");
			viewModel.integrateFolderNotes = kb.observable(viewModel.model(), 'integrateFolderNotes');
			viewModel.noteObjectType = kb.observable(viewModel.model(), "note_object_type");
			viewModel.noteType = kb.observable(viewModel.model(), "note_type");
			viewModel.noteRelationship = kb.observable(viewModel.model(), "noteRelationship");
			viewModel.attachmentAttrToShow = kb.observable(viewModel.model(), "attachmentAttrToShow");

			if(viewModel.emailObjectType() === null){
				viewModel.emailObjectType("HPIEmailMessage");
			}

			if(viewModel.emailStorageLocation() === null){
				viewModel.emailStorageLocation("Correspondence");
			}
			//default folder notes integration to false
			if(viewModel.integrateFolderNotes() === null){
				viewModel.integrateFolderNotes("false");
			}
			//default to HPI Note
			if(viewModel.noteObjectType() === null){
				viewModel.noteObjectType("HPI Note");
			}
			//default to Correspondence
			if(viewModel.noteType() === null){
				viewModel.noteType("Correspondence");
			}

			//default to hpi_folder_note --> documentum default
			if(viewModel.noteRelationship() === null){
				viewModel.noteRelationship("hpi_folder_note");
			}

			//default to dctm relationship name
			if(viewModel.emailRelationship() === null){
				viewModel.emailRelationship("hpi_emailed");
			}
			
			if(viewModel.attachmentAttrToShow() === null){
				viewModel.attachmentAttrToShow("objectName");
			}

			viewModel.integrateFolderNotes.subscribe(function(newVal){
				if(newVal === "false"){
					//reset to defaults
					viewModel.noteObjectType("HPI Note");
					viewModel.noteType("Correspondence");
				}
			});

			viewModel.folderTags = ko.observableArray(viewModel.model().get('folderTags'));

			viewModel.folderTags.subscribe(function(tags) {
				viewModel.model().set('folderTags', tags);
			});

			viewModel.repeatingPlaceholder = ko.observable();
			//repeating values need two extra functions for adding and removing from value
			viewModel.addValue = function() {
				//don't add anything if it already exists in value, make sure that 
				//only whitespace is not entered, and ensure the value is properly 
				//trimmed when added to the array
				if (_.indexOf(viewModel.folderTags(), viewModel.repeatingPlaceholder()) < 0 && 
						viewModel.repeatingPlaceholder() && 
						viewModel.repeatingPlaceholder().trim() !== "") {
					viewModel.folderTags.push(viewModel.repeatingPlaceholder().trim());
				}
				viewModel.repeatingPlaceholder("");
			};

			viewModel.removeValue = function(item) {
				viewModel.folderTags.remove(item);
			};
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});
	
	//list of object types that won't be included in the list of
	//possible email attachments (default is you can't send a note or folder as an attachment)
	var badAttachmentObjectTypes = ['Note', 'Folder'];

	actionModules.registerAction("replyEmail", ReplyEmail, {
        "actionId" : "replyEmail",
		"label" : "Reply Email",
		"icon" : "circle-arrow-left"
    },
    {
		"badAttachmentObjectTypes" : badAttachmentObjectTypes
    });

	return ReplyEmail;

});
require(["replyemail"]);