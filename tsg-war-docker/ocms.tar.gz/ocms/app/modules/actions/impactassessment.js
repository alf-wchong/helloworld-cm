// Export Search Results action
define("impactassessment",[
    // Application.
    "app",
    "modules/actions/actionmodules",
    "modules/common/downloadutils",
    "modules/hpiadmin/actionconfig/actions/impactassessment/impactassessmentcustomactionconfig"
  ],
  
  function(app, actionModules, downloadUtils, ImpactAssessmentCustomConfigView) {
          
    "use strict";

    var ImpactAssessment = {}; 

    ImpactAssessment.CustomConfigView = ImpactAssessmentCustomConfigView.View;

    ImpactAssessment.View = Backbone.Layout.extend({
        template: "actions/impactassessment",
        events:{
            "click #submitImpactAssessment" : "impactassessment"
        },

        initialize: function(){
            //get all info to run impact assessment from impact assessment config
            this.myHandler = this.options.config.get("handler");
            this.searchCriteria = this.options.config.get('searchCriteria');
            this.excelProps = this.options.config.get('nameAttrsToDisplay') ? this.config.get('nameAttrsToDisplay') : [];
            this.queryCriteria = this.options.config.get('queryCriteria') ? this.config.get('queryCriteria') : [];
            this.AddtColumnCriteria = this.options.config.get('columnCriteria') ? this.config.get('columnCriteria') : [];
            this.searchAttr = app.context.document.get("properties")[this.options.config.get('searchCriteria')[0].attribute];
            this.selectedDocumentType = this.options.config.get('selectedDocumentType') ? this.config.get('selectedDocumentType') : "";
        },
        impactassessment : function() {
            //send in parameters to back end
            this.action.get("parameters").excelProps = _.pluck(this.excelProps, 'attrValue');
            this.action.get("parameters").excelLabelProps = _.pluck(this.excelProps, 'attrName');
            this.action.get("parameters").queryAttr = _.pluck(this.queryCriteria, 'attribute');
            this.action.get("parameters").queryValue = _.pluck(this.queryCriteria, 'value');
            this.action.get("parameters").columnValue = _.pluck(this.AddtColumnCriteria, 'attribute');
            this.action.get("parameters").cellValue = _.pluck(this.AddtColumnCriteria, 'value');
            this.action.get("parameters").searchCriteria = _.pluck(this.searchCriteria, 'attribute');
            this.action.get("parameters").objectId = app.context.document.get("properties").objectId;
            this.action.get("parameters").searchAttr = app.context.document.get("properties")[this.options.config.get('searchCriteria')[0].attribute];
            this.action.get("parameters").fileName =  "ImpactAssessment" + "-" + app.context.document.get("properties")[this.options.config.get('searchCriteria')[0].attribute] +".xls";
            this.action.get("parameters").selectedDocumentType = this.selectedDocumentType;

            var self = this;
            var callback = function() {
                app[self.myHandler].trigger("showMessage", window.localize("modules.actions.impactAssessment.theResults"));
            };
            var error = function(){
                app[self.myHandler].trigger("showError", window.localize("modules.actions.impactAssessment.error"));
            };
            
            //download excel sheet
            downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', this.action.attributes, callback, error);
  
        },

    });

    actionModules.registerAction("impactAssessment", ImpactAssessment, {
        "actionId": "impactAssessment",
        "label": (window.localize("modules.actions.impactAssessment.generateImpactAssessment")),
        "icon": "filter",
        "handler": "modalActionHandler"
    });

    return ImpactAssessment;

});

require(["impactassessment"]);