define("sendsmartcomm",[
	"app",
	"oc",
	"modules/actions/actionmodules",
	"modules/common/typeahead",
	"modules/common/exportwithannotations",
	"modules/hpiadmin/searchconfig/emailtemplatesconfig",
	'modules/common/hpiconstants',
	"modules/hpiadmin/actionconfig/actions/sendsmartcomm/sendsmartcommcustomactionconfig",
	"modules/actions/sendsmartcomm/sendsmartcomm-attachmentsview",
	"modules/actions/sendsmartcomm/sendsmartcomm-subjectview",
	"modules/actions/sendsmartcomm/sendsmartcomm-util",
	"tsgUtils",
	"module"
],

function(app, OC, actionModules, HPITypeAhead, 
	ExportWithAnnotations, EmailTemplatesConfig, HPIConstants, SendSmartcommCustomConfigView, SendEmailAttachmentsView, SubjectView, SendSmartCommUtil, TSGUtils, module) {
	"use strict";

	var SendSmartcomm = {};

	SendSmartcomm.thunderheadServer = module.config().thunderheadServer;

	SendSmartcomm.CustomConfigView = SendSmartcommCustomConfigView.View;

	SendSmartcomm.Constants = {
		TO: "to", 
		CC: "cc",
		BCC: "bcc",
		PHONE: "phone"
	};

	SendSmartcomm.validateEmail = function (email) {
		var emailReg = /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return emailReg.test(email);
	};

	SendSmartcomm.parseMultipleEmails =  function(emails){
		var individualEmails = emails.split(/[,;]+/); // split on any number of commas and semicolons
		var responseObject = {
			validEmailList: [], 
			invalidEmailList: [],
			duplicatedEmailList: []			
		};

		//process the individual emails
		_.each(individualEmails, function(email){
			email = email.replace(/\s/g, ''); // throw out whitespace
			if (!email){
				return; // if you get rid of the whitespace and there's nothing left, don't bother doing anything else
			}

			// the name is irrelevant, I only care about what's in the brackets
			var hasBrackets = (email.indexOf("<") >= 0) ? true : false ; // do we have those angled brackets? 
			var isValid = false;
			var emailPortion; 
			if (hasBrackets){
				emailPortion = email.split(/[<>]+/)[1]; // this should grab the section of the email between brackets 
				isValid = SendSmartcomm.validateEmail(emailPortion);
			} else {
				emailPortion = email; // I care about the whole thing, there aren't brackets
				isValid = SendSmartcomm.validateEmail(emailPortion);
			}

			if (!isValid){
				responseObject.invalidEmailList.push(emailPortion);
				return;
			} else{ // it is a valid email
				
				if (responseObject.validEmailList.indexOf(emailPortion) >= 0){ // but this email is a duplicate (note: only valid emails can get marked as duplicates)
					responseObject.duplicatedEmailList.push(emailPortion);
				} else{
					responseObject.validEmailList.push(emailPortion); 
				}
			}
		});

		return responseObject; // just hand back all the emails as arrays of strings: valid, invalid, and duplicated. What the caller wants with that is up to them. 
	};

	SendSmartcomm.validatePhone = function (phone) { 
		var regex = /(\+\d{1,3}\s\d{3}-\d{3}-\d{4})(-\d*)?/;

		return regex.test(phone);
	};
	SendSmartcomm.parseMultiplePhones =  function(phones){
		var individualPhones = phones.split(/[,;]+/); // split on any number of commas and semicolons
		var responseObject = {
			validPhoneList: [], 
			invalidPhoneList: [],
			duplicatedPhoneList: []			
		};

		//process the individual emails
		_.each(individualPhones, function(phone){
			if (!phone){
				return; // if you get rid of the whitespace and there's nothing left, don't bother doing anything else
			}

			var isValid = SendSmartcomm.validatePhone(phone);

			if (!isValid){
				responseObject.invalidPhoneList.push(phone);
				return;
			} else{ // it is a valid email
				if (responseObject.validPhoneList.indexOf(phone) >= 0){ // but this phone is a duplicate (note: only valid phones can get marked as duplicates)
					responseObject.duplicatedPhoneList.push(phone);
				} else{
					responseObject.validPhoneList.push(phone); 
				}
			}
		});

		return responseObject; // just hand back all the phones as arrays of strings: valid, invalid, and duplicated. What the caller wants with that is up to them. 
	};

	SendSmartcomm.Models = {};

	SendSmartcomm.Models.EmailInfoModel = Backbone.Model.extend({
		initialize: function() {
			this.set("toCheckList", new Backbone.Collection());
			this.set("ccCheckList", new Backbone.Collection());
			this.set("bccCheckList", new Backbone.Collection());
			this.set("phoneCheckList", new Backbone.Collection());
			this.set("subject", "");
			this.set("body", "");
		}
	});

	//Model that will be created for each document selected
	//This should be updated to properly use sets and gets instead of just this.
	SendSmartcomm.Models.SendSmartcommCoordinator = Backbone.Model.extend({
		initialize: function(config, action) {
			this.config = config;
			this.action = action;
			this.handler = this.config.get("handler");
			this.emailInfoModel = new SendSmartcomm.Models.EmailInfoModel();
			this.folderId = app.context.container.id || "";
			this.showCC	= false;
			this.showBCC = false;
			this.showPhone = false;
			this.showShared = false;
			this.showCollectionDocs = "";
			this.collectionType = "private";
			this.chosenCollection = "";
			this.state = {};
			this.collectionResults = [];
			this.typeAheadContactList = {"phones":[], "emails":[]};
			this.validateAttachments = this.config.get("validateAttachments") === "true";
			this.validateMaxNumberOfAttachments = this.config.get('validateMaxNumberOfAttachments') === "true";
			this.shouldValidateTotalAttachmentsSize = this.config.get('shouldValidateTotalAttachmentsSize') === "true" ;
			this.shouldTrackAttachmentSize = (this.config.get('cloudSendMode') === "dependent" && this.config.get('restrictInternalBasedOnAttachmentSize') === true) || this.config.get('shouldValidateTotalAttachmentsSize') === "true";
			this.hideAvailableDocsTab = this.config.get("hideAvailableDocsTab") === 'true';
			this.maxLength = this.config.get("maxLength") || "225";
			this.integrateFolderNotes = this.config.get("integrateFolderNotes") === "true";
			this.hasMaxBodyLength = this.config.get('hasMaxBodyLength') === "true";
			this.maxBodyCharacters = this.config.get('maxBodyCharacters') || 8000;
			this.format = this.config.get('bodyFormat') || 'html';
			this.subjectPrefixes = this.config.get('subjectPrefixes') || {};
			this.isUploadAttachmentsActionEnabled = this.config.get('enableUploadAttachmentsAction');
			this.isSelectAttachmentVersionEnabled = this.config.get('enableSelectAttachmentVersion');

			// These should default to true if no value is configured
			var alwaysCreateNoteOnSend = this.config.get("alwaysCreateNoteOnSend");
			this.alwaysCreateNoteOnSend = (!alwaysCreateNoteOnSend || alwaysCreateNoteOnSend === "true");

			var collectionAttachmentsTab = this.config.get("collectionAttachmentsTab");
			this.collectionAttachmentsTab = (!collectionAttachmentsTab || collectionAttachmentsTab === "true");

			/***** smartcomm configs ******/

			this.projectId = this.config.get("smartCommProjectId");
			this.dataModelResId = this.config.get("smartCommDataModelId");
			this.batchConfigResId = this.config.get("smartCommBatchConfigResId");

			// get configured folder attributes
			this.configuredFolder = this.config.get("selectedFolderTypeSmartComm"); // insuranceDemo_claimsFolder
			this.smartCommAttrs = this.config.get("smartCommAttrsToDisplay");

			/***** smartcomm configs ******/
		}
	});

	SendSmartcomm.View = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm",
		events: {
			"click #attachmentButton": "toggleExpandIcon",
			"click #sendEmailButton": "sendEmail",
			"click #uploadAttachmentsAction": "triggerUploadAttachmentsAction",
			"click .glyphicon-remove-circle" : "removeClicked",
		},
			

		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.model = new SendSmartcomm.Models.SendSmartcommCoordinator(this.options.config, this.options.action);
			this.model.attributesToDisplay = this.config.get('attrsToDisplay') ? this.config.get('attrsToDisplay') : [];
			this.hideNoResultMessage = this.options.config.get("hideNoResultMessage");
			this.contentSizeCollection = new Backbone.Collection();
			this.ckeditorSize = this.myHandler ===  HPIConstants.Handlers.RightSideActionHandler ? 400 : 100;

			/***** smartcomm configs ******/

			this.dataModelResId = this.options.config.get("smartCommDataModelId");

			/***** smartcomm configs ******/

			// cloud send can be enabled (always use cloud send), false (never use cloud send), or dependent
			this.validateCloudSend = this.config.get('cloudSendMode') === "dependent";

			// can skip all this business if we're not in dependent mode
			var internalSendEmailDeferreds = [];
			if (this.validateCloudSend){
				internalSendEmailDeferreds = this.initializeInternalEmailRestrictions();
			}

			this.enterKeys =  this.options.config.get('selectedEnterKeys') || [HPIConstants.CHARCODES.Enter]; // just enter key if nothing is configured
			// Figure out if we are a group action coming from tableview. We will be a group action if 'group' is in the action id 
			this.model.groupAction = this.action.get('actionId').indexOf('group') > 0;
			if (this.model.groupAction){
				// set the folderId on the action objectId
				this.action.get('parameters').objectId = app.context.container.id;
			}
			
			this.unattachableDocsView = new SendSmartcomm.UnattachableDocsView({});
			
			//load all of the attachments
			this.loadFolderDocs();

			if(this.config.get("allowEmailTemplates") === "true"){
				this.fetchEmailTemplates();
			}

			// This will reset the annotationInfo action parameter so that whatever was on there before will be erased.
			this.action.get("parameters").annotationInfo = null;
 
			//set up all of the subviews
			this.bodyView = new SendSmartcomm.EmailBodyView();
			// if validateCloudSend is false, this will resolve immediately
			$.when(internalSendEmailDeferreds).done(_.bind(function(){
				this.recipientsView = new SendSmartcomm.RecipientsView({options: this});
			}, this));
			this.attachmentsView = new SendEmailAttachmentsView.View({ options: this });
			this.subjectView = new SubjectView.View({options: this});

			this.startListening();
		},
		initializeInternalEmailRestrictions: function(){
			var internalSendEmailDeferreds = [];
			this.restrictInternalBasedOnAttachmentSize = this.config.get('restrictInternalBasedOnAttachmentSize');
			this.restrictInternalBasedOnFileExtension = this.config.get('restrictInternalBasedOnFileExtension');
			this.restrictInternalBasedOnEmailDomains = this.config.get('restrictInternalBasedOnEmailDomain');


			this.internalSendEmailDomains = [];
			if (this.restrictInternalBasedOnEmailDomains){
				var internalSendEmailDomainsDeferred = $.Deferred();
				internalSendEmailDeferreds.push(internalSendEmailDomainsDeferred);
				var selectedEmailDomainsPicklist = this.config.get('selectedEmailDomains');
				app.context.picklistService.getPicklist(selectedEmailDomainsPicklist, _.bind(function(picklistOptions){
					this.internalSendEmailDomains = _.pluck(picklistOptions, 'label');
					this.internalSendEmailDomains = _.map(this.internalSendEmailDomains, function(domain){
						return domain.toLowerCase();
					});
					internalSendEmailDomainsDeferred.resolve();
				}, this));
			}

			this.internalSendEmailExtensions = [];
			if (this.restrictInternalBasedOnFileExtension){
				var internalSendEmailExtensionsDeferred = $.Deferred();
				internalSendEmailDeferreds.push(internalSendEmailExtensionsDeferred);
				var selectedFileExtensionsPicklist = this.config.get('selectedFileExtensions');
				app.context.picklistService.getPicklist(selectedFileExtensionsPicklist, _.bind(function(picklistOptions){
					this.internalSendEmailExtensions = _.pluck(picklistOptions, 'label');
					this.internalSendEmailExtensions = _.map(this.internalSendEmailExtensions, function(extension){
						return extension.toLowerCase();
					});
					internalSendEmailExtensionsDeferred.resolve();
				}, this));
			}

			if (this.restrictInternalBasedOnAttachmentSize){
				this.internalSendEmailAttachmentSize = this.config.get('internalSendEmailAttachmentSize');				
			}
			return internalSendEmailDeferreds;
		},
		beforeRender: function(){
			this.setViews({
				"#recipientsView": this.recipientsView,
				"#attachmentsSubview": this.attachmentsView,
				"#subjectSubview": this.subjectView,
				"#unattachableDocs-outlet": this.unattachableDocsView,
				'#sendSmartcomm-emailBody': this.bodyView
			});

			if(this.typeaheadResolved){
        		this.setView('#phoneContacts', this.phoneTypeahead);
        	}
		},
		afterRender: function(){

			if(this.model.integrateFolderNotes){
				$("#emailNoteContentDiv").toggle();
			}

			if(this.model.collectionAttachmentsTab){
				$("#collectionAttachTab").toggle();
			}

			this.rendered = true;
			if(this.typeaheadResolved){
				this.startListening();
			}
			
			
			this.recipientsView.render();
			this.attachmentsView.render();
			this.subjectView.render();
		
			this.canSubmit();
		},
		serialize: function() {
			return {
				modal: this.myHandler === HPIConstants.Handlers.ModalActionHandler,
				rightSide: this.myHandler === HPIConstants.Handlers.RightSideActionHandler,
				integrateFolderNotes: this.model.integrateFolderNotes,
				isUploadAttachmentsActionEnabled: this.model.isUploadAttachmentsActionEnabled,
				cid: this.cid
			};
		},

		/**
		 * Grab a clone of the bulk upload folder action config from the stage config. Override a few modal config attributes.
		 * @param {Backbone.Model} stageConfig the stage config for this trac.
		 */
		getUploadFolderActionConfig: function (stageConfig) {
			var bulkUploadConfig;
			if (stageConfig) {
				var folderActionConfigs = stageConfig.get('folderActionConfig');

				if (folderActionConfigs) {
					var actionGroups = folderActionConfigs.get('actionGroups');

					if (actionGroups) {
						// search all of these for a bulk upload config, taking the first one
						actionGroups.each(function (actionGroup) {
							var actions = actionGroup.get('actions');

							if (actions && !bulkUploadConfig) {
								bulkUploadConfig = actions.findWhere({
									actionId: HPIConstants.Actions.BulkUpload
								});
							}
						}, this);
					}
				}
			}

			if (bulkUploadConfig) {
				this.uploadAttachmentsSubactionConfig = bulkUploadConfig.clone();
				// Assuming that the send email action is a right side action and so we fire the upload attachments sub action as a modal action
				this.uploadAttachmentsSubactionConfig.set('handler', HPIConstants.Handlers.ModalActionHandler);
				this.uploadAttachmentsSubactionConfig.set('modalSize', 'xl');
				this.uploadAttachmentsSubactionConfig.set('modalBackdrop', 'static');
				this.uploadAttachmentsSubactionConfig.set('label', window.localize("stage.sendEmail.uploadAttachments"));
			}
		},
		
		/**
		 * Callback for the #uploadAttachmentsAction click event. Kicks off the bulk upload modal. This will grab the bulk upload config if this is the
		 * first time the user has clicked this button.
		 */
		triggerUploadAttachmentsAction: function () {
			if (this.uploadAttachmentsSubactionConfig) {
				this.displayUploadModal();
			} else {
				app.context.configService.getStageConfigByName(app.context.configName(), null, null, this)
					.fail(this.showNoUploadConfigError)
					.done(this.getUploadFolderActionConfig)
					.then(this.displayUploadModal);
			}
		},

		showNoUploadConfigError: function() {
			app.trigger("alert:error", {
				header: window.localize("modules.actions.sendEmail.uploadAttachment.noConfigError.header"),
				message: window.localize("modules.actions.sendEmail.uploadAttachment.noConfigError.message")
			});
		},
		
		/**
		 * Triggers the modalActionHandler's show event with the bulk upload subaction. 
		 * Sets up the done callback on the subaction deferred.
		 * Displays an error to the user if there is no bulk upload config.
		 */
		displayUploadModal: function () {
			if (this.uploadAttachmentsSubactionConfig) {
				var uploadAttachmentSubactionDeferred = $.Deferred();
				uploadAttachmentSubactionDeferred.done(this.processUploadedAttachments);

				app[HPIConstants.Handlers.ModalActionHandler].trigger("show", {
					config: this.uploadAttachmentsSubactionConfig,
					subactionDeferred: uploadAttachmentSubactionDeferred,
					actionContext: this,
					isSubaction: true,
					removeSubactionOnCompletion: false
				});
			} else {
				this.showNoUploadConfigError();
			}
		},
		
		/**
		 * Calls getAttachmentData to add the newly uploaded attachments to the Attachments view.
		 * @param {Object} results Contains an array, successList, that contains all of the successfully uploaded attachments.//#endregion
		 */
		processUploadedAttachments: function (results) {
			var uploadedAttachments = _.pluck(results.successList, "objectId");
			if (!_.isEmpty(uploadedAttachments)) {
				SendSmartCommUtil.getAttachmentData({
					model: this.model,
					ids: uploadedAttachments,
					isOcoFetchGlobal: false,
					ocoFetchSuccessCallback: this.displayAttachments,
					ocoFetchErrorCallback: this.onFetchAttachmentDataError,
					fetchContentSizeSuccessCallback: this.setContentSizeCollection,
					fetchContentSizeErrorCallback: this.onFetchContentSizeError,
					attachmentDataFetchSuccessCallback: this.handleAttachmentDataFetch,
					context: this
				});
			}
		},
		populateAttachmentList: function(){
			var self = this;
			var oCObject = new OC.OpenContentObject({objectId: self.model.folderId});

			var jqxhr = oCObject.getChildren();
			jqxhr.done( function(children) {
				self.attachmentsView.pending = false;
				self.attachmentsView.attachments = [];

				// Get the OTC and time formatting config in order to format any dates
				app.context.configService.getAdminOTC(function(otc) {
					_.each(children, function(child){
						//remove any children that are of a 'bad' object type
						//default bad types are Folder and Note
						if(_.indexOf(self.model.config.badAttachmentObjectTypes, child.objectType) === -1)
						{
							SendSmartCommUtil.setAttributesToDisplay(otc, child, self.model.attributesToDisplay);
							self.attachmentsView.attachments.push(child);

							//check the box of current document on the stage if send email called from document actions list or if the current obj was passed via group action
							if(child.objectId === self.model.action.get("parameters").objectId || _.contains(self.model.action.get("parameters").objectIds, child.objectId))
							{
								// check if the current doc has content by making sure it's mimeType property is set
								if (child.mimeType){
									self.attachmentsView.addSelectedAttachment(child, true);
								} else {
									// we can't attach this doc it has no content, add it to the unattachableDocs view
									self.unattachableDocsView.addUnattachableDoc(child);
								}
							}
						}
						self.attachmentsView.render();
					});
				}); //end getAdminOTC
			});
		},
		onFetchAttachmentDataError: function() {					
			this.attachmentsView.render();
		},
		onFetchContentSizeError: function() {
			this.model.shouldValidateTotalAttachmentsSize = false;
			this.attachmentsView.render();
		},
		setContentSizeCollection: function(docs) {
			_.each(docs, function(doc) {
				var contentSizeMap = {
					size: doc.contentSizes[0],
					id: doc.objectId
				};
				this.contentSizeCollection.add(contentSizeMap);
			}, this);
		},
		displayAttachments: function(ocos) {
			this.attachmentsView.pending = false;
			var self = this;
			// Get the OTC and time formatting config in order to format any dates
			app.context.configService.getAdminOTC(function(otc) {
				_.each(ocos, function(doc){
					SendSmartCommUtil.setAttributesToDisplay(otc, doc, self.model.attributesToDisplay);
					// check if the current doc has content by making sure it's mimeType property is set
					if (doc.mimeType){
						self.attachmentsView.addSelectedAttachment(doc, true);
					} else {
						// we can't attach this doc it has no content, add it to the unattachableDocs view
						self.unattachableDocsView.addUnattachableDoc(doc);
					}
				});

				self.attachmentsView.render();
			});
		},
		fetchEmailTemplates: function(){
			var body = {"dataModelResId": this.dataModelResId};
			var getTemplateIdsOCUrl = "smartcomm/getTemplateIds";
			var getTemplateIdsUrl = app.serviceUrlRoot + "/" + getTemplateIdsOCUrl;

			Backbone.ajax({
				context: this,
				type: "POST",
				url: getTemplateIdsUrl,
				data: JSON.stringify(body),
				contentType: "application/json",
				success: function(response) {
					this.templates = new Backbone.Collection(response.templateIds);
				},
				error: function() {
					this.templates = new Backbone.Collection([]);
				},
				complete: this.createAndRenderTemplatesView
			});
		},
		createAndRenderTemplatesView: function () {
			this.templatesView = new SendSmartcomm.TemplatesView({
				templates: this.templates,
				smartCommModel: this.model
			});
			this.setView("#templates-outlet", this.templatesView).render();
			this.listenTo(this.templatesView, 'sendEmail:emailSubjectView:insertSubjectText', this.updateSubjectValue);
		},
		updateSubjectValue: function(newSubjectValue) {
			$('#send-email-subject').val(newSubjectValue);
			this.subjectView.setSubjectText(newSubjectValue);
		},
		loadFolderDocs: function () {
			var oCObject = new OC.OpenContentObject({
				objectId: this.model.action.get("parameters").objectId
			});
			// first, we fetch the oco to get the object type,
			// then we determine the folder id,
			// then we grab all the folder docs for that folder id
			oCObject.fetch()
				.then(_.bind(this.setFolderId, this, oCObject))
				.then(_.bind(this.fetchFolderDocs, this));
		},
		setFolderId: function(object) {
			var self = this;
			var folderIdFoundDeferred = $.Deferred();
			app.context.configService.isContainer(object.get("objectType"), function(result) {
				if (result === "true") {
					self.model.folderId = self.model.action.get("parameters").objectId;
				} else {
					//we have a document, so we need to get its parent
					//id and use that as the folder id.
					self.model.folderId = app.context.container.id;
					self.model.action.get("parameters").objectIds = [self.model.action.get("parameters").objectId];
				}
				folderIdFoundDeferred.resolve();
			});
			
			return folderIdFoundDeferred;
		},
		fetchFolderDocs: function() {
			// only fetch all docs in folder if we don't want to hide the available docs tab,
			// else, just fetch docs that were passed in on the action params
			if (!this.model.hideAvailableDocsTab){
				this.populateAttachmentList();
			} else {
				SendSmartCommUtil.getAttachmentData({
					model: this.model,
					ids: this.model.action.get("parameters").objectIds,
					isOcoFetchGlobal: true,
					ocoFetchSuccessCallback: this.displayAttachments,
					ocoFetchErrorCallback: this.onFetchAttachmentDataError,
					fetchContentSizeSuccessCallback: this.setContentSizeCollection,
					fetchContentSizeErrorCallback: this.onFetchContentSizeError,
					attachmentDataFetchSuccessCallback: this.handleAttachmentDataFetch,
					context: this
				});
			}

			this.attachmentsView.render();
		},

		/**
		 * Calls displayAttachments with the attachment ocos. 
		 * Calls setContentSizeCollection with the content collection.
		 * @param  {Array} ocosPromiseArray the promise array for the fetchOcos call
		 * @param  {Array} contentSizesPromiseArray the promise array for the fetchContentSizeCollection call
		 */
		handleAttachmentDataFetch: function(ocosPromiseArray, contentSizesPromiseArray) {
			// these arrays contain the result of their respective ajax calls as the first param 
			var ocoArray = ocosPromiseArray[0];
			var contentSizesArray = contentSizesPromiseArray[0];
			this.displayAttachments(ocoArray);
			this.setContentSizeCollection(contentSizesArray);
		},

		toggleExpandIcon: function() {
			this.$('#attachmentToggleArrow').toggleClass('glyphicon-chevron-up glyphicon-chevron-down');
		},

		canSubmit: function() {
			var isSendEmailButtonDisabled = true;
			//Allow Submit is at least one user and a date have been selected. Message is optional.
			var hasEmailsInTheToField = this.model.emailInfoModel.get("toCheckList").length > 0;
			var hasValidSubject = this.subjectView.validateSubject();
			var hasValidNumberOfAttachments = true;
			var hasValidTotalSizeOfAttachments = true;

			if (this.validateCloudSend){
				this.verifyCanSendInternally();
			}

			if (this.model.validateMaxNumberOfAttachments) {
				hasValidNumberOfAttachments = this.attachmentsView.validateNumberOfAttachments();
			}

			if (this.model.shouldValidateTotalAttachmentsSize) {
				hasValidTotalSizeOfAttachments = this.attachmentsView.validateTotalAttachmentsSize(this.options.config.get('maxTotalAttachmentsSize'));
			}

			if (hasEmailsInTheToField && hasValidSubject && hasValidNumberOfAttachments && hasValidTotalSizeOfAttachments) {
				isSendEmailButtonDisabled = false;
			}

			// update the button
			$('#sendEmailButton').prop('disabled', isSendEmailButtonDisabled);
			// return if we can submit
			return !isSendEmailButtonDisabled;
		},
		getAttachmentIds: function() {
			var objectIdKey = HPIConstants.OpenContentObject.ObjectId;
			var selectedAttachmentVersionIdArray = [];
			var attachmentIdArray = [];

			// if we've allowed the user to select versions,
			// we need to grab and send both the selected version and working copy ids
			if (this.model.isSelectAttachmentVersionEnabled) {
				objectIdKey = "workingCopyId";
				selectedAttachmentVersionIdArray = _.uniq(this.attachmentsView.attachedDocs.pluck(HPIConstants.OpenContentObject.ObjectId));
			}

			// get objectId arrays
			var attachedDocsArray = this.attachmentsView.attachedDocs.pluck(objectIdKey);
			var collectionDocsArray = this.attachmentsView.attachedCollectDocs.pluck(HPIConstants.OpenContentObject.ObjectId);

			// get one array that is the unique set of both attached and collection docs
			attachmentIdArray = _.union(attachedDocsArray, collectionDocsArray);

			return {
				selectedAttachmentVersionIdArray: selectedAttachmentVersionIdArray,
				attachmentIdArray: attachmentIdArray
			};
		},
        verifyCanSendInternally: function(){
            var infoMessages = [];

            // three pieces of validation
            var internalEmailDomain = true;
            var internalAttachmentType = true;
            var underConfiguredAttachmentSize = true;

            // 1) domains
			if (this.restrictInternalBasedOnEmailDomains && this.recipientsView.getEmailList().length !== 0){
            	// _.every runs a boolean check for every element, and shortcut returns when it returns false
	            internalEmailDomain =  _.every(this.recipientsView.getEmailList(), function(emailAddress){
	                var domain =  emailAddress.split('@')[1].toLowerCase();
	                return _.contains(this.internalSendEmailDomains, domain);
	            }, this);

	            if (!internalEmailDomain) {
					infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalEmailDomainMessage"));   			
        	    }
            }

            // 2) attachment extensions
            if (this.restrictInternalBasedOnFileExtension && this.attachmentsView.attachedDocs.models.length !== 0){
            	// _.every runs a boolean check for every element, and shortcut returns when it returns false
	            internalAttachmentType =  _.every(this.attachmentsView.attachedDocs.models, function(doc){
	                var filename = doc.get('objectName');
	                var extension = filename.substring(filename.lastIndexOf('.')).toLowerCase();
	                return _.contains(this.internalSendEmailExtensions, extension);
	            }, this);

	            if (!internalAttachmentType) {
					infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalAttachmentExtensionMessage"));    			
        	    }
            }
           
            // 3) attachments under configurable size.
            if (this.restrictInternalBasedOnAttachmentSize){
	            if (this.attachmentsView.totalAttachmentSize > this.internalSendEmailAttachmentSize){
                	infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalAttachmentSizeMessage") + this.internalSendEmailAttachmentSize + TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE);
                	underConfiguredAttachmentSize = false;
          		}
            }

            // if we're over the total attachment size limit, where send email is disabled, we don't want to see both the "can't send internally" and "please remove attachments" messages
            var underActionAttachmentSizeLimit = true;
            if (this.model.shouldValidateTotalAttachmentsSize){
            	underActionAttachmentSizeLimit = this.attachmentsView.validateTotalAttachmentsSize(this.options.config.get('maxTotalAttachmentsSize'));
            }
            // show the message if need be
            if ((!internalEmailDomain || !internalAttachmentType || !underConfiguredAttachmentSize) && underActionAttachmentSizeLimit){
                var messageView = new SendSmartCommUtil.GenericMessageView(
                	{
                		"mainMessage": window.localize("modules.actions.sendEmail.cannotSendInternally"),
                		"ordered" : false,
                		"messages" : infoMessages
                	}
                );
				// that true is to maintain the content
                app[this.myHandler].trigger("showInfo", messageView, true);
                return false; // cannot send internally
            } else {
            	app[this.myHandler].trigger("hideInfo");
 	            return true; // good to send internally
            }
        },
		sendEmail: function() {
			var self = this;
			self.handler = this.model.handler;
			self.$(".error-message-" + this.cid).hide();
			app[self.handler].trigger("loading", true);

			if (self.model.validateMaxNumberOfAttachments) {
				var maxAttachments = this.config.get('maxNumberOfAttachments');
				if (this.attachmentsView.attachedDocs.length > maxAttachments) {
					app[self.handler].trigger("loading", false);
					self.model.errorMessage = window.localize("modules.actions.sendEmail.exceedsMaxAttachments") + maxAttachments +
					" " + window.localize("stage.sendEmail.attachments") + "." + window.localize("modules.actions.sendEmail.removeAttachments");
					self.$(".error-message-" + self.cid).show().html("<span>" + self.model.errorMessage + "</span>");

					return;
				}
			}

			//Get the form info
			var toArray = [], ccArray = [], bccArray = [], phoneArray = []; 

			//if user leaves a recipient in the input make sure they get added!
			self.recipientsView.addToRecipientsSubView(SendSmartcomm.Constants.TO);
			self.recipientsView.addToRecipientsSubView(SendSmartcomm.Constants.CC);
			self.recipientsView.addToRecipientsSubView(SendSmartcomm.Constants.BCC);
			self.recipientsView.addToRecipientsSubView(SendSmartcomm.Constants.PHONE);

			//Handler to check if the email is valid
			//get the email recipients
			self.model.emailInfoModel.get("toCheckList").each(function(addressModel){
				toArray.push(addressModel.get("emailAddress"));
			});
			self.model.emailInfoModel.get("ccCheckList").each(function(addressModel){
				ccArray.push(addressModel.get("emailAddress"));
			});
			self.model.emailInfoModel.get("bccCheckList").each(function(addressModel){
				bccArray.push(addressModel.get("emailAddress"));
			});
			self.model.emailInfoModel.get("phoneCheckList").each(function(addressModel){
				phoneArray.push(addressModel.get("phoneNumber"));
			});
			
            //get plain text or HTML based on configuration (HTML by default)
			// self.model.emailInfoModel.set("body", self.bodyView.getBodyValue());

			if(self.model.validateAttachments) {
				if (this.attachmentsView.attachedDocs.length === 0) {
                    app[self.handler].trigger("loading", false);
                    self.model.errorMessage = window.localize("modules.actions.sendEmail.pleaseAttach");
                    self.$(".error-message-" + self.cid).show().html("<span>" + self.model.errorMessage + "</span>");
                    return;
                }
			}

			// Adds folder and collection attachment ids into one array
			var attachmentIdArray = [];
			var selectedAttachmentVersionIdArray = [];
			var attachmentIdArrays = self.getAttachmentIds();
			attachmentIdArray = attachmentIdArrays.attachmentIdArray;
			selectedAttachmentVersionIdArray = attachmentIdArrays.selectedAttachmentVersionIdArray;
			

			self.model.action.get("parameters").to = toArray;
			self.model.action.get("parameters").cc = ccArray;
			self.model.action.get("parameters").bcc = bccArray;

			self.model.action.get('parameters').phone = phoneArray;
			
			self.model.action.get("parameters").subject = self.model.emailInfoModel.get("subject");
			self.model.action.get("parameters").email_folder_name = self.model.config.get("emailStorageLocation");
			self.model.action.get("parameters").attachment_ids = attachmentIdArray;
			self.model.action.get("parameters").email_rel_type = self.model.config.get("emailRelationship");
			
			self.model.action.get("parameters").from =  app.user.id;
			self.model.action.get("parameters").email_bean_name = self.model.config.get("emailObjectType");
			self.model.action.get("parameters").folderTags = self.model.config.get("folderTags");
			self.model.action.get("parameters").folderId = self.model.folderId || app.context.container.id;
			self.model.action.get("parameters").trac = app.context.configName();

			
			if (this.validateCloudSend){
				// run through the check to see if we should send through the cloud
				self.model.action.get("parameters").cloudSendEnabled = !this.verifyCanSendInternally();
			} else {
				self.model.action.get("parameters").cloudSendEnabled = self.model.config.get("cloudSendMode") === "enabled";
			}

			self.model.action.get("parameters").cloudSend = self.model.config.get("emailObjectType");
			self.model.action.get('parameters').selectedVersionIds = selectedAttachmentVersionIdArray;

			// If folder notes enabled
			if (self.model.integrateFolderNotes) {
				self.model.action.get("parameters").note_content = self.model.emailInfoModel.get("subject");

				// If note content has been set by this point, let's configure the action to add the note
				if (self.model.action.get("parameters").note_content) {
					//get the parent container
					self.model.action.get("parameters").parentID = self.model.action.get("parameters").folderId;
					var currentDate = DateFormat.format.date(new Date(),"E, d MMM yyyy hh-mm-ss a");
					self.model.action.get("parameters").property_map = {
						'note_type': self.model.config.get('noteType'),
						'objectName': "Folder Note - " + currentDate
					};
					self.model.action.get("parameters").note_object_type = self.model.config.get('noteObjectType');
					self.model.action.get("parameters").note_rel_type = self.model.config.get('noteRelationship');
					self.model.action.get("parameters").createNote = "true";
				} else {
					self.model.action.get("parameters").createNote = "false";
				}
			} else {
				self.model.action.get("parameters").createNote = "false";
			}

			var deferred = $.Deferred();
			self.allAttachments = [];
			self.annotations = [];

			// If the Export With Annotations attribute was configured for this action OR if we have already selected some annotators
			if(self.config.get("exportWithAnnotationsToAttachments") === 'true' || self.model.action.get("parameters").annotationInfo) {
				// If the user has selected some annotators
				if(self.model.action.get("parameters").annotationInfo) {
					self.executeAction(self);
				// If the user has not selected any annotators yet
				} else {
					// If the e-mail has no attachments, we send the e-mail as usual.
					if(self.model.action.get("parameters").attachment_ids.length === 0) {
						self.executeAction(self);
					} else {
						var that = self;
						var deferreds = [];
						// For each document the user has selected, we want to call getAnnotations
						_.each(self.model.action.get("parameters").attachment_ids, function(attachmentId) {
							var lastModified = 0;
							var documentName = "";
							for(var i = 0; i < this.attachmentsView.attachments.length; i++){
								if(this.attachmentsView.attachments[i].objectId === attachmentId) {
									lastModified = this.attachmentsView.attachments[i].properties.modifiedDate;
									documentName = this.attachmentsView.attachments[i].properties.objectName;
								}
							}

							deferreds.push( self.getAnnotations(attachmentId, lastModified, documentName, self.allAttachments, self.annotations) );
						}, that);

						if(deferreds.length > 0) {
							$.when.apply(null, deferreds).done($.proxy(function() {
								// If there are no annotations on the attachments, we send the email as usual.
								if(self.annotations.length === 0) {
									self.executeAction(that);
								} else {
									self.exportWithAnnotationsView(that, self.allAttachments);
								}
								deferred.resolve();
							}, that));
						}
					}
				}
			} else {
				self.executeAction(self);
			}
		},
		getAnnotations: function(attachmentId, lastModified, documentName, allAttachments, annotations) {
			var authors = [];
			return $.ajax({
				url: app.serviceUrlRoot + "/annotation/getAnnotations",
				dataType: "json",
				method: "GET",
				data: {
					id: attachmentId,
					lastModified: lastModified
				},
				success: function(data) {
					// We only want to add the info to allAttachments if there were any annotations returned
					if(data.annotations && data.annotations.length > 0) {
						_.each(data.annotations, function(annotation) {
							annotations.push(annotation);
							authors.push(annotation.title);
						});
					}
				},
				error: function() {
					alert((window.localize("modules.actions.sendEmail.cannotGetAnnotations")));
				}
			}).done(function() {
				// We only want to add the info to allAttachments if there were any annotations returned
				if(authors.length > 0) {
					authors = _.uniq(authors);
					allAttachments.push({id: attachmentId, name: documentName, authors: authors});
				}
			});
		},
		exportWithAnnotationsView: function(self, allAttachments) {
			app[self.handler].trigger("loading", false);

			// Pass allAttachments and self.model.action into new ExportWithAnnotations view
			self.exportWithAnnotationsForm = new ExportWithAnnotations.View({
				options: this,
				allAttachments: allAttachments,
				action: self.model.action
			});

			// Set an attribute that will hide the "emailForm" div and show the "exportWithAnnotationsForm"
			self.$("#emailForm").toggleClass("hidden");
			$("div#exportWithAnnotationsForm").removeClass("hiddenExportWithAnnotations");

			// Re-render the action view
			self.setView("#exportWithAnnotationsForm", self.exportWithAnnotationsForm);
			self.exportWithAnnotationsForm.render();
		},
		executeAction: function(self) {
			window.ThunderheadEditor._sendCommand('getString', {forceSave: false}, function(success, XMLofEmailBody){
				// Once we call this callback, use the body returned here
				self.model.action.get("parameters").body = XMLofEmailBody;
				self.model.action.execute({
					success: function(){
						app[self.handler].trigger("loading", false);
						app[self.handler].trigger( "showMessage", (window.localize("modules.actions.sendCorrespondence.successful")));
						//ensure we are doing a container refresh with the folder id
						app.trigger("stage.refresh.containerId", self.model.folderId);
					},
					error: function(jqXHR){
						app[self.handler].trigger("loading", false);
						app[self.handler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) + jqXHR.responseText);
					}
				});
			}, window.ThunderheadEditor);
		},
		startListening: function(){
			// add extra listeners if we need to be checking if we should be doing cloud send
			if (this.validateCloudSend){
				this.listenTo(this.recipientsView, 'emails:changed', this.verifyCanSendInternally);
				this.listenTo(this.attachmentsView, 'totalAttachmentSize:updated', this.verifyCanSendInternally);
			}
		}

	});

	SendSmartcomm.EmailBodyView = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm-bodyview",
		setUpThunderhead: function() {
			// the cloud path for the draft editor we are replacing with the usual email body editor
			window.Thunderhead.DraftEditor.prototype.DRAFTEDITOR_CONTEXT = '/one/draft-editor';
			window.ThunderheadEditor = new window.Thunderhead.DraftEditor({
			    // The protocol (http/https), Thunderhead Server host, & port if not 80/443
			    thunderheadServer: SendSmartcomm.thunderheadServer,
			    // The protocol (http/https), Client Server host, & port if not 80/443 - used to validate origin of API messages
			    clientServer: window.location.origin,
			    // This element will contain the Thunderhead Application iFrame
			    targetElementID: 'thunderheadApplication',
			    // A function to be executed once the Draft-Editor is loaded, for example:  Can be used to execute API calls on start-up
			    onReady: function() {},
			    // Will be called to retrieve configuration for the Draft-Editor
			    loadStartupConfig: function() {
			        // See Draft Editor API JSDoc for available config options
			        return {
			            version: '2'
			        };
			    },
			    // // Requires SSO integration
			    // authUrl: '',
			    // authParams: ''
			});
		},
		afterRender: function () {
			this.setUpThunderhead();
		}
	});

	SendSmartcomm.RecipientsView = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm-allrecipients",
		events: {
			"click .glyphicon-remove-circle" : "removeClicked",
			"click #ccButton": "toggleCC",
			"click #bccButton": "toggleBCC",
			"click #phoneButton": "togglePhone"

		},
		initialize: function(config){
			this.parent = config.options;
			this.model = config.options.model;
			this.hideNoResultMessage = config.options.hideNoResultMessage; 
			this.enterKeys = config.options.enterKeys || [HPIConstants.CHARCODES.Enter];
			this.toRecipientsView = new SendSmartcomm.RecipientsSubView();
			this.ccRecipientsView = new SendSmartcomm.RecipientsSubView();
			this.bccRecipientsView = new SendSmartcomm.RecipientsSubView();
			this.phoneRecipientsView = new SendSmartcomm.RecipientsSubView();
			

			this.fetchAddressBook();
		},
		fetchAddressBook: function() {
			//get all contacts in the address book to populate the typeaheads
			$.ajax({
				url: app.serviceUrlRoot + "/email/folderAddressBook",
				type: "GET",
				context: this,
				data: {
					folderId: app.context.container.get("objectId")
				},
				success: this.onAddressBookFetch,
				error: this.createTypeaheadControls
			});
		},
		onAddressBookFetch: function(data) {
			this.addContactsToContactList(data.emailContactBook, data.phoneContactBook);
			this.createTypeaheadControls();
		},
		getEmailList: function(){
			var emails = [];

			emails = _.union(emails, _.pluck(this.toRecipientsView.addedEmailAddresses, 'emailAddress'));
			emails = _.union(emails, _.pluck(this.ccRecipientsView.addedEmailAddresses, 'emailAddress'));
			emails = _.union(emails, _.pluck(this.bccRecipientsView.addedEmailAddresses, 'emailAddress'));

			return emails;
		},
		getPhoneList: function(){
			var phones = [];
			phones = _.union(phones, _.pluck(this.phoneRecipientsView.addedPhoneNumbers, 'phoneNumber'));
			return phones;
		},

		addContactsToContactList: function(emailBook, phoneBook) {
			var self = this;
			if(emailBook !== null) {
				_.each(emailBook.contacts, function(contact){
					if (contact.username) {
						contact.username = contact.username + " " + contact.emailAddress;
					}
					else {
						contact.username = contact.emailAddress;
					}

					self.model.typeAheadContactList.emails.push(contact);
				});
			}
			if (phoneBook !== null) {
				_.each(phoneBook.contacts, function(contact){
					if (contact.username) {
						contact.username = contact.username + " " + contact.phoneNumber;
					}
					else {
						contact.username = contact.phoneNumber;
					}

					self.model.typeAheadContactList.phones.push(contact);
				});
			}
		},
		createTypeaheadControls: function(){
			var self = this;
			self.toTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)), // must be passed by value
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true, 
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.ccTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)), // must be passed by value
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true,
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.bccTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)), // must be passed by value
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true,
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.phoneTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.phones)), // must be passed by value
                enterKeys : this.enterKeys,
                displayKey: 'phoneNumber',
                searchOn: 'phoneNumber',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true,
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	
        	self.typeaheadResolved = true;
        	self.startListening();
			if(self.rendered){
	         	self.setViews({
	         		'#toContacts': self.toTypeahead,
	         		"#toRecipientsSubview": self.toRecipientsView,
	         		'#ccContacts': self.ccTypeahead,
	         		"#ccRecipientsSubview": self.ccRecipientsView,
	         		'#bccContacts': self.bccTypeahead,
	         		"#bccRecipientsSubview": self.bccRecipientsView,
	         		'#phoneContacts': self.phoneTypeahead,
	         		"#phoneRecipientsSubview": self.phoneRecipientsView
	         		
	         	}).render();
	        }else{
	        	self.setViews({
	         		'#toContacts': self.toTypeahead,
	         		"#toRecipientsSubview": self.toRecipientsView,
	         		'#ccContacts': self.ccTypeahead,
	         		"#ccRecipientsSubview": self.ccRecipientsView,
	         		'#bccContacts': self.bccTypeahead,
	         		"#bccRecipientsSubview": self.bccRecipientsView,
	         		'#phoneContacts': self.phoneTypeahead,
	         		"#phoneRecipientsSubview": self.phoneRecipientsView
	         		
	         	});
	        }
        },


		startListening: function(){
			if(this.typeaheadResolved) {
				this.stopListening(this.toTypeahead);
				this.stopListening(this.ccTypeahead);
				this.stopListening(this.bccTypeahead);
				this.stopListening(this.phoneTypeahead);

				this.listenTo(this.toTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendSmartcomm.Constants.TO, option);
					}
				}, this);
				this.listenTo(this.ccTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendSmartcomm.Constants.CC, option);
					}
				}, this);
				this.listenTo(this.bccTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendSmartcomm.Constants.BCC, option);
					}
				}, this);
				this.listenTo(this.phoneTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendSmartcomm.Constants.PHONE, option);
					}
				}, this);

				this.listenTo(this.toTypeahead,'render:done', function(){
					// check if we should show the required class on the 'To'
					if (this.toRecipientsView.addedEmailAddresses.length <= 0) {
						$(".typeahead-" + this.toTypeahead.cid + ".tt-input").addClass('bs-callout-basic bs-callout-warning');
					}
			 		$(".typeahead-" + this.toTypeahead.cid + ".tt-input").focus();
				}, this);
			} else {
				return;
			}
		},
        beforeRender: function(){
        	if(this.typeaheadResolved){
        		this.setView('#toContacts', this.toTypeahead);
        		this.setView('#ccContacts', this.ccTypeahead);
        		this.setView('#bccContacts', this.bccTypeahead);
        		this.setView('#phoneContacts', this.phoneTypeahead);
        	
        	}
        },
        afterRender: function() {
			this.rendered = true;
			if(this.typeaheadResolved){
				this.startListening();
			}
		},
		serialize: function(){
			return {
				showCC: this.model.showCC,
				showBCC: this.model.showBCC,
				showPhone: this.model.showPhone,
				// default to true even if the config is not defined yet
				showBCCToggleButton: this.parent.config.get("enableBCCControl") === "true" || this.parent.config.get("enableBCCControl") == undefined
			};
		},
		// small helper function for addToRecipientsSubView, which was getting a bit long
		differentiateSubView: function(fieldFlag){
			// ------- Begin code for differentiating between to, cc, and bcc fields ---------
			var isTo, isCC, isBCC, isPhone = false; // can get away with this because these are booleans
			var recipientsSubView;
			var typeahead;
			var checkListString;
			switch (fieldFlag){  // using a switch statement to target the right objects so there aren't if statements everywhere
				case SendSmartcomm.Constants.TO:
					recipientsSubView = this.toRecipientsView;
					typeahead = this.toTypeahead;
					checkListString = "toCheckList";
					isTo = true;
					break;

				case SendSmartcomm.Constants.CC:
					recipientsSubView = this.ccRecipientsView;
					typeahead = this.ccTypeahead;
					checkListString = "ccCheckList";
					isCC = true;
					break; 

				case SendSmartcomm.Constants.BCC:
					recipientsSubView = this.bccRecipientsView;
					typeahead = this.bccTypeahead;
					checkListString = "bccCheckList";
					isBCC = true;
					break;
				case SendSmartcomm.Constants.PHONE:
					recipientsSubView = this.phoneRecipientsView;
					typeahead = this.phoneTypeahead;
					checkListString = "phoneCheckList";
					isPhone = true;
					break;
			}
			// -------- End code for differentiating between to, cc, and bcc fields --------- 

			// now simply return all the parameters for the the specified field, (to, cc, or bcc)
			return {
				isTo: isTo, 
				isCC: isCC, 
				isBCC: isBCC,
				isPhone: isPhone, 
			
				recipientsSubView: recipientsSubView,
				typeahead: typeahead, 
				checkListString: checkListString
			};
		},
		addToRecipientsSubView: function(fieldFlag, currentUser) {

			var fieldParams = this.differentiateSubView(fieldFlag); // dial in on which field we're adding to 

			if (!currentUser) {
				var tempEmailAddress = $(".typeahead-" + fieldParams.typeahead.cid + ".tt-input").val(); // grab the address off the typeahead (if anything's there)
				if (tempEmailAddress){
					currentUser = {
						emailAddress: tempEmailAddress						
					};
				}
			}	
			if(currentUser) {
				// initialize lists for both sending methods
				var emailLists = SendSmartcomm.parseMultipleEmails("");
				var phoneLists = SendSmartcomm.parseMultiplePhones("");

				if(fieldParams.checkListString === "phoneCheckList") {
					// below here is functionality for parsing phones
					var phoneAddressString = currentUser.phoneNumber ? currentUser.phoneNumber : currentUser.value;
					phoneLists = SendSmartcomm.parseMultiplePhones(phoneAddressString);
					if (phoneLists.validPhoneList.length != 0) {
						var addedPhoneNumbers =[];
						_.each(fieldParams.recipientsSubView.addedPhoneNumbers, function(address) { 
							addedPhoneNumbers.push(address.phoneNumber);
						});
						phoneLists.validEmailList = _.filter(phoneLists.validPhoneList, function(validPhone){
							if (addedPhoneNumbers.indexOf(validPhone) > -1 ){ // can't use "includes()" in IE
								phoneLists.duplicatedPhoneList.push(validPhone);
								return false; // it's a duplicate, don't want it in the validEmailList
							}
							this.model.emailInfoModel.get(fieldParams.checkListString).push(new Backbone.Model({ // push this new phone onto the emailinfoModel on the right checklist
								"phoneNumber": validPhone
							})); 
							fieldParams.recipientsSubView.addedPhoneNumbers.push({ "phoneNumber": validPhone, "isPhone": fieldParams.isPhone }); //tack it onto the phones we're sending to
							return true; // unique, leave it in the validEmailList
						}, this);
					}
				}
				else {
					// below here is functionality for parsing emails
					var emailAddressString = currentUser.emailAddress ? currentUser.emailAddress : currentUser.value;
					emailLists = SendSmartcomm.parseMultipleEmails(emailAddressString); // get validEmailList, invalidEmailList, and duplicatedEmailList on this object

					// now that we've parsed the emails, we need to do certain things for valid emails, invalid emails, and duplicated emails
					if (emailLists.validEmailList.length != 0){
						var addedEmailAddresses = []; 
						_.each(fieldParams.recipientsSubView.addedEmailAddresses, function(address){
							addedEmailAddresses.push(address.emailAddress);
						});
						emailLists.validEmailList = _.filter(emailLists.validEmailList, function(validEmail){
							if (addedEmailAddresses.indexOf(validEmail) > -1 ){ // can't use "includes()" in IE
								emailLists.duplicatedEmailList.push(validEmail);
								return false; // it's a duplicate, don't want it in the validEmailList
							}
							this.model.emailInfoModel.get(fieldParams.checkListString).push(new Backbone.Model({ // push this new email onto the emailinfoModel on the right checklist
								"emailAddress": validEmail
							})); 
							fieldParams.recipientsSubView.addedEmailAddresses.push({ "emailAddress": validEmail, "isTo": fieldParams.isTo, "isCC": fieldParams.isCC, "isBCC": fieldParams.isBCC}); //tack it onto the emails we're sending to 
							return true; // unique, leave it in the validEmailList
						}, this);
					}
				}

				// error handling
				fieldParams.recipientsSubView.errorMessage = ""; // zero out the error message
				if (emailLists.invalidEmailList.length >= 1){ 
					fieldParams.recipientsSubView.errorMessage += window.localize("modules.actions.sendEmail.invalidEmail") + emailLists.invalidEmailList.join(", ") + ". ";
				}

				if (emailLists.duplicatedEmailList.length >= 1){
					fieldParams.recipientsSubView.errorMessage += window.localize("modules.actions.sendEmail.duplicatedEmail") + emailLists.duplicatedEmailList.join(", ") + ". ";
				}

				// invalid phone
				if (phoneLists.invalidPhoneList.length >= 1){ 
					fieldParams.recipientsSubView.errorMessage += window.localize("modules.actions.sendEmail.invalidPhone") + phoneLists.invalidPhoneList.join(", ") + ". ";
					fieldParams.recipientsSubView.errorMessage += window.localize("modules.actions.sendEmail.invalidPhone.format");
				}
				// duplicate phone
				if (phoneLists.duplicatedPhoneList.length >= 1){
					fieldParams.recipientsSubView.errorMessage += window.localize("modules.actions.sendEmail.duplicatedPhone") + phoneLists.duplicatedPhoneList.join(", ") + ". ";
				}
				
				// moving on to to the final phase	
				if (emailLists.validEmailList.length > 0 || phoneLists.validPhoneList.length > 0){
					fieldParams.typeahead.clear();
				}

				if (this.toRecipientsView.addedEmailAddresses.length > 0){ // remove the warning orange on the to field
		        	$(".typeahead-" + this.toTypeahead.cid + ".tt-input").removeClass('bs-callout-basic bs-callout-warning');	
				}

							
				fieldParams.recipientsSubView.render(); // all done, render the badges and show the relevant error messages (if any)
				this.trigger('emails:changed');
			}

			if (fieldParams.isTo){
				this.parent.canSubmit(); // check if we're good to send the email, but only on to field
			}
			
		},
		removeClicked: function(event){
        	var self = this;
        	//get the id so we know if the object to remove is a user, group, or date
        	var value = this.$(event.currentTarget)[0].id;
        	//make this the id of the remove date x and have it call its own remove function
        	if (value){
        		var name = this.$(event.currentTarget)[0].parentElement.id;
	        	if(value.indexOf(SendSmartcomm.Constants.TO) > -1){
	        		self.removeToContact(name);
	        	}
	        	//need to put bcc first, otherwise the cc indexOf will catch bcc
	        	else if  (value.indexOf(SendSmartcomm.Constants.BCC) > -1){
	        		self.removeBccContact(name);
	        	}
	        	else if  (value.indexOf(SendSmartcomm.Constants.CC) > -1){
	        		self.removeCcContact(name);
	        	}
	        	else if (value.indexOf(SendSmartcomm.Constants.PHONE) > -1){
	        		self.removePhoneContact(name);
	        	}
	    	}
			// check if we should show the required class on the 'To'
			if (this.toRecipientsView.addedEmailAddresses.length <= 0) {
                $(".typeahead-" + this.toTypeahead.cid + ".tt-input").addClass('bs-callout-basic bs-callout-warning');
            }
            
	    	this.parent.canSubmit();
	    	this.trigger('emails:changed');
        },
		removeToContact: function(item) {
			this.model.emailInfoModel.get("toCheckList").remove(this.model.emailInfoModel.get("toCheckList").findWhere({emailAddress : item}));
			this.toRecipientsView.addedEmailAddresses = _.without(this.toRecipientsView.addedEmailAddresses , _.findWhere(this.toRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.toRecipientsView.render();
		},
		removeCcContact: function(item) {
			this.model.emailInfoModel.get("ccCheckList").remove(this.model.emailInfoModel.get("ccCheckList").findWhere({emailAddress : item}));
			this.ccRecipientsView.addedEmailAddresses = _.without(this.ccRecipientsView.addedEmailAddresses, _.findWhere(this.ccRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.ccRecipientsView.render();
		},
		removeBccContact: function(item) {
			this.model.emailInfoModel.get("bccCheckList").remove(this.model.emailInfoModel.get("bccCheckList").findWhere({emailAddress : item}));
			this.bccRecipientsView.addedEmailAddresses = _.without(this.bccRecipientsView.addedEmailAddresses, _.findWhere(this.bccRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.bccRecipientsView.render();
		},
		removePhoneContact: function(item) {
			this.model.emailInfoModel.get("phoneCheckList").remove(this.model.emailInfoModel.get("phoneCheckList").findWhere({phoneNumber : item}));
			this.phoneRecipientsView.addedPhoneNumbers = _.without(this.phoneRecipientsView.addedPhoneNumbers, _.findWhere(this.phoneRecipientsView.addedPhoneNumbers, {phoneNumber : item}));
			this.phoneRecipientsView.render();
		},

		toggleCC: function(){
			if(this.model.showCC && this.model.emailInfoModel.get("ccCheckList").length===0 && !this.model.currentCCEmail)
			{
				this.model.showCC = false;
			}
			else if(!this.model.showCC)
			{
				this.model.showCC = true;
			}
			this.render();
		},
		toggleBCC: function(){
			if(this.model.showBCC && this.model.emailInfoModel.get("bccCheckList").length===0 && !this.model.currentBCCEmail)
			{
				this.model.showBCC = false;
			}
			else if(!this.model.showBCC)
			{
				this.model.showBCC = true;
			}
			this.render();
		},
		togglePhone: function(){
			if(this.model.showPhone && this.model.emailInfoModel.get("phoneCheckList").length===0 && !this.model.currentPhoneNumber)
			{
				this.model.showPhone = false;
			}
			else if(!this.model.showPhone)
			{
				this.model.showPhone = true;
			}
			this.render();
		}
	});

	

	/*This subview allows us to rerender only the list of recipients
	when a group or user is added or removed.
	Otherwise, rerendering the view resets the contents of the message and
	kills the typeahead listeners.*/
	SendSmartcomm.RecipientsSubView = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm-recipients",
		events: {
			"focus" : "showOrHideErrors",
		},
		initialize: function(){
			this.addedEmailAddresses = [];
			this.addedPhoneNumbers=[];
			this.errorMessage = ""; 
		},
		afterRender: function(){
			this.showOrHideErrors(); 
		},
		showOrHideErrors: function(){
			if (this.errorMessage){
				$(".error-message-" + this.cid).show().html(this.errorMessage); // show any remaining error messages
			}else{
				$(".error-message-" + this.cid).hide();
			}
		},
		serialize: function(){
			return {
				addedEmailAddresses : this.addedEmailAddresses,
				addedPhoneNumbers: this.addedPhoneNumbers,
				cid : this.cid
			};
		}
	});

	SendSmartcomm.UnattachableDocsView = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm-unattachabledocs",
		initialize: function(options){
			this.unattachableDocs = options.unattachableDocs || [];
		},
		addUnattachableDoc: function(newDoc){
			this.unattachableDocs.push(newDoc);
			this.render();
		},
		serialize: function(){
			return {
				unattachableDocs: this.unattachableDocs
			};
		}
	});

	SendSmartcomm.TemplatesView = Backbone.Layout.extend({
		template: "actions/sendsmartcomm/sendsmartcomm-templates",
		events: {
			"click #template-item": "triggerGenerateDraft"
		},
		initialize: function (attrs) {
			this.smartCommModel = attrs.smartCommModel;
			this.templates = attrs.templates;
		},
		triggerGenerateDraft: function (event) { 
			// find the template within the model that matches the text of the clicked template
			var clickedTemplateName = $(event.currentTarget).text();
			this.selectedTemplate = this.templates.find(function(mTemplate) {
				return mTemplate.get("resourceName") === clickedTemplateName;
			});

			// Update the message subject to contain the template name
			this.trigger('sendEmail:emailSubjectView:insertSubjectText', clickedTemplateName);

			this.generateDraft();
		},
		generateDraft: function () {
			var self = this;

			var generateDraftTemplateOCO = this.createDraftXMLString(false);

			var bodyOCO = { 
				"projectId": this.smartCommModel.projectId, // project id in the url of the project
				"batchConfigResId": this.smartCommModel.batchConfigResId, // template selector script resource id
				"transactionData": generateDraftTemplateOCO
			};

			// add data to action if using extranet link config is checked
			if (this.smartCommModel.config.get("smartCommUseExtranet")) {
				this.smartCommModel.action.get("parameters").smartCommDoubleGenerate = {};
				
				var generateDraftTemplateEmail = this.createDraftXMLString(true);

				var bodyEmail = JSON.parse(JSON.stringify(bodyOCO));
				bodyEmail.transactionData = generateDraftTemplateEmail;

				// put the data on the action
				this.smartCommModel.action.get("parameters").smartCommDoubleGenerate.requestBody = bodyEmail;
			}

			var generateDraftOCUrl = "smartcomm/generateDraft";
			var generateDraftUrl = app.serviceUrlRoot + "/" + generateDraftOCUrl + "?includeDocumentData=true";

			// ajax request to OC to generate the draft and return the draft string for the ThunderheadEditor
			Backbone.ajax({
				context: self,
				type: "POST",
				url: generateDraftUrl,
				data: JSON.stringify(bodyOCO),
				contentType: "application/json",
				success: function(response) {
					window.ThunderheadEditor.loadString(response.data);
				}
			});
		},
		createDraftXMLString: function(useExtranet) {
			var folderProperties = app.context.container.get("properties");
			var formattedDate = "";
			
			// hard coded because the data requires a root property
			var requiredFields = {};

			// update the required fields with the data from OC
			_.each(this.smartCommModel.smartCommAttrs, function(attr){
				if (attr.attrName.search("Date") !== -1) { // this field is a date
					var lossDate = new Date(folderProperties[attr.attrValue]);
					formattedDate = (lossDate.getMonth() + 1) + "/" + lossDate.getDate() + "/" + lossDate.getFullYear();
					requiredFields[attr.attrValue] = formattedDate;
					formattedDate = "";
				}
				else {
					requiredFields[attr.attrValue] = folderProperties[attr.attrValue];
				}
			});
			requiredFields.templateId = this.selectedTemplate.get("resourceId");

			if (useExtranet) {
				var workspaceId = encodeURIComponent(this.smartCommModel.action.get("parameters").objectId);
				requiredFields.extranetLink = window.location.origin + "/Extranet/#/login/" + workspaceId;
				this.smartCommModel.action.get("parameters").smartCommDoubleGenerate.extranetLink = requiredFields.extranetLink;
			}

			// builds our xml for generate draft OC Object
			var generateDraftTemplate = '<?xml version="1.0"?>\n<Data xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="document.xsd">';
			generateDraftTemplate = generateDraftTemplate + '\n<document>\n';

			_.each(Object.keys(requiredFields), function(key){
				generateDraftTemplate = generateDraftTemplate + '<' + key + '>' +
					requiredFields[key] + 
					'</' + key + '>\n';
			});
			generateDraftTemplate = generateDraftTemplate + '</document>\n</Data>';

			return generateDraftTemplate;
		},
		serialize: function () {
			if (this.templates) {
				return {
					templates: this.templates.toJSON()
				};
			}
		}
	});

	//list of object types that won't be included in the list of
	//possible email attachments (default is you can't send a note or folder as an attachment)
	var badAttachmentObjectTypes = ['Note', 'Folder'];

	actionModules.registerAction("sendSmartcomm", SendSmartcomm, {
        "actionId" : "sendSmartcomm",
      	"label" : "Send SmartComm Correspondence",
      	"icon" : "envelope"
    },
    {
    	"badAttachmentObjectTypes" : badAttachmentObjectTypes
    });
	
	actionModules.registerAction("sendSmartcomm-group", SendSmartcomm, {
        "actionId" : "sendSmartcomm-group",
      	"label" : "Send SmartComm Correspondence",
      	"icon" : "envelope"
    },
    {
    	"badAttachmentObjectTypes" : badAttachmentObjectTypes
    });

	return SendSmartcomm;

});
require(["sendsmartcomm"]);
