define(["app"], function(app) {

    var SendSmartCommUtil = {};

    /**
     * Method to add formatted OpenContentObject properties to an OpenContentObject
     * @param {Object} otc ObjectTypeConfig for this folder
     * @param {Object} attachmentOco Object representing the OpenContentObject for this content
     * @param {Array} attributesToDisplay Array of the OpenContentObject properties to display
     */
    SendSmartCommUtil.setAttributesToDisplay = function(otc, attachmentOco, attributesToDisplay) {
        // Final variable to hold the formatted attribute values that we will display for attachments.
        attachmentOco.attributesToDisplay = [];
            
        _.each(attributesToDisplay, function(attribute){
            // We should always grab the desired value, our table will be smart enough to handle empty values so no need to worry about that, we just need to format dates below to match the app configurations.
            var attrValue = attachmentOco.properties[attribute.attrValue];

            var attrDataType = otc.get('configs').where({'ocName': attachmentOco.objectType})[0].get('attrs').where({'ocName': attribute.attrValue})[0].get('dataType');
            if(attrDataType === 'date') {
                // Check that the value is not empty here.
                if( (!_.isArray(attrValue) && attrValue) || (_.isArray(attrValue) && attrValue.length) ){
                    app.context.dateService.getFormattedDate(attrValue).done(function(formattedDate){
                        attrValue = formattedDate;
                    });
                }
            }

            attachmentOco.attributesToDisplay.push(attrValue);
        });
    };

    /**
     * Method to fetch a list of OpenContentObjects.
     * @param {Object} options 
     */
    SendSmartCommUtil.fetchOcos = function (options) {
        return $.ajax({
            url: app.serviceUrlRoot + '/openContentObjects',
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(options.ids),
            global: !options.isNotGlobal,
            context: options.context,
            success: options.successCallback,
            error: options.errorCallback
        }).promise();
    };
    
    /**
     * Method to fetch a list of content sizes.
     * @param  {Object} options.context the context in which to call these callbacks in
     * @param {Boolean} options.isNotGlobal whether to show the loading backdrop while fetching the content
     * @param {Array} options.ids array of attachment ids
     * @param {Function} options.successCallback
     * @param {Function} options.errorCallback
     */
    SendSmartCommUtil.fetchContentSizeCollection = function (options) {
        return $.ajax({
            context: options.context,
            global: !options.isNotGlobal,
            url: app.serviceUrlRoot + '/content/getContentInfo',
            type: "GET",
            contentType: "application/json",
            data: {
                "ids[]": options.ids
            },
            success: options.successCallback,
            error: options.errorCallback
        }).promise();
    };

    /**
    * Fetches ocos for the attachment ids and the contentSizeCollection for these ids if shouldValidateTotalAttachmentsSize is true.
    * @param  {Array} options.ids attachment ids
    * @param  {Boolean} options.isOcoFetchGlobal whether to show the loading backdrop while fetching the ocos
    * @param  {Function} options.ocoFetchSuccessCallback the success callback for the fetchOcos call
    * @param  {Function} options.ocoFetchErrorCallback the error callback for the fetchOcos call,
    * @param  {Function} options.fetchContentSizeSuccessCallback the success callback for the fetchContentSizeCollection call
    * @param  {Function} options.fetchContentSizeErrorCallback the error callback for the fetchContentSizeCollection call
    * @param  {Function} options.attachmentDataFetchSuccessCallback the success callback to be called when all attachment data calls have resolved
    * @param  {Object} options.context the context in which to call these callbacks in
    * @param  {Backbone.Model} options.model the SendEmailCoordinator model
    */
   SendSmartCommUtil.getAttachmentData = function(options) {
       var getOcosDeferred = SendSmartCommUtil.fetchOcos({
           ids: options.ids,
           isNotGlobal: options.isOcoFetchGlobal,
           context: options.context,
           errorCallback: options.ocoFetchErrorCallback
       });

       var getAttachmentDataDeferred = getOcosDeferred;

       // fetch the attachment sizes if configured to do so
       if(options.model.shouldTrackAttachmentSize) {
           var getContentSizeDeferred = SendSmartCommUtil.fetchContentSizeCollection({
               context:  options.context,
               isNotGlobal: true,
               ids: options.ids,
               successCallback: options.fetchContentSizeSuccessCallback,
               errorCallback: options.fetchContentSizeErrorCallback
           });
           var whenCallback = _.bind(options.attachmentDataFetchSuccessCallback, options.context);
           getAttachmentDataDeferred = $.when(getOcosDeferred, getContentSizeDeferred).done(whenCallback);

           // if the getContentSize call fails (it's only implemented in Alfresco),
           // the fetchContentSizeCollection error callback will turn off shouldValidateTotalAttachmentsSize
           // then render normally when the getOpenContentObjects call resolves
           getContentSizeDeferred.fail(function() {
               getOcosDeferred.done(options.ocoFetchSuccessCallback);
           });
       } else {
           getOcosDeferred.done(options.ocoFetchSuccessCallback);
       }

       return getAttachmentDataDeferred;
   };


  SendSmartCommUtil.GenericMessageView = Backbone.Layout.extend({
    template: "actions/sendsmartcomm/sendsmartcomm-genericmessageview",
    initialize: function (options) {
      this.mainMessage = options.mainMessage;
      this.ordered = options.ordered ? options.ordered : false; 
      this.messages = options.messages;
    },
    serialize: function () {
      return {
        mainMessage: this.mainMessage ,
        ordered: this.ordered, 
        messages: this.messages
      };
    }
  });

  return SendSmartCommUtil;
});