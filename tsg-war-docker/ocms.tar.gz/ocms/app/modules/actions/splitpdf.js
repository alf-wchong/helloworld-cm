//Advancedsearch module
define("splitpdf",[
	//Application
	"app",
    "modules/common/tossacross",
	"modules/actions/actionmodules",
    "modules/formsupport",
    "oc",
    "modules/common/spinner",
    "handlebars"
],

function(app, TossAcross, actionModules, Formsupport, OC, HPISpinner, Handlebars) {

    var SplitPDF = {};

    SplitPDF.Section = Backbone.Model.extend({
        initialize: function(options){
            this.pageRange = options && options.pageRange ? options.pageRange : '';
            this.oco = options && options.oco ? options.oco : {};
            
            // Corresponds to whether the section in question is being edited, in which case we want to disable the delete button
            this.disabled = false;
        }
    });

    SplitPDF.Sections = Backbone.Collection.extend({
        model: SplitPDF.Section
    });
	
    // Container for form support - modeled after bulkupload
    SplitPDF.FormView = Backbone.Layout.extend({
        template: "actions/splitpdf/fs-template",
        initialize: function() {
            // we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
            // on the bulk properties page)
            var defaults = {
                properties: {},
                enableRequired: true
            };

            var opts = this.options = _.extend(defaults, this.options);

            // this properties view model is what form support uses to put its controls on and other functions
            var propertiesViewModel = this.options.propertiesViewModel = {};

            // init form support - we only want atCreation attributes to show up
            Formsupport.tsgFormSupport(propertiesViewModel, 
                { 
                    'isCreate': true, 
                    'enableRequired': opts.enableRequired,
                    'formName': opts.formName 
                }
            );
            
            // set the form control properties once the controls have finished building
            propertiesViewModel.controls.subscribe(function() {
                // set our initial values once the controls have built
                propertiesViewModel.setValues(opts.properties);
            });

            // emit an event whenever the form's validity changes
            propertiesViewModel.isValid.subscribe(function(isValid) {
                app.trigger('splitpdf:formIsValid', {isValid: isValid, 'externalFormValidationMessage' : propertiesViewModel.externalFormMessage, showExternal: propertiesViewModel.showExternalValidityMessage()});
            });

            // set the object type which will trigger the controls to be generated
            propertiesViewModel.objectType(opts.objectType);
        },
        afterRender: function() {
            // form support uses knockout so let's apply those bindings
            kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
        },
        getValues: function() {
            return this.options.propertiesViewModel.getValues();
        },
        isValid: function() {
            return this.options.propertiesViewModel.isValid();
        },
        serialize: function() {
            return {
                objectType: this.options.objectType,
                // whether or not we're on the bulk properties page - used to display user instructions about what happens
                // with these bulk properties
                bulkProperties: this.options.bulkProperties,
                // only used if we're not in bulk properties page - to display the original document name of the document
                // currently being edited
                title: this.options.title
            };
        }
    });

    SplitPDF.View = Backbone.Layout.extend({
        template: "actions/splitpdf/splitpdf",
        events: {
            'click ul#splitpdf-tracDropdownList.dropdown-menu li a': 'getObjectTypesForTrac',
            'click ul#splitpdf-objectTypeDropdownList.dropdown-menu li a': 'setObjectType',
            'click button.add-btn': 'addSection',
            'click a.remove-btn': 'removeSection'
        },
        initialize: function(){
            this.selectedSplitsView = new SplitPDF.SelectedSplitsView({
                "action": this.action
            });
            this.setView('#splitpdf-selected-splits-outlet', this.selectedSplitsView);

            this.pageRangeView = new SplitPDF.PageRangeView();

            this.setView('#splitpdf-page-range-outlet', this.pageRangeView);

            this.listenTo(app, "selectedSplitsView:showResults", function(successList, errorList, message) {
                this.showResults = true;

               
                this.setView("#splitpdf-results-outlet", new SplitPDF.Results({
                    successList: successList,
                    errorList: errorList,
                    message: message
                })).render();

                // possible alternative to this.removeView("#splitpdf-selected-splits-outlet") error
                /*this.selectedSplitsView.undelegateEvents();
                this.$el.removeData().unbind();
                this.selectedSplitsView.$el.remove();
                Backbone.View.prototype.remove.call(this.selectedSplitsView);*/
                //this.removeView("#splitpdf-selected-splits-outlet");
                this.removeView("#splitpdf-fs-outlet");
                this.removeView("#splitpdf-page-range-outlet");
                this.render();
            });

            this.listenTo(app, "SplitPDF:previewRange", function(pageRange) {
                var objectId = this.action.get("parameters").objectId;

                //Opens the document in a new tab for the user to preview the document before/after selecting it
                window.open(app.serviceUrlRoot + "/content/getPDFSection?id=" + objectId + "&range=" + pageRange);  
            });

            // key is object type and value is the corrsponding form config
            this.tracToFormConfigMap = this.options.config.attributes.tracsToForm;

            // configured option to inherit folder properties
            this.inheritFolderAttributes = this.options.config.attributes.inheritFolderAttributes;

            this.tracs = [];
            this.availableObjectTypes = [];
            //put the trac names from the config onto the array that contains all the tracs
            _.each(this.tracToFormConfigMap,function(object){
                this.tracs.push(object.trac);
            }, this);

            this.isValidForm = false;
            this.isValidRange = false;
            this.sections = new SplitPDF.Sections();
            this.numSections = this.sections.size();
            this.pageRange = "";
            this.showTable = false;
            this.update = false;
            this.showResults = false;
            this.selectedTrac = this.tracs[0];

            this.getObjectTypesForTrac();
            
            // Gets called when the form changes validity or the page range is updated,
            // compares the two, then determines the overall add button validity
            this.listenTo(app, 'splitpdf:formIsValid', function(validityObj){
                // Refresh page range (pull from form)               
                this.isValidForm = validityObj.isValid;
                app.trigger('splitpdf:enableAdd');
            }, this);

            // for verifying if page range is valid
            this.listenTo(app, 'splitpdf:rangeIsValid', function(isValid) {
                this.isValidRange = isValid;
                app.trigger('splitpdf:enableAdd');
            }, this);

            // decides whether add button is enabled
            this.listenTo(app, 'splitpdf:enableAdd', function() {
                if (this.isValidForm && this.isValidRange) {
                    this.$("#splitpdf-add-section-btn").prop('disabled', false);
                } else {
                    this.$("#splitpdf-add-section-btn").prop('disabled', true);
                }
            }, this);

            /* U P D A T E  S P L I T */
            this.listenTo(app, "selectedSplitsView:updateSplit", function(model) {
                var objectType = model.get('oco').objectType;
                var formName = model.get('oco').formName;

                // defaults to true since values are valid on add/previous update
                this.isValidRange = true;
                this.isValidForm = true;
                app.trigger('splitpdf:enableAdd');

                // Populate form support with object to update's values
                this._generateFormSupport(model.get("oco").properties, 'test', objectType, formName);

                // Set page range
                this.pageRangeView.setPageRange(model.get("pageRange"));
                
                // Set trac and object type
                this.selectedObjectTypeLabel = model.get('oco').objectTypeLabel;
                this.selectedObjectTypeValue = model.get('oco').objectType;
                this.selectedTrac = model.get('oco').trac;

                // Set update to true and get the name of the objectToUpdate
                this.update = true;
                var formValues = this.getView("#splitpdf-fs-outlet").getValues();
                this.objectToUpdate = formValues.objectName;
                this.objectName = this.getView("#splitpdf-fs-outlet").properties.objectName;
                this.render();
            });
        },
        getObjectTypesForTrac: function(evt){
            this.availableObjectTypes = [];
            var self = this;
            var trac = this.selectedTrac;
            if (evt) {
                trac = this.$(evt.currentTarget).text();
                this.selectedTrac = this.$(evt.currentTarget).text();
            }
            //find the selected trac in the array of configured tracs
            var formFromTrac = _.find(this.tracToFormConfigMap, function(object) {
                return object.trac === trac;
            });
            
            var formName;
            //if the trac is om the configured trac array, grab the corresponding form
            if(formFromTrac) {
                formName = this.selectedFormName = formFromTrac.form;
            }

            var formConfigTypes = [];
            var objectTypesDeferred = $.Deferred();

            // check if type returned by form is a container
            app.context.configService.getAdminOTC(function(OTC) {
                app.context.configService.getFormConfig(formName, function(formConfig) {
                    formConfig.get("configuredTypes").each(function(type) {
                        var typeModel = OTC.get("configs").where({ocName: type.get("ocName")})[0];
                        // add object type if it is not a container
                        if (typeModel.get("isContainer") === "false") {   
                            formConfigTypes.push(type.get("ocName"));
                        }
                    });

                    var deferredLabels = [];
                    _.each(formConfigTypes, function(item) {
                        var deferredLabel = $.Deferred();
                        deferredLabels.push(deferredLabel);
                        app.context.configService.getLabels(item).done(function(label) {
                            var objectType = {
                                'label': label,
                                'value': item
                            };
                            self.availableObjectTypes.push(objectType);
                            deferredLabel.resolve(objectType);
                        }); 
                    });
                    
                    $.when(null, deferredLabels).done(function(labels){
                        objectTypesDeferred.resolve(formConfig);
                    });
                }); // end getFormConfig
            }); // end getAdminOTC
            $.when(objectTypesDeferred).done(function(){
                //blank out the previously selected object type - trac has changed
                self.selectedObjectTypeLabel = undefined;
                self.selectedObjectTypeValue = undefined;
                //clear out form support form
                self.removeView("#splitpdf-fs-outlet");
                self.pageRangeView.isVisible = false;
                self.render();
            });
        },
        setObjectType: function(evt){
            if (evt) {
                this.selectedObjectTypeLabel = this.$(evt.currentTarget).text();
                this.selectedObjectTypeValue = this.$(evt.currentTarget).attr('value');
            } else { //first is default
                this.selectedObjectTypeLabel = this.availableObjectTypes[0].label;
                this.selectedObjectTypeValue = this.availableObjectTypes[0].value;
            }
            this._refreshFormSupport();
            this.pageRangeView.isVisible = true;
            this.pageRangeView.render();
            this.render();
        },
        addSection: function(evt){
            var formValues = this.getView("#splitpdf-fs-outlet").getValues();

            // build up oco
            var oco = {
                objectName: formValues.objectName,
                properties: formValues,
                objectType: this.selectedObjectTypeValue,
                objectTypeLabel: this.selectedObjectTypeLabel,
                formName: this.selectedFormName,
                trac: this.selectedTrac
            };
            if (this.update) {
                this.selectedSplitsView.addSection(oco, this.pageRangeView.pageRange, this.objectToUpdate);
                this.update = false;
            } else {
                this.selectedSplitsView.addSection(oco, this.pageRangeView.pageRange, null);
            }
            this._refreshFormSupport();
            this.pageRangeView.clearPageRange();
            this.render();
        },
        removeSection: function(evt) {
            app.trigger('selectedsplitsview:remove', this.objectName);
            this._refreshFormSupport();
            this.pageRangeView.clearPageRange();
            this.update = false;
            this.render();
        },
        _refreshFormSupport: function() {
            var self = this;
            this.isValidRange = false;
            this.isValidForm = false;
            if(this.inheritFolderAttributes === "true") {
                // we need to use the getPropsToInherit function from the options passed in and not the private
                // method because if a client extends / overrides this method we want to use their custom
                // implementation
                this._getPropsToInherit(this.selectedObjectTypeValue, this.selectedFormName).done(function(propsToInherit) {
                        // now we have our properties with the the correct object name so let's generate form support
                        self._generateFormSupport(propsToInherit, 'test', self.selectedObjectTypeValue, self.selectedFormName);
                });
            } else {
                // create form support view
                var properties = {};
                self._generateFormSupport(properties, 'test', self.selectedObjectTypeValue, self.selectedFormName);
            }
        },
        // helper function to generate the oco for the slected object type
        _generateFormSupport: function(properties, title, objectType, formName) {
            // generate our formsupport container view
            // set and render our formsupport view
            this.setView("#splitpdf-fs-outlet", new SplitPDF.FormView({
                'properties': properties,
                'objectType': objectType,
                'title': title,
                'enableRequired': true,
                'formName': formName
            })).render();
        },
        _getPropsToInherit: function(objectType, formName) {
            var deferred = $.Deferred();
            var propsToInherit = {};
            // each time the objectType changes, we'll want to get the parent folder properties, 
            // strip out any folder specific attributes, and extend it across the document otc
            app.context.configService.getFormTypeConfig(formName, objectType, function(config) {
                
                var containerProps = app.context.container.get("properties");
                // if the propMap was not set for some reason.
                if(!containerProps){
                    app.context.container.fetch({
                        success: function(fetchedResult) {
                            containerProps = fetchedResult.get("properties");
                        },
                        async: false,
                        global: false
                    });
                }
                var otcProps = config.get('configuredAttrsPri').pluck('ocName');

                var rejectProps = ['objectName', 'document_type', 'creationDate', 'modifiedDate'];

                otcProps = _.reject(otcProps, function(prop){
                    return _.contains(rejectProps, prop);
                });

                // omit any attributes that are labelled as NONE and return the ocNames
                var omittedAttributes = new Backbone.Collection(config.get('configuredAttrsPri').where({'controlType': 'NONE'})).pluck('ocName');
                otcProps = _.reject(otcProps, function(prop){
                    return _.contains(omittedAttributes, prop);
                });

                var containerKeys = [];
                // get only ocNames from container
                _.each(containerProps, function(value, key){
                    containerKeys.push(key);
                });
                // only extend properties whitelisted by the document's otc
                var whiteListedProps = _.intersection(otcProps, containerKeys);

                // ok list built, populate the values
                _.each(whiteListedProps, function(ocName) {
                    // if the folder actually has a value that we can inherit, let's add it to the list of values to inherit
                    if(containerProps[ocName]) {
                        propsToInherit[ocName] = containerProps[ocName];    
                    }
                });

                deferred.resolve(propsToInherit);
            }, app.context.configName());
            return deferred.promise();
        },
        afterRender: function(){
            var caret = ' <span class="caret"></span>';

            if (this.selectedTrac) {
                if (this.tracs.length > 1) {
                    this.$('#splitpdf-tracDropdown').html(this.selectedTrac + caret);
                } else {
                    this.$('#splitpdf-tracDropdown').html(this.selectedTrac);
                    this.$('#splitpdf-tracDropdownList').hide();
                }
            } else {
                this.$('#splitpdf-tracDropdown').html('Trac' + caret);
            }

            if (this.selectedObjectTypeLabel) {
                if (this.availableObjectTypes.length > 1) {
                    this.$('#splitpdf-objectTypeDropdown').html(this.selectedObjectTypeLabel + caret);
                } else {
                    this.$('#splitpdf-objectTypeDropdown').html(this.selectedObjectTypeLabel);
                    this.$('#splitpdf-objectTypeDropdownList').hide();
                }
            } else if (this.availableObjectTypes[0]) {
                if (this.availableObjectTypes.length > 1) {
                    this.$('#splitpdf-objectTypeDropdown').html(this.availableObjectTypes[0].label + caret);
                } else {
                    this.$('#splitpdf-objectTypeDropdown').html(this.availableObjectTypes[0].label);
                    this.$('#splitpdf-objectTypeDropdownList').hide();
                }
                this.setObjectType();
            } else {
                this.$('#splitpdf-objectTypeDropdown').html('Object Type' + caret);
            }
            // always check after render if add/update should be enabled
            app.trigger('splitpdf:enableAdd');
        },
        serialize: function(){
            return {
                tracs: this.tracs,
                objectTypes: this.availableObjectTypes,
                isValid: this.isValid,
                update: this.update,
                showResults: this.showResults
            };
        }
    });

    SplitPDF.PageRangeView = Backbone.Layout.extend({
        template: "actions/splitpdf/pagerange",
        events: {
            'keyup #page-range': 'getPageRange',
            'click #previewBtn': 'previewPageRange'
        },
        initialize: function() {
            this.pageRange = '';
            this.isVisible = false;

            // determine if preview is available
            this.listenTo(app, 'pagerange:rangeIsValid', function(isValid) {
                this.$('#previewBtn').prop('disabled', !isValid);
            }, this);
        },
        getPageRange: function(event) {
            this.pageRange = this.$('#page-range').attr('value');
            var pattern = /^[0-9|,|-]+$/;
            this.pageRange = this.pageRange.replace(/\s+/g, "");
            var isValid = pattern.test(this.pageRange);

            // enable/disable preview + add buttons
            app.trigger('pagerange:rangeIsValid', isValid);
            app.trigger('splitpdf:rangeIsValid', isValid);
        }, 
        setPageRange: function(pageRange) {
            this.pageRange = pageRange;
            var pattern = /^[0-9|,|-]+$/;
            this.pageRange = this.pageRange.replace(/\s+/g, "");
            var isValid = pattern.test(this.pageRange);
            app.trigger('pagerange:rangeIsValid', isValid);
            app.trigger('splitpdf:rangeIsValid', isValid);
            this.render();
        },
        clearPageRange: function() {
            this.pageRange = '';
            this.render();
        },
        previewPageRange: function() {
            app.trigger("SplitPDF:previewRange", this.pageRange);
        },
        afterRender: function() {
            if(this.pageRange){
                this.$('#page-range').val(this.pageRange);
                var pattern = /^[0-9|,|-]+$/;
                var isValid = pattern.test(this.pageRange);
                app.trigger('pagerange:rangeIsValid', isValid);
                app.trigger('splitpdf:rangeIsValid', isValid);
            } else {
                // disable preview
                this.$('#previewBtn').prop('disabled', true);
            }
        },
        serialize: function() {
            return {
                pageRange: this.pageRange,
                isVisible: this.isVisible
            };
        }

    });
    
    SplitPDF.SelectedSplitsView = Backbone.Layout.extend({
        template: "actions/splitpdf/selectedpdfsplits",
        events: {
            'click a.btn-danger' : 'deleteSection',
            'click a.btn-primary' : 'previewSection',
            'click button.finish-and-submit-btn' : 'saveAndSplit',
            'click .savedsearch-result-link': 'updateSelectedSplit'
        },
        initialize: function() {
            // Selected pdfs
            this.sections = new SplitPDF.Sections();

            // Whether or not the table should be shown (number of selected splits > 0) 
            this.showTable = false;

            this.successList = [];
            this.errorList = [];
            this.errorMessage = undefined;

            this.listenTo(app, 'selectedsplitsview:remove', function(objectName) {
                // find target model
                var modelToRemove = this.sections.find(function(model) {
                    return model.get('oco').objectName === objectName;
                });

                // remove the target model
                this.sections.remove(modelToRemove);

                // remove table if no sections left
                if(this.sections.size() === 0) {
                    this.showTable = false;
                }

                this.render();
            });
        }, 
        addSection: function(oco, pageRange, overwriteObjName) {
            var section = new SplitPDF.Section({pageRange: pageRange, oco: oco});

            if(overwriteObjName !== null) {
                var updateModel = this.sections.find(function(model) {
                    return model.get('oco').objectName === overwriteObjName;
                 });       
               
                updateModel.set("pageRange", pageRange);
                updateModel.set("oco", oco);
                updateModel.set("disabled", false);
            }
            else {
                this.sections.add(section);
            }
            
            if(this.sections.size() === 1) {
                this.showTable = true;
            }
            
            this.render();
        },
        deleteSection: function(event) {
            var targetObjectName;
            if (event) {
                // Get the row that corresponds to the clicked delete button
                var row = this.$(event.currentTarget)[0].parentElement.parentElement;

                // Get the first child of the row, which will be the objectName of the split to delete
                targetObjectName = $(row).closest('tr').find('td:eq(0)').text();
            } else {
                // var formValues = this.getView("#splitpdf-fs-outlet").getValues();
                targetObjectName = this.getView('#splitpdf-fs-outlet').properties.objectName;
            }

            // Find the target model in the collection
            var modelToRemove = this.sections.find(function(model) {
                return model.get('oco').objectName === targetObjectName;
            });

            // Remove the target model
            this.sections.remove(modelToRemove);

            // If we no longer have sections, don't show the table
            if(this.sections.size() === 0) {
                this.showTable = false;
            }
            // Call render
            this.render();
        },
        previewSection: function(event) {
            // Get the row that corresponds to the clicked delete button
            var row = this.$(event.currentTarget)[0].parentElement.parentElement;

            // Get the first child of the row, which will be the objectName of the split to delete
            var targetObjectName = $(row).closest('tr').find('td:eq(0)').text();

            // Find the target model in the collection
            var previewTarget = this.sections.find(function(model) {
                return model.get('oco').objectName === targetObjectName;
            });

            app.trigger("SplitPDF:previewRange", previewTarget.get('pageRange'));

        },

        updateSelectedSplit: function(evt){
            evt.preventDefault();

            // Check to see if there is a model we were updating previously
            var previousUpdate = this.sections.find(function(model) {
                return model.get('disabled') === true;
            });
            // If we were previously updating a model, enable the buttons on that row
            if(previousUpdate !== undefined) {
                previousUpdate.attributes.disabled = false;
            }
            var targetObjectName = evt.srcElement.firstChild.nodeValue;
            var targetModel = this.sections.find(function(model) {
                return model.get('oco').objectName === targetObjectName;
            });
            targetModel.attributes.disabled = true;
            app.trigger("selectedSplitsView:updateSplit", targetModel);
        },
        saveAndSplit: function(evt){
            evt.preventDefault();
            // Disable submit button and start spinner
            this.$('#submitSections').prop('disabled', true);
            this.spinner = HPISpinner.createSpinner({
                color: '#666'
            }, this.$el.find(".progressSpinner")[0]);

            // prefix all props
            _.each(this.sections.models, function(section) {
                var prefixedProps = app.context.util.prefixProperties(section.get("oco").properties);
                section.get("oco").properties = prefixedProps;
            });

            this.options.action.get("parameters").splits = this.sections;
            
            var self = this;
            // the deferred to return when the ajax request for uploading this file is completed
            var deferred = $.Deferred();
            $.ajax({
                type: "POST",
                contentType: "application/json",
                url: app.serviceUrlRoot + "/action/execute",
                data: JSON.stringify({
                    name: "splitPdf",
                    parameters: this.options.action.get("parameters")
                }),
                success: function(data) {
                    // Returns a map of object ids keyed by names
                    _.each(data.result, function(metadata, objectName) {
                        var objectId = null;
                        var pageRange = null;
                        if (metadata) {
                            if (metadata.objectId) {
                                objectId = metadata.objectId;
                            }
                            if (metadata.pageRange) {
                                pageRange = metadata.pageRange;
                            }
                        }
                        
                        if (objectId !== null) {
                            var successfulPageRange = {
                                // want the objectId so that if the user only uploaded one file we can refresh the stage
                                // with that file ID when they close this action
                                objectId: objectId,
                                // want the filename of the uploaded doc for display purposes
                                objectName: objectName,
                                // URL to the stage so the user can click on the document uploaded to view it in the stage
                                url: app.root + "StageSimple/" + objectId,
                                // page range for display on links
                                pageRange: pageRange

                            };
                            self.successList.push(successfulPageRange);
                        } else {
                            self.errorList.push({objectName: objectName, pageRange : pageRange});
                        }
                    });

                },
                error: function(jqXHR, textStatus, errorThrown) {
                    self.errorMessage  = errorThrown;
                }
            }).always(function() {
                self.$('#submitSections').prop('disabled', false);
                if(self.spinner){
                    HPISpinner.destroySpinner(self.spinner);
                }
                // we're done with our ajax request for this file so resolve our deferred
                deferred.resolve();
                app.trigger("selectedSplitsView:showResults", self.successList, self.errorList, self.errorMessage);
            });            

        },
        serialize: function() {
            return {
                showTable: this.showTable,
                selectedSplits: this.sections.models
            };
        }

    });

    SplitPDF.Results = Backbone.Layout.extend({

        template: "actions/splitpdf/splitpdf-results",

        initialize: function(options) {
            this.successList = options.successList;
            this.errorList = options.errorList;
            this.message = options.message;
        },

        serialize: function() {
            return {
                successList: this.successList,
                errorList: this.errorList,
                message: this.message
            };
        }
    });

    //############# START OF ADMIN CODE ######################

	SplitPDF.Model = Backbone.Model.extend({
		defaults: {
			properties: {
                //These default properties will get overridden by the configured properties
                tracName: ""
			}
		}
	});

    //Collection of selected document models
    SplitPDF.Collection = Backbone.Collection.extend({
        model: SplitPDF.Model
    });

    SplitPDF.CustomConfigView = Backbone.Layout.extend({
		template:"hpiadmin/actions/customconfig/splitpdfconfig",
		initialize: function(){
			
        },
        afterRender: function () {

            var self = this;

            // these are available tracs for the user to choose fro
            self.availableTracs = ko.observableArray([]);
            var viewModel = self.options.viewModel;
            var model = viewModel.model();

            // whether or not the splits will inherit folder properties
            viewModel.inheritFolderAttributes = new kb.observable(model, "inheritFolderAttributes");
            self.availableTracCollection = new SplitPDF.Collection();
            
            self.selectedTracCollection = new SplitPDF.Collection();
            viewModel.tracsToForm = new kb.observable(model,{key: "tracsToForm"});

            self.tracsToFormArray = viewModel.tracsToForm();
            self.tracViews = [];

            if(!self.tracsToFormArray){
                 self.tracsToFormArray = [];
            }else{
                //for each trac that was previously configured get the tracname and corresponding form
                //and create a new form select view for each and create a change event to keep track
                //when a form is changed.
                _.each(self.tracsToFormArray, function(object){
                    var options = {};
                    options.tracName = object.trac;
                    options.formName = object.form;
                    var view = new SplitPDF.formSelectView(options);
                    self.listenTo(view,"changeEvent",function(trac,formName){
                        //When a form is changed for a trac, create an object with the trac and form
                        var tracToFormObj = {};
                        tracToFormObj.trac = trac;
                        tracToFormObj.form = formName;
                        //Find if the trac is on the current array of configured tracs
                        var tracIndex = self.tracsToFormArray.findIndex(function(object) {
                            return  object.trac === trac;
                        });
                        //if the trac is on the array, replace it with the updated object
                        //if not, push it on the array.
                        if(tracIndex >= 0) {
                            self.tracsToFormArray[tracIndex] = tracToFormObj;
                        } else {
                            self.tracsToFormArray.push(tracToFormObj);
                        } 
                        //update array on the observable
                        viewModel.tracsToForm(self.tracsToFormArray);
                    });
                    self.tracViews.push(view);
                    $("#splitpdf-form-selection").append(view.render().el);
                });
            } 

            app.context.configService.getTracConfigs(function(data){
                _.each(data.models,function(trac){
                    // display pretty names
                    var isSelected = _.find(self.tracsToFormArray, function(object) {
                        return object.trac === trac.get("displayName");
                    });
                    //if the trac is not on the current array add it the available tracs column, if it is on the array
                    //add it to the selected tracs column
                    if (!isSelected) {
                        self.availableTracCollection.add(new SplitPDF.Model({tracName : trac.get("displayName")}));
                    } else {
                        self.selectedTracCollection.add(new SplitPDF.Model({tracName : trac.get("displayName")}));
                    }
                });

                self.tossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: false,
                    srcCollection: {
                        title: (window.localize("modules.actions.splitPDF.availableTracs")),
                        filter: true,
                        labelAttr: 'tracName',
                        collection: self.availableTracCollection
                    },
                    targetCollections: [
                        {
                            title: (window.localize("modules.actions.splitPDF.selectedTracs")),
                            labelAttr: 'tracName',
                            filter: true,
                            collection: self.selectedTracCollection
                        }
                    ]
                }); 

                self.setView('.tossacross-splitpdf', self.tossAcross).render();

                //for each trac that is added to the config get the tracname 
                //and create a new form select view for each and create a change event to keep track
                //when a form is selected/changed.
                self.selectedTracCollection.on('add', _.debounce(function(item){
                    var options = {};
                    options.tracName = item.attributes.tracName;
                    var view = new SplitPDF.formSelectView(options);
                    self.listenTo(view,"changeEvent",function(trac,formName){
                        //When a form is changed for a trac, create an object with the trac and form
                        var tracToFormObj = {};
                        tracToFormObj.trac = trac;
                        tracToFormObj.form = formName;
                        //Find if the trac is on the current array
                        var tracIndex = self.tracsToFormArray.findIndex(function(object) {
                            return  object.trac === trac;
                        });
                        //if the trac is on the array, replace it with the updated object
                        //if not, push it on the array.
                        if(tracIndex >= 0) {
                            self.tracsToFormArray[tracIndex] = tracToFormObj;
                        } else {
                            self.tracsToFormArray.push(tracToFormObj);
                        } 
                        //update array on the observable
                        viewModel.tracsToForm(self.tracsToFormArray);
                    });
                    var index = self.tracViews.findIndex(function(tracView) {
                        return view.tracName === tracView.tracName;
                    });
                    if(index === -1) {
                        self.tracViews.push(view);
                        $("#splitpdf-form-selection").append(view.render().el);
                    }
                },100));

                //here we wanna remove it.
                self.availableTracCollection.on('add', _.debounce(function(item){
                    _.each(self.tracViews,function(view,index){
                        if(item.attributes.tracName === view.options.tracName){
                            //find the index of the object in the array that needs to be removed
                            var indexToDelete = self.tracsToFormArray.findIndex(function(object) {
                                return  object.trac === view.options.tracName;
                            });
                            self.tracsToFormArray.splice(indexToDelete, 1);
                            viewModel.tracsToForm(self.tracsToFormArray);
                            self.tracViews[index].remove();
                            self.tracViews.splice(index, 1);
                        }
                    });
                },100));
                
            });

            kb.applyBindings(viewModel, this.$el[0]);
        }
    });



    SplitPDF.formSelectView = Backbone.Layout.extend({
        template:"hpiadmin/actions/customconfig/splitpdfformselect",
        afterRender: function(){
            var self = this;
            if(this.options.formName){
                self.$(self.$(".btn")[0]).text(this.options.formName);
                self.$(self.$(".btn")[0]).val(this.options.formName);
            }
            self.$("#tracsname").html(this.options.tracName);
            app.context.configService.getFormConfigNames(function(formConfigNames) {
                _.each(formConfigNames,function(name){
                    self.$("ul").append("<li class='null'><a>"+name+"</a></li>");
                });

                self.$(".dropdown-menu li").click(function(){
                    var value = $(this).children("a").text();
                    value = Handlebars.Utils.escapeExpression(value);
                    self.trigger("changeEvent",self.options.tracName,value);
                    self.$(self.$(".btn")[0]).text(value);
                    self.$(self.$(".btn")[0]).val(value);
                });
            });

            
        }
    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("splitPdf", SplitPDF, {
        "actionId" : "splitPdf",
        "label" : "Split PDF",
        "icon" : "scissors",
	    "handler" : "rightSideActionHandler",
	    "paneSize" : "rightPane"
    });

    return SplitPDF;
});
require(["splitpdf"]);