// Export Search Results [Controlled Print Audit] to PDF action
define("exportsearchresultstopdf", [
    "app",
    "moment",
    "momentJDate",
    "modules/actions/actionmodules",
    "modules/common/downloadutils",
    "knockback",
    "jqueryDownload"
],

function (app, moment, momentJDate, actionModules, downloadUtils, kb) {
    "use strict";

    var ExportSearchResultsToPDF = {};

    ExportSearchResultsToPDF.ViewModel = function (action, myHandler) {
        this.action = action;
        var self = this;
     
        self.toggleLoader = function (bool) {
            app[myHandler].trigger("loading", bool);
        };

        self.callback = function () {
            self.toggleLoader(false);
            app[myHandler].trigger("showMessage", window.localize("modules.actions.exportSearchResultsToPDF.theResults"));
        };

        self.errorCallback = function () {
            self.toggleLoader(false);
            app[myHandler].trigger("showError", window.localize("modules.actions.exportSearchResultsToPDF.failedResults"));
        };

        self.exportSearchResultsToPDF = function (searchConfigName) {
            var dt = moment().format("YYYY-MM-DD");
            action.get("parameters").fileName = 'Search-Results' + "_" + dt + ".pdf";
            self.toggleLoader(true);

            app.context.configService.getSearchConfigByName(searchConfigName, function (searchConfig) {
                var fieldLabels = [];
                var tableHeaders = {};
                // For now we assume we're in tableView, since exportSearchResults currently on works there.
                var resultsTableConfig = searchConfig.get("resultsConfig").get("resultsTableConfig");
                var typesResultCollection = resultsTableConfig.get("types");
                _.each(action.get('parameters').objectTypes, function (currentType) {
                    var currentTypeResultsConfig = typesResultCollection.findWhere({
                        objectType: currentType
                    });

                    //people can configure the application wrong and not have a type setup in the search config
                    if (currentTypeResultsConfig) {
                        // Put all fields (visible and invisible) onto sort fields
                        action.get("parameters").sortFields = _.map(currentTypeResultsConfig.get("fields"), function (ocConfig) {
                            return ocConfig.ocName;
                        });
                        app.context.configService.getAdminTypeConfig(currentType, function (objectTypeConfig) {
                            var attributeCollection = objectTypeConfig.get("attrs");

                            _.each(action.get("parameters").sortFields, function (fieldOcName) {

                                var attributeModel = attributeCollection.findWhere({
                                    ocName: fieldOcName
                                });

                                var fieldLabel = attributeModel.get("label");
                                fieldLabels.push(fieldLabel);
                                tableHeaders[fieldOcName] = fieldLabel;
                            });
                            action.get("parameters").fieldLabels = fieldLabels;
                            action.get("parameters").tableHeaders = tableHeaders;
                        });
                    } else {
                        app.log.warn(window.localize("modules.actions.exportSearchResultsToPDF.noTypeFoundInTableViewConfig"));
                    }
                });

                //this check will pass if all of the types searched on or viewed in view all documents are somehow not configured in the search
                //config - we will want the action to alert the user that the excel will not download
                if (_.isEmpty(fieldLabels) || _.isEmpty(tableHeaders)) {
                    self.toggleLoader(false);
                    app[myHandler].trigger("showError", window.localize("modules.actions.exportSearchResultsToPDF.noTypeFoundInTableViewConfig"));
                } else {
                    // Since the getting of configs is asynchronous, we launch our action within the callback.
                    downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, self.callback, self.errorCallback);
                }
            });
        };

        return self;
    };

    ExportSearchResultsToPDF.View = Backbone.Layout.extend({
        template: "actions/exportsearchresultstopdf",
        initialize: function () {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.config = this.options.config;
            this.viewModel = ExportSearchResultsToPDF.ViewModel(this.action, this.myHandler, this.config);
        },
        afterRender: function () {
            kb.applyBindings(this.viewModel, this.$el[0]);

            //let's get the search config by name by pulling it from the id of the current config we are working with
            //the exportSearchResults() function needs this if we have to pull all the properties off, the config will
            //ALWAYS have an _id so we don't need to null check - if no _id is present we have bigger problems 
            var searchConfigName = this.config.get("_id").split(".")[1];
            this.viewModel.exportSearchResultsToPDF(searchConfigName);
        },
        serialize: function () {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal: modal,
                rightSide: rightSide
            };
        }
    });

    ExportSearchResultsToPDF.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/exportsearchresultstopdfconfig",
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    actionModules.registerAction("exportSearchResultsToPDF", ExportSearchResultsToPDF, {
        "actionId": "exportSearchResultsToPDF",
        "label": "Export Results to PDF",
        "icon": "list-alt",
    });

    return ExportSearchResultsToPDF;

});
require(["exportsearchresultstopdf"]);