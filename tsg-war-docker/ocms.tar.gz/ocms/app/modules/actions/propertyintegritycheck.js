define("propertyintegritycheck", [
	// Application.
	"app",
	"oc",
	"modules/common/ocquery",
	"module",
	"moment",
	"modules/actions/actionmodules"
],

function(app, OC, OCQuery, module, moment, actionModules) {
	"use strict";

	var action = {};
	var actionEvent = _.extend({}, Backbone.Events);

	function ViewModel(action, myHandler, config) {
		var self = this;
		self.firstError = true;
		
		self.onSubmit = function(){
			app[myHandler].trigger("hide");
		};
		self.checkChildDocs = function(attrMap){
			
			var allowedEmptyValue = false;
			_.each(self.folderOCO.get("children").models,function(child){
			//for each child, lets look up the properties from the config

				//The document does have the attribute, lets update our map
				if(!attrMap.label){
					//lets set the label for displaying if we don't have it yet
					app.context.configService.getLabels(app.context.container.get("objectType"), attrMap.name).done(function(label){
						//We are using this service to grab the label of the current attr. This is used for display
						attrMap.label = label;
					});	
				}
				//Don't want to show any hidden folders (folder that start with a period).
				if(child.get("properties").objectName.charAt(0) === '.'){
					return;
				}
				if(!child.get("properties")[attrMap.name]){	
					//if the doc attribute is empty or null, lets handle seperately
					if(!self.folderOCO.get("properties")[attrMap.name]){
						//if the folder and the child are empty strings, thats a pass
						attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': true});
					}else{
						//the folder isn't empty, the doc is now a pass/fail based on the config
						if(config.get("allowBlankValues") === 'false'){
							//if we aren't allowing blank values, this is a failure
							attrMap.pass = false;
							if(self.firstError){
								attrMap.firstPass = true;
								self.firstError = false;
							}
							attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': false});	
						}else{
							allowedEmptyValue = true;
							attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': true});
						}
					}					
				}else{ 
					//folderMatch will be based on whether the folderOCO value equals the childDocs value
					var folderMatch = self.folderOCO.get("properties")[attrMap.name] === child.get("properties")[attrMap.name];
					if(attrMap.type === "DatetimeBox"){			
						if(!attrMap.value){
							app.context.dateService.getFormattedDatetime([self.folderOCO.get("properties")[attrMap.name],child.get("properties")[attrMap.name]]).done(function(dates){
								attrMap.value = dates[0];
                				attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal':  dates[1], 'folderMatch': folderMatch});
							});		
                		}else{
                			app.context.dateService.getFormattedDatetime(child.get("properties")[attrMap.name]).done(function(formattedDate){
                				attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal':  formattedDate, 'folderMatch': folderMatch});
                			});
                		}	 
                	}else if(attrMap.type === "DateBox"){
            			if(!attrMap.value){
							app.context.dateService.getFormattedDate([self.folderOCO.get("properties")[attrMap.name],child.get("properties")[attrMap.name]]).done(function(dates){
								attrMap.value = dates[0];
                				attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal':  dates[1], 'folderMatch': folderMatch});
							});			
                		}else{
                			app.context.dateService.getFormattedDate(child.get("properties")[attrMap.name]).done(function(formattedDate){
                				attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal':  formattedDate, 'folderMatch': folderMatch});
                			});
                		}
					}else{
						//if not a date, handle as normal
						if(folderMatch && !_.isArray(self.folderOCO.get("properties")[attrMap.name])){
							attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': true});
						}
						else if(!folderMatch && !_.isArray(self.folderOCO.get("properties")[attrMap.name])){
							//we know we have a failure if one of the child docs attributes doesn't match the parent folders, and its not blank
							attrMap.pass = false;
							if(self.firstError){
								//if this is the first error, we are going to mark the attrMap so that we can pre-open the first error
								attrMap.firstPass = true;
								self.firstError = false;
							}	
							//if they dont match, we are putting this false flag on there
							attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': false});		
						}
						//lets handle repeating attrs and say its a match if anything matches
						else if(_.isArray(self.folderOCO.get("properties")[attrMap.name]) && _.isArray(child.get("properties")[attrMap.name])){
							var matches = _.intersection(self.folderOCO.get("properties")[attrMap.name], child.get("properties")[attrMap.name]);
							if(matches.length === self.folderOCO.get("properties")[attrMap.name].length){
								//if our intersection is just as long as the folder array, then we know we have found all folder props in the child
								attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': true});
							}else{
								attrMap.pass = false;

								if(self.firstError){
									//if this is the first error, we are going to mark the attrMap so that we can pre-open the first error
									attrMap.firstPass = true;
									self.firstError = false;
								}
								attrMap.report.push({'docName': child.get("properties").objectName, 'id': child.get("properties").objectId, 'propVal': child.get("properties")[attrMap.name], 'folderMatch': false});
							}
						}
					}	
				}
			});
			if(!attrMap.value){
				//for this attribute, lets mark down what the folder's value is if we didn't get it from a repeating value
				attrMap.value = self.folderOCO.get("properties")[attrMap.name] ? self.folderOCO.get("properties")[attrMap.name] : 'Attribute is blank';	
			}
			if(allowedEmptyValue){
				//something passed because it was empty, lets let the user know this
				attrMap.value += ' (Passed with blank values)';
			}
		};
		self.checkAttributes = function() {		
			_.each(self.attrsFromConfig,self.checkChildDocs);
			app[myHandler].trigger("loading",false);
			actionEvent.trigger('refresh',self.attrsFromConfig);
		};

		self.runAction = function() {
			app[myHandler].trigger("loading", true);


			var jqxhr = null;
			

			//lets fetch the folder properties
			var deferred = self.folderOCO.fetch();

			//lets also fetch the folders children documents
			jqxhr = self.folderOCO.getChildren();
		
			$.when(jqxhr,deferred).done(self.checkAttributes);
			
		};

		self.objectId = action.get("parameters").objectId;
		self.config = config;
		self.folderOCO = new OC.OpenContentObject({objectId: app.context.container.get("objectId")});

		//this is a folder action, so this is allowed
		self.objectType = app.context.container.get("objectType");
		app.context.configService.getFormTypeConfig(config.get("form"), self.objectType, function(formConfig) {
			if(formConfig){
				self.attrsFromConfig = _.map(formConfig.get("configuredAttrsPri").models, function(attr) {
	               	return {name: attr.get("ocName"), label: '', type: attr.get("controlType"), pass: true, value:'', report: [] };	
				});
				self.runAction();
			}else{
				self.attrsFromConfig = false;
				actionEvent.trigger('refresh',self.attrsFromConfig);
			}
		});
		
	}

	action.View = Backbone.Layout.extend({
		template: "actions/propertyintegritycheck",
		events: {
			// when the user clicks the link column of the result, we want to direct them to the stage
            "click .integrityCheck-result-link": "onResultClick",
			"click .accordion-toggle": "toggleChevron"
		},
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.config = this.options.config;
			this.viewModel = new ViewModel(this.action, this.myHandler, this.options.config);
			this.result = {};

			this.listenTo(actionEvent, 'refresh', function (results) {
				this.result = results;
				this.render();
			},this);
		},
		getLocalizations: function(){
			return module.config().localizations || {
				submitButton: 'OK',
				instructions: 'Results:'
			};
		},
		// called when a user clicks the link column of this result view
        onResultClick: function(event) {
            var self = this;

            // helper function to build the proper URL and navigate to the stage - takes the trac to navigate to as a parameter
            // and whether or not this object is a container
            var navigateToStage = function(tracToNavigateTo, isContainer) {
                // get the objectId for the model they clicked on
                var objectId = event.target.id;

                // start our url with the stage and the trac to navigate to
                var url;
                if(tracToNavigateTo){
                    url = "Stage/" + tracToNavigateTo + "/";
                    
                    // add our proper objectId onto our URL depending on the type or if this is a container or not
                    if(isContainer === "wizard") {
                        url += objectId + "|" + objectId;
                    } else if(isContainer === "true") {
                        url += objectId;
                    } else {
                        // containterID will be resolved by the stage
                        url += "|" + objectId;
                    }
                }
                else{
                    url = "StageSimple/" + objectId;
                }
                // navigate to the built URL and trigger our routing
                Backbone.history.navigate(url, { trigger: true });
            };

            // if the user has a trac to go to configured, use that trac and get the OTC from that trac
            if(self.config.get("tracResolver")) {
                app.context.configService.getAdminOTC(function(otc) {
                    // get the configuration for the type of this result
                    var currentType = otc.get("configs").findWhere({ocName : self.viewModel.objectType});

                    // navigate to the stage
                    navigateToStage(self.config.get("tracResolver"), currentType.get("isContainer"));
                });
            } else {
            
	            app.context.configService.isContainer(self.viewModel.objectType, function(isContainer) {
					navigateToStage("", isContainer);
				});
                // navigate to the stage        
            }
        },
		toggleChevron: function(event) {
			this.$(event.currentTarget.firstElementChild).toggleClass("glyphicon-chevron-up glyphicon-chevron-down");
		},
		afterRender: function(){
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
		serialize: function(){
			var self = this;
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				submitButton : self.getLocalizations().submitButton,
                instructions : self.getLocalizations().instructions,
                result: self.result ? self.result : false
			};
		}
	});

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/propertyintegritycheckconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;

			viewModel.form = kb.observable(viewModel.model(), "form");
			viewModel.allowBlankValues = kb.observable(viewModel.model(), "allowBlankValues");
			var formSubscribePlaceholder = viewModel.form();
			viewModel.potentialForms = ko.observableArray();
			app.context.configService.getFormConfigNames(function(formConfigNames) {
				viewModel.potentialForms(formConfigNames);
				//since the form value is bound from the potentialForms observable,
				//this context call will come back after the form has been gathered
				//from the config. this resets the form to the right value.
				viewModel.form(formSubscribePlaceholder);
			});
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("propertyIntegrityCheck", action, {
        "actionId" : "propertyIntegrityCheck",
        "label" : "Property Integrity Check",
        "icon" : "list-alt",
        "handler" : "rightSideActionHandler"
    });

	return action;

});
require(["propertyintegritycheck"]);