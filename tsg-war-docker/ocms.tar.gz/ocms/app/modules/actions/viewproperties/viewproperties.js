define("viewproperties", [
	// Application.
	"app",
	"modules/formsupport",
	"oc",
	"moment",
	"modules/actions/actionmodules",
	"modules/common/action",
	"modules/actions/viewproperties/readonlyviewproperties",
	"foldernotes",
	"module",
	"modules/externalEventsModule",
	"modules/hpiadmin/common/iosswitch",
	"modules/common/hpiconstants"
],

function(app, Formsupport, OC, moment, actionModules, Action, ReadOnlyViewProperties, FolderNotes, module, externalEventsModule, iOSSwitch, HPIConstants) {
	"use strict";

	var action = {};

	action.ViewModel = function(action, myHandler, config, searchResultsViewController) { 
		var self = this;

		//Enable event-listening functionality
		_.extend(this, Backbone.Events);

		self.searchResultsViewController = searchResultsViewController;

		// We want to hide the file extensions for Wizard Forms
		self.objectTypesToNotAddExtentionTo = module.config().objectTypesToNotAddExtentionTo;

		self.config = config;
		var options = {
			positionData: false, 
			enableRequired : true,
			formName: config.get("form"),
			enableAppendOnly: config.get("appendOnly")
		};
		self.metadataPropId = module.config().positionalAttribute || HPIConstants.hpiMetadataPositions;
		self.objectId = action.get("parameters").objectId;		
		self.objectType = ko.observable();
		Formsupport.tsgFormSupport(self, options);
		self.doneFetching = ko.observable(false);
		self.ocObject = new OC.OpenContentObject({ objectId : self.objectId,
												   hideFileExtensions: self.hideFileExtensions
												});
		self.ocObject.fetch({
			success: function(object) {
				
				//Populate and manage positional data if it's enabled
				self.positionalData(false);
				self.storePositionData = false;
				if (self.metadataPropId && object.get("properties")[self.metadataPropId]) {

					//This is the positional data variable used to display an icon to highlight positional data
					//On the OA iframe. Only set this when the config has positional data enabled (right hand view)
					if (self.config.get("positionDataEnabled")) {
						self.positionalData(JSON.parse(object.get("properties")[self.metadataPropId]));
					}

					//Even if not showing the icon to display data (modal view), still keep track of
					//the positional data and update it when a control value changes
					self.managedPositionalData = JSON.parse(object.get("properties")[self.metadataPropId]);
					self.storePositionData = true;
				}

				//Initialize individual control values when the controls array is built
				var controlsSub = self.controls.subscribe(function() {
					controlsSub.dispose();
					self.setValues(object.get("properties"));

					//Manage control value changes once all initialization has completed.
					if(self.storePositionData) {
						self.listenTo(self.eventManager, "fs:change", self.processControlValueChanges);
					}
				});

				self.objectType(object.get("objectType"));
				
				app.context.configService.isContainer(self.objectType(), function(isContainer) {
					self.doneFetching(true);
					action.get("parameters").isContainer = (isContainer === "true");
				});
				//check appConfig for configuration of file extensions
				app.context.configService.getApplicationConfig(function(configs) {
					self.doneFetching(true);
					action.get("parameters").hideFileExtensions = configs.get('hideFileExtensions');
				});
			}
		});

		self.processControlValueChanges = function(newValue, control) {

			//If preserve location flag is set, don't do anything
			if(control.preserveLocationData()) {
				return;
			}

			//Otherwise remove positional data from the changed attribute and control
			self.managedPositionalData = _.omit(self.managedPositionalData, control.id);
			control.showPositionData(false);
		};

		self.checkConditions = function() {
			var self = this;
			
			if(self.objectId === undefined){
				app[myHandler].trigger("showError", "ID was not provided. Please contact Administrator");
			} else {
				app[myHandler].trigger("loading", true);
			
				//check the write permissions
				var conditions = action.get("conditions");
				for(var i=0;i < conditions.length ; i+=1){
					if(conditions[i].name === "condition-write-conditionevaluator"){
						if(conditions[i].status !== "valid"){
							self.readOnly(true);
						}
					}
				}
				app[myHandler].trigger("loading", false);
			}
		};

		self.onSubmit = function() {
			//variables and functions
			var self = this;
			var unwrappedPropertiesMap = {};

			app[myHandler].trigger("loading", true);

			//check if all the required attributes are filled in
			$.each(self.getValues(), function(key, item) {
				unwrappedPropertiesMap["prop-" + key] = item;
			});

			//Include positional data attribute in properties map if enabled (not found by getValues)
			if(self.storePositionData) {
				unwrappedPropertiesMap["prop-" + self.metadataPropId] = JSON.stringify(self.managedPositionalData || {});
			}

			action.get("parameters").properties = unwrappedPropertiesMap;
			if(self.config.get("enableVersionOnUpdate") && self.config.get("enableVersionOnUpdate") === "true"){
				action.get("parameters").versioning = true;
			}else{
				action.get("parameters").versioning = false;
			}

			// We want to hide the file extensions for Wizard Forms
			if(_.contains(self.objectTypesToNotAddExtentionTo, self.objectType())) {
				action.get("parameters").hideFileExtensions = "true";
			} 

			// Set the objectId on the action params to this.objectId. We need to do this because
			// in the case where the id is updated and view props remains open as a rsah, we need to 
			//update the id before submitting view props again
			action.get("parameters").objectId = this.objectId;

			//stop listening to control value changes
			self.stopListening(self.eventManager, "fs:change");

			action.execute({
				success : self._successCallback,
				error : self._failCallback
			});
		};

		self._populateOldAndNewValueArrays = function(ocObjectData){
			// Create the arrays we want to give to the program
			var allAttrNamesArr = [];
			var oldValuesArr = [];
			var newValuesArr = [];

			//Find changed values and put them in corresponding arrays
			_.each(_.keys(ocObjectData.parameters.properties), function(newKey){
	
				// Get the new value before we modify the key to remove the prop prefix
				var tempNewValue = ocObjectData.parameters.properties[newKey];
	
				newKey = newKey.replace("prop-", "");
				var tempOldValue = self.ocObject.get("properties")[newKey];
	
				// Get the keyDataType for this property
				var objTypeConfig = self.otc.get('configs').where({'ocName': self.objectType()})[0];
				var keyDataType = objTypeConfig.get('attrs').where({'ocName': newKey})[0].get('dataType');
			
				var arrayValueChange = true;
				if(_.isArray(tempNewValue) && _.isArray(tempOldValue)){
					//if both are arrays, check equality
					arrayValueChange = !(_.isEmpty(_.difference(tempNewValue, tempOldValue)) && _.isEmpty(_.difference(tempOldValue, tempNewValue)));
				}else if(_.isArray(tempNewValue) && !_.isArray(tempOldValue)){
					//if only the new val is an array, the old value didn't exist
					if(tempNewValue.length <= 0){
						arrayValueChange = false;
					}
				}
	
				if(tempNewValue || tempOldValue){
					//only check equality if one of these is actually a value. not both null,undefined, empty
					if(!_.isEqual(tempNewValue,tempOldValue) && arrayValueChange){
						app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
							app.context.configService.getLabels(self.ocObject.get("objectType"), newKey).done(function(label){
								allAttrNamesArr.push(label);
								if(keyDataType === "date") {
									var oldVal = moment(tempOldValue).format(dateTimeFormat.dateFormat);
									var newVal = moment(tempNewValue).format(dateTimeFormat.dateFormat);
									oldValuesArr.push(oldVal);
									newValuesArr.push(newVal);
								} else {
									oldValuesArr.push(tempOldValue);
									newValuesArr.push(tempNewValue);
								}				                    	
							});		
						});		                    
					}
				}
			});  //end each keys

			return {
				'allAttrNamesArr': allAttrNamesArr,
				'oldValuesArr' : oldValuesArr,
				'newValuesArr' : newValuesArr
			};
		};

		self._createFolderNoteContent = function(ocObjectData, valueArraysObj){
			// Deconstruct the array object into separate variables for ease of usability
			var allAttrNamesArr = valueArraysObj.allAttrNamesArr;
			var oldValuesArr = valueArraysObj.oldValuesArr;
			var newValuesArr = valueArraysObj.newValuesArr;

			// Use this variable to build up the noteContent string
			var noteContent = "<p>User " + app.user.get("displayName") + " edited propert(ies) of " + "<a class='stageLink' documentId='" + ocObjectData.parameters.objectId + "'>" + self.ocObject.get("properties").objectName + "</a>" + " and changed ";
	
			_.each(allAttrNamesArr, function(object, index) {
				if(allAttrNamesArr[index+1] !== undefined) {
					noteContent = noteContent + object + ", ";
				} else {
					noteContent = noteContent + object + "; and changed value(s) ";
				}
			});
	
			_.each(oldValuesArr, function(object, index) {
				if(oldValuesArr[index+1] !== undefined) {
					if(newValuesArr[index].length < 1) {newValuesArr[index] = "No Value";}
					if(oldValuesArr[index] === null) {oldValuesArr[index] = "No Value";}
					noteContent = noteContent + "from " + oldValuesArr[index] + " to " + newValuesArr[index] + "; ";
				} else {
					if(newValuesArr[index].length < 1) {newValuesArr[index] = "No Value";}
					if(oldValuesArr[index] === null) {oldValuesArr[index] = "No Value";}
					noteContent = noteContent + " from " + oldValuesArr[index] + " to " + newValuesArr[index];
				}
			});
			noteContent = noteContent + ".</p>";
	
			return noteContent;
		};

		// When an action is successfully executed, this is the logic we want to execute.
		self._successCallback = function(data){
			app[myHandler].trigger("showMessage", "Successfully Updated");
			self.fetchedParents = null;
	
			// if folder notes are configured or the objectId was changed by the property edit then we need to fetch the parentId
			if((self.config.get("folderNotes") && self.config.get("folderNotes") === 'true') || data.result !== self.objectId) {	
				app.context.util.getParents(data.result, function(parents) {
					self.fetchedParents = parents;
					//As long as configs for folders/documents are on, create folder notes on property change
					if(self.config.get("folderNotes") && self.config.get("folderNotes") === 'true') {	
						app.context.configService.getAdminOTC(function(otc) {
							// For accessibility, put the OTC on the module
							self.otc = otc;

							// Figure out which properties were changed by the user.
							var valueArraysObj = self._populateOldAndNewValueArrays(data);

							// Create the note content
							var noteContent = self._createFolderNoteContent(data, valueArraysObj);

							// Determine the note type
							var noteType;
							if(!data.parameters.isContainer){ // document
								noteType = "Document Properties Changed";
							}else{ // folder
								noteType = "Folder Properties Changed";
							}
							
							// Determine if this object is a document or a folder that we are updating, to user the right parentId
							var parentId;
							var thisObjectId = self.ocObject.get("properties").objectId
							if(!data.parameters.isContainer){ // document
								// if a note was created on a document, the parentId for the note should be the same parent (folder) as the document
								parentId = self.fetchedParents[0].objectId;
							}else{ // folder
								// if a note was created on a folder, the parentId for the note should be that same folder
								parentId = thisObjectId;
							}
							
							//Create Folder Note
							if(valueArraysObj.allAttrNamesArr.length !== 0) {
								var folderNoteParameters = {
									parameters: {
										parentID: parentId,
										note_content: noteContent,
										note_rel_type: self.config.get("folderNoteRelationship"),
										note_object_type: self.config.get("folderNoteObjectType"),
										property_map:{
											note_type: noteType
										}
									}
								};
								if(config.get('enableDocumentNoteRelation') && config.get('enableDocumentNoteRelation') === "true"){
									// regardless of if this object is a folder or a document, we want to relate the note back to this object
									// so we use thisObjectId instead of parentId for the relationship
									folderNoteParameters.parameters.property_map.note_attachment = [thisObjectId];
								}
								FolderNotes.Service.execute(folderNoteParameters);
							}
						});
					} //end if configs = folderNotes		
				});
			}	
					
			self.newOCO = new OC.OpenContentObject({
				objectId: data.result
			});
			self.newOCO.fetch({
				success: function() {
					// if we fetched parents and we got a parentId back then we want to trigger the update
					// of the objectId with the returned parent in case it was updated as well
					var triggerObject = self.fetchedParents && self.fetchedParents.length ? {
						oldOco: self.ocObject,
						newOco: self.newOCO,
						updatedContainer: self.fetchedParents[0].objectId
					} : {
						oldOco: self.ocObject,
						newOco: self.newOCO
					};
					
					app.trigger("action:object-modified", triggerObject);
					if(self.searchResultsViewController) {
						self.searchResultsViewController.tableEventsRef.trigger("action:object-modified", triggerObject);
					}
					// setting these two params to true means use the same id just refresh, we need this line to refresh the ids in our url
					app.trigger("stage.refresh.bothIds", true, true);
					// set the correct info on the model since rsah doesnt close for view props
					// and if we submit again we want the correct objectId used if it was updated
					self.objectId = self.newOCO.get('objectId');
					self.ocObject = self.newOCO;
					//trigger loading to be off since our callback is done
					app[myHandler].trigger("loading", false);
				},
				error:function(jqXHR, textStatus, errorThrown) {
					//if it throws an error, it means we didnt have permission to check the node, aka we cant read, mark this typeKey
					if(errorThrown.xhr.status === 403){
						Backbone.history.navigate("Stage/" + app.context.configName() + "/" + app.context.container.id, {trigger: true} );
						app[myHandler].trigger("loading", false);
					}else{
						app.trigger("alert:error", {
							header: "Error",
							message: "Unable To Update Properties, an Error occured"
						});	
						app[myHandler].trigger("loading", false);
					}
				}
			});
		};

		// When an action is NOT successfully executed, this is the logic we want to execute.
		self._failCallback = function(jqXHR){
			app[myHandler].trigger("showError", "Sorry, an error has occured. Contact your administrator." +
			jqXHR.status + " " + jqXHR.responseText);
			app[myHandler].trigger("loading", false);
		};

		self.cleanup = function() {
			this.stopListening();
		};

		return self;
	};

	action.View = Backbone.Layout.extend({
		template: "actions/viewproperties/viewproperties",
		events: {
			"click #viewPropertiesPrint": "print",
			"click .positionalBtn": "jumpToPositional"
		},
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			if(this.options.config.get('useReadOnlyControls') === 'true'){
				this.readOnlyView = new ReadOnlyViewProperties.View({'action' : this.action, 'myHandler' : this.myHandler, 'config' : this.options.config});
			} else{
				this.viewModel = new action.ViewModel(this.action, this.myHandler, this.config, this.options.searchResultsViewController);
				this.viewModel.checkConditions();
			}

			this.submitBtnLabel = this.options.config.get("submitBtnLabel") ? this.options.config.get("submitBtnLabel") : window.localize("generic.submit");
		},
		afterRender: function(){
			if(this.options.config.get('useReadOnlyControls') === 'true'){
				//this.readOnlyView = new ReadOnlyViewProperties.View({'action' : this.action, 'myHandler' : this.myHandler, 'config' : this.options.config});
				this.insertView("#readOnlyViewProperties", this.readOnlyView).render();
			} else {
				kb.applyBindings(this.viewModel, this.$el[0]);
			}
		},
		jumpToPositional: function(event) {
			var positionalData = JSON.parse($(event.currentTarget).attr('data-positional'));
			externalEventsModule.locatesAnnotationPosition(positionalData);
			externalEventsModule.createTextSelect(positionalData);
		},
		print: function(){
			var html = this.$("#readOnlyViewProperties").html();
			var w = window.open();

			// Set the origin of the URL, some sort of "http://localhost:8080" format.
			var origin = window.location.origin;
			if(!origin) {
				origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
			}

			$(w.document.head).html('<link rel="stylesheet" href="' + origin + app.root + 'assets/css/index.css"> <link rel="stylesheet" href="' + origin + app.root + 'assets/css/styles/readonlyprint.css">');
			$(w.document.body).html(html);
			w.print();
		},
		serialize: function(){
			var modal = false;
			var rightSide = false;
			var isReadOnly = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			if(this.options.config.get('useReadOnlyControls') === 'true'){
				isReadOnly = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				isReadOnly: isReadOnly,
				btnLabel : this.submitBtnLabel
			};
		},

		cleanup: function() {
			if(this.viewModel) {
				this.viewModel.cleanup();
			}
		}
	});

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/viewpropertiesconfig",
		events: {
			"change #submit-btn-label" : "btnLabelChanged"
		},
		initialize: function(){
			var self = this;
			this.viewModel = this.options.viewModel;

			this.viewModel.form = kb.observable(this.viewModel.model(), "form");
			this.viewModel.potentialForms = ko.observableArray();
			this.initializeDef = app.context.configService.getFormConfigNames(function(formConfigNames) {
				self.viewModel.potentialForms(formConfigNames);
			});
			
			//whether or not to create a Folder Note after document upload
			if(!this.viewModel.model().folderNotes){
				this.viewModel.model().folderNotes = false;
			}
			this.viewModel.folderNotes = kb.observable(this.viewModel.model(), "folderNotes");
			
			if(this.viewModel.folderNotes() === "false" ) {
				this.viewModel.folderNoteType(false);
			}

			// selected folder note type from the admin
			this.viewModel.folderNoteObjectType = kb.observable(this.viewModel.model(),"folderNoteObjectType");
			if (!this.viewModel.folderNoteObjectType()){
				this.viewModel.folderNoteObjectType("HPI Note");
			}
			// note type to apply to all folder notes
			this.viewModel.folderNoteType = kb.observable(this.viewModel.model(),"folderNoteType");
			if (!this.viewModel.folderNoteType()) {
				this.viewModel.folderNoteType("Folder Note");
			}
			//selected folder note relationship from admin
			this.viewModel.folderNoteRelationship = kb.observable(this.viewModel.model(),"folderNoteRelationship");

			// Whether or not to display attributes using readOnly controls
			if(!this.viewModel.model().useReadOnlyControls){
				this.viewModel.model().useReadOnlyControls = false;
			}
			this.viewModel.useReadOnlyControls = kb.observable(this.viewModel.model(), "useReadOnlyControls");

			//is the note directly related to the folder or document?
			this.viewModel.enableDocumentNoteRelation = kb.observable(this.viewModel.model(), "enableDocumentNoteRelation");

			this.viewModel.enableVersionOnUpdate = kb.observable(this.viewModel.model(), "enableVersionOnUpdate");
			this.positionDataView = new iOSSwitch.View({
				model: this.viewModel.model(),
				configModelKey: "positionDataEnabled",
				switchTitle: window.localize("indexerConfig.indexerMainLayout.viewPropertiesPosition"),
				configDescription: window.localize("indexerConfig.showPositionOnDocument")
			});
			
			// if the button label has yet to be set default it to Submit
			if(!this.viewModel.model().get("submitBtnLabel")) {
				this.viewModel.model().set("submitBtnLabel", window.localize("generic.submit"));
			}
		},

		btnLabelChanged: function(evt) {
			// update the button label on the model
			evt.stopPropagation();
			var newMessage = this.$('#submit-btn-label').val();
			this.viewModel.model().set("submitBtnLabel", newMessage);
		},

		afterRender: function(){
			var self = this;
			
			this.initializeDef.done(function(){
				kb.applyBindings(self.viewModel, self.$el[0]);
				self.insertView("#positionalDataIosBind", self.positionDataView).render();
			});
		},

		serialize: function() {
			return {
				submitBtnLabel: this.viewModel.model().get("submitBtnLabel")
			};
		}
	});

	actionModules.registerAction("viewProperties", action, {
		"actionId" : "viewProperties",
		"label" : "View Properties",
		"icon" : "list-alt",
		"handler" : "rightSideActionHandler"
	});

	return action;

});
require(["viewproperties"]);