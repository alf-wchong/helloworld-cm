define([
	"app",
	"oc",
	"modules/actions/viewproperties/readonlyview"
],

function(app, OC, ReadOnlyView) {

	// Create a new module.
	var ReadOnlyViewProperties = {};

    /**
     * A simple model specific to the read only viewproperties action.
     */
    ReadOnlyViewProperties.Model = Backbone.Model.extend({
        initialize: function(model){
			this.attributes = model.attributes;
        }
    });

	/**
	 * Main view for the read only form support module is in charge of retrieving the form to be used, as well as the
	 * OCO object with the data to be displayed.
	 */
	ReadOnlyViewProperties.View = Backbone.Marionette.LayoutView.extend({
	    template: "actions/viewproperties/readonlyviewproperties",
	    regions: {
	        container: '.attributesContainer'
	    },

	    initialize: function(options){
	    	var self = this;

			// Creating our collection for the models of configured attributes.
            this.formControls = new Backbone.Collection();

	    	// Get the objectId from the action trigger.
			this.objectId = this.action.get("parameters").objectId;

			// Use the objectId from the action parameter to retrieve this document's OCO.
			this.oCObject = new OC.OpenContentObject({ objectId : this.objectId });

			// Will allow us to signal the afterRender when all information is ready to populate this action with.
			this.deferredPreparation = $.Deferred();

	    	// Fetch the OpenContent object that triggered this action. We will need to extract its properties to display them correctly
	    	// on the view properties modal.
			this.oCObject.fetch({
				success: function(object) {
					self.objectType = object.get("objectType");					
					self.propertyValues = object.get("properties");

					// Grabbing the form config, using search configs information.
		            app.context.configService.getFormConfig(self.options.config.get("form"), function(retrievedForm) {
						//Get the form associated with our trac and type.
			            self.formForType = _.find(retrievedForm.get("configuredTypes").models, function(formType){
			                return formType.get("ocName") === self.objectType;
			            });

	            		//Getting the OTC and timezoneformatting settings.
	                    app.context.configService.getAdminTypeConfig(self.objectType, function(otc){
                            if (otc){
                                var allConfiguredAttrs = self.formForType.get("configuredAttrsPri").models;
                				
            					//Loop through all the the configured attrs (both primary and secondary).
                                _.each(allConfiguredAttrs, function(availableAttribute) {
            						
                                    var otcAttr = _.find(otc.get("attrs").models, function(theAttr){
                                        return availableAttribute.get("ocName") === theAttr.get("ocName");
                                    });

                                    availableAttribute.set("label", otcAttr.get("label"));

                                    // If this repeating property is populated then get the dataTypes for each.
                                    if(availableAttribute.get('readOnlyGroupedAttrs')){
                                    	_.each(availableAttribute.get('readOnlyGroupedAttrs'), function(attr){
                                    		var attrInConfig = _.find(otc.get('attrs').models, function(theAttr){
                                    			return attr.ocName === theAttr.get('ocName');
                                    		});

                                    		attr.dataType = attrInConfig.get('dataType');
                                    	});
                                    }

            						//Place our "formControl" in the correct collection.
                                    self.formControls.add(new ReadOnlyViewProperties.Model(availableAttribute));
                                });

								// Finished preparing data for view properties, we can move on to creating other views.
								self.deferredPreparation.resolve();
                            }
	                    }); // end getAdminTypeConfig

		    		});// end getFormConfig
				}
			});// end ocObject.fetch
	    },
	    afterRender: function (){
	    	var self = this;

	    	this.deferredPreparation.done(function(){
		    	// This collection view will take a Backbone collection and create a separate view for each of the models defined.
		    	// From these models it will create the type of view defined in its childView property.
		    	self.attributesView = new ReadOnlyViewProperties.CollectionView({
		    	    collection: self.formControls,
		    	    propertyValues: self.propertyValues
		    	});

		    	// Show the newly created view.
		    	self.getRegion('container').show(self.attributesView);
	    	});
	    }
	});

	/**
	 * Main view for the read only form support module is in charge of: XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.
	 */
    ReadOnlyViewProperties.CollectionView = Backbone.Marionette.CollectionView.extend({
    	manage: false,
    	childView: ReadOnlyView.WrapperView,
    	childViewOptions: function(){
    		return {
    			'propertyValues' : this.options.propertyValues
    		};
    	}
        // This view will perform a few of things on its own since it's being called by a Marionette.CollectionView framework.
        // 1) It will create a new view of the type specified in childView for each item in the passed in collection.
        // 2) It will retain all attributes from the model that was passed in and usable/accessible directly on this view at 'this.model'.
        // 3) It will serialize all values in Handlebars within the specified template, provided the names of the variables are the same.
    });

    return ReadOnlyViewProperties;
});