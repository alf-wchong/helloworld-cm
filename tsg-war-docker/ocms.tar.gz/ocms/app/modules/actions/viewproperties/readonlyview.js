// ReadOnlyView contol module
define([
	"app",
	"handlebars"
],

function(app, Handlebars) {

	// Create a new module.
	var ReadOnlyView = {};

    ReadOnlyView.WrapperView = Backbone.Marionette.LayoutView.extend({
        template: "actions/viewproperties/readonlycontrol",
		manage:false,

		initialize: function(){
			// Note: this.options and this.model are already populated upon entering the initialize method thanks to the Marionette framework.

			// If this model doesn't have grouped attributes proceed with an individual view, otherwise create a grouped view.
			if(!this.options.model.get('readOnlyGroupedAttrs').length){
				this.newView = new ReadOnlyView.IndividualView(this.options);
			} else {
				this.newView = new ReadOnlyView.GroupedView(this.options);
			}
		},
		onShow: function(){
			// Add the region particular to this model's display in the DOM.
			this.addRegions({
			    container: '#readOnly-control-' + this.options.model.cid 
			});
			this.getRegion("container").show(this.newView);
		},
		serializeData: function(){
			return {
				'cid': this.options.model.cid
			};
		}
    });

    ReadOnlyView.IndividualView = Backbone.Marionette.ItemView.extend({
        template: "actions/viewproperties/readonlyindividualcontrol",
 		manage:false,

		initialize: function(options){
			// Note: this.options and this.model are already populated upon entering the initialize method thanks to the Marionette framework.

			var self = this;

			// Save this property's value onto the view. If this property's value is of a date type, then format it properly.
			this.propertyValue = this.options.propertyValues[this.model.get('ocName')];
			if(this.model.get('dataType') === 'date'){
				app.context.dateService.getFormattedDate(this.propertyValue).done(function(formattedDate){
					self.propertyValue = formattedDate;
				});
			}
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				'label' : this.model.get('label'),
				'ocName' : this.model.get('ocName'),
				'propertyValue' : this.propertyValue
			};
		}
    });

    ReadOnlyView.GroupedView = Backbone.Marionette.ItemView.extend({
        template: "actions/viewproperties/readonlygroupedcontrol",
		manage:false,

		initialize: function(options){
			// Note: this.options and this.model are already populated upon entering the initialize method thanks to the Marionette framework.

			// Get all grouped attributes and their information for the DOM on an array.
			this.groupedAttrs = [];
			// Push the model's information first.
			this.groupedAttrs.push({
				'label' : this.model.get('label'),
				'ocName' : this.model.get('ocName'),
				'dataType' : this.model.get('dataType'),
				'propertyValue' : this.options.propertyValues[this.model.get('ocName')]
			});
			// Loop through the attributes that were grouped in this model, and add their information to the array.
			_.each(this.model.get('readOnlyGroupedAttrs'), function(groupedAttr){
				var newGroupedAttr = {
					'label' : groupedAttr.label,
					'ocName' : groupedAttr.ocName,
					'dataType' : groupedAttr.dataType,
					'propertyValue' : this.options.propertyValues[groupedAttr.ocName]
				};

				this.groupedAttrs.push(newGroupedAttr);
			}, this);

            // A helper to parse the repeating attributes in an array and render them properly.
            Handlebars.registerHelper('parseGroupedPropertyValue', this.parseGroupedPropertyValue);
		},
		onShow: function(){
			this.serializeData();
		},
		serializeData: function(){
			return {
				'groupedAttrs' : this.groupedAttrs
			};
		},
        parseGroupedPropertyValue: function(groupedAttrs){
        	// Determine the maximum number of rows that must be crated. Should all be the same length if configured properly.
        	var maxRepeatingAttr = _.max(groupedAttrs, function(attr){ return _.isArray(attr.propertyValue) ? attr.propertyValue.length : 0; });
        	var maxRepeatingAttrLength = 0;
        	if(maxRepeatingAttr && maxRepeatingAttr.propertyValue){
        		maxRepeatingAttrLength = maxRepeatingAttr.propertyValue.length;
        	}

        	// Varibale that will hold our built HTML to display our table.
        	var attributesHTML = '';

        	// This will be the callback function for our each loop that build each row's table data. It is advise that functions do not be created within
        	// a for loop in javascript for performance issues and unexpected behavior so we define it here, outside of the for loop.
        	var tableDataFunc = function(attr) {
	            // Holds the value that will be displayed in the HTML.
	            var valueToDisplay;

	            if(_.isArray(attr.propertyValue)){
	            	// Get the right attribute from the array of repeating attributes.
	            	valueToDisplay = attr.propertyValue[tableDataIndex];
	            	if(_.isUndefined(valueToDisplay) || _.isNull(valueToDisplay)){
	            		// Display a blank value in case that this variable is not defined here.
	            		valueToDisplay = '';
	            	}
	            } else {
	                // We don't have a repeating attribute, we can just return the attribute's value.
	            	valueToDisplay = attr.propertyValue;
	            }

	            if(attr.dataType === 'date'){
	            	app.context.dateService.getFormattedDate(attr.propertyValue).done(function(formattedDate){
	            		valueToDisplay = formattedDate;
	            	});
	            }

	            // Create the HTML string for the attribute's value to display.
	            attributesHTML += '<td class="input-sm">' + valueToDisplay + '</td>';
        	};

        	for(var tableDataIndex = 0; tableDataIndex < maxRepeatingAttrLength; tableDataIndex++){
        		// Open table row tag.
	        	attributesHTML += '<tr>';

	        	// Create each table's data row using the attribute's values.
        		_.each(groupedAttrs, tableDataFunc);

        		// Close table row tag.
	        	attributesHTML += '</tr>';
            }

            // Returns the string safe of any HTML escaping to be rendered by the application.
            return new Handlebars.SafeString(attributesHTML);
        }
    });

	return ReadOnlyView;
});