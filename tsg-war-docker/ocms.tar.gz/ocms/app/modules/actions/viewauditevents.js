define("viewauditevents",[
	"app",
	"modules/actions/actionmodules",
	"handlebars"
],
function(app, actionModules, Handlebars) {
	"use strict";

	var ViewAuditEvents = {};

	ViewAuditEvents.headers = [
			{
			 label: "Event",
			 value: 'eventName'
			},
			{
			 label: 'Description',
			 value: 'eventDescription'
			},
			{
			 label: 'Username',
			 value: 'displayName'
			},
			{
			 label:'Date',
			 value: 'eventDate'
			},
			{
			 label: 'Additional Details',
			 value: 'eventDetails'
			}];

	ViewAuditEvents.ViewModel = function(options, myHandler, toggleLoader) {
		var self = this;

		self.enableTimeConfig = options.config.get("enableTimeConfig");

		// get the objectId for the object we want to fetch audit events for
		self.objectId = options.action.get("parameters").objectId;

		self.categories = [];

		self.rows = ko.observableArray([]);
		
		// get all audit events from OC
		self.viewAuditEvents = function() {
			self.toggleLoader(true);
			
			$.ajax({
				type: "GET",
				url: app.serviceUrlRoot + "/audit/getAuditEvents",
				data: {objectId: self.objectId},
				success: function(result){
					app.context.dateService.getDatetimeTimezoneFormat().done(function(formats){
						//need timezone from 
						self.processHeaders(result);
						_.each(result, function(item){
							//OC should return audit events with the last item first
							self.rows.push(self.processRow(item, self.categories, formats));
						});

						self.toggleLoader(false);
					});
				},
				error: function(response){
					app[myHandler].trigger("showError", "There was an error trying to retrieve the audit trail entries. Check with your administrator.");
				}
			});
		};

		self.processHeaders = function(result) {
			if(result.length > 0) {
				_.each (result[0], function(idx, item) {
					self.categories.push(item);
				});
			}
		};

		self.processRow = function(item, headers, dateFormats) {
			var rowJSON = {};
			
			// Parse through extras comments
			_.each(headers, function(key, index){
				if(key === "extras") {
					var extras = [];
					_.each(item[key], function(extraValue, extraKey) {
						var text = extraKey + ": " + extraValue;
						if(extraValue !== "") {
							extras[extras.length] = text;
						}

					});
					rowJSON[key] = extras;
				} else if(key == "auditDate") {
					//format based on date/time format
					var formattedDate = "";
					if(self.enableTimeConfig && self.enableTimeConfig === "true"){
						if(dateFormats.timezoneFormat){
							formattedDate = moment(item[key]).tz(dateFormats.timezoneFormat).format(dateFormats.dateFormat+" "+dateFormats.timeFormat);
						} else {
							formattedDate = moment(item[key]).format(dateFormats.dateFormat+" "+dateFormats.timeFormat);
						}
						rowJSON[key] = (formattedDate ? formattedDate : "");
					} else {
						var date = new Date(item[key]);
						rowJSON[key] = (date ? date.toUTCString(): "");
					}
				} else {
					rowJSON[key] = ((item[key] === null) ? "" : item[key]);
				}
			});

			return rowJSON;
		};

		self.toggleLoader = function(bool) {
			app[myHandler].trigger("loading", bool);
		};

		self.viewAuditEvents();
	};

	ViewAuditEvents.View = Backbone.Layout.extend({
		
		template: "actions/viewauditevents",
		events: {
			"click .auditHeader" : "columnSort"
		},
		initialize: function() {
			this.myHandler = this.options.config.get("handler");
			this.viewModel = new ViewAuditEvents.ViewModel(this.options, this.myHandler);  
			this.currentSort = '';    
			Handlebars.registerHelper('unlessCond', function(v1, v2, options) {
                if(v1 !== v2) {
                    return options.fn(this);
                }
                return options.inverse(this);
            });
		},
		
		afterRender: function() {
			ko.applyBindings(this.viewModel, this.$el[0]);
		},

		columnSort: function(event){
			var self = this;
			if(event.target.id === 'eventDetails'){
				//not sorting on extras
				return;
			}
			if(self.currentSort === event.target.id){
				this.viewModel.rows(this.viewModel.rows().reverse());
			}else{
				self.currentSort = event.target.id;
				if(self.currentSort === 'eventDate'){
					this.viewModel.rows(_.sortBy(this.viewModel.rows(), function(row){
						return moment(row.auditDate).unix();
					}));
				}else{
					this.viewModel.rows(_.sortBy(this.viewModel.rows(), self.currentSort));
				}
			}
		},
		serialize: function() {

			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal: modal,
				rightSide: rightSide,
				headers: ViewAuditEvents.headers
			};
		}
	});
	
	ViewAuditEvents.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/viewauditevents",
        initialize: function(){
            var viewModel = this.options.viewModel;

            viewModel.enableTimeConfig = kb.observable(viewModel.model(), 'enableTimeConfig');

            if(!viewModel.enableTimeConfig()){
            	viewModel.enableTimeConfig("false");
            }
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

	actionModules.registerAction("viewAuditEvents", ViewAuditEvents, {
		"actionId" : "viewAuditEvents",
		"label" : "View Audit Events",
		"icon" : "info-sign"
	});
	
	return ViewAuditEvents;
});
require(["viewauditevents"]);