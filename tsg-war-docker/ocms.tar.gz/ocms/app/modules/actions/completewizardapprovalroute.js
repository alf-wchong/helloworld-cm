define("completewizardapprovalroute",[
  // Application.
  "app",
  "module",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app,module, actionModules) {
    "use strict";

    var action = {};

    var disciplinesEnabled = module.config().disciplinesEnabled || false;
    var disciplinesEndpoint = module.config().disciplinesEndpoint || '';

    function ViewModelCompleteWizardApprovalRoute(action, myHandler, toggleLoader){

		var self = this;

		//The following value is for character validation. 127 allows all
		//characters that are in the standard ASCII table
		var maxASCIICharNum = 127;
		self.formAction = ko.observable();
		self.eSigUsername = ko.observable().extend({ required: true, validateMessage: maxASCIICharNum});
		self.eSigPassword = ko.observable().extend({ required: true, validateMessage: maxASCIICharNum});
		self.eSigError =  ko.observable();	
		self.roleName = ko.observable();
		self.taskId = ko.observable();

        self.requireAuthentication = ko.observable();
		self.allowApprovalComments = ko.observable();
		self.allowRejectionComments = ko.observable();
		self.requireApprovalComments = ko.observable();
		self.requireRejectionComments = ko.observable();
		self.picklistSelected = ko.observable();
		self.meaningOfSignaturePicklist = ko.observable();
		self.possibleUserRoles = ko.observableArray();
		self.picklistOptions = ko.observableArray();
		self.defaultOption = ko.observable();

		if(disciplinesEnabled){
			self.disciplines = ko.observableArray();
			self.chosenDisciplines = ko.observableArray();
		}

		self.taskId.subscribe(function(taskId){
			var item = _.findWhere(self.possibleUserRoles(), {'taskId': taskId});
			self.roleName(item.role);
			//disciplinesEnabled is a list of roles, true, or false
		    if(module.config().disciplinesEnabled){
		    	if(self.roleName() && _.isArray(module.config().disciplinesEnabled)){
		    		disciplinesEnabled = _.contains(module.config().disciplinesEnabled, self.roleName());
		    	}else{
		    		disciplinesEnabled = true;
		    	}
		    }
		    //clear out disciplines if this role doesn't have any
			if(!disciplinesEnabled){
				self.disciplines = ko.observableArray();
				self.chosenDisciplines = ko.observableArray();
			}
		});

		self.objectId = action.get("parameters").objectId;
		//This variable is used to show the validation errors
		var validatedVM = ko.validation.group(self, {deep: true});

		//prevents the user from entering any characters that are outside the scope of the maxASCIICharNum, defined above
		self.keyCheck = function(data, event){
			if(event.charCode>maxASCIICharNum){
				return false;
			}
			return true;
		};

		self.confirmAction = function(func, data, event) {
            if(self.formAction() && (!self.meaningOfSignaturePicklist || (self.meaningOfSignaturePicklist && self.defaultOption() !== ''))){
				var confirmed = window.confirm((window.localize("modules.actions.completeWizardApprovalRoute.areYou")) + func + (window.localize("modules.actions.completeWizardApprovalRoute.this")));
				if(confirmed) {   
                    // when form has been validated submit the approval or rejection  
                    $.when(self.validateForm(func)).done(function(valid) {
                        if(valid) { 
                            if(func === "Approve") {
                				self.onApprove();
                			} else {
            					self.onReject();
            				}
                        }
                        else {
                            self.toggleLoader(false);
                            $('#eSigError').show();
                        }

                    });
                    
				}
			}
			else{
				 if(self.meaningOfSignaturePicklist) {
                	if(self.defaultOption() === ''){
                    	self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.meaningOfSignatureRequired")));
               		} else {
           		 		self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.selectApprove")));
           		 	}
           		 } else {
           		 	self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.selectApprove")));
           		 }
				$('#eSigError').show();
			}
		};

        self.validateForm = function(func) {
            
            var deferred = $.Deferred();

             // check to see we have the task id
            if(!self.taskId()) {
               deferred.resolve(false);
            }
            
            if(self.requireApprovalComments && func === "Approve") {
                if(self.eSigApproveComment.isValid() === false){
                    self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.aComment")));
                    validatedVM.showAllMessages();
                    deferred.resolve(false);
                }
            }
            if(self.requireRejectionComments && func === "Reject") {
                if(self.eSigRejectComment.isValid() === false){
                    self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.aComment")));
                    validatedVM.showAllMessages();
                    deferred.resolve(false);
                }
            }
            if(self.requireAuthentication) {
                if (self.eSigUsername.isValid() && self.eSigPassword.isValid()) {
                    self.toggleLoader(true);
                    //have to be the current logged in user to sign-off if authentication is required
                    if(self.eSigUsername().toLowerCase() !== app.user.id.toLowerCase()){
                        self.toggleLoader(false);
                        self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.userIsIncorrect")));
                        deferred.resolve(false);
                    }
                    else{
                        //validate the e-signature and then submit the form
                        var opts = {
                            type:   "POST",
                            contentType:    "application/json",
                            url:    app.serviceUrlRoot + "/authentication/newSession?username=" + self.eSigUsername(),
                            data: JSON.stringify(self.eSigPassword()),
                            success: function(result){
                               deferred.resolve(true);
                            },                            
                            statusCode: {
                                401: function(jqXHR, textStatus, errorThrown){   
                                    self.toggleLoader(false);
                                    self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.failedToAuthenticate")) +
                                        jqXHR.status + " " + jqXHR.statusText);
                                    deferred.resolve(false);
                                }
                            },

                            error: function(jqXHR, textStatus, errorThrown){
                                self.toggleLoader(false);
                                self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.failedToAuthenticate")) +
                                                    jqXHR.status + " " + jqXHR.statusText);
                                deferred.resolve(false);
                            }

                        };

                        $.ajax(opts);
                    }
                }
                else {
                    deferred.resolve(false);
                }
            }
            else {
                deferred.resolve(true);
            }
      
            return deferred;

        };

		self.getDisciplines = function(){
			//var deferred = $.Deferred();

			return	$.ajax({
				type : "GET",
				contentType: "application/json",
				url: app.serviceUrlRoot + disciplinesEndpoint + "formId=" + action.get("parameters").objectId,
				success: function(result){
					if(result === null || result === undefined){
						app[myHandler].trigger("showError", (window.localize("modules.actions.completeWizardApprovalRoute.noDiscipline")));
					}

					_.each(result,function(discipline){
						self.disciplines.push({
							label: discipline
						});
					});

					//deferred.resolve();

				},
				error: function(){
					app[myHandler].trigger("showError", (window.localize("modules.actions.completeWizardApprovalRoute.errorRetrievingDisciplines")));
				}
			});



		};

		//TODO - refine this as we get the OC side figured out
		self.setRoleNameAndTaskId = function(){
			var opts = {
				type : "GET",
				contentType: "application/json",
				url: app.serviceUrlRoot + "/aw-workflow/getMyWizardTasks?formId=" + action.get("parameters").objectId,
				success: function(result){
					if(result === null || result === undefined){
						app[myHandler].trigger("showError", (window.localize("modules.actions.completeWizardApprovalRoute.noTasksFound")));
					}
					$.each(result, function(i, wizardTask){
						self.possibleUserRoles.push({role: wizardTask.roleName,
														taskId: wizardTask.id
													});
					});
				},
				error: function(){
					app[myHandler].trigger("showError", (window.localize("modules.actions.completeWizardApprovalRoute.errorRetrieving")));
				}
			};

			$.ajax(opts);
		};


		self.onApprove = function() {
            action.get("parameters").taskId  = self.taskId();
            action.get("parameters").eSigUsername   = self.eSigUsername();
            action.get("parameters").eSigPassword   = self.eSigPassword();
            action.get("parameters").comments = self.eSigApproveComment();
            action.get("parameters").meaningOfSignaturePicklist = self.meaningOfSignaturePicklist;
            action.get("parameters").meaningOfSignature = self.defaultOption();
          
            if(disciplinesEnabled){
                action.get("parameters").disciplines = self.chosenDisciplines();
            }
            action.get("parameters").completionType = "approve";

			action.execute({
				success : function(data) {
		  			self.toggleLoader(false);
					//TSG.stage.model.containerId.valueHasMutated();
					app[myHandler].trigger("showMessage", (window.localize("modules.actions.completeWizardApprovalRoute.approvalOfForm")));

					//If the current version id was provided in the result, this is where
					//want to navigate to (Important for HBase which appends version to objectId
					if(data.result !== null && data.result !== undefined) {
						self.objectId = data.result;
					}
					app.listenToOnce(app[myHandler], "hide", function() {
						app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
					});

				},
				error : function(jqXHR, textStatus, errorThrown) {
					self.toggleLoader(false);
					self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.failedToComplete")) +
							jqXHR.status + " " + jqXHR.statusText);
					$('#eSigError').show();
				}
			});
    
		};

		self.onSliderToggle = function()
		{
			if($.browser.msie && $.browser.version < 9){
						$('#approve-status-slider-element').removeClass("red");
						$('#approve-status-slider-element').removeClass("green");

						$('#enableTitle').removeClass("approve-status-element-white");
						$('#disableTitle').removeClass("approve-status-element-white");

						$('#enableTitle').addClass("approve-status-element-black");
						$('#disableTitle').addClass("approve-status-element-black");

						$('#approve-status-slider div').removeClass("switch ios");

						$('#approve-status-slider label').css("display", "inline");
						$('#approve-status-slider input').css("display", "inline");
				}
			else{
				if(self.formAction() === "Approve")
				{
					//Add or remove css classes based on slider position
					$('#approve-status-slider-element').addClass("slide-button green");
					$('#enableTitle').addClass("approve-status-element-white");
					$('#disableTitle').addClass("approve-status-element-black");

					$('#approve-status-slider-element').removeClass("red");
					$('#enableTitle').removeClass("approve-status-element-black");
					$('#disableTitle').removeClass("approve-status-element-white");
				}
				else if(self.formAction()=== "Reject"){
					$('#approve-status-slider-element').addClass("slide-button red");
					$('#enableTitle').addClass("approve-status-element-black");
					$('#disableTitle').addClass("approve-status-element-white");

					$('#approve-status-slider-element').removeClass("green");
					$('#enableTitle').removeClass("approve-status-element-white");
					$('#disableTitle').removeClass("approve-status-element-black");
				}
			}
		};

		self.onReject = function() {
			
            action.get("parameters").taskId = self.taskId();
            action.get("parameters").eSigUsername = self.eSigUsername();
            action.get("parameters").eSigPassword = self.eSigPassword();
            action.get("parameters").comments = self.eSigRejectComment();
            action.get("parameters").meaningOfSignaturePicklist = self.meaningOfSignaturePicklist;
            action.get("parameters").meaningOfSignature = self.defaultOption();
            if(disciplinesEnabled){
                action.get("parameters").disciplines = self.chosenDisciplines();
            }
            action.get("parameters").completionType = "reject";

            action.execute({
                success : function(data) {
                    self.toggleLoader(false);
                    //TSG.stage.model.containerId.valueHasMutated();
                    app[myHandler].trigger("showMessage", (window.localize("modules.actions.completeWizardApprovalRoute.rejectionOfForm")));

                    app.listenToOnce(app[myHandler], "hide", function() {
                        app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
                    }); 
                },
                error : function(jqXHR, textStatus, errorThrown) {
                    self.toggleLoader(false);
                    self.eSigError((window.localize("modules.actions.completeWizardApprovalRoute.failedToComplete"))+
                        jqXHR.status + " " + jqXHR.statusText);
                    $('#eSigError').show();
                }
            });
            
        };

        self.toggleLoader = function(bool){
                    app[myHandler].trigger("loading", bool);
        };
    }

    action.View = Backbone.Layout.extend({
        template: "actions/completewizardapprovalroute",
        events: {
			'click input[type=checkbox]': 'toggleDisciplineCheck'
		},
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");

        },
         beforeRender: function(){
         	var self = this;
            self.viewModel = new ViewModelCompleteWizardApprovalRoute(this.action, this.myHandler);
            self.viewModel.setRoleNameAndTaskId();
            if(disciplinesEnabled){
            	self.viewModel.getDisciplines();
        	}
            self.viewModel.requireAuthentication = this.options.config.attributes.requireAuthentication === "true" ? true : false; //convert from stringified boolean to real bool
            self.viewModel.allowApprovalComments = this.options.config.attributes.allowApprovalComments === "true" ? true : false; //convert from stringified boolean to real bool
            self.viewModel.allowRejectionComments = this.options.config.attributes.allowRejectionComments === "true" ? true : false; //convert from stringified boolean to real bool
            var approvalCommentsRequired = this.options.config.attributes.requireApprovalCommenting === "true" ? true : false; //convert from stringified boolean to real bool
            var rejectionCommentsRequired = this.options.config.attributes.requireRejectionCommenting === "true" ? true : false; //convert from stringified boolean to real bool
            self.viewModel.meaningOfSignaturePicklist = this.options.config.attributes.meaningOfSignaturePicklist === "true" ? true : false; //convert from stringified boolean to real bool
            if(self.viewModel.meaningOfSignaturePicklist){
				//load the picklist of meaning of signatures
				app.context.picklistService.getPicklist(self.options.config.attributes.picklistSelected, function(picklistOptions, defaultOption, picklistName){
					var values = [];
					_.each(picklistOptions, function(picklistItem){
						values.push(picklistItem.label);
					});
					self.viewModel.picklistOptions(values);
					self.viewModel.defaultOption(defaultOption);
				});
            }
            if(!self.viewModel.allowApprovalComments){
            	approvalCommentsRequired = false;
            }
            if(!self.viewModel.allowRejectionComments){
            	rejectionCommentsRequired = false;
            }
       		self.viewModel.eSigApproveComment = ko.observable().extend({ required: approvalCommentsRequired, validateMessage: 127});
       		self.viewModel.eSigRejectComment = ko.observable().extend({ required: rejectionCommentsRequired, validateMessage: 127});
        },
        afterRender: function() {
        	this.rendered = true;
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        toggleDisciplineCheck : function(data){
        	var self = this;
			if(data.target.checked === true){
				self.viewModel.chosenDisciplines.push(data.target.value);
			}else{
				self.viewModel.chosenDisciplines.remove(function(disc){
					return disc === data.target.value;
				});

			}

		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			var self = this;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
                requireAuthentication : self.viewModel.requireAuthentication,
				allowApprovalComments : self.viewModel.allowApprovalComments,
				allowRejectionComments : self.viewModel.allowRejectionComments,
				meaningOfSignaturePicklist : self.viewModel.meaningOfSignaturePicklist,
				disciplines: self.viewModel.disciplines,
				disciplinesEnabled: disciplinesEnabled
			};
        }
    });

    action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/completewizardapprovalrouteconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;
			viewModel.allowApprovalComments = kb.observable(viewModel.model(), "allowApprovalComments");
			viewModel.allowRejectionComments = kb.observable(viewModel.model(), "allowRejectionComments");
            viewModel.requireAuthentication = kb.observable(viewModel.model(), "requireAuthentication");
            viewModel.meaningOfSignaturePicklist = kb.observable(viewModel.model(), "meaningOfSignaturePicklist");
            viewModel.picklistSelected = kb.observable(viewModel.model(), "picklistSelected");
            var selectedPick = viewModel.picklistSelected();

			viewModel.showApprovalCommentingRequired = ko.computed(function(){
            	return viewModel.allowApprovalComments() === "true" ? true : false;
			});
			viewModel.showRejectionCommentingRequired = ko.computed(function(){
            	return viewModel.allowRejectionComments() === "true" ? true : false;
			});
			viewModel.showPicklistMeaningOfSignature = ko.computed(function(){
            	return viewModel.meaningOfSignaturePicklist() === "true" ? true : false;
			});


			viewModel.requireApprovalComments = kb.observable(viewModel.model(), "requireApprovalComments");
			viewModel.requireRejectionComments = kb.observable(viewModel.model(), "requireRejectionComments");

			viewModel.picklists = ko.observableArray([]); 
            var myPicklistNames = [];
            //Pushing the default blank value
            myPicklistNames.push("");

			//defaults if null
			if(viewModel.allowApprovalComments() === null){
                viewModel.allowApprovalComments("false");
            }
            if(viewModel.allowRejectionComments() === null){
                viewModel.allowRejectionComments("true");
            }
            if(viewModel.requireApprovalComments() === null){
                viewModel.requireApprovalComments("false");
            }
            if(viewModel.requireRejectionComments() === null){
                viewModel.requireRejectionComments("true");
            }
            if(viewModel.requireAuthentication() === null){
                viewModel.requireAuthentication("true");
            } 
            if(viewModel.meaningOfSignaturePicklist() === null){
                viewModel.meaningOfSignaturePicklist("false");
            }
            if(viewModel.picklistSelected() === null){
                viewModel.picklistSelected("");
            }

            //Grabbing the picklists for the meaning of signature section.
            $.when(app.context.configService.getPicklistServices()).done(function(){
				_.each(app.context.currentPicklistConfig().get("picklists").models, function(picklist){
					myPicklistNames.push(picklist.get('label'));
				});
				viewModel.picklists(myPicklistNames);
				viewModel.picklistSelected(selectedPick);
            });

		},
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
	});

    actionModules.registerAction("completeWizardApprovalRoute", action, {
        "actionId" : "completeWizardApprovalRoute",
      	"label" : (window.localize("modules.actions.completeWizardApprovalRoute.completeWizardApproval")),
      	"icon" : "ok",
      	"groups" : ["wizard", "complete", "approval"]
    });

    return action;
});
require(["completewizardapprovalroute"]);
