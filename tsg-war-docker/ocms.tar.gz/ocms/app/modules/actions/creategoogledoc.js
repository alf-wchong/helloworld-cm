define("creategoogledoc", [
	"app",
	"modules/actions/actionmodules",
	"googledocs",
	"modules/common/spinner"	
],
function(app, actionModules, GoogleDocs, HPISpinner) {
	"use strict";

	var CreateGoogleDoc = {};

	// the view for an individual option in the object type select input for the object type
	// of the new repository document to create
	CreateGoogleDoc.ObjectTypeOption = Backbone.Layout.extend({

		tagName: "option",

		initialize: function(options) {
			// get the model of the objectType passed in on the options
			var objectType = options.objectType;

			// store our value and label so we can set them on our option element after we've rendered
			this.value = objectType.get("ocName");
			this.label = objectType.get("label");
		},

		afterRender: function() {
			// set our value and text on the option element
			this.$el.val(this.value);
			this.$el.text(this.label);
		}

	});

	// the view for the select dropdown that contains the possible choices for object type to create the
	// new repository object as
	CreateGoogleDoc.ObjectTypeSelect = Backbone.Layout.extend({

		tagName: "select",

		className: "form-control",

		events: {
			"change": "objectTypeSelected"
		},

		initialize: function(options) {
			var self = this;

			// get the form the user chose to use for this action so we can pull off the configured
			// object types
			var formName = options.formName;

			// make our new collection for this select input
			this.collection = new Backbone.Collection([]);

			// get the admin OTC so we can tell which form types are document types
			app.context.configService.getAdminOTC(function(otc) {
				var typeConfigs = otc.get("configs");

				// get the form config for the chosen form for this action
				app.context.configService.getFormConfig(formName, function(formConfig) {
					// filter our object types to only be document object types
					var collection = formConfig.get("configuredTypes").filter(function(type) {
						var typeBeanName = type.get("ocName");

						// find the current type from this form in the OTC
						var typeConfig = typeConfigs.findWhere({ ocName: typeBeanName });
						if(typeConfig) {
							// return whether or not this type is a document type or not
							return typeConfig.get("isContainer") === "false";
						}

						// if we're here, then we didn't find the type on the form in the OTC
						// so we can't count it as a valid document type
						app.log.warn(window.localize("modules.actions.createGoogleDoc.createGoogleDocType") + typeBeanName + window.localize("modules.actions.createGoogleDoc.notFound"));
						return false;
					});

					// add our filtered object types (now just document types) to our collection
					self.collection.reset(collection);

					// put a blank option on the front of this collection
					self.collection.unshift(new Backbone.Model({
						ocName: "blank",
						label: ""
					}));

					// we're ready to render this dropdown now that we've got our legit options
					self.render();
				});
			});
		},

		beforeRender: function() {
			// loop over each of our object types and create an option view for each one and insert
			// each one into this select drop down
			this.collection.each(function(objectType) {
				this.insertView(new CreateGoogleDoc.ObjectTypeOption({
					objectType: objectType
				}));
			}, this);
		},

		afterRender: function() {
			// check if we have any object types resolved yet, if not, let's disabled this
			// select box until some come back
			if(this.collection.length === 0) {
				// let's trigger an event that we're loading the object types so our parent
				// can display a loading spinner
				this.trigger("creategoogledoc:loadingobjecttypes", true);

				this.$el.prop("disabled", true);
				this.$el.addClass("disabled");
			} else {
				// let's trigger an event that we're done loading the object types so our parent
				// can destroy the loading spinner
				this.trigger("creategoogledoc:loadingobjecttypes", false);

				this.$el.prop("disabled", false);
				this.$el.removeClass("disabled");
			}
		},

		// called when the user changes the value of this select input
		objectTypeSelected: function() {
			// get the value of the option the user chose for the object type
			var selectedObjectType = this.$("option:selected").val();

			// trigger the event that an object type was selected passing in the selected type
			this.trigger("creategoogledoc:objecttypeselected", selectedObjectType);
		}

	});

	// this is the main view for the action
	CreateGoogleDoc.View = Backbone.Layout.extend({
		
		template: "actions/creategoogledoc/creategoogledoc",
		
		events: {
			"click #createGoogleDocSubmit": "clickCreateGoogleDocSubmit",
			"change #googleDocType": "validateData"
		},

		initialize: function() {
			// get the action handler for this action so we can trigger the proper events
			this.actionHandler = this.options.config.get("handler");

			// get the form configured to use for this action
			var formName = this.options.config.get("form");

			// create a new select input view passing in the configured form name - this view is the
			// select input that displays the possible document object types the user can choose from to
			// create the new repository object
			this.objectTypeSelect = new CreateGoogleDoc.ObjectTypeSelect({
				formName: formName
			});

			// listen to if our object type select input is loading its options or not - we will either
			// display or hide a loading spinner depending on its status
			this.listenTo(this.objectTypeSelect, "creategoogledoc:loadingobjecttypes", function(loading) {
				// if we're loading the options, let's show the loading spinner
				if(loading) {
					// find our DOM element to attach our loading spinner to
					var spinElem = this.$("#objectTypeLoadingSpinner")[0];
					if(spinElem) {
						// animate our loading indicator with spin.js (lighter weight than animated gif)
						this.spinner = HPISpinner.createSpinner({
							top: '15px',
							left: '15px',
							color: '#000'
						}, spinElem);
					} else { // if we couldn't find the loading spinner element, let's display a warning
						app.log.warn((window.localize("modules.actions.createGoogleDoc.createGoogleDocCouldnt")));
					}
				} else { // we're done loading the object type options
					// destroy our loading spinner since we now have options
					HPISpinner.destroySpinner(this.spinner);
				}
			});

			// listen to our select input view for when the chosen object type changes
			this.listenTo(this.objectTypeSelect, "creategoogledoc:objecttypeselected", function(newObjectType) {
				// store our now selected object type on the view
				this.objectType = newObjectType;

				// validate our data - this validates both the object type and the Google document type
				// to see if we're ready to allow the user to click the "Create..." button
				this.validateData();
			}, this);

			// listen for when the user closes this action so we can refresh the containerId of the stage
			this.listenToOnce(app[this.actionHandler], "hide", function() {
				app.trigger("stage.refresh.containerId", true);
			});
		},

		beforeRender: function() {
			// let's set our select input into its container before we render
			this.setView("#objectTypeSelectContainer", this.objectTypeSelect);
		},

		afterRender: function() {
			// grab our UI elements after we've rendered so we can manipulate them when the
			// input values change
			this.ui = {
				googleDocType: this.$("#googleDocType"),
				googleDocSubmitBtn: this.$("#createGoogleDocSubmit")
			};
		},

		serialize: function() {
			return {
				modal: this.actionHandler === "modalActionHandler",
				rightSide: this.actionHandler === "rightSideActionHandler"
			};
		},

		// called when the user clicks the "Create..." button
		clickCreateGoogleDocSubmit: function() {
			var self = this;

			// we're now processing
			app[this.actionHandler].trigger("loading", true);

			// setup our state object in case the user is not authorized and they need to authorize
			// before we can create our new Google document
			var state = {
				action: "create",
				parentObjectId: app.context.container.get("objectId"),
				objectType: self.objectType,
				googleDocumentType: self.selectedDocType
			};

			// authenticate our user with Google - pass in false for the reauthorize parameter since
			// if they're already authenticated we don't want to force reauthorization right now
			GoogleDocs.authenticateUser(state, false, function(authenticateUserResult) {
				// if the result of authenticating was successful - note the user may have revoked access
				// even if we still have stored credentials
				if(authenticateUserResult.result === "success") {
					// if the user is authenticated, let's go ahead and create our Google doc
					if(authenticateUserResult.isAuthenticated) {
						self._createGoogleDoc(state);
					} else {
						// this user is not authenticated, show the message they must authorize HPI with their account
						app[self.actionHandler].trigger("loading", false);
						self._showReauthorizationMessage();
					}
				} else {
					// we got an error checking the authentication or fetching a new authorization URL
					app[self.actionHandler].trigger("loading", false);
					app[self.actionHandler].trigger("showError", authenticateUserResult.errorMsg);	
				}
			});
		},	

		// called once the authentication is successful to create our Google document - the actual call
		// to create the Google document may return a 401 if the user revoked access in which case we'll reauthorize
		_createGoogleDoc: function(state) {
			var self = this;

			// create our Google Doc - pass false for the replace parameter so a new window is opened for
			// the user to edit the newly created Google document
			GoogleDocs.createGoogleDoc(state, false, function(createGoogleDocResult) {
				app[self.actionHandler].trigger("loading", false);

				if(createGoogleDocResult.result === "success") {
					// if the user must reauthorize before we can create the Google document, show them that message
					if(createGoogleDocResult.reauthorize) {
						self._showReauthorizationMessage();
					} else {
						// show the user a message that their document was created successfully and opened for editing
						// in a new window
						app[self.actionHandler].trigger("showMessage", (window.localize("modules.actions.createGoogleDoc.google")) + self.selectedDocType + (window.localize("modules.actions.createGoogleDoc.successfullyCreate")) + self.selectedDocType + ".");
					}
				} else { // there was an error creating the Google document so show that error
					app[self.actionHandler].trigger("showError", createGoogleDocResult.errorMsg);
				}
			});
		},

		// called when a user must reauthorize HPI with their Google account before we can create the new Google document
		_showReauthorizationMessage: function() {
			// change this text on this action to tell the user to use the newly opened window to authorize
			// HPI to manipulate their Google Docs and then to edit the new document
			app[this.actionHandler].trigger("showMessage", (window.localize("modules.actions.createGoogleDoc.pleaseUse")) + this.selectedDocType + ".");
		},

		// validates the object type for the repository object and the type for the Google document
		// to ensure both are selected before the user can click the "Create..." button
		validateData: function() {
			// get the value of our Google document type to create
			this.selectedDocType = this.ui.googleDocType.find("option:selected").val();

			// check if both the Google document type and repository object type have selected
			// values before we enable the "Create..." button
			if(this.selectedDocType && this.objectType && this.objectType !== "blank") {
				this.ui.googleDocSubmitBtn.prop("disabled", false);
				this.ui.googleDocSubmitBtn.removeClass("disabled");
			} else {
				this.ui.googleDocSubmitBtn.prop("disabled", true);
				this.ui.googleDocSubmitBtn.addClass("disabled");
			}
		}

	});

	// this is the view for the admin configuration section of this action
	CreateGoogleDoc.CustomConfigView = Backbone.Layout.extend({

		template: "hpiadmin/actions/customconfig/creategoogledocconfig",
		
		initialize: function() {
			var viewModel = this.options.viewModel;

			// we only have one configuration option for this action - the form the user
			// wants to use to allow users to select the repository object type to create
			viewModel.form = kb.observable(viewModel.model(), "form");

			// a holder for all the forms the user can choose to use for this action
			viewModel.potentialForms = ko.observableArray();

			var formSubscribePlaceholder = viewModel.form();

			// get all the potential forms the user can choose from
			app.context.configService.getFormConfigNames(function(formConfigNames) {
				viewModel.potentialForms(formConfigNames);

				// since the form value is bound from the potentialForms observable,
				// this context call will come back after the form has been gathered
				// from the config. this resets the form to the right value.
				viewModel.form(formSubscribePlaceholder);
			});
		},
		
		afterRender: function() {
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}

	});

	actionModules.registerAction("createGoogleDoc", CreateGoogleDoc, {
		"actionId": "createGoogleDoc",
		"label": "Create Google Document",
		"icon": "plus"
	});

	return CreateGoogleDoc;
});
require(["creategoogledoc"]);