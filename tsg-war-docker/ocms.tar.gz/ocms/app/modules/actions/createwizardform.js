define("createwizardform", [
        // Application.
        "app",
        "modules/tsg",
        "oc",
        "jquery",
        "modules/common/typeahead",
        "modules/actions/actionmodules",
        "module"
    ],

    // Map dependencies from above array.
    function(app, TSG, OC, $, HPITypeahead, actionModules) {

        var CreateWizardForm = {};

        CreateWizardForm.hasWorkflowDocParams = function(parameters) {
            var context;
            if (parameters && parameters.objectIds) {
                context = parameters.objectIds;
            } else if (parameters && parameters.objectId) {
                context = [parameters.objectId];
            }
            return context;
        };

        CreateWizardForm.isAutoNumbered = function(pageSetType) {
            var deferred = $.Deferred();
            TSG.services.ajaxService.isAutoNumbered(pageSetType, function(result) {
                deferred.resolve(result);
            });
            return deferred;
        };

        CreateWizardForm.fireRoute = function(url) {
            window.location = url;
        };

        CreateWizardForm.PageSets = Backbone.Collection.extend({
            url: app.serviceUrlRoot + "/aw-form/getPageSets"
        });

        CreateWizardForm.Model = Backbone.Model.extend({
            defaults: {
                pageSetType: '',
                pageSetName: '',
                isAutoNumbered: false
            },
            initialize: function(options) {
                this.options = _.defaults(options, this.defaults);
            }
        });

        CreateWizardForm.View = Backbone.Layout.extend({
            template: "actions/createwizardform",
            events: {
                'click .createWizardForm': 'onClick',
                'keydown .form-control': 'sanitizeKey',
                'keyup #formName': 'updateFormName',
                'keyup .typeahead-input': 'disableButton'
            },
            _selectOption: function(option) {
                var self = this;
                if (option) {
                    self.model.set('pageSetType', option.displayValue);
                    self.isAutoNumbered = CreateWizardForm.isAutoNumbered(option.displayValue).done(function(isAutoNumbered) {
                        if (isAutoNumbered) {
                            self.model.set('isAutoNumbered', isAutoNumbered);
                            self.ui.pageSetNameParent.addClass("hide");
                            self.ui.submitButton.removeClass("disabled");

                            return true;
                        } else {
                            self.model.set({
                                'isAutoNumbered': isAutoNumbered
                            });
                            self.ui.pageSetNameParent.removeClass("hide");
                            self.ui.submitButton.addClass("disabled");
                            //Reset the pageSetName model value and html input box value to nothing
                            self.model.set('pageSetName', '');
                            self.ui.pageSetName.val(self.model.get('pageSetName'));
                            return false;
                        }
                    });
                    self.selectedPageSet = option;
                    self.pageSetActiveVersion = option.version;
                } else {
                    self.ui.pageSetNameParent.addClass("hide");
                }
            },
            initialize: function() {
                var self = this;
                //this.undelegateEvents();
                this.action = this.options.action;
                this.model = new CreateWizardForm.Model(this.options.model || {});
                this.myHandler = this.options.config.get("handler");
                this.toggleLoader = function(bool) {
                    app[self.myHandler].trigger("loading", bool, self.myHandler);
                };
                var doc = new OC.OpenContentObject();
                doc.id = self.action.get("parameters").objectId;
                if (doc.id !== null) {
                    doc.fetch({
                        success: function() {
                            self.objectType = doc.attributes.objectType;
                            self.setup();
                        },
                        global: false
                    });
                } else {
                    self.setup();
                }
            },
            setup: function() {
                var self = this;
                self.pageSets = new CreateWizardForm.PageSets();

                self.pageSets.fetch().done(function(pageSets) {
                    pageSets.sort(function(a, b) {
                        if (a.pageSetName.toUpperCase() < b.pageSetName.toUpperCase()) {
                            return -1;
                        } else {
                            return 1;
                        }
                    });

                    self.typeahead = new HPITypeahead({
                        options: self.filterPageSets(pageSets),
                        displayKey: 'pageSetName',
                        searchOn: 'pageSetName'
                    });
                    self.listenTo(self.typeahead, 'change:selected', _.bind(self._onTypeaheadChange, self));
                    // set up a listener to check if there is just one item in the forms if so we auto select it.
                    self.attachRenderedListener();

                    self.render();
                });
            },
            // helper function for unit testing purposes
            _onTypeaheadChange: function(option) {
                // only run _selectOption if we have an instanceType to update.  
                // otherwise we will be trying to access an undefined within _selectOption
                // since the backbone event 'change' includes loss of focus within the typeahead
                // which will send back an undefined instanceType
                if(option.instanceType){ 
                    this._selectOption(option);
                }
            },
            filterPageSets: function(pageSets) {
                var filteredPageSets = [];
                if (this.config.get("wizardTypeToForm") && this.config.get("wizardTypeToForm")[this.objectType] &&
                    this.config.get("wizardTypeToForm")[this.objectType].length > 0) {
                    _.each(this.config.get("wizardTypeToForm")[this.objectType], function(pageSetName) {
                        var pageSet = _.findWhere(pageSets, {
                            pageSetName: pageSetName
                        });
                        if (pageSet) {
                            filteredPageSets.push(pageSet);
                        }
                    });
                } else {
                    filteredPageSets = pageSets;
                }

                return filteredPageSets;
            },
            //must intercept enter key on down press not keyup
            sanitizeKey: function(evt) {
                var code = evt.keyCode || evt.which;
                if (code == 13) {
                    //prevent default for enter key only
                    evt.preventDefault();
                    this.enterPressed(evt);
                }
            },
            enterPressed: function(evt) {
                var self = this;
                this.isAutoNumbered.done(function(isAutoNumbered) {
                    if ($(evt.target).val() === "") {
                        return;
                    } else if (self.ui.pageSetName.val() === "" && !isAutoNumbered) {
                        return;
                    } else {
                        self.onClick();
                    }
                });
            },
            attachRenderedListener: function() {
                var self = this;
                self.listenTo(self, 'rendered', function() {
                    if (self.pageSets.length === 1) {
                        self.typeahead.selected = self.typeahead.options[0];
                        self._selectOption(self.typeahead.options[0]);
                    }
                }, self);
            },
            updateFormName: _.throttle(function() {
                this.model.set("pageSetName", this.ui.pageSetName.val());
                if (this.model.get("pageSetName")) {
                    this.ui.submitButton.removeClass("disabled");
                } else {
                    this.ui.submitButton.addClass("disabled");
                }
            }, 200),
            disableButton: _.throttle(function(evt) {
                if ($(evt.target).val() === "") {
                    this.ui.submitButton.addClass("disabled");
                    this.ui.pageSetNameParent.addClass("hide");
                    this.model.set('pageSetName', '');
                    this.ui.pageSetName.val(this.model.get('pageSetName'));
                }
            }, 200),
            beforeRender: function() {
                if (this.typeahead) {
                    this.setView('.typeahead-outlet', this.typeahead);
                }
            },
            afterRender: function() {
                //Save all of the html elements
                this.ui = {};
                this.ui.submitButton = this.$('#createFormBtn');
                this.ui.pageSetNameParent = this.$('#formNameDiv');
                this.ui.pageSetName = this.$('#formName');
                this.trigger("rendered");
            },
            onClick: function() {
                var self = this;

                self.action.get("parameters").pageSetType = self.model.get("pageSetType");
                self.action.get("parameters").pageSetVersion = self.pageSetActiveVersion;
                self.action.get("parameters").newPsiName = self.model.get("pageSetName");

                if (self.model.get("isAutoNumbered")) {
                    self.action.get("parameters").isAutoNumbered = "true";
                    //Check for values because old browsers will not use the disable class correctly
                    if (!self.action.get("parameters").pageSetType) {
                        return false;
                    }
                } else {
                    self.action.get("parameters").isAutoNumbered = "false";
                    //Check for values because old browsers will not use the disable class correctly
                    if (!self.action.get("parameters").pageSetType || self.action.get("parameters").newPsiName === '') {
                        return false;
                    }
                }
                self.labelOrId = "labelorid";
                self.toggleLoader(true);

                // View the form in HTML5
                // if the Page Set is not auto numbered we pass in the name provided via the url as a parameter.
                var url = 'activeform/' + self.action.get("parameters").pageSetType + '/new';
                var parameters = [];
                if (!self.model.get("isAutoNumbered")) {
                    parameters.push('newPsiName=' + self.action.get("parameters").newPsiName);
                }

                //if we're calling this as the folder action, put the folder id on the url
                if (self.action.get("actionId") === "createWizardForm-wfDocumentDestination") {
                    parameters.push('folderId=' + app.context.container.get("objectId"));

                    //if inherit props from folder is true, add that flag
                    if (self.options.config.get("inheritFolderAttributes") && self.options.config.get("inheritFolderAttributes") === "true") {
                        parameters.push("getFolderProps=" + "true");
                    }
                }

                //pop on our relationname
                if (self.action.get("actionId") === "createRelatedForm") {
                    //if inherit props from folder is true, add that flag
                    if (self.options.config.get("relationName")) {
                        parameters.push("relationName=" + self.options.config.get("relationName"));
                        parameters.push('psiIdToRelate=' + self.action.get("parameters").objectId);
                    }
                }

                var workflowContext;
                if (self.action.get("actionId") === "createWizardForm-fromSingleWfDoc" ||
                    self.action.get("actionId") === "createWizardForm-fromWfDocs") {
                    workflowContext = CreateWizardForm.hasWorkflowDocParams(self.action.get("parameters"));
                }

                if (workflowContext) {
                    //append workflow document ids to the url
                    _.each(workflowContext, function(wfObjectId) {
                        parameters.push('wfDocIds=' + wfObjectId);
                    }, this);
                }
                if (parameters.length > 0) {
                    url += '?' + parameters.join('&');
                }

                // Provide the fully-qualified path for IE support - # is for IE9 support
                url = window.location.protocol + '//' + window.location.host + app.root + '#' + url;

                CreateWizardForm.fireRoute(url);
            },
            serialize: function() {
                var modal = false;
                var rightSide = false;
                if (this.myHandler === "modalActionHandler") {
                    modal = true;
                } else if (this.myHandler === "rightSideActionHandler") {
                    rightSide = true;
                }
                return {
                    modal: modal,
                    rightSide: rightSide
                };
            }
        });

        CreateWizardForm.ObjectTypeForms = function(options) {
            var self = this;

            self.model = options.model;
            // the value of the objectType
            self.objectType = options.objectType;
            self.objectTypetoForms = options.objectTypetoForms;
            self.typeLabel = ko.observable("");
            self.selectedFormType = ko.observable();
            self.selectedFormType.subscribe(function(form) {
                if (form) { // will be undefined if the caption is chosen
                    self.availableForms.remove(_.findWhere(self.availableForms(), {
                        "label": form,
                        "value": form
                    }));
                    self.selectedForms.push({
                        formName: form
                    });
                    if (!self.objectTypetoForms[self.objectType]) {
                        self.objectTypetoForms[self.objectType] = [];
                    }
                    self.objectTypetoForms[self.objectType].push(form);
                    self.model.set('wizardTypeToForm', self.objectTypetoForms);
                }
            });
            app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
                self.typeLabel(typeLabel);
            });
            self.availableForms = ko.observableArray([]);
            self.selectedForms = ko.observableArray([]);
            self.pageSets = new CreateWizardForm.PageSets();

            self.pageSets.fetch().done(function(pageSets) {
                pageSets.sort(function(a, b) {
                    if (a.pageSetName.toUpperCase() < b.pageSetName.toUpperCase()) {
                        return -1;
                    } else {
                        return 1;
                    }
                });
                _.each(pageSets, function(page) {
                    self.availableForms.push({
                        label: page.pageSetName,
                        value: page.pageSetName
                    });
                });
                _.each(self.objectTypetoForms[self.objectType], function(form) {
                    self.availableForms.remove(_.findWhere(self.availableForms(), {
                        "label": form,
                        "value": form
                    }));
                    self.selectedForms.push({
                        formName: form
                    });
                });
            });
            self.removeSelectedForm = function(form) {
                self.selectedForms.remove(_.findWhere(self.selectedForms(), {
                    "formName": form.formName
                }));
                self.availableForms.push({
                    "label": form.formName,
                    "value": form.formName
                });
                self.availableForms(_.sortBy(self.availableForms(), 'label'));
                var index = self.objectTypetoForms[self.objectType].indexOf(form);
                self.objectTypetoForms[self.objectType].splice(index, 1);
                self.model.set('wizardTypeToForm', self.objectTypetoForms);
            };
        };

        CreateWizardForm.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/createwizardformconfig",
            initialize: function() {
                var viewModel = this.options.viewModel;
                var extraParams = actionModules.getDynamicParams(this.options.viewModel.actionId());
                viewModel.isRelatedForm = ko.observable(extraParams.isRelatedForm);


                viewModel.objectTypeViewModels = ko.observableArray([]);
                viewModel.objectTypetoForms = null;
                if (viewModel.model().get("wizardTypeToForm")) {
                    viewModel.objectTypetoForms = viewModel.model().get("wizardTypeToForm");
                } else {
                    viewModel.model().set("wizardTypeToForm", {});
                    viewModel.objectTypetoForms = {};
                }

                _.each(_.keys(viewModel.objectTypetoForms), function(typeKey) {
                    if (typeKey !== "_id") {
                        viewModel.objectTypeViewModels.push(new CreateWizardForm.ObjectTypeForms({
                            objectType: typeKey,
                            model: viewModel.model(),
                            objectTypetoForms: viewModel.objectTypetoForms
                        }));
                    }
                });
                viewModel.objectTypes = ko.observableArray([]);
                app.context.configService.getAdminOTC(function(OTC) {
                    var OCTypes = _.pluck(OTC.attributes.configs.models, 'attributes');
                    _.each(OCTypes, function(ocType) {
                        if (viewModel.objectTypetoForms[ocType.ocName] === undefined) {
                            viewModel.objectTypes.push({
                                label: ocType.label,
                                value: ocType.ocName
                            });
                        }
                    });
                });
                viewModel.selectedObjectType = ko.observable();
                viewModel.selectedObjectType.subscribe(function(objectType) {
                    if (objectType) { // will be undefined if the caption is chosen
                        viewModel.objectTypeViewModels.push(new CreateWizardForm.ObjectTypeForms({
                            objectType: objectType,
                            model: viewModel.model(),
                            objectTypetoForms: viewModel.objectTypetoForms
                        }));
                        viewModel.objectTypes.remove(_.findWhere(viewModel.objectTypes(), {
                            "value": objectType
                        }));
                    }
                });
                viewModel.deleteTypePath = function(objectType) {
                    viewModel.objectTypeViewModels.remove(objectType);
                    viewModel.objectTypes.push({
                        "label": objectType.typeLabel(),
                        "value": objectType.objectType
                    });
                    viewModel.objectTypes(_.sortBy(viewModel.objectTypes(), 'label'));
                    delete viewModel.objectTypetoForms[objectType.objectType];
                    viewModel.model().set('wizardTypeToForm', viewModel.objectTypetoForms);
                };
                // default to false
                if (!viewModel.model().get("inheritFolderAttributes")) {
                    viewModel.model().set("inheritFolderAttributes", "false");
                }
                viewModel.model().set("inheritFolderAttributes", viewModel.model().get("inheritFolderAttributes"));
                viewModel.inheritFolderAttributes = ko.observable(viewModel.model().get("inheritFolderAttributes"));
                viewModel.inheritFolderAttributes.subscribe(function(inherit) {
                    viewModel.model().set('inheritFolderAttributes', inherit);
                });

                if (viewModel.isRelatedForm) {
                    viewModel.model().set("relationName", viewModel.model().get("relationName"));
                    viewModel.relationName = ko.observable(viewModel.model().get("relationName"));
                    viewModel.relationName.subscribe(function(inherit) {
                        viewModel.model().set('relationName', inherit);
                    });
                }

                //check if acceptedForms already exists
                if (!viewModel.model().get('acceptedForms')) {
                    viewModel.model().set('acceptedForms', []);
                }
                viewModel.model().set('acceptedForms', viewModel.model().get('acceptedForms'));

                viewModel.acceptedForms = ko.observableArray(viewModel.model().get('acceptedForms'));

                viewModel.acceptedForms.subscribe(function(tags) {
                    viewModel.model().set('acceptedForms', tags);
                });

                viewModel.repeatingPlaceholder = ko.observable();
                //repeating values need two extra functions for adding and removing from value
                viewModel.addValue = function() {
                    //don't add anything if it already exists in value, make sure that 
                    //only whitespace is not entered, and ensure the value is properly 
                    //trimmed when added to the array
                    if (_.indexOf(viewModel.acceptedForms(), viewModel.repeatingPlaceholder()) < 0 &&
                        viewModel.repeatingPlaceholder() &&
                        viewModel.repeatingPlaceholder().trim() !== "") {
                        viewModel.acceptedForms.push(viewModel.repeatingPlaceholder().trim());
                    }
                    viewModel.repeatingPlaceholder("");
                };

                viewModel.removeValue = function(item) {
                    viewModel.acceptedForms.remove(item);
                };
            },
            afterRender: function() {
                kb.applyBindings(this.options.viewModel, this.$el[0]);
                self.$('[data-toggle="tooltip"]').tooltip();
            }
        });

        actionModules.registerAction("createWizardForm", CreateWizardForm, {
            "actionId": "createWizardForm",
            "label": "Create Wizard Form",
            "icon": "plus",
            "groups": ["wizard", "create", "form"]
        }, {
            "isRelatedForm": false
        });
        actionModules.registerAction("createWizardForm-fromWfDocs", CreateWizardForm, {
            "actionId": "createWizardForm-fromWfDocs",
            "label": "Create Wizard Form",
            "icon": "plus"
        }, {
            "isRelatedForm": false
        });
        actionModules.registerAction("createWizardForm-fromSingleWfDoc", CreateWizardForm, {
            "actionId": "createWizardForm-fromSingleWfDoc",
            "label": "Create Wizard Form",
            "icon": "plus"
        }, {
            "isRelatedForm": false
        });
        actionModules.registerAction("createWizardForm-wfDocumentDestination", CreateWizardForm, {
            "actionId": "createWizardForm-wfDocumentDestination",
            "label": "Create Wizard Form",
            "icon": "plus"
        }, {
            "isRelatedForm": false
        });
        actionModules.registerAction("createRelatedForm", CreateWizardForm, {
            "actionId": "createRelatedForm",
            "label": (window.localize("modules.actions.createRelatedForm.createRelatedForm")),
            "icon": "plus"
        }, {
            "isRelatedForm": true
        });

        return CreateWizardForm;
    });
require(["createwizardform"]);