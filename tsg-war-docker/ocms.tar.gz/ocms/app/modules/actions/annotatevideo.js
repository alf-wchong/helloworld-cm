define("annotatevideo",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
    "use strict";

    var action = {};
    


    action.View = Backbone.Layout.extend({
        template: "actions/annotatevideo",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };

            // TODO: ACTUALLY BUILD UP THE URL TO GO TO THE VIDEO ANNOTATION APPLICATION
            window.open("http://edge2.tsgrp.com/index.html");
        },
        events: {
            "click #annotate-ok" : "dismiss"
        },
        serialize: function(){
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            
            return {
                message: (window.localize("modules.actions.annotateVideo.wereOpening")),
                modal: modal
            };
        },
        dismiss : function(){
            app.trigger("stage.refresh.documentId", true);
        }

    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("annotateVideo", action, {
       "actionId" : "annotateVideo",
        "label" : "Annotate",
        "icon" : "comments"
    });

    return action;
});
require(["annotatevideo"]);