define("signature",[
    "app",
    "modules/actions/actionmodules"
],
function(app, actionModules) {
    "use strict";

    var Signature = {};
    
    Signature.View = Backbone.Layout.extend({
        template: "actions/signature",
        initialize: function() {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
            window.open(app.openAnnotateURL +
             "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&username=" + app.user.get("loginName") + "&mode=signature");
        },
        events: {
            "click #signature-ok" : "dismiss"
        },
        serialize: function() {            
            return {
                message: (window.localize("modules.actions.signature.wereOpening")),
                modal: this.myHandler === "modalActionHandler"
            };
        },
        dismiss: function() {
            app.trigger("stage.refresh.documentId", true);
        }

    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("signature", Signature, {
       "actionId": "signature",
       "label": "Signature",
       "icon": "pen"
    });

    return Signature;
});
require(["signature"]);
