// OpenNewTab module
//@author: Bradley White
define("copytext", [
        // Application.
        "app",
        "modules/actions/actionmodules"
    ],

    // Map dependencies from above array.
    function (app, actionModules) {
        "use strict";
        //Start with declaring your id - this is the same value as in the filename between the words action. and .js
        //get the config from the namespace. The action handler is responsible for this; //

        var CopyText = {
            timeout: 2000
        };

        CopyText.View = Backbone.Layout.extend({
            initialize: function (options) {
                this.action = options.action;
                this.selectedHtml = this.action.get("parameters").selectedHtml;
                this.extractText();
                this.copyText();
            },
            extractText: function(){
                if($(this.selectedHtml).children(".link").length > 0){
                    this.textToCopy = $(this.selectedHtml).children(".link").children("a")[0].title;
                }else{
                    this.textToCopy = this.selectedHtml.innerText;
                }
            },
            copyText: function () {
                // Create a dummy input to copy the string array inside it
                var dummy = document.createElement("input");
                document.body.appendChild(dummy);
                dummy.setAttribute("id", "dummy_id");

                // Output the text into it
                document.getElementById("dummy_id").value=this.textToCopy;
                dummy.select();

                // Copy its contents to the clipboard
                document.execCommand("copy");

                // Remove it as its not needed anymore
                document.body.removeChild(dummy);

                // get localized success message
                var copyTextSuccessText = window.localize("generic.copyText.success.message");
                // Create success message div
                var successMessageHtml = '<div id="copyTextSuccessMessage" z-index="100000" class="alert alert-success" style="position: absolute; top: 0px; right: 42%;">' + copyTextSuccessText + '</div>';

                // display the success message
                $(".navbar").append(successMessageHtml);
                // highlight the cell in the table
                $(this.selectedHtml).addClass('highlightedCell');

                // After 3 seconds remove success message and un-highlight the cell
                var self = this;
                setTimeout(function(){
                    $("#copyTextSuccessMessage").remove();
                    $(self.selectedHtml).removeClass('highlightedCell');
                }, CopyText.timeout);
            }
        });

        actionModules.registerAction("copyText", CopyText, {
            "actionId": "copyText",
            "label": window.localize("generic.copyText"),
            "icon": "share-alt"
        });

        return CopyText;
    });
require(["copytext"]);