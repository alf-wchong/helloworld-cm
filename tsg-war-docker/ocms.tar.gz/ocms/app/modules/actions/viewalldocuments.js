define("viewalldocuments", [
        // Application.
        "app",
        "tableview",
        "modules/formsupport",
        "modules/actions/actionmodules",
        "modules/common/action",
        "modules/common/ocquery",
        "oc",
        "moment",
        "modules/conditions/condition",
        "modules/hpiadmin/searchconfig/searchconfig",
        "modules/hpiadmin/tracconfig/tracconfig",
        "modules/hpiadmin/hpiconfiglist",
        "modules/search/searchresultcontrols",
        "thumbnailview",
        "listview",
        "modules/search/searchresultsviewcontroller",
        "modules/common/booleanutils",
        "modules/common/hpiconstants",
        "modules/services/logstashservice",
        "modules/search/attributesearch",
        "modules/hpiadmin/common/iosswitch"
    ],

    function(app, TableView, Formsupport, actionModules, Action, OCQuery, OC,
        moment, Condition, SearchConfig, TracConfig, HPIConfigList, SearchResultControls,
        ThumbnailView, ListView, SearchResultsViewController, BooleanUtils, HPIConstants,
        LogstashService, AttributeSearch, iOSSwitch) {
        "use strict";

        var ViewAllDocuments = app.module();

        ViewAllDocuments.Views.Search = Backbone.Layout.extend({
            template: 'actions/viewalldocuments/searchresults',
            initialize: function(options) {
                this.config = options.config;
                this.searchConfigName = options.config.get('SearchConfig');
                this.initialFetchComplete = false;
                this.defaultIndicators = []; // initializing an empty array to store the knockback bindings
                //Creating the searchResultsViewController. This handles comunication and data persistence through
                // all modules that deal with search results view

                this.inAdHocQueryMode = (this.config.get("queryMode") === "AdHocQueryMode");
                this.inGetChildrenQueryMode = (this.config.get("queryMode") === "GetChildrenQueryMode");

                this.searchResultsViewController = new SearchResultsViewController.Model();

                // set the view type before building the rest of the view (needed for listeners and execute query)
                $.when(this.setInitialViewType()).done(_.bind(function() {
                    this.applyListeners();

                    //setting up the contents of the array with the bindings and their default value as a string 
                    this.defaultIndicators.push("showRedacted~:~" + options.config.get("showRedacted"));
                    this.defaultIndicators.push("showDocNotes~:~" + options.config.get("showDocNotes"));
                    this.defaultIndicators.push("showAnnotated~:~" + options.config.get("showAnnotated"));
                    this.defaultIndicators.push("showInWorkflow~:~" + options.config.get("showInWorkflow"));

                    //set up the search results based off query mode
                    if(this.inGetChildrenQueryMode) {
                        this.searchResults =  new OCQuery.Children([], {
                            context: HPIConstants.TableView.Context.VAD
                        });
                        this.searchResults.id = this.action.get('parameters').objectId;
                    } else {
                        this.searchResults = new OCQuery.Collection([], {
                            mode: "client"
                        });
                    }

                    //execute the base query to load initial results
                    this.executeQuery();
                }, this));
            },
            setInitialViewType: function() {
                // check user preferences for the last viewed viewType
                var self = this;
                var deferred = $.Deferred();
                app.context.configService.getUserPreferences(function(currentUserPreferences) {
                    self.viewType = currentUserPreferences.get("lastSearchResultView");
                    if (self.viewType === "") {
                        self.viewType = "Table View";
                    }
                    deferred.resolve();
                });
                return deferred;
            },
            executeQuery: function() {
                var self = this;

                // is it at least the second time though
                if (this.initialFetchComplete) {
                    // since there are some places of code that did not account for
                    // the user to run multiple searches, everytime a new query is run
                    // we need to remove the offending views (force them to stop listening)
                    // and reset the query snapshots
                    if (!_.isUndefined(this.thumbnailview)) {
                        this.thumbnailview.remove();
                    }
                    if (!_.isUndefined(this.listview)) {
                        this.listview.remove();
                    }

                    // remove snapshots and start fresh
                    this.searchResults.deleteSnapshot();
                    this.searchResults.deleteSnapshot('facets');
                    this.searchResultsViewController.textFilter = "";
                }

                var searchConfigDeferred = $.Deferred();
                app.context.configService.getSearchConfigByName(this.searchConfigName, function(config) {
                    self.searchConfig = config;
                    searchConfigDeferred.resolve(config);
                }, this);

                var otcDeferred = $.Deferred();
                app.context.configService.getAdminOTC(_.bind(function(otc) {
                    otcDeferred.resolve(otc);
                }, this));

                var searchQueryDeferred = $.Deferred();
                this.searchResults.searchParameters = undefined;

                $.when.apply($, [otcDeferred, searchConfigDeferred]).done(_.bind(function(otc, config) {
                    
                    if(this.isAttributeSearchQuery) {
                        this.buildAttributeQuery(searchQueryDeferred, this.attributeSearchForm);
                    }
                    else { 
                        this.buildQuery(searchQueryDeferred, otc, config);
                    }
                    

                    $.when(searchQueryDeferred).done(_.bind(function() {
                        $.when(this.sendQuery()).done(_.bind(function() {
                            this.queryPostProcessing();
                        }, this));
                    }, this));
                }, this));
            },
            buildQuery: function(searchQueryDeferred, otc, config) {
                //stash original search query for fetching all children in a folder
                //rel_parent is a cheater "fake" attribute that resolves to i_folder_id in DCTM, PARENT in Alfresco, and rel_parent_s in HBase
                var parent = {
                    "paramName": "rel_parent",
                    "paramValue": window.encodeURIComponent(app.context.container.get('objectId')), //get the id of the parent
                    "paramType": "property",
                    "logic": "and",
                    "operator": "OPERATOR_EQUALS",
                    "searchMod": "CASE_SENSITIVE"
                };
                // build list of all non-container types based on the search config
                //If we are in query mode, parse the criteria and add them to the searchParameters
                if(this.inAdHocQueryMode) {
                    var otherParams = this.buildAdHocQuery();
                    this.getChildrenParameters = otherParams;
                    this.searchResults.searchParameters = otherParams;
                }
                else{
                    this.getChildrenParameters = [
                        parent
                    ];
                    this.searchResults.searchParameters = [
                        parent
                    ];
                }
                if (window.localStorage.getItem("viewFolderTerms:lastFolderTermClicked")) {
                    var vftParam = {
                        "paramName": "allproperties",
                        "paramValue": window.localStorage.getItem("viewFolderTerms:lastFolderTermClicked"),
                        "paramType": "allproperties",
                        "logic": "and"
                    };
                    this.searchResults.searchParameters.push(vftParam);
                }

                // Get the sort key and ordering from the search attributes confiv
                var availableObjectTypeConfigs = app.context.currentAdminOTC().get('configs').models;
                var defaultAttribute = _.findWhere(config.get('sidebarConfig').get('attributeSearchConfig').get('formTypes'), {
                    // Base sorting off the first configured type in the search config that isn't a container
                    'type': _.find(config.get("formTypes"), function(formType) {
                        /*
                            We don't have any meaningful information about the formTypes since it is just an array
                            of strings so we have to find the actual config from the OTC
                        */
                        var matchingOTC = _.find(availableObjectTypeConfigs, function(config) {
                            return config.get('ocName') === formType;
                        });
                        // We don't want folders to get picked for sorting 
                        return matchingOTC.get('isContainer') === "false";
                    })
                });
                // if no non-container configs were found we'll just pull the first one since we need one to sort off of
                if (!defaultAttribute) {
                    defaultAttribute = _.findWhere(config.get('sidebarConfig').get('attributeSearchConfig').get('formTypes'), {
                        //base sorting off the first configured type in the search config
                        'type': _.first(config.get("formTypes"))
                    });
                }
                this.searchResults.state.sortKey = defaultAttribute.defaultSortAttr;
                this.searchResults.state.order = defaultAttribute.defaultSortOrder;
                //disable client-side sorting by OCQuery.Collection - rely on the server for the initial sort
                this.searchResults.comparator = null;
                _.each(config.get("formTypes"), function(ocName) {
                    var typeConfig = otc.get('configs').findWhere({
                        'ocName': ocName
                    });
                    //isContainer attr is a string
                    if (BooleanUtils.isFalsey(typeConfig.get('isContainer'))) {
                        //If we are in query mode, we want to add the type parameter as an "and" instead of the default value
                        var typeLogic = window.localStorage.getItem("viewFolderTerms:lastFolderTermClicked") ? "and" : "or";
                        if(this.inAdHocQueryMode) {
                            typeLogic = "and";
                        }

                        var type = {
                            "paramName": typeConfig.get('ocName'),
                            "paramType": "type",
                            "paramValue": typeConfig.get('ocName'),

                            // We need and if we are doing view folder terms, or if it's anything else
                            "logic": typeLogic,
                            "operator": "OPERATOR_EQUALS"
                        };
                        this.getChildrenParameters.push(type);
                        this.searchResults.searchParameters.push(type);
                    }
                }, this);
                //apply any custom parameters and resolve
                this.applySearchParameters(searchQueryDeferred, this.searchResults.searchParameters);
            },
            sendQuery: function() {
                // create the view if its configured to be on and undefined
                if (this.config.get('enableAttributeSearch') && !this.inGetChildrenQueryMode) {
                    this.searchResultsViewController.stageAttributeSearchEnabled = true;
                    // first time sending the query
                    if (!this.initialFetchComplete) {
                        // since we have to create the views in the query execution, only
                        // create the view on the first initialization query
                        this.createAttributeSearchView();
                    }
                }

                // setting this before it gets reset by query fetch
                this.preQueryViewType = this.viewType;

                //fetch results
                if (this.searchResults.client()) {
                    var documentInfoStartTime = Date.now();
                    // passing an obj to fetch with the key as defaultIndicators and value as this.defaultIndicators
                    // returning a deferred from the fetch call
                    return this.searchResults.fetch({
                        'defaultIndicators': this.defaultIndicators,
                        'searchResultsViewController': this.searchResultsViewController,
                        'headers': {"timeOCCall": "true", "requestTimestamp" : documentInfoStartTime}
                    });
                } else {
                    // returning rejected deferred here so the call does not resolve
                    var failedSendDeferred = $.Deferred();
                    return failedSendDeferred.reject();
                }

            },
            queryPostProcessing: function() {
                this.initialFetchComplete = true;
                this.render();

                if (this.isAttributeSearchQuery) {
                    // search has been successful, pass that along to the view
                    this.searchResultsViewController.tableEventsRef.trigger('attributeSearchStage:searchFinished');
                    this.isAttributeSearchQuery = false; // reset this flag
                } else {
                    // reset the search params because they are shared by the
                    // attribute search query when it is run
                    this.searchResults.searchParameters = [];
                }

                //point app.context.currentSearchConfig to the one configured for View All Documents
                app.context.currentSearchConfig(this.searchConfig);

                // because the thumbnail view relies on the grid created in the tableview
                // we have to render the tableview first no matter what
                var isThumbnailViewOn = this.preQueryViewType === "Thumbnail View";
                var isListViewOn = this.preQueryViewType === "List View";
                this.createTableView(isThumbnailViewOn, isListViewOn);

                // since the viewType has been reset we need to update it to the state before the query
                this.viewType = this.preQueryViewType;

                this.createSearchResultsControlsView();

                this.setViews({
                    "#results-outlet": this.tableView,
                    ".search-controls": this.searchResultControls
                });

                this.logDuration();
            },
            executeAttributeQuery: function(attributeForm) {
                this.isAttributeSearchQuery = true;
                this.attributeSearchForm = attributeForm;
                this.executeQuery();
            },
            logDuration: function() {
                var launchActionCompletionTime = Date.now();
                LogstashService.sendMetrics(
                    new LogstashService.PerformanceLog({
                        'eventTitle': HPIConstants.Logging.Events.LaunchAction,
                        'events': {
                            'action': this.action.get("name"),
                            'folderName': app.context.container.get("properties")[app.objectDisplayName],
                            'eventDuration': launchActionCompletionTime - this.action.get("startTime")
                        },
                        'docCount': this.searchResults.length,
                        'objectId': app.context.container.get("objectId")
                    })
                );
            },
            showThumbnails: function() {
                // If leaving standardized view and entering thumbnmail view then the search result controls will need to be re-rendered. 
                if (this.viewType.indexOf(HPIConstants.TableView.ViewType.StandardTableView) !== -1) {
                    this.renderSearchResultControls();
                }
                this.viewType = "Thumbnail View";
                this.createThumbnailView();
                this.setView("#results-outlet", this.thumbnailview).render();
            },
            showLists: function() {
                // If leaving standardized view and entering list view then the search result controls will need to be re-rendered. 
                if (this.viewType.indexOf(HPIConstants.TableView.ViewType.StandardTableView) !== -1) {
                    this.renderSearchResultControls();
                }
                this.viewType = "List View";
                this.createListView();
                this.setView("#results-outlet", this.listview).render();
            },
            showResetTableView: function() {
                this.viewType = "Reset Table View";
                this.showTable("Reset Table View");
                this.renderSearchResultControls();
            },
            showStandardizedTableView: function() {
                this.viewType = "Standardized Table View";
                this.showTable("Standardized Table View");
            },
            showTable: function(typeOfView) {
                var renderSearchResultControlsRequired = false;
                // Keeping track of which view the user from switching from.
                // If the user is coming from standardized table view then 
                // search result controls will need to be re-rendered. 
                if (this.viewType.indexOf(HPIConstants.TableView.ViewType.StandardTableView) !== -1) {
                    renderSearchResultControlsRequired = true;
                }
                if (this.searchConfig && this.searchResults.searchParameters && this.initialFetchComplete) {
                    this.viewType = typeOfView === "Reset Table View" || typeOfView === "Standardized Table View" ? typeOfView : "Table View";

                    //point app.context.currentSearchConfig to the one configured for View All Documents
                    app.context.currentSearchConfig(this.searchConfig);
                    this.createTableView();
                    this.listenToOnce(this.searchResultsViewController.tableEventsRef, "tableview:tableAfterRenderDone", function() {
                        // update page size etc after the updated tableview is rendered
                        if (renderSearchResultControlsRequired) {
                            this.renderSearchResultControls();
                        }
                    });

                    this.setView("#results-outlet", this.tableView).render();
                }
            },
            renderSearchResultControls: function() {
                // rendering again to display/hide the filter controls
                this.getView(".search-controls").render();
            },
            createTableView: function(isThumbnailViewOn, isListViewOn) {
                this.tableView = new TableView.Views.Layout({
                    searchResults: this.searchConfig,
                    collection: this.searchResults,
                    groupActions: this.searchConfig.get("resultsConfig").get("groupActionsConfig").get("actions"),
                    context: HPIConstants.TableView.Context.VAD,
                    serverside: false,
                    viewType: this.viewType,
                    config: this.config,
                    isThumbnailViewOn: isThumbnailViewOn,
                    isListViewOn: isListViewOn,
                    searchResultsViewController: this.searchResultsViewController
                });
                this.isTableViewCreated = true;
            },
            createThumbnailView: function() {
                this.thumbnailview = new ThumbnailView.View({
                    collection: this.searchResults,
                    context: HPIConstants.TableView.Context.VAD,
                    searchResultsViewController: this.searchResultsViewController,
                    handler: this.config.get('handler')
                });
            },
            createListView: function() {
                this.listview = new ListView.View({
                    collection: this.searchResults,
                    context: HPIConstants.TableView.Context.VAD,
                    searchResultsViewController: this.searchResultsViewController,
                    handler: this.config.get('handler')
                });
            },
            createSearchResultsControlsView: function() {
                this.searchResultControls = new SearchResultControls.Views.Layout({
                    searchResults: this.searchConfig,
                    collection: this.searchResults,
                    context: HPIConstants.TableView.Context.VAD,
                    hideSortControls: true,
                    viewType: this.viewType,
                    silent: true, //don't update the URL when in Stage
                    searchResultsViewController: this.searchResultsViewController
                });
            },
            createAttributeSearchView: function() {
                this.attributeSearchStageView = new AttributeSearch.Stage.View({
                    searchConfig: this.searchConfig,
                    collection: this.searchResults,
                    searchResultsViewController: this.searchResultsViewController
                });
                this.setView("#stage-attribute-search-outlet", this.attributeSearchStageView);
            },
            applySearchParameters: function(searchQueryDeferred, searchParameters) {
                //CLIENT OVERRIDES - support for async operations
                //hotspot function for applying custom search criteria beyond all docs in this folder
                searchQueryDeferred.resolve(searchParameters);
                return searchParameters;
            },
            applyListeners: function() {
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:tableAfterRenderDone', function() {
                    if (this.isTableViewCreated && this.viewType === "Thumbnail View") {
                        $('#showThumbnails-' + this.searchResultControls.cid).click();
                    }else if (this.isTableViewCreated && this.viewType === "List View") {
                            $('#showLists-' + this.searchResultControls.cid).click();
                    }
                });
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:showThumbnails', this.showThumbnails);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:showLists', this.showLists);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:showTable', this.showTable);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:showResetTableView', this.showResetTableView);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:showStandardizedTableView', this.showStandardizedTableView);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'VAD:resetQuery', this.executeQuery);
                
                // triggered within attribute search when a search is executed
                this.listenTo(app, 'stageAttributeSearch:execute', this.executeAttributeQuery);
            },
            cleanup: function() {
                //called when this view is about to be destroyed.
                //we need to manually destruct any subviews
                if (this.tableView) {
                    this.tableView.stopListening();
                    this.removeView(this.tableView);
                }
                if (this.searchResultControls) {
                    this.searchResultControls.stopListening();
                    this.removeView(this.searchResultControls);
                }
                this.stopListening();
            },
            buildAdHocQuery: function(){
                var self = this;
                var searchParameters = [];
                //Iter over search criteria and parse to correct query syntax
                _.each(this.config.get("criteria"), function(item) {
                    var value;
                    //If it is a proximity criteria, parse dates correctly, otherwise filter the arg for special argument syntax
                    if (item.isProximityOperator) {
                        value = self.buildProximitySearchValue(item.operator, item.proximityNumber, item.proximityTimeSpan);
                    } else {
                        value = self._tokenResolve(item.value);
                    }
                    var sp = {
                        logic: "and",
                        // the attribute we're searching on
                        paramName: item.attribute,
                        // the value of the attribute we're searching on
                        paramValue: value,
                        // this is a property we're searching on
                        paramType: "property",
                        operator: item.operator
                    };
                    searchParameters.push(sp);
                });

                return searchParameters;
            },
            buildAttributeQuery: function(searchQueryDeferred, attributeForm) {
                var stageAttributeSearchParams = attributeForm.searchParameters;
                var objectType = attributeForm.objectType;

                // skip parent parameter if in AdHocQueryMode
                if(!this.inAdHocQueryMode) {
                    var parent = {
                        "paramName": "rel_parent",
                        "paramValue": window.encodeURIComponent(app.context.container.get('objectId')),
                        "paramType": "property",
                        "logic": "and",
                        "operator": "OPERATOR_EQUALS",
                        "searchMod": "CASE_SENSITIVE"
                    };
                    stageAttributeSearchParams.push(parent);
                }

                var type = {
                    "paramName": objectType,
                    "paramType": "type",
                    "paramValue": objectType,
                    "logic": "and",
                    "operator": "OPERATOR_EQUALS"
                };
                stageAttributeSearchParams.push(type);

                // override existing parameters with only those from the attribute form
                this.searchResults.searchParameters = stageAttributeSearchParams;
                searchQueryDeferred.resolve(stageAttributeSearchParams);
            },
            buildProximitySearchValue: function(proximityType, proximityNumber, proximityTimeSpan) {
                if (!proximityType || !proximityNumber || !proximityTimeSpan) {
                    app.log.warn('Invalid parameters in view all documents search criteria for proximity search');
                    return;
                }

                var proximityNumberAsInt = parseInt(proximityNumber, 10);
                var startDate = moment().startOf('day');
                var endDate = moment().startOf('day');

                if (proximityType.toLowerCase() === HPIConstants.SearchCriteriaConfig.Within) {
                    startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
                    endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
                } else if (proximityType.toLowerCase() === HPIConstants.SearchCriteriaConfig.Past) {
                    startDate = startDate.subtract(proximityNumberAsInt, proximityTimeSpan);
                } else { // next
                    endDate = endDate.add(proximityNumberAsInt, proximityTimeSpan);
                }

                var value = startDate.toDate().getTime() + '|' + endDate.toDate().getTime();

                // need to tack on the actual user input parameters that way we will be able to repopulate from a different
                // day than when the query was originally ran, $*prx*$ is just a random string so we can easily split the dates from the params
                var proximityParams = '$*prx*$' + proximityType + '|' + proximityNumber + '|' + proximityTimeSpan;

                return value + proximityParams;
            },
            // we want to resolve a token that a user used in a query criteria - currently only resolves dates
            // and user information
            _tokenResolve: function(value) {
                if (value === '$date') {
                    return new Date();
                } else if (value === "$user.loginName") {
                    return app.user.get("loginName");
                } else if (value === "$user.displayName") {
                    return app.user.get("displayName");
                }
                //If arg starts with $, parse it as a context specific value
                else if (value.charAt(0) === "$"){
                    return app.context.container.get("properties")[value.slice(1)];
                } else {
                    return value;
                }
            }
        });

        ViewAllDocuments.View = ViewAllDocuments.Views.Search;

        ViewAllDocuments.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/viewalldocumentsconfig",
            events: { 
                'change .savedsearch-criteria-attr': 'changeCriteria',
                'change .searchCriteriaOp': 'changeOperator',
                'change .savedsearch-objectTypes': 'changeObjectType',
                'change .proximityNumber': 'changeProximityNumber',
                'change .proximityTimeSpan': 'changeProximityTimeSpan',
                'click  .btn-hpi': 'addCriteria',
                'click  .btn-warning': 'removeCriteria'
            },
            initialize: function() {
                var self = this;
                this.rendered = false;
                this.documentTypeVent = _.extend({}, Backbone.Events);

                this.viewModel = self.options.viewModel;
                this.model = this.viewModel.model();

                this.searchConfig = new HPIConfigList.View({
                    config: this.model,
                    configClass: SearchConfig,
                    configType: 'SearchConfig'
                });

                this.viewModel.attributeToLink = kb.observable(this.model, "attributeToLink");
                this.viewModel.attrsForDropdown = ko.observableArray([]);
                this.viewModel.showDocNotes = kb.observable(this.model, "showDocNotes");
                this.viewModel.showRedacted = kb.observable(this.model, 'showRedacted');
                this.viewModel.showAnnotated = kb.observable(this.model, 'showAnnotated');
                this.viewModel.showInWorkflow = kb.observable(this.model, 'showInWorkflow');
                this.viewModel.isFolderQuery = ko.observable(false);
                this.viewModel.queryMode = kb.observable(this.model, 'queryMode');
                this.viewModel.criteria = kb.observable(this.model, 'criteria');
                this.viewModel.allAttrs = new Backbone.Collection();
                this.viewModel.selectedType = kb.observable(this.model, "selectedType");

                // date filter
                this.viewModel.showDateFilter = kb.observable(this.model, "showDateFilter");
                // default to false
                if (this.viewModel.showDateFilter() === null) {
                    this.viewModel.showDateFilter("false");
                }

                // date filter datepicker range
                this.viewModel.startYearOffset = kb.observable(this.model, 'startYearOffset');
                // default to 50
                if (!this.viewModel.startYearOffset()) {
                    this.viewModel.startYearOffset(50);
                }

                this.viewModel.endYearOffset = kb.observable(this.model, 'endYearOffset');
                // default to 50
                if (!this.viewModel.endYearOffset()) {
                    this.viewModel.endYearOffset(50);
                }

                /* S H O W  R E D A C T E D */
                // default to false
                if (this.viewModel.showRedacted() === null) {
                    this.viewModel.showRedacted("false");
                }

                /* S H O W  D O C  N O T E S */

                // default to false
                if (this.viewModel.showDocNotes() === null) {
                    this.viewModel.showDocNotes("false");
                }

                /* S H O W  A N N O T A T E D */

                // default to false
                if (this.viewModel.showAnnotated() === null) {
                    this.viewModel.showAnnotated("false");
                }

                if (this.viewModel.queryMode() === null) {
                    this.viewModel.queryMode("FolderQueryMode");
                }

                /*S H O W  W O R K F L O W*/

                // default to false
                if (this.viewModel.showInWorkflow() === null) {
                    this.viewModel.showInWorkflow("false");
                }

                // RECENT DOCUMENT //
                this.escapeFirstSubscribe = false;
                this.viewModel.numberOfDocuments = kb.observable(this.model, "numberOfDocuments");

                this.viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
                this.viewModel.selectedDocumentType = ko.observable();
                this.viewModel.potentialAttributesCollection = new Backbone.Collection();
                this.viewModel.selectedAttributesCollection = new Backbone.Collection();



                this.viewModel.selectedAttributes = kb.observable(this.model, "objectTypeFields");

                if (this.model.get("objectTypeFields") === undefined) {
                    this.model.attributes.objectTypeFields = {};
                }

                app.context.configService.getAdminOTC(function(config) {
                    config.get("configs").each(function(typeConfig) {
                        if (typeConfig.get("isContainer") === "false") {
                            self.viewModel.availableDocumentTypesInConfig.push({
                                "label": typeConfig.get("label"),
                                "value": typeConfig.get("ocName")
                            });
                        }
                    }, this);
                    self.viewModel.selectedDocumentType(self.model.get("selectedDocumentType"));
                    self.onSelectDocumentType(self.viewModel.selectedDocumentType());
                });

                this.viewModel.form = kb.observable(this.viewModel.model(), "form");
                var formSubscribePlaceholder = this.viewModel.form();
                this.viewModel.potentialForms = ko.observableArray();
                app.context.configService.getFormConfigNames($.proxy(function(formConfigNames) {
                    this.viewModel.potentialForms(formConfigNames);
                    //since the form value is bound from the potentialForms observable,
                    //this context call will come back after the form has been gathered
                    //from the config. this resets the form to the right value.
                    this.viewModel.form(formSubscribePlaceholder);
                }, this));



                //When a new document type is chosen (or upon initial load of the config),
                //this function is called, cycling through the previously selected attributes
                //and displaying them in the right column (holdSelected), with the remaining
                //possible attributes getting displayed in the left (potentialAttributes).
                this.viewModel.selectedDocumentType.subscribe($.proxy(this.onSelectDocumentType, this));
                // END OF RECENT DOCUMENTS //

                this.setChildViews();
            },
            setChildViews: function() {
                this.enableAttributeSearch = new iOSSwitch.View({
                    model: this.viewModel.model(),
                    configModelKey: 'enableAttributeSearch',
                    switchTitle: window.localize('customConfig.viewalldocuments.attributeSearch.title'),
                    configDescription:  window.localize('customConfig.viewalldocuments.attributeSearch.info'),
                });

                this.setView('#vadConfig-enableAttributeSearch', this.enableAttributeSearch);
            },
            onSelectDocumentType: function(newVal) {
                var self = this;
                this.documentTypeVent.stopListening(this.viewModel.selectedAttributesCollection);
                if (newVal) {
                    var objectProps;
                    if (this.viewModel.selectedAttributes()) {
                        objectProps = this.viewModel.selectedAttributes()[this.viewModel.selectedDocumentType()];
                    }
                    if (!objectProps) {
                        //create new key for current object type on objectTypeFields
                        this.model.get("objectTypeFields")[this.viewModel.selectedDocumentType()] = [];
                    }
                    this.viewModel.selectedAttributesCollection.reset();
                    _.each(this.model.get("objectTypeFields")[this.viewModel.selectedDocumentType()], function(attr) {
                        this.escapeFirstSubscribe = true;
                        if (!attr.attributes) {
                            this.viewModel.selectedAttributesCollection.add({
                                'attrName': attr.attrName,
                                'attrValue': attr.attrValue
                            });
                        } else {
                            this.viewModel.selectedAttributesCollection.add({
                                'attrName': attr.attributes.attrName,
                                'attrValue': attr.attributes.attrValue
                            });
                        }
                        self.viewModel.attrsForDropdown(this.viewModel.selectedAttributesCollection.models);

                    }, this);

                    //Getting all potential attributes from the OTC
                    app.context.configService.getAdminTypeConfig(this.viewModel.selectedDocumentType(), $.proxy(function(typeConfig) {
                        this.viewModel.potentialAttributesCollection.reset();
                        _.each(typeConfig.get("attrs").models, function(attr) {
                            if ($.inArray(attr.get("ocName"), _.pluck(self.model.get("objectTypeFields")[self.viewModel.selectedDocumentType()], 'attrValue')) === -1) {
                                self.viewModel.potentialAttributesCollection.add({
                                    'attrName': attr.get("label"),
                                    'attrValue': attr.get("ocName")
                                });
                            }
                        });
                    }, this));
                    this.documentTypeVent.listenTo(this.viewModel.selectedAttributesCollection, 'add remove reset', function() {
                        //var prevObjectProps = self.viewModel.selectedAttributes()[self.model.get('selectedDocumentType')];
                        var newObjectProps = self.viewModel.selectedAttributesCollection.models;
                        self.model.get("objectTypeFields")[self.viewModel.selectedDocumentType()] = _.extend([], newObjectProps);
                        self.viewModel.attrsForDropdown(newObjectProps);
                    }, this);
                    this.model.set('selectedDocumentType', this.viewModel.selectedDocumentType());
                }

            },
            changeOperator: function(e) {
                if (!this.$(e.currentTarget).attr('id')) {
                    return;
                }
                var index = Number(this.$(e.currentTarget).attr('id').replace('searchCriteriaOp-', ''));
                var newOperator = this.$(e.currentTarget).attr('value');
                var changeOperatorCriteriaCopy =  this.viewModel.criteria().splice(0);
                if (newOperator.toLowerCase() === HPIConstants.SearchCriteriaConfig.Within ||
                    newOperator.toLowerCase() === HPIConstants.SearchCriteriaConfig.Past ||
                    newOperator.toLowerCase() === HPIConstants.SearchCriteriaConfig.Next) {
                    changeOperatorCriteriaCopy[index].isProximityOperator = true;
                } else {
                    changeOperatorCriteriaCopy[index].isProximityOperator = false;
                }
                this.viewModel.criteria(changeOperatorCriteriaCopy);
                this.renderCriteriaAttrs();
            },
            changeProximityNumber: function(e) {
                if (!this.$(e.currentTarget).attr('id')) {
                    return;
                }
                var index = Number(this.$(e.currentTarget).attr('id').replace('proximityNumber-', ''));
                var newProxNumber = this.$(e.currentTarget).attr('value');
                if(this.viewModel.criteria()){
                    this.viewModel.criteria()[index].proximityNumber = newProxNumber;
                }
            },
            changeProximityTimeSpan: function(e) {
                if (!this.$(e.currentTarget).attr('id')) {
                    return;
                }
                var index = Number(this.$(e.currentTarget).attr('id').replace('proximityTimeSpan-', ''));
                var newProxTimeSpan = this.$(e.currentTarget).attr('value');
                if(this.viewModel.criteria()){
                    this.viewModel.criteria()[index].proximityTimeSpan = newProxTimeSpan;
                }
            },
            addCriteria: function() {
                var addCriteriaCopy = [];
                if(this.viewModel.criteria()){
                    addCriteriaCopy = this.viewModel.criteria().splice(0);
                }
                addCriteriaCopy.push({ attribute: "", operator: "", value: "", isProximityOperator: false, proximityNumber: "", proximityTimeSpan: "" });
                this.viewModel.criteria(addCriteriaCopy);
                this.renderCriteriaAttrs();
            },
            removeCriteria: function() {
                var removeCriteriaCopy = [];
                if(this.viewModel.criteria()){
                    removeCriteriaCopy = this.viewModel.criteria().splice(0);
                    removeCriteriaCopy.pop();
                }
                this.viewModel.criteria(removeCriteriaCopy);
    
                this.renderCriteriaAttrs();

            },
            changeCriteria: function(e) {
                //get id and update the correct criteria
                var index = Number(this.$(e.currentTarget).attr('id').replace('savedsearch-criteria-attr-', ''));
                var criteriaAttr = this.$(e.currentTarget).val();
                this.viewModel.criteria()[index].attribute = criteriaAttr;

            },
            renderCriteriaAttrs: function() {
                //render criteria attributes
                var self = this;
                var criteriaAttrs = this.$('.savedsearch-criteria-attr');
                criteriaAttrs.empty();
                criteriaAttrs.append($("<option></option>")
                    .attr("disabled", "disabled")
                    .attr("selected", "selected"));
                //render object types
                this.viewModel.allAttrs.each(function(type) {
                    criteriaAttrs.append($("<option></option>")
                        .attr('value', type.get('ocName'))
                        .text(type.get('label')));
                });
    
                //ko seems to not like the deferreds
                //set selected criteria to the config's attribute manually
                if(this.viewModel.criteria()){
                    _.each(criteriaAttrs, function(el, index) {
                        this.$(el).val(self.viewModel.criteria()[index].attribute);
                    }, this);
                }

            },
            updateAllAttributes: function() {
                var self = this;
                var deferred = $.Deferred();
                //careful here, send the ocName, not the label
                var ocName = this.viewModel.selectedType;
                app.context.configService.getAdminTypeConfig(ocName, function(otc) {
                    //update all attributes - clear any existing ones
                    self.viewModel.allAttrs = self.viewModel.allAttrs ? self.viewModel.allAttrs.reset() : new Backbone.Collection();
                    self.viewModel.allAttrs.reset(otc.get("attrs").models);
                    deferred.resolve();
                }, this);
                return deferred.promise();
            },
            changeObjectType: function(e) {
                var self = this;
                //set to the ocName, nopt the label
                var value = this.$(e.currentTarget).attr('value');
    
                if (value !== this.viewModel.selectedType || this.viewModel.selectedType === '') {
                    this.viewModel.selectedType = value;
                    this.model.set('selectedType', this.viewModel.selectedType);

                    //clear selected types - get attributes specific to new type
                    //get all types, avalible types, then build the toss across
                    this.updateAllAttributes().done(function(){
                        self.renderCriteriaAttrs();
                    });
                    
                }
            },
            updateObjectTypes: function() {
                var self = this;
                var deferred = $.Deferred();
                //populate types for dropdown
                app.context.configService.getAdminOTC(function(freshOTC) {
                    self.objectTypes = self.objectTypes ? self.objectTypes.reset() : new Backbone.Collection();
                    freshOTC.get("configs").each(function(typeConfig) {
                        self.objectTypes.add({ name: typeConfig.get("ocName"), label: typeConfig.get("label") });
                    }, this);
                    //render object types
                    var objectTypesOutlet = self.$('.savedsearch-objectTypes');
                    objectTypesOutlet.empty();
                    objectTypesOutlet.append($("<option></option>")
                        .attr("disabled", "disabled")
                        .attr("selected", "selected"));
                    if(self.model.get("selectedType")){
                        self.viewModel.selectedType = self.model.get("selectedType");
                    }else{
                        self.viewModel.selectedType = self.objectTypes.models[0].attributes.name;
                    }
                    //render object types
                    self.objectTypes.each(function(type) {
                        objectTypesOutlet.append(
                            $("<option></option>")
                            .attr('value', type.get('name'))
                            .text(type.get('label'))
                        );
                    });
                    //select the configured type if there is one
                    objectTypesOutlet.val(self.viewModel.selectedType);
                    deferred.resolve();
                }, this);
                return deferred.promise();
            },
            beforeRender: function() {
                this.setViews({
                    '.search-hpiconfig-list': this.searchConfig
                });
            },
            afterRender: function() {
                ko.applyBindings(this.options.viewModel, this.$el[0]);
                if(!this.rendered){
                    var self = this;
                    //build object types
                    this.updateObjectTypes().done(function() {
                        if(self.viewModel.selectedType){
                            //Get Object Type model attributes
                            self.updateAllAttributes().done(function() {
                                //Render each Attribute dropdown 
                                self.renderCriteriaAttrs();           
                            });
                        }
                    }); 
                }
                this.rendered = true;  
            }
        });

        actionModules.registerAction("viewAllDocuments", ViewAllDocuments, {
            "actionId": "viewAllDocuments",
            "label": "View All Documents",
            "icon": "list",
            "handler": "rightSideActionHandler",
            "paneSize": "fullPane"
        });

        return ViewAllDocuments;

    });
require(["viewalldocuments"]);