define("exportfolder",[
  // Application.
  "app",
  "knockout",
  "knockback",
  "moment",
  "modules/actions/actionmodules",
  "modules/common/action",
  "oc",
  "foldernotes",
  "modules/common/downloadutils"
],

// Map dependencies from above array.
function(app, ko, kb, moment, actionModules, Action, OC, FolderNotes, downloadUtils) {
	"use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
	//get the config from the namespace. The action handler is responsible for this; //
	var action = {};

	action.ViewModel = function(action, myHandler, config, searchResultsViewController) {
		var self = this;

		self.config = config;
		self.folderName = ko.observable(app.context.container.get('properties').objectName);

		self.toggleLoader = function(bool) {
			app[myHandler].trigger("loading", bool);
		};

		self.submit = function() {
			action.get("parameters").fileName = this.folderName() + ".zip";
			action.get("parameters").downloadWithTags = config.get('downloadWithTags');
			action.get("parameters").objectIds = [action.get("parameters").objectId];
			this.toggleLoader(true);
			
			downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, this._iframeCallback);
		};

		self._iframeCallback = function(){
			self.toggleLoader(false);
			app[myHandler].trigger("showMessage", window.localize("stage.actions.exportFolder.downloadMessage"));
			// When exporting a folder in search view this will remove all folders that are checked
			// otherwise this will not be defined if in stage view for example
			if(searchResultsViewController){
				searchResultsViewController.tableEventsRef.trigger("search:removeAllChecked");
			}
			if(config.get("folderNotes") && config.get("folderNotes") === 'true'){
				self.createFolderNotes(action.get('parameters').objectId, action.get('parameters').fileName);
			}
		};

		self.createFolderNotes = function(objectId, fileName) {
			var self = this;
			var note_type, parentId;

            var currentDate = DateFormat.format.date(new Date(),"E, d MM yyyy hh-mm-ss sss");

            fileName = fileName.substring(0, fileName.length-4);
                
            var noteContent = "<p>" + (window.localize("modules.actions.exportFolder.user")) + app.user.get("displayName") + (window.localize("modules.actions.exportFolder.downloadedFolder")) + fileName;

            noteContent += "</p>";
            parentId = objectId;
            
            note_type = "Audit Trail";

            FolderNotes.Service.execute({
            	parameters: {
                    parentID: parentId,
                    note_content: noteContent,
                    note_rel_type: self.config.get("folderNoteRelationship"),
                    note_object_type: self.config.get("folderNoteObjectType"),
                    property_map:{
                        note_type: note_type,
                        objectName: (window.localize("modules.actions.exportFolder.folderNote"))+ currentDate + '-' + fileName
                    }
                }
            });
		};

		return self;
	};

	action.View = Backbone.Layout.extend({
		template: "actions/exportfolder",
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.searchResultsViewController = this.options.searchResultsViewController;
			this.viewModel = new action.ViewModel(this.action, this.myHandler, this.options.config, this.searchResultsViewController);
		},
		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/exportfolderconfig",
		initialize: function(){
			this.viewModel = this.options.viewModel;
			
			this.viewModel.downloadWithTags = kb.observable(this.viewModel.model(), 'downloadWithTags');
			//default folder notes integration to false
			if(this.viewModel.downloadWithTags() === null){
				this.viewModel.downloadWithTags("false");
			}

			//FOLDER NOTES INTEGRATION
            this.viewModel.folderNotes = kb.observable(this.viewModel.model(), "folderNotes");
            
            if(this.viewModel.folderNotes() === "false" ) {
                this.viewModel.folderNoteType(false);
            }
            // selected folder note type from the admin
            this.viewModel.folderNoteObjectType = kb.observable(this.viewModel.model(),"folderNoteObjectType");
            if (!this.viewModel.folderNoteObjectType()){
                this.viewModel.folderNoteObjectType((window.localize("modules.actions.exportFolder.hpiNote")));
            }
            // note type to apply to all folder notes
            this.viewModel.folderNoteType = kb.observable(this.viewModel.model(),"folderNoteType");
            if (!this.viewModel.folderNoteType()) {
                this.viewModel.folderNoteType((window.localize("modules.actions.exportFolder.folderNote")));
            }
            //selected folder note relationship from admin
            this.viewModel.folderNoteRelationship = kb.observable(this.viewModel.model(),"folderNoteRelationship");
            //END FOLDER NOTES INTEGRATION
		},
		afterRender: function(){
			kb.applyBindings(this.viewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("exportFolder", action, {
		"actionId" : "exportFolder",
		"label" : (window.localize("modules.actions.exportFolder.exportFolder")),
		"icon" : "download"
	});

	return action;

});
require(["exportfolder"]);