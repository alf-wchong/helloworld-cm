define("cancelform",[
	// Application.
	"app",
	"modules/actions/actionmodules",
	"modules/hpiadmin/common/iosswitch"
  ],
  
  // Map dependencies from above array.
function(app, actionModules, iOSSwitch)  {
	"use strict";
  
	var action = {};
  
	action.View = Backbone.Layout.extend({
		template: "actions/cancelform",
		initialize: function() {
			this.permissionToDeleteMinorVersion = true;
			this.deleteMinorVersions = true;
			this.wfDocList = [];
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.spinnerBoolHasLoaded = false;

			this.minorVersionSwitch = new iOSSwitch.View({
				model: this.options.config,
				configModelKey: "disableMinorVersions",
				switchTitle: window.localize("action.cancelForm.switchConfigMinorVersionsTitle"),
				onLabel: window.localize("generic.yes"),
				offLabel: window.localize("generic.no"),
				configDescription: window.localize("action.cancelForm.switchConfigMinorVersionsDescription")
			});
  
			var self = this;
			this.getWfDocs(this.action.get("parameters").objectId).done(function(){
				var deffs = [];
				if(self.wfDocList.length==0){
					//don't show the toggle if there aren't any workflow docs
					self.permissionToDeleteMinorVersion = false;
				}else{
					_.each(self.wfDocList, function(doc){
						var miniDef = self.checkPermission(doc).done(function(canDelete){
							if(!canDelete){
								self.permissionToDeleteMinorVersion = false;
							}
						});
						deffs.push(miniDef);
					}, self);
				}
				$.when.apply($, deffs).then(function() {
					self.spinnerBoolHasLoaded=true;
					self.render();
				});
			});
			  
			this.setViews({
				'#hpi-config-switch': this.minorVersionSwitch
			}).render();

		},
		//check for delete permissions to see if they can delete minor versions
		checkPermission: function(docId){
			return $.ajax({
				url: app.serviceUrlRoot + "/permission/delete?id=" + docId,
				global: false
			});
		},
  
		getWfDocs: function(formId) {
			var overallDeferred = new $.Deferred();  
			var deferredCalls = [];
			var getWfDocsDeffered = new $.Deferred(); 
			deferredCalls.push(getWfDocsDeffered);

			$.ajax({
				global: false,
				url: app.serviceUrlRoot + "/aw-workflow/getWFDocs?formId=" + formId,
				context:this,
				success: function(response) {
					if (response !== undefined) {
						if(response.length > 0) {
							this.wfDocList = response;
						}
					}
					getWfDocsDeffered.resolve();
				},
				error: function(){
					//just in case it can't get the WFdocs... resolve this. 
					//we don't want it to toggle forever. therefore it will cancel the form and not delete any minor versions.
					getWfDocsDeffered.resolve();
				}
			});
  
			$.when.apply($, deferredCalls).then(function() {
				overallDeferred.resolve();
			});
			return overallDeferred;
		},
  
		beforeRender: function() {
			var self = this;
			this.viewModel = {
				comments : ko.observable(),
				onSubmit : function() {
					self.onSubmit();
				}
			};
		},
			
		onSubmit: function(){
			app.log.debug("time to submit this form");
			//taskId must be on the action
			var formId = this.action.get("parameters").objectId;
			if(formId === undefined){
				app[this.myHandler].trigger("showError", (window.localize("modules.actions.cancelForm.unableToCancelForm")));
			}else{
	
				var self = this;
				app[this.myHandler].trigger("loading", true);

				this.action.get("parameters").formId = formId;
				this.action.get("parameters").comments = this.viewModel.comments();
				this.action.get("parameters").deleteMinorVersions = this.options.config.get("disableMinorVersions");

				this.action.execute({
					success : function(data) {

						app[self.myHandler].trigger("loading", false);

						app.listenToOnce(app[self.myHandler], "hide", function() {
							app.trigger("stage.refresh.bothIds", formId, formId);
						});		
						
						app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.cancelForm.formCanceledSuccess")));
					},
					error : function(jqXHR, textStatus, errorThrown) {

						app[self.myHandler].trigger("loading", false);
						app[self.myHandler].trigger("showError", (window.localize("modules.actions.cancelForm.failedToCancel")) +
								jqXHR.status + " " + jqXHR.statusText);
					}
				});
			}
		},
		afterRender: function(){
			if(!this.spinnerBoolHasLoaded){
				app[this.myHandler].trigger("loading", true);
			}else{
				app[this.myHandler].trigger("loading", false);
			}

			kb.applyBindings(this.viewModel, this.$el[0]);
		},
		serialize: function() {
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				minorVersionSwitch: this.minorVersionSwitch,
				permissionToDeleteMinorVersion: this.permissionToDeleteMinorVersion
			};
		}
	});
  
	actionModules.registerAction("cancelForm", action, {
		"actionId" : "cancelForm",
		"label" : (window.localize("modules.actions.cancelForm.cancelForm")),
		"icon" : "stop",
		"groups" : ["wizard", "cancel", "form"]
	});

	return action;
});

require(["cancelform"]);