define("managerelations", [
	"app",
	"modules/actions/actionmodules",
	"modules/common/action",
	"oc",
	"modules/common/ocquery",
	"modules/common/spinner",
	"module",
	"modules/hpiadmin/actionconfig/actions/managerelations/managerelationscustomconfig"
],

function(app, actionModules, Action, OC, OcQuery, HPISpinner, module, ManageRelationsCustomConfig){
	"use strict";

	var ManageRelations = {};

	var manageRelationsVent = _.extend({}, Backbone.Events);

	ManageRelations.CustomConfigView = ManageRelationsCustomConfig.View;

	ManageRelations.Config = Backbone.Model.extend({	
		//hotspot function for getting table headers and associated attributes
		initialize: function(options) {
			this.config = options.config;
		},
		getAttributes: function(){
			var configAttrs = this.config.get('searchResultAttrs');

			if(configAttrs instanceof Backbone.Collection) {
				configAttrs = _.pluck(configAttrs.models, 'attributes');
			}

			//Parse Configs
			var retVal = [];
			_.each(configAttrs, function(attr, index) {
				var curAttr = {};
				if(index === 0) {
					curAttr.createLink = true;
				}

				curAttr.displayName = attr.displayValue;
				curAttr.ocoName = attr.value;
				retVal.push(curAttr);
			});

			return retVal;
		},
		getLocalizations: function(){
			return {
				tabs: {
					existingRelations : window.localize('modules.actions.manageRelations.existingRelationTabHeader'),
					addNewRelations : window.localize('modules.actions.manageRelations.newRelationTabHeader')
				},
				add: {
					success: window.localize('modules.actions.manageRelations.addRelationSuccess'),
					failure: window.localize('modules.actions.manageRelations.addRelationError')
				},
				remove: {
					success: window.localize('modules.actions.manageRelations.removeRelationSuccess'),
					failure: window.localize('modules.actions.manageRelations.removeRelationError')
				},
				validate: {
					message: window.localize('modules.actions.manageRelations.invalidDocMessage')
				},
				placeholder: window.localize('modules.actions.manageRelations.searchPlaceholder'),
				instructions: window.localize('modules.actions.manageRelations.instructions'),
				existingDocumentsInstructions: window.localize('modules.actions.manageRelations.existingDocumentsInstructions'),
				errorMessage: window.localize('modules.actions.manageRelations.errorMessage'),
				noRelsFound: window.localize('modules.actions.manageRelations.noRelationsFound'),
				noRelsSelected : window.localize('modules.actions.manageRelations.noRelationsSelected'),
				btns : {
					removeRelBtn : window.localize('modules.actions.manageRelations.buttonRemoveRelation'),
					addRelBtn : window.localize('modules.actions.manageRelations.buttonAddRelation')
				}
			};
		},
		getSearchParameters: function(searchTerm, docQuery){
			var searchParams = docQuery.searchParameters = [];

			//Set search term input
			var searchParam = this.config.get('searchAttribute');
			searchParams.push({
				paramName: searchParam,
				paramValue: searchTerm,
				paramType: "property",
				isSearchTermInput: true
			});

			//Set search result limit
			var searchLimit = this.config.get('searchResultLimit');
			if(searchLimit !== undefined && searchLimit !== -1) {
				searchParams.push({
					paramName: "limit_results",
					paramType: "options",
					paramValue: searchLimit,
				});
			}

			//Set object type
			var objectType = this.config.get('searchObjectType');
			searchParams.push({
				paramType: "type",
				paramValue: objectType,
				paramName: objectType
			});

			//Set additional attribute criteria
			var attrCriteria = this.config.get('searchCriteria');
			_.each(attrCriteria, function(entry) {
				searchParams.push({
					paramName: entry.attrName,
					paramValue: entry.attrValue,
					paramType: "property",
					operator: 'OPERATOR_EQUALS'
				});
			});

			//Set search all versions (not in configs, this should always be true)
			searchParams.push({
				paramName: "searchallversions",
				paramValue: "true",
				paramType: "searchallversions"
			});

			return searchParams;
		},
		validate: function(){
			var deferred = $.Deferred();
			//validation for this selected doc
			deferred.resolve(undefined);
			return deferred;
		},
		openLink: function(event){
			window.open(app.root + "StageSimple/" + event.target.id);
		}
	});

	ManageRelations.View = Backbone.Layout.extend({
		template: "actions/managerelations/managerelations",
		events: {
			"click .manageRelationsTab": "tabClicked"
		},
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.relationNames = this.options.config.get("relationNames");
			this.twoWayRelation = this.options.config.get("twoWayRelation");
			this.primaryId = this.action.get("parameters").objectId;

			if(!_.has(this, 'configHelper')) {
				this.configHelper = new ManageRelations.Config(this.options);
			}

			//create our tabs
			this.tabs = [{
				"id": "existingRelationsTab",
				"name": this.getOverrides().getLocalizations().tabs.existingRelations,
				"active": true
			},
			{
				"id": "addRelationsTab",
				"name": this.getOverrides().getLocalizations().tabs.addNewRelations,
				"active": false
			}];

			//reset listeners to avoid mem leak
			this.stopListening(manageRelationsVent);

			this.listenTo(manageRelationsVent, 'managerelations:show:existing:relations', function(){
				this.createView('existingRelationsTab');
			}, this);

			this.listenTo(manageRelationsVent, 'managerelations:show:add:relations', function(){
				this.createView('addRelationsTab');
			}, this);
		},
		tabClicked: function(e){
			//get id, will tell us what tab was clicked
			var $el = $(e.currentTarget);
			var id = $el.attr("id");

			//only do something if this tab isn't the active one
			if(!$el.hasClass("active")){
				this.createView(id);
			}
		},
		createView: function(tabName){
			if(tabName === "existingRelationsTab"){
				this.existingRelationsView = new ManageRelations.ExistingRelationsView({
					"action": this.action,
					"relationNames": this.relationNames,
					"twoWayRelation": this.twoWayRelation,
					"myHandler": this.myHandler,
					"config": this.getOverrides(),
					"primaryId": this.primaryId
				});
				this.switchViews("existingRelationsTab", this.existingRelationsView);
			}else if(tabName === "addRelationsTab"){
				this.addRelationsView = new ManageRelations.AddRelationsView({
					"action": this.action,
					"relationNames": this.relationNames,
					"twoWayRelation": this.twoWayRelation,
					"myHandler": this.myHandler,
					"config": this.getOverrides(),
					"primaryId": this.primaryId
				});
				this.switchViews("addRelationsTab", this.addRelationsView);
			}
		},
		switchViews: function(tabId, newView){
			//remove old view
			this.removeView("#manageRelationsSubView");
			this.setView("#manageRelationsSubView", newView, true).render();
			$(".manageRelationsTab").removeClass("active");
			$("#" + tabId).addClass("active");
		},
		getOverrides: function(){
			return this.configHelper;
		},
		serialize: function(){
			var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                tabs: this.tabs
            };
		},
		afterRender: function(){
			//create our existing relationships view and insert it
			this.existingRelationsView = new ManageRelations.ExistingRelationsView({
				"relationNames": this.relationNames,
				"twoWayRelation": this.twoWayRelation,
				"action": this.action,
				"myHandler": this.myHandler,
				"config": this.getOverrides(),
				"primaryId": this.primaryId
			});
			this.setView("#manageRelationsSubView", this.existingRelationsView, true).render();
		}

	});
	
	//Models
	ManageRelations.Document = Backbone.Model.extend({
		defaults: function(){
			return _.extend({}, {
				objectId: '',
				selectedRelation: '',
				oco: {},
				message: ''
			});
		},
		initialize: function(options){
			this.options = _.defaults(options, this.defaults);
			if(this.options.oco){
				this._id = this.options.oco.objectId;
				this.set('objectId', this.options.oco.objectId);
				this.set('selectedRelation', this.options.selectedRelation);
			}
		},
		validate: function(){
			return this.get('message');
		}
	});

	ManageRelations.Documents = Backbone.Collection.extend({
		model: ManageRelations.Document,
		initialize: function(options, config){
			this.config = config;
		},
		isValid: function(){
			return this.validate() ? false : true;
		},
		validate: function(){
			var docsValid = true;
			if(this.size() === 0){
				return this.config.getLocalizations().noRelsSelected;
			}
			this.each(function(doc){
				if(docsValid){
					docsValid = doc.isValid();
				}
			}, this);
			return docsValid ? undefined : this.config.getLocalizations().errorMessage;
		}
	});

	//Views
	ManageRelations.DocumentRow = Backbone.Layout.extend({
		tagName: 'tr',
		template: 'actions/managerelations/documentrow',
		events: {
			'click .addDocCheckbox': 'validate'
		},
		initialize: function(options){
			this.config = options.config;
			this.attrs = this.config.getAttributes();
			this.model = options.model || new ManageRelations.Document();
			//order is based off of the order of the attrs array
			this.serializedAttributes = [];
			_.each(this.attrs, function(attr){
				if(attr.createLink){
					//generate a direct content link
					var attrValue = this.model.get('oco')[attr.ocoName];
					// TODO - have this link pop up the document in Pane 3 in Stage instead of opening a new tab
					var url = '<a data-bypass target="_blank" class="manageRelationsLink" href="' + app.serviceUrlRoot + '/content/content/' + encodeURIComponent(attrValue) + '?id=' + this.model.get('objectId') + '&contentType[]=pdf&overlay=true' + '">' + attrValue + '</a>';
					this.serializedAttributes.push(url);
				}else{
					this.serializedAttributes.push(this.model.get('oco')[attr.ocoName]);
				}
			}, this);

			//whenever this doc is validated, re-render and show the message
			this.listenTo(this.model, 'change:message', function(obj, message){
				this.$('.message').html(message);
			}, this);
			
			this.listenTo(this.model, 'set:checkbox', function(checked){
				this.$('input[type=checkbox]').prop('checked', checked);
			});
		},
		validate: function(evt){
			var self = this;
			var isChecked = this.$(evt.currentTarget).is(':checked');
			//if checked and no message, validate
			if(isChecked && !this.model.get('message')){
				var isValid = this.config.validate(this.model.get('oco'));
				$.when(isValid).done(function(message){
					self.model.set('message', message);
					//make row red if ther's a message
					if(message){
						self.$el.addClass('danger');
					}
					self.model.trigger('pendingrelations:add');
				});
			}else if(!isChecked){
				this.model.trigger('pendingrelations:remove');
			}else if(isChecked){
				//already validated one way or the other
				self.model.trigger('pendingrelations:add');
			}
		},
		serialize: function(){
			return {
				'config': this.config,
				'attributes': this.serializedAttributes,
				'model': this.model.attributes,
				'message': this.model.get('message')
			};
		}
	});

	ManageRelations.ExistingDocumentRow = ManageRelations.DocumentRow.extend({
		validate: function(evt){
			var self = this;
			var isChecked = this.$(evt.currentTarget).is(':checked');
			if(isChecked){
				//already validated one way or the other
				self.model.trigger('pendingrelations:add');
			}else{
				this.model.trigger('pendingrelations:remove');
			}
		}
	});

	ManageRelations.DocumentsTable = Backbone.Layout.extend({
		template: 'actions/managerelations/documentstable',
		initialize: function(options){
			this.config = options.config;
			this.headers = _.pluck(this.config.getAttributes(), 'displayName');

			this.config.showRelations = options.showRelations !== undefined ? options.showRelations : false;

			//if showing relationship names add a header for it
			if(this.config.showRelations){
				this.headers.push('Relation');
			}
			this.pendingRelations = options.pendingRelations || new ManageRelations.Documents(undefined, this.config);

			this.documents = options.documents || new ManageRelations.Documents(undefined, this.config);

			this.listenTo(this.documents, 'reset', this.reload, this);
		},
		reload: function(){
			this.render();
			this.removeView('.document-rows-outlet');
			this.documents.each(function(model){
				this.stopListening(model);
				//listen for this doc to be added or removed from the pending queue
				this.listenTo(model, 'pendingrelations:add', function(){
					this.pendingRelations.add(model);
					this.documents.trigger('check', model);
				}, this);
				this.listenTo(model, 'pendingrelations:remove', function(){
					this.pendingRelations.remove(model);
					this.documents.trigger('uncheck', model);
				}, this);
				this.insertView('.document-rows-outlet', new ManageRelations.DocumentRow({
					'config': this.config,
					'model': model
				})).render();
			}, this);
		},
		serialize: function(){
			return _.extend({
				'headers': this.headers,
				'showTable': this.documents.length
			}, this.config.getLocalizations());
		}
	});

	ManageRelations.ExistingDocumentsTable = ManageRelations.DocumentsTable.extend({
		template: 'actions/managerelations/existingdocumentstable',
		reload: function(){
			this.render();
			this.removeView('.document-rows-outlet');
			this.documents.each(function(model){
				this.stopListening(model);
				//listen for this doc to be added or removed from the pending queue
				this.listenTo(model, 'pendingrelations:add', function(){
					this.pendingRelations.add(model);
				}, this);
				this.listenTo(model, 'pendingrelations:remove', function(){
					this.pendingRelations.remove(model);
				}, this);
				this.insertView('.document-rows-outlet', new ManageRelations.ExistingDocumentRow({
					'config': this.config,
					'model': model
				})).render();
			}, this);
		}
	});

	ManageRelations.SearchControl = Backbone.Layout.extend({
		template: 'actions/managerelations/searchcontrol',
		events: {
			'keydown .typeahead-input': 'sanitizeKey',
			'keyup .typeahead-input': 'update',
			'click .executeSearchBtn': 'execute'
		},
		initialize: function(options){
			this.isSearching = false;
			this.config = options.config;
			this.selectedRelation = options.selectedRelation || '';
			this.placeholder = options.placeholder || this.config.getLocalizations().placeholder;
			this.query = options.query;

			//execute an ocquery
			this.docQuery = new OcQuery.Collection([],{
				mode: "client"
			});	

			this.docQuery.searchParameters = this.config.getSearchParameters(this.query, this.docQuery);

			this.formOCO = new OC.OpenContentObject({ objectId : app.context.document.attributes.properties.objectId });
			this.formOCO.fetch({context: this}).done(function(formOCO) {
				_.each(this.docQuery.searchParameters, function(searchParameter) {
					if (typeof searchParameter.paramValue === "string" && searchParameter.paramValue.includes("$")) {
						var tokenValue = app.context.util.parsePatternForAttributes(searchParameter.paramValue)[0];
						searchParameter.paramValue = formOCO.properties[tokenValue];
					}
				});
			});
		},
		sanitizeKey: _.throttle(function(evt){
            //catch the enter key to prevent the query text being set as the selected user
            var code = evt.keyCode || evt.which;
            if(code === 13){
            	evt.preventDefault();
            }
		}, 200, this),
		update: _.throttle(function(evt){
			this.query = this.$(evt.currentTarget).val();
			var code = evt.keyCode || evt.which;
           	var queryOK = this.checkQuery();
           	if(queryOK && code === 13){
           		//prevent default for enter key only    
                this.execute(evt);
           	}
		}, 200, this),
		execute: function(evt){
			evt.preventDefault(); //stop form submission
			this.isSearching = true;
			this.spinner = HPISpinner.createSpinner({
				top: '50%',
				left: '102%',
                color: '#666'
            }, this.$el.find(".searchSpinnerDiv")[0]);

			this.docQuery.searchParameters = this.config.getSearchParameters(this.query, this.docQuery);
			this.executeSearchQuery(this.docQuery);
		},
		executeSearchQuery: function(docQuery) {
			var self = this;
			docQuery.fetch({
				success: function(data){
					var ocos = [];
					if(data.length !== 0){
						data.fullCollection.each(function(oco){
							ocos.push(_.extend({}, oco.get("properties"), {
								"objectId": oco.get("objectId"),
								"objectName": oco.get("properties").objectName,
								"title": oco.get("properties").title
							}));
						});
					}
					self.isSearching = false;
					if(self.spinner){
						HPISpinner.destroySpinner(self.spinner);
					}
					self.trigger('search:results', ocos);
				},
				error: function(){
					app.log.error("MANAGE RELATIONS: Failed to retrieve search results for related docs");
					if(self.spinner){
						HPISpinner.destroySpinner(self.spinner);
					}
				},
				//don't gray out screen on ajax request
				global: false
			});
		},
		checkQuery: function(){
			if(this.query && this.query.length >= 3 && this.selectedRelation){ //min three character length
				this.$('.executeSearchBtn').removeClass('disabled');
				this.$('.executeSearchBtn').removeAttr('disabled');
				this.$('.message-output').text('');
				return true;
			}else if(!this.selectedRelation){
				this.$('.executeSearchBtn').addClass('disabled');
				//IE 9-10 support - double tap disabled buttons
				this.$('.executeSearchBtn').attr('disabled', 'disabled');
				this.$('.message-output').text('please select a relationship');
				return false;
			}else if(!this.query || this.query.length < 3){
				this.$('.executeSearchBtn').addClass('disabled');
				//IE 9-10 support - double tap disabled buttons
				this.$('.executeSearchBtn').attr('disabled', 'disabled');
				this.$('.message-output').text('three characters minimum');
				return false;
			}
		},
		updateRelationship: function(relationship){
			this.selectedRelation = relationship;
		},
		afterRender: function(){
			this.checkQuery();
		},
		serialize: function(){
			return {
				'placeholder': this.placeholder
			};
		}
	});

	ManageRelations.AddRelationsView = Backbone.Layout.extend({
		template: "actions/managerelations/addrelations",
		events: {
			"click .addRelationButton": "addRelations",
			"change .relationNameSelect": "updateSelectedRelation"
		},
		initialize: function(){
			this.config = this.options.config;
			this.relationNames = this.options.relationNames || [];
			this.twoWayRelation = this.options.twoWayRelation || true;
			this.primaryId = this.options.primaryId;
			this.showRelations = true;
			this.action = this.options.action;
			this.myHandler = this.options.myHandler;
			this.selectedRelation = undefined;
			this.searchResults = new ManageRelations.Documents(undefined, this.config);
			this.pendingRelations = new ManageRelations.Documents(undefined, this.config);
			this.allRelationDocsValid = false;
			//listen for pending relations and check if all are valid
			this.listenTo(this.pendingRelations, 'add remove reset', function(){
				var status = this.pendingRelations.validate();
				this.allRelationDocsValid = this.pendingRelations.isValid();
				if(this.allRelationDocsValid){
					this.$('.addRelationButton').removeClass('disabled');
					this.$('.addRelationButton').removeAttr('disabled');
					this.$('.status-message').addClass('hide');
				}else if(this.pendingRelations.size() > 0){
					this.$('.addRelationButton').addClass('disabled');
					//IE 9-10 support - double tap disabled buttons
					this.$('.addRelationButton').attr('disabled', 'disabled');
					this.$('.status-message').text(status).removeClass('hide');
				}
			}, this);

			//preselect selectedRelation if only one relation is configured
			if(this.relationNames.length === 1){
				this.selectedRelation = this.relationNames[0];
				this.showRelations = false;
			}

			this.searchResultsTable = new ManageRelations.DocumentsTable({
				'showRelations': this.showRelations,
				'pendingRelations': this.pendingRelations,
				'documents': this.searchResults,
				'config': this.config
			});

			this.searchBoxControl = new ManageRelations.SearchControl({
				'config': this.config,
				'selectedRelation': this.selectedRelation
			});

			this.listenTo(this.searchBoxControl, 'search:results', function(ocos){
				//build Document models from the search results
				var documents = [];
				_.each(ocos, function(oco){
					//get oco and the currently set relation name
					documents.push(new ManageRelations.Document({
						'selectedRelation': this.selectedRelation,
						'oco': oco
					}));
				}, this);
				//clear out any previously selected docs
				this.pendingRelations.reset();
				this.searchResults.reset(documents);
			}, this);
		},
		addRelations: function(){
			var self = this;

			app[this.myHandler].trigger("loading", true);
			//setup our relation map
			var relationMap = {};
			this.pendingRelations.each(function(docObj){
				if(!relationMap[docObj.get('selectedRelation')]){
					relationMap[docObj.get('selectedRelation')] = [];
				}
				relationMap[docObj.get('selectedRelation')].push(docObj.get('objectId'));
			});
			this.action.get("parameters").relationMap = relationMap;
			this.action.get("parameters").removeRelation = false;
			this.action.execute({
				success: function(){
					app[self.myHandler].trigger("loading", false);
					self.$("#" + self.myHandler + "-message").html(self.config.getLocalizations().add.success).show();
					setTimeout(function(){
						$("#" + self.myHandler + "-message").hide();
					}, 2000);
					manageRelationsVent.trigger('managerelations:show:existing:relations');
					app.trigger("stage.refresh.bothIds", app.context.container.id, app.context.document.id);
				},
				error: function(){
					app[self.myHandler].trigger("loading", false);
					self.$("#" + self.myHandler + "-error").html(self.config.getLocalizations().add.failure).show();
					setTimeout(function(){
						$("#" + self.myHandler + "-error").hide();
					}, 2000);
				}
			});
		},
		updateSelectedRelation: function(){
			var newRelationship = this.$('.relationNameSelect').val();
			if(newRelationship !== this.selectedRelation){
				this.selectedRelation = newRelationship;
				this.searchBoxControl.updateRelationship(this.selectedRelation);
				this.searchBoxControl.checkQuery();
				//uncheck all checked models
				this.searchResults.reset(this.searchResults.models);
				this.pendingRelations.reset([]); //clear out relations of the previous name
			}
		},
		beforeRender: function(){
			this.setView('.search-control-outlet', this.searchBoxControl);
			this.setView('.search-results-table-outlet', this.searchResultsTable);
		},
		afterRender: function(){
			if(this.selectedRelation){
				this.$('select').val(this.selectedRelation);
				this.searchBoxControl.updateRelationship(this.selectedRelation);
				this.searchBoxControl.checkQuery();
				this.pendingRelations.reset([]); //clear out relations of the previous name
			}
		},
		serialize: function(){
			return _.extend({
				'relationNames': this.relationNames,
				'twoWayRelation': this.twoWayRelation,
				'showRelations': this.showRelations,
				'allRelationDocsValid': this.allRelationDocsValid
			}, this.config.getLocalizations());
		}
	});
	
	ManageRelations.ExistingRelationsView = Backbone.Layout.extend({
		template: "actions/managerelations/existingrelations",
		events: {
			"click .removeRelationsButton": "removeRelations",
			"change .relationNameSelect": "updateSelectedRelation"
		},
		initialize: function(){
			this.config = this.options.config;
			this.relationNames = this.options.relationNames;
			this.twoWayRelation = this.options.twoWayRelation;
			this.action = this.options.action;
			this.myHandler = this.options.myHandler;
			this.primaryId = this.options.primaryId;
			this.selectedRelation = this.relationNames[0];
			this.showRelations = true;
			this.pendingRelations = new ManageRelations.Documents(undefined, this.config);
			this.existingRelations = new ManageRelations.Documents(undefined, this.config);

			//preselect selectedRelation if only one relation is configured
			if(this.relationNames.length === 1){
				this.showRelations = false;
			}

			this.existingRelationsTable = new ManageRelations.ExistingDocumentsTable({
				//dont show relationship name since it was already selected
				'pendingRelations': this.pendingRelations,
				'documents': this.existingRelations,
				'config': this.config
			});

			this.applyListeners();
		},
		applyListeners: function() {
			//listen for pending relations and check if all are valid
			this.listenTo(this.pendingRelations, 'add remove', function(){
				this.allRelationDocsValid = this.pendingRelations.isValid();
				if(this.allRelationDocsValid){
					this.$('.removeRelationsButton').removeClass('disabled');
				}else{
					this.$('.removeRelationsButton').addClass('disabled');
				}
			}, this);	
		},
		getExistingRelations: function(){
			var self = this;
			this.spinner = HPISpinner.createSpinner({
				top: '50%',
				left: '102%',
                color: '#666'
            }, this.$el.find(".loadRelationDiv")[0]);

			var url;
			if(this.twoWayRelation == "true") {
				url = app.serviceUrlRoot + "/content/getRelationsByCategory?id=" + this.action.get("parameters").objectId  +
				"&relationName=" + this.selectedRelation;
			} else{
				url = app.serviceUrlRoot + "/content/getChildRelations?id=" + this.action.get("parameters").objectId  +
				"&relationName=" + this.selectedRelation;
			}
			return $.ajax({
				url: url,
				type: "GET",
				context: this,
				success: function(parentAndChildOcos){
					var parentOcos = [];
					var childOcos = [];
					var allOcos = [];
					if (parentAndChildOcos.Parents && parentAndChildOcos.Children) { 
						var parentCollection = new OC.OpenContentObjectCollection(parentAndChildOcos.Parents);
						var childCollection = new OC.OpenContentObjectCollection(parentAndChildOcos.Children);
	
						parentCollection.each(function(oco){
							parentOcos.push(_.extend({}, oco.get("properties"), {
								"objectId": oco.get("objectId"),
								"objectName": oco.get("properties").objectName,
								"title": oco.get("properties").title
							}));
						});
						childCollection.each(function(oco){
							childOcos.push(_.extend({}, oco.get("properties"), {
								"objectId": oco.get("objectId"),
								"objectName": oco.get("properties").objectName,
								"title": oco.get("properties").title
							}));
						});
	
	
						this.parentCollection = parentCollection;
						this.childCollection = childCollection;
	
						_.each(childOcos, function(oco){
							allOcos.push(oco);
						});
						
						_.each(parentOcos, function(oco){
							allOcos.push(oco);
						});
					} else {
						var fullCollection = new OC.OpenContentObjectCollection(parentAndChildOcos);
						fullCollection.each(function(oco){
							allOcos.push(_.extend({}, oco.get("properties"), {
								"objectId": oco.get("objectId"),
								"objectName": oco.get("properties").objectName,
								"title": oco.get("properties").title
							}));
						});
					}

					//build up Document models
					var documents = [];
					_.each(allOcos, function(oco){
						//get oco and the currently set relation name
						documents.push(new ManageRelations.Document({
							'selectedRelation': self.selectedRelation,
							'oco': oco
						}));
					}, this);
					self.existingRelations.reset(documents);
					//wait a sec
					window.setTimeout(function(){
						if(self.spinner){
							HPISpinner.destroySpinner(self.spinner);
						}
					}, 1000);
				},
				error: function(){
					if(self.spinner){
						HPISpinner.destroySpinner(self.spinner);
					}
					app.log.debug("Error getting existing relations");
				}
			});	
		},
		updateSelectedRelation: function(){
			this.selectedRelation = this.$('.relationNameSelect').val();
			this.getExistingRelations();
		},
		openLink: function(event){
			this.config.openLink(event);		
		},
		removeRelations: function(){
			var self = this;

			app[self.myHandler].trigger("loading", true);
			//remove relations
			var relationMap = {};
			relationMap[this.selectedRelation] = this.pendingRelations.pluck('objectId');

			this.action.get("parameters").relationMap = relationMap;
			this.action.get("parameters").removeRelation = true;

			var parentObjectIds= [];
			if (this.parentCollection) {
				_.each(this.parentCollection.models, function(model){
					parentObjectIds.push(model.get("objectId"));
				});
				this.parentObjectIds = parentObjectIds;
			}

			var map = {};

			_.each(this.pendingRelations.pluck('objectId'), function(objIdToRemove){
				if(this.parentObjectIds && this.parentObjectIds.includes(objIdToRemove)){
					if (map[objIdToRemove] == undefined){
						map[objIdToRemove] = [this.action.get("parameters").objectId];
					} else{
						map[objIdToRemove].push(this.action.get("parameters").objectId);
					} 
					
				}else{
					if (map[this.action.get("parameters").objectId] == undefined){
						map[this.action.get("parameters").objectId] = [objIdToRemove];
					} else{
						map[this.action.get("parameters").objectId].push(objIdToRemove);
					}
				}
			}, this);

			this.action.get("parameters").mapParentToChild = map;

			this.action.execute({
				success: function(){
					app[self.myHandler].trigger("loading", false);
					$("#" + self.myHandler + "-message").html(self.config.getLocalizations().remove.success).show();
					self.getExistingRelations();
					setTimeout(function(){
						$("#" + self.myHandler + "-message").hide();
					}, 2000);
					app.trigger("stage.refresh.bothIds", app.context.container.id, app.context.document.id);
				},
				error: function(){
					app[self.myHandler].trigger("loading", false);
					$("#" + self.myHandler + "-error").html(self.config.getLocalizations().remove.failure).show();
					self.getExistingRelations();
					setTimeout(function(){
						$("#" + self.myHandler + "-error").hide();
					}, 2000);
				}
			});
		},
		beforeRender: function(){
			this.setView('.existing-relations-table-outlet', this.existingRelationsTable);
		},
		afterRender: function(){
			this.$('select').val(this.selectedRelation);
			this.getExistingRelations();
		},
		serialize: function(){
			return _.extend({
				'relationNames': this.relationNames,
				'twoWayRelation': this.twoWayRelation,
				'showRelations': this.showRelations,
				'allRelationDocsValid': this.allRelationDocsValid
			}, this.config.getLocalizations());
		}
	});
	
	actionModules.registerAction("manageRelations", ManageRelations, {
		"actionId": "manageRelations",
		"label": "Manage Relations",
		"icon": "paperclip"
	});

	return ManageRelations;
});
require(["managerelations"]);