define("runimpactassessment",[
	// Application.
	"app",
	"modules/actions/actionmodules",
	"modules/tsg"
],

function(app, actionModules, TSG) {
	"use strict";

	var action = {};

	//primary view model
	function ViewModel(action, myHandler, config) {

		var self = this;
		
		self.onSubmit = function() {
			
			var iframe;
			iframe = document.getElementById("hiddenDownloader");
			if(iframe === null){
				iframe = document.createElement("iframe");
				iframe.id = "hiddenDownloader";
				iframe.style.visibility = "hidden";
				document.body.appendChild(iframe);
			}
			iframe.src = "impactAssessment.htm?objectId="+config.otherProperties.objectName+"&objectType="+config.otherProperties.objectType+"&trac="+config.otherProperties.trac+"&docNumber="+TSG.stage.model.activeDocument().properties.docNumber;
		};
	}

	action.View = Backbone.Layout.extend({
		template: "actions/runimpactassessment",

		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.viewModel = new ViewModel(this.action, this.myHandler, this.options.config);
		},
		afterRender: function(){
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	actionModules.registerAction("runImpactAssessment", action, {
        "actionId" : "runImpactAssessment",
		"label" : (window.localize("modules.actions.runImpactAssessment.runImpactAssessment")),
		"icon" : "arrow-right",
		"groups" : ["wizard", "run", "impactAssessment"]
    });

	return action;

});
require(["runimpactassessment"]);