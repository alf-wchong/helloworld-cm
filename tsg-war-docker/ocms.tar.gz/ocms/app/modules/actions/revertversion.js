// delete document
define("revertversion",[
  // Application.
  "app",
  "oc",
  "modules/actions/actionmodules",
  "modules/common/action",
  "foldernotes"
],

// Map dependencies from above array.
function(app, OC, actionModules, Action, FolderNotes) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this;

    var action = {};

    action.Service = {
		getParameters: function(options){
			return {
				prevVersionId: options.prevVersionId,
				objectId: options.objectId || options.parentID
			};
		},
		execute: function(options){
			var defaultSuccess = function(result){
				
				app.modalActionHandler.trigger("showMessage", (window.localize("modules.actions.revertVersion.successful")));
				app.trigger("stage.refresh.documentId", result.result.objectId);
			};
			var defaultError =  function(){
				app.modalActionHandler.trigger("showError", (window.localize("modules.actions.revertVersion.fail")));
			};
			options.parameters = this.getParameters(options.parameters);			
			var action = new Action.Model({
				name:"revertVersion",
				parameters: options.parameters
			});
			action.execute({
				success: options.successFunction || defaultSuccess,
				error: options.errorFunction || defaultError,
				global: options.global || false,
				async: options.async || true
			});
		},
		isValid: function(options){

			//Making a revert version action model and sending this collection to an OC endpoint to get permission information 
			var _actions = [];
            _actions.push(new Action.Model({ actionId: "revertVersion", ocActionId: "revertVersion"}));
            var actionCollection = new Action.Collection(_actions, {objectId: options.id});
            actionCollection.fetch({
                 success: function(col){
                 //Calling this for revert version action so only expecting one action to be in this collection 
                    col.each(function(action){
                        if(action.isValid()){
                            options.deferred.resolve(true);
                        }
                        else{
                        	options.deferred.resolve(false);
                        }
                    });
                }
            });
		}
	};

	return action;
  
});
require(["revertversion"]);