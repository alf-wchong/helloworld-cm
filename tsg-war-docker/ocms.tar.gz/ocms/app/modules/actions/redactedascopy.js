define("redactedascopy", [
        "app",
        "modules/actions/actionmodules"
    ],
    function(app, actionModules) {
        "use strict";

        var RedactedAsCopy = {};

        RedactedAsCopy.View = Backbone.Layout.extend({
            template: "actions/redaction",
            initialize: function() {
                this.action = this.options.action;
                this.myHandler = this.options.config.get("handler");
                this.navigateToRedactedDoc = (this.options.config.get("navigateToRedactedDoc") === "true" ? true : false);

                window.open(app.openAnnotateURL +
                    "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&parentId=" + app.context.container.get('properties').objectId +
                    "&username=" + app.user.get("loginName") + "&mode=redact" + "&redactionMode=redactedAsCopy" + "&useLocalStorageForRedaction=" + this.navigateToRedactedDoc);
            },
            onDismiss: function() {
                // Get the objectId to our current document
                var currentDocumentId = this.action.get("parameters").objectId;

                // Check to see if we are explicitly navigating to the redacted document
                if (this.navigateToRedactedDoc) {
                    // Pass in the currentDocumentId (the document being viewed)
                    // and attempt to find the associated redactedId if applicable
                    var redactedId = this.getRedactedId(currentDocumentId);

                    // If redactedId comes back as falsy either one there is no unredactedId match to
                    // currentDocumentId because the process wasn't completed on the OA side and there was
                    // nothing to add to local storage OR this is a previously redacted document and the
                    // currentDocumentId is the redacted document already
                    if (redactedId) {
                        app.trigger("stage.refresh.documentId", redactedId);
                    } else {
                        app.trigger("stage.refresh.documentId", currentDocumentId);
                    }
                } else {
                    app.trigger("stage.refresh.documentId", currentDocumentId);
                }
            },
            getRedactedId: function(currentDocumentId) {
                // Init our redactedId to a blank string, which is what we will return if nothing is found
                var redactedId = "";
                // Retrieve our local storage item representing the data that was set on the OA side
                // It is an array objects, an example would look like the following
                // [{'unredactedId' : 'unredactedObjectId', 'redactedId : 'redactedObjectId'}]
                var unredactedObjArray = window.localStorage.getItem("openAnnotate.unredactedObjArray");

                // If the unredactedObjArray is truthy we know there was an item in local storage
                if (unredactedObjArray) {
                    // Now we need to parse the string into the actual json array
                    unredactedObjArray = JSON.parse(unredactedObjArray);
                    
                    // Here we are attempting to find an object that has it's unredactedId key
                    // with the value of our currentDocumentId
                    var matchingObj = _.find(unredactedObjArray, function (obj) { 
                        return obj.unredactedId === currentDocumentId;
                    });

                    // Verify we found a matchingObj by checking if it is truthy
                    if (matchingObj) {
                        // Get the index of our matching object
                        var index = _.indexOf(unredactedObjArray, matchingObj);
                        
                        // Get the redactedId off the object
                        redactedId = matchingObj.redactedId;

                        // Remove the object
                        unredactedObjArray.splice(index, 1);

                        // Reset unredactedMap on localstorage
                        window.localStorage.setItem("openAnnotate.unredactedObjArray", JSON.stringify(unredactedObjArray));
                    }
                }

                return redactedId;
            },
            serialize: function() {
                return {
                    message: window.localize("modules.actions.redaction.wereOpening"),
                    modal: this.myHandler === "modalActionHandler"
                };
            }
        });

        RedactedAsCopy.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/redactedascopyconfig",
            initialize: function () {
                var self = this;

                var viewModel = self.options.viewModel;
                var model = viewModel.model();

                viewModel.navigateToRedactedDoc = kb.observable(model, "navigateToRedactedDoc");
                if (!viewModel.navigateToRedactedDoc()) {
                    viewModel.navigateToRedactedDoc("false");
                }
            },
            afterRender: function () {
                kb.applyBindings(this.options.viewModel, this.$el[0]);
            }
        });

        //action registers itself with getAction in actionModules
        actionModules.registerAction("redactedAsCopy", RedactedAsCopy, {
            "actionId": "redactedAsCopy",
            "label": window.localize("modules.actions.redactedAsCopy.redactSave"),
            "icon": "exclamation-sign"
        });

        return RedactedAsCopy;
    });
require(["redactedascopy"]);