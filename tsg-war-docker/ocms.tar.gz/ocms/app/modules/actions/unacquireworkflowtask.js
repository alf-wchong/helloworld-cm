define("unacquireworkflowtask", [
	"app",
	"oc",
	"modules/actions/actionmodules",
	"modules/common/workflowutil"
],
function(app, OC, actionModules, WorkflowUtil) {
	"use strict";
	var UnacquireWorkflowTask = {};

	UnacquireWorkflowTask.View = Backbone.Layout.extend({
		template: "actions/unacquireworkflowtask",
		events: {
			"click #unacquire-task-submit" : "unacquireTask"
		},
		initialize: function() {
			var self = this;
			self.handler = this.options.config.get("handler");
			self.action.get("parameters").auditEvent = self.config.get("auditEvent") === "true" ? true : false;
			app[self.handler].trigger("loading", true);

			if (this.options.config.get("attrToShow")) {
				this.attrToShow = this.config.get("attrToShow");
			}
				
			// fetch task by objectId from OC
			$.ajax({
				url: app.serviceUrlRoot + "/workflow/getTasksByContent",
				data: {
					objectId : this.action.get("parameters").objectId
				},
				success: function(tasks) {
					self.taskId = tasks[0];
					self.setUsername();
					app[self.handler].trigger("loading", false);
				}
			});
		},
		setUsername: function() {
			var self = this;
            self.userLoginName = "";
            self.userDisplayName = "";
			// get task instance from OC
			$.ajax({
				url: app.serviceUrlRoot + "/workflow/gettask",
				data: {
					taskId : self.taskId
				},
				success: function(data) {
					// use loginName to get displayName from OC user 
					var assignee = new OC.User({"loginName" : data.assignee});
					assignee.fetch().done(function() {
                        self.userLoginName = this.get("loginName");
                        self.userDisplayName = this.get("displayName");
						if (self.userDisplayName === app.user.get("displayName")) {
							self.userDisplayName = "you";
						}
						self.render();
					});
				}
			});
		},
		unacquireTask: function() {
			var self = this;
			if (self.taskId === undefined) {
				app[self.handler].trigger("showError", window.localize("modules.actions.unacquireWorkflowTask.unableTo") + 
					window.localize("modules.actions.unacquireWorkflowTask.taskId"));
			} else {
				// execute release task
				app[self.handler].trigger("loading", true);
				self.action.get("parameters").taskId = self.taskId;
				self.action.get("parameters").userLoginName = self.userLoginName;
				self.action.execute({
					success: function(data) {
						app[self.handler].trigger("loading", false);
						app[self.handler].trigger("showMessage",
							window.localize("modules.actions.unacquireWorkflowTask.successfullyReleased") + self.userDisplayName);
						app.trigger("stage.refresh.bothIds", true, true);
					},
					error: function(jqXHR, textStatus, errorThrown) {
						app[self.handler].trigger("loading", false);
						app[self.handler].trigger("showError", 
							window.localize("modules.actions.unacquireWorkflowTask.failedToReleaseTask") + jqXHR.status + ": " + 
							jqXHR.statusText);
					}
				});
			}
		},
		afterRender: function(){
			this.setView("#workflowOwnerOutlet", new WorkflowUtil.View({
				"objectId" : app.context.document.get("objectId"),
				"attrToShow" : this.attrToShow
			}));
		},
		serialize: function() {
			var modal = false;
			var rightSide = false;
			if (this.handler === "modalActionHandler") {
				modal = true;
			} else if (this.handler === "rightSideActionHandler") {
				rightSide = true;
			}

			return {
				modal : modal,
				rightSide : rightSide,
				"user" : this.userDisplayName
			};
		}
	});

	UnacquireWorkflowTask.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/unacquireworkflowtaskconfig",
		initialize: function() {
			var viewModel = this.options.viewModel;
			var model = viewModel.model();
			viewModel.auditEvent = kb.observable(model, "auditEvent");

			// Attribute to use as document display name
			viewModel.attrToShow = kb.observable(viewModel.model(), "attrToShow");
		},
		afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
	});

	actionModules.registerAction("unacquireWorkflowTask", UnacquireWorkflowTask, {
		"actionId" : "unacquireWorkflowTask",
		"label" : (window.localize("modules.actions.unacquireWorkflowTask.releaseTask")) ,
		"icon" : "log-out"
	});

	return UnacquireWorkflowTask;
});
require(["unacquireworkflowtask"]);