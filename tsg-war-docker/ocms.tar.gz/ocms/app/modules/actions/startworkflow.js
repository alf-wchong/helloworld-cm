define("startworkflow", [
    "app",
    "modules/common/workflow",
    "modules/actions/actionmodules",
    "modules/common/action",
    "modules/formsupport",
    "modules/hpiadmin/workflowconfig/workflowconfig",
    "modules/common/spinner",
    "foldernotes",
    "ckeditorcore"
],

    // Map dependencies from above array.
    function (app, Workflow, actionModules, Action, Formsupport, WorkflowConfig, HPISpinner, FolderNotes) {
        "use strict";
        //Start with declaring your id - this is the same value as in the filename between the words action. and .js
        //get the config from the namespace. The action handler is responsible for this.

        var action = {};
        action.View = Backbone.Layout.extend({
            template: "actions/startworkflow",
            events: {
                "click #btn-startworkflow": "submit",
                "change #workflowDefinition-select": "showWorkflowForm"
            },
            initialize: function () {
                var self = this;
                this.action = this.options.action;
                //appRoot
                this.action.get("parameters").appRoot = app.root;
                //Audit Event
                this.action.get("parameters").auditEvent = this.config.get("auditEvent") === "true" ? true : false;
                //User/Group Selection Validity
                this.action.get("parameters").noUserOrGroupAssigneeCheck = this.config.get("noUserOrGroupAssigneeCheck") === "true" ? true : false;
                this.action.get("parameters").bothUserAndGroupAssigneeCheck = this.config.get("bothUserAndGroupAssigneeCheck") === "true" ? true : false;

                this.myHandler = this.options.config.get("handler");
                this.toggleLoader = function (bool) {
                    app[this.myHandler].trigger("loading", bool);
                };

                // If no templates were configured in the config, show them all.
                this.workflowDefinitions = (this.options.config.get("chosenWorkflows").length !== 0) ? this.options.config.get("chosenWorkflows") : this.options.config.get("availableWorkflows");

                this.folderNoteRequired = this.options.config.get("folderNoteRequired");
                this.integrateFolderNotes = this.options.config.get("integrateFolderNotes");
                this.folderNoteObjectType = this.options.config.get("folderNoteObjectType");
                this.folderNoteRelationship = this.options.config.get("folderNoteRelationship");
                this.folderNoteType = this.options.config.get("folderNoteType");

                //Clean up logic
                this.folderNoteRequired = ((this.folderNoteRequired === "true" || this.folderNoteRequired === true) ? true : false);
                this.integrateFolderNotes = ((this.integrateFolderNotes === "true" || this.integrateFolderNotes === true) ? true : false);


                app.context.configService.getAdHocFormConfigNames(function (formConfigNames) {
                    self.currentForms = formConfigNames.length !== 0 ? formConfigNames : undefined;
                    self.render();
                });

                this.attachedDocument = app.context.document.attributes.properties.objectName;
                self.assignees = [];
                self.groupAssignee = [];

                // Listen to any changes to the users so we can update the assignees.
                self.listenTo(app, "simpleWorkflow:updateAssignees", function (addedUsers) {
                    self.assignees = addedUsers;

                    //add if statement here to hide the group control
                });

                // Listen to any changes to the users so we can update the assignees.
                self.listenTo(app, "simpleWorkflow:updateGroupAssignees", function (addedGroups) {
                    self.groupAssignee = addedGroups;

                    //add if statement here to hide the user control
                });

                app.listenTo(app, "simpleWorkflow:updateSpinner", function (isFormValidationComplete) {
                    if (isFormValidationComplete) {
                        self.stopSpinner();
                    } else {
                        self.setSpinner();
                    }
                });
            },
            serialize: function () {
                //var defs = this.workflowDefinitions.toJSON() || [];

                return {
                    workflowDefinitions: this.workflowDefinitions,
                    integrateFolderNotes: this.integrateFolderNotes,
                    folderNoteRequired: this.folderNoteRequired,
                    attachedDocument: this.attachedDocument,
                    modal: this.myHandler === "modalActionHandler",
                    rightSide: this.myHandler === "rightSideActionHandler"
                };
            },
            submit: function () {
                var self = this;
                app[self.myHandler].trigger("loading", true);

                var actionParameters = self.action.get("parameters");

                if (self.workflowFormView) {
                    var formValues = self.workflowFormView.getValues();

                    //Comment and add self/this
                    actionParameters.workflowDefinitionId = $("#workflowDefinition-select").val();
                    actionParameters.bpm_assignees = formValues.bpm_assignees;
                    actionParameters.bpm_groupAssignee = formValues.bpm_groupAssignee;

                    //Adding on the props from the form.  
                    _.extend(actionParameters, { "properties": self.workflowFormView.getValues() });
                }

                self.action.execute({
                    success: function (data) {
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showMessage", window.localize("modules.actions.startWorkflow.workflowStarted"));
                        app.trigger("stage.refresh.documentId", true);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        app[self.myHandler].trigger("loading", false);
                        if (jqXHR.responseText.indexOf("individual") >= 0) {
                            app[self.myHandler].trigger("showError", jqXHR.responseText);
                        }
                        else {
                            app[self.myHandler].trigger("showError", window.localize("modules.actions.startWorkflow.sorryAnError") +
                                " " + jqXHR.responseText);
                        }
                    }

                });

                if (self.integrateFolderNotes) {
                    var note_content = CKEDITOR.instances.startWorkflowNoteContent.getData();
                    if (note_content.length > 0) {
                        //Creating the folder notes action with the proper parameters
                        FolderNotes.Service.execute({
                            parameters: {
                                parentID: app.context.container.get("objectId"),
                                note_content: note_content,
                                note_rel_type: self.folderNoteRelationship,
                                note_object_type: self.folderNoteObjectType,
                                property_map: {
                                    note_type: self.folderNoteType,
                                    note_attachment: [app.context.document.get("objectId")]
                                }
                            }
                        });
                    }
                }
            },
            showWorkflowForm: function () {
                if (this.getView("#addUsersControls")) {
                    this.getView("#addUsersControls").remove();
                }
                var self = this;
                app.context.configService.getWorkflowConfigs(function(workflowConfigs) { 
                    var description = "";
                    //Check logic.. undefined
                    if (self.currentForms !== undefined) {
                        self.workflowConfig = workflowConfigs.get(newFunction())[$("#workflowDefinition-select").val()];
                        if (self.workflowConfig) {
                            //We know this will be the "startForm", so hardcoding is OK
                            self.configuredForm = _.findWhere(self.workflowConfig, { 'id': 'startForm' });

                            self.workflowFormView = new action.FormView({
                                'formName': self.configuredForm.configName,
                                'folderNoteRequired': self.folderNoteRequired
                            });
                            if (self.workflowFormView) {
                                self.setView("#addUsersControls", self.workflowFormView, false).render();
                            }
                            description = self.configuredForm.description || description;
                        }
                    }

                    $("#workflow-description").html(description);

                    $("#workflowDefinition-form").show();

                    if (self.integrateFolderNotes && !$("#startWorkflowNoteContentDiv").is(":visible") || !$("#workflowDefinition-select").val()) {
                        self.toggleFolderNoteArea();
                    }
                });
            },

            setSpinner: function () {
                var spinElem = this.$el.find(".progressSpinner")[0];
                if (spinElem) {
                    this.spinner = HPISpinner.createSpinner({
                        color: '#000'
                    }, spinElem);
                }
            },
            stopSpinner: function () {
                if (this.spinner) {
                    HPISpinner.destroySpinner(this.spinner);
                }
            },

            afterRender: function () {
                var self = this;
                var ckeditorSize;
                if (self.myHandler === "rightSideActionHandler") {
                    ckeditorSize = 400;
                } else {
                    //myHandler is modal
                    ckeditorSize = 100;
                }

                //deploy folder note ckeditor of configured
                if (this.integrateFolderNotes && this.currentForms &&
                    CKEDITOR.instances.startWorkflowNoteContent === undefined) {
                    CKEDITOR.replace('startWorkflowNoteContent', {
                        toolbar: "HPIMinimal",
                        disableNativeSpellChecker: false,
                        height: ckeditorSize
                    }, '');

                    if (this.folderNoteRequired) {
                        //create a keyup event on the ckeditor textbox so we can check to make sure there is content
                        CKEDITOR.instances.startWorkflowNoteContent.on('contentDom', function () {
                            var editable = CKEDITOR.instances.startWorkflowNoteContent.editable();
                            editable.attachListener(CKEDITOR.instances.startWorkflowNoteContent.document, 'keyup', function () {
                                self.workflowFormView.checkAndEnforceValidation();
                            });
                        });
                    }
                }


                //Do an initial hide to ensure the wisywig doesn't show before a form is selected
                this.toggleFolderNoteArea();
            },
            toggleFolderNoteArea: function () {
                $("#startWorkflowNoteContentDiv").toggle();
            },
            cleanup: function () {
                try {
                    //remove this instance of CKEDITOR from the global registry
                    //of CKEDITOR.instances to prevent memory leaks
                    if (CKEDITOR.instances.startWorkflowNoteContent) {
                        CKEDITOR.instances.startWorkflowNoteContent.destroy(true);
                        delete CKEDITOR.instances.startWorkflowNoteContent;
                    }
                } catch (e) { }
            }
        });

        action.FormView = Backbone.Layout.extend({
            template: "actions/startworkflowform",
            initialize: function (options) {
                var self = this;
                var defaults = {
                    properties: {},
                    enableRequired: true
                };

                var opts = this.options = _.extend(defaults, this.options);

                this.propertiesViewModel = this.options.propertiesViewModel = {};

                Formsupport.tsgFormSupport(this.propertiesViewModel, {
                    "isCreate": true,
                    "enableRequired": opts.enableRequired,
                    "formName": options.formName,
                    'isWorkflowForm': true
                });

                this.propertiesViewModel.controls.subscribe(function () {
                    self.propertiesViewModel.setValues(opts.properties);
                });

                this.propertiesViewModel.isValid.subscribe(function (isValid) {
                    self.checkAndEnforceValidation();
                });

                this.propertiesViewModel.isFormValidationComplete.subscribe(function (isFormValidationComplete) {
                    app.trigger("simpleWorkflow:updateSpinner", isFormValidationComplete);
                });

                // Trigger controls generation
                // TO DO: Set object type to workflow type.
                //Can we call "generateContols()" here?? 
                this.propertiesViewModel.objectType(app.context.document.get("objectType"));
            },
            getValues: function () {
                return this.options.propertiesViewModel.getValues();
            },
            checkAndEnforceValidation: function () {
                if (this.options.folderNoteRequired && CKEDITOR.instances.startWorkflowNoteContent &&
                    CKEDITOR.instances.startWorkflowNoteContent.getData().length === 0) {
                    $('#btn-startworkflow').prop('disabled', true);
                } else {
                    $('#btn-startworkflow').prop('disabled', !this.propertiesViewModel.isValid());
                }
            },
            afterRender: function () {
                kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
            },
            serialize: function () {

            }
        });

        action.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/startworkflowconfig",
            initialize: function () {
                var self = this;

                var viewModel = self.options.viewModel;
                var model = viewModel.model();

                //instantiate observable to hold the list of wf defs
                viewModel.availableWorkflows = ko.observableArray([]);
                //Grab the alrady chosen workflows, if there are any.
                if (model.get("chosenWorkflows")) {
                    viewModel.chosenWorkflows = ko.observableArray(model.get("chosenWorkflows"));
                } else {
                    viewModel.chosenWorkflows = ko.observableArray([]);
                }

                //grab all defined wfs
                this.workflowDefinitions = new Workflow.DefinitionCollection();
                this.workflowDefinitions.fetch().done(function (wfs) {
                    //Push all potential workflows on to "Available Workflows"
                    _.each(wfs, function (wf) {
                        if (!_.contains(_.pluck(viewModel.availableWorkflows(), 'id'), wf.id)) {
                            viewModel.availableWorkflows.push(wf);
                        }
                    });
                    //Then, remove all of the workflows that have already been "selected".
                    _.each(viewModel.chosenWorkflows(), function (chosenWf) {
                        if (_.contains(_.pluck(viewModel.availableWorkflows(), 'id'), chosenWf.id)) {
                            viewModel.availableWorkflows(_.without(viewModel.availableWorkflows(), _.findWhere(viewModel.availableWorkflows(), {
                                'id': chosenWf.id
                            })));
                        }
                    });
                });

                model.attributes.availableWorkflows = viewModel.availableWorkflows();
                model.attributes.chosenWorkflows = viewModel.chosenWorkflows();

                //Audit Event
                viewModel.auditEvent = kb.observable(model, "auditEvent");

                //user and group selection validity
                viewModel.noUserOrGroupAssigneeCheck = kb.observable(model, "noUserOrGroupAssigneeCheck");
                if (viewModel.noUserOrGroupAssigneeCheck() === null) {
                    viewModel.noUserOrGroupAssigneeCheck("true");
                }
                viewModel.bothUserAndGroupAssigneeCheck = kb.observable(model, "bothUserAndGroupAssigneeCheck");
                if (viewModel.bothUserAndGroupAssigneeCheck() === null) {
                    viewModel.bothUserAndGroupAssigneeCheck("true");
                }

                //whether or not to create a Folder Note after document upload
                if (!viewModel.model().integrateFolderNotes) {
                    viewModel.model().integrateFolderNotes = false;
                }
                viewModel.integrateFolderNotes = kb.observable(viewModel.model(), "integrateFolderNotes");

                //whether or not to create a Folder Note after document upload
                if (!viewModel.model().folderNoteRequired) {
                    viewModel.model().folderNoteRequired = false;
                }
                viewModel.folderNoteRequired = kb.observable(viewModel.model(), "folderNoteRequired");

                //Is folder notes integration enabled
                if (viewModel.integrateFolderNotes() === "false") {
                    viewModel.folderNoteType(false);
                }

                // selected folder note type from the admin
                viewModel.folderNoteObjectType = kb.observable(viewModel.model(), "folderNoteObjectType");
                if (!viewModel.folderNoteObjectType()) {
                    viewModel.folderNoteObjectType("HPI Note");
                }
                // note type to apply to all folder notes
                viewModel.folderNoteType = kb.observable(viewModel.model(), "folderNoteType");
                if (!viewModel.folderNoteType()) {
                    viewModel.folderNoteType("Workflow Note");
                }
                //selected folder note relationship from admin
                viewModel.folderNoteRelationship = kb.observable(viewModel.model(), "folderNoteRelationship");
            },
            afterRender: function () {
                kb.applyBindings(this.options.viewModel, this.$el[0]);
            }
        });

        actionModules.registerAction("startWorkflow", action, {
            "actionId": "startWorkflow",
            "label": (window.localize("modules.actions.startWorkflow.startWorkflow")),
            "icon": "play"
        });

        return action;

    });

//immediately require the action
require(["startworkflow"]);

function newFunction() {
    return 'currentWorkflows';
}
