define("formapprovalreport", [
        "app",
        "modules/actions/actionmodules",
],

function (app, actionModules) {
    "use strict";

    var FormApprovalReport = {};

    FormApprovalReport.View = Backbone.Layout.extend({
        template: "actions/formapprovalreport/formapprovalreport",
        initialize: function () {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.objectId = this.action.get('parameters').objectId;

            this.openFormApprovalReport(this.objectId);
        },
        openFormApprovalReport: function (objectId) {
            var self = this;
            this.action.set("objectId", objectId);
            app[this.myHandler].trigger("loading", true);
            this.action.execute({
                success: function (data) {
                    app[self.myHandler].trigger("loading", false);
                    app[self.myHandler].trigger("showMessage", window.localize("action.formApprovalReport.success"));

                    var formApprovalReportWindow = window.open("FormApprovalReport", 'top=0,left=0,width=1000,height=600,scrollbars');
                    formApprovalReportWindow.document.open();
                    formApprovalReportWindow.document.write(data.result);
                    formApprovalReportWindow.document.close();
                },
                error: function () {
                    app[self.myHandler].trigger("loading", false);
                    app[self.myHandler].trigger("showError", window.localize("action.formApprovalReport.failure"));
                }
            });
        },
        serialize: function () {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal: modal,
                rightSide: rightSide
            };
        }
    });

    actionModules.registerAction("formApprovalReport", FormApprovalReport, {
        "actionId": "formApprovalReport",
        "label": "Form Approval Report",
        "icon": "cogwheel"
    });

    return FormApprovalReport;

});
require(["formapprovalreport"]);