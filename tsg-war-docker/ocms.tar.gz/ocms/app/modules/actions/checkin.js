define("checkin",[
	"app",
	"modules/actions/actionmodules",
	"oc",
	"modules/formsupport",
	"fileupload",
	"iframeTransport"
],
function(app, actionModules, OC, FormSupport) {
	"use strict";

	var action = {};

	function ViewModel(options, myHandler) {
		var self = this;
		var action = options.action;

		var objectId = action.get("parameters").objectId;

		// this will be updated with the objectId result of the checkin
		// we initialize it to the passed in objectId so if they cancel the checkin action,
		// the stage will be refreshed with the correct objectId
		self.checkedInObjectId = ko.observable(objectId);

		// initialize our selected version type to checkin to be a minor version
		self.selectedVersionType = ko.observable("minor");

		// used to display the original document's object name on the screen
		self.originalDocName = ko.observable();

		// the actual file we're checking in
		self.fileToCheckin = ko.observable();
		// the name of the file we're going to be checking in
		self.fileName = ko.observable();

		self.objectType = ko.observable();

		// the current version of the document, used to display in parentheses if checking in as the
		// current version is configured
		self.currentVersion = ko.observable();
		
		// these three observables represent the different version types the document can be checked in as:
		// current version, minor version or major version
		self.showCurrent = ko.observable(true);
		if(options.config.get("disableSameVersion") && options.config.get("disableSameVersion") === "true") {
			self.showCurrent(false);
		}
		self.showMinor = ko.observable(true);
		if(options.config.get("disableMinorVersion") && options.config.get("disableMinorVersion") === "true") {
			self.showMinor(false);
		}
		self.showMajor = ko.observable(true);
		if(options.config.get("disableMajorVersion") && options.config.get("disableMajorVersion") === "true") {
			self.showMajor(false);
		}

		self.formSelected = ko.observable(false);
		if(options.config.get("form")) {
			self.formSelected(true);
		}

		//the selectedVersionType might have been disabled by the each block above, ensure the
		//selectedVersionType default is valid. if everything was disabled, we checkin as minor by default
		if (!self.showMinor()) {
			if (!self.showMajor() && self.showCurrent()) {
				self.selectedVersionType("current");
			} else if (self.showMajor() && !self.showCurrent()) {
				self.selectedVersionType("major");
			}
		}

		// called when the user clicks the submit button for the action
		self.checkin = function() {
			if(!objectId) {
				app[myHandler].trigger("showError", (window.localize("modules.actions.checkin.unableToCheckinDocument")));
			} else {
				// disable the submit button so they can't click it again
				$("#submitButton").addClass("disabled");					
				toggleLoader(true);
				self.submitCheckin();
				toggleLoader(false);
			}
		};

		// called to initialize the action by getting the versions for the document so we can get the current version label and
		// the original document's objectName
		self.initialize = function() {
			var self = this;
			if(!objectId) {
				app[myHandler].trigger( "showError", (window.localize("modules.actions.checkin.unableToViewPrev")));
			} else {
				toggleLoader(true);

				$.ajax({
					type: "POST",
					contentType: "application/json",
					url: app.serviceUrlRoot + "/action/execute?id=" + objectId,
					data: JSON.stringify({
						name: "viewVersions",
						parameters: { objectId:  objectId }						
					}),					
					success: function(data) {
						var currentVersionObjectProps = data.result[0].properties;
						// current version version number
						if(currentVersionObjectProps.versionLabels === undefined) {
							self.currentVersion(currentVersionObjectProps.versionLabel);
						} else {
							self.currentVersion(currentVersionObjectProps.versionLabels[0]);
						}

						// we want to set the current version's object name so we can display it on the checkin screen
						self.originalDocName(currentVersionObjectProps.objectName);
						// setting the object props only if we have a form configured for checkin
						if(self.formSelected()){
							self.setValues(currentVersionObjectProps);
						}						

						toggleLoader(false);
					},
					error: function(jqXHR, textStatus, errorThrown) {
						toggleLoader(false);
						app[myHandler].trigger("showError", (window.localize("modules.actions.checkin.couldNotRetrieveVersion")) +
								jqXHR.status + " " + jqXHR.statusText);
					}
				});
			}
		};
		function toggleLoader(bool) {
			app[myHandler].trigger("loading", bool);
		}

		self.parseResponse = function() {
			return function(jqXHR, textStatus, errorThrown) {
				if(jqXHR && jqXHR !== undefined) {
					var parsedResponse = app.context.util.parseIEJSON(jqXHR);
					if (textStatus === "error") {
						app[myHandler].trigger("showError", (window.localize("modules.actions.checkin.failedToCheckin")) +
							parsedResponse.status + " " + parsedResponse.statusText);
					}else {
						app[myHandler].trigger("showMessage", (window.localize("modules.actions.checkin.documentHasBeen")));
						self.checkedInObjectId(parsedResponse.result);
					}
				} else {
					app[myHandler].trigger("showError", (window.localize("modules.actions.checkin.failedToCheckinDocument")));
				}
				toggleLoader(false);
			};
		};

		self.clearFileToCheckin = function() {
			self.fileToCheckin(undefined);
			self.fileName(undefined);
			// Disabling the submit button since there is no file attached.
			$("#submitButton").addClass("disabled");
		};

		return self;
	}

	action.View = Backbone.Layout.extend({
        template: "actions/checkin",
        initialize: function() {
			var self = this;
            this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.commentsEnabled = this.options.config.get("commentsEnabled");
			this.commentsEnabled = (this.commentsEnabled === "true" || this.commentsEnabled === true);
			
			this.viewModel = new ViewModel(this.options, this.myHandler);
			
			if(this.config.get("form")) {
				//added for Form Support
				var defaults = {
					properties: {},
					enableRequired: true
				};
				
				var opts = this.options = _.extend(defaults, this.options);			
				
				FormSupport.tsgFormSupport(this.viewModel, {
					"isCreate": true,
					"enableRequired": opts.enableRequired,
					"formName": this.config.get("form")
				});

				// set the form control properties once the controls have finished building
				this.viewModel.controls.subscribe(function() {
					// set our initial values once the controls have built
					self.viewModel.setValues(opts.properties);
				});
			}
		
			this.viewModel.objectType(app.context.document.get("objectType"));

            this.viewModel.initialize();
            
            this.listenToOnce(app[this.myHandler], "hide", function() {
				var newOCO = new OC.OpenContentObject({ objectId: this.viewModel.checkedInObjectId() });
				newOCO.fetch({
					success: function() {
						app.trigger("action:object-modified", {
							oldOco: new OC.OpenContentObject({ objectId: self.action.get("parameters").objectId }),
							newOco: newOCO
						});
					}
				});
			});
		},
		// If there is a form configured on checkin then we use this function to decide if the submit button should be enabled or not. 
		isButtonEnabled: function() {
			var buttonElement = $("#submitButton");
			// If the form is valid and a file has been selected then we can enable the button
			if(this.viewModel.isValid() && this.viewModel.fileName()){
				buttonElement.removeClass("disabled");
			}
			// If the form is invalid then we need to make sure that the button is disabled
			if(!this.viewModel.isValid()) {
				buttonElement.addClass("disabled");
			}
		},
        afterRender: function() {
			var self = this;
			
			// We set this listener up in the after render since we dont want to fire off any events before html is rendered. 
			if(this.config.get("form")) {
				// emit an event whenever the form's validity changes
				this.viewModel.isValid.subscribe(_.bind(this.isButtonEnabled, this));
			}


			ko.bindingHandlers.fileToCheckinBinding = {
				init: function(element, valueAccessor, allBindings, viewModel, bindingContext) {
					self.checkinFileUpload = $(element).fileupload({
						type: "POST",
						url: app.serviceUrlRoot + "/action/executeWithAttachment",
						add: function(e, data){
							if(data.files && data.files[0]) {
								// set the fileName of the viewModel to be the fileName of the file we're uploading
								bindingContext.$data.fileName((window.localize("modules.actions.checkin.fileToUpload")) + data.files[0].name);

								// enable the submit button for the user to submit the action
								if(self.config.get("form")) {
									self.isButtonEnabled();
								} else {
									$("#submitButton").removeClass("disabled");
								}
								
								
								// sets the current model property involved in this binding
								var val = valueAccessor();
								val(data);

								// focus on the the whole modal because it loses focus on the modal after using file browser and will make
								// the submit button unclickable. previously this was a temp fix for IE9 and would focus on the version type
								// radio buttons which make the user have to click somewhere else on the modal before submit button became clickable.
								$("#checkin").focus();
							}
						}
					});

					$(element).bind('change', function(e) {
						self.checkinFileUpload.add(e, {
							fileInput: $(this)
						});
					});

					$(element).bind('fileuploadsubmit', function(e, data) {
						var params = { objectId: self.action.get("parameters").objectId };
						params.versionType = bindingContext.$data.selectedVersionType();
						if(self.config.get("form")){
							params.formAttrsAndValues = self.viewModel.getValues();
						}						
						if(self.commentsEnabled){
							params.comments = $("#commentArea")[0].value;
						}						
						data.formData = {
							'objectId': self.action.get("parameters").objectId,
							'action': JSON.stringify({
								'name' : self.action.get("name"),
								'parameters': params
							})
						};
					});

					bindingContext.$data.submitCheckin = function() {
						if(bindingContext.$data.fileToCheckin() && bindingContext.$data.fileToCheckin().submit) {
							var element = bindingContext.$data.fileToCheckin();
							element.submit().always(bindingContext.$data.parseResponse());
						}
					};

				}
            };

            ko.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				commentsEnabled : this.commentsEnabled,
				formSelected: this.config.get("form")
			};
        }
    });

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/checkinconfig",
        initialize: function(){
            var viewModel = this.options.viewModel;

            viewModel.disableSameVersion = kb.observable(viewModel.model(), 'disableSameVersion');
            viewModel.disableMajorVersion = kb.observable(viewModel.model(), 'disableMajorVersion');
            viewModel.disableMinorVersion = kb.observable(viewModel.model(), 'disableMinorVersion');
			viewModel.commentsEnabled = kb.observable(viewModel.model(), 'commentsEnabled');
            //default disable same version to false
			if(viewModel.disableSameVersion() === null){
				viewModel.disableSameVersion(false);
			}
			//default disable major version to false
			if(viewModel.disableMajorVersion() === null){
				viewModel.disableMajorVersion(false);
			}
			//default disable minor version to false
			if(viewModel.disableMinorVersion() === null){
				viewModel.disableMinorVersion(false);
			}

			if(viewModel.commentsEnabled() === null) {
				viewModel.commentsEnabled(false);
			}

			viewModel.form = kb.observable(viewModel.model(), 'form');
			viewModel.potentialForms = ko.observableArray();
			var formSubscribePlaceholder = viewModel.form();

			app.context.configService.getFormConfigNames(function(formConfigNames) {
				// Adding the option to not pick a form 
				formConfigNames.unshift("");
				viewModel.potentialForms(formConfigNames);
				viewModel.form(formSubscribePlaceholder);
			});
			
		},
        afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

	actionModules.registerAction("checkin", action, {
		"actionId" : "checkin",
		"label" : "Check In",
		"icon" : "ok"
    });

	return action;
});
require(["checkin"]);