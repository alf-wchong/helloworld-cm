// BulkDeleteAttribute module
define("bulkdeleteattribute", [
        // Application.
        "app",
        "modules/actions/actionmodules",
        "modules/common/action"
    ],

    // Map dependencies from above array.
    function(app, actionModules, Action) {
        "use strict";

        var BulkDeleteAttribute = {};

        BulkDeleteAttribute.View = Backbone.Layout.extend({
            template: "actions/bulkdeleteattribute",
            events: {
                "click .attrToDelete": 'attrSelected',
                "click #confirmDeleteBulkProperties": "submit",
                "click #unselect-attr": "attrUnselected"
            },
            initialize: function(options) {
                var self = this;
                this.config = options.config;
                this.action = options.action;
                this.myHandler = options.config.get('handler');
                this.form = options.config.get('form');

                this.objectIds = this.action.collection.objectIds;
                
                this.potentialAttrs = [];
                this.selectedAttrs = [];
                this.submitConfirmed = false;

                //Getting the last searched type
                this.typeUsed = _.findWhere(app.routers.search.query.searchParameters, {
                    'paramType': 'type'
                }).paramValue;

                //Getting our configured form
                app.context.configService.getFormConfig(this.form, function(formConfig) {
                    //If the last searched type is not on the form, show that in an error message to the user
                    if (formConfig.get("configuredTypes").where({
                            'ocName': self.typeUsed
                        }).length < 1) {
                        app[self.myHandler].trigger("showError", (window.localize("modules.actions.bulkDeleteAttribute.theTypeYou")) + self.form);
                        $('#modalActionHandler-content').hide();
                    }
                    //Show the configured attributes
                    else {
                        $('#modalActionHandler-content').show();
                        var allModels = _.union(formConfig.get("configuredTypes").where({
                                'ocName': self.typeUsed
                            })[0].get('configuredAttrsPri').models,
                            formConfig.get("configuredTypes").where({
                                'ocName': self.typeUsed
                            })[0].get('configuredAttrsSec').models);
                        //Getting our labels and values for each attribute    
                        _.each(allModels, function(model) {
                            if (model.get('ocName') !== "objectName" || model.get('ocName') !== "objectType") {
                                app.context.configService.getLabels(self.typeUsed, model.get('ocName')).done(function(label) {
                                    self.potentialAttrs.push({
                                        'label': label,
                                        'value': model.get('ocName')
                                    });
                                });
                            }
                        });
                        self.render();
                    }
                });

                this.toggleLoader = function(bool) {
                    app[this.myHandler].trigger("loading", bool);
                };
            },
            //An attribute has been chosen from the dropdown
            attrSelected: function(e) {
                var attrLabel = $(e.currentTarget).text().trim();
                var attrValue = $(e.currentTarget).attr('val');
                this.selectedAttrs.push({
                    'label': attrLabel,
                    'value': attrValue
                });
                //Removing it from the dropdown
                this.potentialAttrs = _.without(this.potentialAttrs, _.findWhere(this.potentialAttrs, {
                    'value': attrValue
                }));
                this.render();
            },
            //An attribute has been removed from the list to delete
            attrUnselected: function(e) {
                var attrLabel = $(e.currentTarget).text().trim();
                var attrValue = $(e.currentTarget).attr('val');
                this.potentialAttrs.push({
                    'label': attrLabel,
                    'value': attrValue
                });
                //Sorting the attributes in the dropdown
                this.potentialAttrs = _.sortBy(this.potentialAttrs, 'label');

                //Removing it from the selected attributes / modal body
                this.selectedAttrs = _.without(this.selectedAttrs, _.findWhere(this.selectedAttrs, {
                    'value': attrValue
                }));
                this.render();
            },
            submit: function() {
                var self = this;

                //If the user hasnt confirmed that they want to delete, show the confirmation message
                if (!this.submitConfirmed) {
                    $("#confirm-submit").show();
                    this.submitConfirmed = true;
                }
                //Go through with the action once the user has confirmed they want to proceed
                else {
                    this.action.get("parameters").objectIds = this.objectIds;
                    this.action.get("parameters").ocNames = _.pluck(this.selectedAttrs, "value");

                    this.action.execute({
                        success: function(data) {
                            self.toggleLoader(false);
                            app.trigger("stage.refresh.bothIds", true, true);
                            app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.bulkDeleteAttribute.taskCompleted")));
                            //Re-generating the table
                            app.trigger('search:execute');
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            self.toggleLoader(false);
                            app[self.myHandler].trigger("showError", (window.localize("modules.actions.bulkDeleteAttribute.failedToComplete")) +
                                jqXHR.status + " " + jqXHR.statusText);
                        }
                    });
                }
            },
            serialize: function() {
                var modal = false;
                var rightSide = false;
                if (this.myHandler === "modalActionHandler") {
                    modal = true;
                } else if (this.myHandler === "rightSideActionHandler") {
                    rightSide = true;
                }
                return {
                    modal: modal,
                    rightSide: rightSide,
                    selectedAttrs: this.selectedAttrs,
                    potentialAttrs: this.potentialAttrs,
                    submitDisabled: this.selectedAttrs.length < 1
                };
            },
            afterRender: function() {
                this.rendered = true;
            }
        });

        BulkDeleteAttribute.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/bulkdeleteattributeconfig",
            initialize: function() {
                var viewModel = this.options.viewModel;

                viewModel.form = kb.observable(viewModel.model(), "form");
                var formSubscribePlaceholder = viewModel.form();
                viewModel.potentialForms = ko.observableArray();
                app.context.configService.getFormConfigNames(function(formConfigNames) {
                    viewModel.potentialForms(formConfigNames);
                    //since the form value is bound from the potentialForms observable,
                    //this context call will come back after the form has been gathered
                    //from the config. this resets the form to the right value.
                    viewModel.form(formSubscribePlaceholder);
                });
            },
            afterRender: function() {
                kb.applyBindings(this.options.viewModel, this.$el[0]);
            }
        });

        actionModules.registerAction("bulkDeleteAttribute", BulkDeleteAttribute, {
            "actionId": "bulkDeleteAttribute",
            "label": (window.localize("modules.actions.bulkDeleteAttribute.bulkDeleteAttribute")),
            "icon": "file"
        });

        return BulkDeleteAttribute;
    });
require(["bulkdeleteattribute"]);