define("setrendition", [
	"app",
	"modules/actions/actionmodules",
	"oc",
	"modules/common/action",
	"fileupload",
	"iframeTransport"
],
function(app, actionModules, OC, Action) {
	"use strict";

	var SetRenditionAction = {};

	function ViewModel(options, myHandler) {
		var self = this;
		self.action = options.action;

		var objectId = self.action.get("parameters").objectId;

		// used to display the original document's object name on the screen
		self.originalDocName = ko.observable();

		self.fileToUpload = ko.observable();
		self.fileNameToUpload = ko.observable();
		self.renditionedDocumentId = objectId;

		// Flags for which 'modes' to show - upload file or regenerate rendition
		self.allowManualUpload = ko.observable(options.config.attributes.allowManualUpload);
		self.allowRegenerateRendition = ko.observable(options.config.attributes.allowRegenerateRendition);

		self.toggleLoader = function(bool) {
			app[myHandler].trigger("loading", bool);
		};

		self.setRendition = function() {
			if(!objectId) {
				app[myHandler].trigger("showError", (window.localize("modules.actions.setRendition.objectIdWasNot")));
			} else {
				self.toggleLoader(true);
				self.submitUpload();
				self.toggleLoader(false);
			}
		};

		self.regenerateRendition = function () {
			if(!objectId) {
				app[myHandler].trigger("showError", (window.localize("modules.actions.setRendition.objectIdWasNot")));
			} else {
				self.toggleLoader(true);

				self.action.get("parameters").regenerateRendition = true;

				self.action.execute({
					success: function (data) {
						self.toggleLoader(false);

						if (data) {
							app[myHandler].trigger("showMessage", (window.localize("modules.actions.setRendition.renditionRegeneration")));
						}

						app.trigger("stage.refresh.bothIds", true, true);
					},
					error: function (jqXHR, textStatus, errorThrown) {
						self.toggleLoader(false);
						app[myHandler].trigger("showError", (window.localize("modules.actions.setRendition.failedToRegenerate")) +
							jqXHR.status + " " + jqXHR.statusText
						);
					}
				});
			}
		};

		self.parseResponse = function() {
			return function(jqXHR, textStatus, errorThrown) {
				if(jqXHR && jqXHR !== undefined) {
					var parsedResponse = app.context.util.parseIEJSON(jqXHR);
					if(textStatus === "error") {
						app[myHandler].trigger("showError", (window.localize("modules.actions.setRendition.failedToSet")) +
							parsedResponse.status + " " + parsedResponse.statusText);
					} else {
						self.renditionedDocumentId = parsedResponse.result;
						app[myHandler].trigger("showMessage", (window.localize("modules.actions.setRendition.renditionSetSuccessfully")));

						app.trigger("stage.refresh.bothIds", true, true);
					}
				} else {
					app[myHandler].trigger("showError", (window.localize("modules.actions.setRendition.failedToSetRendition")));
				}
				self.toggleLoader(false);
			};
		};

		self.clearfileToUpload = function() {
			self.fileToUpload(undefined);
			self.fileNameToUpload(undefined);
		};

		return self;
	}

	SetRenditionAction.View = Backbone.Layout.extend({
		template: "actions/setrendition",
		
		initialize: function () {
			var self = this;

			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.viewModel = new ViewModel(this.options, this.myHandler);

			//Get the object name of the original doc
			var oco = new OC.OpenContentObject({ objectId: self.action.get("parameters").objectId });
			oco.fetch({
				success: function() {
					self.viewModel.originalDocName(oco.attributes.properties.objectName);
				}
			});

			this.listenToOnce(app[this.myHandler], "hide", function() {
				app.trigger("stage.refresh.documentId", self.viewModel.renditionedDocumentId);
			});
		},

		afterRender: function () {
			var self = this;

			self.setRenditionFileUpload = {};

			ko.bindingHandlers.fileToUploadBinding = {
				init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
					self.setRenditionFileUpload = $(element).fileupload({
						type: "POST",
						url: app.serviceUrlRoot + "/action/executeWithAttachment",
						add: function (e, data) {
							if(data.files && data.files[0]) {
								// set the fileNameToUpload of the viewModel to be the fileNameToUpload of the file we're uploading
								bindingContext.$data.fileNameToUpload("File to upload: " + data.files[0].name);
								
								// sets the current model property involved in this binding
								var val = valueAccessor();
								val(data);

								// focus on the cancel button, which fixes IE9 bug where the modal loses focus
								// and no click events on the "Remove Document" button fire
								$("#submitRenditionCancel").focus();
							}
						}
					});

					$(element).bind('change', function (e) {
						self.setRenditionFileUpload.add(e, {
							fileInput: $(this)
						});
					});

					$(element).bind('fileuploadsubmit', function (e, data) {
						var params = { objectId: self.action.get("parameters").objectId };
						data.formData = {
							'objectId': self.action.get("parameters").objectId,
							'action': JSON.stringify({
								'name': self.action.get("name"),
								'parameters': params
							})
						};
					});
					bindingContext.$data.submitUpload = function () {
						if (bindingContext.$data.fileToUpload() && bindingContext.$data.fileToUpload().submit) {
							var element = bindingContext.$data.fileToUpload();
							element.submit().always(bindingContext.$data.parseResponse());
						}
					};

				}
			};

			ko.applyBindings(this.viewModel, this.$el[0]);
		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	SetRenditionAction.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/setrenditionconfig",
		initialize: function(){
			var self = this;
			var viewModel = self.options.viewModel;
			var model = viewModel.model();

			// Allow manual upload of a PDF rendition
			viewModel.allowManualUpload = kb.observable(model, "allowManualUpload");

			// Allow manual regeneration of a PDF rendition
			viewModel.allowRegenerateRendition = kb.observable(model, "allowRegenerateRendition");
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});
	SetRenditionAction.Service = {
		getParameters: function(options){
			return {
					asyncRendition: options.asyncRendition || false,
					regenerateRendition: options.regenerateRendition || false,
					objectId: options.objectId,
					mimeType: options.mimeType,
					parts: options.parts || null
			};
		},
		execute: function(options){
			var defaultSuccess = function(){
				app.log.debug("Set rendition executed successfully");
			};
			var defaultError =  function(){
				app.log.debug("Set renditon executed with an error");
			};
			options.parameters = this.getParameters(options.parameters);
			
			var action = new Action.Model({
				name:"setRendition",
				parameters: options.parameters
			});
			action.execute({
				context: options.context,
				success: options.successFunction || defaultSuccess,
				error: options.errorFunction || defaultError,
				global: options.global || false,
				async: options.async || true
			});
		}
	};
	actionModules.registerAction("setRendition", SetRenditionAction, {
		"actionId": "setRendition",
		"label": "Set Rendition",
		"icon": "plus"
	});

	return SetRenditionAction;
});
require(["setrendition"]);