define("prunepdf", [
	"app",
	"modules/actions/actionmodules",
	"modules/formsupport",
	"tsgUtils",
	"modules/common/spinner",
	"modules/hpiadmin/actionconfig/actions/prunepdf/prunepdfconfig"
],

function(app, actionModules, Formsupport, tsgUtils, HPISpinner, PrunePDFCustomConfigView) {
	"use strict";

	var PrunePDF = {};

	PrunePDF.CustomConfigView = PrunePDFCustomConfigView.View;

	PrunePDF.View = Backbone.Layout.extend({
		template: "actions/prunepdf/prunepdf",
		events: {
			"click #pruneSubmitBtn": "submit"
		},
		initialize: function() {
			var self = this;
			// Variable to know when to destroy or create spinner
			this.disableSpinner = false;
			// grab variables from the config
			this.version = this.options.config.get("enableVersioning");
			this.audit = this.options.config.get("enableAuditing");
			this.formName = this.options.config.get("formName");
			this.myHandler = this.options.config.get("handler");

			// init other view variables
			this.pageRangeValid = false;
			this.formValid = false;
			this.pageView = new PrunePDF.PageRangeView();

			// have to get the form object type before we set the form view so we need a deferred.
			var formDeferred = new $.Deferred();

			// select the first non-container objectType for the form.
			app.context.configService.getAdminOTC(function(otc) {
				app.context.configService.getFormConfig(self.formName, function(formConfig) {
					// find the configured type that has the same ocName as the first otc config that is not a container
					var firstNonContainerType = formConfig.get("configuredTypes").find(function(typeConfig) {
						var type = otc.get("configs").findWhere({ocName : typeConfig.get("ocName")});

						// only return type if it is not a container
						return type.get("isContainer") === "false";
					});

					// if firstNonContainerType isn't defined reject the deferred since we won't have an object type for the form
					// otherwise set the formObjectType and resolve.
					if(firstNonContainerType) {
						self.formObjectType = firstNonContainerType.get("ocName");
						formDeferred.resolveWith(self);
					} else {
						formDeferred.rejectWith(self);
					}
				});
			});

			// need objectType to be set so wait for the formDeferred
			$.when(formDeferred).done(this.formDeferredDone).fail(this.formDeferredRejected);
		},

		formDeferredDone: function() {
			this.formView = new PrunePDF.FormView({
				"formName": this.formName,
				"objectType": this.formObjectType
			});

			this.setViews({
				"#formDiv": this.formView,
				"#pageRangeDiv": this.pageView
			});

			this.applyListeners();
			// call remove spinner to render the form and remove the spinner from the dom
			this.removeSpinner();

		},

		formDeferredRejected: function() {
			// show an error if the configured form doesn't have a non container type
			app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.nonContainerErrorMessage"), true);
			this.removeSpinner();
		},

		// set up listeners from other views. 
		applyListeners: function() {
			this.listenTo(this.pageView, "rangeIsValid", this.toggleRangeValid);
			this.listenTo(this.pageView, "previewRange", this.previewPageRange);
			this.listenTo(this.formView, "formIsValid", this.toggleFormValid);
		},

		// determine if submit button should be activated.
		validation: function() {
			this.$("#pruneSubmitBtn").prop('disabled', !(this.pageRangeValid && this.formValid));
		},

		// split function out to make unit testing easier this is the code we want to be debounced
		debouncedToggleRangeValid: function(isValid) {
			this.pageRangeValid = isValid;
			this.validation();
		},
		// set the pageRangeValid when it changes and call validation. debounce so not triggering on every key
		toggleRangeValid: function(isValid) {
			var debounceToggleRangeValid = _.bind(_.debounce(this.debouncedToggleRangeValid, 200),this);

			debounceToggleRangeValid(isValid);
		},

		// split function out to make unit testing easier this is the code we want to be debounced
		debouncedToggleFormValid: function(isValid) {
			this.formValid = isValid;
			this.validation();
		},

		// set the formValid when it changes and call validation. debounce so not triggering on every key
		toggleFormValid: function(isValid) {
			var debounceToggleFormValid = _.bind(_.debounce(this.debouncedToggleFormValid, 200),this);

			debounceToggleFormValid(isValid);
		},

		// preview the pruned document in a new tab
		previewPageRange: function(pageRange) {
			//Opens the document in a new tab for the user to preview the document before/after selecting it
			window.open(app.serviceUrlRoot + "/content/getPDFSection?id=" + this.action.get("parameters").objectId + "&range=" + pageRange);
		},

		// execute the action upon click of prune button.
		submit: function() {
			// parse the page range and make sure it is valid.
			var parsedPageRange = tsgUtils.parsePageRange(this.pageView.pageRange);
			if(parsedPageRange === "cannot parse"){
				app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.invalidPageRange"), true);
			} else if(parsedPageRange === "empty page range") {
				app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.emptyPageRange"), true);
			} else {
				// show spinner again
				this.disableSpinner = false;
				this.render();

				// page range was valid set it on the action
				this.action.get("parameters").pageRange = parsedPageRange;

				// format and set the values from the form on the action, need properties and objectType
				var formDivView = this.getView("#formDiv");
				this.action.get("parameters").properties = app.context.util.prefixProperties(formDivView.getValues());
				this.action.get("parameters").objectType = formDivView.objectType;
				this.action.get("parameters").prettyPageRange = tsgUtils.getFormattedSelectedPages(parsedPageRange);

				// set whether versioning is enabled on the action
				this.action.get("parameters").versioning = this.version;

				// set whether auditing is enabled on the action
				this.action.get("parameters").audit = this.audit;

				// execute action in OC
				this.action.execute({
					context: this,
					success: this.prunePdfSuccess,
					error: this.prunePdfGenericError,
					statusCode: {
						// Override for errors surrounding invalid page ranges caught by the backend.
						415: this.invalidPageRangeErrors
					}
				});
			}
		},

		// on success refresh stage and show a message with a link to the pruned doc in handler.
		prunePdfSuccess: function(data) {
			// hide error message so only success shows.
			app[this.myHandler].trigger("hideError");
			// hide spinner and show action
			this.removeSpinner();
			app.trigger("stage.refresh.bothIds", true, data.result.objectId);

			this.messageView = new PrunePDF.SuccessMessageView({
				"prunedObjId": data.result.prunedObjectId
			});
			app[this.myHandler].trigger("showMessage", this.messageView);
		},

		// overrides the 415 status code to display custom messages.
		invalidPageRangeErrors: function(jqXHR) {
			var responseText = JSON.parse(jqXHR.responseText);
			// out of range error use indexOf since ie does not support includes()
			if(responseText.message.indexOf("out of the range") !== -1) {
				var mainDocPageCount = responseText.message.substr(responseText.message.lastIndexOf("1-") + 2);
				app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.outOfRangeError") + mainDocPageCount, true);
			// Must retain at least one page in the main doc. 
			} else {
				app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.selectedAllPagesError"), true);
			}
		},

		// handles generic errors from prunePdf
		prunePdfGenericError: function() {
			// hide spinner and show action
			this.removeSpinner();
			app[this.myHandler].trigger("showError", window.localize("modules.actions.prunePDF.genericErrorMessage"), true);
		},

		removeSpinner: function() {
			// hide spinner and show action
			this.disableSpinner = true;
			HPISpinner.destroySpinner(this.spinner);
			this.render();
		},

		afterRender: function(){
			// Need to create our spinner after the first render.
			if(!this.disableSpinner) {
				var spinElem = this.$("#prune-spinner")[0];
				this.spinner = HPISpinner.createSpinner({
					color: '#fff',
					shadow: true
				}, spinElem);
			}
		},

		serialize: function() {
			// ajax hasn't returned display spinner and hide other html
			return {
				loadingDone: this.disableSpinner,
			};
		}
	});

	PrunePDF.SuccessMessageView = Backbone.Layout.extend({
		template: "actions/prunepdf/successmessage",
		initialize: function() {
			this.prunedObjId = this.options.prunedObjId;
		},
		serialize: function() {
			return {
				url: "StageSimple/" + this.prunedObjId
			};
		}
	});

	// Container for form support - modeled after bulkupload
	PrunePDF.FormView = Backbone.Layout.extend({
		template: "actions/prunepdf/fs-template",
		initialize: function() {
			var self = this;
			// we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
			// on the bulk properties page)
			var defaults = {
				properties: {},
				enableRequired: true
			};

			var opts = this.options = _.extend(defaults, this.options);

			// this properties view model is what form support uses to put its controls on and other functions
			var propertiesViewModel = this.options.propertiesViewModel = {};

			// init form support - we only want atCreation attributes to show up
			Formsupport.tsgFormSupport(propertiesViewModel, { 
				'isCreate': true, 
				'enableRequired': opts.enableRequired,
				'formName': opts.formName 
			});

			// set the form control properties once the controls have finished building
			propertiesViewModel.controls.subscribe(function() {
				// set our initial values once the controls have built
				propertiesViewModel.setValues(opts.properties);
			});

			// emit an event whenever the form's validity changes
			propertiesViewModel.isValid.subscribe(function(isValid) {
				self.trigger('formIsValid', isValid);
			});

			// set the object type which will trigger the controls to be generated
			propertiesViewModel.objectType(opts.objectType);
		},
		afterRender: function() {
			// form support uses knockout so let's apply those bindings
			kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
		},
		getValues: function() {
			return this.options.propertiesViewModel.getValues();
		},
		isValid: function() {
			return this.options.propertiesViewModel.isValid();
		},
		serialize: function() {
			return {
				objectType: this.options.objectType,
				// whether or not we're on the bulk properties page - used to display user instructions about what happens
				// with these bulk properties
				bulkProperties: this.options.bulkProperties,
				// only used if we're not in bulk properties page - to display the original document name of the document
				// currently being edited
				title: this.options.title
			};
		}
	});

	PrunePDF.PageRangeView = Backbone.Layout.extend({
		template: "actions/prunepdf/pagerange",
		events: {
			'keyup #page-range': 'getPageRange',
			'click #previewBtn': 'previewPageRange'
		},
		initialize: function() {
			this.pageRange = '';

			// determine if preview is available
			this.listenTo(app, 'pagerange:rangeIsValid', this.togglePreviewButton);
		},

		togglePreviewButton: function(isValid) {
			this.$("#previewBtn").prop('disabled', !isValid);
		},
		getPageRange: function() {
			this.pageRange = this.$('#page-range').attr('value');
			var pattern = /^[0-9|,|-]+$/;
			this.pageRange = this.pageRange.replace(/\s+/g, "");
			var isValid = pattern.test(this.pageRange);

			// enable/disable preview + add buttons
			this.trigger('rangeIsValid', isValid);
			app.trigger('pagerange:rangeIsValid', isValid);
		}, 
		setPageRange: function(pageRange) {
			this.pageRange = pageRange;
			var pattern = /^[0-9|,|-]+$/;
			this.pageRange = this.pageRange.replace(/\s+/g, "");
			var isValid = pattern.test(this.pageRange);
			this.trigger('rangeIsValid', isValid);
			this.render();
		},
		clearPageRange: function() {
			this.pageRange = '';
			this.render();
		},
		previewPageRange: function() {
			this.trigger('previewRange', this.pageRange);
		},
		afterRender: function() {
			if(this.pageRange) {
				this.$('#page-range').val(this.pageRange);
				var pattern = /^[0-9|,|-]+$/;
				var isValid = pattern.test(this.pageRange);
				this.trigger('rangeIsValid', isValid);
			} else {
				// disable preview
				this.$('#previewBtn').prop('disabled', true);
			}
		},
		serialize: function() {
			return {
				pageRange: this.pageRange,
			};
		}

	});

	//action registers itself with getAction in actionModules
	actionModules.registerAction("prunePdf", PrunePDF, {
		"actionId" : "prunePdf",
		"label" : (window.localize("modules.actions.prunePDF.prunePDF")),
		"icon" : "scissors",
		"handler" : "rightSideActionHandler",
		"paneSize" : "rightPane"
	});

	return PrunePDF;

});
require(["prunepdf"]);