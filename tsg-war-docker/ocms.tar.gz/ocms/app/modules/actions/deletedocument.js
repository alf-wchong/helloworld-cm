// delete document
define("deletedocument",[
  // Application.
  "app",
  "oc",
  "modules/actions/actionmodules",
  "modules/common/action",
  "foldernotes"
],

// Map dependencies from above array.
function(app, OC, actionModules, Action, FolderNotes) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this;

    var action = {};

    action.View = Backbone.Layout.extend({
        template: "actions/deletedocument",
        events: {
            'keyup #reasonForDeletion': 'updateDeletionComment'
        },
        initialize: function(){
            this.action = this.options.action;
            this.config = this.options.config;
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.myHandler = this.options.config.get("handler");
            this.auditEventComment = this.config.get("auditEventComment") === 'true' ? true : false;
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };

            //When triggered, creates folder note for document that has just been deleted
            this.listenTo(app, 'deleteDocument:createFolderNote', function(params){
                
                var objectId = params.id;
                var parentIdAndObjectNameMap = params.docIdToParentAndObjectName;
                    
                //use time stamp as name of note
                var currentDate = DateFormat.format.date(new Date(),"E, d MM yyyy hh-mm-ss a");
                var parentId = params.id;
                var objectName = params.objectName;
                if(parentIdAndObjectNameMap){
                    //if this exists, its a group action, need to use this value instead
                    parentId = parentIdAndObjectNameMap[objectId][0];
                    objectName = parentIdAndObjectNameMap[objectId][1];
                }
                 
                //properties of document that has been deleted
                var documentModifier = app.user.get("displayName");

                var noteContent = "<p>" + window.localize("modules.actions.deleteDocument.theDocument")+ objectName + window.localize("modules.actions.deleteDocument.wasDeletedFrom") + documentModifier + ". </p>";
                
                FolderNotes.Service.execute({
                    parameters: {
                        parentID: parentId,
                        note_content: noteContent,
                        note_rel_type: this.config.get("folderNoteRelationship"),
                        note_object_type: this.config.get("folderNoteObjectType"),
                        property_map:{
                            note_type: this.config.get("folderNoteType"),
                            objectName: objectName + ' Deleted - ' + currentDate
                        }
                    },
                    errorFunction:function(jqXHR, textStatus, errorThrown){
                        $("#delete-document-output").append("<div class='alert ale rt-error'><ul><li>" +(window.localize("modules.actions.deleteDocument.folderNote")) + "</li></ul></div>");
                    }
                });
            },this);
        },
        beforeRender: function(){
            var that = this;

            this.viewModel = {
                deleteDocument  : function(){
                    
                    var docIdToParentAndObjectName = {};
                                        
                    var executeAction = function(parentId,docIdToParentAndObjectName){
                        that.toggleLoader(true);
                        that.action.get("parameters").auditEvent = that.config.get("auditEvent") === "true" ? true : false;
                        that.action.get("parameters").reasonForDeletion = that.deletionComment;
                        that.action.execute({
                            success: function(data){  
                                that.toggleLoader(false);
                                app[that.myHandler].trigger("showMessage", window.localize("modules.actions.deleteDocument.documentSuccessfully"));
                                if(that.action.get("parameters").objectId){
                                    app.trigger("action:object-deleted", {
                                        id : that.action.get("parameters").objectId
                                    });
                                }else{
                                    app.trigger("action:objects-deleted", {
                                        ids : that.action.get("parameters").objectIds
                                    });
                                }
                                //If the searchResultsViewController is on the action then this action occured on a table and we need to update the table
                                if(that.searchResultsViewController){
                                    that.searchResultsViewController.tableEventsRef.trigger("search:deleteObjects", that.action.get("parameters").objectIds);
                                }
                                app.trigger("indexer:nodeDeleted", that.action.get("parameters").objectId);

                                //check whether or not option to create folder note on delete has been checked
                                if(that.config.get("folderNote") === "true"){
                                    if(that.action.get("parameters").objectId){
                                        app.trigger("deleteDocument:createFolderNote", {
                                            id : parentId,
                                            objectName : docIdToParentAndObjectName
                                        });
                                    }else{
                                        _.each(that.action.get("parameters").objectIds,function(docId){
                                            app.trigger("deleteDocument:createFolderNote", {
                                                id : docId,
                                                docIdToParentAndObjectName : docIdToParentAndObjectName
                                            });
                                        });
                                        
                                    }
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown){
                                that.toggleLoader(false);
                                app[that.myHandler].trigger("showError", window.localize("modules.actions.deleteDocument.sorryAnError") +
                                    " " + jqXHR.responseText);
                            }
                        });
                    };
                    
                    if(that.config.get("folderNote") === "true"){
                        //we cant figure out the parent after we delete, so we need to do it now
                        if(that.action.get("parameters").objectId){
                            app.context.util.getParents(that.action.get("parameters").objectId, function(fetchedParent) {
                                //we also need to figure out our objectName since we won't be able to after its deleted either
                                var oco = new OC.OpenContentObject({
                                    'objectId': that.action.get("parameters").objectId
                                });
                                oco.fetch().done(function(docOco){ 
                                    executeAction(fetchedParent[0].objectId, docOco.properties.objectName);
                                });
                                
                            });
                        }else{
                            _.each(that.action.get("parameters").objectIds,function(docId){
                                app.context.util.getParents(docId, function(fetchedParent) {
                                    var oco = new OC.OpenContentObject({
                                        'objectId': docId
                                    });
                                    oco.fetch().done(function(docOco){
                                        //need to get our objectName before we delete this object
                                        docIdToParentAndObjectName[docId] = [fetchedParent[0].objectId, docOco.properties.objectName];
                                        if(that.action.get("parameters").objectIds.indexOf(docId) + 1 === that.action.get("parameters").objectIds.length){
                                            //this is the last docId to enter our map, so were ready to fire.
                                            executeAction(false, docIdToParentAndObjectName);
                                        }
                                    });    
                                    
                                });
                            });
                        }
                    }else{
                        executeAction();
                    }
                    
               }
           };
        },
        updateDeletionComment: function(event) {
            this.deletionComment = event.currentTarget.value;
            if(this.deletionComment.length > 0 || !this.auditEventComment) {
                $('#deleteDocumentButton').attr('disabled', false);
            }
            else {
                $('#deleteDocumentButton').attr('disabled', true);
            }
        },
        afterRender: function(){
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                auditEventComment : this.auditEventComment
            };
        }
    });
    
    action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/deletedocumentconfig",
        initialize: function(){
            var self = this;
            var viewModel = self.options.viewModel;
            var model = viewModel.model();
            //whether or not to create an audit event on the folder
            viewModel.auditEvent = kb.observable(model, "auditEvent");
            //require deletionComment
            viewModel.auditEventComment = kb.observable(model, "auditEventComment");
            //whether or not to create a Folder Note before document delete
            viewModel.folderNote = kb.observable(model, "folderNote");
            // selected folder note type from the admin
            viewModel.folderNoteObjectType = kb.observable(model,"folderNoteObjectType");
            if (!viewModel.folderNoteObjectType()){
                viewModel.folderNoteObjectType("HPI Note");
            }
            // note type to apply to all folder notes
            viewModel.folderNoteType = kb.observable(model,"folderNoteType");
            if (!viewModel.folderNoteType()) {
                viewModel.folderNoteType("Folder Note");
            }
            //selected folder note relationship from admin
           viewModel.folderNoteRelationship = kb.observable(model,"folderNoteRelationship");
       },
       afterRender: function(){
        kb.applyBindings(this.options.viewModel, this.$el[0]);
       }
    });

    //have the action register itself with getAction in actionModules
    actionModules.registerAction("deleteDocument", action, {
        "actionId" : "deleteDocument",
        "label" : (window.localize("modules.actions.deleteDocument.deleteDocument")),
        "icon" : "bin"
    });

    actionModules.registerAction("deleteDocuments", action, {
        "actionId" : "deleteDocuments",
        "label" : "Delete Documents",
        "icon" : "bin"
    });

    actionModules.registerAction("deleteDocument-revert", action, {
        "actionId" : "deleteDocument-revert",
        "label" : (window.localize("modules.actions.deleteDocument.deleteVersion")),
        "icon" : "bin"
    });

    actionModules.registerAction("deleteDocuments-revert", action, {
        "actionId" : "deleteDocument-revert",
        "label" : (window.localize("modules.actions.deleteDocument.deleteVersion")),
        "icon" : "bin"
    });
    
    return action;
  
});
require(["deletedocument"]);