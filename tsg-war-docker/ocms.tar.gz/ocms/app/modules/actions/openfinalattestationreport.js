define("openfinalattestationreport", [
        "app",
        "modules/actions/actionmodules",
        'module',
        "modules/hpiadmin/actionconfig/actions/opennewtab/opennewtabconfig"
    ],

    // Map dependencies from above array.
    function (app, actionModules, module, openNewTabConfig) {
        "use strict";

        var OpenFinalAttestationReport = {};

        OpenFinalAttestationReport.CustomConfigView = openNewTabConfig.CustomConfigView;

        OpenFinalAttestationReport.View = Backbone.Layout.extend({
            initialize: function (options) {
                this.action = options.action;
                this.config = options.config;

                this.grabAttestationReportId();
               
            },
            grabAttestationReportId: function(){
                var self = this;
                this.action.execute({
                    success : function(data) {
                        self.openDocument(data.result);
                    }
                });
            },
            openDocument: function (props) {
                var url;
                var id = props.docId;
                var tabName = "Final Attestation Report " + props.documentNumber + " " + props.versionLabel;

                var configuredRoute = this.config.get('selectedNewTabViewer') === "docviewer" ? "DocViewer/" + app.context.configName() : "View";
                url = app.root + configuredRoute + "/" + encodeURIComponent(tabName);
                
                //Build additional property map from config
                var overlayParamMap = {};
                if(this.config.get('selectedNewTabViewer') === "stream") {
                    _.each(this.config.get("overlayParameters"), function(propModel) {
                        var key = propModel.key;
                        var value = propModel.value;
                        if(key && value) {
                            overlayParamMap[key] = value;
                        }
                    });
                }

                //Build query string
                var paramMap = {
                    id: id
                };
                if(!_.isEmpty(overlayParamMap)) {
                    paramMap.overlayParameters = overlayParamMap;
                }
                var queryString = $.param(paramMap);

                //Make call with completed url
                url += "?" + queryString;
                window.open(url);
            }
        });

        actionModules.registerAction("openFinalAttestationReport", OpenFinalAttestationReport, {
            "actionId": "openFinalAttestationReport",
            "label": "Open Final Attestation Report",
            "icon": "share-alt"
        });

        return OpenFinalAttestationReport;
    });

require(["openfinalattestationreport"]);