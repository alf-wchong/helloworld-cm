
define("skipactivity",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
	"use strict";

	var SkipActivity = {};

	SkipActivity.View = Backbone.Layout.extend({
		template: "actions/skipactivity/skipactivity",
		events: {
			"click #skip_activity_confirm" : "setSkipActivitySigned"
		},
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.formKey = this.action.get("parameters").objectId;
			this.taskEntryList = [];
			this.usersToSkip = [];
		},
		toggleLoader: function (bool) {
			app[this.myHandler].trigger("loading", bool);
		},
		beforeRender: function() {
			this.toggleLoader(false);
			// call this function to populate an unordered list with the users that it will skip and approve
			this.getTasks();
		},
		getTasks: function(){
			var self = this;
			//ajax call to query for the tasks that the form has
			$.ajax({
				url: app.serviceUrlRoot + "/aw-workflow/getWizardTasks?formId=" + self.formKey,
				success: function(result){
					_.each(result, function(item) {
						self.taskEntryList.push({roleName : item.roleName, taskId : item.id, taskOwner: item.assignee, label: item.labelName});
					});
					self.showTaskIds(self.taskEntryList);
				},
				error: function() {
					app[self.myHandler].trigger("loading", false);
					app[self.myHandler].trigger("showError",window.localize("modules.actions.reassignWizardWorkflowTask.failedToRetrieve"));
				}
			});
		},
		showTaskIds: function(taskEntries){
			var self = this;
			self.usersToSkip = _.map(taskEntries, function(element) {
				return { label: element.label, roleName: element.roleName };
			});
			_.each(self.usersToSkip, function(element){
				$("#skip_activity_usersList").append("<tr>" + "<td>" + element.label + "</td>" + "<td>" + element.roleName + "</td>" + "</tr>");
			});
		},
		getSignatureUsername: function() {
            return $("#skip_activity_user").val();
        },
        getSignaturePassword: function() {
            return $("#skip_activity_pass").val();
        },
        // call to authentication endpoint to make sure we have a valid username/password combination
        setSkipActivitySigned: function() {
            var eSigUsername = this.getSignatureUsername();
            var eSigPassword = this.getSignaturePassword();
            this.toggleLoader(true);
            if (eSigUsername && eSigPassword) {
                if (eSigUsername !== app.user.get("loginName")) {
                    this._setSkipActivitySignedError();
                } else { 
                    $.ajax({
                        context: this,
                        type: "POST",
                        contentType: "application/json",
                        url: app.serviceUrlRoot + "/authentication/newSession?username=" + eSigUsername,
                        data: JSON.stringify(eSigPassword),
                        success: this._setSkipActivitySignedSuccess,                            
                        statusCode: {
                            401: this._setSkipActivitySignedError
                        },
                        error: this._setSkipActivitySignedError
                    });
                }
            }
        },
        _setSkipActivitySignedSuccess: function() {
            $("#skip_activity_authFail").addClass("hidden");
            // when username & password are correct then execute the action
            this.executeSkipActivity();
        },
        _setSkipActivitySignedError: function() {
        	this.toggleLoader(false);
            $("#skip_activity_authFail").removeClass("hidden");
        },
		executeSkipActivity: function() {
			var self = this;
			//build the action with the taskEntryList list and send to OC
			self.action.attributes.parameters.taskList = self.taskEntryList;
			self.action.execute({
				success : function() {
					self.toggleLoader(false);
					app[self.myHandler].trigger("showMessage", window.localize("action.skipActivity.successMessage") + " " + self.taskEntryList[0].roleName);
				},
				error : function() {
					self.toggleLoader(false);
					app[self.myHandler].trigger("showError", window.localize("action.skipActivity.errorMessage"));
				}
			});
		},
        serialize: function() {
        	var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	 actionModules.registerAction("skipActivity", SkipActivity, {
        "actionId" : "skipActivity",
        "label" : "Skip Task",
      	"icon" : "chevron-right"

    });
		
	return SkipActivity;
});
require(["skipactivity"]);