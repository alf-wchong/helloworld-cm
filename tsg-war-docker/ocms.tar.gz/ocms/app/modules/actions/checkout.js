//Advancedsearch module
define("checkout",[
	//Application
	"app",
	"modules/actions/actionmodules"
],

function(app, actionModules) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
	var action = {};

	action.View = Backbone.Layout.extend({
		template: "actions/checkout",
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		},
		beforeRender: function() {
			var self = this;
			this.viewModel = {

				checkout: function() {
					//app.log.debug("time to submit this form");
					var objectId = self.action.get("parameters").objectId;
					if (objectId === undefined) {
						app[self.myHandler].trigger("showError", window.localize("modules.actions.checkout.unableToCheckout"));	
					}
					else {
						self.toggleLoader(true);
						self.action.execute({
							success: function(data) {
								self.toggleLoader(false);
								
								app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.checkout.documentSuccessfully")));

								self.listenToOnce( app.modalActionHandler, "hide", function(){
                                    app.trigger("stage.refresh.documentId", data.result);
                                });
								
								var iframe;
								iframe = document.getElementById("hiddenDownloader");
								if (iframe === null) {
									iframe = document.createElement('iframe');
									iframe.id = "hiddenDownloader";
									iframe.style.display = 'none';
									document.body.appendChild(iframe);
								}
								iframe.src = app.serviceUrlRoot + "/content/content?id=" + self.action.get("parameters").objectId +"&download=true";

							},
							error: function(jqXHR, textStatus, errorThrown) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showError", (window.localize("modules.actions.checkout.failedToCheck")) +
								jqXHR.status + " " + jqXHR.statusText);

							}	
						});
					}
				}

			};
		},
		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }

	});

	//action registers itself with getAction in actionModules
    actionModules.registerAction("checkout", action, {
        "actionId" : "checkout",
        "label" : "Check Out",
        "icon" : "edit"
    });

    //action registration for checkout-controlleddoc with getAction in actionModules
    actionModules.registerAction("checkout-controlleddoc", action, {
        "actionId" : "checkout-controlleddoc",
        "label" : "Check Out",
        "icon" : "edit"
    });
	return action;
	
});
require(["checkout"]);