//Advancedsearch module
define("obsoletedocument",[
	//Application
	"app",
	"underscore",
	"modules/tsg",
	"modules/actions/actionmodules",
	"modules/hpiadmin/actionconfig/actions/obsoletedocument/obsoletedocumentconfig"
],

function(app, _, TSG, actionModules, ObsoleteDocumentConfig) {
	"use strict";

	var docNumberProp = "tsg_documentNumber";

	var ObsoleteDocument = {};

	ObsoleteDocument.CustomConfigView = ObsoleteDocumentConfig.View;

	ObsoleteDocument.Model = Backbone.Model.extend({
		defaults: {
			userName: "",
			password: "",
			obsoleteDate: "",
			obsoleteComment: ""
		},
		initialize: function(options) {
			this.options = _.defaults(options,this.defaults);
		}
	});

 	ObsoleteDocument.View = Backbone.Layout.extend({
        template: "actions/obsoletedocument",
        events : {
        	"click #obsoleteDocSubmitBtn" : "submit",
        	"keyup #obsolete-username" : "updateUserName",
        	"keyup #obsolete-password" : "updatePassword",
        	"keyup #obsolete-reason" : "updateObsoleteComment",
        	"blur #obsolete-dateBox" : "checkVal",
        	"change #obsolete-dateBox": "checkVal2"
        },
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            // constructs with a model for unit testing purposes in productions will always pass empty object.
			this.model = new ObsoleteDocument.Model(this.options.model || {});
			this.requireAuthentication = this.options.config.get("requireAuthentication");
			this.sigPagesUsed = this.options.config.get("sigPagesUsed");
        },
        afterRender: function() {
        	var self = this;

        	// Java Script for current obsolete date //
			var currentObsoleteDate = app.context.document.attributes.properties.tsg_obsoleteDate;

        	if(currentObsoleteDate) {

        		var obsDate = new Date(currentObsoleteDate);
        		var parsedDate = obsDate.toString().slice(0,15);

        		$('#current-obsolete-date').text(window.localize("modules.actions.obsoleteDocuments.currentObsoleteDate")+ parsedDate);
        	}
        	else {
        		$('#current-obsolete-date').text(window.localize("modules.actions.obsoleteDocuments.currentObsoleteDateNoDate"));
        	}

        	// Java Script for the DateBox //
 			$('#obsolete-dateBox').datepicker({
 				minDate: 0,
 				changeMonth: true,
 				changeYear: true,
 				onSelect: function(date){
 					self.model.set({obsoleteDate: date});
 					$('#obsoleteDocSubmitBtn').prop('disabled', !self.validate());
					//set formatted value
					//$('#obsolete-dateBox').val(self.model.getFormattedValue());
				},
		      	//case where datepicker is empty
		      	onClose: function(dateText){
		      		if( !dateText ){
		      			self.model.set({obsoleteDate: ''});
		      		}
		      	}
		      });
			//set date if there is one
			if(this.model.get("obsoleteDate")){
				$('#obsolete-dateBox').datepicker('setDate', this.model.get("obsoleteDate"));
			}



        	TSG.services.ajaxService.getObjectProperties(
        		this.action.get("parameters").objectId, function(obj) {
					self.$('#obsolete-candidate-name-output').html(obj.properties[docNumberProp]);
				}
			);

        },
        submit: function() {

			$('#obsoleteDocSubmitBtn').prop('disabled', true);

        	var username, password, obsoleteComment, obsoleteDate;
        	var self = this,
        		action = this.action,
        		myHandler = this.myHandler;


        	username = this.model.get("userName");
        	password = this.model.get("password");
        	obsoleteComment = this.model.get("obsoleteComment");
        	obsoleteDate = this.model.get("obsoleteDate");
        	var opts = {
				type:	"POST",
				contentType:	"application/json",
				url:	app.serviceUrlRoot + "/authentication/newSession?username=" + username,
				data: JSON.stringify(password),
				// success call
				success: function(){
					self.executeObsoletion(action, myHandler, username, password, obsoleteDate, obsoleteComment);
				},
				// error call
				error: function(jqXHR){
					if(jqXHR.status != 401) {
						$("#" + self.myHandler + "-error").html(window.localize("modules.actions.obsoleteDocuments.failedToObsolete") +
										jqXHR.status + " " + jqXHR.statusText).show();
						setTimeout(function(){
							$("#" + self.myHandler + "-error").hide();
						}, 6000);
					}

				},
				//override default to go to login screen on login failure
				statusCode: {
					401: function(){
						$("#" + self.myHandler + "-error").html(window.localize("modules.actions.obsoleteDocuments.401Authentication")).show();
						setTimeout(function(){
							$("#" + self.myHandler + "-error").hide();
						}, 6000);

					}
				}
			};
			
			if (obsoleteComment && obsoleteDate) {
				//Default behavior will have authentication required
				if(this.requireAuthentication === true || this.requireAuthentication === undefined){
					if (username === app.user.get("loginName")) {
						$.ajax(opts);

					}else{
						$("#" + self.myHandler + "-error").html("Invalid credentials").show();
						setTimeout(function(){
							$("#" + self.myHandler + "-error").hide();
						}, 6000);
					}

				}else{
					self.executeObsoletion(action, myHandler, username, password, obsoleteDate, obsoleteComment);
				}

			}else{
				$("#" + self.myHandler + "-error").html(window.localize("modules.actions.obsoleteDocuments.aCommentAnd")).show();
				setTimeout(function(){
					$("#" + self.myHandler + "-error").hide();
				}, 6000);
			}
			$('#obsoleteDocSubmitBtn').prop('disabled', !self.validate());
        },
        executeObsoletion: function(action, myHandler, username, password, obsoleteDate, obsoleteComment){
        	var self = this;
        	app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
				var longDate,trueOffset;
				if(dateTimeFormat.timezoneFormat){
					//we are using the default datepicker format in this action, so the hardcoded map is allowed
					trueOffset = moment(obsoleteDate, "MM/DD/YYYY").utcOffset() - moment(obsoleteDate, "MM/DD/YYYY").tz(dateTimeFormat.timezoneFormat).utcOffset();
					longDate = moment(obsoleteDate).utcOffset(trueOffset)._d.getTime();
				}
				else{
					longDate = moment(obsoleteDate)._d.getTime();
				}

				// setting up the parameters to be sent to the backend.
				action.get("parameters").obsoleteDate = longDate;
				action.get("parameters").obsoleteComment = obsoleteComment;
				if (self.requireAuthentication){
					action.get("parameters").userName = username;
				}else{
					action.get("parameters").userName = app.user.get("loginName");
				}
				action.get("parameters").password = password;
				action.get("parameters").sigPagesUsed = self.sigPagesUsed;

				action.execute({
					success : function() {

						var compareDate = new Date();
						compareDate.setHours(23);
						compareDate.setMinutes(59);
						compareDate.setSeconds(59);
						compareDate.setMilliseconds(999);

						app[myHandler].trigger("showMessage", "The Obsolete date of this Document has been set.");

						self.listenToOnce(app[myHandler], "hide", function() {
							app.trigger("stage.refresh.documentId", action.get("parameters").objectId);
						});
					},
					error : function() {
						$("#" + self.myHandler + "-error").html("Error during the execution of obslete document.").show();
						setTimeout(function(){
							$("#" + self.myHandler + "-error").hide();
						}, 6000);
					}
				});

			});
        },
        validate: function() {
            var self = this;
            // script to control the accept and reject buttons
            if (this.model.get("userName") !== app.user.get("loginName") && this.requireAuthentication) {
                return false;
            }
            else if (self.model.get("userName") && self.model.get("password") || !this.requireAuthentication) {
                if (self.model.get("obsoleteDate") && self.model.get("obsoleteComment")) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                requireAuth: this.requireAuthentication
            };
        },
        updateUserName: _.throttle(function() {
        		this.model.set("userName", $('#obsolete-username').val());
        		$('#obsoleteDocSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this),
        updatePassword: _.throttle(function() {
        		this.model.set("password", $('#obsolete-password').val());
        		$('#obsoleteDocSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this),
        updateObsoleteComment: _.throttle(function() {
        		this.model.set("obsoleteComment", $('#obsolete-reason').val());
        		$('#obsoleteDocSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this)

    });

 	actionModules.registerAction("obsoleteDocument", ObsoleteDocument, {
        "ocActionId" : "obsoleteDocument",
        "label" : window.localize("modules.actions.obsoleteDocuments.obsoleteDocument"),
        "icon" : "ban-circle",
        "groups" : ["wizard", "obsolete", "document"]
    });

	return ObsoleteDocument;

});
require(["obsoletedocument"]);
