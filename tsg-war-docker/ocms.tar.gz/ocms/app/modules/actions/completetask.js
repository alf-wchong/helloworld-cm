define("completetask", [
    "app",
    "foldernotes",
    "oc",
    "modules/formsupport",
    "modules/common/workflow",
    "modules/actions/actionmodules",
    "modules/common/action",
    "modules/common/workflowutil",
    "modules/hpiadmin/actionconfig/actions/completetask/completetaskconfig"
],

    // Map dependencies from above array.
    function (app, FolderNotes, OC, FormSupport, Workflow, actionModules, Action, WorkflowUtil, CompleteTaskConfig) {
        "use strict";
        //Start with declaring your id - this is the same value as in the filename between the words action. and .js
        //get the config from the namespace. The action handler is responsible for this; //

        var CompleteTask = {};

        CompleteTask.CustomConfigView = CompleteTaskConfig.View;

        CompleteTask.View = Backbone.Layout.extend({
            template: "actions/completetask",
            events: {
                "click #btn-completeTask": "submit"
            },
            initialize: function () {
                var self = this;
                this.action = this.options.action;
                //Creating this here for testing purposes.
                this.folderNoteAction = new Action.Model({});
                this.myHandler = this.options.config.get("handler");
                this.toggleLoader = function (bool) {
                    app[this.myHandler].trigger("loading", bool);
                };

                this.action.get("parameters").auditEvent = this.config.get("auditEvent") === "true" ? true : false;
                app.context.configService.getAdHocFormConfigNames(function (formConfigNames) {
                    self.currentForms = formConfigNames.length !== 0 ? formConfigNames : undefined;
                    self.render();
                });

                this.folderNoteRequired = this.options.config.get("folderNoteRequired");
                this.integrateFolderNotes = this.options.config.get("integrateFolderNotes");
                this.folderNoteObjectType = this.options.config.get("folderNoteObjectType");
                this.folderNoteRelationship = this.options.config.get("folderNoteRelationship");
                this.folderNoteType = this.options.config.get("folderNoteType");

                //Clean up logic
                this.folderNoteRequired = ((this.folderNoteRequired === "true" || this.folderNoteRequired === true) ? true : false);
                this.integrateFolderNotes = ((this.integrateFolderNotes === "true" || this.integrateFolderNotes === true) ? true : false);

                if (this.options.config.get("attrToShow")) {
                    this.attrToShow = this.config.get("attrToShow");
                }

                this.taskId = this.action.attributes.parameters.taskId;
                this.taskName = this.action.attributes.parameters.taskName;
                this.formKey = this.action.attributes.parameters.formKey;
            },
            submit: function () {
                var self = this;

                if (!this.taskId) {
                    app[this.myHandler].trigger("showError", (window.localize("modules.actions.completeTask.unableToComplete")));
                } else {
                    this.toggleLoader(true);

                    //set our params
                    this.action.get("parameters").taskId = this.taskId;
                    this.action.get("parameters").taskName = this.taskName;
                    this.action.get("parameters").formKey = this.formKey;

                    //if we have a form do that;
                    if (this.getView("#addUsersControls") &&
                        this.getView("#addUsersControls").options.propertiesViewModel.controls().length > 0) {
                        var formValues = this.getView("#addUsersControls").options.propertiesViewModel.getValues();
                        _.extend(this.action.get("parameters"), formValues);
                    }

                    // If there are folder notes, add them in the params.
                    if (this.integrateFolderNotes) {
                        this.action.get("parameters").folderNote = CKEDITOR.instances.completeTaskNoteContent.getData();
                    }

                    this.action.execute({
                        success: function () {
                            self.toggleLoader(false);
                            app.trigger("stage.refresh.bothIds", true, true);
                            app[self.myHandler].trigger("showMessage", window.localize("modules.actions.completeTask.taskCompleted"));
                        },
                        error: function (jqXHR) {
                            self.toggleLoader(false);
                            app[self.myHandler].trigger("showError", window.localize("modules.actions.completeTask.failedToComplete") +
                                (jqXHR.responseText ? jqXHR.responseText : jqXHR.status + " " + jqXHR.statusText));
                        }
                    });

                    if (this.integrateFolderNotes) {
                        var note_content = CKEDITOR.instances.completeTaskNoteContent.getData();
                        if (note_content.length > 0) {
                            //Creating the folder notes action with the proper parameters
                            FolderNotes.Service.execute({
                                parameters: {
                                    parentID: app.context.container.get("objectId"),
                                    note_content: note_content,
                                    note_rel_type: this.folderNoteRelationship,
                                    note_object_type: this.folderNoteObjectType,
                                    property_map: {
                                        note_type: this.folderNoteType,
                                        note_attachment: [app.context.document.get("objectId")]
                                    }
                                }
                            });
                        }
                    }
                }
            },
            showWorkflowForm: function (wfTask) {
                var self = this;
                var useWorkflowConfig = true;
                var docOco = new OC.OpenContentObject({objectId : app.context.document.get("objectId")});
                // Fetch the document oco, all the logic needs to be under this so it runs after it has finished getting the doc oco
                $.when(docOco.fetch()).done(function(){
                        // Check to see that the complete task config map exists & whatever match comes first we saying that will win
                        if (self.options.config.get("bypassWorkflowConfig") && self.options.config.get("completeTaskConfigMap") && 
                            self.options.config.get("completeTaskConfigMap").objectType === docOco.attributes.objectType && 
                            _.contains(_.keys(docOco.get('properties')), self.options.config.get("completeTaskConfigMap").attrSelected)){

                            // Loop through the criteria list to see if one matches a property on the document
                            _.every(self.options.config.get("completeTaskConfigMap").criteria, function(mapEntry){

								// Using == here to account for the integers
                                if (docOco.get('properties')[self.options.config.get("completeTaskConfigMap").attrSelected] == mapEntry.attributeValueCriteria){
                                    
                                    self.workflowFormView = new CompleteTask.FormView({
                                        'formName': mapEntry.adHocFormValue,
                                        'wfResult': wfTask,
                                        'folderNoteRequired': self.folderNoteRequired
                                    });

                                    self.setView("#addUsersControls", self.workflowFormView, false).render();

                                    $("#workflowDefinition-form").show();

                                    useWorkflowConfig = false;
									
									return;
                                }

                            });
                        }

                        if (useWorkflowConfig && self.currentForms){
                            app.context.configService.getWorkflowConfigs(function(workflowConfigs) {
                                var description;
                                // ----------------------------------  All current workflow configs ------------------ Name of the current workflow/process -----------------
                                self.workflowConfig = _.findWhere(workflowConfigs.get("currentWorkflows")[wfTask.workflowDefinitionName], {
                                    //----- Name of current task -------
                                    'id': wfTask.taskDefinitionKey
                                });
                                if (self.workflowConfig) {
                                    var formName = self.workflowConfig.configName;
                                    if (formName) {
                                        self.workflowFormView = new CompleteTask.FormView({
                                            'formName': formName,
                                            'wfResult': wfTask,
                                            'folderNoteRequired': self.folderNoteRequired
                                        });

                                        self.setView("#addUsersControls", self.workflowFormView, false).render();

                                        description = self.workflowConfig.description || "";
                                    }
                                }
                                if (description) {
                                    $("#workflow-description").html(description);
                                }
                                $("#workflowDefinition-form").show();
                            });
                            
                        }
                });
            },
            afterRender: function () {
                var self = this;
                var ckeditorSize;
                if (self.myHandler === "rightSideActionHandler") {
                    ckeditorSize = 400;
                } else {
                    //myHandler is modal
                    ckeditorSize = 100;
                }

                //deploy folder note ckeditor of configured
                if (this.integrateFolderNotes && this.currentForms &&
                    CKEDITOR.instances.completeTaskNoteContent === undefined
                ) {
                    CKEDITOR.replace('completeTaskNoteContent', {
                        toolbar: "HPIMinimal",
                        disableNativeSpellChecker: false,
                        height: ckeditorSize
                    }, '');

                    if (this.folderNoteRequired) {
                        //if folder note is required the submit button needs to be disbaled from the start
                        $('#btn-completeTask').attr('disabled', true);

                        //create a keyup event on the ckeditor textbox so we can check to make sure there is content
                        CKEDITOR.instances.completeTaskNoteContent.on('contentDom', function () {
                            var editable = CKEDITOR.instances.completeTaskNoteContent.editable();
                            editable.attachListener(CKEDITOR.instances.completeTaskNoteContent.document, 'keyup', function () {
                                self.workflowFormView.checkAndEnforceValidation();
                            });
                        });
                    }
                }

                //If folder notes is not enabled, hide it.
                if (!self.integrateFolderNotes) {
                    this.toggleFolderNoteArea();
                }

                this.workflowUtilView = new WorkflowUtil.View({
                    "objectId": app.context.document.get("objectId"),
                    "attrToShow": self.attrToShow
                });

                this.setView("#workflowOwnerOutlet", this.workflowUtilView).render();

                this.workflowUtilView.getResult().done(function (wfTask) {
                    self.showWorkflowForm(wfTask); 
                });
            },
            toggleFolderNoteArea: function () {
                $("#completeTaskNoteContentDiv").toggle();
            },
            cleanup: function () {
                try {
                    //remove this instance of CKEDITOR from the global registry
                    //of CKEDITOR.instances to prevent memory leaks
                    if (CKEDITOR.instances.completeTaskNoteContent) {
                        CKEDITOR.instances.completeTaskNoteContent.destroy(true);
                        delete CKEDITOR.instances.completeTaskNoteContent;
                    }
                } catch (e) { 
                    //swallow exception
                }
            },
            serialize: function () {
                var modal = false;
                var rightSide = false;
                if (this.myHandler === "modalActionHandler") {
                    modal = true;
                } else if (this.myHandler === "rightSideActionHandler") {
                    rightSide = true;
                }
                return {
                    attachedDocument: app.context.document.attributes.properties.objectName,
                    integrateFolderNotes: this.integrateFolderNotes,
                    folderNoteRequired: this.folderNoteRequired,
                    modal: modal,
                    rightSide: rightSide
                };
            }
        });

        CompleteTask.FormView = Backbone.Layout.extend({
            template: "actions/startworkflowform",
            initialize: function (options) {
                var self = this;
                var defaults = {
                    properties: {},
                    enableRequired: true
                };

                var opts = this.options = _.extend(defaults, this.options);

                this.propertiesViewModel = this.options.propertiesViewModel = {};

                FormSupport.tsgFormSupport(this.propertiesViewModel, {
                    "isCreate": true,
                    "enableRequired": opts.enableRequired,
                    "formName": options.formName,
                    'isWorkflowForm': true
                });

                this.propertiesViewModel.controls.subscribe(function () {
                    self.propertiesViewModel.setValues(opts.properties);
                });

                this.propertiesViewModel.isValid.subscribe(function () {
                    self.checkAndEnforceValidation();
                });

                // Trigger controls generation
                // TO DO: Set object type to workflow type.
                this.propertiesViewModel.objectType(app.context.document.get("objectType"));

                //Filling in values, but only ones that are configured.
                var ocNamesToImport = _.pluck(_.filter(this.propertiesViewModel.controls(), function (control) {
                    return control.willImport === true;
                }), 'id');

                var mapValuesToSend = _.pick(_.extend(this.options.wfResult.allVariables, this.options.wfResult.allVariables.properties), ocNamesToImport);

                this.propertiesViewModel.setValues(mapValuesToSend);
            },
            getValues: function () {
                return this.options.propertiesViewModel.getValues();
            },
            checkAndEnforceValidation: function () {
                if (this.options.folderNoteRequired && CKEDITOR.instances.completeTaskNoteContent &&
                    CKEDITOR.instances.completeTaskNoteContent.getData().length === 0
                ) {
                    $('#btn-completeTask').prop('disabled', true);
                } else {
                    $('#btn-completeTask').prop('disabled', !this.propertiesViewModel.isValid());
                }
            },
            afterRender: function () {
                kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
            },
            serialize: function () {

            }
        });

        actionModules.registerAction("completeTask", CompleteTask, {
            "actionId": "completeTask",
            "label": (window.localize("modules.actions.completeTask.completeTask")),
            "icon": "ok-sign"
        });

        return CompleteTask;

    });
require(["completetask"]);