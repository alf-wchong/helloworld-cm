define("startwizardapprovalworkflow",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
	"use strict";

	var action = {};

	action.View = Backbone.Layout.extend({
		template: "actions/startwizardapprovalworkflow",
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		},

		beforeRender: function() {
			var self = this;
			this.viewModel = {
				taskId : ko.observable(),
				objectId : self.action.get("parameters").objectId,
				onSubmit : function() {

                    if(self.action.get("parameters").objectId === undefined){
						app[self.myHandler].trigger("showError", (window.localize("modules.actions.startWizardApprovalWorkflow.unableToStart")));
					}
					else{
						self.toggleLoader(true);
						// Set the appRoot value so we can build up the email url properly
						self.action.get('parameters').appRoot = app.root;
						self.action.execute({
							success : function(data) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.startWizardApprovalWorkflow.approvalRoute")));

								app.listenToOnce(app[self.myHandler], "hide", function() {
									app.trigger("stage.refresh.bothIds", self.viewModel.objectId, self.viewModel.objectId);
								});								
							},
							error : function(jqXHR, textStatus, errorThrown) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showError", (window.localize("modules.actions.startWizardApprovalWorkflow.failedToStart")) + jqXHR.status + 
                                    " " + jqXHR.statusText);
							}
						});
					}
				}
			};
		},

		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
		
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	 actionModules.registerAction("startWizardApprovalWorkflow", action, {
        "actionId" : "startWizardApprovalWorkflow",
      	"label" : (window.localize("modules.actions.startWizardApprovalWorkflow.startApprovalWorkflow")),
      	"icon" : "chevron-right",
      	"groups" : ["wizard", "start", "approval", "streamline"]
    });
		
	return action;
});
require(["startwizardapprovalworkflow"]);