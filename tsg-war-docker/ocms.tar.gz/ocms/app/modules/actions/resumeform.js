define("resumeform",[
  // Application.
  'app',
  "oc",
  'modules/actions/actionmodules',
  'URIjs/URI',
  "module",
  "modules/common/action"
],

// Map dependencies from above array.
function(app, OC, actionModules, URI, module, Action) {
    "use strict";

    var ResumeForm = {};

    // states for which to not recompute workflow rules.
    var noWfDefStates = module.config().noWfDefStates || ["Pending Approval"];

    ResumeForm.View = Backbone.Layout.extend({
        template: "actions/resumeform",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
        },
        beforeRender: function(){
            var self = this;
            this.viewModel = {
                onSubmit : function() {
                    //formId must be on the action
                    var formId =  self.action.get("parameters").objectId;
                    if(formId === undefined){
                        app[self.myHandler].trigger("showError", (window.localize("modules.actions.resumeForm.unableToResume")));
                    }else{
                        self.toggleLoader(true);
                        var formOco = new OC.OpenContentObject({objectId : formId});
                        $.when(app.user.fetch(), formOco.fetch()).done(
                            $.proxy(function(user, formOco){
                                var url = app.root + 'activeform/' + encodeURIComponent(formOco[0].properties.objectId) + '/edit/0';
                                window.location.pathname = url;
                                app[self.myHandler].trigger("hide");
                            }, {
                                noWfDefStates : noWfDefStates
                            })
                        );
                    }
                }
            };
        },
        getActiveFormUrl: function(formOco){
            var url = new URI(app.root + 'activeform/' + encodeURIComponent(formOco[0].properties.objectId) + '/edit/0');
            return url.toString();
        },
        afterRender: function(){
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
    });

    ResumeForm.Service = {
        execute:function(options){
            var defaultSuccess = function(){
                app.log.debug("Resume form executed successfully");
            };
            var defaultError =  function(){
                app.log.debug("Resume Form executed with an error");
            };
            var action = new Action.Model({
                name:"resumeForm",
                parameters: options.parameters
            });
            action.execute({
                success: options.successFunction || defaultSuccess,
                error: options.errorFunction || defaultError,
                global: options.global || false,
                async: options.async || true
            });
        }
    };
    actionModules.registerAction("resumeForm", ResumeForm, {
        "actionId" : "resumeForm",
        "label" : "Edit Form",
        "icon" : "edit",
        "groups" : ["wizard", "resume", "form"]
    });

    return ResumeForm;
});
require(["resumeform"]);
