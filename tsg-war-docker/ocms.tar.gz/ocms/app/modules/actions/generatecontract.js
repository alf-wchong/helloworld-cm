//Advancedsearch module
define("generatecontract",[
	//Application
	"app",
	"modules/actions/actionmodules"
],

function(app, actionModules) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
	var action = {};

	action.View = Backbone.Layout.extend({
		template: "actions/generatecontract",
		events: {
			"click #generateContract": "generateContract"
		},
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		},
		generateContract: function() {
			var self = this;
			var objectId = self.action.get("parameters").objectId;

			if (objectId === undefined) {
				app[self.myHandler].trigger("showError", window.localize("modules.actions.generateContract.unableToGenerate"));	
			}
			else {
				self.toggleLoader(true);
				self.action.execute({
					success: function(data) {
						self.toggleLoader(false);
						
						app[self.myHandler].trigger("showMessage", window.localize("modules.actions.generateContract.contractSuccessfullly"));

						//do a refresh on the containerId so we'll see the updated workflow document
						self.listenToOnce( app.modalActionHandler, "hide", function(){
                            app.trigger("stage.refresh.containerId", true);
                        });
					},
					error: function(jqXHR, textStatus, errorThrown) {
						self.toggleLoader(false);
						app[self.myHandler].trigger("showError", window.localize("modules.actions.generateContract.failedToGenerate") +
						jqXHR.status + " " + jqXHR.statusText);

					}	
				});
			}
		},
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }

	});

	//action registers itself with getAction in actionModules
    actionModules.registerAction("generateContract", action, {
        "actionId" : "generateContract",
        "label" : "Generate Contract",
        "icon" : "gift"
    });

	return action;
	
});
require(["generatecontract"]);