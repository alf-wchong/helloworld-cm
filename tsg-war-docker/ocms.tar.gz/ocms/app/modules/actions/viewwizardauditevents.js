//Advancedsearch module
define("viewwizardauditevents",[
	//Application
	"app",
	"modules/actions/actionmodules"
],

function(app, actionModules) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
	var action = {};


	function ViewModel(action, myHandler) {

		var self = this;
		self.objectId = action.get("parameters").objectId;

		self.rows = ko.observableArray([]);
		self.catagories = ko.observableArray();
		self.headersMap = ko.observable({"eventName" : "Event", "eventDescription" : "Description",
												"auditedObjectVersion" : "Version", "displayName" : "Username", 
												"auditDate" : "Date", "extras" : "Additional Details"});
		
		self.headers = ko.observableArray(["Event", "Description", "Version", "Username", "Date", "Additional Details"]);
		self.headerKeys = ko.observableArray(["eventName", "eventDescription", "auditedObjectVersion", "displayName", "auditDate", "extras"]);
		self.viewWizardAuditEvents = function() {
			self.toggleLoader(true);
			var opts = {
				type : "GET",
				url: app.serviceUrlRoot + "/aw-form/audit",
				data: {formId: self.objectId},
				success: function(result){
					self.processHeaders(result);
					$.each(result, function(index, item){
						//OC should return audit events with the last item first
						self.rows.push( self.processRow(item, self.catagories()) );
		          	});
					self.toggleLoader(false);

				},
				error: function(){
					app[myHandler].trigger("showError", window.localize("modules.actions.viewWizardAuditEvents.thereWasAn"));
				}
			};

			$.ajax(opts);

		};

		self.processHeaders = function(result) {
			
			if (result.length > 0) {
				$.each (result[0], function(idx) {
					self.catagories.push(idx);
				});
			}
		};

		self.processRow = function(item, headers) {
			
			var rowJSON = {};
			_.each(headers, function(head){
				var key = head;
				if(key === "extras") {
					var extras = ko.observableArray([]);
					_.each(item[key], function(extraValue, extraKey) {
						var text = extraKey + ": " + extraValue;
						if(extraValue !== "") {
							extras.push(text);
						}

					});
					rowJSON[key] = extras();
				}
				else if(key == "auditDate") {	
					var date = new Date(item[key]);
		    		if (date !== null) {
		    			
		    			app.context.dateService.getFormattedDatetime(date).done(function(formattedDate) {
	                        rowJSON[key] = formattedDate;
	                    });

		        	}
		        	else {
			             rowJSON[key] = "";
		        	}
				}
				else {
					if(item[key] !== null) {
						rowJSON[key] = item[key];
					}
					else {
						rowJSON[key] = "";
					}
				}
			});

			return rowJSON;

		};

		self.toggleLoader = function(bool) {
			app[myHandler].trigger("loading", bool);
		};
	}	

 action.View = Backbone.Layout.extend({
        template: "actions/viewwizardauditevents",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.viewModel = new ViewModel(this.action, this.myHandler);
        },
         beforeRender: function(){
            this.viewModel.viewWizardAuditEvents();
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
    });

 	actionModules.registerAction("viewWizardAuditEvents", action, {
        "actionId" : "viewWizardAuditEvents",
        "label" : "View Wizard Audit Events",
        "icon" : "info-sign",
        "handler" : "rightSideActionHandler",
	    "paneSize" : "fullPane",
	    "groups" : ["wizard", "view", "audit"]
    });
    
	return action;
	
});
require(["viewwizardauditevents"]);