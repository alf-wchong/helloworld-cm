define("promoteordemote",[
  // Application.
  'app',
  'oc',
  'handlebars',
  'modules/actions/actionmodules',
  'modules/tsg',
  'module',
  'modules/common/tossacross',
  'modules/common/typeahead',
  'modules/common/spinner'
],

// Map dependencies from above array.
function(app, OC, Handlebars, actionModules, TSG, module,TossAcross,HPITypeahead, HPISpinner) {

	var PromoteOrDemote = {};
	PromoteOrDemote.configuredTypes = {};
	PromoteOrDemote.allowedTransitionStates = [];
	PromoteOrDemote.statusAttrName = module.config().statusAttrName || "aw_status";

	PromoteOrDemote.Document = OC.OpenContentObject.extend({
		defaults: {
			objectId: '',
			currentState: '',
			targetState: '',
			//this promotionChange flag is set to true if its a promotion and false if its a demotion
			promotionChange: ''
		},
		setState: function(targetState) {
			this.targetState = targetState;
		},
		setPromotionChange: function(targetState) {
			var self = this;
			var docAllowedStates;
			_.each(PromoteOrDemote.allowedLifecycleStates, function(type){
	 			if(type.docType === self.attributes.objectType){
	 				docAllowedStates = type.lifecycles;
	 			}
	 		});

	 		var startIndex,endIndex;

	 		_.find(docAllowedStates,function(item,itemIdx){
	 			if(item.label === self.currentState || item.value === self.currentState){
	 				startIndex = itemIdx;
	 			}else if(item.label === targetState || item.value === targetState){
	 				endIndex = itemIdx;
	 				self.targetStateLabel = item.label;
	 			}
	 		});

	 		if(startIndex < endIndex){
	 			this.promotionChange = true;
	 		}else if(startIndex > endIndex){
	 			this.promotionChange = false;
	 		}else{
	 			//if we aren't going up or down, we've moved it around but are now back in our starting state, so we won't need a promotionChange value
	 			this.promotionChange = undefined;
	 		}
			
		},
		getCurrentState: function() {
			return this.currentState;
		},
		setCurrentState: function(state) {
			this.currentState = state;
		},
		toJSON: function(){
			return  { 
						objectId: this.id,
					    targetState: this.targetState,
					    promotionChange: this.promotionChange
					};
		},
		parse: function(oco){
			this.currentState = oco.properties[PromoteOrDemote.statusAttrName];
			return oco;
		}
	});


	PromoteOrDemote.fetchAndPopulateTypes = function(type){
		var self = this;
		return $.ajax({
			type : "GET",
			contentType: "application/json",
			url: app.serviceUrlRoot + "/picklists/" + type.picklistName,
			success: function(result){
				if(result === null || result === undefined){
					app[self.myHandler].trigger("showError", window.localize("modules.actions.promoteOrDemote.noLifecycles"));
				}

				self.foundLifecycles = [];

				_.each(result,function(lifecycleState){
					self.foundLifecycles.push({
						label: lifecycleState.label,
						value: lifecycleState.value
					});
				});

				PromoteOrDemote.allowedLifecycleStates.push({
					name: type.picklistName,
					docType: type.docType,
					lifecycles: self.foundLifecycles,
					allowedTransitions: type.allowedTransitionStates
				});
				
			},
			error: function(){
				app[self.myHandler].trigger("showError", window.localize("modules.actions.promoteOrDemote.failedTo"));
			}
		});			
	};


	PromoteOrDemote.Documents = OC.OpenContentObjectCollection.extend({
		model: PromoteOrDemote.Document,
		initialize: function(options){
			var self = this;
			PromoteOrDemote.allowedLifecycleStates = [];
			PromoteOrDemote.Documents.__super__.initialize.apply(this, arguments);
			this.config = options.config;
			//referencing configured lifecycle states
			this.allowedStatesDeferred = $.Deferred();
	
			PromoteOrDemote.configuredTypes = _.extend([], _.map(module.config().configuredTypes, _.clone));

			var allowedStatesDeferreds = [];

			_.each(PromoteOrDemote.configuredTypes,_.bind(function(type) {
                allowedStatesDeferreds.push(PromoteOrDemote.fetchAndPopulateTypes(type));
            },this));

            $.when.apply($, allowedStatesDeferreds).then(function() {
                self.allowedStatesDeferred.resolve();
            });
		}
	});

	PromoteOrDemote.TableRow = Backbone.Layout.extend({
		tagName: function(){
			return "tr data-id=" + encodeURIComponent(this.model.id);
		},
		template: "actions/promoteordemotetable",
		events: {
			'click input[type=radio]': 'check'
		},
		initialize: function(options){
			var self = this;
			self.model = options.model || {};
			
	 	},
	 	check: function(evt){
			//firefox doesn't support evt.srcElement
			var target = evt.currentTarget || evt.srcElement;
			if(target.type === 'radio'){
				var targetState = this.$(target).attr('value');
				this.model.setState(targetState);
				this.model.setPromotionChange(targetState);
			}
		},
		moveAllStates: function(bulkState,tableRow) {
			var self = this;
			var bulkIsValid = true;
			var holderInput;
			_.each(tableRow[0].children,function(childTd){
				//Now we're looping through to set inputs to checked or disabled.
				_.each(childTd.children,function(input){
					//If we found the bulkState to move to, and it isn't disabled, then set it as checked and move the target state
					if(input.value === bulkState && input.disabled !== true){
						input.checked = true;			
						self.model.setState(input.value);
						self.model.setPromotionChange(input.value);
					}else if(input.value === bulkState && input.disabled === true){
						bulkIsValid = false;
						//We just found out that the bulkState to move to is disabled, so lets see if were holding an input that we need to check
						if(holderInput){
							holderInput.checked = true;
						}
					//If the bulk state isn't valid and we're on our already checking state, leave it checked
					}else if(!bulkIsValid && input.checked === true){
						input.checked = true;
					}else if(input.checked === true){
					//bulkState is still valid here, but we are going to hold on to what is currently checked in case we find
					//out later that the bulkState actually isn't valid
						input.checked = false;
						holderInput = input;
					}else{
						input.checked = false;
					}
				});
			});	
		},
		isCurrentState: function(lifecycleState, currentLifecycleState, options){
			if(lifecycleState.value.toLowerCase() === this.model.currentState.toLowerCase()){
				return options.fn(this);
			}else{
				return options.inverse(this);
			}
		},
		isAllowedState: function(allowedTransitions, lifecycleState,currentLifecycleState, options){
			var tempStateMap;
			//We need to find the correct stateMap to see whether the current state is allowed or not.
			//tempStateMap is used because we don't want to return multiple times within the _.each loop
			_.each(allowedTransitions,function(stateMap){
				if(stateMap.label.toLowerCase() === this.model.currentState.toLowerCase()){
					tempStateMap = stateMap;
				}
			},this);
			//If we have a stateMap for the given type, then we are going to see if its allowed or not
			//If there is no stateMap, then we are going to assume that everything is valid.
			if(tempStateMap){
				//compare with both ocname and reponame
				if(tempStateMap.allowedStates.indexOf(lifecycleState.label) > -1){
					return options.fn(this);
				}else{
					return options.inverse(this);
				}
			}
			else{
				return options.fn(this);
			}
		},
	 	serialize: function(){
	 		var self = this;
	 		var docAllowedStates;
	 		var docAllowedTransitions = [];

	 		_.each(PromoteOrDemote.allowedLifecycleStates, function(type){
	 			if(type.docType === self.model.attributes.objectType){
	 				docAllowedStates = type.lifecycles;
	 				docAllowedTransitions = type.allowedTransitions;
	 			}
	 		});

	 		Handlebars.registerHelper('current-lifecycle-state', _.bind(this.isCurrentState,this));
	 		Handlebars.registerHelper('allowed-lifecycle-state', _.bind(this.isAllowedState,this,docAllowedTransitions));

	 		return {
	 			'model': this.model.attributes,
	 			'currentState': this.model.attributes.properties[PromoteOrDemote.statusAttrName] ? this.model.attributes.properties[PromoteOrDemote.statusAttrName] : '',
	 			'lifecycleStates': docAllowedStates ? docAllowedStates : [],
	 			'cid': this.cid
	 		};
	 	}
	});

	PromoteOrDemote.TableView = Backbone.Layout.extend({
		tagName: "table",
		className: "table table-striped",
		initialize: function(options) {
			var self = this;
			self.objectIds = options.objectIds;
			self.config = options.config;
			self.ocoCollection = new PromoteOrDemote.Documents({"ids" : self.objectIds,
																 "config" : self.config
															   });
			self.ocoFetch = self.ocoCollection.fetch();
			self.ocoAllowedStatesFetch = self.ocoCollection.allowedStatesDeferred;
			self.tableRows = [];

			self.ocoFetch.done(function(ocos) {
				self.ocoCollection.fetched = true;
				self.render();
			}); 

			
            self.ocoAllowedStatesFetch.done(function(ocos) {
                self.render();
            }); 
		},
		beforeRender: function() { 
			var self = this;
			if(this.ocoCollection.fetched) {	
				var allSameObjectType = self.checkDocTypes();
				if(allSameObjectType && this.ocoCollection.models.length > 1){
					self.trigger("showTypeahead",allSameObjectType);
					self.allSameType = true;				
				}
				//todo:insert headers from config
				this.ocoCollection.each(function(oco) {
					this.tableRow = new PromoteOrDemote.TableRow({
						'model': oco,
						'config': this.config
					});
					this.tableRows.push(this.tableRow);
					this.insertView(this.tableRow);
				},this);
			}
		},
		checkDocTypes: function() {
			var self = this;
			var firstType = self.ocoCollection.models[0].attributes.objectType;
			_.each(self.ocoCollection.models,function(oco){
				if(oco.attributes.objectType !== firstType){
					firstType = false;
				}
			});

			//return the type if they were all the same
			return firstType;
		},
		afterRender: function() {
			this.rendered = true;
		}
	});

	/**
	 * Shows the successfully changed documents and documents that failed to change.
	 */
	PromoteOrDemote.Results = Backbone.Layout.extend({

		template: "actions/promoteordemote-results",

		initialize: function(options) {
			this.successList = options.successList;
			this.errorList = options.errorList;
		},

		serialize: function() {
			return {
				successList: this.successList,
				errorList: this.errorList
			};
		}
	});

	PromoteOrDemote.View = Backbone.Layout.extend({
		template: "actions/promoteordemote",
		events: {
			"click #submitButton": "submit"
		},
		initialize: function(options) {
			this.action = this.options.action;
			this.objectIds = this.action.get('parameters').objectIds || [this.action.get('parameters').objectId];
			this.myHandler = this.options.config.get("handler");
			this.tableView = new PromoteOrDemote.TableView({
				'objectIds': this.objectIds,
				'config': this.options.config
			});
			this.listenTo(this.tableView,"showTypeahead",this.createTypeahead);
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		

		},
		beforeRender: function() { 
			if (this.tableView){
				this.setView(".table-outlet",this.tableView);
			}
		},
		createTypeahead: function(objectType) {
			var self = this;

			var doCreateTypeahead = _.bind(function() {
				self.$('.typeahead-instructions').append('<label>' + window.localize("modules.actions.promoteOrDemote.selectAState")+ '<label>');
				var allowedStates;
				_.each(PromoteOrDemote.allowedLifecycleStates, function(type){
		 			if(type.docType === objectType){
		 				allowedStates = type.lifecycles;
		 			}
		 		});

				self.changeAllStates = new HPITypeahead({
		       			options: allowedStates,
		       			displayKey: 'label',
						searchOn: 'label'
		       	});

				self.listenTo(self.changeAllStates, 'change:selected', function(option){
	       			var bulkState = option ? option.displayValue : undefined;
	       			if(bulkState){
		       			_.each(self.tableView.tableRows,function(tableRow){
		       				tableRow.moveAllStates(bulkState,tableRow.$el);
		       			});
					}	
				});

	       		if(self.changeAllStates) {
					self.setView(".typeahead-changeStates-outlet", self.changeAllStates).render();
				}
			}, this);

			if(this.rendered){
				doCreateTypeahead();
			} else {
				this.listenOnce('rendered', doCreateTypeahead);
			}
		},
		afterRender: function() { 
			var self = this;
			self.tableView.render();
			this.rendered = true;
			this.trigger('rendered');
		},
		getLocalizations: function(){
			return module.config().localizations || {
				cancelButton: (window.localize("generic.cancel")),
				submitButton: (window.localize("generic.submit")),
				instructions: (window.localize("modules.actions.promoteOrDemote.toChange"))
			};
		},
		resetAllowedStates: function(childrenTds,currentState,docType){
			var docAllowedTransitions;
			_.each(PromoteOrDemote.allowedLifecycleStates, function(type){
	 			if(type.docType === docType){
	 				docAllowedTransitions = type.allowedTransitions;
	 			}
	 		});
			//We need to find the correct stateMap to see whether the current state is allowed or not.
			//tempStateMap is used because we don't want to return multiple times within the _.each loop
			var tempStateMap;
			_.each(docAllowedTransitions,function(stateMap){
				if(stateMap.label === currentState){
					tempStateMap = stateMap;
				}
			},this);

			_.each(childrenTds,function(childTd) {
				_.each(childTd.children,function(input){
					if(tempStateMap){
						if(tempStateMap.allowedStates.indexOf(input.value) <= -1 && input.value != currentState){
							input.disabled = true;
						}
						else{
							input.disabled = false;
						}
					}else{
						//if we dont have a stateMap, we are going to assume that every other state is valid
						input.disabled = false;
					}
				});
			});
		},
		submit: function(){
			var self = this;
			self.action.get("parameters").objectsToPromoteOrDemote = self.tableView.ocoCollection.toJSON();
			self.action.get("parameters").objectIds = self.objectIds;
			self.$('#submitButton').addClass('disabled');
			self.spinner = HPISpinner.createSpinner({
				color: '#666'
			}, this.$el.find(".progressSpinner")[0]);

			self.action.execute({
				success : function(data) {
					self.$('#submitButton').removeClass('disabled');
					if(self.spinner){
						HPISpinner.destroySpinner(self.spinner);
					}
					var errorList = [];
					var successList = [];
					//If data.result contains id's, then we have failures
					if(data.result !== undefined && data.result.length > 0 && data.parameters.objectIds.length > 0)
					{
						var splitId = "";
						var errorIds = [];
						

						_.each(data.result,function(failedObjectId){
							if(failedObjectId.indexOf("~") > -1){
								var objectIdAndError = failedObjectId.split("~");
								splitId = objectIdAndError[0];
								errorIds.push(splitId);
							}
						});

						_.each(errorIds,function(objectId){
							_.each(self.tableView.ocoCollection.models,function(oco){
								if(oco.id === objectId){
									errorList.push(oco.objectName);
								}
							});	
						});


						_.each(data.parameters.objectIds,function(objectId){
							_.each(self.tableView.ocoCollection.models,function(oco){
								if(oco.id === objectId){
									if(oco.targetState){
										successList.push(oco.attributes.properties.objectName + (window.localize("modules.actions.promoteOrDemote.isUpdated")) + oco.targetState);
									}								
								}
							});	
						});

						// hide our table,footer,typeahead and instructions so there's no buttons for a user to interact with
						$('.modal-footer').addClass('hide');
						$(".table-outlet").addClass('hide');
						$(".typeahead-section").addClass('hide');

						//Note: This could cause a race condition if the succes and error lists aren't finished being populated when this fires
						self.setView("#promoteordemote-results-outlet", new PromoteOrDemote.Results({
							successList: successList,
							errorList: errorList
						})).render();

						

					
					//If we have no failures we will enter this loop
					}else if(data.parameters.objectIds.length > 0 ){		

						_.each(data.parameters.objectIds,function(objectId){
							_.each(self.tableView.ocoCollection.models,function(oco){
								if(oco.id === objectId){
									if(oco.targetState){
										successList.push(oco.attributes.properties.objectName + (window.localize("modules.actions.promoteOrDemote.isUpdated")) + oco.targetStateLabel);
										app.trigger("stage.refresh.documentId", objectId);
									}
								}
							});	
						});

						// hide our table,footer,typeahead and instructions so there's no buttons for a user to interact with
						$('.modal-footer').addClass('hide');
						$(".table-outlet").addClass('hide');
						$(".typeahead-section").addClass('hide');

						self.setView("#promoteordemote-results-outlet", new PromoteOrDemote.Results({
							successList: successList
						})).render();
					}


				},
				error : function(jqXHR, textStatus, errorThrown) {
					self.$('#submitButton').removeClass('disabled');
					//self.toggleLoader(false);
					app[self.myHandler].trigger("showError", (window.localize("modules.actions.promoteOrDemote.failedToStart")) + jqXHR.status + 
                        " " + jqXHR.statusText);
				}
			});
		},
        serialize: function() {
        	var self = this;
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                allSameType : self.tableView.allSameType,
                submitButton : self.getLocalizations().submitButton,
                cancelButton : self.getLocalizations().cancelButton,
                instructions : self.getLocalizations().instructions

            };
        }
	});
		
	actionModules.registerAction("promoteOrDemote", PromoteOrDemote, {
	    "actionId" : "promoteOrDemote",
	  	"label" : (window.localize("modules.actions.promoteOrDemote.promoteOrDemote")),
	  	"icon" : "fast-forward"
	});

	actionModules.registerAction("promoteOrDemoteCollection", PromoteOrDemote, {
	    "actionId" : "promoteOrDemoteCollection",
	  	"label" : (window.localize("modules.actions.promoteOrDemote.promoteOrDemote")),
	  	"icon" : "fast-forward",
	  	"groups" : ["wizard", "promote", "demote"]
	});
		
	return PromoteOrDemote;

});
require(["promoteordemote"]);