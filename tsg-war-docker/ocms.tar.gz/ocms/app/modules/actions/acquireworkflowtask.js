//Advancedsearch module
define("acquireworkflowtask", [
	//Application
	"app",
	"modules/actions/actionmodules",
	"modules/common/workflowutil",
	"handlebars"
],

function(app, actionModules, WorkflowUtil, Handlebars) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
	var action = {};
	
	action.View = Backbone.Layout.extend({
		template: "actions/acquireworkflowtask",
		events: {
			"click #acquireTask-submitBtn": "onSubmit",
			"change #acquireTask-taskSelect": "changeSelectedTask"
		},
		initialize: function(){
			var self = this;
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.action.get("parameters").auditEvent = this.options.config.get("auditEvent") === "true" ? true : false;
            this.objectId = this.action.get("parameters").objectId;
			this.showDropdown = true;
			this.unclaimedTasks = [];
			this.getUnclaimedTasks();

			if (this.options.config.get("attrToShow")) {
				this.attrToShow = this.config.get("attrToShow");
			}

			Handlebars.registerHelper( 'concat', function(task) {
			    return task.taskGroup + ' - ' + task.taskName;
			});

            app.listenTo(app, 'refreshWorkflowOutletView', function(task) {
            	var multipleCandidateGroups = self.unclaimedTasks.length > 1 ? true : false;

            	if(task) {
            		self.setView("#workflowOwnerOutlet", new WorkflowUtil.View({
	                	"objectId" : app.context.document.get("objectId"),
						"multipleCandidateGroups" : multipleCandidateGroups,
						"attrToShow" : self.attrToShow
					}));
            	} else {
            		self.removeView("#workflowOwnerOutlet");
            		document.getElementById("acquireTask-submitBtn").disabled = true;
            	}

                
            });
        },
        getUnclaimedTasks: function() {
			var self = this;

			var endpointUrl = app.serviceUrlRoot + "/workflow/getunclaimedtasks?associatedContentId=" + self.objectId + "&userLoginName=" + app.user.get("loginName");

			if (this.options.config.forWizardWorkflows) {
				endpointUrl = app.serviceUrlRoot + "/aw-workflow/getUnclaimedWizardTasks?associatedContentId=" + self.objectId + "&userLoginName=" + app.user.get("loginName");
			}

			$.ajax({
				url: endpointUrl,
				type: "GET",
				success: function(result) {
					$.each(result, function(index, task) {
						$.each(task.candidateGroups, function(index2, group) {
							self.unclaimedTasks.push({taskGroup: group, taskName: task.name, taskId: task.id});
						});
                    });

                    if(self.unclaimedTasks.length == 1) {
						self.showDropdown = false;
						self.selectedTask = self.unclaimedTasks[0];
                    }

                    self.render();
				},
				error: function(jqXHR, textStatus, errorThrown) {
					self.toggleLoader(false);
                    app[self.myHandler].trigger("showError", (window.localize("modules.actions.acquireWorkflowTask.failedTo")) + 
                        jqXHR.status + " " + jqXHR.statusText);
                }
			});
		},
		onSubmit: function() {
			var self = this;
			this.toggleLoader(true);
			var taskId = this.selectedTask.taskId;
			if (taskId === null) {
				this.toggleLoader(false);
                app[this.myHandler].trigger("showError", window.localize("modules.actions.acquireWorkflowTask.failedToAcquire")); 
			}
			else {
                this.action.get("parameters").taskId = taskId;
				this.toggleLoader(true);
			
                this.action.execute({
                    success : function(data) {
                                self.toggleLoader(false);
                                // only refresh both ids if you are in the wizard trac
                                if(Backbone.history.getFragment().indexOf("wizard") !== -1){
 									app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
 								}
 								else{
	                                app.trigger("stage.refresh.documentId", self.objectId);
 								}   
                                app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.acquireWorkflowTask.acquiredTask")) + self.selectedTask.taskName + (window.localize("modules.actions.acquireWorkflowTask.fromGroup")) + self.selectedTask.taskGroup + ".");
                            },
                    error : function(jqXHR, textStatus, errorThrown) {
                                self.toggleLoader(false);
                                app[self.myHandler].trigger("showError", (window.localize("modules.actions.acquireWorkflowTask.failedToAcquireTask")) + jqXHR.status + " " + jqXHR.statusText);
                            }
                });				

			}
		},
		changeSelectedTask: function(evt) {
			var taskGroup= $("#acquireTask-taskSelect").val();

			this.selectedTask = _.find(this.unclaimedTasks, function(task) {
				return task.taskGroup === taskGroup;
			});

			document.getElementById("acquireTask-submitBtn").disabled = false;
			app.trigger("refreshWorkflowOutletView", this.selectedTask);

			if(this.selectedTask) {
				var message = (window.localize("modules.actions.acquireWorkflowTask.toAcquire")) + this.selectedTask.taskGroup + ", click Acquire Task.";
				$('.alert-success').html(message);
				$('.alert-success').show();
			} else {
				$('.alert-success').hide();
			}

		},
		toggleLoader: function(bool){
                app[this.myHandler].trigger("loading", bool);
        },
		beforeRender: function() {
			this.toggleLoader(false);
		},
		afterRender: function() {
			if (this.unclaimedTasks.length == 1) {

	            this.setView("#workflowOwnerOutlet", new WorkflowUtil.View({
					"objectId" : app.context.document.get("objectId"),
					"attrToShow" : this.attrToShow
				}));

				document.getElementById("acquireTask-submitBtn").disabled = false;

				var message = (window.localize("modules.actions.acquireWorkflowTask.toAcquire")) + this.unclaimedTasks[0].taskGroup + ", click Acquire Task.";
				$('.alert-success').html(message);
				$('.alert-success').show();
			}

		},
        serialize: function(){
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				showDropdown : this.showDropdown,
				unclaimedTasks : this.unclaimedTasks
			};
        }
	});

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/acquireworkflowtaskconfig",
		initialize: function() {
			var viewModel = this.options.viewModel;
			var model = viewModel.model();
			viewModel.auditEvent = kb.observable(model, "auditEvent");
			
			// Attribute to use as document display name
            viewModel.attrToShow = kb.observable(viewModel.model(), "attrToShow");},
		afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
	});

	actionModules.registerAction("acquireWorkflowTask", action, {
        "actionId" : "acquireWorkflowTask",
		"label" : (window.localize("action.acquireWorkflowTask.acquireTask")), 
		"icon" : "inbox"
    },
    {
		"forWizardWorkflows": false
	});

    actionModules.registerAction("acquireWizardWorkflowTask", action, {
        "actionId" : "acquireWizardWorkflowTask",
		"label" : (window.localize("action.acquireWorkflowTask.acquireTask")), 
		"icon" : "inbox"
    },
    {
		"forWizardWorkflows": true
	});

	return action;
	
});
require(["acquireworkflowtask"]);