define("manageworkflowdocuments", [
	'app',
	"managerelations",
	"modules/conditions/condition",
	"modules/actions/actionmodules",
	"modules/hpiadmin/actionconfig/actions/manageworkflowdocuments/manageworkflowdocumentscustomconfig"
],
function(app, ManageRelations, Condition, actionModules, ManageWorkflowDocumentsCustomConfig){
	"use strict";

	var ManageWorkflowDocuments = _.extend({}, ManageRelations);

	ManageWorkflowDocuments.CustomConfigView = ManageWorkflowDocumentsCustomConfig.View;

	ManageWorkflowDocuments.Config = ManageRelations.Config.extend({
		//hotspot function for getting table headers and associated attributes
		getLocalizations: function(){
			return _.extend({}, ManageRelations.Config.prototype.getLocalizations.call(this), {
				tabs: {
					existingRelations : (window.localize("modules.actions.manageWorkflowDocuments.controlledDoc")),
					addNewRelations :(window.localize("modules.actions.manageWorkflowDocuments.addControlled")) 
				},
				validate: {
					message: (window.localize("modules.actions.manageWorkflowDocuments.thisDocument"))
				},
				instructions: (window.localize("modules.actions.manageWorkflowDocuments.useTheSearch")) +
						(window.localize("modules.actions.manageWorkflowDocuments.searchResults")) +
						(window.localize("modules.actions.manageWorkflowDocuments.youWould")),
				noRelsFound: (window.localize("modules.actions.manageWorkflowDocuments.noControlledDoc")),
				noRelsSelected: (window.localize("modules.actions.manageWorkflowDocuments.noControlledSelected")),
				btns : {
					removeRelBtn : (window.localize("modules.actions.manageWorkflowDocuments.removeDocuments")),
					addRelBtn : (window.localize("modules.actions.manageWorkflowDocuments.addDocuments"))
				},
				existingDocumentsInstructions: (window.localize("modules.actions.manageWorkflowDocuments.existingDocumentsInstructions"))
			});
		},
		validate: function(doc){
			var self = this;
			var deferred = $.Deferred();
			//check conditions for this doc
			var conditionsCollection = new Condition.Collection({
				nodeId: doc.objectId,
				conditions: this.getConditions()
			});
			$.when(conditionsCollection.fetch()).done(function(){
				deferred.resolve(conditionsCollection.validateCollection() ? undefined :
																			conditionsCollection.getMessages() || self.getLocalizations().validate.message);
			});
			return deferred;
		},
		getConditions: function(){
			var searchResultConditions = this.config.get('searchResultConditions');

			if(searchResultConditions instanceof Backbone.Collection) {
				searchResultConditions = _.pluck(searchResultConditions.models, 'attributes');
			}
			return _.pluck(searchResultConditions, 'name');
		},
		openLink: function(event){
			//override and stream back this document
			window.open(app.serviceUrlRoot + '/content/content?id=' + event.target.id  + "&contentType[]=" + ["pdf"]);
		}
	});

	ManageWorkflowDocuments.View = ManageRelations.View.extend({
		initialize: function() {
			this.configHelper = new ManageWorkflowDocuments.Config(this.options);
			ManageRelations.View.prototype.initialize.call(this);
		}
	});

	actionModules.registerAction("manageWorkflowDocuments", ManageWorkflowDocuments, {
		"actionId": "manageWorkflowDocuments",
		"label": (window.localize("modules.actions.manageWorkflowDocuments.manageWorkflowDocuments")),
		"icon": "paperclip",
		"groups" : ["wizard", "manage", "documents"]
	});

	return ManageWorkflowDocuments;
});
require(["manageworkflowdocuments"]);
