define("createcontentlessobject", [
	"app",
	"modules/formsupport",
	"modules/common/ocquery",
	"modules/hpiadmin/otc/objecttypeconfig",
	"modules/actions/actionmodules",
	"oc"
],
function(app, Formsupport, Query, OTC, actionModules, OC) {
	
	"use strict";

	var CreateContentlessObject = {};


	CreateContentlessObject.View = Backbone.Layout.extend({
		template: "actions/createcontentlessobject",
		events: {
			"change #objectTypeSelector": "updateObjectType",
			"click #confirmObjectTypeBtn": "confirmObjectType"
		},
		initialize: function(options) {
			this.options = this.options || options;
			var self = this;
			// the remove function is overloaded to remove event listeners and properly remove subviews
			this.remove = function(){
				// reset identifierIndex
				this.identifierIndex = 0;
				// remove object subviews
				_.each(this.objects, function(value){
					value.remove();
				});
				// remove footer view
				this.footerView.remove();
				// remove the object type picklist if it was ever created
				if(this.objectTypePicklistView){
					this.objectTypePicklistView.remove();
				}
				// reset the list of objects
				this.objects = [];
				// remove all event listeners
				app.stopListening(app, "createcontentlessobject:modelFinished");
				app.stopListening(app, "createcontentlessobject:modelUnfinished");
				app.stopListening(app, "createcontentlessobject:deleteObjectView");
				app.stopListening(app, "createcontentlessobject:addNewObject");
				app.stopListening(app, "createcontentlessobject:uploadObjects");
				// extra removal things
				this.undelegateEvents();
				this.$el.removeData().unbind();
				Object.getPrototypeOf(Object.getPrototypeOf(this)).remove.call(this);
				this.$el.empty();
			};
			// get the handler
			this.myHandler = this.options.config.get("handler");
			// used for having a unique identifier for each object to be uploaded
			this.identifierIndex = 0;
			// this will keep track of all the objects that come in from the subview
			this.objects = [];
			// create the footer view that holds submit buttons and close buttons
			this.footerView = new CreateContentlessObject.FooterView({
				myHandler: this.myHandler
			});
			this.setView("#footerView", this.footerView);
			// get the object types associated with the form specified in the config
			// and perform the correct actions when the types are returned
			this.getObjectTypes();
			// counter for the number of completed object forms
			// if an object is completed then the value at that id is true, otherwise false
			this.completedViews = [];
			//listen for models to be complete
			app.listenTo(app, "createcontentlessobject:modelFinished", function(id){
				// if an object's form is complete, increment the counter and see if it is equal to the number of objects present
				if(id !== undefined && id !== null){
					self.completedViews.push(id);
				}
				if(self.completedViews.length === self.objects.length && self.objects.length !== 0){
					// enable the submit button
					self.$("#uploadObjectsBtn").prop("disabled", false);
				} else{
					self.$("#uploadObjectsBtn").prop("disabled", true);
				}
			});
			// listen for when an object is no longer completed
			app.listenTo(app, "createcontentlessobject:modelUnfinished", function(id){
				// if the object was already invalid, we don't need to mess with the counter
				if(self.completedViews.indexOf(id) > -1){
					// remove form id from completed views array if it becomes invalid
					self.completedViews = _.without(self.completedViews, id);
				}
				// if all of the forms were previously valid, we need to disable the submit button
				self.$("#uploadObjectsBtn").prop("disabled", true);
			});
			// listen for when a delete button is pressed
			app.listenTo(app, "createcontentlessobject:deleteObjectView", function(identifier){
				// the key of the object to be deleted
				var deletedObjectKey;
				// find the key of the object to be deleted
				_.each(self.objects, function(value, key){
					if(value.identifier === identifier){
						deletedObjectKey = key;
					}
				});
				// if something has broken and the key comes back undefined, dont delete anything
				if(deletedObjectKey === undefined){
					return;
				}
				// ensure that the object to be deleted is no longer in the completedViews list
				_.each(self.completedViews, function(value, key, list){
					if(value === identifier){
						list.splice(key,1);
					}
				});
				// removes the item from the array and removes the view
				self.objects.splice(parseInt(deletedObjectKey,10),1)[0].remove();
				// validate the form
				app.trigger("createcontentlessobject:modelFinished");
			});
			// listening for when a new object is added
			app.listenTo(app, "createcontentlessobject:addNewObject", function(){
				self.addNewObject();
			});
			// listening for when objects are to be uploaded
			app.listenToOnce(app, "createcontentlessobject:uploadObjects", function(){
				self.uploadObjects();
			});
		},

		getObjectTypes: function(){
			this.objectTypes = [];
			var self = this;
			// set up the deferreds holder
			var deferreds = [];
			// async call for getting the form config
			app.context.configService.getFormConfig(this.options.config.get("form"), function(newConfig){
				// now that we have the form config, we can get the types
				_.each(newConfig.get("configuredTypes").models, function(value, key, list){
					// create and push the deferred onto the list
					var def = $.Deferred();
					deferreds.push(def);
					// determine if each object type is a container or not
					app.context.configService.isContainer(value.get("ocName"), function(isContainer){
						if(isContainer === "false"){
							self.objectTypes.push({
								label: value.get("label"),
								value: value.get("ocName"),
								localizedLabel: window.localize(value.get("label"))
							});
						}
						// resolve each deferred on its turn
						def.resolve();
					});
				});
				// now that the deferreds holder is filled with deferreds waiting to be resolved,
				// we can set up the function to be called when the deferreds are done
				$.when.apply(this, deferreds).done(function(){
					// if there is only one suitable type returned, then use that
					if(self.objectTypes.length === 1){
						// set the values needed to add new object views
						self.objectType = self.objectTypes[0].value;
						self.objectLabel = self.objectTypes[0].localizedLabel;
						// confirm the type and get the ball rolling
						self.confirmObjectType();
					} else {
						// set the objectType to null
						self.objectType = null;
						// create the view that holds the object type picklist
						self.objectTypePicklistView = new CreateContentlessObject.ObjectTypePicklist({
							config: self.options.config,
							objectTypes: self.objectTypes
						});
						// set the view of the picklist and render it
						self.setView("#objectTypePicklist", self.objectTypePicklistView).render();
					}
				});
			});
		},
		// once an object type is selected, add a new view and set up submit buttons
		confirmObjectType: function(){
			// if they havent selected a type yet, dont submit
			if(typeof this.objectType !== "string"){
				return;
			}
			// remove the type picker inputs
			// add a new object for the first time
			if(this.objectTypePicklistView){
				this.objectTypePicklistView.remove();
			}
			// hide the holder of the picklist
			$(".trac-config-top").addClass("hidden");
			// change the footer to hold submit buttons and render it
			this.footerView.onlyClose = false;
			this.footerView.render();
			// add a new object view
			this.addNewObject();
		},
		// sets up object type info on change
		updateObjectType: function(){
			// enable the confirm object type button once a type is selected
			this.$("#confirmObjectTypeBtn").prop("disabled", false);
			// grab the object type
			this.objectType = this.$("#objectTypeSelector").val();
			// grab the object type label
			this.objectLabel = this.$("#objectTypeSelector option[value='"+this.$("#objectTypeSelector").val()+"']").text();
		},
		// creates the contentless object properties form and adds it to the main view
		addNewObject: function(){
			var self = this;
			// disable the upload button since we are adding an invalid form
			this.$("#uploadObjectsBtn").attr("disabled", "true");
			// create the item view
			var newView = new CreateContentlessObject.CreateContentlessObjectItemView({
				config: self.options.config,
				objectType: self.objectType,
				objectLabel: self.objectLabel,
				identifier: self.getNextIdentifier(),
				handler: self.myHandler
			});
			// add the new object to the collection
			this.objects.push(newView);
			// once a new view is added, all other views are collapsed and the new one is visiblie
			_.each(this.objects, function(value, key, list){
				if(key !== list.length-1){
					value.toggleEditMode(false);
				}
			});
			// insert the new view and render it
			this.insertView("#contentless-object-outlet", newView).render();
		},
		// ensures that all contentless objects have unique identifiers for submission
		getNextIdentifier: function(){
			this.identifierIndex++;
			// identifiers are used as class names sometimes, so they cant have spaces
			return this.objectType.replace(/ /g, "-") + "-" + this.identifierIndex;
		},
		// submits the contentless objects to OC
		uploadObjects: function(){
			var self = this;
			// change the footer to only hold a close button after submission
			this.footerView.onlyClose = true;
			this.footerView.render();
			// create an OcoCollection to hold ocos
			var ocos = new OC.OpenContentObjectCollection();
			// grab all of the properties of each object's form for submission
			_.each(this.objects, function(value){
				var form = value.itemForm;
				var oco = new OC.OpenContentObject();
				// reset the oco properties
				oco.set("properties", {});
				// grab each of the property values
				_.each(form.controls(), function(valueInner, keyInner, listInner){
					oco.get("properties")[valueInner.id] = valueInner.value();
				});
				// set the object identifier
				oco.set("objectIdentifier", value.identifier);
				// set the object type
				oco.set("objectType", self.objectType);
				// add the oco to the collection of ocos
				ocos.add(oco);
			});
			// set parameters passed by action
			self.action.get("parameters").objectType = self.objectType;
			if(self.options.config.get("isHeaderMode")){
				self.action.get("parameters").parentPath = self.options.config.get("defaultFolder");
			} else {
				self.action.get("parameters").parentPath = self.action.get("parameters").objectId;
			}
			self.action.get("parameters").objects = ocos;
			// execute the action
			self.action.execute({
				success: function(result){
					// grab the necessary values for the results view
					var successList = [];
					_.each(result.result.successList, function(value, key, list){
						var valueKey = Object.keys(value)[0];
						var submittedObject = _.filter(result.parameters.objects, function(parameterObject){
							return valueKey === parameterObject.objectIdentifier;
						})[0];
						var object = {
							name: submittedObject.properties.objectName,
							id:valueKey.replace(/ /g,"-"),
							link:value[valueKey].replace(/ /g,"-")
						};
						successList.push(object);
					});
					var errorList = [];
					_.each(result.result.errorList, function(value, key, list){
						var valueKey = Object.keys(value)[0];
						var submittedObject = _.filter(result.parameters.objects, function(parameterObject){
							return valueKey === parameterObject.objectIdentifier;
						})[0];
						var object = {
							name: submittedObject.properties.objectName
						};
						errorList.push(object);
					});
					// create the results view
					self.resultsView = new CreateContentlessObject.UploadCompleteView({
						successList: successList,
						errorList: errorList,
						myHandler: self.myHandler
					});
					// change the current view since submission has happened
					self.$("#createContentlessObjectView").addClass("hidden");
					self.$("#footerContentlessObjectButtons").addClass("hidden");
					self.$("#footerCloseButton").removeClass("hidden");
					
					// set the results view
					self.setView("#resultsBox", self.resultsView).render();
				},
				error: function(jqXHR, textStatus, errorThrown){
					// show errors accordingly
					app[self.myHandler].trigger("loading", false);
					app[self.myHandler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) +
						jqXHR.status + " " + jqXHR.responseText);
				}
			});
		},
		afterRender: function(){
			// make sure that the view's max height is set correctly
			$("#createContentlessObjectView").css("max-height", 
				window.innerHeight - 
				parseInt($(".modal-dialog").css("margin-top"), 10) - 
				parseInt($(".modal-footer").css("height"), 10) - 
				parseInt($("#createContentlessObjectView").css("margin-bottom"), 10) - 
				parseInt($(".modal-header").css("height"), 10) - 
				parseInt($(".modal-body").css("padding-bottom"), 10) - 
				parseInt($(".modal-body").css("padding-top"), 10) - 
				// for some bottom padding
				50 + "px"
			);
		},
		serialize: function() {
			var modal = false;
			var rightSide = false;
			if(this.myHandler === "modalActionHandler") {
				modal = true;
			} else if(this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal: modal,
				rightSide: rightSide
			};
		}
	});

	// object picklist view
	CreateContentlessObject.ObjectTypePicklist = Backbone.Layout.extend({
		template: "actions/createcontentlessobjectobjectTypePicklist",
		initialize: function(options) {
			this.options = this.options || options;
			// the object types for this object type picker
			this.objectTypes = this.options.objectTypes;
		},
		serialize: function() {
			return {
				notSingleType: this.objectTypes.length !== 1,
				objectTypes: this.objectTypes
			};
		}
	});

	// individual views for each of the contentless objects to be added that hold the property forms
	CreateContentlessObject.CreateContentlessObjectItemView = Backbone.Layout.extend({
		template: "actions/createcontentlessobjectitemview",
		events:{
			"click .hpi-header": "toggleEditMode",
			"click .deleteObject": "deleteObjectView"
		},
		initialize: function() {
			var self = this;
			// set up the ui holder
			this.ui = {};
			// visiblity starts as true of a new view
			this.visible = true;
			// identifier of this object
			this.identifier = this.options.identifier;
			// variables passed in by the options
			this.objectType = this.options.objectType;
			// options for formsupport
			var options = {
				enableRequired: true,
				isCreate: true,
				acceptableAttrsByObjectType: {},
				formName: this.options.config.get("form")
			};
			// holder of form info and observables
			this.itemForm = {};
			// getting the form
			Formsupport.tsgFormSupport(this.itemForm, options);
			// set the object type of the form
			this.itemForm.objectType(this.objectType);
			// set the initial values of the controls once they are created to be blank
			this.itemForm.controls.subscribe(function() {
				this.itemForm.setValues({});
			});
			// subscribe to the objectName field to use as a header for this object view
			_.filter(this.itemForm.controls(), function(value){
				// return the control with objectName as the id
				return value.id === "objectName";
			})[0].value.subscribe(function(value){
				// test for nulls and undefined
				if(value !== ""){
					// set the text of the header
					self.$(".objectViewHeader").text(value);
				} else {
					// if the value is blank, set the title to "Unnamed Document"
					self.$(".objectViewHeader").text("Unnamed Document");
				}
			});
			// get the form validation set up
			this.itemForm.isValid.subscribe(function(isValid) {
				if(isValid){
					// if this form is finished, tell the main view that the form is finished
					app.trigger("createcontentlessobject:modelFinished", self.identifier);
					// change the header status
					self.$(".hpi-header").removeClass("hpi-section-header-danger").addClass("hpi-section-header-success");
				} else {
					// if this form is unfinished, tell the main view that the form is unfinished
					app.trigger("createcontentlessobject:modelUnfinished", self.identifier);
					// change the header status
					self.$(".hpi-header").removeClass("hpi-section-header-success").addClass("hpi-section-header-danger");
				}
			});
		},
		// delete the current view
		deleteObjectView: function(){
			// fire the event that deletes this view
			app.trigger("createcontentlessobject:deleteObjectView", this.identifier);
		},
		// if the header is clicked, toggle the visiblity of the form
		toggleEditMode: function(visiblity){
			// toggle the visiblity boolean
			this.visible = typeof visiblity === "boolean" ? visiblity : !this.visible;
			if(!this.visible){
				// hide the form
				this.ui.content.slideUp();
				// change the arrow direction
				this.ui.upDownIndicator.find("span").removeClass("glyphicon glyphicon-chevron-up").addClass("glyphicon glyphicon-chevron-down");
			} else {
				// show the form
				this.ui.content.slideDown();
				// change the arrow direction
				this.ui.upDownIndicator.find("span").removeClass("glyphicon glyphicon-chevron-down").addClass("glyphicon glyphicon-chevron-up");
			}
		},
		afterRender: function() {
			// set the ui objects
			this.ui.content = this.$(".hpi-section-content");
			this.ui.upDownIndicator = this.$(".hideTracBtn");
			// animate the scrolling to the newest view that was added
			$('#createContentlessObjectView').animate({
				scrollTop: $("#itemView-" + this.identifier).offset().top - 10
			});
			kb.applyBindings(this.itemForm, this.$el[0]);
		},
		serialize: function(){
			return {
				identifier: this.options.identifier,
				objectType: this.objectLabel
			};
		}
	});

	// this view is responsible for taking in a successList and an errorList and displaying the results of the upload
	CreateContentlessObject.UploadCompleteView = Backbone.Layout.extend({
		template: "actions/createcontentlessobjectresults",
		events: {
			"click .successLink" : "closeModal"
		},
		initialize: function(){
			var self = this;
			self.successList = self.options.successList;
			self.errorList = self.options.errorList;
			self.myHandler = self.options.myHandler;
		},
		// when the link is clicked, the modal needs to disappear
		closeModal: function(){
			if(this.myHandler === "modalActionHandler"){
				// triggers the event that hides the modal
				app[this.myHandler].trigger("hide");
			}
		},
		serialize: function(){
			return {
				successList: this.successList,
				successes: this.successList.length !== 0,
				errorList: this.errorList,
				errors: this.errorList.length !== 0
			};
		}
	});

	// view for holding buttons in the footer of the modal
	// toggles between having one close button and a addNewObject, uploadObjectsBtn, and cancel button
	CreateContentlessObject.FooterView = Backbone.Layout.extend({
		template: "actions/createcontentlessobjectFooterView",
		events: {
			"click #uploadObjectsBtn": "uploadObjects",
			"click #contentlessobjectAddNewBtn": "addNewObject",
			"click #contentlessobjectCloseBtn": "closeModal"
		},
		initialize: function(){
			// starts as true
			this.onlyClose = true;
			this.myHandler = this.options.myHandler;
		},
		addNewObject: function(){
			// fires an event that adds a new object
			app.trigger("createcontentlessobject:addNewObject");
		},
		uploadObjects: function(){
			// fires an event that uploads the current objects
			app.trigger("createcontentlessobject:uploadObjects");
		},
		// when the link is clicked, the modal needs to disappear
		closeModal: function(){
			if(this.myHandler === "modalActionHandler"){
				// triggers the event that hides the modal
				app[this.myHandler].trigger("hide");
			}
		},
		serialize: function(){
			return {
				onlyClose: this.onlyClose
			};
		}
	});

	CreateContentlessObject.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/createcontentlessobjectconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;

			viewModel.defaultFolder = kb.observable(viewModel.model(),"defaultFolder");

			viewModel.form = kb.observable(viewModel.model(), "form");
			var formSubscribePlaceholder = viewModel.form();
			viewModel.potentialForms = ko.observableArray();
			app.context.configService.getFormConfigNames(function(formConfigNames) {
				viewModel.potentialForms(formConfigNames);
				//since the form value is bound from the potentialForms observable,
				//this context call will come back after the form has been gathered
				//from the config. this resets the form to the right value.
				viewModel.form(formSubscribePlaceholder);
			});
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
			self.$('[data-toggle="tooltip"]').tooltip();
		}
	});

	actionModules.registerAction("createContentlessObject", CreateContentlessObject, {
		"actionId": "createContentlessObject",
		"label": (window.localize("customConfig.createContentlessObjectConfig.addContentlessObject")) ,
		"icon": "plus"
	});

	return CreateContentlessObject;

});
require(["createcontentlessobject"]);