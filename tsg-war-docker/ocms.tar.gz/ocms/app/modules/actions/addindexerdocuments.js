// Advancedsearch module
define("addindexerdocuments", [
  // Application.
  "app",
  "modules/formsupport",
  "fileupload",
  "modules/actions/actionmodules"
],

function(app, Formsupport, fileUpload, actionModules) {

// Map dependencies from above array.
    "use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var Action = {};

    function IndividualDocUploadViewModel(vmArrayIndex, action, myHandler, vmArray, file) {
		var self = this;

		var options = {
        	enableRequired : false
		};
		Formsupport.tsgFormSupport(self, options);

		// Index location of the view model in the array
		self.vmArrayIndex = ko.observable(vmArrayIndex);

		self.vmLabel = ko.observable();
		
		_.each(self.controls(), function (control) {
			if (control.id === "name") {
				if (control.value()) {
					self.vmLabel(control.value());
				} else {
					var docNumber = self.vmArrayIndex() + 1;
					self.vmLabel((window.localize("modules.actions.addIndexDocuments.asset")) + docNumber);
				}
			}
		});

		// Text shown after a user picks a document to upload
		self.fileNameText = ko.observable();

		//Text for error message, personalized for each error
		self.errorText = ko.observable();
		
		//Text for edit properties button -- varies when edit properties
		//form is visible or not
		self.editPropertiesText = ko.observable(window.localize("modules.actions.editProperties"));
		
		//Shown when document is being uploaded, updates when progress is updated
		//by fileUpload
		self.uploadProgress = ko.observable("0%");
	
	
		//Visibility Bindings
		
		//documents selected to copy properties to
		self.selectedCopyDocs = ko.observableArray();
		
		//file selected by user to upload
		self.fileToUpload = ko.observable(undefined);

		self.backgroundFileToUpload = ko.observable(file);
		
		//after user chooses document to upload, this button is visible
		self.showRemoveDocButton = ko.observable(false);
		
		//overall form visibility, includes everything but error/success, upload progress,
		//and buttons at the bottom of the modal
		self.showForm = ko.observable(true);
		
		//visiblity of success message
		self.showSuccess = ko.observable(false);
		
		//visibility of error message
		self.showError = ko.observable(false);
		
		//only show the copy button if there are more than one form
		//in the modal
		self.showCopyPropertiesButton = ko.computed(function(){
			if(getNumberOfDocs() > 1){
				return true;
			}
			else{
				return false;
			}
		});
			
		//for edit properties form visibility			
		self.isShowingEditForm = ko.observable(false);
		
		//for copying properties form visibility
		self.isShowingCopyForm = ko.observable(false);
		
		//when true, the upload progress stuff is visible
		self.submittingDoc = ko.observable(false);
			

		//Other Bindings
		
		//copies the applicable folder properties to the document if
		//the property is set in config-details
		self.objectType.subscribe(
		function(){
		/*	
			if(config.otherProperties.copyFolderProperties === "true"){
				var propMap = TSG.stage.model.container().editableProperties;
				//don't copy object name
				if(propMap["name"]){
					delete propMap["name"];
				}
				self.setValues(propMap);
			}*/
		});

		//Used to enable the 'Submit All Documents' button
		//and for validation message for the form
		self.formIsValid = ko.computed(function(){
			if(self.isValid() && self.fileToUpload()){
				return true;
			}
			else {
				return false;
			}				
		}).extend({ equal: {params: true, message: (window.localize("modules.actions.addIndexDocuments.theFormIsNot"))}});
		
		//used to number the documents correctly based on 
		//location in array, called when a document is created or deleted
		self.populateOtherDocs = function(){
			var docs = [];
			for(var i=0; i<getNumberOfDocs(); i++){
				if(i !== self.vmArrayIndex()){
					var docNum = i+1;
					docs.push({index: i, docName: "Asset "+docNum}); 
				}
			}
			return docs;
		};

		//list of other docs in the modal
		self.otherDocs = ko.observableArray(self.populateOtherDocs());
		
		
		//Individual View Model functions
		
		//toggles the visibility of the edit properties form
		//toggles the edit properties button text as well
		self.toggleShowingEditForm = function(){
			if(self.isShowingEditForm()){
				self.isShowingEditForm(false);
				self.editPropertiesText(window.localize("modules.actions.editProperties"));
			}
			else{
				self.isShowingEditForm(true);
				self.editPropertiesText(window.localize("modules.actions.hideProperties"));
			}
		};
					
		//toggles the visibility of the copy properties form
		self.toggleShowCopyForm = function(){
			if(self.isShowingCopyForm()){
				self.isShowingCopyForm(false);
			}
			else{
				self.isShowingCopyForm(true);
			}
		};
		
		//Called when a user clicks the Remove button
		//Clears out the file to upload and the text for the DOM
		self.clearFileToUpload = function(){
			self.fileNameText(undefined);
			self.fileToUpload(undefined);
		};

		function getNumberOfDocs() {
			return vmArray.length;
		}
					
		//allows user to close the error message
		self.removeErrorMessage = function(){
			self.showError(false);
		};
		
		//since the file upload was calling the success function along with
		//the error function when there was an error, 
		//we will do the error/success parsing ourselves
		//
		//returning an anonymous function allows us to pass this function
		//extra parameters
		self.parseResponse = function(successObservable, failObservable){
			return function(jqXHR, textStatus, errorThrown){
				//IE8 and IE9 are reporting 200 success when there are 
				//really 500 errors, but when there are errors,
				//jqXHR is undefined, so that is how we are differentiating for IE
				if(jqXHR && jqXHR !== undefined){
					//Chrome and Firefox do things correctly, so
					//this logic checks for errors in Chrome/Firefox
					if(textStatus === "error"){
						self.errorText((window.localize("modules.actions.addIndexDocuments.assetDidNotUpload")) + errorThrown);
						self.showError(true);
						self.showForm(true);
						failObservable(failObservable()+1);
						app.log.debug(window.localize("modules.actions.addIndexDocuments.errorFunction"));
					}
					else{
						//set up success screen
						self.showForm(false);
						self.showSuccess(true);
						//if a document failed, and then is resubmitted and succeeds,
						//we don't want both the error message and the success showing
						self.showError(false);
						//increment success observable for FormViewModel
						successObservable(successObservable()+1);
					}
				}
				//If jqXHR doesn't exist/is undefined, IE8/IE9 returned an error
				else{
					//set up error message
					self.errorText(window.localize("modules.actions.addIndexDocuments.assetDidNotUpload"));
					self.showError(true);
					self.showForm(true);
					//increment fail observable for FormViewModel
					failObservable(failObservable()+1);
				}
				self.submittingDoc(false);
			};
		};

        return self;
    }

    Action.FormViewModel = function(action, myHandler) {
    	var that = this;

		//FormViewModel Bindings
		that.shouldShowDragNDropArea = ko.observable(true);
		
		//array of upload document view models (sub viewModels)
        that.viewModelsArray = ko.observableArray();
		
		//Visibility Bindings
		that.enableButtons = ko.observable(true);
		
		that.showAddDocumentsButton = ko.observable(true);
		
		that.showSubmitButton = ko.observable(true);
		
		//Text Bindings
		that.submitButtonText = ko.observable(window.localize("modules.actions.addIndexDocuments.submitAssets"));
		
		that.cancelButtonText = ko.observable(window.localize("generic.cancel"));
		
		//Other Bindings
		that.indexPackageName = ko.observable("");

		// Index upload module needs an individual type selection that applies to all the types added
		that.objectType = ko.observable("");

		that.finalDestination = ko.observable(""); // noderef that points to the folder location for the uploaded content

		that.availableDocumentTypes = ko.observableArray([""]);

		// Retrieve document types available to the user
		app.user.fetch().done(function(data) { 
			var userGroups = app.user.get("groupNames");
			app.context.configService.getIndexerConfigNames(function(names) {
				app.context.configService.getIndexerConfigByName(names[0], function(config){
					var indexGroups = config.get("indexerUserGroups");
					_.each(indexGroups.get("userGroups").models, function(group) {
						if ($.inArray(group.get("groupName"), userGroups) != -1) {
							_.each(group.get("allowedUploadTypes"), function(type) {

								// get the label via configservice for this type (we need it to match our folder name)
								app.context.configService.getLabels(type).done(function(label) { 
									if ($.inArray(label, that.availableDocumentTypes()) == -1) {
										that.availableDocumentTypes.push(label);
									}
								});
								
							});
						}
					});
				});
			});

			// If no available object types for user to upload...
			if (that.availableDocumentTypes().length === 1 && that.availableDocumentTypes()[0] === "") {
				app[myHandler].trigger("showError", ((window.localize("modules.actions.addIndexDocuments.cannotUploadAnyAssets")) /*<br />**/ (window.localize("modules.actions.addIndexDocuments.pleaseContractYour"))));
			}
		});
	
		//submit button enabler -- only works if all the forms are valid and enable buttons is true
		that.enableSubmitButton = ko.computed(function(){
			if(that.enableButtons()){
				if(that.viewModelsArray().length > 0) {
					for(var i=0; i<that.viewModelsArray().length; i++){
						if(!that.viewModelsArray()[i].isValid() || !that.viewModelsArray()[i].fileToUpload()){
							return false;
						}
					}
				}
				else {
					return false;
				}
				if(that.indexPackageName().trim() === "" || that.indexPackageName() === null) {
					return false;
				}
				if(that.objectType().trim() === "" || that.objectType() === null) { 
					return false;
				}
				//if all the forms are valid and enableButtons is true, return true
				return true;
			}
			else {
				return false;
			}
		});
		
		//number of documents that have been successfully uploaded
		that.successSubmits = ko.observable(0);
		
		//number of documents that attempted to be uploaded, but failed
		that.failSubmits = ko.observable(0);
		
		//used to prevent pop-up on modal close if all docs have been uploaded successfully
		that.allDocsUploadedSuccessfully = ko.observable(false);
		
		//keep track of all the submits, so we can know when all of them have returned
		that.totalNumberOfSubmits = ko.computed(function(){return that.failSubmits() + that.successSubmits();});
		
		that.totalNumberOfSubmits.subscribe(function(newVal){
			//once the total number of submits is equal to the number of docs,
			//see if any of the docs have failed or not
			if(newVal === that.viewModelsArray().length){
				if(that.failSubmits() > 0){
					//change buttons for post-failure
					app.log.debug(window.localize("modules.actions.addIndexDocuments.failureHit"));
					that.submitButtonText(window.localize("modules.actions.addIndexDocuments.resubmitFailed"));
				}
				else{
					//change buttons for all-success
					app.log.debug(window.localize("modules.actions.addIndexDocuments.successHit"));
					that.showSubmitButton(false);
					that.cancelButtonText("Close");
					that.allDocsUploadedSuccessfully(true);
					//trigger actionComplete event
					app[myHandler].trigger("showMessage", (window.localize("modules.actions.addIndexDocuments.allAssets")));
					app.trigger("stage.refresh.containerId", true);
					app.trigger("dashboard:refreshInbox");
				}
				//refresh the stage so new docs show up in 'related objects'
				that.enableButtons(true);
			}
		});

		//add new document to the array of sub viewModels
        that.addNewDocument = function (file) {
        	if (!file){ file = undefined; }
            that.viewModelsArray.push(new IndividualDocUploadViewModel(that.viewModelsArray().length, action, myHandler, that.viewModelsArray(), file));
            //update the list of docs in the copy properties menu
			for(var i=0; i<that.viewModelsArray().length; i++){
				that.viewModelsArray()[i].otherDocs(that.viewModelsArray()[i].populateOtherDocs());
			}
        };

        //add new document to the array of sub viewModels
        that.addNewDocuments = function (files) {
        	$.each(files, function(key, file){
				that.addNewDocument(file);
			});
        };

		//remove specified document from array
		//update docNumber and other docs list for remaining documents
        that.removeDocument = function () {
            that.viewModelsArray.remove(this);
			for(var i=0; i<that.viewModelsArray().length; i++){
				that.viewModelsArray()[i].vmArrayIndex(i);
				that.viewModelsArray()[i].otherDocs(that.viewModelsArray()[i].populateOtherDocs());
			}
        };

        that.findOrCreateIndexFolders = function(callback) { 			
			// the following gets a little ugly w/ nesting - we need to avoid race conditions so we need folders to be created before executing the action..
			// check that all our required folders exist.
			// TODO: Add the folder configuration to the indexer config (e.g. configure "Uploads")
			$.ajax({
				url: app.serviceUrlRoot + "/content/findOrCreateFolderByPath" + "?path=Upload",
				dataType: "json", 
				type: "POST",
				success: function(data) { 
					// created or found the root Uploads folder
					$.ajax({
						url: app.serviceUrlRoot + "/content/findOrCreateFolderByPath" + "?path=" + encodeURIComponent(data.result + "/" + that.objectType()),
						dataType: "json",
						type: "POST",
						success: function(data) { 
							// now we'll create our folder for this unique package set
							// we'll use the returned id to specify where this action is going to upload
							$.ajax({
								url: app.serviceUrlRoot + "/content/findOrCreateFolderByPath" + "?path=" + encodeURIComponent(data.result + "/" + $.trim(that.indexPackageName())),
								dataType: "json",
								type: "POST",
								success: function(data, textstatus, jqXHR) { 
									// set observable that contains the objectId with the final folder path for upload
									that.finalDestination(data.objectId);
									callback(jqXHR); // should pass a deferred
								}
							});
						}
					});
				}
			});

			// callback should return the id of the newly created folder
			callback();

		};
		
		//submits all of the docs in the array to the repo
		that.submitAllDocs = function(){
			
			that.findOrCreateIndexFolders(function(deferred) {
				// execute submit on callback	
				//reset the counters
				that.shouldShowDragNDropArea(false);
				that.successSubmits(0);
				that.failSubmits(0);
				//disable buttons and remove add docs button
				that.showAddDocumentsButton(false);
				that.enableButtons(false);

				for(var i=0; i<that.viewModelsArray().length; i++){
					//if the form isn't showing (Document Success screen is showing)
					//don't submit the doc
					if(that.viewModelsArray()[i].showForm()){
						that.viewModelsArray()[i].submitDoc(
						//first method is success, second method is failure
							that.successSubmits,that.failSubmits,deferred
						);
					}
					//since the form is still on the array, if it has already
					//been successfully submitted, add it to the count
					else{
						that.successSubmits(that.successSubmits()+1);
					}
				}
			});

		};

		that.closeModal = function() {
			app[myHandler].trigger("hide");
		};

		that.slideOutForm = function(elem){ 
			if(elem.nodeType === 1){
				$(elem).slideUp(400, function(){
					$(elem).remove();
				});
			}
		};
		
		that.slideInForm = function(elem){ $(elem).slideDown(400);};
		
        return that;
	};


	Action.View = Backbone.Layout.extend({
		template: "actions/addindexerdocuments",
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			ko.bindingHandlers.fileToUploadBinding = {
				init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext){
					$(element).bind('change', function (e) {
						$(element).fileupload('add', {
							fileInput: $(this)
						});
					});
					$(element).fileupload({
						type: 'post',
						url: app.serviceUrlRoot + '/action/executeWithAttachment',
						add: function(e, data){										
							if(data.files && data.files[0]){
								bindingContext.$data.fileNameText((window.localize("modules.actions.addIndexDocuments.fileToUpload")) + data.files[0].name);
								//set the object name to the name of the file selected
								bindingContext.$data.setValues({"name":data.files[0].name});
								bindingContext.$data.isShowingEditForm(true);
								bindingContext.$data.editPropertiesText(window.localize("modules.actions.hideProperties"));
								var val = valueAccessor();
								val(data);	
							}
						},
						dropZone: $(element)
					});
					
					//for whatever reason, adding additional form data through the formData option
					//on the plugin wasn't working, so before we submit, we are going to put
					//the params directly on the file's form data when it submits
					$(element).bind('fileuploadsubmit', function(e, data){
						var repoTypeName;
						app.context.configService.getObjectTypeConfig(function(config) {
							/* 
							//this seems jacked up
							if (config.get("configs").ocName === bindingContext.$data.objectType()) {
								repoTypeName = config;
							}
							*/
							$.each(config.get("configs").models, function(indx, otc) {
								if(otc.get("ocName") === bindingContext.$parent.objectType()) { 
									repoTypeName = otc.get("ocName");
								}
							});
						});
						var params = {
							'objectType' : repoTypeName,
							'folderTitle' : bindingContext.$parent.indexPackageName()
						};
						//params.objectId = action.get("parameters").objectId; // for old file upload
						// for indexing, we're setting this to a new folder we created based on some criteria
						params.objectId = bindingContext.$parent.finalDestination();
						params.properties = {};
						$.each(bindingContext.$data.getValues(), function(key, item){
							params.properties["prop-" + key] = item;
						});
						app.log.debug(window.localize("modules.actions.addIndexDocuments.timeToSubmit"));
						data.formData = {					
								'action' : JSON.stringify({
									'name' : 'addDocuments',
									'parameters' : params
								})
						};
					});
					
					$(element).bind('fileuploadprogress', function(e, data){
						var progress = parseInt(data.loaded/data.total * 100, 10);
						bindingContext.$data.uploadProgress(progress + "%");
					});
					
					bindingContext.$data.submitDoc = function(successCountObservable, failCountObservable, deferred) {

						if(deferred !== undefined) { 
							deferred.done(function() { 
								if(bindingContext.$data.fileToUpload() && bindingContext.$data.fileToUpload().submit){
									bindingContext.$data.showForm(false);
									bindingContext.$data.submittingDoc(true);
									bindingContext.$data.isShowingEditForm(false);
									//if document is being resubmitted, take out the error message while uploading
									bindingContext.$data.showError(false);
									bindingContext.$data.editPropertiesText(window.localize("modules.actions.editProperties"));
									var element = bindingContext.$data.fileToUpload();
									element.submit().always(bindingContext.$data.parseResponse(successCountObservable, failCountObservable));
								}
							});
						}

					};
				},
				update: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext){

					if(bindingContext.$data.backgroundFileToUpload()) {
						$(element).fileupload('add', 
							{ files: [bindingContext.$data.backgroundFileToUpload()] }
						);
					}
					
				}
			};
			
			//allows for elements to slide in and out of visibility -- for effect, replaces visible binding
			ko.bindingHandlers.slideVisibility = {
				update: function(element, valueAccessor, allBindingsAccessor){
					var value = valueAccessor();
					var valueUnwrapped = ko.utils.unwrapObservable(value);
					if(valueUnwrapped === true){
						$(element).slideDown(200);
					}
				}
			};
			ko.bindingHandlers.dragInMultipleDocuments = {
				init: function(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext){
					$.event.props.push('dataTransfer');
					$(element).bind('dragenter', function (e) {
						$(this).addClass("hover");
						// hide children because they seem to interfere
						$(this).children().hide();
						e.stopPropagation();
					});
					$(element).bind('dragleave', function (e) {
						$(this).removeClass("hover");
						$(this).children().show();		    			
					});
					$(element).bind('drop', function (e) {
						var files = e.dataTransfer.files;
						$(this).removeClass("hover");
						e.preventDefault();
						$(this).children().show();

						bindingContext.$data.addNewDocuments(files);
					});
					$(window).bind('dragover', function(e) {
						e.preventDefault();
					});
				}
			};
			this.viewModel = window.uvm = new Action.FormViewModel(this.action, this.myHandler);
		},
		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
			$(document).bind('drop dragover', function (e) {
			    e.preventDefault();
			});
		},

		serialize: function() {
            var modal = false;
			var rightSide = false;
			if(this.myHandler === "modalActionHandler") {
				modal = true;
			} else if(this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal: modal,
				rightSide: rightSide
			};
        }
	});

	Action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/addindexerdocumentsconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;

			viewModel.form = kb.observable(viewModel.model(), "form");
			var formSubscribePlaceholder = viewModel.form();
			viewModel.potentialForms = ko.observableArray();
			app.context.configService.getFormConfigNames(function(formConfigNames) {
				viewModel.potentialForms(formConfigNames);
				//since the form value is bound from the potentialForms observable,
				//this context call will come back after the form has been gathered
				//from the config. this resets the form to the right value.
				viewModel.form(formSubscribePlaceholder);
			});
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("addIndexerDocuments", Action, {
        "actionId" : "addIndexerDocuments",
      	"label" : "Upload Assets",
      	"icon" : "ok"
    });

	return Action;

});
require(["addindexerdocuments"]);