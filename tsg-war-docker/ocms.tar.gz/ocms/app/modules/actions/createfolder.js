define("createfolder", [
	"app",
	"modules/formsupport",
	"modules/hpiadmin/otc/objecttypeconfig",
	"modules/common/spinner",
	"modules/actions/actionmodules",
	"modules/common/ocquery",
	"modules/common/spinner",
	"oc"
],
function(app, Formsupport, OTC, HPISpinner, actionModules, OcQuery, OCMSSpinner) {
	
	"use strict";

	var CreateFolder = {};

	// in the view model using a bind to set up self.unqiueAttributeUpdated
	CreateFolder.uniqueAttributeUpdated = function(control) {
		var attrName = control.id;
		var newVal = control.value();
		var self = this;
		
		// query pre-checks
		if (!newVal || newVal === "") { return; } // don't run the query with blank or undefined values
		if (control.value.isValid()) { return; } // only run the query if the form is invalid
		if (attrName.toLowerCase().search(/date/) !== -1) { newVal = newVal + "|" + newVal; } // if attr is a date, format query val to a range
		if (newVal.search(/\*/) !== -1 || newVal.search(/%/) !== -1) { return; } // don't allow wildcards in the value (prevent regex wildcard searches here)

		// do an ocquery for folders, only of the current type, that already have the passed-in value of uniqiue attribute 
		var query = new OcQuery.Collection([], {});
		query.searchParameters = [
			{   // search current folder type
				paramName: self.objectType(),
				paramValue: self.objectType(),
				paramType : "type",
				operator: "OPERATOR_EQUALS"
			},
			{   // search for those with unique attribute
				paramName: attrName,
				paramValue: newVal,
				paramType : "property",
				operator: "OPERATOR_EQUALS"
			}
		];

		// run the query
		query.fetch({
			success: function(data){
				if(data.models.length) {
					// we found the folder(s), alert the user
					var folder = data.models[0]; // select the first one to alert the user about
					self.foundFolder([
						{ foundFolderId: folder.get("objectId"), name: folder.get("properties").objectName }
					]);
				}
				else {
					// something went wrong, we should be running this query after the evaluator confirms a duplicate exists
					self.foundFolder([]);
				}
			},
			error: function(jqxhr){
				app[self.myHandler].trigger("showError", (window.localize("modules.actions.createFolder.sorry")) +
				jqxhr.status + " " + jqxhr.responseText);
			}
		});
	};

	CreateFolder.ViewModel = function(createFolderView, options) {
		var self = this;

		var action = options.action;
		var myHandler = options.config.get("handler");
		var config = options.config;

		self.createFolderView = createFolderView;
		self.myHandler = myHandler;

		// this is the selected trac the user chose
		// initialize the subscriber here to ensure that the viewModel's initialization isn't
		// run before the subscribe is registered (as was the case when only one trac was configured)
		// whether or not this is a header action
		self.isHeaderMode = ko.observable(config.get("isHeaderMode"));

		if (self.isHeaderMode()) {
			// when executed from the header
			// a trac needs to be selected, default to none selected
			self.tracSelected = ko.observable(false);
		}
		else {
			// executed from within a folder, there is no trac on the form
			// if tracSelected is false the form won't validate and setting this value 
			// to true will resolve that check and allow form to be validated as normal
			self.tracSelected = ko.observable(true);
		}

		// available object types for the user to choose from when creating the folder
		self.availableObjectTypes = ko.observableArray([]);

		self.foundFolder = ko.observableArray([]);
		self.showBulkExcelImport = ko.observable(false);
		
		self.showBulkCreateFolderButton = function(){
			// determine if the bulk create folders button should be shown
			var showBulkCreateFolder = config.get('allowBulkExcelImport') !== 'false';
			// if there are no groups allowed, then all groups are allowed and the only thing to determine if bulk create folders is allowed is the slider option
			if (config.has('allowedGroupsForBulkExcelImport') && config.get('allowedGroupsForBulkExcelImport').length > 0 && showBulkCreateFolder) {
				var bulkCreateFolderAllowedGroups = _.intersection(app.user.get("groupNames"), config.get('allowedGroupsForBulkExcelImport'));
				if (bulkCreateFolderAllowedGroups.length < 1) {
					showBulkCreateFolder = false;
				}
			} 
			
			self.showBulkExcelImport(showBulkCreateFolder);
		};
		
		// only check to see if we should show the bulk create folder button if bulk create folders is turned on
		if (config.has('allowBulkExcelImport') && config.get('allowBulkExcelImport') !== 'false'){
			// make sure that the user's groups have been loaded before checking them to see if 
			// they are in the correct group for bulk createfolder
			if (app.user.get("groupNames")) {
				self.showBulkCreateFolderButton();
			} else {
				app.user.getGroups().done(function() {
					self.showBulkCreateFolderButton();
				});
			}
		}
		
		// disable the bulkCreateFolder button until the object type is figured out
		self.enableBulkCreateFoler = ko.observable(false);

		// the selected object type for folder creation
		self.objectType = ko.observable();
		self.showAvailableObjectTypes = ko.observable(false);

		// get filterObjectTypesByUser config
		app.context.configService.getApplicationConfig(function (appConfig) {
			self.filterObjectTypesByUserIsEnabled = (appConfig && appConfig.get("filterObjectTypesByUser")
				&& appConfig.get("filterObjectTypesByUser") === true);
		});

		//Called when the selected trac has changed, this function
		//finds and processes object types that the user has permission to use
		//on the new selected trac
		self.newTracSelectedHandler = function(newVal) {
			self.tracSelected(false);
			var tracConfigs = config.get("tracTypePaths");

			// reset the error box if one existed on a previous trac
			self.foundFolder([]);

			// deselect the previously selected object type
			self.objectType(undefined);
			// remove the list of available object types
			self.availableObjectTypes([]);
			// get rid of the controls if they've been generated
			if(self.controls) {
				self.controls([]);	
			}
			// rehide the list of available object types to choose from
			self.showAvailableObjectTypes(false);
			if(newVal && newVal.name) { // this will be undefined if the user chooses the 'Choose trac...' option
				self.tracSelected(true);
				if(self.tracToUse) {
					self.tracToUse(newVal.name);
				}

				// this is the trac configuration for the selected trac
				var tracConfig = tracConfigs[newVal.name];
					
				// these are the types the user has chosen to limit folder creation to
				var limitedTypes = tracConfig.limitTypes.types;


				//we need to get the right form and use some formsupprt functions
				//to rebuild the form
				self.form(undefined);
				self.formName(tracConfig.form);
				self.buildFormSupportControls();

				// loop over each configured object type path configuration when the object type has been filterd by
				// user access
				var deferredArray = [];
				_.each(tracConfig.paths, function(path, objectType) {
					if(objectType !== "_id") { // skip _id key
						// either the user is not limiting the types, 
						// or the user is limiting the types and the current type is in the allowed types for folder creation
						if(tracConfig.limitTypes.enabled === "false" || (tracConfig.limitTypes.enabled === "true" && $.inArray(objectType, limitedTypes) !== -1)) { 
							if(path !== "") { // if the path is not empty

								// check to see if the user has write permission on the specified path
								var permissionDeferred = $.Deferred();

								$.ajax({
									type : "GET",
									contentType: "application/json",
									url: app.serviceUrlRoot + "/permission/write?id=" + path,
									success: function(data) {
										var labelDeferred;
										if (data) {
											labelDeferred = self.securityByPathSuccess(objectType, true);
											self.enableBulkCreateFoler(true);
										} else {
											labelDeferred = self.securityByPathSuccess(objectType, false);
										}
										deferredArray.push(labelDeferred);
									},
									error: function(jqXHR) {
										// most commonly will happen if the specified path doesn't exist
										app[myHandler].trigger("showError", window.localize("modules.actions.sorryAnErrorHasOccured") +
											jqXHR.status + " " + jqXHR.responseText);
									},
									complete: function() {
										permissionDeferred.resolve();
									}
								});

								deferredArray.push(permissionDeferred);
							} 
							else{
								// This code should only be run for CaseIDPrefix Mode (where you don't have a parent location)
								var labelDeferred = self.securityByPathSuccess(objectType, true);
								deferredArray.push(labelDeferred);
								self.enableBulkCreateFoler(true);
							}
						}
					}
				});

				//Once all opjectType labels have been loaded/configured successfully, process them all and assign them to the form.
				$.when.apply($, deferredArray).done(function() {
					self.filterResolvedObjectTypes();
				});
			}
		};

		// As of now, all attributes of the selected Folder type are being put into the form
		// Must change if we want to limit what attributes are displayed in the form
		this.selectedTrac = ko.observable();
		this.selectedTrac.subscribe(self.newTracSelectedHandler);

		self.securityByPathSuccess = function(objectType, fetchObjectTypeLabel) {
			var labelDeferred = $.Deferred();

			if (fetchObjectTypeLabel) {
				app.context.configService.getLabels(objectType).done(function(typeLabel) {
					self.availableObjectTypes.push({
						"label": typeLabel,
						"value": objectType
					});
					labelDeferred.resolve();
				});
			} else {
				labelDeferred.resolve();
			}

			return labelDeferred;
		};

		//Sets the object type for the form modal if possible, or allows the user to pick among
		//all types available to them if there are multiple options.
		self.filterResolvedObjectTypes = function() {
			var filterByObjectTypeDeferred = $.Deferred();

			//If filtering is required, we'll need to fetch a config. Otherwise
			//we can execute immediately
			if(self.filterObjectTypesByUserIsEnabled) {
				self.filterObjectTypesByUser(self.availableObjectTypes()).done(function() {
					filterByObjectTypeDeferred.resolve();
				});
			} else {
				filterByObjectTypeDeferred.resolve();
			}

			//Set object type or allow user to pick among all available object types
			$.when(filterByObjectTypeDeferred).done(function() {
				// if there's only one available object type to choose, just default to it
				// this will also make the object type select box disabled
				if(self.availableObjectTypes().length === 1) {
					self.objectType(self.availableObjectTypes()[0].value);
				}

				self.showAvailableObjectTypes(true);
			});
		};

		// calls the oc security endpoint to check which objectTypes
		// this user has access to
		self.filterObjectTypesByUser = function(objectTypes) {
			var deferred = $.Deferred();
			var potentialTypes = [];
			var validObjectTypes = [];

			_.each(objectTypes, function(type) {
				potentialTypes.push(type["value"]);
			});

			$.ajax({
				type: "POST",
				dataType: "json",
				contentType: "application/json",
				data: JSON.stringify(potentialTypes),
				url: app.serviceUrlRoot + "/security/filterObjectTypesByUser",
				success: function (returnedObjectTypes) {
					validObjectTypes = returnedObjectTypes;
				},
				error: function() {
					// if an error occurs return the original list without the security filter
					validObjectTypes = potentialTypes;
				},
				complete: function() {
					// run after every call regardless of response. we want to resolve with valid types
					self.replaceWithFilteredTypes(validObjectTypes).done(deferred.resolve());
				}
			});
			return deferred.promise();
		};

		// replaces the list of object types with the list
		// of object types that the user has access to
		self.replaceWithFilteredTypes = function(typesToKeep) {
			var self = this;
			var tempObjectTypes = [];

			var deferred = $.Deferred();

			// we need to fetch the OTC, for this trac, but we don't need the full config
			app.context.configService.getAdminOTC(function(otc) {
				// We also need the formTypes, to see what can be created based on the form
				app.context.configService.getFormConfig(self.formName(), function(formConfig) {
					formConfig.get("configuredTypes").each(function(typeConfig) {
						// Find the form's type on the OTC
						var type = otc.get("configs").findWhere({ocName : typeConfig.get("ocName")});
						if (typesToKeep.indexOf(type.get('ocName')) !== -1){
							// If type is in the "types to keep" array, push it into object types
							tempObjectTypes.push({
								label: type.get("label"),
								value: type.get("ocName")
							});
						}
					});
					self.availableObjectTypes(tempObjectTypes);
					deferred.resolve();
				});
			});

			return deferred.promise();
		};

		// display helpful messages if legacy versions of this action cause problems
		if(config.get("isHeaderMode") === undefined) {
			app.log.warn((window.localize("modules.actions.createFolder.thereIsNoHeader")));
		} else {
			// if this is configured as being in header mode but there are no tracTypePaths
			if(config.get("isHeaderMode") && config.get("tracTypePaths") === undefined) {
				app.log.warn((window.localize("modules.actions.createFolder.thereAreNoTrac")));
			}
		}
		
		self.onFoundFolderClick = function(event){
			app[myHandler].trigger("hide");
			app.routers.main.stageSimple(event.foundFolderId);
		};
		
		//helper function to check if the objectName already exists
		// binding the debounce for unit tesing purposes :(
		self.uniqueAttributeUpdated = _.bind(CreateFolder.uniqueAttributeUpdated, this);
		
		// this function gets called after we've attached formsupport to this view model and have let it do its initilization
		// this is important to have this code in a function because some of the logic in here depends on form support being ready
		// to go - such as the objectType observable needs to be subscribed to by form support before we run this logic or we could
		// get a race condition where form support never generates the form for the selected object type
		self.initialize = function() {		
			// if this is a header action
			if(self.isHeaderMode()) {
				// these are the configured tracs
				var tracConfigs = config.get("tracTypePaths");

				// these are available tracs for the user to choose from
				self.availableTracs = ko.observableArray([]);

				// fetch all available tracs
				if(tracConfigs !== undefined) {
					app.context.configService.getTracConfigs(function(allConfigs) {
						// availavleTracs id an observable array of Trac objects, so we can 
						// access name and display name as needed
						var result = _.map(allConfigs.models, function(tracConfig) {
							var otcName = tracConfig.attributes.name;
							if(tracConfigs[otcName]) {
								return {
									'name': otcName,
									'displayName': tracConfig.attributes.displayName
								};
							}
							else {
								app.log.debug((window.localize("modules.actions.createFolder.noPathConfig")) + otcName);
							}
						});

						// sort the results alphabetically by displayName and set available tracs
						self.availableTracs(_.sortBy(_.without(result, undefined), 'displayName', function(config) {
							return config;
						}));
						
						// if there's only one available trac, default to it
						// this will make the select box on the front end disabled as well
						if(self.availableTracs().length === 1) {
							self.selectedTrac(self.availableTracs()[0]);
						}
					});
				}

				// this is used to control whether or not to show the list of selectable obejct types to the user
				// it will become true when the object types have been filtered below
			} else { // this is not a header action
				//get the types from our form
				app.context.configService.getFormConfig(config.get("form"), function(formConfig) {
					//we need to adminOTC to check if the type in the form is a container or not
					app.context.configService.getAdminOTC(function(adminOTC) {
						//need to get the path of the parent folder from the id
						$.ajax({
							url: app.serviceUrlRoot + '/content/getPathById?objectId=' + encodeURIComponent(action.get("parameters").objectId),
							success: function(data){
								//path of the parent folder
								self.parentFolderPath = data;
								_.each(formConfig.get("configuredTypes").models, function(typeConfig) {
									//find the type on the adminOTC and get the isContainer value
									var container = adminOTC.get("configs").findWhere({ocName: typeConfig.get("ocName")}).get("isContainer");

									if (container === "true") {
										//if you want to limit types, the find looks for the type in the OTC 
										//in the action config's selectedFolderTypes array
										if (config.get("limitTypes") !== "true" || 
												_.find(config.get("selectedFolderTypes"), function(folderType) { 
													return folderType.value === typeConfig.get("ocName"); 
												})) {
												self.availableObjectTypes.push({
													"label": typeConfig.get("label"),
													"value": typeConfig.get("ocName")
												});
											}
									}
								});
							},
							error: function(jqXHR) {
								//uhoh, couldn't get the parent folder path
								app[myHandler].trigger("showError", window.localize("modules.actions.createFolder.sorryAnError") +
									jqXHR.status + " " + jqXHR.responseText);
							}

						});
					});
				});
			}
			
		};
		
		self.createFolderFromExcel = function(file, formTypes) {
			app[myHandler].trigger("loading", true);
			
			// OC requires the name be sent event tho we won't be using it
			action.get("parameters").name = "";
			action.get("parameters").folderType =  self.objectType();
			var dependsOnMap = {};
			//dependsOnMap is going to be used to keep track of those attributes that are dependent upon another
			var dependerMap = {};
			//dependerMap is going to be used to keep track of those attributes that when changed, need to modify their dependents, call this a depender
			var computedMap = {};
			//computedMap is going to be used to keep track of attributes that will need to get their values computed based on others
			var tempFormModels;
			_.each(formTypes,function(type){
				if(type.get("ocName") === self.objectType()){
					tempFormModels = _.union(type.get("configuredAttrsPri").models, type.get("configuredAttrsSec").models);
				}
			});
			var currentFormValues = self.getValues();
			var formControls = _.map(tempFormModels, function(control) {
				//here we are going to map our formControls into a more usable map.
				var dependsOn = control.get("dependsOn");
				if(dependsOn.length > 0) {
					var picklistLabel = control.get("picklist");
					var picklistName = app.context.currentPicklistConfig().get("picklists").findWhere({label: picklistLabel}).get("ocName");
					dependsOnMap[control.get("ocName")] = dependsOn[0];
					dependerMap[dependsOn[0]] = {attrToSet: control.get("ocName"),
												 picklistName: picklistName};
				}
				if(control.get("controlType") === "Computed"){
					//computed control
					computedMap[control.get("ocName")] = control.get("computedPattern");
				}
				if(config.get("copyAttrs") === 'form'){
					//this section is for copying values from the currentForm when bulkCreate is hit, we will just grab the values in the controls
					return {ocName: control.get("ocName"), label: window.localize(control.get("label")), required: control.get("required"), value: currentFormValues[control.get("ocName")]};
				}else if(config.get("copyAttrs") === 'config'){
					//this means we are copying attrs from the config, need to get those values based on the picklist defaults
					var controlPicklistDefaultValue,picklistValues;
					if(control.get("picklist")){
						//if we have a picklist, we could have a default.. pretty much only way this is going to work from the config.
						var currentPicklist = app.context.currentPicklistConfig().get("picklists").findWhere({label: control.get("picklist")});
						controlPicklistDefaultValue = currentPicklist.get("defaultItems");
						picklistValues = _.pluck(currentPicklist.get("options"), 'value');
					}
					//we will end up sending an empty string if this control doesnt have a default value
					if(control.get("repeating")){
						//if were setting a repeating default value, lets use the whole thing, otherwise lets take the first
						return {ocName: control.get("ocName"), label: window.localize(control.get("label")), required: control.get("required"), picklistValues: picklistValues, value: controlPicklistDefaultValue};
					}else{
						return {ocName: control.get("ocName"), label: window.localize(control.get("label")), required: control.get("required"), picklistValues: picklistValues, value: controlPicklistDefaultValue ? controlPicklistDefaultValue[0] : null};
					}
				}else{
					return {ocName: control.get("ocName"), label: window.localize(control.get("label")), required: control.get("required"), value: null};
				}
				
			});

			action.get("parameters").controls = formControls;
			action.get("parameters").dependsOnMap = dependsOnMap;
			action.get("parameters").dependerMap = dependerMap;
			action.get("parameters").computedMap = computedMap;
			//get the path from the trac config data based on the selected trac and selected object type
            var tracConfigs = config.get("tracTypePaths");
			action.get("parameters").path = tracConfigs[self.selectedTrac().name].paths[self.objectType()];
			
			var xhr = new XMLHttpRequest();
			
			xhr.onreadystatechange = function() {
				// action is complete
				if (xhr.readyState === 4) {
					var response = app.context.util.parseIEJSON(xhr.response);
					var result = response.result;
					var createdFolders = [];
					var failedFolders = [];
					// check if there was error at the beginning of the action executer
					// if so, then the result won't have any folder infomation
					if (result.initialError){
						// mock up an object that has the same attributes as folder would have as if it would
						// normally be sent to the template
						var errorMessage = {
							folderName: (window.localize("modules.actions.createFolder.errorCreating")),
							cause: result.initialError
						};
						
						failedFolders.push(errorMessage);
					} else {
						_.each(result, function(folder){
							if (folder.created === 'true') {
								folder.url = app.root + "StageSimple/" + folder.objectId;
								createdFolders.push(folder);
							} else {
								failedFolders.push(folder);
							}
						});
					}
					
					app[myHandler].trigger("loading", false);
					
					app.trigger("bulkCreateFolders:done", createdFolders, failedFolders);
				}
			};
			
			xhr.open("POST", app.serviceUrlRoot + '/action/executeWithAttachment');
			var formData = new FormData();
			formData.append('parts', file, file.name);
			formData.append('action', JSON.stringify(action));
			xhr.send(formData);
		};
		
		// triggered when user clicks Create Folder button
		self.createFolder = function() {
			// Trigger loader
			app[myHandler].trigger("loading", true);

			// if it's a header action
			if(self.isHeaderMode()) {
				// get the path from the trac config data based on the selected trac and selected object type
				var tracConfigs = config.get("tracTypePaths");
				action.get("parameters").path = tracConfigs[self.selectedTrac().name].paths[self.objectType()];
				action.get("parameters").trac = self.selectedTrac().name;
			} else {
				// sets defualt to empty string so OC does not get null pointer if this is not a header action
				action.get("parameters").path = "";
				action.get("parameters").trac = "";
			}
			
			// check if all the required attributes are filled in
			// This needs to be done in regards to form support
			var unwrappedPropertiesMap = {};
			$.each(self.getValues(), function(key, item) {
				unwrappedPropertiesMap["prop-" + key] = item;
				if(key === "objectName") {
					action.get("parameters").name = item;
				}
			});

			action.get("parameters").properties = unwrappedPropertiesMap;
			action.get("parameters").folderType =  self.objectType();

			action.execute({
				success: function(data) {
					app.log.debug((window.localize("modules.actions.createFolder.successfullyCreatedWithId"))+ data.result);
					// if it's a header action
					if(self.isHeaderMode()) {
						// if we are in the stage and already on the trac the user chose to create the new folder on, we just want to refresh
						// the stage
						if(Backbone.history.fragment.split("/")[0] === "Stage" && app.context.configName() === self.selectedTrac().name) {
							// the newly created folder is empty, so we want to get rid of the document in the stage
							// left in stage refresh because it could potentially save seconds when loading the stage
							//app.trigger("stage.refresh.bothIds", data.result, "");
							Backbone.history.navigate("Stage/" + self.selectedTrac().name + "/" + data.result, {trigger: true} );
							app[myHandler].trigger("loading", false);
							app[myHandler].trigger("showMessage", (window.localize("modules.actions.createFolder.folderSuccessfully")));
						} else {
							// we either are not in the Stage or we are in the Stage but we're on a trac other than what the user chose
							// to create the new folder on - so we need to do a navigate to get to the Stage and the right trac
							app[myHandler].trigger("hide");
							Backbone.history.navigate("Stage/" + self.selectedTrac().name + "/" + data.result, {trigger: true} );
						}
					} else { // it's not a header action
						// refresh the stage to see the newly created folder in the related objects section (if they've configured a 'children' relation)
						app.trigger("stage.refresh.containerId", true);
						app[myHandler].trigger("loading", false);
						app[myHandler].trigger("showMessage", (window.localize("modules.actions.createFolder.folderSuccessfully")));
					}

				},
				error: function(jqXHR) {
					app[myHandler].trigger("loading", false);
					app[myHandler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) +
						jqXHR.status + " " + jqXHR.responseText);
				}
			});
		};
	};

	CreateFolder.View = Backbone.Layout.extend({
		template: "actions/createfolder",

		initialize: function() {
			var self = this;
			this.myHandler = this.options.config.get("handler");
			this.viewModel = new CreateFolder.ViewModel(this, this.options);
			this.formName = this.options.config.get("form");

			Formsupport.tsgFormSupport(this.viewModel, {
				isCreate: true,
				enableRequired: true,
				acceptableAttrsByObjectType: {},
				formName: this.formName
			});

			this.viewModel.controls.subscribe(function(controls){
				if(controls){
					_.each(controls , function(control){
						// check if attr is unique, if unique add subscribe
						_.each(control.externalRules, function(externalRule) {
							if (externalRule.ruleValue === "condition-isattributeunique-conditionevaluator") {
								control.value.isValid.subscribe(function() {
									if(!control.value.isValid()) { 
										// query oc to populate the alert
										self.viewModel.uniqueAttributeUpdated(control); 
									}
									else {
										// remove the alert when for is valid
										self.viewModel.foundFolder([]);
									}
								});
								return;
							}
						});
					});
				}
			});

			this.viewModel.isFormValidationComplete.subscribe(function (isCompleted) {
				self.trigger("formValidation:updateSpinner", isCompleted);
			});
			
			this.listenTo(app, 'bulkCreateFolders:done', function(successList, errorList){
				this.setView("#createFolder", new CreateFolder.BulkCreateResults({
					successList: successList,
					errorList: errorList
				})).render();
			});

			this.listenTo(this, "formValidation:updateSpinner", function (isCompleted) {
				isCompleted ? self.stopSpinner() : self.setSpinner();
			});
			
			// initialize our view model after we've attached form support to it
			this.viewModel.initialize();
		},
		setSpinner: function () {
			var spinElem = this.$el.find(".progressSpinner")[0];
			if (spinElem) {
				this.spinner = OCMSSpinner.createSpinner({
					color: '#000'
				}, spinElem);
			}
		},
		stopSpinner: function () {
			if (this.spinner) {
				OCMSSpinner.destroySpinner(this.spinner);
			}
		},
		afterRender: function() {
			var self = this;
			ko.applyBindings(this.viewModel, this.$el[0]);
			this.$('#bulkCreateFolders').fileupload({
				add: function (e, data) {
					self.viewModel.createFolderFromExcel(data.files[0], self.viewModel.form().get("configuredTypes").models);
				}
			});
			
		},
		serialize: function() {
			return {
				modal: this.myHandler === "modalActionHandler",
				rightSide: this.myHandler === "rightSideActionHandler"
			};
		}
	});
	
	CreateFolder.BulkCreateResults = Backbone.Layout.extend({
		template: "actions/bulkcreatefoldersresults",

		initialize: function(options) {
			this.successList = options.successList;
			this.errorList = options.errorList;
		},

		serialize: function() {
			return {
				successList: this.successList,
				errorList: this.errorList,
				errorListLength: this.errorList.length,
				successListLength: this.successList.length
			};
		}
	});

	// this represents a view model for a path configuration for an object type
	CreateFolder.TypePathViewModel = function(options) {
		var self = this;

		// the parent trac of this object type
		self.trac = options.trac;

		// typePattern server data that needs to be updated when an object type's path configuration changes
		self.typePathServerData = options.typePathServerData;

		// the value of the objectType
		self.objectType = options.objectType;

		self.typeLabel = ko.observable("");
		app.context.configService.getLabels(self.objectType).done(function(typeLabel) {
			self.typeLabel(typeLabel);
		});

		// the path that is displayed on the admin screen
		self.computedPath = ko.observable("");
		if(options.path) { // the path will be set if we get data back from the server
			self.computedPath(options.path);
		}

		// every time the observable's value changes, update that object type's path in the server data map
		self.computedPath.subscribe(function (newValue) {
			self.typePathServerData[self.trac].paths[self.objectType] = newValue;
		});
	};

	// this represents a view model for a trac configuration
	CreateFolder.TracViewModel = function(options) {
		var self = this;

		// the name of the trac
		self.trac = options.trac;

		// the server data with trac configurations
		self.typePathServerData = options.typePathServerData;

		// an array of possible object types that a user can configure paths for
		self.objectTypesWithoutPathConfig = ko.observableArray([]);

		// whether or not to limit the available types of folder creation ("true" or "false")
		self.tracLimitTypes = ko.observable(self.typePathServerData[self.trac].limitTypes.enabled);
		// the available folder object types that a user can limit folder creation
		self.availableTracFolderTypes = ko.observableArray([]);
		// the selected foler object types a user has chosen to limit folder creation
		self.selectedTracFolderTypes = ko.observableArray([]);

		// when a user chooses to limit or remove limitation of object types, update the data sent back to the server
		self.tracLimitTypes.subscribe(function(value) {
			self.typePathServerData[self.trac].limitTypes.enabled = value;
		});

		// when a user updates the selected folder object types to limit creation, update the data sent back to the server
		self.selectedTracFolderTypes.subscribe(function(values) {
			self.typePathServerData[self.trac].limitTypes.types = _.pluck(values, 'value');
		});

		self.form = ko.observable(self.typePathServerData[self.trac].form);
		var formSubscribePlaceholder = self.form();
		self.potentialForms = ko.observableArray();
		app.context.configService.getFormConfigNames(function(formConfigNames) {
			self.potentialForms(formConfigNames);
			//since the form value is bound from the potentialForms observable,
			//this context call will come back after the form has been gathered
			//from the config. this resets the form to the right value.
			self.form(formSubscribePlaceholder);
		});
		// when a user chooses a form, update the form value
		self.form.subscribe(function(value) {
			self.typePathServerData[self.trac].form = value;
		});

		// fetch the possible object types based on the trac name
		app.context.configService.getAdminOTC(function (config) {
			config.get("configs").each(function (typeConfig) {
				if (typeConfig.get("isContainer") === "true") {
					// populate the available object types of the trac that a user can configure a path for
					if(!self.typePathServerData[self.trac].paths[typeConfig.get("ocName")]) {
						self.objectTypesWithoutPathConfig.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					}

					// populate the available and selected array for limiting folder object types
					//without notifying subscribers of selectedTracFolderTypes array, just pushes onto array
					if($.inArray(typeConfig.get("ocName"), self.typePathServerData[self.trac].limitTypes.types) !== -1) {
						self.selectedTracFolderTypes().push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});
					} else {
						self.availableTracFolderTypes.push({
							"label": typeConfig.get("label"),
							"value": typeConfig.get("ocName")
						});	
					}
				}
			});
			//notifies subscribers of the selectedTracFolderTypes array to re-evaluate before displaying
			self.selectedTracFolderTypes.valueHasMutated();
		});

		// each trac has an array of configured object types with paths
		self.typePathViewModels = ko.observableArray([]);
		// populate the trac's configured object types
		_.each(self.typePathServerData[self.trac].paths, function(path, objectType) {
			if(objectType !== "limitTypes" && objectType !== "_id") { // skip the limit types key and the _id key
				self.typePathViewModels.push(new CreateFolder.TypePathViewModel({ trac: self.trac, objectType: objectType, path: path, typePathServerData: self.typePathServerData }));
			}
		});

		self.selectedObjectTypeWithoutPathConfig = ko.observable();

		// this allows a user to add a path configuration for a selected object type
		self.selectedObjectTypeWithoutPathConfig.subscribe(function(objectType) {
			if(objectType) { // will be undefined if the caption is chosen
				self.typePathViewModels.push(new CreateFolder.TypePathViewModel({ trac: self.trac, objectType: objectType, path: "", typePathServerData: self.typePathServerData }));
				self.objectTypesWithoutPathConfig.remove(_.findWhere(self.objectTypesWithoutPathConfig(), { "value": objectType }));
			}
		});

		// this allows a user to delete a path configuration for a selected object type
		self.deleteTypePath = function(typePath) {
			self.typePathViewModels.remove(typePath);
			delete self.typePathServerData[self.trac].paths[typePath.objectType];
			self.objectTypesWithoutPathConfig.push({
				"label": typePath.typeLabel, 
				"value": typePath.objectType
			});
		};
	};

	// Custom config view for HPI admin configuration
	CreateFolder.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/createfolderconfig",

		initialize: function () {
			var self = this;
			self.viewModel = this.options.viewModel;
			
			// is this action a header action
			self.viewModel.isHeaderMode = ko.observable(self.viewModel.model().get("isHeaderMode") ? self.viewModel.model().get("isHeaderMode") : false);
			
			// if it's not a header action, we want to allow the user to filter the possible objectTypes of folders that can be created
			if(!self.viewModel.isHeaderMode()) {
				// if the limiting types option is enabled or disabled ("true" or "false")
				self.viewModel.limitTypes = kb.observable(self.viewModel.model(), "limitTypes");
				// available types to limit folder creation to
				self.viewModel.availableFolderTypesInConfig = ko.observableArray([]);
				// selected types to limit folder creation to
				self.viewModel.selectedFolderTypesInConfig = ko.observableArray(self.viewModel.model().get("selectedFolderTypes") || []);

				self.viewModel.form = kb.observable(self.viewModel.model(), "form");
				var formSubscribePlaceholder = self.viewModel.form();
				self.viewModel.potentialForms = ko.observableArray();
				app.context.configService.getFormConfigNames(function(formConfigNames) {
					self.viewModel.potentialForms(formConfigNames);
					//since the form value is bound from the potentialForms observable,
					//this context call will come back after the form has been gathered
					//from the config. this resets the form to the right value.
					self.viewModel.form(formSubscribePlaceholder);
				});

				// reset the selectedFolderTypes on the model every time a user adds or takes away a type to limit
				self.viewModel.selectedFolderTypesInConfig.subscribe(function(values) {
					self.viewModel.model().set("selectedFolderTypes", values);
				});

				// grab the adminOTC so we can populate our document types
				app.context.configService.getAdminOTC(function(config) {
					// we only care about document types so filter through the returned configs for only document configs
					var containerConfigs = config.get("configs").filter(function(config) {
						return config.get("isContainer") === "true";
					});

					// a cached value for all the document types available on this admin OTC with only the label and ocName fields
					_.map(containerConfigs, function(ctrConfig) { 
						self.viewModel.availableFolderTypesInConfig.push({
							label: ctrConfig.get("label"),
							value: ctrConfig.get("ocName")
						});
					});

					// filter the available types based on what has already been selected
					var objs = {};
					_.each(self.viewModel.selectedFolderTypesInConfig(), function(selectedFolderType) {
						objs[selectedFolderType.value] = true;
					});
					self.viewModel.availableFolderTypesInConfig(_.filter(self.viewModel.availableFolderTypesInConfig(), function(availableFolderType) {
						return !objs[availableFolderType.value];
					}));
				});

			} else { // the action is a header action
				
				//this will be a config option for bulk create folder
				self.viewModel.copyAttrs = kb.observable(self.viewModel.model(),"copyAttrs");
				
				// all available tracs for a user to configure
				self.viewModel.availableTracs = ko.observableArray([]);
				// fetch all the trac names
				app.context.configService.getTracConfigs(function(allConfigs) {
					var tracNames = allConfigs.pluck("name");
					if(self.viewModel.model().get("tracTypePaths")) { // if there are already tracs configured
						// filter the available tracs based on which tracs have already been configured
						var configuredTracs = {};
						_.each(self.viewModel.model().get("tracTypePaths"), function(tracData, trac) {
							configuredTracs[trac] = true;
						});
						self.viewModel.availableTracs(_.filter(tracNames, function(tracName) {
							return !configuredTracs[tracName];
						}));
					} else { // no tracs are configured yet so all tracs are available
						self.viewModel.availableTracs(tracNames);	
					}
				}, function() {}, true);

				// the view models representing a collection of configured tracs
				self.viewModel.tracViewModels = ko.observableArray([]);
				// the corresponding data of the tracViewModels array that gets sent back to the server
				self.typePathServerData = self.viewModel.model().get("tracTypePaths") || {};

				// build up the tracViewModels observable array based on the already configured tracs
				// if no tracs are configured, set the empty object on the model
				if(self.viewModel.model().get("tracTypePaths")) {
					_.each(self.viewModel.model().get("tracTypePaths"), function(tracData, trac) {
						if(trac !== "_id") { // an extra key with "_id" is sent in the obejct to the server, skip this
							var newTrac = new CreateFolder.TracViewModel({ trac: trac, typePathServerData: self.typePathServerData });

							self.viewModel.tracViewModels.push(newTrac);
						}
					});
				} else {
					self.viewModel.model().set("tracTypePaths", self.typePathServerData);
				}
				
				self.viewModel.allowBulkExcelImport = ko.observable(self.viewModel.model().get("allowBulkExcelImport") || false);
				self.viewModel.allowBulkExcelImport.subscribe(function(newValue){
					self.viewModel.model().set('allowBulkExcelImport', newValue);
				});
				
				self.viewModel.deniedGroupsForBulkExcelImport = ko.observableArray([]);
				self.viewModel.allowedGroupsForBulkExcelImport = ko.observableArray([]);

				var requestGroupObject = {
                	"authorityType": "group",
                	"criterion": {
									"attrToSearch": "displayName", 
									"matchType": "startsWith", 
									"searchTerm": "*"
								}
            	};


				$.ajax(
                    {
                    url: app.serviceUrlRoot + "/authorities/search", 
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(requestGroupObject),
                    success: function (groups){
                    	var allGroups = [];
                        _.each(groups, function(group) {
                            allGroups.push(group.authorityId);
                        });
                  				
						var allowedGroups = self.viewModel.model().get('allowedGroupsForBulkExcelImport');
						if (!allowedGroups){
							self.viewModel.deniedGroupsForBulkExcelImport(allGroups);
						} else {
							self.viewModel.allowedGroupsForBulkExcelImport(allowedGroups);
							self.viewModel.deniedGroupsForBulkExcelImport(_.difference(allGroups, allowedGroups));
						}
					},
					error: function() {
						app.log.error((window.localize("modules.actions.createFolder.couldNotLoad")));
					}
				});
				
				self.viewModel.allowedGroupsForBulkExcelImport.subscribe(function(allowedGroups){
					self.viewModel.model().set('allowedGroupsForBulkExcelImport', allowedGroups);
				});
				
				// this function allows a user to add a new trac to configure
				self.viewModel.selectedAddTrac = ko.observable();
				self.viewModel.selectedAddTrac.subscribe(function(trac) {
					if(trac) { // will be undefined if the chosen option is "Choose a trac to configure..."
						// set up the initial server data that will be sent back
						self.typePathServerData[trac] = {};
						self.typePathServerData[trac].paths = {};
						self.typePathServerData[trac].limitTypes = {
							// whether or not the user has chosen to limit possible folder creation types
							"enabled": 'false',
							// the actual object types the user has chosen to limit, only relevant if enabled === "true"
							"types": []
						};
						self.typePathServerData[trac].form = "";
						// add a new trac view model
						self.viewModel.tracViewModels.push(new CreateFolder.TracViewModel({ trac: trac, typePathServerData: self.typePathServerData }));
						// remove the trac from the list of available tracs to configure
						self.viewModel.availableTracs.remove(trac);	
					}
				});

				// whether or not to show the edit trac component of the admins screen
				self.viewModel.showEditTrac = ko.observable(false);
				// this is the selected trac the user has chosen to edit / configure
				self.viewModel.selectedEditTrac = ko.observable(null);
				// this function allows a user to edit a trac configuration
				self.viewModel.editTrac = function(tracVM) {
					self.viewModel.selectedEditTrac(tracVM);

					var formName = tracVM.form();
					var uniqueAttrsForFormDeferred = self.getUniqueAttrsForForm(formName);

					$.when(uniqueAttrsForFormDeferred).done($.proxy(function() {
						self.viewModel.showEditTrac(true);
						self.render();
					}, self));

					// set up subscribe for current tracVM form to refresh table on change
					tracVM.form.subscribe(function(newFormName) {
						var subscribeUniqueAttrTableDeferred = self.getUniqueAttrsForForm(newFormName);
						$.when(subscribeUniqueAttrTableDeferred).done($.proxy(function() {
							self.render();
						}, self));
					});
				};

				// this function allows a user to delete a configured trac
				self.viewModel.deleteTrac = function(tracVM) {
					// clear the edit trac component of the admin screen if the user is deleting the trac that is populated there
					if(self.viewModel.selectedEditTrac() === tracVM) {
						self.viewModel.selectedEditTrac(null);
						self.viewModel.showEditTrac(false);
					}
					// remove the trac from the view models array
					self.viewModel.tracViewModels.remove(tracVM);
					// add the trac back in to the array of available tracs to configure
					self.viewModel.availableTracs.push(tracVM.trac);
					// delete the trac and its configuration from the data to be sent back to the server
					delete self.typePathServerData[tracVM.trac];
				};
			}
		},
		getUniqueAttrsForForm: function(formName) {
			this.configuredObjectTypes = [];

			var self = this;
			var deferred = $.Deferred();

			app.context.configService.getFormConfig(formName, function(formConfig) {
				var configuredTypes = formConfig.get("configuredTypes"); // backbone collection

				var typeTrimmingDeferred = self.returnContainerObjects(configuredTypes);

				$.when(typeTrimmingDeferred).done($.proxy(function() {
					// find unqiue attr for each object type configured and place on model
					_.each(configuredTypes.models, function(objectType) {
						self.setUniqueAttributesOnModel(objectType);
					});
					deferred.resolve();
				}, self));
			});
			return deferred.promise();
		},
		returnContainerObjects: function(formObjectTypes) {
			var deferred = $.Deferred();
			// check if objectType is a folder
			app.context.configService.getAdminOTC(function(adminOTC) {
				var configs = adminOTC.get("configs").models;

				formObjectTypes.models = _.reject(formObjectTypes.models, function(formObjectType) {
					var config = _.find(configs, function(config){
						return config.get("ocName") === formObjectType.get("ocName");
					});
					return config && config.get("isContainer") === "false"; // undefined check and only reject non-folders
				});

				deferred.resolve();
			});

			return deferred.promise();
		},
		setUniqueAttributesOnModel: function(formObjectType) {
			var objectLabel = formObjectType.get("label");
			var attributesWithPotentialUnique = _.extend({}, formObjectType.get("configuredAttrsPri").models, formObjectType.get("configuredAttrsSec").models);

			// loop through primary attributes to find attr with unique attr external rule
			var uniqueAttrs = [];
			_.each(attributesWithPotentialUnique, function(attribute) {
				var ocName = attribute.get("ocName");
				var externalRules = attribute.get("externalRules");

				// loop through each external rule set on this attr to see if its a unique attr
				_.each(externalRules, function(externalRule) {
					if (externalRule.ruleValue === "condition-isattributeunique-conditionevaluator") { 
						uniqueAttrs.push(ocName);
					}
				});
			});

			if (uniqueAttrs.length) {
				// unique attr exists for this object type prepare the table entry for success
				this.configuredObjectTypes.push({
					"objectType": objectLabel,
					"uniqueAttrs": uniqueAttrs.sort()
				});
			} else {
				// prepare error message for configured object type
				this.configuredObjectTypes.push({
					"objectType": objectLabel,
					"uniqueAttr": uniqueAttrs,
					"errorMessage": window.localize("customConfig.createFolderConfig.unqiueAttrTable.noAttrConfigured")
				});
			}
		},
		afterRender: function() {
			kb.applyBindings(this.options.viewModel, this.$el[0]);
			self.$('[data-toggle="tooltip"]').tooltip();
		},
		serialize: function() {
			return {
				configuredObjectTypes: this.configuredObjectTypes
			};
		}
	});

	actionModules.registerAction("createFolder", CreateFolder, {
		"actionId" : "createFolder",
		"label" : (window.localize("modules.actions.createFolder.createNewFolder")) ,
		"icon" : "plus"
	});

	return CreateFolder;

});
require(["createfolder"]);
