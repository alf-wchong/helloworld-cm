define("advancedcombinetopdf", [
        "app",
        "module",
        "oc",
        "modules/formsupport",
        "moment",
        "modules/actions/actionmodules",
        "modules/common/ocquery",
        "modules/common/downloadutils",
        "modules/common/exportwithannotations",
        "modules/common/spinner",
        "foldernotes",
        "modules/search/searchresults",
        "modules/search/searchresultsviewcontroller",
        "modules/common/hpiconstants",
        "modules/hpiadmin/actionconfig/actions/advancedcombinetopdf/advancedcombinetopdfconfig",
        "tsgUtils"
    ],

    // Map dependencies from above array.
    function(app, module, OC, Formsupport, Moment, actionModules, OCQuery, downloadUtils, ExportWithAnnotations,
             HPISpinner, FolderNotes, SearchResults, SearchResultsViewController, HPIConstants, AdvancedCombineToPdfCustomConfigView, tsgUtils) {
        "use strict";

        // Create a new module.
        var AdvancedCombineToPDF = {
            'NON_PDF': 'nonPdf',
            'PASSWORD_PROTECTED': "passwordProtected",
            'CORRUPT': 'corrupt',
            'IS_NOT_READABLE': 'notReadable',
            //How long a setTimout should last in this file. Made into a variable to make unit testing easier
            'timeoutDuration': 5000,
            'throttleDuration': 250,
            'renditionPollTimeout': 2000,
            'progressBarCompletionTimeout': 2000,
            'Events': _.extend({}, Backbone.Events)
        };

        AdvancedCombineToPDF.CustomConfigView = AdvancedCombineToPdfCustomConfigView.View;

        AdvancedCombineToPDF.View = Backbone.Layout.extend({
            template: "actions/advancedcombinetopdf/advancedcombinetopdfcontrols",
            events: {
                "click #combine-submitBtn": "combineDocuments",
                "keyup #download-pdf-name": "updateFileName",
                "click #combine-submitBtn-container": "clickCombineBtnContainer",
                "show.bs.tab #actpdf-selectedTabLink": "saveToRepoSelectedDocumentsTabClick",
                "show.bs.tab #actpdf-propsTabLink": "saveToRepoEditPropertiesTabClick",
                "click #combine-nextBtn-container": "saveToRepoNextTabBtnClick"
            },
            initialize: function() {
                this.config = this.options.config;
                this.myHandler = this.options.config.get("handler");
                //Creating the searchResultsViewController. This handles comunication and data persistence through
                // all modules that deal with tableview
                this.searchResultsViewController = new SearchResultsViewController.Model();
                
				this.searchResultsViewController.showIndexPageCheckbox = this.config.get('showIndexPageCheckbox');
                if (_.isUndefined(this.searchResultsViewController.showIndexPageCheckbox)) {
                    this.searchResultsViewController.showIndexPageCheckbox = false;
                }

                this.searchResultsViewController.includeIndexPage = this.config.get('defaultValueForShowIndexPageCheckbox');
                if (_.isUndefined(this.searchResultsViewController.includeIndexPage)) {
                    this.searchResultsViewController.includeIndexPage = true;
                }

                this.showDefaultName = this.config.get("showDefaultName");
                this.errorDocs = {
                    nonPdf: {
                        message: window.localize("modules.actions.advancedCombineToPDF.erroredDocs.nonPDFMessage"),
                        values: []
                    },
                    passwordProtected: {
                        message: window.localize("modules.actions.advancedCombineToPDF.erroredDocs.passwordProtectedMessage"),
                        values: []
                    },
                    corrupt: {
                        message: window.localize("modules.actions.advancedCombineToPDF.erroredDocs.corruptMessage"),
                        values: []
                    },
                    notReadable: {
                        message: window.localize("modules.actions.advancedCombineToPDF.erroredDocs.notReadableMessage"),
                        values: []
                    }
                };
                this.selectedDocumentModels = [];
                if (this.showDefaultName === "false") {
                    this.defaultName = "";
                } else {
                    //Setting default file name
                    var newDate = moment().format("ddd MMM DD YYYY h-mm-ss");
                    this.defaultName = "Combined PDF-" + newDate;
                }                
                app.context.dateService.getDatetimeTimezoneFormat().done(_.bind(function(dateTimeFormat) {
                    this.dateFormat = dateTimeFormat.dateFormat;
                }, this));

                this.selectedPagesEnabled = this.options.config.get('enableSelectedPages') === "true";
                this.allowRenditionable = this.options.config.get('allowRenditionable') === "true";
                this.selectVersionsEnabled = this.options.config.get('showSelectVersionColumn') === "true";

                this.saveToRepo = this.config.get("saveToRepo") && this.config.get("saveToRepo") === 'true';
                this.showBookmarkColumn = this.config.get('showBookmarkColumn') === 'true';
                this.exportWithAnnotationsToAttachments = this.config.get("exportWithAnnotationsToAttachments") === "true";
                this.folderNotesEnabled = this.config.get("folderNotes") === 'true';
                this.fetched = false;

                this.customTypePaths = this.config.get("customTypePaths");
                this.containerPath = this.config.get("containerPath");
                this.form = this.config.get("form");
                this.progressBarPollTimeout = this.config.get('progressBarPollTimeout');

                this.contextLessUpload = this.config.get("contextLessUpload") === "true";
                // This will reset the annotationInfo action parameter so that whatever was on there before will be erased.
                this.action.get("parameters").annotationInfo = null;
                this.async = this.config.get("asyncDownloadEnabled") === 'true';

                //set up validation progress bar, hide table and controls
                this.canBeReadRequestsToBeCompleted = 0;
                this.completedCanBeReadRequests = 0;
                app[this.myHandler].trigger("showInfo", (window.localize("modules.actions.advancedCombineToPDF.progressBar")), true);
                app[this.myHandler].trigger("showProgress");

                //hide content so progress bar is shown instead of table
                //all other right side actions will want to show #rightSideActionHandler-content on initialize,
                //so we have to tell RSAH to not show content for this action
                //ACTPDF will call show when the progress bar is complete
                $('#' + this.myHandler + '-content').hide();
                this.keepRSAHContentHiddenUntilSubActionCallsShow = true;
                this.totalMemoryAmount = 0;
                this.enableLimitCombinedPdfSize = this.config.get('enableLimitCombinedPdfSize');
                this.setUp();

            },
            applyListeners: function() {
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:docSelected', this.validate);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:docRemoved', this.validate);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'selected:docs:removeDoc', this.removeErroredDoc);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'actpdf:renderFinished', this.validate);
                this.listenTo(this.searchResultsViewController.tableEventsRef, 'tableview:tableAfterRenderDone', this.validate);
                //listens for a container to change in order to refresh the view
                this.listenTo(app, 'stage.refresh.containerId', this.setup);
                this.listenTo(AdvancedCombineToPDF.Events, 'change:properties', this.validate);
            },
            /**
             * Sets up everything needed for the ACTPDF action. This invloves stopping all previous listeners, re-applying those listeners,
             * querying oc for the documents collected and then filtering 
             */
            setUp: function(){
                this.stopListening();
                this.applyListeners();
                this.fetchDocs().done(_.bind(this.filterDocsAndCreateCollection,this));
            },
            /**
             * Returns the document size, preferring the renditioned
             * size
             * @param {Object} document
             * @return {Number} document size
             */
            getDocumentSize: function(doc) {
                if (doc[HPIConstants.Properties.RenditionSize]) {
                    return doc[HPIConstants.Properties.RenditionSize];
                } else {
                    return doc[HPIConstants.Properties.NativeSize];
                }
            },
            /**
             * This is a hotspot function for custom overrides on the error pdfs to be displayed to the user
             * @param  Takes in an array of documents to filter
             * @return Returns an array of filtered documents
             */
            applyCustomErrorPdfFilter: function(documents) {
                return documents;
            },
            /**
             * Checks if the aggregate Pdf created is over the 
             * configured size limit
             * @param Takes in an array of documents
             */
            checkCombinedPdfSizeLimit: function(documents) {
                // This method will be called only when coming from tableview as a group action
                // It will check if the total document size is the above the combined pdf size limit
                // This will not filter documents
                if (this.enableLimitCombinedPdfSize) {
                    this.totalMemoryAmount = 0;

                    _.each(documents, function(doc) {
                        var docSize = this.getDocumentSize(doc);
                        this.totalMemoryAmount += docSize;
                    }, this);
                }
            },
            /**
             * This is a hotspot function for any custom filtering
             * @param  Takes in an array of documents to filter
             * @return Returns an array of filtered documents
             */
            applyCustomFilter: function(documents) {
                return documents;
            },
            /**
             * This function contacts OC with an array of objectIds to determine their mimeTypes. On a succesful
             * call it will resolve the Deferred promise returned with an object that has the kay value pair of
             * document objectId to an array of its mimeTypes. If the call error's then the function will resolve the 
             * deferred with a blank array 
             * @return A JQuery.Deferred.promise() object.
             */
            fetchObjectMimeTypes: function() {
                var self = this;
                //this deferred is present because we want to make sure that it will ALWAYS get resolved
                var deferred = $.Deferred();

                $.ajax({
                    url: app.serviceUrlRoot + '/content/getObjectsMimeTypes',
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(self.action.get('parameters').objectIds),
                    success: function(objects) {
                        deferred.resolve(objects);
                    },
                    error: function() {
                        app.log.error(window.localize("modules.actions.advancedCombineToPDF.advancedCombineToPDF"));
                        deferred.resolve([]);
                    },
                    global: false
                });
                return deferred.promise();
            },
            /**
             * This function contacts OC with an array of objectIds to determine if they can be renditioned
             * into the "application/pdf" mimeType. 
             * 
             * @return {$.Deferred.promise} - On a succesful call it will resolve the Deferred promise 
             * returned with an object that has the kay value pair of document objectId to true/false.
             * If the call error's then the function will resolve the deferred with a blank array 
             */
            fetchObjectsRenditionable: function() {
                var self = this;
                //this deferred is present because we want to make sure that it will ALWAYS get resolved
                var deferred = $.Deferred();

                $.ajax({
                    url: app.serviceUrlRoot + '/content/getObjectRenditionable?targetMimetype=application/pdf',
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(self.action.get('parameters').objectIds),
                    success: function(objects) {
                        deferred.resolve(objects);
                    },
                    error: function() {
                        app.log.error(window.localize("modules.actions.advancedCombineToPDF.advancedCombineToPDF"));
                        deferred.resolve([]);
                    },
                    global: false
                });
                return deferred.promise();
            },
            filterOutDocsWithoutRenditions: function(documents) {
                // filters out the non pdfDocs and stores them in an array for future use. returns pdfDocs
                var self = this;
                var pdfDocs = [];
                var deferred = $.Deferred();
                var deferreds = [];
                var objectMimetypesFetched ;
                if (!this.allowRenditionable) {
                    objectMimetypesFetched = self.fetchObjectMimeTypes();
                    deferreds = [objectMimetypesFetched];
                    $.when.apply($, deferreds).done(_.bind(function(objectMimeTypes) {
                        _.each(documents, function(doc) {
                            if (self.documentHasPdfRendition(doc, objectMimeTypes)) {
                                pdfDocs.push(doc);
                            } else {
                                self.errorDocs[AdvancedCombineToPDF.NON_PDF].values.push(doc.get("properties"));
                            }
                        });
                        deferred.resolve(pdfDocs);
                    }));
                } else {
                    objectMimetypesFetched = self.fetchObjectMimeTypes(); 
                    var objectsRenditionableFetched = self.fetchObjectsRenditionable();
                    deferreds = [objectMimetypesFetched, objectsRenditionableFetched];
                    $.when.apply($, deferreds).done(_.bind(function(objectMimeTypes, objectsRenditionable) {
                        _.each(documents, function(doc) {
                            if (self.documentHasPdfRendition(doc, objectMimeTypes)) {
                                pdfDocs.push(doc);
                            } else if (self.documentIsRenditionable(doc, objectsRenditionable)) {
                                pdfDocs.push(doc);
                            } else {
                                self.errorDocs[AdvancedCombineToPDF.NON_PDF].values.push(doc.get("properties"));
                            }
                        });
                        deferred.resolve(pdfDocs);
                    }));
                }

                return deferred;
            },
            documentHasPdfRendition: function(doc, objectMimeTypes) {
                var documentMimeTypes = objectMimeTypes[doc.get("objectId")];
                return _.contains(documentMimeTypes, "application/pdf");
            },
            documentIsRenditionable: function(doc, objectsRenditionable) {
                return objectsRenditionable[doc.get("objectId")];
            },
            fetchDocs: function() {
                var self = this;
                var deferred = $.Deferred();
                $.ajax({
                    url: app.serviceUrlRoot + '/openContentObjects',
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify(self.action.get('parameters').objectIds),
                    success: function(objects) {
                        deferred.resolve(objects);
                    },
                    error: function() {
                        app.log.error(window.localize("modules.actions.advancedCombineToPDF.advancedCombineToPDF"));
                        deferred.resolve([]);
                    },
                    global: false
                });
                return deferred.promise();
            },
            filterDocsAndCreateCollection: function(documents){
                var self = this;
                //filter non pdfs makes an async call so if we are a grouped action and need to 
                //filter out the non pdf we need to wait until that has finished to continue
                var deferred = $.Deferred();
                //This needs to occur to format the date properties correctly
                _.each(documents, function(doc, index) {
                    var oco = new OC.OpenContentObject(doc);
                    oco.formatPropertiesReadOnly();
                    documents[index] = oco;
                });
                // check if any of the passed in docs have a rendition in the correct format
                this.filterOutDocsWithoutRenditions(documents).done(function(pdfDocs) {
                    pdfDocs = self.applyCustomErrorPdfFilter(pdfDocs);
                    deferred.resolve(pdfDocs);
                });

                $.when(deferred).done(function(documents) {
                    documents = self.applyCustomFilter(documents);
                    self.fetched = true;
                    //Create a OCQuery Collection that we can pass to Search Results
                    self.collection = new OCQuery.Collection(self.filterResults(documents),{
                        mode: 'client',
                        queryParams : {
                            oc_type: [self.config.get("selectedDocumentType")]
                        }
                    });
                    self.buildAndSetSearchResultsView().done(function(){
                        self.render();
                    });
                });
            },
            //HotSpot function for custom filtering of docs
            filterResults: function(results) {
                return results; 
            },
            validate: function() {
                //using find because we only need to know that one of the selected docs is not valid
                var invalidDocument = _.find(this.selectedDocumentModels, function(selectedDocument) { 
                    return !selectedDocument.validate(); 
                });
                
                var propertiesValid = true;
                if (this.saveToRepo && this.propertiesView) {
                    propertiesValid = this.propertiesView.isValid();
                }

                var fileNameEmpty = false;
                if (!this.defaultName || this.defaultName.trim() === "") {
                    fileNameEmpty = true;
                }

                var fileNameValid = true;
                if (this.defaultName && this.defaultName.toLowerCase().indexOf(".pdf") != -1) {
                    app[this.myHandler].trigger("showError", window.localize("modules.actions.advancedCombineToPDF.fileToBeCreated"), true);
                    fileNameValid = false;
                    this.userEnteredInvalidFileName = true;
                } else {
                    if(this.userEnteredInvalidFileName) {
                        app[this.myHandler].trigger("hideError");
                        this.userEnteredInvalidFileName = false;
                    }
                }

                var pdfNameSelector = $("#download-pdf-name");
                if (!fileNameValid) {
                    pdfNameSelector.removeClass('bs-callout-basic bs-callout-warning');
                    pdfNameSelector.addClass('bs-callout-basic bs-callout-danger');
                } else if (fileNameEmpty) {
                    pdfNameSelector.removeClass('bs-callout-basic bs-callout-danger');
                    pdfNameSelector.addClass('bs-callout-basic bs-callout-warning');
                } else {
                    pdfNameSelector.removeClass('bs-callout-basic bs-callout-danger');
                    pdfNameSelector.removeClass('bs-callout-basic bs-callout-warning');
                }

                var docsToBeCombined = [];
                if(this.searchResultsViewController.grid){
                    docsToBeCombined = _.filter(this.searchResultsViewController.grid.getData().getItems(), function(doc){
                        return !_.contains(this.searchResultsViewController.grid.excludedDocs, doc.objectId);
                    }, this);
                }

                // Checks if the selected documents are over the configured
                // size limit
                this.checkCombinedPdfSizeLimit(docsToBeCombined);

                var sizeOverLimit = false;
                if (this.enableLimitCombinedPdfSize && (this.totalMemoryAmount > Number(this.config.get('limitCombinedPdfSize')) * tsgUtils.FILE_SIZE_CONVERSIONS.BYTES_TO_MEGABYTE)) {
                    app[this.myHandler].trigger("showError", window.sLocalize("modules.actions.advancedCombineToPDF.fileSizeOverLimit", [this.config.get('limitCombinedPdfSize')]), true);
                    sizeOverLimit = true;
                } else {
                    app[this.myHandler].trigger("hideError");
                }

                var enable = propertiesValid && !invalidDocument && fileNameValid && !(fileNameEmpty || docsToBeCombined.length === 0) && !sizeOverLimit;
                this.enableOrDisableNextButton(enable);
            },
            // Functioning this part out so we may have different button names and validate/invalidate by overriding
            enableOrDisableNextButton: function(enable) {
                this.$("#combine-submitBtn").prop('disabled', enable ? false : 'disabled');
            },
            updateFileName: _.throttle(function() {
                if (this.saveToRepo) {
                    var newDate = moment().format("ddd MMM DD YYYY h-mm-ss");
                    this.defaultName = "Combined PDF-" + newDate;
                } else {
                    this.defaultName = this.$("#download-pdf-name").val();
                }
                this.validate();
            }, AdvancedCombineToPDF.throttleDuration, this),
            combineDocuments: function(evt) {
                app[this.myHandler].trigger("hideWarning");
                
                if (evt) {
                    //stop form submission
                    evt.preventDefault();
                }
                var self = this;
                var objectIds = [];
                var objectNames = [];
                var bookmarkValues = [];
            	var numCopies = [];

                //Filter out docs that have been excluded
                var docsToBeCombined = _.filter(this.searchResultsViewController.grid.getData().getItems(), function(doc){
                    return !_.contains(this.searchResultsViewController.grid.excludedDocs, doc.objectId);
                }, this);

                self.action.get('parameters').excludeIndexPage = !this.searchResultsViewController.includeIndexPage;

                if(this.selectVersionsEnabled) {
                    // Replace the object ids for documents with different selected versions
                    _.each(this.searchResultsViewController.grid.versionSelections, function(selectedVersionObj, workingCopyId) {
                        // replace the old objectId with the selected versionId!
                        var oco = _.find(docsToBeCombined, function(oco){
                            return oco.objectId === workingCopyId;
                        });
                        if(oco) {
                            oco.objectId = selectedVersionObj.selectedVersionId;
                        }
                    });
                }

                //For each model on the collection, add it's id and name to the appropriate array
                //to be passed into the action executer
                _.each(docsToBeCombined, function(collectionDoc) {
                    var bookmarkValue = collectionDoc.bookmarkValue;
                    if (bookmarkValue) {
                        bookmarkValues[objectNames.length] = bookmarkValue;
                    } else {
                        bookmarkValues[objectNames.length] = collectionDoc.objectName;
                    }

                    objectIds[objectIds.length] = collectionDoc.objectId;
                    objectNames[objectNames.length] = collectionDoc.objectName;
                	numCopies.push(1);
            });

                // check and see if we have any selectedDocumentsData and if so build up a map of objectNames to their selected pages input to send to the backend
                var selectedPages = {};
                if (self.selectedPagesEnabled) {
                    _.each(this.searchResultsViewController.grid.pageSelection,function(pages,objectName){
                        selectedPages[objectName] = pages;
                    });
                }

                //Add the arrays that were just populated onto the action params
                self.action.get("parameters").objectIds = objectIds;
                self.action.get("parameters").objectNames = objectNames;
                self.action.get("parameters").indexTitle = self.config.get("indexTitle");
            	self.action.get("parameters").numCopies = numCopies;
                self.action.get("parameters").bookmarkValues = bookmarkValues;
                self.action.get("parameters").fileName = self.defaultName + ".pdf";
                self.action.get("parameters").selectedPagesMap = selectedPages;
                //back end expects a string true/false
                self.action.get("parameters").asyncThread = this.async ? "true" : "false";

                //this parameter tell us the format we want our output to be in, options are 
                //ByteArrayOutputStream or File
                self.action.get("parameters").outputContentFormat = HPIConstants.ByteArrayOutputStream;

                if (self.exportWithAnnotationsToAttachments) {
                    self.allAttachments = [];
                    self.annotations = [];
                    // If the user has selected some annotators
                    if (self.action.get("parameters").annotationInfo) {
                        self.executeAction();
                        // If the user has not selected any annotators yet
                    } else {
                        var deferreds = [];
                        // For each document the user has selected, we want to call getAnnotations
                        _.each(self.action.get("parameters").objectIds, function(objectId) {
                            var selectdDoc = _.find(self.searchResultsViewController.grid.getData().getItems(), function(doc) {
                                return doc.objectId === objectId;
                            });
                            var lastModified = moment(selectdDoc.modifiedDate, self.dateFormat).unix();
                            var documentName = selectdDoc.objectName;

                            deferreds.push(self.getAnnotations(objectId, lastModified, documentName, self.allAttachments, self.annotations));
                        }, self);

                        $.when.apply(null, deferreds).done($.proxy(function() {
                            // If there are no annotations on the documents, we combine the PDF as usual.
                            if (self.annotations.length === 0) {
                                self.executeAction();
                            } else {
                                self.exportWithAnnotationsView(self.allAttachments);
                            }
                        }, self));
                }
            } else {
                self.executeAction();
            }
        },
        makeCheckStatusCall: function(uniqueId) {
            $.ajax({
                url: app.serviceUrlRoot + "/asyncThread/status",
                method: "POST",
                global: false,
                context: this,
                data: {
                    uniqueId: uniqueId,
                    download: "false"
                },
                success: _.partial(this._makeCheckStatusCallSuccess, _, uniqueId),
                error: _.partial(this._makeCheckStatusCallError)
            });
        },

        /**
         * Function to be executed in the error callback of makeCheckStatusCall
         */
        _makeCheckStatusCallError: function() {
            app[this.myHandler].trigger("showError", "Cannot get annotations from OC");
        },

        /**
         * Function to be executed in the success of makeCheckStatusCall
         */
        _makeCheckStatusCallSuccess: function(data, uniqueId) {
            if (data.percent === 100) {
                app.log.debug("Successfully created combined PDF with ID: " + data.result);
                app[this.myHandler].trigger("loading", false);
                app[this.myHandler].trigger("hideProgress");
                app[this.myHandler].trigger("hideInfo");
                app.trigger("stage.refresh.bothIds", true, undefined);

                var url = "StageSimple/" + data.result[0].objectId;
                var message = '<label>' + (window.localize("modules.actions.advancedCombineToPDF.pleaseWait.successfullyCombinedPDFs")) + '</label><a data-bypass href=' + url + '>  Combined PDF</a>';
                app[this.myHandler].trigger("showMessage", message);

                if (this.folderNotesEnabled) {
                    if (app.context.container.get("objectId")) {
                        this.createFolderNotes(app.context.container.get("objectId"), this.options.action.get('parameters').objectNames, this.options.action.get('parameters').objectIds);
                    }
             	}
            } else {
                app[this.myHandler].trigger("showInfo", window.localize("modules.actions.advancedCombineToPDF.pleaseWait"));
                app[this.myHandler].trigger("updateProgress", data.percent);
                app.log.debug("Trying again - not complete yet");
				var self = this;
                setTimeout(function() {
                	self.makeCheckStatusCall(uniqueId);
                }, AdvancedCombineToPDF.timeoutDuration);

            }
        },
        makeCheckStatusCallForDownload: function(uniqueId) {
            var self = this;
            $.ajax({
                url: app.serviceUrlRoot + "/asyncThread/download/status",
                method: "POST",
                global: false,
                data: {
                    uniqueId: uniqueId,
                    download: "false"
                },
                success: function(data) {
                    if (data.percent === 100) {
                            //boom, were done, lets hit that download endpoint
                            downloadUtils.asyncDownload(app.serviceUrlRoot + '/asyncMap/download/file?download=true&uniqueId=' + uniqueId);

                            app[self.myHandler].trigger("hideProgress");
                            app[self.myHandler].trigger("hideInfo");
                            app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.advancedCombineToPDF.successfullyCombined")));

                            //check the config to see if folder notes should be created
                            if (self.folderNotesEnabled) {
                                if (app.context.container.get("objectId")) {
                                    self.createFolderNotes(app.context.container.get("objectId"), self.options.action.get('parameters').objectNames, self.options.action.get('parameters').objectIds);
                            }
                        }
                    } else {
                        app[self.myHandler].trigger("showInfo", window.localize("modules.actions.advancedCombineToPDF.pleaseWait"));
                        app[self.myHandler].trigger("updateProgress", data.percent);
                        app.log.debug("Trying again - not complete yet");
                        setTimeout(function() {
                            self.makeCheckStatusCallForDownload(uniqueId);
                        }, AdvancedCombineToPDF.timeoutDuration);

                    }
                },
                error: function() {
                    app[self.myHandler].trigger("showError", "Cannot get annotations from OC");
                }
            });
        },
        executeAction: function() {
            var self = this;
                if(!app.context.container.get("objectId") && self.folderNotesEnabled){
                    app.trigger("alert:error", {
                        header: window.localize("generic.configurationIssue"),
                        message: window.localize("modules.actions.advancedCombineToPDF.configIssue.folderNotes")
                    });
                }else{
                    // add prop- to each key as that's the way OC expects the properties
                    // check if all the required attributes are filled in
                    // This needs to be done in regards to form support
                    if (self.saveToRepo) {
                        var unwrappedPropertiesMap = {};
                        _.each(_.extend({}, {
                            'objectName': self.defaultName
                        }, self.propertiesView.getValues()), function(item, key) {
                            unwrappedPropertiesMap["prop-" + key] = item;
                        });
                        self.action.get("parameters").properties = unwrappedPropertiesMap;
                        var path = "";
                        if (self.contextLessUpload) {
                            //we have some paths to use, lets get the right one for our object type     
                            if (self.customTypePaths && self.customTypePaths[self.form] && self.customTypePaths[self.form][self.options.config.objectType]) {
                                //got a custom path, lets snag it
                                path = self.customTypePaths[self.form][self.options.config.objectType];
                            } else {
                                //no custom, use default
                                path = self.containerPath;
                            }
                        } else {
                            path = app.context.container.get("objectId");
                        }
                        self.action.get("parameters").parentFolderPath = path;
        
                        self.action.get("parameters").pdfObjectType = self.options.config.objectType;
                    }
                    if (this.async) {
                        self.action.execute({
                            success: function(data) {
                                $("#advancedCombineToPdf").empty();
                                app[self.myHandler].trigger("showProgress");
                                if (self.saveToRepo) {
                                    self.makeCheckStatusCall(data.result);
                                } else {
                                    self.makeCheckStatusCallForDownload(data.result);
                                        }
                                    },
                            error: function() {
                                app[self.myHandler].trigger("showError", window.localize("modules.actions.advancedCombineToPDF.combineFailed"));
                            }
                        });
                    } else {
                        this.executeActionSync();
                    }
            }
        },
            executeActionSync: function() {
                var self = this;

                if (self.saveToRepo) {
                    self.action.execute({
                        success: function(data) {
                            app.log.debug("Successfully created combined PDF with ID: " + data.result);
                            app[self.myHandler].trigger("loading", false);
                            app.trigger("stage.refresh.bothIds", true, undefined);
    
                            var url = "StageSimple/" + data.result[0].objectId;
                            var message = '<label>' + (window.localize("modules.actions.advancedCombineToPDF.pleaseWait.successfullyCombinedPDFs")) + '</label><a data-bypass href=' + url + '>  Combined PDF</a>';
                            app[self.myHandler].trigger("showMessage", message);

                            //check  if folder notes should be created
                            if (self.folderNotesEnabled) {
                                if (app.context.container.get("objectId")) {
                                    self.createFolderNotes(app.context.container.get("objectId"), self.options.action.get('parameters').objectNames, self.options.action.get('parameters').objectIds);
                            }
                        }
                    },
                    error: function() {
                        app[self.myHandler].trigger("showError", window.localize("modules.actions.advancedCombineToPDF.combineFailed"));
                    }
                });
            } else {
                var callback = function() {
                    app[self.myHandler].trigger("showMessage", window.localize("modules.actions.advancedCombineToPDF.successfullyCombined"));
                };
                downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', self.action.attributes, callback);                           
                
                    //check if folder notes should be created
                    if (self.folderNotesEnabled) {
                        if (app.context.container.get("objectId")) {
                            self.createFolderNotes(app.context.container.get("objectId"), self.options.action.get('parameters').objectNames, self.options.action.get('parameters').objectIds);
                    }
                }
            } 
        },
        createFolderNotes: function(objectId, objectNames, objectIds) {
            var self = this;
            var note_type, parentID;
            var noteContent = "<p>" + (window.localize("modules.actions.advancedCombineToPDF.user")) + app.user.get("displayName") + (window.localize("modules.actions.advancedCombineToPDF.createdAnCombined"));

                _.each(objectNames, function(objectName, index) {
                    noteContent += "<a class='stageLink' documentId='" + objectIds[index] + "'>" + objectName + "</a>" + ", ";
                });

                noteContent = noteContent.substring(0, noteContent.length - 2);
                noteContent += "</p>";
                parentID = objectId;
                note_type = self.config.get("folderNoteType");

                FolderNotes.Service.execute({
                    parameters: {
                        parentID: parentID,
                        note_content: noteContent,
                        note_rel_type: self.config.get("folderNoteRelationship"),
                        note_object_type: self.config.get("folderNoteObjectType"),
                        property_map:{
                            note_type: note_type
                    }
                }
            });
        },
        getAnnotations: function(objectId, lastModified, documentName, allAttachments, annotations) {
            var self = this;
            var authors = [];
            return $.ajax({
                url: app.serviceUrlRoot + "/annotation/getAnnotations",
                dataType: "json",
                method: "GET",
                data: {
                    id: objectId,
                    lastModified: lastModified
                },
                success: function(data) {
                        // We only want to add the info to allAttachments if there were any annotations returned
                        if (data.annotations && data.annotations.length > 0) {
                            _.each(data.annotations, function(annotation) {
                                annotations.push(annotation);
                                authors.push(annotation.title);
                            });
                        }
                    },
                    error: function() {
                        app[self.myHandler].trigger("showError", "Cannot get annotations from OC");
                    },
                    global: false
                }).done(function() {
                    // We only want to add the info to allAttachments if there were any annotations returned
                    if (authors.length > 0) {
                        authors = _.uniq(authors);
                        allAttachments.push({ id: objectId, name: documentName, authors: authors });
                    }
                });
            },
            exportWithAnnotationsView: function(allAttachments) {
                var self = this;
                app[self.myHandler].trigger("loading", false);

                // Pass allAttachments and self.model.action into new ExportWithAnnotations view
                self.exportWithAnnotationsForm = new ExportWithAnnotations.View({
                    options: this,
                    allAttachments: allAttachments,
                    action: self.action
                });
                self.setView("#exportWithAnnotationsForm", self.exportWithAnnotationsForm);
                self.exportWithAnnotationsForm.render();
            },    
            // click event that gets fired when clicking on the 'Create PDF' btn when it is disabled so that we can show error messages
            clickCombineBtnContainer: function() {
                var inValidSelectedPages = _.find(this.selectedDocumentModels, function(selectedDocument) { 
                    return !selectedDocument.validate(); 
                });

                if ($("#download-pdf-name").val() === "") {
                    app[this.myHandler].trigger("showInfo", (window.localize("modules.actions.advancedCombineToPDF.fileToBeCreatedName")), true);
                } else if (inValidSelectedPages) {
                    app[this.myHandler].trigger("showError", (window.localize("modules.actions.advancedCombineToPDF.thereIsAnError")), true);
                } else {
                    app[this.myHandler].trigger("hideError");
                }
            },
            buildAndSetSearchResultsView: function() {
                var self = this;
                var deferred = $.Deferred();
                app.context.configService.getSearchConfigByName(this.config.get("currentSearchConfig"), function(searchConfig){
                    //get start time for the requests
                    self.canBeReadRequestsStart = Date.now();

                    //as docs are found to be invalid, they are removed from the collection and selectedDocumentModels
                    //need to find how many docs are being checked at the beginning
                    self.canBeReadRequestsToBeCompleted = self.collection.fullCollection.models.length;

                    // We need to use the fullCollection since we want to loop through every document. If we used jsut the collection,
                    //then we would only loop through one page of documents
                    _.each(self.collection.fullCollection.models, function(selectedDocument){
                        self.selectedDocumentModels.push(new AdvancedCombineToPDF.SelectedDocument({
                            parentView: self,
                            model: selectedDocument.get("properties"),
                            selectedPagesEnabled: self.selectedPagesEnabled,
                            computedBookmarkPattern: self.config.get('computedBookmarkPattern'),
                            config: self.options.config,
                            searchResultsViewController: self.searchResultsViewController
                        }));
                    });

                    self.pollingForProgressBar();

                    //Putting tableview options on the controller
                    self.searchResultsViewController.sortable = false;
                    self.searchResultsViewController.saveUserPrefs = false;
                    self.searchResultsViewController.rowSelection = false;
                    self.searchResultsViewController.disableRightClickMenu = true;
                    self.searchResultsViewController.enableColumnPicker = false;
                    self.searchResultsViewController.plugins = [
                        HPIConstants.TableView.Plugins.RowToggleColumn,
                        HPIConstants.TableView.Plugins.OrderInputColumn,
                        HPIConstants.TableView.Plugins.DragAndOrderRows
                    ];
                    self.searchResultsViewController.searchStatisticsEnabled = false;

                    if(self.selectedPagesEnabled){
                        self.searchResultsViewController.plugins.push(HPIConstants.TableView.Plugins.OAPageSelectColumn);
                    }
                    if(self.showBookmarkColumn){
                        self.searchResultsViewController.plugins.push(HPIConstants.TableView.Plugins.BookmarkColumn);
                    }
                    if(self.selectVersionsEnabled) {
                        self.searchResultsViewController.plugins.push(HPIConstants.TableView.Plugins.SelectVersionColumn);
                    }

                    if (self.enableLimitCombinedPdfSize) {
                        self.searchResultsViewController.plugins.push(HPIConstants.TableView.Plugins.RowSizeColumn);
                    }

                    if(self.addNumColumnPlugin) {
                        self.searchResultsViewController.plugins.push(HPIConstants.TableView.Plugins.NumCopiesColumn);
                    }

                    //Put the current handler on tableview so that we have reference to it in tableview
                    self.searchResultsViewController.handler = self.myHandler;
                    self.searchResultView = new SearchResults.Views.Layout({
                        collection : self.collection,
                        configuration : searchConfig,
                        context : HPIConstants.TableView.Context.ACTPDF,
                        searchResultsViewController: self.searchResultsViewController
                });
                self.setView('#selectedDocsOutlet', self.searchResultView);
                deferred.resolve();
            });
            return deferred;
        },
            pollingForProgressBar: function(){
                var self = this;
                var progressPercent = (self.completedCanBeReadRequests / self.canBeReadRequestsToBeCompleted) * 100;

                //if all documents are non-PDFs, there will be 0 canBeRead requests
				//this also handles undefined or null values
                //set this to be 100% completion to fast-forward the user to the warning message
                if (isNaN(progressPercent)) {
                    progressPercent = 100;
                }

                //round to the nearest percent
                app[self.myHandler].trigger("updateProgress", Math.floor(progressPercent));
                if (progressPercent < 100) {
                    _.delay(_.bind(self.pollingForProgressBar,self), self.progressBarPollTimeout);
                } else {
                    //find how long it took for all the canBeRead requests to complete
                    var timeToCompleteAllCanBeReadRequests = Date.now() - self.canBeReadRequestsStart;

                    //If requests took less than the specified timeout length of time, wait the difference. If not, don't wait.
                    if (timeToCompleteAllCanBeReadRequests < AdvancedCombineToPDF.progressBarCompletionTimeout) {
                        setTimeout(function(){
                        self.progressBarComplete();
                    }, AdvancedCombineToPDF.progressBarCompletionTimeout - timeToCompleteAllCanBeReadRequests);
                } else {
                    self.progressBarComplete();
                }
            }
        },
            progressBarComplete: function(){
                //hide progress bar and message, show content div and render error section
                app[this.myHandler].trigger("hideInfo");
                app[this.myHandler].trigger("hideProgress");
                $('#' + this.myHandler + '-content').show();
                
                // we only want to show the warning if we have errored docs
                //Check if each of the value arrays for the objects in errorDocs are empty.
                //As soon as one array is found to be not empty, _.some() stops iterating and returns true.
                if (_.some(this.errorDocs, function(error) {
                    return !_.isEmpty(error.values);
                })) {
                    var erroredDocsView = new AdvancedCombineToPDF.ErroredDocsView({
                        errorDocs: this.errorDocs
                    });
                    app[this.myHandler].trigger("showWarning", erroredDocsView);
                }
                this.render();
        },
            buildAndSetPropertiesView: function(){
                var properties = {};
                this.options.config.objectType = this.config.get('selectedDocumentType');
                if (this.config.get("inheritFolderAttributes") && this.config.get("inheritFolderAttributes") === 'true') {
                    properties = app.context.container.get("properties");
                    properties.objectName = this.defaultName;
                } else {
                    properties = {
                        'objectName': this.defaultName
                };
            }
                this.propertiesView = new AdvancedCombineToPDF.View.Properties(_.extend({}, this.config.attributes, {
                    'objectType': this.config.get('selectedDocumentType'),
                    'properties': properties,
                    'formName': this.config.get('form')
                }));
                this.setView('#propertiesOutlet', this.propertiesView);
        },
            removeErroredDoc: function(selectedDocModel, reason){
                var modelToRemove = this.collection.find(function(model){
                    return model.get("objectId") === selectedDocModel.get("model").objectId;
                });
                this.collection.remove(modelToRemove);
                //Remove the document from the selectedDocumentModels
                this.selectedDocumentModels = _.without(this.selectedDocumentModels, selectedDocModel);

                //Grid may not be created at this point
                if(this.searchResultsViewController.grid){
                    _.each(this.collection.models, function(model,index){
                        model.get("properties").ordinal =  index + 1;
                    });
                    this.searchResultsViewController.grid.getData().setItems(this.collection, "objectId");
                }
                this.errorDocs[reason].values.push(selectedDocModel.get("model"));

                //Update the Search Result Controls display message
                this.searchResultsViewController.tableEventsRef.trigger('filter:collection', this.collection);
                this.validate();
            },
            // when user clicks edit props tab, hide next button, show save button
            saveToRepoEditPropertiesTabClick: function() {
                $('#combine-nextBtn-container').hide();
                $('#combine-submitBtn-container').show();
            },
            // when user clicks select docs tab, hide save button, show next button
            saveToRepoSelectedDocumentsTabClick: function() {
                $('#combine-nextBtn-container').show();
                $('#combine-submitBtn-container').hide();
            },
            // when user clicks next button, show the edit props tab
            saveToRepoNextTabBtnClick: function() {
                // this will fire the edit properties tab listener
                $('#actpdf-propsTabLink').tab('show');
        },
            beforeRender: function() {
                if (this.fetched) {
                    if (this.saveToRepo && !this.propertiesView) {
                        this.buildAndSetPropertiesView();
                }
            }
        },
        afterRender: function() {
                this.$("#download-pdf-name").val(this.defaultName);
            
                //No point in validating anything until documents are fetched
                if (this.fetched) {
                    this.validate();
            }
        },          
        serialize: function() {
            var modal = (this.myHandler === "modalActionHandler");
            return {
                saveToRepo: this.saveToRepo,
                modal: modal
            };
        },
        cleanup: function() {
            this.stopListening();
        }
    });

        AdvancedCombineToPDF.ErroredDocsView = Backbone.Layout.extend({
            template: "actions/advancedcombinetopdf/erroredDocs",
            initialize: function(options) {
                this.errorDocs = options.errorDocs;
        },
            serialize: function() {
                return {
                    errorDocs: this.errorDocs
                };
            }
        });

        AdvancedCombineToPDF.SelectedDocument = Backbone.Model.extend({
            defaults:{
                docProps: {},
                erroredDocNames: []
        },
            initialize: function(options) {
                this.set("parentView", options.parentView);
                //setting the duration time on the model to make unit testing easier
                this.set("pollingForRenditionDelay", AdvancedCombineToPDF.renditionPollTimeout);
                this.set("selectedPagesEnabled", options.selectedPagesEnabled);
                this.set("computedBookmarkPattern", options.computedBookmarkPattern);
                this.set("config", options.config);
                this.determineAndSetBookmark();
                this.set("objectName", this.get("model").objectName);
                // If the config is disabled we know everything passed into available docs is already renditioned
                // otherwise we have to check
                if (this.get("config").get("allowRenditionable") === "true") {
                    this.get("model").isRenditioning =  true;
                    var pollingFinishedDeferred = $.Deferred(); 
                    this.pollingForRendition(pollingFinishedDeferred);
                    pollingFinishedDeferred.done(_.bind(function(){
                        this.checkCanBeRead();
                    }, this));
                } else {
                    this.get("model").isRenditioning = false;
                    this.checkCanBeRead();
                }
            },
            determineAndSetBookmark: function(){
                if (this.get("computedBookmarkPattern")) {
                    this.set("attrsInBookmark", app.context.util.parsePatternForAttributes(this.get("computedBookmarkPattern")));
                    this.set("delimitersInBookmark", this.get("computedBookmarkPattern").split("$"));
                }
                if (!this.get("model").bookmarkValue) {
                    var tempBookmarkString = "";
                    if (this.get("delimitersInBookmark") && this.get("delimitersInBookmark").length !== 0) {
                        _.each(this.get("delimitersInBookmark"), function(delimiter) {
                            if (_.contains(this.get("attrsInBookmark"), delimiter)) {
                                if (delimiter === "objectName") {
                                    var delimiterPieces = this.get("model")[delimiter].split(".");
                                    tempBookmarkString += delimiterPieces[0];
                                } else {
                                    tempBookmarkString += this.get("model")[delimiter];
                                }
                            } else if (delimiter !== "" && delimiter !== null) {
                                tempBookmarkString += delimiter;
                            }
                        }, this);
                    } else {
                        tempBookmarkString = this.get("model").objectName;
                    }

                    this.get("model").bookmarkValue = tempBookmarkString;
                }
            },
            pollingForRendition: function(pollingFinishedDeferred) {
                var self = this;
                app.log.debug("Checking if doc is renditioning");
                $.ajax({
                    url: app.serviceUrlRoot + "/isRenditioning",
                    data: {
                        objectId: self.get("model").objectId
                    },
                    success: function(isRenditioning) {
                        if (isRenditioning.value) {
                            _.delay(_.bind(self.pollingForRendition,self), self.get("pollingForRenditionDelay"), pollingFinishedDeferred); // change this <-- make configurable
                            //if it's still renditioning, count it as a completed canBeRead request so the user isn't stuck waiting
							//if the rendition completes successfully, the doc can definitely be read
                            self.get("parentView").completedCanBeReadRequests++;
                        } else {
                            self.get("model").isRenditioning = false;
                            self.getMimetype(pollingFinishedDeferred);
                        }
                    },
                    error: function() {
                        //Should probably be updated to be a different reasion then NON_PDF
                        self.get("searchResultsViewController").tableEventsRef.trigger("selected:docs:removeDoc",self, AdvancedCombineToPDF.NON_PDF);
                    },
                    global: false
                });
            },
            getMimetype: function(pollingFinishedDeferred){
                $.ajax({
                    type: 'GET',
                    url: app.serviceUrlRoot + '/content/getContentInfo',
                    data: {
                        "ids[]": [this.get("model").objectId]
                    },
                    success: _.bind(this.mimetypeFound, this, pollingFinishedDeferred),
                    error: _.bind(this.mimetypeNotFound, this, pollingFinishedDeferred),
                    global: false
                });
            },
            checkCanBeRead: function(){
                var self = this;
                $.ajax({
                    url: app.serviceUrlRoot + "/pdf/canBeRead?objectId=" + self.get("model").objectId,
                    success: function() {
                        if(self.get("searchResultsViewController").grid){
                            var row = self.get("searchResultsViewController").grid.getData().getRowById(self.get("model").objectId);
                            //invalidating the row and calling a rerender on the grid, should only rerender the invalidated row. 
                            //This should update that row to not have an HPISpinnner
                            self.get("searchResultsViewController").grid.invalidateRow(row);
                            self.get("searchResultsViewController").grid.render();
                        }
                        self.get("searchResultsViewController").tableEventsRef.trigger("actpdf:renderFinished");
                    },
                    error: function(jqXHR) {
                        if (jqXHR.status === HPIConstants.HTTP.Status.Locked) {
                            self.get("searchResultsViewController").tableEventsRef.trigger("selected:docs:removeDoc", self, AdvancedCombineToPDF.PASSWORD_PROTECTED);
                        } else if (jqXHR.status === HPIConstants.HTTP.Status.UnsupportedMediaType) {
                            self.get("searchResultsViewController").tableEventsRef.trigger("selected:docs:removeDoc", self, AdvancedCombineToPDF.CORRUPT);
                        } else {
                            self.get("searchResultsViewController").tableEventsRef.trigger("selected:docs:removeDoc", self, AdvancedCombineToPDF.IS_NOT_READABLE);
                        }
                    },
                    global: false
                }).always(function() {
                    self.get("parentView").completedCanBeReadRequests++;
                });
            },
            mimetypeFound: function(pollingFinishedDeferred, response) {
                var pdfFound = _.find(response[0].mimeTypes, function(mimetype) {
                    return mimetype == "application/pdf";
                });
                if (pdfFound) {
                    pollingFinishedDeferred.resolve();
                } else {
                    this.mimetypeNotFound(pollingFinishedDeferred);
                }  
            },
            mimetypeNotFound: function(pollingFinishedDeferred) {
                this.get("searchResultsViewController").tableEventsRef.trigger("selected:docs:removeDoc",this, AdvancedCombineToPDF.NON_PDF);
                pollingFinishedDeferred.reject();
                this.get("parentView").canBeReadRequestsToBeCompleted--;
            },
            validate: function() {
                var docIsExcluded = false;
                if(this.get("searchResultsViewController").grid){
                    docIsExcluded = _.contains(this.get("searchResultsViewController").grid.excludedDocs, this.get("model").objectId);
                }
                //If the document is excluded from the ACTPDF job then we can say that this model is valid
                return docIsExcluded || !this.get("model").isRenditioning;
            }
        });

        AdvancedCombineToPDF.View.Properties = Backbone.Layout.extend({
            template: "actions/advancedcombinetopdf/advancedcombinetopdfproperties",
            initialize: function() {
                // we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
                // on the bulk properties page)
                var defaults = {
                    properties: {},
                    enableRequired: true
                };

                var opts = this.options = _.extend(defaults, this.options);

                // this properties view model is what form support uses to put its controls on and other functions
                var propertiesViewModel = this.options.propertiesViewModel = {};

                // init form support - we only want atCreation attributes to show up since we're uploading stuff
                Formsupport.tsgFormSupport(propertiesViewModel, {
                    'isCreate': true,
                    'enableRequired': opts.enableRequired,
                    'enableReadonly': opts.enableReadonly,
                    'formName': opts.formName
                });

                // set the form control properties once the controls have finished building
                propertiesViewModel.controls.subscribe(function() {
                    // set our initial values once the controls have built
                    propertiesViewModel.setValues(opts.properties);
                });

                // emit an event whenever the form's validity changes
                propertiesViewModel.isValid.subscribe(function(isValid) {
                    AdvancedCombineToPDF.Events.trigger('change:properties', isValid);
                });

                // set the object type which will trigger the controls to be generated
                propertiesViewModel.objectType(opts.objectType);
            },
            afterRender: function() {
                // form support uses knockout so let's apply those bindings
                kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
        },
            getValues: function() {
                return this.options.propertiesViewModel.getValues();
        },
            isValid: function() {
                return this.options.propertiesViewModel.isValid();
        },
            serialize: function() {
                return {
                    objectType: this.options.objectType,
                    // only used if we're not in bulk properties page - to display the original document name of the document
                    // currently being edited
                    title: this.options.title
            };
        }
        });

        actionModules.registerAction("advancedCombineToPDF", AdvancedCombineToPDF, {
            "actionId": "advancedCombineToPDF",
            "label": (window.localize("modules.actions.advancedCombineToPDF.generateCombinedPdf")),
            "icon": "filter",
            "handler": "modalActionHandler",
            "paneSize": "rightPane"
        });

        return AdvancedCombineToPDF;

    });

require(["advancedcombinetopdf"]);