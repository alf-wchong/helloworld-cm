//CompareDocuments module
define("comparedocuments", [
	"app",
	"modules/actions/actionmodules"
],

function(app, actionModules) {
	"use strict";

	var action = {};
	
	action.View = Backbone.Layout.extend({
		initialize: function(options){
			this.options = options;
			this.compareDocs(options.action.get("parameters").objectIds[0], 
			options.action.get("parameters").objectIds[1]);
		},
		compareDocs: function(doc1, doc2){
			window.open(app.serviceUrlRoot + "/content/compare?primaryId=" + doc1 + "&modifiedId=" + doc2 + "&contentType=application%2Fpdf");
		}
	});
	actionModules.registerAction("compareDocuments", action, {
		"actionId" : "compareDocuments",
		"label" : "Compare Documents", 
		"icon" : "switch"
	});

	return action;
	
});
require(["comparedocuments"]);
