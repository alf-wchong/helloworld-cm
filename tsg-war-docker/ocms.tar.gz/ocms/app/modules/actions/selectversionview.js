define([
    'app',
    "modules/common/action",
    "modules/common/hpiconstants",
    "viewversions"
], function (app, Action, HPIConstants, ViewVersions) {

    var SelectVersion = {};

    SelectVersion.View = Backbone.Layout.extend({
        // we'll set the template in initialize based on our mode
        template: null,
        events: {
            "click #select-version-btn": "triggerSelectVersionDone",
            "click #close-modal-btn": "triggerPreviewVersionDone",
            "click #done-previewing-version-btn": "triggerPreviewVersionDone",
            "click #cancel-select-version-btn": "triggerSelectVersionViewClosed"
        },
        initialize: function (options) {
            this.action = new Action.Model({
                actionId: HPIConstants.Actions.ViewVersions,
                ocActionId: HPIConstants.Actions.ViewVersions,
                name: HPIConstants.Actions.ViewVersions,
                parameters: {
                    objectId: this.options.objectId,
                    objectName: this.options.objectName
                }
            });
            this.mode = options.mode;
            this.row = options.row;
            this.template = this.mode === "popover" ? "actions/selectversion/selectversionpopover" : "actions/selectversion/selectversionmodal";
            this.config = new Backbone.Model({
                // doesn't really matter what we pass in here..
                // just used to display revert/compare buttons which we aren't using
                handler: HPIConstants.Handlers.ModalActionHandler
            });
            this.isPreviewingVersion = false;
            this.selectedVersionLabel = this.options.selectedVersionLabel || "";
            this.createViewVersionsView();
        },
        createViewVersionsView: function () {
            this.selectVersionsView = new ViewVersions.View({
                action: this.action,
                config: this.config,
                selectVersionMode: true,
                selectedVersionLabel: this.options.selectedVersionLabel || ""
            });
            this.insertView("#select-version-modal-body-content", this.selectVersionsView);
            // kill any previous listeners
            this.stopListening(this.selectVersionsView);
            this.listenTo(this.selectVersionsView, "previewVersionInOA", this.triggerPreviewVersion);
        },
        createOAPreviewVersionView: function (options) {
            this.OAPreviewVersionView = new SelectVersion.OAPreviewView({
                objectId: options.objectId,
                objectName: options.objectName,
                versionLabel: options.versionLabel
            });
            this.insertView('#select-version-modal-body-content', this.OAPreviewVersionView);
        },
        triggerPreviewVersion: function (options) {
            this.isPreviewingVersion = true;
            // need to update the version label on the select version footer button
            this.selectedVersionLabel = options.versionLabel;
            this.createOAPreviewVersionView(options);
            // need to render to get the updated isPreviewingVersion values to the DOM
            this.render();
        },
        triggerPreviewVersionDone: function () {
            // When we have a modal, this is triggered by the close button
            // when isPreviewingVersion is true, we want to return to the view versions view
            // otherwise, just close the modal and return to the parent view
            if (this.isPreviewingVersion) {
                this.isPreviewingVersion = false;
                this.createViewVersionsView();
                // set the select version label to its reset value
                this.selectedVersionLabel = this.selectVersionsView.viewModel.selectedVersion.versionLabel;
                this.render();
            } else {
                // we're not previewing a version, the user has dismissed the modal
                this.triggerSelectVersionViewClosed();
            }
        },

        // let our parent view know that we're closed so we can be removed
        triggerSelectVersionViewClosed: function() {
            this.trigger('selectVersionView:closed');
        },
        triggerSelectVersionDone: function () {
            // they either clicked select version while previewing a version or using the input buttons
            var selectedVersion = this.selectVersionsView.viewModel.previewVersion || this.selectVersionsView.viewModel.selectedVersion;
            
            if(this.options.callbackContext) {
                this.options.persistSelectedVersions.call(this.options.callbackContext, selectedVersion, this.row);
            } else {
                this.options.persistSelectedVersions(selectedVersion, this.row);
            }
        },
        // used to resize modal and popover
        resizeModal: function () {
            var iframeElement = $("#tableview-preview-version-iframe");
            var modalBody = $("#select-version-modal-body");
            var iframeOffset = iframeElement.offset();
            // 140 is a rough estimate of the top offset above the iframe
            var iframeOffsetTop = iframeOffset === undefined || iframeOffset.top === 0 ? 140 : iframeOffset.top;
            // 10 parameter means we want the int as a decimal
            var modalBodyPaddingBottom = modalBody === undefined ? 0 : parseInt(modalBody.css("padding-bottom"), 10);
            var containerBottomHeight = 0;
            if (this.mode === "modal") {
                // using hard coded values here because when this function is called, the modal is not on dom
                // height of the version title
                var previewVersionTitleHeight = 18;
                // padding of the modal content div
                var bodyOuterHeight = 15;
                var modalDialogContainer = parseInt($('#select-version-modal-dialog').css('margin-bottom'), 10);
                containerBottomHeight = parseInt($('#select-version-modal-dialog').css('margin-bottom'), 10) + previewVersionTitleHeight + bodyOuterHeight + modalDialogContainer;
            } else {
                // outerHeight minus content height is equal to the border, margin, and padding of the element
                containerBottomHeight = $('.popover-content').outerHeight() - $('.popover-content').height();
                containerBottomHeight += parseInt($('.modal-dialog').css('margin-bottom'), 10);
            }
            // 15 comes from a rough estimate of the border px on this iframe dom tree
            var newIframeHeight = window.innerHeight - 15 - iframeOffsetTop - containerBottomHeight - modalBodyPaddingBottom - $("#select-version-modal-footer").outerHeight(true);
            iframeElement.height(newIframeHeight);
        },
        serialize: function () {
            return {
                isPreviewingVersion: this.isPreviewingVersion,
                versionLabel: this.selectedVersionLabel
            };
        },
        afterRender: function () {
            if (this.mode === "modal") {
                $('#select-version-modal').modal('show');
            }

            // used to resize modals and popovers
            this.resizeModal();
            this.stopListening(app);
            this.listenTo(app, 'stage.windowResizePanes', this.resizeModal);
        },
        cleanup: function () {
            if(this.OAPreviewVersionView) {
                this.OAPreviewVersionView.remove();
            }

            if(this.selectVersionsView) {
                this.selectVersionsView.remove();
            }
            
            this.stopListening();
        }
    });

    SelectVersion.OAPreviewView = Backbone.Layout.extend({
        template: "actions/selectversion/previewVersionIFrame",
        initialize: function (options) {
            if(options.showInOA) {
                this.contentUrl = app.openAnnotateURL + "/login/external.htm?" +
                    "docId=" + options.objectId +
                    "&username=" + app.user.get("loginName") +
                    "&mode=" + HPIConstants.OpenAnnotate.Modes.OpenViewer;
            } else {
                var objName = options.objectName;
                objName = objName.replace("/", "_");
                objName = objName.replace("\\", "_");
                this.contentUrl = app.serviceUrlRoot + "/content/content/" + objName + "?id=" +  encodeURIComponent(options.objectId) + "&contentType[]=pdf";
            }
            
            this.versionLabel = options.versionLabel;
        },
        serialize: function () {
            return {
                contentUrl: this.contentUrl,
                versionLabel: window.localize("generic.version") + ": " + this.versionLabel
            };
        },
        cleanup: function () {
            this.stopListening();
        }
    });

    return SelectVersion;
});