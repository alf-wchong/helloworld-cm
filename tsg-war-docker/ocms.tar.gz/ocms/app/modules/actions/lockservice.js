define([
    'app',
    'modules/common/action'
], function(app, Action){
    var LockService = {};

    LockService._launchAction  = function(options){
        var action = new Action.Model({
            name:options.actionName,
            parameters: options.parameters
        });
        action.execute({
            success: options.successFunction,
            error: options.errorFunction || defaultLockUnlockErrorFunction,
            global: options.global || false,
            async: options.async || true
        });
    };
    var defaultLockSuccessFunction = function(){
        app.log.debug("Successfully Locked Document");
    };
    var defaultLockUnlockErrorFunction = function(response){
        app.trigger("alert:error",{
            header: "Error",
            message:JSON.parse(response.responseText).message
        });
    };

    var defaultUnlockSuccessFunction = function(){
        app.log.debug("Successfully unLocked Document");
    };
    LockService.LockDocument = function(options){
        options.actionName = 'lock';
        if(!options.successFunction){
            options.successFunction = defaultLockSuccessFunction;
        }
        LockService._launchAction(options);
    };

    LockService.UnlockDocument = function(options){
        options.actionName = 'unlock';
        if(!options.successFunction){
            options.successFunction = defaultUnlockSuccessFunction;
        }
        LockService._launchAction(options);
    };


    return LockService;
});