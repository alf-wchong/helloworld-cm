define("downloaddocument", [
  "app",
  "oc",
  "modules/actions/actionmodules",
  "modules/common/action",
  "foldernotes",
  "modules/common/hpiconstants",
  "modules/hpiadmin/actionconfig/actions/downloaddocument/downloaddocumentconfig",
  "modules/services/logstashservice",
  "modules/common/spinner"
],
function(app, OC, actionModules, Action, FolderNotes, HPIConstants, DownloadDocumentCustomConfigView, LogstashService, HPISpinner) {
	"use strict";

	var DownloadDocument = {};

	DownloadDocument.CustomConfigView = DownloadDocumentCustomConfigView.View;

	DownloadDocument.View = Backbone.Layout.extend({
		template: "actions/downloaddocument",
		events: {
			// this is triggered when a user clicks the submit button of the download document modal
			"click .downloaddocument": "downloadDocument"
		},
		initialize: function() {
			// this is the objectId of the current object on the stage
			this.objectId = this.options.action.get("parameters").objectId;

			// this is the map of patterns for objectTypes configured in the admin
			this.typePatterns = this.options.config.get("typePatterns");
			this.selectedRenditions = this.options.config.get('selectedRenditions');
			this.contentType = ".*";
			_.each(this.selectedRenditions, function(rendition){
				if(rendition.type === "application/pdf"){
					this.contentType = "pdf,.*";
				}
			}, this);

			this.directDownload = this.config.get("directDownloadSwitch");
			
			// used for displaying loading spinner while processing
			this.myHandler = this.options.config.get("handler");
			//Only listen to the instantExecute config if the handler is the modalactionhandler
			if(this.myHandler === HPIConstants.Handlers.ModalActionHandler) {
				this.instantExecute = this.options.config.get("instantExecute") === "true";
			} else {
				this.instantExecute = false;
			}
			this.loading = true;
			this.startListening();
			this.determineDownloadName();
		},
		startListening: function() {
			var self = this;
			this.listenTo(app, "downloadDocument:createFolderNote", function(object) {
				var currentDate = DateFormat.format.date(new Date(),"E, d MM yyyy hh-mm-ss a");
				var tempUser = object.user;
				var docName = app.context.document.get("properties").objectName;
				var parentId;
				if(self.config.get('enableDocumentNoteRelation') && self.config.get('enableDocumentNoteRelation') === "true"){
					parentId = self.objectId;
				}else{
					parentId = app.context.container.get("properties").objectId;
				}
				var noteContent = "<p>" + (window.localize("modules.actions.downloadDocument.theDocument")) + docName + window.localize("modules.actions.downloadDocument.wasDownloaded") + tempUser.id + window.localize("modules.actions.downloadDocument.at") + currentDate +  ". </p>";
				//Create folder note
				FolderNotes.Service.execute({
					parameters: {
						parentID: parentId,
						note_content: noteContent,
						note_rel_type: self.config.get("folderNoteRelationship"),
						note_object_type: self.config.get("folderNoteObjectType"),
						property_map:{
							note_attachment: [app.context.document.get("objectId")],
							note_type: self.config.get("folderNoteType")
						}
					}
				});
			});
		},
		toggleLoader: function(bool){
			if(bool) {
				this.spinner = HPISpinner.createSpinner({
					length:11,
					width:6,
					radius: 16,
					color: '#000',
					shadow: false
				}, this.$("#download-spinner")[0]);
			} else {
				HPISpinner.destroySpinner(this.spinner);
			}
		},
		downloadDocument: function(evt) {
			// NOTE: currently, the event duration for downloading files will almost always
			// be 0 due to us opening the file in a new tab and letting the browser handle
			// all the downloading. If we want to more accurately track the timing, then we 
			// would need to make a custom endpoint.
			var downloadDocumentStartTime = Date.now();
			
			if(evt) {
				evt.preventDefault();
			}

			// Fetch presigned url / direct download
			// if config was set
			var presignedUrl = "";

			if (this.directDownload) {
				presignedUrl = "&presignedUrl=" + this.directDownload;
			}

			this.setWindowLocation(app.serviceUrlRoot + "/content/content?id=" + this.objectId + "&download=true&contentType[]=" + this.contentType + presignedUrl);
			if (this.config.get("folderNotes") === "true") {
				app.trigger("downloadDocument:createFolderNote", {
					"user": app.user,
					"documentId": app.context.document.id
				});
			}

			// Grab the file name, then grab the extension by making a substring of everything after the period.
			var fileExtension = this.getFileExtension(this.downloadName);

			//Log the download document event duration
			var downloadDocumentCompletionTime = Date.now();
			LogstashService.sendMetrics(
				new LogstashService.PerformanceLog({
					'eventTitle': HPIConstants.Logging.Events.DownloadDocument,
					'events': {
						'eventDuration': downloadDocumentCompletionTime - downloadDocumentStartTime,
						'fileExtension': fileExtension
					},
					'objectId': this.objectId
				})
			);

			if(this.instantExecute) {
				app[this.myHandler].trigger("hide");
			}
		},
        setWindowLocation: function(url){
            window.location = url;
		},
		getFileExtension: function(fileName){
			// Will return any extension that is after the LAST period.
			// mockFile.pdf and this.is.a.mock.file.pdf will both return pdf.
			// Every other case will return "NO_EXTENSION".
			var regex = /(?:\.([^.]+))?$/;

			var fileExtension = regex.exec(fileName)[1];

			return fileExtension ? fileExtension : 'NO_EXTENSION';
		},
		determineDownloadName: function(){
			var self = this;
			// get the OC object so we can replace the placeholder attributes with their values
			var oco = new OC.OpenContentObject({ objectId: self.objectId });

			// fetch the OC object and operate on it once it has been fetched
			oco.fetch().done(function(ocObject) {
				// grab the OTC for this object type on this trac since we need to be able to replace date attributes with
				// their appropriate format
				app.context.configService.getAdminTypeConfig(ocObject.objectType, function(ocObjectConfig) {
					// default to the object's objectName
					// if there's no pattern defined it will just use objectName		
					self.downloadName = ocObject.properties.objectName;
					
					// check the typePatterns object to see if a pattern is defined for the objectType of the OC object
					// and that the pattern is not empty
					if(self.typePatterns && self.typePatterns[ocObject.objectType] && self.typePatterns[ocObject.objectType] !== "") {
						// overwrite downloadName with the pattern
						self.downloadName = self.typePatterns[ocObject.objectType];

						// extract the file extension from the objectName
						var objectName = ocObject.properties.objectName;
						var period = objectName.lastIndexOf(".");
						var fileExt = objectName.substring(period + 1);
						// save the object name without the file extension in a variable to use for replacing an
						// objectName placeholder below
						var objectNameMinusFileExt;
						if(period !== -1) {
							objectNameMinusFileExt = objectName.slice(0, period);
						} else {
							objectNameMinusFileExt = objectName;
						}
						// fetch an array of the attributes that need to be replaced with the proper value
						var allAttrs = app.context.util.parsePatternForAttributes(self.downloadName);
						
						// loop over the attributes and substitute the placeholder with the value
						_.each(allAttrs, function(attrName) {
							// let's assume there isn't a value for our attribute (blank, null, etc), which we'll therefore
							// replace with an empty string
							var replaceValue = "";
							
							// if this attribute has a value on the OC object
							if(ocObject.properties[attrName]) {
								// get the configuration from the type config so we can check this attr's dataType
								// if it's a date, we want to format the date as configured
								var attrConfig = ocObjectConfig.get("attrs").findWhere({ ocName: attrName });

								if(attrName === "objectName") {
									// want to use the special file extension stripped objectName
									replaceValue = objectNameMinusFileExt;
								} else if(attrConfig.get("dataType") === "date") {
									// format our date - the below function is not async
									app.context.dateService.getFormattedDate(ocObject.properties[attrName]).done(function(formattedDate) {
										replaceValue = formattedDate;
									});
								} else { // not a date type and not the objectName attr
									// use the value of the attribute from the obObject properties map
									replaceValue = ocObject.properties[attrName];
								}
							}

							// we've now populated our replaceValue variable with what we need so do the actual replacing of the token
							self.downloadName = self.downloadName.replace(new RegExp("[$]" + attrName + "[$]","g"), replaceValue);
						});
						
						// downloadName could be empty if none of the placeholders in the pattern have a corresponding value
						// in the ocObject. In that case just default to the object name (w/o the file extension)
						if(self.downloadName === "") {
							self.downloadName = objectNameMinusFileExt;
						}

						// add the file extension to the end of our downloadName (it was stripped off the objectName param)
						if(period !== -1) {
							self.downloadName += "." + fileExt;
						}
					} // end if a type pattern is defined for the download name
					
					if(self.instantExecute) {
						self.downloadDocument();
					} else {
						// done processing so turn off the loading spinner
						self.loading = false;
						self.render();
					}
				}); // end getAdminTypeConfig for object type of the current document
			}); // end fetch the OCO for the current document
		},
		afterRender: function(){
			this.toggleLoader(this.loading);
		},
        serialize: function() {
			return {
				modal: this.myHandler === HPIConstants.Handlers.ModalActionHandler,
				loading: this.loading
			};
        }
	});
	
	actionModules.registerAction("downloadDocument", DownloadDocument, {
		"actionId" : "downloadDocument",
		"label" : (window.localize("modules.actions.downloadDocument.downloadDocument")),
		"icon" : "download"
	});

	return DownloadDocument;
});
require(["downloaddocument"]);