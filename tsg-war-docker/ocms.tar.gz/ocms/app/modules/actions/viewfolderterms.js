define("viewfolderterms", [
        "app",
        "jquery",
        "modules/actions/actionmodules",
        "modules/common/actionservice",
        "modules/common/tossacross",
        "handlebars"
    ],

    function(app, $, actionModules, ActionService, TossAcross, Handlebars) {
        "use strict";

        var ViewFolderTerms = {};

        ViewFolderTerms.Model = Backbone.Model.extend({
            initialize: function(config, action) {
                this.config = config;
                this.action = action;
                this.handler = this.config.get("handler");
                this.folderId = app.context.container.id || "";
                this.set('dictionaries', this.config.attributes.selectedPicklists);
            }
        });

        ViewFolderTerms.View = Backbone.Layout.extend({
            template: "actions/viewfolderterms",
            events: {
                "click .vft-reindex-btn": "updateExistingJSON",
                "click .vft-picklist-heading-container": "showOrHidePicklist",
                "click .picklistTerm": "showViewAllDocsForTerm",
                "click .addTerm": "addPicklistTerm",
                "click .removeTerm": "removePicklistTerm"
            },
            initialize: function() {
                var self = this;
                this.action = this.options.action;
                this.config = this.options.config;

                this.myHandler = this.options.config.get("handler");
                this.model = new ViewFolderTerms.Model(this.config, this.action);

                // Empty array used later to push our views to render
                this.viewsToAdd = [];

                this.model.set("allTerms", []);

                // Getting our dictionaries/picklists and all of the unique terms from them
                // Then, we get the existing 'folderTerms' JSON from OC, or create it if it doesn't exist
                this.getDictionariesAndTerms().done(self.getOrCreateJSON());
            },
            getDictionariesAndTerms: function() {
                var self = this;

                // Our configured picklists
                var dictionaries = this.model.get("dictionaries");

                // An array of 'getPicklist' promises
                var promises = [];
                _.each(dictionaries, function(dictionary) {
                    var that = self;
                    var def = $.Deferred();
                    app.context.picklistService.getPicklist(dictionary.label, function(terms) {

                        // Don't use blank term values
                        terms = _.filter(terms, function(term) {
                            return term.label.length > 0;
                        });

                        // Don't allow duplicate terms
                        _.each(terms, function(term) {
                            if (that.model.get('allTerms').indexOf(term.label) === -1) {
                                that.model.get('allTerms').push(term.label);
                            }
                        });

                        // Creating a view for each picklist/dictionary
                        var currentPicklistView = new ViewFolderTerms.PicklistView({
                            "picklistName": dictionary.label,
                            "picklistTerms": terms
                        });

                        // Pushing that view on to our 'viewsToAdd'
                        that.viewsToAdd.push(currentPicklistView);

                        // Resolving the deferred.
                        def.resolve();
                    });
                    promises.push(def.promise());
                });

                // Return a promise that is resolved once all of our picklists have been fetched and processed
                return $.when.apply(undefined, promises).promise();
            },
            getOrCreateJSON: function() {
                var self = this;
                var params = this.action.get('parameters');
                // our current folder
                params.objectId = app.context.container.id;

                // our terms to search on
                params.terms = this.model.get('allTerms');

                // We are grabbing the existing JSON, or creating one if it doesn't exist
                params.mode = "getOrCreateJSON";

                this.action.set("parameters", params);

                // send the action to OC
                this.action.execute({
                    success: function(data) {
                        self._successFunc(data);
                    },
                    error: function() {
                        app.log.debug("View Folder Terms executed with an error");
                    }
                });
            },

            updateExistingJSON: function() {
                var self = this;
                var params = this.action.get('parameters');
                // our current folder
                params.objectId = app.context.container.id;

                // our terms to search on
                params.terms = this.model.get('allTerms');

                // we have clicked the "reindex" button so the FTS queries will be run again for all terms
                // and the new JSON object will be saved
                params.mode = "reindex";

                this.action.set("parameters", params);

                this.action.execute({
                    success: function(data) {
                        self._successFunc(data);
                    },
                    error: function() {
                        app.log.debug("View Folder Terms executed with an error");
                    }
                });
            },

            _successFunc: function(data) {
                var self = this;

                // now that we have our "data" we can render our previously set up views knowing that they
                // will have the data they need
                _.each(this.viewsToAdd, function(view) {
                    view.data = data;
                    self.insertView(".dictionaries-container", view).render();
                });
            },

            // Toggles entire picklist
            showOrHidePicklist: function(evt) {
                var currSelectedPicklist = evt.currentTarget.textContent.trim();
                $(evt.currentTarget).find('.vft-chevron').toggleClass("glyphicon-chevron-down glyphicon-chevron-up");
                // Replacing spaces and special chars w/ hyphens so class will work for templating
                currSelectedPicklist = currSelectedPicklist.trim();
                currSelectedPicklist = currSelectedPicklist.replace(/[`~!@#$%^&*()_|+\-=÷¿?;:'",.<>\{\}\[\]\\\/\s]/gi, '-');

                this.$el.find(".vft-all-terms-" + currSelectedPicklist).toggle();
            },

            // Launches the results for a term in VAD
            showViewAllDocsForTerm: function(evt) {
                var selectedTerm = evt.currentTarget.textContent || evt.currentTarget.nextElementSibling.textContent;
                var config;
                // Used to get the VAD config
                this.actionList = this.action.collection;
                for (var i = 0; i < this.actionList.configs.length; i++) {
                    if (this.actionList.configs[i].actionId === "viewAllDocuments") {
                        config = this.actionList.configs[i];
                    }
                }
                if (!config) {
                    app.log.error("View All Documents is not configured as an action on this trac");
                    return;
                }
                this.actionLauncher = new ActionService.ActionLauncher();
                window.localStorage.setItem('viewFolderTerms:lastFolderTermClicked', selectedTerm);
                this.actionLauncher.launchAction(this.actionList.findWhere({'name': "viewAllDocuments"}), config, true);
            }
        });

        ViewFolderTerms.PicklistView = Backbone.Layout.extend({
            template: "actions/viewfolderterms/picklistview",
            events: {
                "click .vft-accordion": "showAssociatedDocsDropdown"
            },
            initialize: function(options) {
                this.picklistName = options.picklistName;
                this.picklistTerms = options.picklistTerms;

                // hides terms that have 0 results
                Handlebars.registerHelper('hideTerm', this._hideTerm);

                // removes spaces so that templating works for terms with spaces
                Handlebars.registerHelper('removeSpacesFromTerms', this._removeSpacesFromTerms);
            },
            showAssociatedDocsDropdown: function(evt) {
                var selectedTerm = evt.currentTarget.textContent || evt.currentTarget.nextElementSibling.textContent;

                // get the associated OCOs
                var associatedDocs = this.data.result[selectedTerm];

                var associatedDocsListView = new ViewFolderTerms.TermsView({
                    "associatedDocs": associatedDocs,
                    "selectedTerm": selectedTerm
                });

                // Replacing spaces and special chars w/ hyphens so class will work for templating
                selectedTerm = selectedTerm.trim();
                selectedTerm = selectedTerm.replace(/[`~!@#$%^&*()_|+\-=÷¿?;:'",.<>\{\}\[\]\\\/\s]/gi, '-');

                this.$el.find(".vft-plus-minus-" + selectedTerm).toggleClass("glyphicon-plus glyphicon-minus");
                if (this.getView("#associated-doc-container-" + selectedTerm)) {
                    this.$el.find("#associated-doc-container-" + selectedTerm).toggle();
                    this.$el.find(".vft-term-text-container-" + selectedTerm).toggleClass('vft-activePicklist');
                } else {
                    this.insertView("#associated-doc-container-" + selectedTerm, associatedDocsListView).render();
                    this.$el.find(".vft-term-text-container-" + selectedTerm).addClass('vft-activePicklist');
                }
            },
            serialize: function() {
                var self = this;

                _.each(this.picklistTerms, function(term) {
                    if (self.data.result[term.label]) {
                        term.numberOfDocs = self.data.result[term.label].length;
                    } else {
                        term.numberOfDocs = 0;
                    }
                });

                // Sorting the terms based on most common
                this.picklistTerms = this.picklistTerms.sort(function(a, b) {
                    if (self.data.result[b.label] && self.data.result[a.label]) {
                        return self.data.result[b.label].length - self.data.result[a.label].length;
                    } else {
                        return 0;
                    }
                });

                return {
                    picklistName: this.picklistName,
                    picklistTerms: this.picklistTerms,
                    hidePicklist: !this._atLeastOneTermPopulated()
                };
            },
            _hideTerm: function() {
                if (this.numberOfDocs === 0) {
                    return "hidden";
                }
            },
            // Only show the picklist if there is at least one term that has 'associated docs'
            _atLeastOneTermPopulated: function() {
                var self = this;
                return _.some(this.picklistTerms, function(term) {
                    if (self.data.result[term.label] && self.data.result[term.label].length > 0) {
                        return true;
                    }
                });
            },
            _removeSpacesFromTerms: function(term) {
                term = term.trim();
                return term.replace(/[`~!@#$%^&*()_|+\-=÷¿?;:'",.<>\{\}\[\]\\\/\s]/gi, '-');
            },
            cleanup: function() {
                // Unregistering our helpers on cleanup
                Handlebars.unregisterHelper('hideTerm');
                Handlebars.unregisterHelper('removeSpacesFromTerms');
            }
        });

        ViewFolderTerms.TermsView = Backbone.Layout.extend({
            template: "actions/viewfolderterms/termsview",
            events: {
                "click .vft-doc-text": "openSelectedAssociatedDoc"
            },
            initialize: function(options) {
                this.associatedDocs = options.associatedDocs;
                this.selectedTerm = options.selectedTerm;
            },
            openSelectedAssociatedDoc: function(evt) {
                // setting the term associated with the clicked 
                window.localStorage.setItem('openAnnotateSearchValue', this.selectedTerm);

                var selectedDoc = evt.currentTarget.id;
                if (selectedDoc) {
                    app.trigger("stage.refresh.documentId", selectedDoc);
                    app.trigger("stage.refresh.showPane3", true);
                    app.trigger("toggleLeftBar", false);
                    this.paneSize = "rightPane";
                }
            },
            serialize: function() {
                return {
                    associatedDocs: this.associatedDocs
                };
            }
        });

        ViewFolderTerms.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/viewfoldertermsconfig",
            initialize: function() {
                var self = this;

                if (!this.viewModel.availablePicklists || !this.viewModel.selectedPicklists) {
                    this.viewModel.availablePicklists = new Backbone.Collection();
                    this.viewModel.selectedPicklists = new Backbone.Collection();
                } else if (this.viewModel.availablePicklists instanceof Backbone.Collection === false) {
                    this.viewModel.availablePicklists = new Backbone.Collection(this.viewModel.availablePicklists());
                    this.viewModel.selectedPicklists = new Backbone.Collection(this.viewModel.selectedPicklists());
                }

                if (!this.viewModel.model().get("selectedPicklists")) {
                    this.viewModel.model().set("selectedPicklists", []);
                }

                $.when(app.context.configService.getPicklistServices()).done(function() {
                    _.each(app.context.currentPicklistConfig().get("picklists").models, function(picklist) {
                        // If there is a new picklist in the config, it won't be in either collection, so we need 
                        // to add it to the 'availablePicklists'
                        if (!_.contains(self.viewModel.availablePicklists.pluck('label'), picklist.get('label')) &&
                            !_.contains(self.viewModel.selectedPicklists.pluck('label'), picklist.get('label'))) {
                            self.viewModel.availablePicklists.push({
                                'label': picklist.get("label"),
                                'value': picklist.get("ocName")
                            });
                        }
                    });
                    self.buildPicklistTossAcross();
                });
            },
            buildPicklistTossAcross: function() {
                var picklistTossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: true,
                    srcCollection: {
                        title: 'Available Picklists',
                        filter: true,
                        labelAttr: 'label',
                        valueAttr: 'ocName',
                        collection: this.viewModel.availablePicklists
                    },
                    targetCollections: [{
                        title: 'Selected Picklists',
                        labelAttr: 'label',
                        valueAttr: 'ocName',
                        collection: this.viewModel.selectedPicklists
                    }]
                });
                this.setView(".picklist-toss-across", picklistTossAcross).render();
            },
            afterRender: function() {
                var self = this;
                this.stopListening(this.viewModel.selectedPicklists, 'add remove reset');
                this.stopListening(this.viewModel.availablePicklists, 'add remove reset');

                this.listenTo(this.viewModel.selectedPicklists, 'add remove reset', function() {
                    self.viewModel.model().set("selectedPicklists", _.extend([], self.viewModel.selectedPicklists.toArray()));
                    self.viewModel.model().set("availablePicklists", _.extend([], self.viewModel.availablePicklists.toArray()));
                }, this);

                kb.applyBindings(this.options.viewModel, this.$el[0]);
            }
        });

        actionModules.registerAction("viewFolderTerms", ViewFolderTerms, {
            "actionId": "viewFolderTerms",
            "label": "View Folder Terms",
            "icon": "book",
            "handler": "rightSideActionHandler",
            "paneSize": "fullPane"
        });

        return ViewFolderTerms;
    });
require(["viewfolderterms"]);