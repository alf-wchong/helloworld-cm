//Operations Tech Transfer module
define("getdocumentlink",[
    //Application
    "app",
    "modules/actions/actionmodules",
    "oc",
    "module"
],
function(app, actionModules, OC, module) {
    var GetDocumentLink = {};

    GetDocumentLink.View = Backbone.Layout.extend({
        template: "actions/getdocumentlink",
        initialize: function() {
            var self = this;

			//set variables  depending on whether link/shortLink are enabled or disabled
            this.shortLinkEnabled = self.options.config.get("shortLinkEnabled");
            this.linkEnabled = self.options.config.get("linkEnabled");

            // Set the variables received in the options parameters onto this view for easy access.
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");

            // Get an OpenContentObject using the objectId of the object triggering this action.
            this.objectId = this.options.action.get("parameters").objectId;
            this.oco = new OC.OpenContentObject({ objectId : this.objectId });

			//set up deferreds so that we dont try to display the link before we get
			//all needed data from OC and generate the links
            var deferreds = [];
            if(this.linkEnabled === "true"){  
                var defLink = $.Deferred();
                deferreds.push(defLink);
                this.getLink(defLink);
            }
                       
            if(this.shortLinkEnabled === "true"){
                var defShort = $.Deferred();
                deferreds.push(defShort);
                this.getShortLink(defShort);
            }
            
			//once we have the links, we can generate our results- 
			//and render our view
            $.when.apply(self, deferreds).done(function(){
                self.generateResults();
            });
           
        },
        generateResults: function() {
            var self = this;
            // Pass our information to render our results view.
			// note: some values are undefined at this point
            self.setView("#getdoclink-outlet", new GetDocumentLink.Results({
                url: self.url,
                shortLinkEnabled: this.shortLinkEnabled,
                linkEnabled: this.linkEnabled,
                shortUrl: self.shortUrl,
                longError: self.longError, 
                shortError: self.shortError
            })).render();
            self.toggleLoader(false);
        },
        getLink: function(defLink) {
            var self = this; 
            this.toggleLoader(true);
            // We're just going to query OC with this object, so we can grab the chronId from the object. 
             this.oco.fetch({
                success: function(object) {
                    // Set this view with the properties required to build the results view below.
                    self.object = object;
                    self.documentNumber = self.object.get("properties").objectId;
                    // Here we will build our link so that this document has a direct URL to its streamed content. We will build a link
                    // based on the object's configured attribute/value combinations for a certain object type in the case this is configured
                    // and enabled in the action. Otherwise, we will simply use the object's id to build this.
                    if(self.options.config.get("queryParamsEnabled") === "true") {
                        self.generateQueryParamsUrl();
                        self.toggleLoader(false);
                    } else {
                        self.generateIdUrl();
                        self.toggleLoader(false);
                    }      
                    defLink.resolve();      
                }, 
                error: function(jqXHR, textStatus, errorThrown) {
                    //error generating permanent link, resolve deferred and set longError
					self.toggleLoader(false);
                    self.longError = "Error Generating url: " + errorThrown;
                    defLink.resolve();
                }
            });
        },
        getShortLink: function(defShort) {
            var self = this;
            self.toggleLoader(true);
            //send license data to OC REST endpoint and get back success or failure
            $.ajax({
                url: app.serviceUrlRoot + "/getShortLink",
                data: {
                    objectId: this.oco.id
                },
                type: "POST",
                success: function(shortUrl) {               
                    //set shortUrl on our model
                    self.shortUrl = shortUrl;
                    
                    self.toggleLoader(false);

                    defShort.resolve();
                    
                },
                error: function(jqXHR, textStatus, errorThrown) {
					//error generating short link, resolve deferred and set shortError
                    self.toggleLoader(false);
                    self.shortError = "Error Generating url: " + errorThrown;
                    defShort.resolve();
                },
                async: false
            });
        },
        toggleLoader: function(bool) {
            app[this.myHandler].trigger("loading", bool);
        },
        generateIdUrl: function() {
            // Seek to fetch the objects chronicleId, but if not found simply use the regular objectId.
            var id = (this.object.get("properties").chronicleId) ? this.object.get("properties").chronicleId : this.object.get("properties").objectId;
            
            // Set the origin of the URL, some sort of "http://localhost:8080" format.
            var origin = window.location.origin;
            if(!origin) {
                origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
            }
            // Let's ensure that the value for app.root is equal to '/hpi/'.
            var hpiRoot = (app.root === '/hpi') ? '/hpi/' : app.root;

            // Construct the remaining of the URL making sure to specify the viewOnly router.
            this.url = origin + hpiRoot + "viewOnly/" + id;
        },
        generateQueryParamsUrl: function() {
            // Holds our attributes that will serve as query parameters in the form of a string URL. This will be parsed by our special
            // viewOnlyQuery router to fetch the correct object based on these parameters.
            var paramsQuery = '';

            // Use the objectType that has been configured for this action's attribute parameters to add it to the URL before
            // we get around the other properties. This is required for OC to be able to execute its query in the SolrSchemalessImpl.
            var objectType = {
                paramName: this.options.config.get("selectedDocumentType"),
                paramValue: this.options.config.get("selectedDocumentType"),
                paramType: 'type'
            };

            paramsQuery = $.param(objectType); 
            _.each(this.options.config.get("linkCriteria"), function(item) {
                // Set the value we want to query for.
                var paramValue = item.value;
                // Check if this parameter is tokenized. If so, resolve it now to retrieve tha value we require.
                var objectValueAttrName = this.resolveValueToken(item.value);
                if(objectValueAttrName) {
                    paramValue = this.object.get("properties")[objectValueAttrName];
                }

                var sp = {
                    // The attribute's name that we're searching on.
                    paramName: item.attribute,
                    // The desired value of the attribute defined above.
                    paramValue: paramValue,
                    // This is a property attribute and we want to find an object who's value equals this one.
                    paramType: "property",
                    operator: "OPERATOR_EQUALS"
                };
                paramsQuery = paramsQuery + "/" + $.param(sp);
            }, this);
            
            // Set the origin of the URL, some sort of "http://localhost:8080" format.
            var origin = window.location.origin;
            if(!origin) {
                origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '');
            }
            // Let's ensure that the value for app.root is equal to '/hpi/'.
            var hpiRoot = (app.root === '/hpi') ? '/hpi/' : app.root;

            // Construct the remaining of the URL making sure to specify the viewOnly router.
            this.url = origin + hpiRoot + "viewOnlyQuery/" + paramsQuery;
        },
        resolveValueToken: function(valueToken) {
            // Regex that we will use to make sure this valueToken is properly formatted.
            var regex = /[$](.+)[$]\s*/g;

            // Check that we have a regex match against our provided token.
            if(valueToken.search(regex) !== -1) {
                // Let's return what's inside of the surrounding dollar signs from this valueToken.
                return regex.exec(valueToken)[1];
            }
        }
    });

    GetDocumentLink.Results = Backbone.Layout.extend({
        template: "actions/getdocumentlink-results",

        initialize: function(options) {
			//each of these values will be a string or undefined
            this.shortError = options.shortError;
            this.longError = options.longError;
            this.url = options.url;
            this.shortUrl = options.shortUrl;
            //these are either "true" or "false"
            this.shortLinkEnabled = options.shortLinkEnabled;
            this.linkEnabled = options.linkEnabled;
        },
        afterRender: function() {
            var self = this;
            $("#getDocLink").on("click", function() {
                $(this).select();
            });
            $("#copyPermLink").on("click", function() {
                var textToCopy = $("#getDocLink").val();
                $("#getDocLink").select();
                try {
                    if(!document.execCommand("copy", true, textToCopy)) {
                        self.renderWarning();
                    }
                } catch(err) {
                    self.renderWarning();
                }

            });

			// select the short link if you click on it
            $("#getDocShortLink").on("click", function() {
                $(this).select();
            });
	
			// copy the short link if you click the copy button 
            $("#copyShortLink").on("click", function() {
                var textToCopy = $("#getDocShortLink").val();
                $("#getDocShortLink").select();
                try {
                    if(!document.execCommand("copy", true, textToCopy)) {
                        self.renderWarning();
                    }
                } catch(err) {
                    self.renderWarning();
                }

            });
        },
        serialize: function() {
            return {
                //these are undefined or set to the correct url or set to the correct error string
                url: this.url,
                longError: this.longError,
                shortUrl: this.shortUrl,
                shortError: this.shortError,
                
                neitherConfigured: (this.linkEnabled === "false") && (this.shortLinkEnabled === "false")
            };
        }
    });

    GetDocumentLink.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/getdocumentlinkconfig",
        events: {
            'click #addLinkCriteria' : 'addLinkCriteria',
            'click .removeLinkCriteria' : 'removeLinkCriteria',
            'click #enableQueryParameters' : 'showQueryParamsConfig',
            'click #disableQueryParameters' : 'hideQueryParamsConfig',
            'click #enableLink' : 'showEnableQueryParams',
            'click #disableLink' : 'hideEnableQueryParams',
            'change .getdocumentlink-object-type' : 'changeObjectType',
            'change .getdocumentlink-criteria-attr' : 'changeCriteria'
        },
        
        initialize: function() {
           // var self = this;

            // The viewModel through which we will tie all knockout/knockback variables used.
            var viewModel = this.viewModel;
            var model = viewModel.model();

            // Toggle that allows the user to activate or deactivate a link configuration using attributes as query parameters.
            viewModel.queryParamsEnabled = kb.observable(model, "queryParamsEnabled");

            // Toggle that allows the user to activate or deactivate short link creation.
            viewModel.shortLinkEnabled = kb.observable(model, "shortLinkEnabled");

            // Toggle that allows the user to activate or deactivate short link creation.
            viewModel.linkEnabled = kb.observable(model, "linkEnabled");

            // Initialize the link criteria for this configuration.
            viewModel.linkCriteria = kb.observable(model, "linkCriteria");

            // Holds all of the available object types in the application.
            viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
            // Populate the observable with the object types in our application config.
            app.context.configService.getAdminOTC(function (config) {
                config.get("configs").each(function (typeConfig) {
                    if (typeConfig.get("isContainer") === "false") {
                        viewModel.availableDocumentTypesInConfig.push({
                            "label": typeConfig.get("label"),
                            "value": typeConfig.get("ocName")
                        });
                    }
                });
            });

            /// Holds the selected object type in this view's configuration. This variable determines the attributes that will be available for configuration.
            viewModel.selectedDocumentType = kb.observable(model, "selectedDocumentType");

            if(_.isEmpty(model.get("selectedDocumentType"))) { 
                if(viewModel.availableDocumentTypesInConfig().length > 0){
                    // If it's empty due to the initial set up of the action, select the first of the available document types.
                    viewModel.selectedDocumentType(viewModel.availableDocumentTypesInConfig()[0].value);
                
                    // Give our criteria a new line for the user to pick attributes from.
                    viewModel.linkCriteria([{attribute: "", value:""}]);

                    viewModel.queryParamsEnabled("false");

                    viewModel.shortLinkEnabled("false");

                    viewModel.linkEnabled("false");
                }
            }
      },

      showQueryParamsConfig: function() {
        $(".hiddenQueryParamsConfig").show("fast");
      },

      hideQueryParamsConfig: function() {
        $(".hiddenQueryParamsConfig").hide("fast");
      },

      showEnableQueryParams: function() {
        $(".hiddenEnableQueryParams").show("fast");
        if(this.viewModel.model().get("queryParamsEnabled") === "true"){
            this.showQueryParamsConfig();
        }
      },

      hideEnableQueryParams: function() {
        this.hideQueryParamsConfig();
        $(".hiddenEnableQueryParams").hide("fast");
      },

       addLinkCriteria: function() {
            var viewModel = this.viewModel;
            var model = viewModel.model();

            var addArray = [];

            addArray = model.get("linkCriteria").splice(0);

            addArray.push({attribute: "", value:""});
            viewModel.linkCriteria(addArray);

            this.renderLinkCriteriaAttrs();
        },

        removeLinkCriteria: function(e) {
            var viewModel = this.viewModel;
            var model = viewModel.model();

            // Get id and remove this criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('remove-documentlink-', ''));

            var removeArray = [];
            // Remove the item at the specified index.
            removeArray = model.get("linkCriteria").splice(0);
            removeArray.splice(index, 1);

            viewModel.linkCriteria(removeArray);

            this.renderLinkCriteriaAttrs();
        },

        changeCriteria: function(e){
            //Get id and update the correct criteria.
            var index = Number(this.$(e.currentTarget).attr('id').replace('getdocumentlink-criteria-attr-', ''));
            var criteriaAttr = this.$(e.currentTarget).val();
            this.viewModel.linkCriteria()[index].attribute = criteriaAttr;
        },

        renderLinkCriteriaAttrs: function(){
            var self = this;

            // Careful here, send the ocName, not the label.
            var ocName = this.viewModel.selectedDocumentType();
            app.context.configService.getAdminTypeConfig(ocName, function(otc) {
                // Update all attributes - clear any existing ones.
                self.allAttrs = self.allAttrs ? self.allAttrs.reset() : new Backbone.Collection();
                self.allAttrs.reset(otc.get("attrs").models);
            }, this);

            // Get the attributes that are set to on this configuration model.
            var linkCriteriaAttrs = this.$('.getdocumentlink-criteria-attr');
            // Update all criteria attributes - clear any existing ones.
            linkCriteriaAttrs.empty();
            linkCriteriaAttrs.append($("<option></option>")
                       .attr("disabled", "disabled")
                       .attr("selected", "selected"));
            // Render object types using all the attributes that were extracted from our selected object type.
            this.allAttrs.each(function(type){
                linkCriteriaAttrs.append($("<option></option>")
                                .attr('value', type.get('ocName'))
                                .text(type.get('label'))); 
            });

            // Loop through each of the criteria combinations that are on the DOM and that should match our observable.
            // Set each criteria's currently selected attribute value on the DOM.
            _.each(linkCriteriaAttrs, function(el, index){
                this.$(el).val(self.viewModel.model().get("linkCriteria")[index].attribute);
            }, this);
        },

        changeObjectType: function () {
            // Reset criteria attributes after a type change to an empty criteria.
            this.viewModel.linkCriteria([{attribute: "", value:""}]);

            // Update the DOM to reflect the changes pushed to the linkCriteria here.
            this.renderLinkCriteriaAttrs();
        },

        afterRender: function() {
            // Apply the model-data bindings used by our knockout/knockback observables on the DOM.
            ko.applyBindings(this.options.viewModel, this.$el[0]);

            if(this.viewModel.model().get("linkEnabled") === "true") {
                this.viewModel.linkEnabled("true");
                this.showEnableQueryParams();

                if(this.viewModel.model().get("queryParamsEnabled") === "true") {
                    this.viewModel.queryParamsEnabled("true");
                    this.showQueryParamsConfig();
                } else {
                    this.viewModel.queryParamsEnabled("false");
                    this.hideQueryParamsConfig();
                }
            }else if(this.viewModel.model().get("linkEnabled") === "false") {
                this.viewModel.linkEnabled("false");
                this.hideEnableQueryParams();
                this.hideQueryParamsConfig();
            }  
			else {
                this.viewModel.linkEnabled("true");
                this.showEnableQueryParams();
                this.hideQueryParamsConfig();
            } 

            if(this.viewModel.model().get("shortLinkEnabled") === "true") {
                this.viewModel.shortLinkEnabled("true");
            } else {
                this.viewModel.shortLinkEnabled("false");
            }

            // Now that our view has been rendered, we are able to target every aspect of our DOM, so let's render the 
            // criteria's attribute values for the selectedDocumentType on the configuration.
            this.renderLinkCriteriaAttrs();

        },
        serialize: function() {
            return {
                shortLinkDisabled: module.config().disableShortLink ? module.config().disableShortLink : false
            };
        }

    });

    actionModules.registerAction("getDocumentLink", GetDocumentLink, {
        "actionId": "getDocumentLink",
        "label": (window.localize("modules.actions.getDocumentLink.getDocLink")),
        "icon": "globe",
        "groups" : ["wizard", "get", "documentLink"]
    });

    return GetDocumentLink;

}); 
require(["getdocumentlink"]);