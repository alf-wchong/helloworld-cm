define("cancelworkflow", [
	//Application
	"app",
	"modules/actions/actionmodules",
	"modules/common/action",
	"modules/common/workflowutil",
	"foldernotes",
	"ckeditorcore"
],

	function (app, actionModules, Action, WorkflowUtil, FolderNotes) {
		"use strict";

		//Start with declaring your id - this is the same value as in the filename between the words action. and .js
		//get the config from the namespace. The action handler is responsible for this; //
		var action = {};

		action.View = Backbone.Layout.extend({
			template: "actions/cancelworkflow",
			events: {
				"click #btn-cancelWorkflow": "cancelWorkflow"
			},
			initialize: function () {
				this.action = this.options.action;
				this.action.get("parameters").auditEvent = this.config.get("auditEvent") === "true" ? true : false;
				this.myHandler = this.options.config.get("handler");
				this.toggleLoader = function (bool) {
					app[this.myHandler].trigger("loading", bool);
				};

				this.folderNoteRequired = this.options.config.get("folderNoteRequired");
				this.integrateFolderNotes = this.options.config.get("integrateFolderNotes");
				this.folderNoteObjectType = this.options.config.get("folderNoteObjectType");
				this.folderNoteRelationship = this.options.config.get("folderNoteRelationship");
				this.folderNoteType = this.options.config.get("folderNoteType");

				//Clean up logic
				this.folderNoteRequired = ((this.folderNoteRequired === "true" || this.folderNoteRequired === true) ? true : false);
				this.integrateFolderNotes = ((this.integrateFolderNotes === "true" || this.integrateFolderNotes === true) ? true : false);
			
				if (this.options.config.get("attrToShow")) {
				    this.attrToShow = this.config.get("attrToShow");
                }
			},
			cancelWorkflow: function () {
				var self = this;
				var objectId = this.action.get("parameters").objectId;

				if (objectId === undefined) {
					app[this.myHandler].trigger("showError", (window.localize("modules.actions.cancelWorkflow.unableToCancel")));
				} else {
					this.toggleLoader(true);

					// If there are folder notes, add them in the params.
					if (this.integrateFolderNotes) {
						this.action.get("parameters").folderNote = CKEDITOR.instances.cancelWorkflowNoteContent.getData();
					}

					this.action.execute({
						success: function (data) {
							self.toggleLoader(false);


							if (data) {
								app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.cancelWorkflow.workflowSuccessfully")));
							}

							app.listenToOnce(app[self.myHandler], "hide", function () {
								app.trigger("stage.refresh.bothIds", true, true);
							});


						},
						error: function (jqXHR, textStatus, errorThrown) {
							self.toggleLoader(false);
							app[self.myHandler].trigger("showError", (window.localize("modules.actions.cancelWorkflow.failedToCancel")) +
								jqXHR.status + " " + jqXHR.statusText);
						}
					});

					if (this.integrateFolderNotes) {
						var note_content = CKEDITOR.instances.cancelWorkflowNoteContent.getData();
                        if (note_content.length > 0) {
                            //Creating the folder notes action with the proper parameters
                            FolderNotes.Service.execute({
                                parameters: {
                                    parentID: app.context.container.get("objectId"),
                                    note_content: note_content,
                                    note_rel_type: this.folderNoteRelationship,
                                    note_object_type: this.folderNoteObjectType,
                                    property_map: {
                                        note_type: this.folderNoteType,
                                        note_attachment: [app.context.document.get("objectId")]
                                    }
                                }
                            });
                        }
					}
				}
			},
			afterRender: function () {
				var self = this;
				
				this.setView("#workflowOwnerOutlet", new WorkflowUtil.View({
					"objectId": app.context.document.get("objectId"),
					"attrToShow" : self.attrToShow
				})).render();

				var ckeditorSize;
				if (this.myHandler === "rightSideActionHandler") {
					ckeditorSize = 400;
				} else {
					//myHandler is modal
					ckeditorSize = 100;
				}

				//deploy folder note ckeditor of configured
				if (this.integrateFolderNotes && CKEDITOR.instances.cancelWorkflowNoteContent === undefined) {
					CKEDITOR.replace('cancelWorkflowNoteContent', {
						toolbar: "HPIMinimal",
						disableNativeSpellChecker: false,
						height: ckeditorSize
					}, '');

					if (this.folderNoteRequired) {
						//create a keyup event on the ckeditor textbox so we can check to make sure there is content
						CKEDITOR.instances.cancelWorkflowNoteContent.on('contentDom', function () {
							var editable = CKEDITOR.instances.cancelWorkflowNoteContent.editable();
							editable.attachListener(CKEDITOR.instances.cancelWorkflowNoteContent.document, 'keyup', function () {
								if (CKEDITOR.instances.cancelWorkflowNoteContent.getData().length > 0) {
									$('#cancelWorkflowBtn').attr('disabled', false);
								} else {
									$('#cancelWorkflowBtn').attr('disabled', true);
								}
							});
						});
					}
				}

				//If folder notes is not enabled, hide it.
				if (!this.integrateFolderNotes) {
					this.toggleFolderNoteArea();
				}

				if (this.integrateFolderNotes === true && this.folderNoteRequired === true) {
					$('#cancelWorkflowBtn').attr('disabled', true);
				} else {
					$('#cancelWorkflowBtn').attr('disabled', false);
				}
			},
			toggleFolderNoteArea: function () {
				$("#cancelWorkflowNoteContentDiv").toggle();
			},
			cleanup: function () {
				try {
					//remove this instance of CKEDITOR from the global registry
					//of CKEDITOR.instances to prevent memory leaks
					if (CKEDITOR.instances.cancelWorkflowNoteContent) {
						CKEDITOR.instances.cancelWorkflowNoteContent.destroy(true);
						delete CKEDITOR.instances.cancelWorkflowNoteContent;
					}
				} catch (e) { }
			},
			serialize: function () {
				var modal = false;
				var rightSide = false;
				if (this.myHandler === "modalActionHandler") {
					modal = true;
				} else if (this.myHandler === "rightSideActionHandler") {
					rightSide = true;
				}
				return {
					modal: modal,
					rightSide: rightSide,
					integrateFolderNotes: this.integrateFolderNotes,
					folderNoteRequired: this.folderNoteRequired
				};
			}

		});

		action.CustomConfigView = Backbone.Layout.extend({
			template: "hpiadmin/actions/customconfig/cancelworkflowconfig",
			initialize: function () {
				var viewModel = this.options.viewModel;
				var model = viewModel.model();
				viewModel.auditEvent = kb.observable(model, "auditEvent");

				//whether or not to create a Folder Note after document upload
				if (!viewModel.model().integrateFolderNotes) {
					viewModel.model().integrateFolderNotes = false;
				}
				viewModel.integrateFolderNotes = kb.observable(viewModel.model(), "integrateFolderNotes");

				//whether or not to create a Folder Note after document upload
				if (!viewModel.model().folderNoteRequired) {
					viewModel.model().folderNoteRequired = false;
				}
				viewModel.folderNoteRequired = kb.observable(viewModel.model(), "folderNoteRequired");

				//Is folder notes integration enabled
				if (viewModel.integrateFolderNotes() === "false") {
					viewModel.folderNoteType(false);
				}

				// selected folder note type from the admin
				viewModel.folderNoteObjectType = kb.observable(viewModel.model(), "folderNoteObjectType");
				if (!viewModel.folderNoteObjectType()) {
					viewModel.folderNoteObjectType("HPI Note");
				}
				// note type to apply to all folder notes
				viewModel.folderNoteType = kb.observable(viewModel.model(), "folderNoteType");
				if (!viewModel.folderNoteType()) {
					viewModel.folderNoteType("Workflow Note");
				}
				//selected folder note relationship from admin
				viewModel.folderNoteRelationship = kb.observable(viewModel.model(), "folderNoteRelationship");
				
				// Attribute to use as document display name
                viewModel.attrToShow = kb.observable(viewModel.model(), "attrToShow");
			},
			afterRender: function () {
				kb.applyBindings(this.options.viewModel, this.$el[0]);
			}
		});

		actionModules.registerAction("cancelWorkflow", action, {
			"actionId": "cancelWorkflow",
			"label": (window.localize("modules.actions.cancelWorkflow.cancelWorkflow")),
			"icon": "remove-sign"
		});

		actionModules.registerAction("cancelWizardWorkflow", action, {
			"actionId": "cancelWizardWorkflow",
			"label": (window.localize("modules.actions.cancelWorkflow.cancelWizardWorkflow")),
			"icon": "remove-sign"
		});

		return action;

	});
require(["cancelworkflow"]);