//Advancedsearch module
define("performperiodicreview",[
	//Application
	"app",
	"modules/actions/actionmodules"
],

function(app, actionModules) {


	var docNumberProp = "tsg_documentNumber";

	var PerformPeriodicReview = {};

	PerformPeriodicReview.Model = Backbone.Model.extend({
		defaults: {
			userName: "",
			password: "",
			periodicReviewAccept: "",
			periodicReviewComment: "",
            slider: ""
		},
		initialize: function(options) {
			this.options = _.defaults(options,this.defaults);
		}
	});

 	PerformPeriodicReview.View = Backbone.Layout.extend({
        template: "actions/performperiodicreview",
        events : {
        	"click #periodicReviewSubmitBtn" : "completePeriodicReview",
        	"keyup #periodic-review-username" : "updateUserName",
        	"keyup #periodic-review-password" : "updatePassword",
        	"keyup #periodic-review-reject" : "updatePeriodicReviewComment",
            "click #enable" : "updateCompletionTypeApprove",
            "click #disable" : "updateCompletionTypeReject"
        },
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            // constructs with a model for unit testing purposes in productions will always pass empty object.
			this.model = new PerformPeriodicReview.Model(this.options.model || {});
        },
        afterRender: function() {
        	var self = this;

        	TSG.services.ajaxService.getObjectProperties(
        		this.action.get("parameters").objectId, function(obj) {
					self.$('#periodic-review-candidate-name-output').html(obj.properties[docNumberProp]);
				}
			);
            // trigger an AJAX call when a user opens this action to grab the taskId for the task
            // that is attempting to be completed
            $.ajax({
                url: app.serviceUrlRoot + "/workflow/getTasksForUserByContent",
                data: {
                    objectId: self.action.get("parameters").objectId,
                    userLoginName: app.user.id
                },
                success: function(tasks) {

                    if (tasks.length<1) {
                        $("#" + self.myHandler + "-error").html(window.localize("modules.actions.performPeriodicReview.thisIsAn")).show();
                        setTimeout(function(){
                            $("#" + self.myHandler + "-error").hide();
                        }, 6000);
                    }
                    else {
                        // what task the user is attempting to complete
                        self.action.get("parameters").taskId = tasks[0].id;
                    }
                }
            });
            $('#periodicReviewCommentsBox').hide();
        },
        completePeriodicReview: function() {   

            $('#periodicReviewSubmitBtn').prop('disabled', true);

           var self = this;
           var action = this.action;
           var myHandler = this.myHandler;

            if (this.model.get("slider") == "approve") {
                action.get("parameters").completionType = "approve";
            }
            else {
                action.get("parameters").completionType = "reject";
            }

           var opts = {
            type:   "POST",
            contentType:    "application/json",
            url:    app.serviceUrlRoot + "/authentication/newSession?username=" + self.model.get("userName"),
            data: JSON.stringify(self.model.get("password")),
                    // success call
                    success: function(result){
                        if(result){
                            //we got a valid ticket
                            // setting up the parameters to be sent to the backend.
                            action.get("parameters").periodicReviewComment = self.model.get("periodicReviewComment");
                            action.get("parameters").periodicReviewAccept = self.model.get("periodicReviewAccept");
                            action.get("parameters").userName = self.model.get("userName");
                            action.get("parameters").password = self.model.get("password");

                            action.execute({
                                success : function(data) {
                                    if (action.get("parameters").completionType == "reject") {
                                       app[myHandler].trigger("showMessage", window.localize("modules.actions.performPeriodicReview.thisDocumentNeeds"));
                                    }
                                    else {
                                        app[myHandler].trigger("showMessage", window.localize("modules.actions.performPeriodicReview.thisDocumentHas"));
                                    }    
                                    app.listenToOnce(app[myHandler], "hide", function() {
                                    app.trigger("stage.refresh.documentId", action.get("parameters").objectId);
                                });                         
                                },
                                error : function(jqXHR, textStatus, errorThrown) {
                                    $("#" + self.myHandler + "-error").html(window.localize("modules.actions.performPeriodicReview.errorPerforming")).show();
                                    setTimeout(function(){
                                       $("#" + self.myHandler + "-error").hide();
                                    }, 6000);
                                }
                            });
                        }
                     },
                    // error call
                    error: function(jqXHR, textStatus, errorThrown){
                        if(jqXHR.status != 401) {
                            $("#" + self.myHandler + "-error").html(window.localize("modules.actions.performPeriodicReview.errorDuring")).show();
                            setTimeout(function(){
                                $("#" + self.myHandler + "-error").hide();
                             }, 6000);
                        }
                    },
                        //override default to go to login screen on login failure
                    statusCode: {
                         401: function(jqXHR, textStatus, errorThrown){
                             $("#" + self.myHandler + "-error").html(window.localize("modules.actions.performPeriodicReview.authenticationFailed")).show();
                             setTimeout(function(){
                                 $("#" + self.myHandler + "-error").hide();
                            }, 6000);
                        }
                    }
                };

                if(self.model.get("periodicReviewComment") && this.action.get("parameters").completionType == "reject") {
                    $.ajax(opts);
                }
                else if(self.model.get("periodicReviewAccept") && this.action.get("parameters").completionType  == "approve") {
                    $.ajax(opts);
                }
                else {
                    $("#" + self.myHandler + "-error").html("One or more fields are invalid.").show();
                    setTimeout(function(){
                        $("#" + self.myHandler + "-error").hide();
                    }, 6000);
                }
            $('#periodicReviewSubmitBtn').prop('disabled', !self.validate());
        },
        validate: function() {
            var self = this;
            // script to control the accept and reject buttons
            if (this.model.get("userName") !== app.user.get("loginName")) {
                return false;
            }
            else if (self.model.get("userName") && self.model.get("password")) {
                if (self.model.get("periodicReviewAccept") && (self.model.get("slider") === "approve")) {
                    return true;
                }
                else if ((self.model.get("slider") === "reject") && self.model.get("periodicReviewComment")) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        },
        updateCompletionTypeApprove: function() {
            this.model.set("slider", "approve");
            this.model.set("periodicReviewAccept", true);
            //Add or remove css classes based on slider position
            $('#approve-status-slider-element').addClass("slide-button green");
            $('#enableTitle').addClass("approve-status-element-white");
            $('#disableTitle').addClass("approve-status-element-black");

            $('#approve-status-slider-element').removeClass("red");
            $('#enableTitle').removeClass("approve-status-element-black");
            $('#disableTitle').removeClass("approve-status-element-white");

            $('#periodicReviewCommentsBox').hide();
            
            $('#periodicReviewSubmitBtn').prop('disabled', !this.validate());
        },
        updateCompletionTypeReject: function() {
            this.model.set("slider", "reject");
            this.model.set("periodicReviewAccept", false);
            //Add or remove css classes based on slider position
            $('#approve-status-slider-element').addClass("slide-button red");
            $('#enableTitle').addClass("approve-status-element-black");
            $('#disableTitle').addClass("approve-status-element-white");

            $('#approve-status-slider-element').removeClass("green");
            $('#enableTitle').removeClass("approve-status-element-white");
            $('#disableTitle').removeClass("approve-status-element-black");

            $('#periodicReviewCommentsBox').show();

            $('#periodicReviewSubmitBtn').prop('disabled', !this.validate());
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        },
        updateUserName: _.throttle(function(evt) {
        		this.model.set("userName", $('#periodic-review-username').val());
                $('#periodicReviewSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this),
        updatePassword: _.throttle(function(evt) {
        		this.model.set("password", $('#periodic-review-password').val());
                $('#periodicReviewSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this),
        updatePeriodicReviewComment: _.throttle(function(evt) {
        		this.model.set("periodicReviewComment", $('#periodic-review-reject').val());
                $('#periodicReviewSubmitBtn').prop('disabled', !this.validate());
        	}, 250, this)
        
    });

 	actionModules.registerAction("performPeriodicReview", PerformPeriodicReview, {
        "actionId" : "performPeriodicReview",
        "label" : (window.localize("modules.actions.performPeriodicReview.performPeriodicReview")),
        "icon" : "refresh",
        "groups" : ["wizard", "perform", "periodicReview"]
    });
    
	return PerformPeriodicReview;
	
});
require(["performperiodicreview"]);