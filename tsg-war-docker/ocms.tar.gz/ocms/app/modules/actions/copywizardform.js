define("copywizardform",[
    "app",
    "oc",
    "modules/actions/actionmodules",
    "URIjs/URI",
    "module"
  ],
  
function(app, OC, actionModules, URI, module) {
    "use strict";

    var CopyWizardForm = {};

    CopyWizardForm.View = Backbone.Layout.extend({
		template: "actions/copywizardform",
        events: {
            "click #copyform-continue-btn" : "onClickCopyWizardForm"
        },
		initialize: function() {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            var doc = new OC.OpenContentObject();
            doc.id = this.action.get("parameters").objectId;
            this.relationName = this.options.config.get('relationName') || "aw:relatedTo";
        },
        serialize:function(){
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        },
        onClickCopyWizardForm: function(){
            var self = this;

            self.action.get("parameters").parentPsiId = app.context.container.attributes.properties.objectId;
            self.action.get("parameters").psiType = app.context.container.attributes.objectType;
            self.action.get("parameters").psdName = app.context.container.attributes.properties.pageSetName;
            self.action.get("parameters").folderType = module.config().wizardPsiFolderType  || 'Folder';
            self.action.get("parameters").folderPath = module.config().wizardPsiFolderPath  || '/Wizard/wizard';
            self.action.get("parameters").relationName =  this.relationName;
            self.action.get("parameters").appId = app.appId;

			app[this.myHandler].trigger("loading", true);
            app[this.myHandler].trigger("showMessage", window.localize("action.copyWizardForm.pleaseWait"));
            
            this.action.execute({
				success: function(result) {
					app[self.myHandler].trigger("loading", false);
                    var stageUrl = "Stage/wizard/"+result.result.objectId+'%7C'+result.result.objectId;
                    var linkElement = window.localize("action.copyWizardForm.manageNewForm") +" <a class='btn-link' href='"+stageUrl + "' title='" + result.result.properties.objectName + "'>"+result.result.properties.objectName+"</a>";
                    app[self.myHandler].trigger("showMessage", linkElement);
				},
				error: function() {
					app[self.myHandler].trigger("loading", false);
					app[self.myHandler].trigger("showError", window.localize("action.copyWizardForm.error"));
				}
			});
        }
		
    });

    CopyWizardForm.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/copywizardformconfig",

        initialize: function(){
            var viewModel = this.options.viewModel;
            var model = viewModel.model();
            viewModel.relationName = kb.observable(model, "relationName");

        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }

    });


    actionModules.registerAction("copyWizardForm", CopyWizardForm, {
        "actionId" : "copyWizardForm",
        "label" : "Copy Form",
        "icon" : "copy"
    });
  
    return CopyWizardForm;
});
  
require(["copywizardform"]);