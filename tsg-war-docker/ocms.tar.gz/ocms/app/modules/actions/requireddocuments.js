// RequiredDocuments module
define("requireddocuments", [
        // Application.
        "app",
        "modules/actions/actionmodules",
        "module",
        "oc"
    ],

    // Map dependencies from above array.
    function(app, actionModules, module, OC) {
        "use strict";

        var RequiredDocuments = {};

        RequiredDocuments.TagView = Backbone.View.extend({
            template: "actions/requireddocuments/tagview",
            events: {
                "click .document": "onClickDocument"
            },
            initialize: function(options) {
                this.documents = options.documents;
                this.tagNameProp = options.tagNameProp;

                //this will determine what color the panel is for each required doc
                if (this.documents) {
                    this.isCompleted = true;
                } else {
                    this.isCompleted = false;
                }
            },
            serialize: function() {
                return {
                    documents: this.documents,
                    tagName: this.tagNameProp,
                    isCompleted: this.isCompleted,
                    documentView: this.options.documentView,
                    cid: this.cid
                };
            },
            onClickDocument: function(e) {
                var self = this;
                var objectId = $(e.currentTarget).data("id");

                app.trigger("stage.refresh.documentId", objectId);

                if (self.options.handler === "rightSideActionHandler") {
                    app.trigger("stage.refresh.showPane3", true);
                    //don't hide the left bar for smaller screens
                    //the left Bar will instead go to the top of the screen
                    if (window.innerWidth > 991) {
                        if (self.hideLeftBar) {
                            app.trigger("toggleLeftBar", false);
                        }
                    }
                    self.paneSize = "rightPane";
                } else if (self.options.handler === "modalActionHandler") {
                    app.trigger("toggleLeftBar", true);
                    app[self.options.handler].trigger("hide");
                }

                app.trigger("viewRequiredDocument");

                self.render();
            }
        });

        RequiredDocuments.View = Backbone.Layout.extend({
            template: "actions/requireddocuments",
            initialize: function() {
                this.action = this.options.action;
                this.myHandler = this.options.config.get("handler");
                this.toggleLoader = function(bool) {
                    app[this.myHandler].trigger("loading", bool);
                };

                this.getChildren();

                this.listenTo(app, "viewRequiredDocument", function() {
                    this.documentView = true;
                    this.render();
                });
            },
            setUpViews: function() {
                var self = this;

                getTagProperty().done(function() {
                    self.render();
                });
            },
            getChildren: function() {
                var self = this;

                this.folderObject = new OC.OpenContentObject({
                    objectId: app.context.container.id
                });
                var getFolderChildren = this.folderObject.getChildren();
                var getFolderProps = this.folderObject.fetch();
                $.when(getFolderChildren, getFolderProps).done(function(results) {
                    //Excluding folders
                    //TODO: Would be great to have a way to exclude this abstractly in oc.js
                    self.children = _.filter(results[0], function(oco) {
                        return !_.contains(["Folder"], oco.objectType);
                    });
                    self.setUpViews();
                });
            },
            afterRender: function() {
                var self = this;
                var tags = {};
                var folderTags = app.folderTags || "hpi_folderTags";
                var requiredDocs = app.requiredDocs || "requiredTags";

                _.each(this.children, function(child) {
                    _.each(child.properties[folderTags], function(tag) {
                        if (!tags[tag]) {
                            tags[tag] = [];
                        }
                        tags[tag].push({
                            name: child.properties.objectName,
                            id: child.objectId
                        });
                    });
                });

                _.each(this.folderObject.get("properties")[requiredDocs], function(doc) {
                    var view = new RequiredDocuments.TagView({
                        documents: tags[doc],
                        tagNameProp: doc,
                        handler: self.myHandler,
                        documentView: self.documentView
                    });
                    self.insertView(".requireddocuments-outlet", view).render();
                });

            },
            serialize: function() {

                var requiredDocs = app.requiredDocs || "requiredTags";
                var remainingDocs = app.remainingRequiredDocs || "remainingRequiredTags";
                var modal = false;
                var rightSide = false;
                if (this.myHandler === "modalActionHandler") {
                    modal = true;
                } else if (this.myHandler === "rightSideActionHandler") {
                    rightSide = true;
                }
                return {
                    modal: modal,
                    rightSide: rightSide,
                    documents: this.children,
                    requiredDocuments: this.folderObject.get("properties")[requiredDocs],
                    remainingDocuments: this.folderObject.get("properties")[remainingDocs]
                };
            }
        });

        //This function returns the correct tag property.  For example, the default for Alfresco is "hpi_folderTags" and for DCTM it's "keywords"
        var getTagProperty = function() {
            var def = $.Deferred();
            $.ajax({
                url: app.serviceUrlRoot + '/hpi/getTagProperty',
                success: function(response) {
                    app.folderTags = response;
                    def.resolve();
                },
                error: function(jqXHR, textStatus, errorThrown) {}
            });

            return def.promise();
        };

        actionModules.registerAction("requiredDocuments", RequiredDocuments, {
            "actionId": "requiredDocuments",
            "label": "Required Documents",
            "icon": "exclamation-sign",
            "handler": "rightSideActionHandler",
            "paneSize": "fullPane"
        });

        return RequiredDocuments;
    });
require(["requireddocuments"]);