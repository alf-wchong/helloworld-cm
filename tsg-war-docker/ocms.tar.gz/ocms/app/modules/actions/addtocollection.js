// Advancedsearch module
define("addtocollection",[
  // Application.
  "app",
  "knockout",
  "modules/common/ocquery",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, ko, Ocquery, actionModules) {
    "use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    function ViewModel(action, myHandler) {
        
        var self = this;
        self.availableCollections = ko.observableArray();
        self.selectedCollection = ko.observable();
        self.newOrExisting = ko.observable("existing");
        self.newCollectionName = ko.observable();
        self.collectionVisibility = ko.observable(window.localize("generic.private"));

        // do an ocquery for hpi_collections with the owner as the logged in user
        var query = new Ocquery.Collection([], {});
        query.searchParameters = [];
        var sp;

        // add a search parameter for searching upon type hpi_collection
        sp = {
            paramName: window.localize("modules.actions.addToCollection.collection"),
            paramValue: window.localize("modules.actions.addToCollection.collection"),
            paramType : "type"
        };
        query.searchParameters.push(sp);

        // parameter for owner
        if(!app.uniqueUserName) {
            app.log.error(window.localize("modules.actions.addToCollection.theUniqueUserName"));
        }
        sp = {
            paramName: "creator",
            paramValue: app.user.get(app.uniqueUserName),
            paramType : "property"
            };
        query.searchParameters.push(sp);
        // optionally, we'd include a typeahead here once we get to that point
        query.fetch({
            success: function() {
                _.each(query.models, function(collection){
                    self.availableCollections.push(collection);
                });
            }
        });

        self.addToCollection = function(){
            // In the case of selecting the action on a single object
            if (action.get("parameters").objectId !== null) {
                action.get("parameters").objectIds = [action.get("parameters").objectId];
            }
            self.toggleLoader(true);
            action.get("parameters").collectionId = self.selectedCollection().get("objectId");
            action.execute({
                success: function(data, textStatus, jqXHR){
                    self.toggleLoader(false);
                    if (data.result.length > 0) {
                        var resultString = '';
                        _.each(data.result, function(result) {
                            resultString = resultString + result + "<br />";
                        });
                        // 1 item being added and it is already in collection
                        if (data.result.length === action.get("parameters").objectIds.length) {
                            app[myHandler].trigger("showError", (window.localize("modules.actions.addToCollection.theSelectedItems")) + resultString);
                        } else {
                            app[myHandler].trigger("showMessage", window.localize("modules.actions.addToCollection.someItems") + 
                                    window.localize("modules.actions.addToCollection.theseItemsWereAlreadyMembers") + resultString);
                        }
                    } else {
                        app[myHandler].trigger("showMessage", window.localize("modules.actions.addToCollection.itemSuccessfully"));
                    }
                    app.trigger("stage.refresh.containerId", true);
                },
                error: function(jqXHR, textStatus, errorThrown){
                    self.toggleLoader(false);
                    app[myHandler].trigger("showError", (window.localize("modules.actions.addToCollection.sorryAnErrorHas")) +
                        " " + jqXHR.responseText);
                }
            });
        };

        self.createCollection = function() {
            if (action.get("parameters").objectId !== null) {
                action.get("parameters").objectIds = [action.get("parameters").objectId];
            }
            self.toggleLoader(true);
            action.get("parameters").newCollectionName = $.trim(self.newCollectionName()); //no leading or trailing whitespace allowed
            action.get("parameters").collectionVisibility = self.collectionVisibility();
            action.execute({
                success: function(data){
                    self.toggleLoader(false);
                    app[myHandler].trigger("showMessage", window.localize("modules.actions.addToCollection.collectionSuccessfully"));
                    app.trigger("stage.refresh.containerId", true);
                },
                error: function(jqXHR, textStatus, errorThrown){
                    self.toggleLoader(false);
                    app[myHandler].trigger("showError", window.localize("modules.actions.addToCollection.sorryAnErrorHasOccuredCollection") +
                         " " + jqXHR.responseText);
                }
            });
        };

        self.toggleLoader = function(bool){
                app[myHandler].trigger("loading", bool);
        };
 
    }

    action.View = Backbone.Layout.extend({
        template: "actions/addtocollection",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.viewModel = new ViewModel(this.action, this.myHandler);
        },

        afterRender: function(){
            kb.applyBindings(this.viewModel, this.$el[0]);

        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
    });

    actionModules.registerAction("addToCollection", action, {
        "actionId" : "addToCollection",
        "label" : "Add To Collection",
        "icon" : "tags"
    });
    actionModules.registerAction("addToCollection-DocViewer", action, {
        "actionId" : "addToCollection-DocViewer",
        "label" : "Add To Collection",
        "icon" : "tags"
    });
    
    return action;
	
});
require(["addtocollection"]);