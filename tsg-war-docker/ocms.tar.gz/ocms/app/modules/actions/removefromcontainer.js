define("removefromcontainer", [
	'app',
	"managerelations",
	"modules/conditions/condition",
	"modules/actions/actionmodules"
],
function(app, ManageRelations, Condition, actionModules){
	"use strict";

	var RemoveFromContainer = _.extend({}, ManageRelations);
	
	RemoveFromContainer.View = ManageRelations.View.extend({
		template: "actions/removefromcontainer/removefromcontainer",
		initialize: function(){
			RemoveFromContainer.View.__super__.initialize.apply(this, arguments);
			this.removeFromContainerSubView = new RemoveFromContainer.RemoveFromContainerSubView({
					"action": this.action,
					"relationNames": this.relationNames,
					"twoWayRelation": this.twoWayRelation,
					"myHandler": this.myHandler,
					"config": this.getOverrides(),
					"primaryId": this.primaryId,
					"parentView": this
			});
			this.setView("#remove-from-container-subview-outlet", this.removeFromContainerSubView);
		}
	});

	RemoveFromContainer.RemoveFromContainerSubView = ManageRelations.ExistingRelationsView.extend({
		template: "actions/removefromcontainer/removefromcontainersubview",
		initialize: function(){
			this.config = this.options.config;
			this.relationNames = this.options.relationNames;
			this.action = this.options.action;
			this.parentView = this.options.parentView;
			this.myHandler = this.options.myHandler;
			this.selectedRelation = this.relationNames[0];
			this.pendingRelations = new ManageRelations.Documents(undefined, this.config);
			this.existingRelations = new ManageRelations.Documents(undefined, this.config);
		},
		doOnDismiss: function(){
			var url = "Stage/" + app.context.configName() + "/" + app.context.container.id;
			Backbone.history.navigate(url, { trigger: true });
		},
		removeRelations: function(){
			var self = this;
			app[this.myHandler].trigger("loading", true);
			
			// grab the parentId from the container
			this.parentObjectId = app.context.container.id;
			
			// set relation map to selected relation to objectId of doc we are removing
			var relationMap = {};
			relationMap[this.selectedRelation] = [this.action.get("parameters").objectId];

			// set parentChild map that back-end uses to remove child from parent
			var map = {};
			map[this.parentObjectId] = [this.action.get("parameters").objectId];

			this.action.get("parameters").mapParentToChild = map;
			this.action.get("parameters").relationMap = relationMap;
			this.action.get("parameters").removeRelation = true;

			this.action.execute({
				success: function(){
					app[self.myHandler].trigger("loading", false);
					app[self.myHandler].trigger("showMessage", window.localize("action.removeFromContainer.successMessage"));

					// handler function run after modal is closed. Look at modalActionHandler #_onModalHidden 
					self.parentView.onDismiss = self.doOnDismiss;
				},
				error: function(){
					app[self.myHandler].trigger("loading", false);
					app[self.myHandler].trigger("showError", window.localize("action.removeFromContainer.errorMessage"));
				}
			});
		},
		// override the before and after render so that it doesn't get fired off by manage relations
		beforeRender: function(){},
		afterRender: function(){}
	});

	actionModules.registerAction("removeFromContainer", RemoveFromContainer, {
		"actionId": "removeFromContainer",
		"label": "Remove From Container",
		"icon": "bin"
	});

	return RemoveFromContainer;
});
require(["removefromcontainer"]);
