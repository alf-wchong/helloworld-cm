define("generateworkflowreport", [
        "app",
        "underscore",
        "modules/actions/actionmodules",
        "modules/common/downloadutils",
        "modules/common/queryabletypeahead",
        "modules/common/typeahead",
        "modules/hpiadmin/actionconfig/actions/generateworkflowreport/generateworkflowreportconfig"
],

function (app, _, actionModules, DownloadUtils, QueryableTypeahead, HPITypeAhead, GenerateWorkflowReportConfig) {
    "use strict";

    var GenerateWorkflowReport = {};

    GenerateWorkflowReport.CustomConfigView = GenerateWorkflowReportConfig.View;

    GenerateWorkflowReport.View = Backbone.Layout.extend({
        template: "actions/generateworkflowreport",
        events: {
            "click .submit-attestation-report": "generateReport",
            "click .additional-attestation-report-filter": "checkedFilter",
            "keydown .assignee-userList" : 'sanitizeKey',
            "click .removeAssignee": "removeAssignee"
        },
        initialize: function () {
            this.myHandler = this.options.config.get("handler");
            this.excelProps = this.options.config.get('nameAttrsToDisplay') ? this.config.get('nameAttrsToDisplay') : [];
            this.fileName = this.options.config.get("fileNamePrefix") ? this.options.config.get("fileNamePrefix") : "Workflow Report";
            this.assigneeTypeaheadDropdownLimit = this.options.config.get("assigneeTypeaheadDropdownLimit") ? this.options.config.get("assigneeTypeaheadDropdownLimit") : 5;
            this.includeIncompleteTasks = true;
            this.includeCompletedTasks = false;
            this.userAssigneeList = [];
            this.createUserTypeaheads();
        },
        createUserTypeaheads: function(){
            this.queryUrl = app.serviceUrlRoot + "/authorities/search?authorityType=user&attrToSearch=displayName&matchType=contains";

            this.assigneeTypeahead = new QueryableTypeahead({
                queryUrl: this.queryUrl,
                displayKey: 'displayName',
                searchOn: 'displayName',
                placeholder: 'Start typing here...',
                minLength:3,
                limit:this.assigneeTypeaheadDropdownLimit
            }, this);

            this.startTypeaheadListening();
            this.render();
        },
        startTypeaheadListening: function () {
            var self = this;
            if(this.assigneeTypeahead){
                this.stopListening(this.assigneeTypeahead);
                this.listenTo(this.assigneeTypeahead, 'change:selected', function(option){
                    if(option){
                       self.addAssignee();
                    }
                });
            }
        },
        generateReport: function() {
            var self = this;
            var todayDate = new Date();
            this.action.get("parameters").fileName =  this.fileName + "-" + todayDate.toString() +".xlsx";
            this.action.get("parameters").excelColPropValues = _.pluck(this.excelProps, 'attrValue');
            this.action.get("parameters").excelColPropLabels = _.pluck(this.excelProps, 'attrName');
            this.action.get("parameters").includeIncompleteTasks = this.includeIncompleteTasks;
            this.action.get("parameters").includeCompletedTasks = this.includeCompletedTasks;
            this.action.get("parameters").emailReportEnabled = this.options.config.get("emailReportEnabled");

            // build up custom filter variables
            var filterListMap = {
                "Assignee": _.pluck(this.userAssigneeList, "value") ? _.pluck(this.userAssigneeList, "value") : [],
            };

            this.action.get("parameters").filterListMap = filterListMap;

            if (this.options.config.get("emailReportEnabled")){
                app[this.myHandler].trigger("loading", true);
                this.action.execute({
                    success : function() {
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showMessage", window.localize("modules.actions.generateWorkflowReport.email.success"));
                    },
                    error: function() {
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showError", window.localize("modules.actions.generateWorkflowReport.email.error"));
                    }
                });

            }else{
                var callback = function() {
                    app[self.myHandler].trigger("showMessage", window.localize("modules.actions.generateWorkflowReport.download.success"));
                };

                var error = function(){
                    app[self.myHandler].trigger("showError", window.localize("modules.actions.generateWorkflowReport.download.error"));
                };

                //download excel sheet
                DownloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', this.action.attributes, callback, error);
            }
        },
        checkedFilter: function(){
            this.includeIncompleteTasks = ($(".include-incomplete-tasks").is(":checked")) ? true : false;
            this.includeCompletedTasks = ($(".include-completed-tasks").is(":checked")) ? true : false;
        },
        addAssignee: function(){
            var removeAttrList = _.pluck(this.userAssigneeList, "value");
            if(!_.contains(removeAttrList, this.assigneeTypeahead.selected.authorityId) && this.assigneeTypeahead.selected.authorityId){
                this.userAssigneeList.push({"label": this.assigneeTypeahead.selected.displayName, "value": this.assigneeTypeahead.selected.authorityId});
            }
            this.render();
        },
        removeAssignee: function(e){
           var labelToRemove = e.currentTarget.id;
           this.userAssigneeList = _.without(this.userAssigneeList, _.findWhere(this.userAssigneeList, {"label": labelToRemove}));
           $(e.currentTarget).remove();
           this.render();
        },
        sanitizeKey: function(evt){
            //catch the enter key to prevent the query text being set as the selected user
            var code = evt.keyCode || evt.which;
            if(code==13){
                //prevent default for enter key only
                evt.preventDefault();
            }
        },
        beforeRender: function(){
            this.setView('.assignee-userList', this.assigneeTypeahead);
        },
        serialize: function () {
            //forcing this to be a modal for the current implementation
            return {
                modal: true,
                userAssigneeList: this.userAssigneeList
            };
        }
    });

    actionModules.registerAction("generateWorkflowReport", GenerateWorkflowReport, {
        "actionId": "generateWorkflowReport",
        "label": (window.localize("modules.actions.generateWorkflowReport.generateAttestationReport")),
        "icon": "cogwheel",
        "isHeaderMode": true,
        "handler": "modalActionHandler" 
    });

    return GenerateWorkflowReport;

});
require(["generateworkflowreport"]);