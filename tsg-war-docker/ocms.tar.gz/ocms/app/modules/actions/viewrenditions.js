// Viewrenditions module
define("viewrenditions",[
  // Application.
  "app",
  'URIjs/URI',
  "modules/actions/actionmodules",
  "module"
],

// Map dependencies from above array.
function(app, URI, actionModules, module) {
    "use strict";
        
    var ViewRenditions = {};
    
    ViewRenditions.Config = {
        //Config (can be changed in config-project.js)
        getAttributes: function(){
            return module.config().attributes || [
            {
                'displayName': 'Document Name',
                'ocoName': 'objectName'
            }];
        }
    };

    ViewRenditions.View = Backbone.Layout.extend({
		template: "actions/viewrenditions",
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
            
            this.documentId = app.context.document.id;
            this.loading = true;
            
            $.ajax({
                type: 'GET',
                url: app.serviceUrlRoot + '/content/getContentInfo',
                data: {
                    "ids[]" : [this.documentId]
                },
                context: this,
                success: this.getContentInfoSuccess
            });  
        },
        getContentInfoSuccess: function(objectContentInfo) {
            this.renditions = [];
            _.each(objectContentInfo[0].mimeTypes, function(type){
                this.renditions.push({
                    "type" : type,
                    "prettyName" : this.getMimeTypeName(type),
                    "icon" : this.getMimeTypeIcon(type),
                    "link" : new URI().path(app.serviceUrlRoot + "/content/content")
                                        .addSearch("id", this.documentId)
                                        .addSearch("download", true)
                                        .addSearch("contentType[]", objectContentInfo[0].fileExtensions[_.indexOf(objectContentInfo[0].mimeTypes, type)])
                });
            }, this);
                
            this.noRenditions = this.renditions.length === 0;
            
            this.showProperties();
            this.loading = false;
            this.render();
        },
        getMimeTypeName: function(type){
            var prettyName = type;
            
            var mimeType = app.context.getMimeTypePrettyType(type);
            
            if(mimeType){
                prettyName = mimeType.prettyName;
            }
            
            return prettyName;
        },
        getMimeTypeIcon: function(type) {
    		var iconImageLocation = "assets/css/styles/img/icons/unknown.svg";

    		var contentType = type;
            
			var contentTypeConfig = app.context.getContentTypeConfigByMimiType(contentType);

			// if we've got a configuration set up for this mimeType, set the icon, otherwise we'll use the default
			if(contentTypeConfig) {
				iconImageLocation = contentTypeConfig.iconPath;	
            }

    		return iconImageLocation;
    	},
        showProperties: function(){
            var self = this;
            
            var propsToShow = ViewRenditions.Config.getAttributes();
            var docProps = app.context.document.get('properties');
            this.propertyMap = [];
            
            _.each(propsToShow, function(prop){
                self.propertyMap.push({
                    "prop" : prop.displayName,
                    "value": docProps[prop.ocoName]
                });
            });
        },
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
                renditions : this.renditions,
                propsToShow : this.propertyMap,
                noRenditions: this.noRenditions,
                loading: this.loading
			};
        },
		afterRender: function(){
            this.rendered = true;
        }
	});

	actionModules.registerAction("viewRenditions", ViewRenditions, {
        "actionId" : "viewRenditions",
      	"label" : "View Renditions",
      	"icon" : "file"
    });

    return ViewRenditions;
});
require(["viewrenditions"]);