// Advancedsearch module
define("annotateobject",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
    "use strict";

    var action = {};
    
    action.View = Backbone.Layout.extend({
        template: "actions/annotateobject",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
            window.open(app.openAnnotateURL +
             "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&username=" + app.user.get("loginName"));
        },
        events: {
            "click #annotate-ok" : "dismiss"
        },
        serialize: function(){
            var modal = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            }
            
            return {
                message: (window.localize("modules.actions.annotateObject.wereOpening")),
                modal: modal
            };
        },
        dismiss : function(){
            app.trigger("stage.refresh.documentId", true);
        }

    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("annotateObject", action, {
       "actionId" : "annotateObject",
        "label" : "Annotate",
        "icon" : "comments"
    });

    return action;
});
require(["annotateobject"]);