//Advancedsearch module
define("viewwizardworkflowstatus",[
    //Application
    "app",
    "modules/conditions/condition",
    "modules/actions/actionmodules"
],

function(app, Condition, actionModules){
    "use strict";

    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //
    var action = {};

    function ViewModel(action, myHandler, toggleLoader) {

        var self = this;
        self.objectId = action.get("parameters").objectId;
        self.rows = ko.observableArray();
        self.sigEvents = ko.observableArray();

        self.getWorkflowStatus = function() {
            self.toggleLoader(true);
            var opts = {
                type : "GET",
                url: app.serviceUrlRoot + "/aw-workflow/getWizardWorkflowStatus",
                data: {formId : self.objectId},

                success: function(result){
                    self.toggleLoader(false);
                    // console.log(result);
                    // console.log(result["formSignatures"][0]);
                    $.each(result.formSignatures, function(index, item){
                        // accounting for poor formatting from the server
                        if(item.status === "approve") {
                            item.status = "Approved";
                        } else if(item.status === "reject") {
                            item.status = "Rejected";
                        } else if(item.status === "pending") {
                            item.status = "Pending";
                        } else if(item.status === "reviewed") {
                            item.status = "Reviewed";
                        } else if(item.status === "skipped") {
                            item.status = "Skipped";
                        }
                        self.sigEvents.push(item);
                        
                    });
                },
                error: function(){
                    app[myHandler].trigger("showError", window.localize("modules.actions.viewWizardWorkflowStatus.errorRetrieving"));
                }
            };

            $.ajax(opts);
        };
        self.toggleLoader = function(bool) {
            app[myHandler].trigger("loading", bool);
        };
        
    }   


    action.View = Backbone.Layout.extend({
        template: "actions/viewwizardworkflowstatus",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.inWorkflow = this.checkIsInWorkflow();
        },
        checkIsInWorkflow: function() {
            var conditions = this.action.get("conditions");
            for(var i=0;i < conditions.length ; i+=1){
                if(conditions[i].name === "condition-isanyobjectinworkflow-conditionevaluator"){
                    if(conditions[i].status === "valid"){
                        return true;
                    }
                    return false;
                }
            }
        },
        beforeRender: function(){
            this.viewModel = new ViewModel(this.action, this.myHandler);
            this.viewModel.getWorkflowStatus();
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                inWorkflow : this.inWorkflow
            };
        }
    });

    actionModules.registerAction("viewWizardWorkflowStatus", action, {
        "actionId" : "viewWizardWorkflowStatus",
        "label" : "View Wizard Workflow Status",
        "icon" : "cogwheel",
        "groups" : ["wizard", "view", "status"]
    });
    
    return action;
    
});
require(["viewwizardworkflowstatus"]);