define("exportforms",[
  // Application.
  "app",
  "modules/actions/actionmodules",
  "modules/common/downloadutils",
  "modules/common/tossacross",
  'modules/wizard/services/pagesetinstanceprovider',
  'jqueryDownload'
],

// Map dependencies from above array.
function(app,actionModules, downloadUtils, TossAcross, PSIProvider) {

	"use strict";
	var ExportForms = {};
	var action = {};

	var getPageSet = function(objectId){
		var deferred = $.Deferred();
		$.ajax({
			url: app.serviceUrlRoot + "/content/content?contentType[]=json,xml&id=" + encodeURIComponent(objectId),
			dataType: "json",
			success: function(json){
				app.context.configService.getApplicationConfig(function(cfg) {
					deferred.resolve(PSIProvider.transformJSON(json, cfg));
				});
			},
			error: function(jqxhr, response, status){
				app.log.error('failed to retrieve json for: ' + objectId, status);
                deferred.resolve(undefined);
			}
		});

		return deferred.promise();
	};
	
	//Grouping all of the messages in one place.
	action.localize = {
		displayHelpIcon: (window.localize("modules.actions.exportForms.chooseToSet")),
		noJSONMessage: (window.localize("modules.actions.exportForms.oneOfThe")),
		successfulActionSubmissionMessage: (window.localize("modules.actions.exportForms.theResults"))
	};

	ExportForms.Model = Backbone.Model.extend({
		defaults: {
			properties: {
				//These default properties will get overridden by the configured properties
				questionName: "",
				questionShortName: "",
				questionId: "",
				questionLabel: ""
			}
		}
	});

	//Collection of selected document models
	ExportForms.Collection = Backbone.Collection.extend({
		model: ExportForms.Model
	});

	//This is the main controller.  Here we keep the state of all the collections so that the listeners in tossacross
	//remain functioning.  A new view is created with each "render" where the current state of the collections are passed
	//in as parameters.
	ExportForms.View = Backbone.Layout.extend({
		template: "actions/exportformscontroller",
		events: {
			"click #back" : "back",
			"click #export-form" : "exportFormsToExcel",
			"click #next" : "next"
		},
		initialize: function(){
			var self = this;
			this.ui = {};
			self.action = this.options.action;
			self.config = this.options.config;
			this.searchResultsViewController = this.options.searchResultsViewController;
			self.myHandler = self.config.get("handler");
			this.availableQuestionsCollection = new ExportForms.Collection();
			this.selectedQuestionsCollection = new ExportForms.Collection();
			this.availableSortFieldsCollection = new ExportForms.Collection();
			this.selectedSortFieldsCollection = new ExportForms.Collection();
			this.ControlsView = new ControlsView();

			//These listeners update to enable/disable the Export Forms based on the fact that we don't want to allow for
			//submitting a blank form.
			this.listenTo(self.selectedSortFieldsCollection, 'add remove', function(){
				if(self.selectedSortFieldsCollection.length === 0 && self.selectedQuestionsCollection.length === 0 &&
					this.currentView === "this.attrView"){
					this.ControlsView.disableExport(this.ui);
				}
			});

			this.listenTo(self.selectedQuestionsCollection, 'add remove', function(){
				if(self.selectedSortFieldsCollection.length === 0 && self.selectedQuestionsCollection.length === 0){
					this.ControlsView.disableExport(this.ui);
				}
				else{
					this.ControlsView.enableExport(this.ui);
				}
			});


			self.deferredPageSetProps = $.Deferred();
			var objectId = self.action.get("parameters").objectIds[0];
			$.ajax({
				url: app.serviceUrlRoot + "/content/properties?id=" + encodeURIComponent(objectId),
				dataType: "json",
				success: function(json){
					self.deferredPageSetProps.resolve(json);
				},
				error: function(jqxhr, response, status){
					app.log.error('failed to retrieve json for: ' + objectId, status);
					app[self.myHandler].trigger("showError", action.localize.noJSONMessage);
				}
			});
			this.questionsDeferred = $.Deferred();
			$.when(self.deferredPageSetProps).done(function(props){
				self.getAvailableQuestions(props);
				self.renderTossacrossControl(props);
			});
			
		},
		getAvailableQuestions: function(props){
			var self = this;
			var pageSetURL = app.serviceUrlRoot + "/aw-form/getPageSet?pageSetName=" + encodeURIComponent(props.properties.pageSetName);
			//Parses he JSON form.  Also, makes sure that no other types of forms can be called with this action.
			$.ajax({
				url: pageSetURL,
				dataType: "json",
				success: function(pageSet){
					getPageSet(pageSet.objectId).done(function(pageSetJSON){
					
						_.each(pageSetJSON.pages, function(pages){
							_.each(pages.questions, function(questions){
								self.availableQuestionsCollection.add(new ExportForms.Model({
										questionName : questions.label,
										questionShortName: questions['short-label'],
										questionId : questions._id,
										questionLabel : "Page: " + pages.title + " // " + " Question: " + questions.label
									}));
								});
							});
						});
						/*//Making sure that the list of potential questions comes from pages that are
						//on the flowpath.
						var flowpath = self.flattenFlowPath(json.flowpath);
						var availablePages = _.reject(json.pages, function(page){
							return !_.contains(flowpath, page._id);
						});*/
				},
				error: function(jqxhr, response, status){
					app.log.error('failed to retrieve json for: ' + props.properties.pageSetName, status);
					app[self.myHandler].trigger("showError", action.localize.noJSONMessage);
				}
			});
		},
		renderTossacrossControl: function(props){
			var self = this;
			self.formObjectType = props.objectType;//do whatever

			this.currentView = "";
			var sortFields = self.action.get("parameters").sortFields;
			app.context.configService.getLabels(self.formObjectType, sortFields)
				.done($.proxy(function(typeLabels) {
				this.prettyNames = app.context.configService.getLabels(self.formObjectType, sortFields);
				for(var index = 0; index < sortFields.length; index++){
						this.prettyNames[index] = typeLabels[index].label;
				}
				for(var index1 = 0; index1 < sortFields.length; index1++){
					this.availableSortFieldsCollection.add({
						'prettyName' : this.prettyNames[index1],
						'attrName': sortFields[index1]
					});
				}
				this.attrView = new AttributesView({
					'available': this.availableSortFieldsCollection, 
					'selected': this.selectedSortFieldsCollection
				});
				self.currentView = 'this.attrView';
				if(self.rendered){
					this.setView(".active-pane", this.attrView).render();
				}else{
					this.setView(".active-pane", this.attrView);
				}
			}, self));
		},
		_updateColumnHeader: function(e){
			var self = this;
			self.selectedColumnHeader = $(e.target).attr("value");
		},
		//When the 'next' button is pressed.
		next: function(){
			var self = this;
			self.selectedColumnHeader = "label";
			if(self.currentView === "this.attrView"){
				self.questView = new QuestionsView({
					'availible': self.availableQuestionsCollection, 
					'selected': self.selectedQuestionsCollection
				});
				self.setView(".active-pane", this.questView).render();
				self.ControlsView.nextPressed(this.ui);
				self.currentView = "this.questView";
				if(self.selectedSortFieldsCollection.length === 0 && self.selectedQuestionsCollection.length === 0){
					this.ControlsView.disableExport(this.ui);
				}
				else{
					this.ControlsView.enableExport(this.ui);
				}
				self.$('.export-forms-label-btn').show();
				self.$('#dropDownInfo').prop('title', action.localize.displayHelpIcon);
				self.$('#selected li > a').click(function(e){
					self.$('#text').text($(this).html());
					self._updateColumnHeader(e);
				});
			}
		},
		//When the 'back' button is pressed.
		back: function(){
			var self = this;
			if(this.currentView === "this.questView"){
				this.attrView = new AttributesView({
					'available': self.availableSortFieldsCollection, 
					'selected': self.selectedSortFieldsCollection
				});
				this.setView(".active-pane", this.attrView).render();
				this.currentView = "this.attrView";
				this.ControlsView.backPressed(this.ui);
				self.$('.export-forms-label-btn').hide();
			}
		},
		//When the 'export forms' action is pressed.  Here is where we gather the questions and sort fields that have been selected and
		//send them off to OC.
		exportFormsToExcel: function(){
			var self = this;
			//Grabbing the Selected Questions Collection
			var questions = [];
			for(var index = 0; index < self.selectedQuestionsCollection.length; index++){
				if(self.selectedColumnHeader === "short-label"){
					questions[index] = self.selectedQuestionsCollection.models[index].get('questionId') + "divider" + self.selectedQuestionsCollection.models[index].get('questionShortName');
				}
				else{
					questions[index] = self.selectedQuestionsCollection.models[index].get('questionId') + "divider" + self.selectedQuestionsCollection.models[index].get('questionName');
			
				}
			}
			//Grabbing the Selected Sort Fields Collection
			var fields = [];
			for(var index1 = 0; index1 < self.selectedSortFieldsCollection.length; index1++){
				fields[index1] = self.selectedSortFieldsCollection.models[index1].get('attrName');
			}
			
			self.action.get("parameters").selectedColumnHeader = self.selectedColumnHeader;
			self.action.get("parameters").selectedQuestions = questions;
			self.action.get("parameters").selectedSortFields = fields;
			//Putting a time stamp on the .xls file so no two files are identical.
			var dt = moment().format();
            var dtFormat = dt.replace(/:/g, "-");
			self.action.get("parameters").fileName = 'Export-Form' + "-" + dtFormat + ".xls";

			var callback = function() {
                app[self.myHandler].trigger("showMessage", action.localize.successfulActionSubmissionMessage);
                self.searchResultsViewController.tableEventsRef.trigger("search:removeAllChecked");
            };

            downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', self.action.attributes, callback);
        
		},
		flattenFlowPath: function(pages){
			var flattenedPages = [];
			if(!pages){
				return flattenedPages;
			}
			_.each(pages, function(page){
				flattenedPages.push(page.id);
				flattenedPages = flattenedPages.concat(this.flattenFlowPath(page.children));
			}, this);
			return flattenedPages;
		},
		afterRender: function(){
			var self = this;
			this.rendered = true;
			this.currentView = "this.attrView";
			self.$("#back").hide();
			self.$("#export-form").hide();
			self.$('.export-forms-label-btn').hide();
			this.ui.backBtn = self.$("#back");
			this.ui.exportForms = self.$("#export-form");
			this.ui.exportFormsLabelBtn = self.$('.export-forms-label-btn');
			this.ui.displayer = self.$('#display');
			this.ui.nextBtn = self.$("#next");
			this.ui.selector = self.$('#selected li > a');
			this.ui.selectorText = self.$('#text');
		},
		serialize: function(){
            return action.localize;
        }
	});
	
	//This is the questions subview where we do the tossacross.
	var QuestionsView = Backbone.Layout.extend({
		template: "actions/exportforms",
		initialize: function(options){
			var self = this;
			self.typesTossAcross = new TossAcross.Layout({
                clickAcross: true,
                enableAddRemove: true,
                srcCollection: {
                    title: 'Available Questions',
                    filter: true,
                    labelAttr: 'questionLabel',
                    collection: options.availible
                },
                targetCollections: [
                    {
                        title: 'Selected Questions',
                        labelAttr: 'questionLabel',
                        filter: true,
                        collection: options.selected
                    }
                ]
            });	
		},
		beforeRender: function(){
			this.setView('.question-fields', this.typesTossAcross);	
		},
		afterRender: function(){
			this.rendered = true;
		}
	});

	//This is the attributes view where we do the tossacross.
	var AttributesView = Backbone.Layout.extend({
		template: "actions/sortfieldsexportforms",
		initialize: function(options){
			var self = this;
			self.typesTossAcross = new TossAcross.Layout({
                    clickAcross: true,
                    enableAddRemove: true,
                    srcCollection: {
                        title: (window.localize("modules.actions.exportForms.availableAttr")),
                        filter: true,
                        labelAttr: 'prettyName',
                        collection: options.available
                    },
                    targetCollections: [
                        {
                            title: (window.localize("modules.actions.exportForms.selectedAttr")),
                            labelAttr: 'prettyName',
                            collection: options.selected,
                            filter: true
                        }
                    ]
                });	
		},
		beforeRender: function(){
			this.setView('.sort-fields', this.typesTossAcross);
		},
		afterRender: function(){
			this.rendered = true;
		}
	});		

	//This is the controls view for the three buttons on the bottom: Back, Next, and Export Form.
	var ControlsView = Backbone.Layout.extend({
		template: "actions/exportformscontroller",
		//When the next button is pressed.
		nextPressed: function(ui){
			ui.backBtn.show();
			ui.nextBtn.hide();
			ui.exportForms.show();
		},
		//When the 'back' button is pressed.
		backPressed: function(ui){
			ui.backBtn.hide();
			ui.nextBtn.show();
			ui.exportForms.hide();
		},
		//Enabling the Export Form button.
		enableExport: function(ui){
			ui.exportForms.removeClass("disabled");
		},
		//Disabling the Export Form button.
		disableExport: function(ui){
			ui.exportForms.addClass("disabled");
		},
		afterRender: function(){
			var self = this;
			self.ui.backBtn = self.$("#back");
			self.ui.exportForms = self.$("#export-form");
			self.ui.nextBtn = self.$("#next");
		}
	});

	actionModules.registerAction("exportForms", ExportForms, {
        "actionId" : "exportForms",
        "label" : (window.localize("modules.actions.exportForms.exportForm")),
        "icon" : "list-alt",
        "modalSize" : "xl"
    });

    return ExportForms;

});
require(["exportforms"]);