define("delegatewizardworkflowtask",[
  // Application.
  "app",
  "modules/actions/actionmodules",
  "modules/tsg",
  "modules/common/queryabletypeahead",
  "modules/common/hpiconstants",
  "modules/hpiadmin/actionconfig/actions/delegatewizardworkflowtask/delegatewizardworkflowtaskconfig",
  "oc"
],

// Map dependencies from above array.
function(app, actionModules, TSG, QueryableTypeahead,  HPIConstants, DelegateWizardWorkflowCustomConfigView, OC) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var DelegateWizardWorkflowTask = {};

    DelegateWizardWorkflowTask.Model = Backbone.Model.extend({
        defaults: {

        },
        initialize: function(options) {
            this.options = _.defaults(options,this.defaults);
        }
    });

    DelegateWizardWorkflowTask.CustomConfigView = DelegateWizardWorkflowCustomConfigView.View;

    // Carry out the action
    DelegateWizardWorkflowTask.View = Backbone.Layout.extend({
        template: "actions/delegatewizardworkflowtask",
        events: {
            'change #delegateTask-roleList': 'selectRole',
            'click #delegateTask-submitBtn': 'onSubmit',
            'keydown #delegateTask-userList' : 'sanitizeKey'
        },
        initialize: function(){
            var self = this;
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.selectedUser = '';
            this.selectedUserLabel = '';
            this.usersWhoHaveTasks = [];
            this.availableTasksAndRoles = [];
            this.selectedTaskAndRole = {};
            this.isLastUserSelectionValid = false;
            this.objectId = this.action.get("parameters").objectId;
            this.groupName = this.options.config.get("groupName");
            this.caseSensitiveRequired = this.options.config.get("caseSensitiveRequired");

            //Clean up logic
            this.caseSensitiveRequired = ((this.caseSensitiveRequired === "true" || this.caseSensitiveRequired === true) ? true : false);

            this.startListening();

            $.when(this.getTaskAndUserInfo()).done(function(){
                self.createUserTypeahead();
            });
           
        },
        createUserTypeahead: function(){
            var self = this;
            // search on the oco for the form attribute
            var oco = new OC.OpenContentObject({ objectId : self.objectId });
            oco.fetch().done(function(docOco){

                // update the set group name
                self.setGroupName(docOco);

                // build up the queryUrl with the group name
                self.queryUrl = app.serviceUrlRoot + "/authorities/search";
                self.queryUrl = self.queryUrl + "?authorityType=" + "user" + "&childOfAuthority=" + self.groupName + "&attrToSearch=" + "displayName" + "&matchType=" + "contains" + "&isCaseSensitive=" + self.caseSensitiveRequired;

                self.typeahead = new QueryableTypeahead({
                    queryUrl: self.queryUrl,
                    displayKey: 'displayName',
                    searchOn: 'displayName',
                    placeholder: 'Start typing here...'
                });

                // now call the listener here since the groupName is correctly set now
                self.startListening();
                self.render();
            });

        },
        setGroupName: function(docOco){
            var configuredGroupName = this.options.config.get("groupName");
            // check to see if the groupName is configured and if not then do the searching on all groups
            if (configuredGroupName && this.selectedTaskAndRole.roleName){
                // parse the groupName to see if they are injecting properties
                if (configuredGroupName.indexOf("$") !== -1){

                    var attributeValues = app.context.util.parsePatternForAttributes(configuredGroupName);
                    _.each(attributeValues, function(attr) {
                        if (attr === "roleName"){
                            configuredGroupName = configuredGroupName.replace("$" + attr + "$", this.selectedTaskAndRole.roleName);

                        }else if (docOco.properties.hasOwnProperty(attr)){
                            // check if the attribute isn't repeating and is just a string
                            if (!Array.isArray(docOco.properties[attr])){
                                configuredGroupName = configuredGroupName.replace("$" + attr + "$", docOco.properties[attr]);
                            }
                        }
                    },this);

                    // set the groupname now that the attributes are injected
                    this.groupName = configuredGroupName;
                }

            }else{
                this.groupName = HPIConstants.WizardGroups.WizardContributorGroup;
            }
        },
        startListening: function(){
            if(this.typeahead){
                this.stopListening(this.typeahead);
                this.listenTo(this.typeahead, 'change:selected', function(option){
                    if(option){
                        this.selectedUserEventHandler(option);
                    }
                    else{
                        this.selectedUser = '';
                        this.dialog(false);
                        this.validSubmitData(false);
                    }
                }, this);

                this.listenTo(this.typeahead, 'typeahead:clear', function(){
                    this.clearUserInput();
                }, this);
            }
        },
        sanitizeKey: function(evt){
            //catch the enter key to prevent the query text being set as the selected user
            var code = evt.keyCode || evt.which;
            if(code==13){
                //prevent default for enter key only
                evt.preventDefault();
            }
        },
        beforeRender: function(){
            if(this.typeahead){
                //setView broke listeners so rebuild typeahead on every re-render
                this.setView('#delegateTask-userList', this.typeahead);
            }          
        },
        serialize: function(){
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                availableTasksAndRoles: this.availableTasksAndRoles,
                multipleTask: this.multipleTask,
                groupName: this.groupName
            };
        },
        clearUserInput: function(){
            var self = this;
            self.selectedUser = '';
            self.selectedUserLabel = '';
            self.isLastUserSelectionValid = false;
            self.dialog(false);
            self.validSubmitData(false);
        },
        onSubmit: function(){
            var self = this;
            //disable submit button while call is happening.
            self.toggleSubmit(false);

            //must have selected task
            var taskId = self.selectedTaskAndRole.taskId;
            var roleName = self.selectedTaskAndRole.roleName;
            //todo get rid of these error catches, form validation takes care of this.
            if(taskId === undefined){
                app[self.myHandler].trigger("showError", window.localize ("modules.actions.delegateWizardWorkflowTask.unableToDelegate"));
            }else if( self.selectedUser === undefined || self.selectedUser === '' ) {  //selectedUser() must have a value selected
                app[self.myHandler].trigger("showError",  window.localize ("modules.actions.delegateWizardWorkflowTask.mustSelect"));
            }else{
                self.action.get("parameters").taskId = taskId;
                self.action.get("parameters").newUserLoginName = self.selectedUser;
                self.action.get("parameters").roleName = roleName;

                self.action.execute({
                    success : function() {
                        app[self.myHandler].trigger("showMessage",  window.localize ("modules.actions.delegateWizardWorkflowTask.taskDelegatedTo") + self.selectedUserLabel + ".");

                        app.listenToOnce(app[self.myHandler], "hide", function() {
                            app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
                        });
                    },
                    error : function(jqXHR) {
                        app[self.myHandler].trigger("showError",  window.localize ("modules.actions.delegateWizardWorkflowTask.failedToDelegate") + jqXHR.status + " " + jqXHR.statusText);
                    }
                });
            }
        }, 
        getTaskAndUserInfo: function(){
            var self = this;
            return $.ajax({
                url: app.serviceUrlRoot + "/aw-workflow/getMyWizardTasks?formId=" + self.objectId,
                success: function(result){
                    _.each(result, function(item) {
                        self.availableTasksAndRoles.push({roleName : item.roleName, taskId : item.id});
                        if(result.length === 1){
                            self.selectedTaskAndRole = {roleName : item.roleName, taskId : item.id};
                            self.multipleTask = false;
                        }else{
                            self.multipleTask = true;
                        }
                        self.usersWhoHaveTasks.push({authorityId : item.assignee});
                    });
                 },   
                error: function() {
                    app[self.myHandler].trigger("loading", false);
                    app[self.myHandler].trigger("showError",  window.localize ("modules.actions.delegateWizardWorkflowTask.failedToRetrieveTask"));
                }
            }); 
        },
        selectedUserEventHandler: function(userSelected){
            var self = this;
            //clear any previous validation
            $('.alert-danger').hide();
            $('.alert-success').hide();
            self.toggleSubmit(false);
            self.selectedUser = userSelected.authorityId;
            self.selectedUserLabel = userSelected.displayName;
            var valid = true;
            _.each(self.usersWhoHaveTasks, function(user){
                if (user.authorityId === self.selectedUser){
                    $('.alert-danger').html( window.localize ("modules.actions.delegateWizardWorkflowTask.selectedUser"));
                    $('.alert-danger').show();
                    valid = false;
                    self.isLastUserSelectionValid = false;
                }
            });
            if (valid) {
                self.isLastUserSelectionValid = true;
                self.evaluateValidity();
            }
        },
        validSubmitData: function(valid){
            var self = this;
            if (valid) {
                //then we show user feedback showing them what they're about to do
                self.dialog(true,  window.localize ("modules.actions.delegateWizardWorkflowTask.toDelegateThis")+ self.selectedUserLabel +  window.localize ("modules.actions.delegateWizardWorkflowTask.inRole")+
                             self.selectedTaskAndRole.roleName +  window.localize ("modules.actions.delegateWizardWorkflowTask.pressDelegateTask"));
                self.toggleSubmit(true);

            } else {
                //then we disable Submit button and... show error? TODO decide
                self.dialog(false);
                $('.alert-danger').hide();                    
                self.toggleSubmit(false);
            }
        },
        dialog: function(show, html){
            if (show) {
                $('.alert-success').html(html);
                $('.alert-success').show();
            }
            else {
                $('.alert-success').hide();
            }
        },
        toggleSubmit: function(enabled){
            if(enabled) {
                document.getElementById('delegateTask-submitBtn').disabled = false;
            }
            else {
                document.getElementById('delegateTask-submitBtn').disabled = true;
            }
        },
        evaluateValidity: function(){
            //if we have all the necessary pieces
            if (this.selectedUser && this.selectedTaskAndRole.roleName && this.selectedTaskAndRole.taskId){
                //If the last selection was invalid, we don't want to remove the alert-danger
                //which occurs inside validSubmitData(false)
                if(this.isLastUserSelectionValid){
                    this.validSubmitData(true);
                }
                else {
                    this.dialog(false);
                    this.toggleSubmit(false);
                }
            }
            else {
                this.validSubmitData(false);
            }
        },
        selectRole: function(){
            var data = $("#delegateTask-roleList option:selected").val();
            var parseData = JSON.parse(data);
            this.selectedTaskAndRole = {roleName: parseData.roleName, taskId: parseData.taskId};
            this.evaluateValidity();
        }
    });
    
    actionModules.registerAction("delegateWizardWorkflowTask", DelegateWizardWorkflowTask, {
       "actionId" : "delegateWizardWorkflowTask",
        "label" :  (window.localize ("modules.actions.delegateWizardWorkflowTask.delegateWizardTask")),
        "icon" : "user",
        "groups" : ["wizard", "delegate", "task"]
    });

    return DelegateWizardWorkflowTask;
});
require(["delegatewizardworkflowtask"]);