// Advancedsearch module
define("sendtodocusign",[
  // Application.
  "app",
  "handlebars",
  "modules/actions/actionmodules",
  "modules/common/action",
  'foldernotes'
],

// Map dependencies from above array.
function(app, Handlebars, actionModules, Action, FolderNotes) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    var validateEmail = function (email) {
        var emailReg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return emailReg.test(email);
    };

    action.Localizations = {
        'error': {
            'invalid:to:address'    : (window.localize("modules.actions.sendToDocUSign.invalidEmailAddress"))
        }
    };


    action.View = Backbone.Layout.extend({
        template: "actions/sendtodocusign",
        events: {
            "click .glyphicon-remove-circle" : "removeClicked",
            "click #sendToDocuSignButton": "sendToDocUSign",
            "keyup #inputDocusign": "checkEnterOrTab",
            "blur #inputDocusign" : "onBlur",
            "click #addEmailDoc" : "clickAdd"
        },
        initialize: function(){
            var self = this; 
            this.handler = self.config.get("handler");
            this.anchorString = self.config.get("anchorString");
            this.tabs = self.config.get("tabs");
            this.toRecipientsView = new action.ToRecipientsView();
            this.setUpInput({});
            
            this.listenTo(this, 'sendtodocusign:createFolderNote', function(emails) {
                // create the folder notes action with our data
                FolderNotes.Service.execute({
                    parmeters: {
                        parentID: app.context.container.get("objectId"),
                        note_content: app.context.document.get("properties").title + (window.localize("modules.actions.sendToDocUSign.hasBeenSignedBy")) + emails,
                        note_rel_type: "hpi:folder_note",
                        note_object_type: "HPI Note",
                        property_map: {
                            objectName: app.context.document.get("properties").title + (window.localize("modules.actions.sendToDocUSign.hasBeenSigneds")) + new Date().getTime(),
                            note_type: (window.localize("modules.actions.sendToDocUSign.sentViaDocuSign"))
                         }
                    }
                });
            });
        },
        setUpInput: function(users){
            var self = this;
            if(self.rendered){
                self.setViews({
                    "#toRecipientsSubview": self.toRecipientsView
                }).render();
            }else{
                self.setViews({
                    "#toRecipientsSubview": self.toRecipientsView
                });
            }
        },
        checkEnterOrTab: function(evt){
            if(evt.keyCode === 13){
                this.addTo($("#inputDocusign").val());
            }
        },
        onBlur: function(){
            this.addTo($("#inputDocusign").val());
        },
        clickAdd: function(){
            this.addTo($("#inputDocusign").val());
        },
        addTo: function(object) {
            if(object) {
                if(validateEmail(object)) {
                    this.toRecipientsView.showErrorMessage = false;
                    this.toRecipientsView.addedEmailAddresses.push({ emailAddress: object, name: object, isTo: true});
                    this.toRecipientsView.render();
                    $("#inputDocusign").val('');
                }
                else {
                    this.toRecipientsView.showErrorMessage = true;
                    this.toRecipientsView.render();
                }
            }
        },
        removeClicked: function(event){
            var value = $(this.$(event.currentTarget).parent()).text().trim();

            if (value){
                this.toRecipientsView.addedEmailAddresses = _.filter(this.toRecipientsView.addedEmailAddresses, function(user){
                    return user.emailAddress != value;
                });
                this.toRecipientsView.render();
            }
        },
        sendToDocUSign: function() {
            var self = this;
            $("#sendToDocuSignButton").prop("disabled", true);
            $("#sendToDocuSignButton").addClass("disabled");
            self.action.get("parameters").emails = _.pluck(self.toRecipientsView.addedEmailAddresses, "emailAddress");
            self.action.get("parameters").anchorString = self.anchorString;
            //Getting rid of tab types with no more tabs so that the request doesn't fail from incorrect formatting.
            _.each(_.keys(self.tabs), function(key){
                if(self.tabs[key].length === 0){
                    delete self.tabs[key];                    
                }
            });
            self.action.get("parameters").tabs = self.tabs;
            self.action.execute({
                success: function(data){
                    app[self.handler].trigger( "showMessage", (window.localize("modules.actions.sendToDocUSign.documentSuccessfully")));
                    if(self.config.get("folderNotes") === "true"){
                        self.trigger('sendtodocusign:createFolderNote', self.action.get("parameters").emails);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown){
                    app[self.handler].trigger("showError", jqXHR.responseText);
                }
            });
        },
        afterRender: function(){
            this.rendered = true;
        },
        serialize: function(){
            var modal = false;
            var rightSide = false;
            if (this.handler === "modalActionHandler") {
                modal = true;
            } else if (this.handler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                whyCantIActions: this.action.get("whyCantIActions"),
                anchorString: this.anchorString,
                tabs : this.tabs
            };
        }
    });

    action.ToRecipientsView = Backbone.Layout.extend({
        template: "actions/sendemail/sendemailrecipients",
        initialize: function(){
            this.addedEmailAddresses = [];
            this.showErrorMessage = false;
            this.errorMessage = action.Localizations.error['invalid:to:address'];
        },
        validate: function(){
            if(this.addedEmailAddresses.length > 0){
                $("#sendToDocuSignButton").removeClass("disabled");
            }
            else{
                $("#sendToDocuSignButton").addClass("disabled");
            }
        },
        afterRender: function(){
            this.validate();
        },
        serialize: function(){
            return {
                addedEmailAddresses : this.addedEmailAddresses,
                showErrorMessage : this.showErrorMessage,
                errorMessage : this.errorMessage
            };
        }
    });
    
    action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/sendtodocusignconfig",
        events: {
            "click #add-tab" : "addTab",
            "click #remove-tab" : "removeTab",
            "keyup #anchor-text" : "validate"
        },
        initialize: function(){
            this.viewModel = this.options.viewModel;
            this.viewModel.anchorString = kb.observable(this.viewModel.model(), "anchorString");
            this.viewModel.tabs = kb.observable(this.viewModel.model(), "tabs");
            
            //whether or not to create a Folder Note after document upload
            if(!this.viewModel.model().folderNotes){
                this.viewModel.model().folderNotes = false;
            }
            this.viewModel.folderNotes = kb.observable(this.viewModel.model(), "folderNotes");
            
            if(this.viewModel.folderNotes() === "false" ) {
                this.viewModel.folderNoteType(false);
            }
            
            this.viewModel.folderNoteType = kb.observable(this.viewModel.model(), "folderNoteType");
            
            if(!this.viewModel.folderNoteType()) {
                this.viewModel.folderNoteType("HPI Note");
            }
        },
        //Adding a tab
        addTab: function(e){
            e.preventDefault();
            //Making sure the tabs observable is instantiated.
            if(!this.viewModel.tabs()){
                this.viewModel.tabs({});
            }
            //If there is already a tab of this type added, we can just push it on the array.
            if(this.viewModel.tabs()[$("#tab-type").val()]){
                this.viewModel.tabs()[$("#tab-type").val()].push({
                    "tabType" : $("#tab-type").val(),
                    "anchorString" : $("#anchor-text").val()});
            } 
            //This is the first tab of this type to be added, we need to make the array first.
            else{
                this.viewModel.tabs()[$("#tab-type").val()] = [];
                this.viewModel.tabs()[$("#tab-type").val()].push({
                    "tabType" : $("#tab-type").val(),
                    "anchorString" : $("#anchor-text").val()});
            }
            this.updateCurrentTabs();
        },
        //Removing a tab when the X is clicked
        removeTab: function(e){
            var tabType = e.target.parentElement.className;
            var anchorString = e.target.parentElement.getAttribute("value");
            var tabToRemove = _.findWhere(this.viewModel.tabs()[tabType], {"anchorString": anchorString});
            this.viewModel.tabs()[tabType] = _.without(this.viewModel.tabs()[tabType], tabToRemove);
            this.updateCurrentTabs();
        },
        updateCurrentTabs: function(){
            //Clearing tabs on DOM
            $("#current-tabs").empty();
            //Adding them back
            _.each(this.viewModel.tabs(), function(tabType){
                _.each(tabType, function(singleTab){
                    if(typeof singleTab === "object"){
                        $("#current-tabs").append('<div><li value="' + singleTab.anchorString + '" class="' + singleTab.tabType + '">' + "<strong>" + singleTab.tabType + "&nbsp;&nbsp;&nbsp;&nbsp;</strong>" + singleTab.anchorString + '<span class="glyphicon glyphicon-remove pull-right" id="remove-tab"></span></li></div>');
                    }
                });
            });
        },
        //Controlling the button so only valid tabs will be added.
        validate: function(){
            if($("#anchor-text").val().length > 0 && $("#tab-type").val()){
                $("#add-tab").attr("disabled", false);
            } else{
                $("#add-tab").attr("disabled", true);
            }
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
            this.updateCurrentTabs();
        }
    });

    actionModules.registerAction("sendToDocuSign", action, {
        "actionId" : "sendToDocuSign",
        "label" : (window.localize("modules.actions.sendToDocUSign.sendToDocuSign")),
        "icon" : "disk-export"
    });

    return action;

});
require(["sendtodocusign"]);