// delete document
define("bulkproperties",[
    // Application.
    "app",
    "underscore",
    "oc",
    "modules/actions/actionmodules",
    "modules/formsupport",
    "modules/common/spinner",
    "modules/common/action",
    "modules/common/propertiesview",
    "foldernotes",
    "handlebars"
  ],
  
  // Map dependencies from above array.
  function(app, _, OC, actionModules, FormSupport, HPISpinner, Action, PropertiesView, FolderNotes, Handlebars) {
      "use strict";
      //Start with declaring your id - this is the same value as in the filename between the words action. and .js
      //get the config from the namespace. The action handler is responsible for this; //
      var BulkProperties = app.module();
  
      BulkProperties.checkPermission = function(id){
          return $.ajax({
              url: app.serviceUrlRoot + "/permission/write?id=" + id,
              global: false
          });
      };
  
      var mergingAttributes = function(objectProperties, bulkProperties) {
          var result = {};
          var i = 0;
  
          _.each(bulkProperties, function(value, key, oco) {
              if(_.isArray(value)) {
                  var combinedArray = [];
                  if(!(_.isEmpty(objectProperties[key]))){
                       combinedArray = objectProperties[key];
                  }
                  for(i=0; i<value.length; i++) {
                      combinedArray.push(value[i]);
                  }
                  
                  result[key] = key === "hpi_folderTags" ? _.uniq(combinedArray) : combinedArray;
              }
              else {
                  if(value !== null) {
                      result[key] = value;
                  }
                  else {
                      result[key] = objectProperties[key];
                  }
              }
          });
          return result;
      };
  
      BulkProperties.fetchOcos = function(objectIds, that) {
  
          var jqxhrs = [];
          //create an oco collection with the object ids and load it up.
          var ocoCollection = that.ocoCollection = new OC.OpenContentObjectCollection();
          var unWriteable =[];
          _.each(objectIds, function(objectId){
              //check permission
              var permJqxhr =  BulkProperties.checkPermission(objectId).done(function(){
                  //a little IIF to preseve the scope of i
                  var id = objectId;
                  return function(canWrite){
                      if(!canWrite){
                          unWriteable.push(id);
                      }
                  };
              }());
              jqxhrs.push(permJqxhr);
              var oco = new OC.OpenContentObject( { objectId : objectId } );
              jqxhrs.push(oco.fetch({global: false}));
              ocoCollection.add(oco);
          });
  
          var names = this.names = [];
  
          //we are going to wait until all the objects are loaded. This could potentially be slow
          //we need to test wil many items.
          $.when.apply(null, jqxhrs).done(function(){
              that.toggleLoader(false);
              that.originallyFetchedOcos = $.extend(true, {}, ocoCollection.toJSON());
              //if we can't right just show an error:
              if(unWriteable.length > 0){
                  _.each(unWriteable, function(objectId){
                      var object = ocoCollection.findWhere({objectId : objectId});
                      if(object){
                          names.push(object.get("properties").objectName);
                      }
                  });
                  app[that.myHandler].trigger("showError",
                      (window.localize("modules.actions.bulkProperties.youMustHave")) + 
                      names.join(", "));
              }else{
                  that.fileNames = [];
                  that.ocoCollection.each(function(oco){
                      that.fileNames.push(oco.get('properties').objectName);
                  }, this);
                  if(that.rendered){
                      var controls = new BulkProperties.PaginationControls({
                          showIndex: false,
                          showRequired: false,
                          hasNext: true,
                          hasPrevious: false,
                          allowFinish: true
                      });
                      that.setView("#bulkproperties-pagination-controls", controls).render();
  
                      that.render();
                  }
              }
          });
      };
  
      //Factored this bulk properties propagation out for use when a user
      //eleccts to commit all changes rather then go through FormSupport
      BulkProperties.setAndPropagateBulkProperties = function(bulkProperties, bulkPropertiesObjectType, ocoCollection, formName) {
          var that = this;
  
          // this will be undefined if we're only uploading one document
          var selectedObjectType = bulkPropertiesObjectType;
  
          // this method could be asynchronous if we have to fetch the type configuration from the OTC, so we
          // return a deferred so callers can know when we're done
          var deferred = $.Deferred();
  
          // we won't have a selected object type if they are uploading one document and they are not limiting the object types
          // to one type - in that case we have to wait for the user to choose the object type they want
          if(selectedObjectType) {
              app.context.configService.getFormTypeConfig(formName, selectedObjectType, function(config) {
                  var configuredAttrs = _.union(config.get("configuredAttrsPri").models, config.get("configuredAttrsSec").models);
                  var objectNameAttr = _.filter(configuredAttrs, function(attr) {
                      return attr.get("ocName") === "objectName";
                  }, this)[0];
  
                  ocoCollection.each(function(oco, index) {
                      if (!oco.get("havePropertiesBeenPropagated")) {
                          //if bulkproperties has something the oco doesn't, we need to add the key but with a null to the oco
                          var keyDifference = _.difference(_.keys(bulkProperties), _.keys(oco.get("properties")));
                          var objectProperties = oco.get("properties");
  
                          //only overrite objectTypes that are of the same type as the master
                          if(oco.get('objectType') === selectedObjectType){
                              _.each(bulkProperties, function(value, key, oco){
                                  //delete key:value if the value is blank, undefined, or an empty array (for repeating support)
                                  if(!value || (_.isArray(value) && _.isEmpty(value))){
                                      delete bulkProperties[key];
                                  } else {
                                      var combinedArray = [];
                                      var i = 0;
                                      //can only trim strings, not numbers
                                      if(_.isString(value)){ //string, check if empty
                                          if(_.isArray(value)) {
                                              combinedArray = [];
                                              for(i=0; i<value.length; i++) {
                                                  combinedArray.push(value[i].trim());
                                              }
                                              bulkProperties[key] = combinedArray;
                                          } else {
                                              bulkProperties[key] = value.trim();
                                          }
                                      } else { //not a string
                                          if(_.isArray(value)) {
                                              combinedArray = [];
                                              for(i=0; i<value.length; i++) {
                                                  combinedArray.push(value[i]);
                                              }
                                              bulkProperties[key] = combinedArray;
                                          } else {
                                              bulkProperties[key] = value;
                                          }
                                      }
                                  }
                              }, that);
  
                              //we now add back the differences of the keys, this was causing oco probles with sequential props
                              _.each(keyDifference, function(key) {
                                  if(bulkProperties[key] === null) {
                                      bulkProperties[key] = null;
                                  }
                                  objectProperties[key] = null;
                              });
  
  
                              var mergedAttributes = mergingAttributes(objectProperties, bulkProperties);
  
                              oco.set('properties', _.extend(oco.get('properties'), bulkProperties, mergedAttributes));
                              oco.set("havePropertiesBeenPropagated", true);
                          }
  
                          //if not configured as a computed value,
                          //use the file name as a placeholder in the name field of the oco
                          //ONLY if bulk properties hasn't already injected something
                          if(objectNameAttr && objectNameAttr.get("controlType") !== 'Computed' && !oco.get('properties').objectName){
                              oco.get('properties').objectName = this.options.fileNames[index];
                          }
                      }
                  }, that);
  
                  deferred.resolve();
              }, app.context.configName());
          } else {
              // we're uploading one document and we're not limiting object types to just one type so let's resolve so the user
              // can choose the object type they want to use for this document
              deferred.resolve();
          }
  
          return deferred.promise();
      };
  
      BulkProperties.View = Backbone.Layout.extend({
          template: "actions/bulkproperties",
          initialize: function(){
              this.myHandler = this.options.config.get("handler");
              this.isCustomBulkPropertiesFormConfigured = this.options.config.get("isCustomBulkPropertiesFormConfigured") === 'true';
              this.bulkPropertiesForm = this.options.config.get("bulkPropertiesForm");
              this.formName = this.options.config.get("form");
              this.searchResultsViewController = this.options.searchResultsViewController;
              this.action = this.options.action;
              this.objectIds = this.action.get('parameters').objectIds;
              
              // Setup all our listeners on this view
              this._startListening();
  
              // Toggle loader before fetching the ocos of the provided object ids in the action's parameters
              this.toggleLoader(true);
              BulkProperties.fetchOcos(this.objectIds, this);
          },
          _startListening: function() {
              this.listenTo(app, 'bulkproperties:allOcosValid', this._resolveAllOcosValid);
  
              // once the user clicks next, we're going to load our sequential properties view
              this.listenToOnce(app, "bulkproperties:nextPressed", this.loadSequentialPropertiesView);
  
              this.listenTo(app, 'bulkproperties:setupSequentialProperties', this.setupSequentialProperties);
  
              this.listenTo(app, 'bulkproperties:goToBulkProperties', this.goToBulkProperties);
  
              this.listenTo(app, 'bulkproperties:onFinish', this.commitPropertyChanges);
  
              // Listen for bulk properties auto-finish
              this.listenToOnce(app, 'bulkproperties:commitchanges', this.commitPropertyChanges);
          },
          _resolveAllOcosValid: function(deferred){
              deferred.resolve(this.sequentialProperties._allOcosValid());
          },
          setupSequentialProperties: function(objectType, bulkProperties, collection){
              // set up the properties view and pass it the collection of objects
              this.sequentialProperties = new BulkProperties.SequentialPropertyEditingView({
                  objectType: objectType,
                  ocoCollection: collection,
                  bulkProperties: bulkProperties,
                  fileNames: this.fileNames,
                  formName: this.formName
              });
              
              // we don't want sequential properties to be listening for anything when we first initialize it
              // if you want sequential properties to listen to something, use the startListening method
              this.sequentialProperties.stopListening();
          },
          goToBulkProperties: function() {
              // refretch the ocos
              // TODO: would be nice to have original oco's cached after first request
              BulkProperties.fetchOcos(this.objectIds, this);
  
              this.tracker = new BulkProperties.Tracker({
                  fileNames: this.fileNames,
                  ocoCollection: this.ocoCollection
              });
  
              this.setView('#tracker-section', this.tracker).render();
              
              var controls = new BulkProperties.PaginationControls({
                  showIndex: false,
                  showRequired: false,
                  hasNext: true,
                  hasPrevious: false,
                  allowFinish: true
              });
  
              this.setView("#bulkproperties-pagination-controls", controls).render();
  
              // we're already listening to the nextPressed button click (when we initalized this view) and if we don't stop listening
              // before we listen to the event, we'll end up listening to the event twice which will cause bad behavior (cause form support
              // to be generated twice - trust me, you don't want that to happen)
              this.stopListening(app, "bulkproperties:nextPressed").listenToOnce(app, "bulkproperties:nextPressed", this.loadSequentialPropertiesView);
          },
          toggleLoader: function(bool){
              app[this.myHandler].trigger("loading", bool);
          },
          // to upload, the app triggers this event itself in accept file list
          loadSequentialPropertiesView: function(gotoIndex) {
              var self = this;
  
              var bulkPropertiesObjectType = '';
              var bulkProperties = {};
  
              gotoIndex = (gotoIndex ? gotoIndex : 0);
  
              this.collection = new OC.OpenContentObjectCollection();
              this.collection = this.ocoCollection.clone();
  
              // if we have more than one file, then we've built a bulk properties view and have possibly gotten
              // starting properties from inheritance and user entry into the bulk properties form
              if(this.fileNames.length > 1) {
                  if(this.bulkPropertiesView){
                      // let's grab our starting properties from bulk properties
                      bulkProperties = this.bulkPropertiesView.getBulkProperties();
                      // let's get our selected object type the user chose for all the documents to be uploaded
                      bulkPropertiesObjectType = this.bulkPropertiesView.getBulkPropertiesObjectType();
                  }
              }else{
                  bulkPropertiesObjectType = this.ocoCollection.models[0].get('objectType');
              }
  
              // this will happen if the app triggered this method itself (there is only one document to upload)
              if(!this.sequentialProperties) {
                  // set up the sequential properties view and pass it the collection of objects
                  // we don't have an object type to pass in here
                  this.sequentialProperties = new BulkProperties.SequentialPropertyEditingView({
                      ocoCollection: this.collection,
                      bulkProperties: bulkProperties,
                      fileNames: this.fileNames,
                      objectType: bulkPropertiesObjectType,
                      formName: this.formName
                  });
                  this.sequentialProperties.stopListening();
              }
  
              $.when(BulkProperties.setAndPropagateBulkProperties(bulkProperties, bulkPropertiesObjectType, this.collection, this.formName)).done(function() {
                  // set our properties-section outlet with our sequential properties view - this will replace the bulk properties
                  // view that was there if there was more than one document to upload
                  self.setView('#properties-section',  self.sequentialProperties).render();
  
                  // check to see if we can go "Next" past the document we're navigating to
                  var hasNext = self.sequentialProperties._canGoto(gotoIndex + 1);
                  // check to see if we can go "Previous" before the document we're navigating to
                  var hasPrevious = self.sequentialProperties._canGoto(gotoIndex - 1);
  
                  app.trigger('bulkproperties:controls:update', {
                      // we're going to start at the first document to upload
                      currentIndex: gotoIndex + 1,
                      // we pass this in so we can get the number of total docs we're trying to upload (for "1 of 3")
                      numDocsToUpload: self.fileNames.length,
                      // i.e. show "1 of 3"
                      showIndex: true,
                      hasNext: hasNext,
                      hasPrevious: hasPrevious
                  });
  
                  self.sequentialProperties.startListening();
              });
          },
          createFolderNotes: function(ocos,originalOcos,fieldsOnForm){
              var self = this;
              //As long as configs for folders/documents are on, create folder notes on property change
              _.each(ocos.models,function(oco){
                  var currentDate = DateFormat.format.date(new Date(),"E, d MM yyyy hh-mm-ss sss");
                  //need to loop each oco and create notes if necessary
                  var oldOco = _.find(originalOcos,function(oldObj){
                      return oldObj.objectId === oco.id;
                  });
                  //need to grab our old oco
                  app.context.configService.getAdminOTC(function(otc) {
                      var attrNameArray = [];
                      var oldValueArray = [];
                      var newValueArray = [];
                      var type,note_type,objectName,noteContent,parentID;
  
                      app.context.util.getParents(oco.get("properties").objectId, function(fetchedParents) {
  
  
                          var valChange = false;
                          self.otc = otc;
                          //Find changed values and put them in corresponding arrays
                          _.each(_.keys(oco.get("properties")), function(newKey){
                              if(fieldsOnForm.indexOf(newKey) === -1){
                                  //if this field isn't even on our form, were going to skip to the next one
                                  return;
                              }
                              var newKeySansProp = newKey.replace("prop-", "");
                              var tempNewValue = oco.get("properties")[newKey];
                              var tempOldValue;
                              var path;
                              var objectType = oco.get("objectType");
                              var otcObjectType = self.otc.get('configs').where({'ocName': objectType})[0];
                              self.type = otcObjectType.get('attrs').where({'ocName': newKeySansProp})[0].get('dataType');
  
                              type = otcObjectType.get("isContainer") === 'false' ? "document" : "folder";
                              tempOldValue = oldOco.properties[newKeySansProp];
                              objectName = oldOco.properties.objectName;
                              path = oldOco.objectType;
  
                              if(type ==='document'){
                                  if(self.config.get("enableDocumentNoteRelation") && self.config.get("enableDocumentNoteRelation") === 'true'){
                                       parentID = oldOco.properties.objectId;
                                  }else{
                                  parentID = fetchedParents[0].objectId;
                                  }   
                              }else{
                                  parentID = oldOco.properties.objectId;
                              }
  
                              var arrayValueChange = true;
                              if(_.isArray(tempNewValue) && _.isArray(tempOldValue)){
                                  //if both are arrays, check equality
                                  arrayValueChange = !(_.isEmpty(_.difference(tempNewValue, tempOldValue)) && _.isEmpty(_.difference(tempOldValue, tempNewValue)));
                              }else if(_.isArray(tempNewValue) && !_.isArray(tempOldValue)){
                                  //if only the new val is an array, the old value didnt exist
                                  if(tempNewValue.length <= 0){
                                      arrayValueChange = false;
                                  }
                              }
                              if(tempNewValue || tempOldValue){
                                  //only check equality if one of these is actually a value. not both null,undefined, empty
                                  if(!_.isEqual(tempNewValue,tempOldValue) && arrayValueChange){
                                      var tempAttrName;
                                      valChange = true;
                                      app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
                                          app.context.configService.getLabels(path, newKeySansProp).done(function(label){
                                              tempAttrName = label;
                                              attrNameArray.push(tempAttrName);
                                              if(self.type === "date") {
                                                  var oldVal = moment(tempOldValue).format(dateTimeFormat.dateFormat);
                                                  var newVal = moment(tempNewValue).format(dateTimeFormat.dateFormat);
                                                  oldValueArray.push(oldVal);
                                                  newValueArray.push(newVal);
                                              } else {
                                                  oldValueArray.push(tempOldValue);
                                                  newValueArray.push(tempNewValue);
                                              }
                                          });
                                      });
                                  }
                              }
                          });  //end each keys
  
                          if(valChange){
                              noteContent = "<p>User " + app.user.get("displayName") + " edited propert(ies) of " + "<a class='stageLink' documentId='" + oco.get("properties").objectId + "'>" + objectName + "</a>" + " and changed ";
                              _.each(attrNameArray, function(object, index) {
                                  if(attrNameArray[index+1] !== undefined) {
                                      noteContent = noteContent + object + ", ";
                                  } else {
                                      noteContent = noteContent + object + "; and changed value(s) ";
                                  }
                              });
                              _.each(oldValueArray, function(object, index) {
                                  if(oldValueArray[index+1] !== undefined) {
                                      if(newValueArray[index].length < 1) {newValueArray[index] = "No Value";}
                                      if(oldValueArray[index] === null) {oldValueArray[index] = "No Value";}
                                      noteContent = noteContent + "from " + oldValueArray[index] + " to " + newValueArray[index] + "; ";
                                  } else {
                                      if(newValueArray[index].length < 1) {newValueArray[index] = "No Value";}
                                      if(oldValueArray[index] === null) {oldValueArray[index] = "No Value";}
                                      noteContent = noteContent + " from " + oldValueArray[index] + " to " + newValueArray[index];
                                  }
                              });
                              noteContent = noteContent + ".</p>";
                              if(type === "document")
                              {
                                  note_type = "Document Properties Changed";
                              }else{
                                  note_type = "Folder Properties Changed";
                              }
                              //Create Folder Note
                              if(attrNameArray.length !== 0) {
                                  var folderNoteParameters = {
                                      parameters: {
                                          parentID: parentID,
                                          note_content: noteContent,
                                          note_rel_type: self.config.get("folderNoteRelationship"),
                                          note_object_type: self.config.get("folderNoteObjectType"),
                                          property_map:{
                                              note_type: note_type,
                                              objectName: "Folder Note - " + currentDate + '-' + oco.get("properties").objectName
                                          }
                                      }
                                  };
                                  if(self.config.get("enableDocumentNoteRelation") && self.config.get("enableDocumentNoteRelation") === 'true'){
                                      folderNoteParameters.parameters.property_map.note_attachment = parentID;
                                  }
                                  FolderNotes.Service.execute(folderNoteParameters);
                              }
                          }
                      });
                  });
              });
  
          },
          commitPropertyChanges: function(ocos){
              var that = this;
  
              var validOcoList = $.extend(true, [], this.tracker.validOcos);
  
              var ocoCollection = this.ocoCollection = ocos;
  
              this.originalOcos = ocoCollection.clone();
  
              var processingDeferreds = [];
              
              // Creating this deferred so that we don't execute before we even push the other deferred's onto the processingDeferreds array
              var setupCommitPropertyChangesDeferred = $.Deferred();
  			  processingDeferreds.push(setupCommitPropertyChangesDeferred);
              
			  this.toggleLoader(true);
  
              //bulk properties assumes everything is of the same object type, so this is allowed
              var typeName = ocoCollection.models[0].get("objectType");
  
              app.context.configService.getFormTypeConfig(this.formName, typeName, function (formTypeConfig) {
                  app.context.configService.getAdminTypeConfig(typeName, function (typeConfig) {
                      that.firstFailureIndex = null;

                      // We have to compute all of the computed controls - this is the price we pay
                      // for doing computed values on the front end in formsupport
                      ocoCollection.each(function (currentOco, index) {
                          var computedDeferreds = [];
                          var processingDeferred = $.Deferred();
                          var configuredAttrs = _.union(formTypeConfig.get("configuredAttrsPri").models, formTypeConfig.get("configuredAttrsSec").models);

                          processingDeferreds.push(processingDeferred);

                          //we have to compute all of the computed controls - this is the price we pay
                          //for doing computed values on the front end in formsupport
                          _.each(configuredAttrs, function (currentAttrConfig) {
                              var computedDeferred = $.Deferred();

                              if (currentAttrConfig.get("controlType") === "Computed") {
                                  // must be a deferred since parsing dates may require network calls, so just leverage the resulting
                                  // deferred from this function and set it on the one we expect to actually execute the action
                                  computedDeferred = that._processComputedControl(typeConfig, currentAttrConfig, currentOco)
                              } else {
                                  computedDeferred.resolve();
                              }

                              computedDeferreds.push(computedDeferred);
                          }); // end of configuredAttrs loop

                          $.when.apply(null, computedDeferreds).done(function () {
                              //If it is on the valid oco list, then it means that it has been successfully visited, and the properties
                              //have been properly propagated for that specific folder/document, so we don't have to extend the bulk properties
                              //to those documents anymore
                              //validOcoList is a list of indexes for ocos that have been visited by the user, only applies to composite docs.
                              if (_.contains(validOcoList, index + 1) === false) {

                                  var validityDeferred = that._checkOcoValidity(currentOco);

                                  $.when(validityDeferred).done(function (isOcoValid) {
                                      if (!isOcoValid) {
                                          that.tracker.invalidOcos.push(index + 1);
                                          if (that.firstFailureIndex === null) {
                                              that.firstFailureIndex = index + 1;
                                          }
                                      } else {
                                          that.tracker.validOcos.push(index + 1);
                                      }

                                      processingDeferred.resolve();
                                  });
                              } else {
                                  processingDeferred.resolve();
                              }
                          });
                      });

                      setupCommitPropertyChangesDeferred.resolve();
                  });
              });
              
              $.when.apply($, processingDeferreds).done(_.bind(this.executeAction, this));
          },
          _checkOcoValidity: function(oco) {
              var deferred = $.Deferred();
  
              // we'll default to having no starting properties to populate and to enable validation (which will be disabled if we're
              // on the bulk properties page)
              var opts = {
                  objectType: oco.get("objectType"),
                  properties: oco.get("properties"),
                  enableValidation: true
              };
  
              // this properties view model is what form support uses to put its controls on and other functions
              var propertiesViewModel = {};
  
              // init form support - we only want atCreation attributes to show up since we're uploading stuff
              FormSupport.tsgFormSupport(propertiesViewModel, {
                  'isCreate': true,
                  'enableValidation': opts.enableValidation,
                  'formName': this.formName
              });
  
              // set the form control properties once the controls have finished building
              var propViewModelSubscription = propertiesViewModel.controls.subscribe(function() {
                  //since we only need to set these once, dispose afterward
                  propViewModelSubscription.dispose();
                  
                  // set our initial values once the controls have built
                  propertiesViewModel.setValues(opts.properties);
  
                  deferred.resolve(propertiesViewModel.isValid());
              });
  
              // set the object type which will trigger the controls to be generated
              propertiesViewModel.objectType(opts.objectType);
  
              return deferred;
          },
          _processComputedControl: function(typeConfig, currentAttrConfig, currentOco){
              var that = this;
  
              var deferred = $.Deferred();
              
              // So this is fun, but dates are async, so we need a counter to make sure all of them are processed before running the action
              var jqXhrs = [];
              var attrPatternMaps = {};
  
              //there could be multiple attrbites that are computed, so we need a map within the map, with
              //the key being the attribute's ocName
              attrPatternMaps[currentAttrConfig.get("ocName")] = {
                  computedPattern: currentAttrConfig.get("computedPattern")
              };
  
              var patternAttrs = app.context.util.parsePatternForAttributes(currentAttrConfig.get("computedPattern"));
  
              _.each(patternAttrs, function(attr) {
                  var currentValue = currentOco.get("properties")[attr];
                  if ((!_.isArray(currentValue) && currentValue) || (_.isArray(currentValue) && !_.isEmpty(currentValue))) {
                      //if attribute is configured as a date, run it through the dateservice
                      if(typeConfig.get('attrs').findWhere({'ocName': attr}).get('filter') === 'date') {
                          jqXhrs.push(app.context.dateService.getFormattedDate(currentOco.get('properties')[attr]).done(function(formattedDate) {
                              attrPatternMaps[currentAttrConfig.get("ocName")][attr] = formattedDate;
                          }));
                      } else if(typeConfig.get('attrs').findWhere({'ocName': attr}).get('filter') === 'datetime') {
                          jqXhrs.push(app.context.dateService.getFormattedDatetime(currentOco.get('properties')[attr]).done(function(formattedDate) {
                              attrPatternMaps[currentAttrConfig.get("ocName")][attr] = formattedDate;
                          }));
                      } else {
                          attrPatternMaps[currentAttrConfig.get("ocName")][attr] = currentValue;
                      }
                  } else {
                      attrPatternMaps[currentAttrConfig.get("ocName")][attr] = "";
                  }
              });
  
              if (jqXhrs.length > 0) {
                  $.when.apply(null, jqXhrs).done(function(){
                      //build your patternstring up now
                      attrPatternMaps = that._getParsedAttrPatternMaps(attrPatternMaps);
                      currentOco.get("properties")[currentAttrConfig.get("ocName")] = attrPatternMaps[currentAttrConfig.get("ocName")].computedValue;
  
                      deferred.resolve();
                  });
              } else {
                  //no dates in the computed strings
                  //build your patternstring up now
                  attrPatternMaps = that._getParsedAttrPatternMaps(attrPatternMaps);
                  currentOco.get("properties")[currentAttrConfig.get("ocName")] = attrPatternMaps[currentAttrConfig.get("ocName")].computedValue;
                  
                  deferred.resolve();
              }
  
              return deferred;
          },
          _getParsedAttrPatternMaps: function(attrPatternMaps){
              //go through each attribute that has a computed controlType
              _.each(attrPatternMaps, function(value, key) {
                  var computedValue = attrPatternMaps[key].computedPattern;
                  app.log.debug(computedValue);
                  //go through each property found in the computedPattern map
                  _.each(value, function(value, key) {
                      if (_.isArray(value)) {
                          value = value[0];
                      }
                      computedValue = computedValue.replace(key, value);
                  });
                  //get rid of our parser value
                  computedValue = computedValue.replace(/\$/g, "");
                  attrPatternMaps[key].computedValue = computedValue;
              });
  
              return attrPatternMaps;
          },
          executeAction: function(){
              var that = this;
  
              this.action.get("parameters").ocos = this.ocoCollection;
  
              if (this.firstFailureIndex === null) {
                  app.context.configService.getApplicationConfig(function(configs) {
                      that.action.get("parameters").hideFileExtensions = configs.get('hideFileExtensions');
                      // Will evaluate to true if the config has a string "true", if it has a string false, or undefined or anything else, it will be false.
                      that.action.get('parameters').versioning = (that.config.get('enableVersionOnUpdate') === 'true');
  
                      that.action.execute({
                          success: _.bind(that._executeActionSuccessCallback, that),
                          error: _.bind(that._executeActionErrorCallback, that)
                      });
                  });
              } else {
                  // Toggle the loader off
                  this.toggleLoader(false);
  
                  this.tracker.hasBulkCommitValidationError = true;
  
                  // Since bulk properties auto-finish failed due to validation, we need to 
                  // add the listener for commitchanges back onto the view
                  this.listenToOnce(app, 'bulkproperties:commitchanges', this.commitPropertyChanges);
  
                  // Use the tracker to navigate to our failure index
                  this.tracker._goTo(this.firstFailureIndex);
              }
          },
          _executeActionSuccessCallback: function(actionResponse){
              this.toggleLoader(false);
  
              if(this.config.get("folderNotes") && this.config.get("folderNotes") === 'true'){
                  this.createFolderNotes(this.ocoCollection, this.originallyFetchedOcos, actionResponse.parameters.sortFields);
              }
  
              app[this.myHandler].trigger("showMessage", "Properties updated.");
  
              var oldOcos = this.originalOcos;
              var searchResultsViewController = this.searchResultsViewController;
  
              var newOcos = new OC.OpenContentObjectCollection(actionResponse.result);
              var jqxhrArray = [];
  
              // Format the ocos
              _.each(newOcos.models, function(oco) {
                  var typeConfig = $.Deferred();
                  jqxhrArray.push(typeConfig);
                  //store objectTypes in memory
                  app.context.configService.getAdminTypeConfig(oco.get('objectType'), function(otc) {
                      typeConfig.resolve(otc);
                  });
  
                  $.when(typeConfig).done(function(otc) {
                      var formatJqxhr = oco.formatProperties(otc);
                      jqxhrArray.push(formatJqxhr);
                  });
              });
  
              $.when.apply($, jqxhrArray).done(function() {
                  app.trigger("action:bulkProperties-objects-modified", {
                      oldOcos: oldOcos,
                      newOcos: newOcos,
                      searchResultsViewController: searchResultsViewController
                  });
              });
          },
          _executeActionErrorCallback: function(jqXHR, textStatus, errorThrown){
              this.toggleLoader(false);
              app[this.myHandler].trigger("showError", "Sorry, an error has occured. Documents not updated. Contact your administrator." +
                  " " + jqXHR.responseText);
          },
          afterRender: function(){
              this.rendered = true;
              if(this.fileNames && this.fileNames.length > 0){
                  this.tracker = new BulkProperties.Tracker({
                      fileNames: this.fileNames,
                      ocoCollection: this.ocoCollection
                  });
  
                  this.setView('#tracker-section', this.tracker).render();
  
                  //more than one file, load bulk props editor
                  if(this.fileNames.length === 1){
                      this.loadSequentialPropertiesView();
                  }else{
                      // Check if there is a separate form that has been configured for the bulk properties view 
                      var formName = this.formName;
                      if(this.isCustomBulkPropertiesFormConfigured) {
                          formName = this.bulkPropertiesForm;
                      }
  
                      this.bulkPropertiesView = new BulkProperties.BulkPropertiesView({
                          bulkPropertiesObjectType: this.ocoCollection.pluck('objectType')[0],
                          ocoCollection: this.ocoCollection,
                          formName: formName
                      });
                      
                      this.setView('#properties-section', this.bulkPropertiesView).render();
                  }
              }
  
              var controls = new BulkProperties.PaginationControls({
                  showIndex: false,
                  showRequired: false,
                  hasNext: true,
                  hasPrevious: false,
                  allowFinish: false
              });
              this.setView("#bulkproperties-pagination-controls", controls).render();
          }
      });
  
      BulkProperties.Tracker = Backbone.Layout.extend({
          template: "actions/bulkproperties/bulkproperties-tracker",
          events: {
              "click .uploadDoc": "goToEventHandler",
              "click #confirmBulkProperties": "goToBulkProperties",
              // the button "No" that represents the user does not want to go back to bulk properties
              "click #cancelBulkProperties": "cancelBulkProperties"
          },
          initialize: function(options){
              var that = this;
              this.currentIndex = 0;
              this.fileNames = options.fileNames;
              this.ocos = options.ocoCollection;
              this.invalidOcos = [];
              this.validOcos = [];
              // When initialized, there is no bulk properties validation error
              this.hasBulkCommitValidationError = false;
  
              this.hasImages = false;
              // this is a handlebars helper for building an element when a new file is chosen for upload
              // and for building the document status markers on the status bar
              Handlebars.registerHelper('tracker', function(fileNames, options) {
                  // we're going to construct our HTML and return it
                  var html = '';
  
                  // this counter is for separating the filenames into sections that will scroll together
                  // when the user clicks the next or previous arrows on the status bar
                  var i = 0;
  
                  // loop over each of the individual file names to upload and build their HTML
                  _.each(fileNames, function(fileName, index) {
                      // if our counter is at 0, we're creating a new group of document name labels to scroll together
                      if(i === 0) {
                          html += "<div>";
                      }
  
                      // index is 0 based and we want to be 1-based
                      var offset = index + 1;
  
                      html += '<div class="acceptedDoc">';
                      html += '<div class="tracker-wrapper">';
                      html += '<div id="bulkproperties-tracker-' + offset + '" class="uploadLabel';
  
                      if(offset === that.currentIndex) {
                          // we are dealing with the current document, let's add the arrow underneath it to
                          // indicate to the user which document is currently being viewed
                          html += ' current-arrow';
  
                          // if this document is valid, let's make it green, otherwise make it blue
                          if(_.contains(that.validOcos, offset)) {
                              html += ' btn-success">';
                          } else {
                              html += ' btn-primary">';
                          }
                      } else { // we're building up something other than the current document
                          // if the current document is invalid, we'll make it a btn-danger to make it a red background
                          if(_.contains(that.invalidOcos, offset)) {
                              html += ' uploadDoc btn-danger">';
                          } else { // possibly valid or not visited
                              // if the current document is visited (it's also valid) we'll make it green
                              if(_.contains(that.validOcos, offset)) {
                                  html += ' uploadDoc btn-success">';
                              } else { // not visited - let's make the not visited documents a black gradient background
                                  html += ' uploadDoc btn-inverse">';
                              }
                          }
                      }
  
                      html += fileName;
                      //Add the container and image.  Image tags are shrunk in after reader if there are no thumbnails
                      html += '<div class="image-wrapper">';
                      html += '<img id="bulkproperties-image-tracker-' + offset;
                      //Enable/disable the thumbnail by giving assigning it the proper class
                      var fileExtension = fileName.split('.').pop().toLowerCase();
                      if(fileExtension === "jpg" || fileExtension === "jpeg" || fileExtension === "png" || fileExtension === "gif"){
                          html += '" class="previewImage"';
                          that.hasImages = true;
                      }
                      else{
                          html += '" class="disabledImage"';
                      }
                      //Close the image-wrapper, bulkupload-tracker-#, tracker-wrapper, and acceptedDoc div's respectively.
                      html += ' src="" /></div></div></div></div>';
                      // we're done building up this document marker
                      i++;
  
                      // if we've reached the number of documents we can have on a page, let's close the container div
                      // that surrounds that number of documents
                      if(i === that.numDocsPerPage) {
                          html += "</div>";
  
                          // reset our counter so we start building a new container div
                          i = 0;
                      }
                  }, this);
  
                  // if we didn't have a divisible number of documents by the number we can have on a page, we need to close
                  // off the final container div
                  if(i !== 0) {
                      html += "</div>";
                  }
  
                  return html;
              }, this);
  
              this.listenTo(app, 'bulkproperties:nextPressed', function(gotoIndex){
  
                  if(gotoIndex){
                      this.currentIndex = gotoIndex;
                  }
                  else{
                      // both currentIndex and docMarker are 1-based, so we increment first
                      this.currentIndex++;
                  }
  
                  if(this.currentIndex === 1) {
                      // if this document is not already valid, add it to the list of validOcos
                      if(!_.contains(this.validOcos, this.currentIndex)) {
                          this.validOcos.push(this.currentIndex);
                      }
  
                      // remove the document from the invalidOcos array if it's there
                      this.invalidOcos = _.without(this.invalidOcos, this.currentIndex);
                  }
  
                  this.docMarker = this.currentIndex;
                  this.render();
              }, this);
  
              this.listenTo(app, 'bulkproperties:prevPressed', function() {
                  // both currentIndex and docMarker are 1-based
                  this.currentIndex--;
                  this.docMarker = this.currentIndex;
                  this.render();
              }, this);
  
              this.listenTo(app, 'bulkproperties:tracker:update', function(index){
                  // both currentIndex and docMarker are 1-based
                  this.currentIndex = index;
                  this.docMarker = this.currentIndex;
                  this.render();
              });
  
              this.listenTo(app, 'bulkproperties:ocoInvalid', function(index) {
                  // if this document is not already in the invalidOcos array, add it
                  if(!_.contains(this.invalidOcos, index)) {
                      this.invalidOcos.push(index);
                  }
  
                  // remove the document from the validOcos if it's there
                  this.validOcos = _.without(this.validOcos, index);
  
                  this.render();
              }, this);
  
              this.listenTo(app, 'bulkproperties:ocoValid', function(index) {
                  // if this document is not already valid, add it to the list of validOcos
                  if(!_.contains(this.validOcos, this.currentIndex)) {
                      this.validOcos.push(this.currentIndex);
                  }
  
                  // remove the document from the invalidOcos array if it's there
                  this.invalidOcos = _.without(this.invalidOcos, index);
  
                  this.render();
              }, this);
  
              this.listenTo(app, "bulkproperties:isSubmitValid", function() {
                  if(!_.isEmpty(that.invalidOcos)){
                      $("#finishUploadFormBtn").attr('disabled', true);
                  } else{
                      $("#finishUploadFormBtn").attr('disabled', false);
                  }
              });
          },
          // this gets called when a user clicks a document status marker on the status bar or the bulk properties button
          // on the status bar
          goToEventHandler: function(event) {
              // strip bulkupload-tracker prefix and compute the id as an index - the index is -1 if they clicked the bulk properties button
              var index = Number( this.$(event.currentTarget).attr('id').replace(/bulkproperties-tracker-/, '') );
              
              this._goTo(index);
          },
          _goTo: function(index) {
              if(this.currentIndex === 0){
                  app.trigger('bulkproperties:nextPressed', index);
              }
  
              if(!isNaN(index)){
                  // we want to destroy all the tooltips for the document status markers, otherwise they'll stick around on the DOM
                  // and won't hide because their associated DOM element goes away
                  // this.$(".acceptedDoc label").not(".bulk-properties").each(function() {
                  //     $(this).tooltip("destroy");
                  // });
  
                  // index is -1 if they clicked on "Bulk Properties"
                  if(index === -1) {
                      // let's make sure we're not currently on the bulk properties page - if so, there's no warning to display
                      if(this.currentIndex > 0) {
                          // we're not on the bulk properties page so slide down our warning message and options
                          this.$("#bulk-properties-warning").slideDown("fast");
                      }
                  } else { // they clicked on a document to view
                      // the docMarker is the document they clicked on (1-based)
                      this.docMarker = index;
                      // the current index is also the document they clicked on (1-based)
                      this.currentIndex = index;
  
                      app.trigger('bulkproperties:goTo', index);
                      this.render();
                  }
              }
          },
          // this gets called if the user confirms they actually want to go to Bulk Properties by clicking the "Yes" button
          goToBulkProperties: function() {
              // reset our current index to 0
              this.currentIndex = 0;
              // our docMarker is 0 (so we scroll back to the first page of documents)
              this.docMarker = 0;
              // reset our valid and invalid OCOs (will get rid of the colors)
              this.validOcos = [];
              this.invalidOcos = [];
  
              // go to bulk properties now
              app.trigger('bulkproperties:goToBulkProperties');
          },
          // this gets called if the user cancels their request to go to Bulk Properties by clicking the "No" button - it simply
          // hides the warning
          cancelBulkProperties: function() {
              this.$("#bulk-properties-warning").slideUp("fast");
          },
          afterRender: function() {
              this.hasBulkCommitValidationError = false;
  
              // if we're not on the bulk properties page, let's remove the arrow from the bulk properties button
              if(this.currentIndex > 0) {
                  this.$("#bulkproperties-tracker--1").removeClass("current-arrow");
              }
              // get the amount of space we have to deal with for our status bar
              var statusBarWidth = $("#fileupload-list").width();
  
              // we subtract 175 pixels from the available width, since we've got a Bulk Properties button (120 pixels), a left arrrow (15 pixels),
              // a right facing arrow (15 pixels) and a scrollbar (20 pixels) and we want to space things a little bit
              var scrollerWidth = statusBarWidth - 175;
  
              // if we're at this point, then the Handlebars tracker for generating the containers for the "pages" of documents
              // to scroll through has already executed and it's possible that it ran before we have run this code (i.e., the first time)
              // so the numDocsPerPage will be undefined and once we've calculated the real number of documents per page, we'll re-render
              // so we get the right number of containers
              var previousDocsPerPage = this.numDocsPerPage;
  
              // the minimum width we want for each document marker label is 151px so we should divide our usable space by that
              // to figure out how many documents we can have per page
              this.numDocsPerPage = Math.floor(scrollerWidth / 151);
  
              // if we have room to display more documents than we have, then we should only account for the amount of docs
              // the user is uploading
              var docsToDisplay = this.numDocsPerPage > this.fileNames.length ? this.fileNames.length : this.numDocsPerPage;
  
              // each document label should be our available width for the documents divided by how many we have
              var docWidth = Math.floor(scrollerWidth / docsToDisplay);
  
              // we want a maximum size for our document labels (230 pixels), otherwise they'll stretch a lot and look ridiculous
              docWidth = Math.min(docWidth, 230);
  
              // set the width of the scroller container to be just enough to display however many docs will fit fully on the
              // status bar
              $("#bulkProperties-fileNames").width(docsToDisplay * docWidth);
  
              // update the width of each document status label to be the width we calculated minus the padding (10 on each side) and
              // the border (1 pixel from one side)
              this.$("#bulkProperties-fileNames .acceptedDoc label").width(docWidth - 21);
  
              // initialize our scrollable plugin on that div that we've now resized correctly
              this.$("#bulkProperties-fileNames").scrollable();
  
              // let's figure out the page we should be looking at - if docMarker is defined then they could have clicked
              // on a document on the second, third, fourth, etc. page so we want to seek there
              var page;
              if(!this.docMarker) {
                  // we have no docMarker defined so they either clicked the bulk properties button or are just entering the
                  // bulk properties page for the first time
                  page = 0;
              } else {
                  // docMarker is the index they clicked on so we can figure out what page that is by dividing by the number
                  // of documents we have per page, rounding up to the nearest integer and subtracting 1
                  page = Math.ceil(this.docMarker / this.numDocsPerPage) - 1;
              }
  
              // get the api for our scrollable plugin
              var api = this.$("#bulkProperties-fileNames").data("scrollable");
  
              // go to the page that we should be viewing (0 specifies that we want to go right away)
              api.seekTo(page, 0);
  
              // this is the case above where we've incorrectly (probably) calculated the number of containers we need, since
              // now we know how many documents we can have per page, let's re-render so we get the right number of containers
              if(!previousDocsPerPage) {
                  this.render();
              }
  
              // now that the HTML for the document markers has been created, we want to create a tooltip of the document name
              // for each one - we don't want a tooltip for the bulk properties button
              this.$(".acceptedDoc").not("#bulk-properties-btn").each(function() {
                  // we're attaching the tooltip to the bulkUpload div since our document marker divs are constrained by
                  // a specific height (needed to make the scrollable plugin work correctly) so they would not show completely
                  $(this).tooltip({
                      title: $(this).text(),
                      container: $("#bulkProperties-main"),
                      delay: {
                          show: 500,
                          hide: 0
                      }
                  });
  
                  // when a tooltip hides, it unfortunately triggers a 'hide' event that the modal would pick up on and
                  // end up closing itself if we don't stop the propagation of the event
                  $(this).on('hidden', function(event) {
                      event.stopPropagation();
                  });
              });
  
              // Do thumbnail processing if there are thumbnails
              this.evaluateThumbnails();
          },
          evaluateThumbnails: function(){
              var self = this;
              //Perform special actions in case the fileupload-list contains images.
              if(self.hasImages === true){
                  // Adjust the height of the fileupload-list & other containers if there are images.
                  $("div#bulkProperties-fileNames").addClass("image-filenames");
                  // Add in the loaded images, currently nothing extra is done here to makes sure
                  // they play nice with the spacing of the labels.
                  _.each(this.fileNames, function(fileName, index){
                       var offset = index+1;
                      //If we have an image, load it into its corresponding image-tracker.
                      var fileExtension = fileName.split('.').pop().toLowerCase();
                       if(fileExtension === "jpg" || fileExtension === "jpeg" || fileExtension === "png" || fileExtension === "gif"){
                          self.ocos.models[index].getThumbnail("medium", function(thumbUrl){
                              $("#bulkproperties-image-tracker-" + offset).attr('src', thumbUrl);
                          });
                      }
                      //For non-image panes we need to adjust the height of the empty image div so that
                       // the labels for non-images line up with the image label.
                      else{
                          $("#bulkproperties-image-tracker-" + offset).removeClass("disabledImage").addClass("unusedImage");
                      }
                      //We use offset here because self.currentIndex counts the 'bulk Properties' button as index 0,
                      //  therefore, the first actual file is at index 1.
                      if(offset === self.currentIndex){
                          $("#bulkupload-tracker-" + offset).removeClass("current-arrow").addClass("current-image-arrow");
                      }
  
                  }, this);
                  $(".image-wrapper").removeClass("unused-image-wrapper");
                  $(".uploadLabel").addClass("img-upload-label");
              }
              else{
                  // Remove the height attribute of the containers incase it was previously set due to
                  //  images being part of the upload.
                  $("div#bulkProperties-fileNames").removeClass("image-filenames");
                  $(".image-wrapper").addClass("unused-image-wrapper");
                  $("div.current-arrow").removeClass("current-image-arrow").addClass("current-arrow");
              }
  
          },
          serialize: function(){
              return {
                  fileNames: this.fileNames,
                  bulkPropertiesMode: this.fileNames && this.fileNames.length > 1,
                  hasBulkCommitValidationError: this.hasBulkCommitValidationError
              };
          }
      });
  
      // a pagable (not backbone.pagable) list of UploadItemView
      BulkProperties.SequentialPropertyEditingView = Backbone.Layout.extend({
          template: "actions/bulkproperties/sequentialpropertyeditingview",
          initialize: function() {
              var defaults = {
                  ocoCollection: new OC.OpenContentObjectCollection(),
                  fileNames: [],
                  objectType: ''
              };
  
              this.options.currentIndex = 0;
              this.options = _.extend(defaults, this.options);
  
              // the bulk properties object type for these sequential upload item views - will be undefined if they're
              // only uploading one document
              this.bulkPropertiesObjectType = this.options.objectType;
  
              // the object type of the current upload item view being looked at
              this.currentObjectType = this.options.objectType;
  
              this.formName = this.options.formName;
          },
          beforeRender: function(){
              // do this here makes unit testing alot easier..
              this._goto();
          },
          // called when a user clicks on the name of a file to edit
          jumpTo: function(clickedIndex) {
              var hasNext, hasPrevious;
  
              // save the properties of the current document being viewed
              this._saveCurrentOcoProperties();
  
              // the current index should be 0-based, clickedIndex is 1-based
              this.options.currentIndex = clickedIndex - 1;
  
              // set the current object type to be the type of the document that we're navigating to
              this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');
  
              // check to see if we can go "Next" past the document we're navigating to
              hasNext = this._canGoto(this.options.currentIndex + 1);
              // check to see if we can go "Previous" before the document we're navigating to
              hasPrevious = this._canGoto(this.options.currentIndex - 1);
  
              // update our pagination controls
              app.trigger('bulkproperties:controls:update', {
                  hasNext: hasNext,
                  hasPrevious: hasPrevious,
                  currentIndex: this.options.currentIndex + 1,
                  numDocsToUpload: this.options.ocoCollection.models.length,
                  // we want to display "1 of 3 files"
                  showIndex: true,
                  showRequired: this._isCurrentOcoValid()
              });
  
              // render this view
              this.render();
          },
          next: function() {
              var hasNext, hasPrevious;
  
              // if we can go to the next object
              if(this._canGoto(this.options.currentIndex + 1, "next")) {
                  // save the current object's properties
                  this._saveCurrentOcoProperties();
  
                  // increase our current index by one
                  this.options.currentIndex = this.options.currentIndex + 1;
  
                  // update our "Next" and "Previous" buttons
                  hasNext = this._canGoto(this.options.currentIndex + 1);
                  hasPrevious = true;
              } else {
                  // we can't go to the next object, update our "Next" and "Previous" buttons
                  hasNext = this._canGoto(this.options.currentIndex + 1);
                  hasPrevious = this._canGoto(this.options.currentIndex - 1);
              }
  
              // set the current object type to be the type of the document that we're navigating to
              this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');
  
              // update our pagination controls
              app.trigger('bulkproperties:controls:update', {
                  hasNext: hasNext,
                  hasPrevious: hasPrevious,
                  // current index is 0-based and we want to make it 1-based for display purposes
                  currentIndex: this.options.currentIndex + 1,
                  numDocsToUpload: this.options.ocoCollection.models.length,
                  showIndex: true,
                  showRequired: this._isCurrentOcoValid()
              });
  
              // render the view
              this.render();
          },
          previous: function() {
              var hasPrevious, hasNext;
  
              // if we can go to the previous object
              if(this._canGoto(this.options.currentIndex - 1)) {
                  // save the current object's properties
                  this._saveCurrentOcoProperties();
  
                  // update our current object index
                  this.options.currentIndex = this.options.currentIndex - 1;
  
                  // update our "Next" and "Previous" buttons
                  hasNext = this._canGoto(this.options.currentIndex + 1);
                  hasPrevious = this._canGoto(this.options.currentIndex - 1);
              } else {
                  // we can't go to the next object, update our "Next" and "Previous" buttons
                  hasNext = this._canGoto(this.options.currentIndex + 1);
                  hasPrevious = this._canGoto(this.options.currentIndex - 1);
              }
  
              // set the current object type to be the type of the document that we're navigating to
              this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');
  
              // update our pagination controls
              app.trigger('bulkproperties:controls:update', {
                  hasPrevious: hasPrevious,
                  hasNext: hasNext,
                  // current index is 0-based and we want to make it 1-based for display purposes
                  currentIndex: this.options.currentIndex + 1,
                  numDocsToUpload: this.options.ocoCollection.models.length,
                  showIndex: true,
                  showRequired: this._isCurrentOcoValid()
              });
  
              // render the view
              this.render();
          },
          _canGoto: function(index, action) {
              // index is the 0-based index
              if(index <= this.options.ocoCollection.length - 1 && index > -1) {
                  if(action && action === "next") {
                      return this._isCurrentOcoValid();
                  } else {
                      return true;
                  }
              } else {
                  return false;
              }
          },
          // called from the beforeRender of this view to set up our object type picklist view and set our listener for
          // when we're done rendering and we trigger the generation of our form support
          _goto: function() {
                  var self = this;
  
                  if(this.options.fileNames.length == 1){
                      app.trigger('bulkproperties:tracker:update', this.options.currentIndex + 1);
                  }
  
                  // get the current properties of the document we're currently looking at
                  var currentProps = this.options.ocoCollection.at(this.options.currentIndex).get("properties");
  
                  // this will be the title of the form support view - so we'll make it the original file name of
                  // the current document being edited
                  var title = "Original Document Name: " + this.options.fileNames[this.options.currentIndex];
  
                  var objectType = this.objectType = this.bulkPropertiesObjectType;
  
                  // helper function to generate the upload item view (form support container), set it and render
                  var generateFormSupport = function(properties) {
                      // set the object type of the object at our current index to be the new object type selected
                      self.options.ocoCollection.at(self.options.currentIndex).set("objectType", objectType);
  
                      // generate our formsupport container view
                      self.options.activeChildView = new PropertiesView.PropertyList({
                          'properties': properties,
                          'objectType': objectType,
                          'title' : title,
                          'enableRequired': true,
                          'formName': self.formName,
                          'listener': 'bulkproperties',
                          'disableDefaults': true
                      });
  
                      // set and render our formsupport view
                      self.setView("#active-item-outlet", self.options.activeChildView).render();
                  };
  
                  // if we only have one document let's do this logic which contains some special logic for figuring out
                  // the control type of the object name (so we can use the filename if it's not computed)
                  if(this.options.ocoCollection.length === 1) {
                      //get the form's type config
                      app.context.configService.getFormTypeConfig(self.formName, objectType, function(config) {
                          var configuredAttrs = _.union(config.get("configuredAttrsPri").models, config.get("configuredAttrsSec").models);
  
                          // get the object name attribute
                          var objectNameAttr = _.filter(configuredAttrs, function(attr) {
                              return attr.get("ocName") === "objectName";
                          }, this)[0];
  
                          // if the control type is not a computed and they aren't inheriting objectName
                          // from the parent folder (maybe some weird client implementation?)
                          if(objectNameAttr && objectNameAttr.get("controlType") !== 'Computed' && !currentProps.objectName){
                              currentProps.objectName = self.options.fileNames[self.options.currentIndex];
                          }
  
                          // now we have our properties with the the correct object name so let's generate form support
                          generateFormSupport(currentProps);
                      }, app.context.configName());
  
                  } else { // we are uploading multiple documents
                      // our properties are either the bulk properties overriden with whatever the current properties are
                      // or just the current properties if this object type is not the type selected in bulk properties
                      var bulkProperties = _.clone(this.options.bulkProperties);
                      generateFormSupport((this.bulkPropertiesObjectType === objectType) ? _.extend(bulkProperties, currentProps) : currentProps);
                  }
          },
          finish: function() {
              // save the properties of the current OCO (which is the last document since we might have not saved them yet)
              this._saveCurrentOcoProperties();
              app.trigger('bulkproperties:onFinish', this.options.ocoCollection);
          },
          _allOcosValid: function(){
              var allValid = true;
              this.options.ocoCollection.each(function(oco) {
                  if(!oco.get('isValid')) {
                      allValid = false;
                  }
              });
              return allValid;
          },
          _isCurrentOcoValid: function() {
              return this.options.activeChildView ? this.options.activeChildView.isValid() : true;
          },
          // this saves the properties of the current document being viewed
          _saveCurrentOcoProperties: function() {
              // if we have an upload item view (a.k.a a formsupport instance to get the values from)
              // we'll get the values currently on the document, save them to the OCOs properties
              // and also set the indicator on the document Backbone model if it's valid or not
              if(this.options.activeChildView) {
                  var newValues = this.options.activeChildView.getValues();
                  var oco = this.options.ocoCollection.at(this.options.currentIndex);
                  oco.set('properties', _.extend(oco.get('properties'), newValues));
                  oco.set('isValid', this._isCurrentOcoValid());
                  var updatedOcos = this.options.ocoCollection.models;
                  updatedOcos[this.options.currentIndex] = oco;
                  this.options.ocoCollection.set(updatedOcos);
              }
          },
          startListening: function() {
              this.listenTo(app, "bulkproperties:backPressed", function() {
                  this.options.currentIndex = 0; //reset if back button pressed
              }, this);
  
              // they just clicked the "Next" button
              this.listenTo(app, "bulkproperties:nextPressed", function() {
                  this.next();
              });
  
              // they just clicked the "Previous" button
              this.listenTo(app, "bulkproperties:prevPressed", function() {
                  this.previous();
              });
  
              // they just clicked the "Finish and Upload" Button
              this.listenTo(app, "bulkproperties:finishPressed", function() {
                  this.finish();
              });
  
              // they clicked on a file name across the top
              this.listenTo(app, "bulkproperties:goTo", function(clickedIndex) {
                  this.jumpTo(clickedIndex);
              }, this);
  
              // we need to set the valid indicator on the OCO when this event is fired
              this.listenTo(app, 'bulkproperties:ocoValid', function(documentIndex) {
                  this.options.ocoCollection.at(documentIndex - 1).set('isValid', true);
              }, this);
  
              // we need to set the invalid indicator on the OCO when this event is fired
              this.listenTo(app, 'bulkproperties:ocoInvalid', function(documentIndex) {
                  this.options.ocoCollection.at(documentIndex - 1).set('isValid', false);
              }, this);
          }
      });
  
      // this is the view for choosing bulk properties to apply to multiple documents being uploaded
     BulkProperties.BulkPropertiesView = Backbone.Layout.extend({
          template: "actions/bulkproperties/bulkpropertiesview",
          initialize: function(options) {
              if(options) {
                  // the selected object type for the documents
                  this.bulkPropertiesObjectType = options.bulkPropertiesObjectType;
                  this.ocoCollection = options.ocoCollection;
                  this.formName = options.formName;
              }
  
              // the title for this view - which is actually used in our upload item view above our form support
              this.title = (window.localize("action.bulkPropertiesView.bulkPropertyEditPage"));
  
              // make a new collection of ocos which will hold our OCOs we build up throughout the action
              this.collection = new OC.OpenContentObjectCollection();
  
              // we have no starting properties since we're not inheriting anything
              this.bulkProperties = {};
  
              // if we haven't already built our OCO collection, let's do that
              if(this.collection.length === 0) {
                  // for each of the file names we have, we'll create a new OCO, set its objectType and its
                  // initial properties from the properties we just fetched from the parent folder
                  this.collection=  this.ocoCollection.clone();
              }
  
              // this sets up our sequential properties view with our starting properties, the collection and object type selected
              app.trigger('bulkproperties:setupSequentialProperties', this.bulkPropertiesObjectType, this.bulkProperties, this.collection);
  
              // let's build our upload item view - which houses our form support for Bulk Properties
              this.buildBulkPropertiesView();
  
              this._startListening();
          },
          _startListening: function() {
              //this can be sent from bulk properties - a fast forwards of sorts
              this.listenToOnce(app, 'bulkproperties:finishPressed', function(){
                  //we can't realie on form support here, we'll need to propogate manually
                  var bulkProperties = {};
                  var bulkPropertiesObjectType = this.ocoCollection.pluck('objectType')[0];
                  var ocos = this.ocoCollection.clone();
  
                  // let's grab our starting properties from bulk properties
                  bulkProperties = this.getBulkProperties();
                  // let's get our selected object type the user chose for all the documents to be uploaded
                  bulkPropertiesObjectType = this.getBulkPropertiesObjectType();
  
                  BulkProperties.setAndPropagateBulkProperties(bulkProperties, bulkPropertiesObjectType, ocos, this.formName).done($.proxy(function(){
                      //we don't want to crosstalk a normal commit so lets use a seperate message
                      app.trigger('bulkproperties:commitchanges', ocos);
                  }, this));
              });
          },
          getBulkProperties: function() {
              this.bulkProperties = this.activeChildView.getValues();
              return this.bulkProperties;
          },
          getBulkPropertiesObjectType: function() {
              return this.bulkPropertiesObjectType;
          },
          buildBulkPropertiesView: function() {
              // we don't want to build our upload item view (form support container) if we have no object type
              if(this.bulkPropertiesObjectType) {
                  // this builds a view which houses our form support for our bulk properties
                  this.activeChildView = new PropertiesView.PropertyList({
                      'properties': this.bulkProperties,
                      'objectType': this.bulkPropertiesObjectType,
                      // we're in bulk properties view so we don't have a document name title to display over form support
                      'bulkProperties': true,
                      // enable validation if this is the bulk property edit page
                      'enableRequired': false,
                      'enableReadonly': true,
                      'formName': this.formName,
                      'listener': 'bulkproperties',
                      'disableDefaults': true
                  });
  
                  // let's set our form support container view and render it (the controls will show up since
                  // form support uses knockout and we apply bindings in the after render of the upload item view)
                  this.setView(".bulk-properties-item-view", this.activeChildView).render();
              }
          }
      });
  
      BulkProperties.PaginationControls = Backbone.Layout.extend({
          template: "actions/bulkproperties/bulkproperties-pagination-controls",
          events: {
              "click #nextUploadFormBtn" : "next",
              "click #prevUploadFormBtn" : "previous",
              "click #finishUploadFormBtn" : "finish",
              "click #properties-back-button" : "goBack",
              "click #bulk-properties-back-button" : "goToBulkProperties"
          },
          initialize: function(options) {
              // options will be the initial options for this view
              if(options) {
                  // the "1 of 2" documents to indicate where in the list the user is currently
                  this.showIndex = options.showIndex;
                  // the text indicating to the user that there are more required fields to fill out
                  this.showRequired = options.showRequired;
                  // if the "Next" button should be disabled or not
                  this.hasNext = options.hasNext;
                  // if the "Previous" button should be disabled or not
                  this.hasPrevious = options.hasPrevious;
                  // the current index in the list of documents the user is viewing (for the "1" in the "1 of 2")
                  this.currentIndex = options.currentIndex;
                  // the total number of documents chosen for upload (for the "2" in the "1 of 2")
                  this.numOfUploadItems = options.numOfUploadItems;
                  // if the documents are all valid and the finish button should be shown to complete the action
                  this.allowFinish = options.allowFinish;
              }
  
              // the text for the button that allows the user to be done setting properties and actually perform the upload
              this.finishMessage = (window.localize("modules.actions.bulkProperties.save"));
  
              // this listener is nessesary in the case that there is only one document selected, we still want to finish and upload
              this.listenTo(app, 'bulkproperties:formIsValid', function(options) {
  
                  // update tracker with the current index and its validity
                  if(this.currentIndex !== undefined) {
                      if(options.isValid) {
                          // oco is valid, pagination controls and sequential editor will show a valid oco
                          app.trigger('bulkproperties:ocoValid', this.currentIndex);
                      } else {
                          // conversly, we need to diable the next button and show an error message if its invalid
                          app.trigger('bulkproperties:ocoInvalid', this.currentIndex);
                      }
                  }
  
                  if(options.externalFormValidationMessage){
                      this.externalFormValidationMessage = options.externalFormValidationMessage;
                  }
  
                  // show the helper text that there are required fields to fill out if this form is not yet valid
                  this.showRequired = !options.isValid;
                  //show external validity message
                  this.showExternalValidityMessage = options.showExternal;
  
                  // if we want to show the index then we are not on the bulk properties page
                  if(this.showIndex) {
                      // we have a next button if the current index is less than the number of items to upload
                      this.hasNext = this.currentIndex < this.numOfUploadItems;
  
                      // figure out whether we can show the user the Finish & Upload button
                      this.setAllowFinish();
                  } else { // we are on the bulk properties page
                      // there's always a next button on the bulk properties page
                      this.hasNext = true;
                      
  
                      this.allowFinish = options.isValid;
                      // figure out whether we can show the user the Finish & Upload button
                      this.render();
                  }
              }, this);
  
              this.listenTo(app, 'bulkproperties:controls:update', function(options) {
                  this.hasPrevious = options.hasPrevious;
                  this.hasNext = options.hasNext;
                  this.currentIndex = options.currentIndex;
                  this.numOfUploadItems = options.numDocsToUpload;
                  this.showRequired = options.showRequired;
                  this.showIndex = options.showIndex !== undefined ? options.showIndex : this.showIndex;
  
                  // figure out whether we can show the user the Finish & Upload button
                  this.setAllowFinish();
              }, this);
          },
          next: function(){
              app.trigger("bulkproperties:nextPressed");
          },
          previous: function(){
              app.trigger("bulkproperties:prevPressed");
          },
          finish: function(){
              // animate our loading indicator with spin.js (lighter weight than animated gif)
              this.spinner = HPISpinner.createSpinner({
                  color: '#666'
              }, this.$el.find(".progressSpinner")[0]);
  
              app.trigger("bulkproperties:finishPressed");
  
              this.disableButtons();
  
              this.listenTo(app, 'bulkproperties:doneUpdating', function() {
                  // we're done uploading so let's destroy the spinner that indicates we're still processing something
                  HPISpinner.destroySpinner(this.spinner);
  
                  this.enableButtons();
              }, this);
          },
          disableButtons: function(){
              var buttons = this.$('button');
              buttons.addClass('disabled');
              //disable all events
              this.undelegateEvents();
          },
          enableButtons: function(){
              var buttons = this.$('button');
              buttons.removeClass('disabled');
              //disable all events
              this.delegateEvents();
          },
          goBack: function() {
              app.trigger("bulkproperties:backPressed");
          },
          goToBulkProperties: function() { //return to bulk properties view
              if($('#bulk-properties-back-button').hasClass('disabled')) {
                  return; //do nothing if btn disabled
              }
              app.trigger('bulkproperties:goToBulkProperties');
          },
          // helper method to set whether the Finish and Upload button should be enabled or not
          setAllowFinish: function() {
              var self = this;
  
              // if we're not showing a message saying the current OCO is invalid and we're on the last OCO
              if(!this.showRequired) {
                  var deferred = new $.Deferred();
                  // this code runs a scan of all the ocos in sequential properties and checks their validity on the whole
                  app.trigger('bulkproperties:allOcosValid', deferred);
                  deferred.then(function(allValid) {
                      // if all ocos are valid, allow finish & upload
                      self.allowFinish = allValid;
  
                      self.render();
                  });
              } else { // we're either not on the last OCO or the last OCO isn't valid so let's not show the finish & upload button
                  this.allowFinish = false;
                  this.render();
              }
          },
          afterRender: function() {
              app.trigger("bulkproperties:isSubmitValid");
          },
          serialize: function(){
              return {
                  showIndex: this.showIndex,
                  currentIndex: this.currentIndex,
                  numOfUploadItems: this.numOfUploadItems,
                  showRequired: this.showRequired,
                  hasNext: this.hasNext,
                  hasPrevious: this.hasPrevious,
                  allowFinish: this.allowFinish,
                  finishMessage: this.finishMessage,
                  externalFormValidationMessage: this.externalFormValidationMessage,
                  showExternalValidityMessage: this.showExternalValidityMessage
              };
          }
      });
  
      BulkProperties.CustomConfigView = Backbone.Layout.extend({
          template: "hpiadmin/actions/customconfig/bulkpropertiesconfig",
          initialize: function(){
              var viewModel = this.options.viewModel;
              //FOLDER NOTES INTEGRATION
              viewModel.folderNotes = kb.observable(viewModel.model(), "folderNotes");
  
              if(viewModel.folderNotes() === "false" ) {
                  viewModel.folderNoteType(false);
              }
              // selected folder note type from the admin
              viewModel.folderNoteObjectType = kb.observable(viewModel.model(),"folderNoteObjectType");
              if (!viewModel.folderNoteObjectType()){
                  viewModel.folderNoteObjectType("HPI Note");
              }
              // note type to apply to all folder notes
              viewModel.folderNoteType = kb.observable(viewModel.model(),"folderNoteType");
              if (!viewModel.folderNoteType()) {
                  viewModel.folderNoteType("Folder Note");
              }
              //selected folder note relationship from admin
              viewModel.folderNoteRelationship = kb.observable(this.viewModel.model(),"folderNoteRelationship");
  
              //is the note directly related to the folder or document?
              viewModel.enableDocumentNoteRelation = kb.observable(this.viewModel.model(),"enableDocumentNoteRelation");
              //END FOLDER NOTES INTEGRATION
              viewModel.enableVersionOnUpdate = kb.observable(viewModel.model(), "enableVersionOnUpdate");
  
              viewModel.isCustomBulkPropertiesFormConfigured = kb.observable(viewModel.model(), "isCustomBulkPropertiesFormConfigured");
  
              viewModel.form = kb.observable(viewModel.model(), "form");
  
              viewModel.bulkPropertiesForm = kb.observable(viewModel.model(), "bulkPropertiesForm");
  
              viewModel.potentialForms = ko.observableArray();
  
              this.initializeDef = app.context.configService.getFormConfigNames(function(formConfigNames) {
                  viewModel.potentialForms(formConfigNames);
              });
          },
          afterRender: function(){
              var self = this;
              this.initializeDef.done(function(){
                  kb.applyBindings(self.options.viewModel, self.$el[0]);
              });
          }
      });
  
      actionModules.registerAction("bulkProperties", BulkProperties, {
          "actionId" : "bulkProperties",
          "label" : (window.localize("modules.actions.bulkProperties.bulkPropertyEdit")),
          "icon" : "pencil"
      });
  
      return BulkProperties;
  
  });
  require(["bulkproperties"]);