define("advancedcombinetopdfsendemail", [
    "app",
	"modules/actions/actionmodules",
	"handlebars",
    "sendemail",
    "advancedcombinetopdf",
    "modules/hpiadmin/actionconfig/actions/advancedcombinetopdfsendemailconfig"
],
function(app, actionModules, handlebars, SendEmail, ACTPDF, ACTPDFSendEmailCustomConfigView) {
	"use strict";
    var ACTPDFSendEmail = {};

    ACTPDFSendEmail.CustomConfigView = ACTPDFSendEmailCustomConfigView.View;

    // extend the view of advanced combine to pdf, as we want to use some methods, but override others
    ACTPDFSendEmail.View =  ACTPDF.View.extend({
        template: "actions/advancedcombinetopdfsendemailcontrols",
        events: {
            "click #combine-submitBtn": "combineDocuments",
            "keyup #download-pdf-name": "updateFileName",
            "click #combine-submitBtn-container": "clickCombineBtnContainer",
            "show.bs.tab #actpdf-selectedTabLink": "selectedDocumentsTabClick",
            "show.bs.tab #actpdf-emailTabLink": "nextToSendEmailTabShow",
            "click #combine-nextBtn": "nextToSendEmailBtnClicked",
            "click #saveSendEmail-Btn": "combineDocumentsAndSendEmail"
		},
		
		initialize: function() {
			var self = this;
			self.tabActive = "selectedDocsActive";
			handlebars.registerHelper("active", function(searchType) {
				//searchType contains the tab we want to be active
				//if this matches the model's searchActive attribute we want to add the active class to the html
				if (self.tabActive === searchType) {
					return "active";
				} else {
					return "";
				}
			});

			ACTPDFSendEmail.View.__super__.initialize.apply(this);
		},
        
        beforeRender: function() {
            if (this.fetched) {
                this.buildAndSetEmailView();
            }
        },

        enableOrDisableNextButton: function(enable) {
            this.$("#combine-nextBtn").prop('disabled', enable ? false : 'disabled');
        },

        combineDocumentsAndSendEmail: function() {
			this.handler = this.myHandler;
			this.$(".error-message-" + this.cid).hide();
			app[this.handler].trigger("loading", true);

			if (this.sendEmailView.model.validateMaxNumberOfAttachments) {
				var maxAttachments = this.config.get('maxNumberOfAttachments');
				if (this.sendEmailView.attachmentsView.attachedDocs.length > maxAttachments) {
					app[this.handler].trigger("loading", false);
					this.sendEmailView.errorMessage = window.localize("modules.actions.sendEmail.exceedsMaxAttachments") + maxAttachments +
					" " + window.localize("stage.sendEmail.attachments") + "." + window.localize("modules.actions.sendEmail.removeAttachments");
					this.$(".error-message-" + this.cid).show().html("<span>" + this.sendEmailView.errorMessage + "</span>");

					return;
				}
			}

			//Get the form info
			var toArray = [], ccArray = [],  bccArray =  [];

			//if user leaves a recipient in the input make sure they get added!
			this.sendEmailView.recipientsView.addToRecipientsSubView(SendEmail.Constants.TO);
			this.sendEmailView.recipientsView.addToRecipientsSubView(SendEmail.Constants.CC);
			this.sendEmailView.recipientsView.addToRecipientsSubView(SendEmail.Constants.BCC);

			//Handler to check if the email is valid
			//get the email recipients
			this.sendEmailView.model.emailInfoModel.get("toCheckList").each(function(addressModel){
				toArray.push(addressModel.get("emailAddress"));
			});
			this.sendEmailView.model.emailInfoModel.get("ccCheckList").each(function(addressModel){
				ccArray.push(addressModel.get("emailAddress"));
			});
			this.sendEmailView.model.emailInfoModel.get("bccCheckList").each(function(addressModel){
				bccArray.push(addressModel.get("emailAddress"));
			});

            //get plain text or HTML based on configuration (HTML by default)
			this.sendEmailView.model.emailInfoModel.set("body", this.sendEmailView.bodyView.getBodyValue());

			if(this.sendEmailView.model.validateAttachments) {
				if (this.sendEmailView.attachmentsView.attachedDocs.length === 0) {
                    app[this.handler].trigger("loading", false);
                    this.sendEmailView.errorMessage = SendEmail.Localizations.error['no:attachments'];
                    this.$(".error-message-" + this.cid).show().html("<span>" + this.sendEmailView.errorMessage + "</span>");
                    return;
                }
			}
			
			if(this.sendEmailView.model.emailInfoModel.get("body").length > 0) {

				this.action.get("parameters").to = toArray;
				this.action.get("parameters").cc = ccArray;
				this.action.get("parameters").bcc = bccArray;
				this.action.get("parameters").subject = this.sendEmailView.model.emailInfoModel.get("subject");
				this.action.get("parameters").email_folder_name = this.sendEmailView.model.config.get("emailStorageLocation");
				this.action.get("parameters").attachment_ids = [];
				this.action.get("parameters").email_rel_type = this.sendEmailView.model.config.get("emailRelationship");
				this.action.get("parameters").body = this.sendEmailView.model.emailInfoModel.get("body");
				this.action.get("parameters").from =  app.user.id;
				this.action.get("parameters").email_bean_name = this.sendEmailView.model.config.get("emailObjectType");
				this.action.get("parameters").folderTags = this.sendEmailView.model.config.get("folderTags");
				this.action.get("parameters").folderId = this.sendEmailView.model.folderId || app.context.container.id;
				this.action.get("parameters").trac = app.context.configName();

				
				if (this.sendEmailView.validateCloudSend){
					// run through the check to see if we should send through the cloud
					this.action.get("parameters").cloudSendEnabled = !this.sendEmailView.verifyCanSendInternally();
				} else {
					this.action.get("parameters").cloudSendEnabled = this.sendEmailView.model.config.get("cloudSendMode") === "enabled";
				}

				this.action.get("parameters").cloudSend = this.sendEmailView.model.config.get("emailObjectType");

				// If folder notes enabled
				if (this.sendEmailView.model.integrateFolderNotes) {
					// Check if the ckeditor has a typed note
					if (CKEDITOR.instances[this.sendEmailView._CKEDITOR_getFolderNoteBody()].getData()) {
						// We have verified that the ckeditor has content
						this.action.get("parameters").note_content = CKEDITOR.instances[this.sendEmailView._CKEDITOR_getFolderNoteBody()].getData();
					} else if (this.sendEmailView.model.alwaysCreateNoteOnSend) {
						// If the ckeditor note content is empty AND the configuration to create a default note is on,
						// set the note content to the subject of the email object being sent
						this.action.get("parameters").note_content = this.sendEmailView.model.emailInfoModel.get("subject");
					}

					// If note content has been set by this point, let's configure the action to add the note
					if (this.action.get("parameters").note_content) {
						//get the parent container
						this.action.get("parameters").parentID = this.action.get("parameters").folderId;
						var currentDate = DateFormat.format.date(new Date(),"E, d MMM yyyy hh-mm-ss a");
						this.action.get("parameters").property_map = {
							'note_type': this.sendEmailView.model.config.get('noteType'),
							'objectName': "Folder Note - " + currentDate
						};
						this.action.get("parameters").note_object_type = this.sendEmailView.model.config.get('noteObjectType');
						this.action.get("parameters").note_rel_type = this.sendEmailView.model.config.get('noteRelationship');
						this.action.get("parameters").createNote = "true";
					} else {
						this.action.get("parameters").createNote = "false";
					}
				} else {
					this.action.get("parameters").createNote = "false";
                }
                
				this.allAttachments = [];
				this.annotations = [];

				// If the Export With Annotations attribute was configured for this action OR if we have already selected some annotators
				if(this.config.get("exportWithAnnotationsToAttachments") === 'true' || this.action.get("parameters").annotationInfo) {
					// If the user has selected some annotators
					if(this.action.get("parameters").annotationInfo) {
						this.combineDocuments();
					// If the user has not selected any annotators yet
					} else {
						// If the e-mail has no attachments, we send the e-mail as usual.
						if(this.action.get("parameters").attachment_ids.length === 0) {
							this.combineDocuments();
						}
					}
				} else {
					this.combineDocuments();
				}
			} else {
				app[this.handler].trigger("loading", false);
				this.sendEmailView.errorMessage = SendEmail.Localizations.error['no:body'];
				this.$(".error-message-" + this.cid).show().html("<span>" + this.sendEmailView.errorMessage + "</span>");
			}
        },

        executeAction: function() {
            if(!app.context.container.get("objectId") && this.folderNotesEnabled){
                app.trigger("alert:error", {
                    header: window.localize("generic.configurationIssue"),
                    message: window.localize("modules.actions.advancedCombineToPDF.configIssue.folderNotes")
                });
            }else{
                this.action.execute({
					context: this,
                    success: function(){
                        app[this.handler].trigger("loading", false);
                        app[this.handler].trigger( "showMessage", (window.localize("modules.actions.sendEmail.emailSuccessfully")));
                    },
                    error: function(){
                        app[this.handler].trigger("loading", false);
                        app[this.handler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")));
                    }
                });
            }
        },

        // when user clicks select docs tab, hide save button, show next button
        selectedDocumentsTabClick: function() {
            $('#combine-nextBtn-container').show();
            $('#saveSendEmail-Btn-container').hide();
        },
        nextToSendEmailTabShow: function() {
            $('#combine-nextBtn-container').hide();
            $('#saveSendEmail-Btn-container').show();
        },
        nextToSendEmailBtnClicked: function() {
            // this will fire the send email tab listener
            $('#actpdf-emailTabLink').tab('show');
        },

        buildAndSetEmailView: function() {
            this.sendEmailView = new SendEmail.View({
                action: this.options.action,
				config: this.options.config,
				advancedCombineToPDFSendEmail: true,
				showAttachments: false,
				showSubmitButton: false
            });
            this.sendEmailView.action.get('parameters').objectId = this.sendEmailView.model.folderId;
            this.setView('#saveSendEmailOutlet', this.sendEmailView);
        },
        serialize: function() {
            return {
                modal: this.myHandler === "modalActionHandler"
            };
        },
    });

    // register controlled print, is a group action in the search config
    actionModules.registerAction("sendCombinedPDFEmail", ACTPDFSendEmail, {
        "actionId": "sendCombinedPDFEmail",
        "label": "Email Combined PDF",
        "icon": "filter",
        "handler": "modalActionHandler",
        "paneSize": "rightPane"
    });

	return ACTPDFSendEmail;
});
require(["advancedcombinetopdfsendemail"]);