define("sendnotification", [
	// Application.
	"app",
	"oc",
	"modules/formsupport",
	"modules/actions/actionmodules",
	"modules/common/typeahead",
	"modules/common/queryabletypeahead",
	"modules/common/hpiconstants",
	"modules/hpiadmin/sendnotificationconfig/sendnotificationconfig"
],

	function (app, OC, formSupport, actionModules, HPITypeahead, QueryableTypeahead, HPIConstants, SendNotificationConfig) {
		"use strict";

		var SendNotification = {};

		SendNotification.CustomConfigView = SendNotificationConfig.View;

		SendNotification.View = Backbone.Layout.extend({
			template: "actions/sendnotification",
			events: {
				"click #btn-sendNotification": "submit",
				'keydown .typeahead': 'sanitizeKey'
			},
			initialize: function () {
				var self = this;
				this.action = this.options.action;
				this.config = this.options.config;
				this.myHandler = this.options.config.get("handler");
				this.objectId = this.action.get("parameters").objectId;
				this.selectedDate = '';
				this.emailSubjectAttrMessage = '';
				
				this.attrToShow = self.config.get("attrToShow") ? self.config.get("attrToShow") : "objectName";
				// the notification form to use when creating a new notification
				this.formToShow = this.options.config.attributes.selectedFormName;

				this.resolverMode = self.config.get("resolverMode") || HPIConstants.Resolvers.Stage;

				// this should be done before any submission right? no need to promise
				app.context.configService.getAdHocFormConfig(this.formToShow, function(model) {
					
					self.workflowAttrMap = _.map(model.attributes.controls, function (control) {
						return _.pick(control.attributes, ['label', 'value', 'controlType', 'isWysiwyg', 'ocName']);
					});
					
				});

				this.oCObject = new OC.OpenContentObject({
					objectId: self.objectId
				});
				
				this.oCObject.fetch({
					success: function (object) {
						app[self.myHandler].trigger("loading", false);
						self.toNotify = object.get("properties")[self.attrToShow];
					},
					error: function () {
						self.toNotify = "";
					}
				});
			},
			afterRender: function () {

				var self = this;

				app.context.configService.getWorkflowConfigs(function(workflowConfigs) { 
					var description = "";

					self.workflowConfig = workflowConfigs.get("currentWorkflows").hpiNotificationWorkflow;
					if (self.workflowConfig) {

						self.configuredForm = _.findWhere(self.workflowConfig, { 'configName': self.formToShow });

						self.workflowFormView = new SendNotification.FormView({
							'formName': self.configuredForm.configName
						});
						if (self.workflowFormView) {
							self.setView("#addUsersControls", self.workflowFormView, false).render();
						}
						description = self.configuredForm.description || description;

						$("#workflow-description").html(description);

                    	$("#workflowDefinition-form").show();
					}
					
				});
			},
			serialize: function () {
				var modal = false;
				var rightSide = false;
				if (this.myHandler === "modalActionHandler") {
					modal = true;
				} else if (this.myHandler === "rightSideActionHandler") {
					rightSide = true;
				}

				return {
					modal: modal,
					rightSide: rightSide,
					formToShow: this.formToShow
				};
			},
			sanitizeKey: function (evt) {
				var code = evt.keyCode || evt.which;
				if (code == 13) {
					//prevent default for enter key only
					evt.preventDefault();
				}
			},
			submit: function () {
                var self = this;
                app[self.myHandler].trigger("loading", true);
               	this.actionParameters = self.action.get("parameters");

                if (self.workflowFormView) {
                    self.formValues = self.workflowFormView.getValues();

                    //Comment and add self/this
                    this.actionParameters.workflowDefinitionId = $("#workflowDefinition-select").val();
                    this.actionParameters.userIds = self.formValues.bpm_assignees;
                    this.actionParameters.groups = self.formValues.bpm_groupAssignee;
					this.actionParameters.attached = self.toNotify;
					this.actionParameters.workflowFormName = self.formToShow;
					this.actionParameters.event = self.config.get("eventName");
					this.actionParameters.subject = this.parseNotificationEmailSubjectAttrs(self.config.get("notificationEmailSubject"));
					this.actionParameters.trac = app.context.configName();
					if (self.formValues.bpm_workflowDueDate) {
						this.actionParameters.dueDate = self.formValues.bpm_workflowDueDate;
					}

					if (self.workflowAttrMap) {
						self.formValues = self.createControlMapWithLabels();
					}

					//Adding on the props from the form.  
                    _.extend(this.actionParameters, { "properties": self.formValues });
					
				}
				
				self.buildURLParam().done(function(url){
					self.action.get("parameters").url = url;
					self.executeAction();
				});
			},
			createControlMapWithLabels : function () {
				var self = this;
				var newLabelMap = {};
				var requiredOrSpecialProps = ['bpm_assignees','bpm_groupAssignee','bpm_workflowDueDate','bpm_comment'];
				_.each(_.keys(self.formValues), function(formValue) {
					if (requiredOrSpecialProps.indexOf(formValue) === -1) {
						var formValueControlProps = _.findWhere(self.workflowAttrMap, {value: formValue});
						newLabelMap[formValue] = _.extend({}, formValueControlProps);
						newLabelMap[formValue].value = self.formValues[formValue];
					}		
				});

				var textAreaControls = _.where(self.workflowAttrMap, {controlType: "TextArea"});
			
				// check for a wysiwyg editor data - if bpm_comment is undefined in its instances then we haven't configured 
				// our text area to be a wysiwyg - do something if regular text area is blank? 
				_.each(textAreaControls, function(textAreaControl) {
					if (textAreaControl.controlType === "TextArea" && textAreaControl.isWysiwyg && CKEDITOR.instances[textAreaControl.ocName]) {
						if (textAreaControl.ocName === "bpm_comment") {
							self.actionParameters.bpm_comment = CKEDITOR.instances.bpm_comment.getData();
						} else {
							self.formValues[textAreaControl.ocName].value = CKEDITOR.instances[textAreaControl.ocName].getData();
						}
					}	
				});

				return newLabelMap;
			},
			buildURLParam: function () {
				var self = this;
				var url = window.location.protocol + "//" + window.location.host + app.root;
				var deferred = $.Deferred();
				if (this.resolverMode === "Stage") {
					// if this is a notification being sent for a folder, we don't need to fetch the parent
					if (app.context.container.get("objectId") === this.objectId) {
						url += "#Stage/" + this.action.get("parameters").trac + "/" + this.objectId;
						deferred.resolve(url);
					} else {
						// this is a notification for a document in a folder, so we should fetch the parent (they might have
						// clicked on a document in some sub folder many folders down so it might not be the current folder in the stage)
						$.get(app.serviceUrlRoot + "/content/getParents", {
							"objectId": this.objectId
						}, function (parentId) {
							parentId = parentId[0].objectId;
							url += "#Stage/" + self.action.get("parameters").trac + "/" + parentId + "|" + self.objectId;
							deferred.resolve(url);
						});
					}
				} else if(this.resolverMode === "Wizard") {
					//Wizard mode for commit
					url += "#Stage/" + this.action.get("parameters").trac + "/" + this.objectId + "|" + this.objectId;
					deferred.resolve(url);
				}
				return deferred.promise();
			},
			parseNotificationEmailSubjectAttrs: function(emailSubjectMessage) {
				if (emailSubjectMessage.indexOf("$") !== -1){

                    var attributeValues = app.context.util.parsePatternForAttributes(emailSubjectMessage);

                    _.each(attributeValues, function(attr) {

                        if (this.oCObject.attributes.properties.hasOwnProperty(attr)){
                            // check if the attribute isn't repeating and is just a string
                            if (!Array.isArray(this.oCObject.attributes.properties[attr])){
                            	emailSubjectMessage = emailSubjectMessage.replace("$" + attr + "$", this.oCObject.attributes.properties[attr]);
                            }
                        }

                    },this);
                }

                return emailSubjectMessage;
			},
			executeAction: function () {
				var self = this;
				app[self.myHandler].trigger("loading", true);
				self.action.execute({
                    success: function (data) {
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showMessage", window.localize("modules.actions.sendNotification.notificationSuccessfully"));
                        app.trigger("stage.refresh.documentId", true);
                    },
                    error: function (jqXHR) {
                        app[self.myHandler].trigger("loading", false);
                        if (jqXHR.responseText.indexOf("individual") >= 0) {
                            app[self.myHandler].trigger("showError", jqXHR.responseText);
                        }
                        else {
                            app[self.myHandler].trigger("showError", window.localize("modules.actions.sendNotification.sorryAnError") +
                                " " + jqXHR.responseText);
                        }
                    }

                });
			}
		});

		
        SendNotification.FormView = Backbone.Layout.extend({
            template: "actions/startworkflowform",
            initialize: function (options) {
                var self = this;
                var defaults = {
                    properties: {},
                    enableRequired: true
                };

                var opts = this.options = _.extend(defaults, this.options);

                this.propertiesViewModel = this.options.propertiesViewModel = {};

                formSupport.tsgFormSupport(this.propertiesViewModel, {
                    "isCreate": true,
                    "enableRequired": opts.enableRequired,
                    "formName": options.formName,
                    'isWorkflowForm': true
                });

                this.propertiesViewModel.controls.subscribe(function () {
                    self.propertiesViewModel.setValues(opts.properties);
                });

                this.propertiesViewModel.isValid.subscribe(function () {
					var controlVals = self.propertiesViewModel.getValues();

					// we dont NEED to have a group and a user on the form
					// we have to check all scenarios 
					var groupControlInvalid = controlVals.bpm_groupAssignee === null;
					var userControlInvalid = controlVals.bpm_assignees === null;

					var hasGroupControl = controlVals.bpm_groupAssignee !== undefined;
					var hasUserControl = controlVals.bpm_assignees !== undefined ;

					// if we have both a group control and a user control - make sure at least one of them 
					// has a user selected - otherwise we shouldn't be sending a notification
					// TODO add error message - if there is simply just a user or group control - use the 
					// required option and regular form validation will be done.
					if ((hasUserControl && hasGroupControl) && (userControlInvalid && groupControlInvalid)) {
						$('#btn-sendNotification').prop('disabled', true);
						return false;
					}
					
					$('#btn-sendNotification').prop('disabled', !self.propertiesViewModel.isValid());
                });

                this.propertiesViewModel.isFormValidationComplete.subscribe(function (isFormValidationComplete) {
                    app.trigger("simpleWorkflow:updateSpinner", isFormValidationComplete);
                });

				this.propertiesViewModel.objectType(app.context.document.get("objectType"));
            },
            getValues: function () {
                return this.options.propertiesViewModel.getValues();
            },
            afterRender: function () {
                kb.applyBindings(this.options.propertiesViewModel, this.$el[0]);
            }
		});

		actionModules.registerAction("sendNotification", SendNotification, {
			"actionId": "sendNotification",
			"label": "Send Notification",
			"notificationEmailSubject": "New Notification",
			"maxMessageLength": "800",
			"icon": "bullhorn"
		});

		return SendNotification;

	});
require(["sendnotification"]);
