define("manageadhocdocuments", [
	"app",
	"modules/actions/actionmodules",
	"oc",
	"modules/common/spinner",
	"module",
	"handlebars",
	"tsgUtils",
	"modules/common/hpiconstants",
	"managerelations",
	"modules/hpiadmin/actionconfig/actions/manageadhocdocuments/manageadhocdocumentscustomconfig"
],

function(app, actionModules, OC, HPISpinner, module, Handlebars, tsgUtils, HPIConstants, ManageRelations, ManageAdHocDocumentsCustomConfig){
	"use strict";

	var ManageAdHocDocuments = {};
	var manageAdHocDocumentsVent = _.extend({}, Backbone.Events);

	ManageAdHocDocuments.CustomConfigView = ManageAdHocDocumentsCustomConfig.View;
	
	ManageAdHocDocuments.Config = ManageRelations.Config.extend({	
		//Defaulting the supporting doc relation name to be the DCTM name
		getRelationName: function() {
			var relationNames = this.config.get('relationNames');

			//In the custom config view, this array is guaranteed to have only 1 entry (or none if the action isn't configured)
			//The data type is an array to be consistent with manage relations which can have multiple relation types.
			return _.isArray(relationNames) && relationNames.length === 1 ? relationNames[0] : "";
		},
		getLocalizations: function(){
			//This function intentionally overwrites the manage relations version.
			return {
				tabs: {
					addAdHocDocuments : window.localize("modules.actions.manageAdHocDocuments.newDocTabHeader"),
					existingAdHocDocuments : window.localize("modules.actions.manageAdHocDocuments.existingDocTabHeader")
				},
				add: {
					success: window.localize("modules.actions.manageAdHocDocuments.addDocSuccess"),
					failure: window.localize("modules.actions.manageAdHocDocuments.addDocError")
				},
				remove: {
					success: window.localize("modules.actions.manageAdHocDocuments.removeDocSuccess"),
					failure: window.localize("modules.actions.manageAdHocDocuments.removeDocError")
				},
				noAdHocDocumentsSelected : window.localize("modules.actions.manageAdHocDocuments.noDocSelectedError")
			};
		}
	});

	/**
	 * The view for the Manage Ad Hoc Documents tabs.
	 */
	ManageAdHocDocuments.View = Backbone.Layout.extend({
		template: "actions/manageadhocdocuments/manageadhocdocuments",
		events: {
			"click .manageAdHocDocumentsTab": "tabClicked",
		},
		initialize: function(){
			this.configHelper = new ManageAdHocDocuments.Config(this.options);
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.tabs = [{
				"id": HPIConstants.WizardSupportingDocsTabs.AddAdHocDocumentsTab,
				"name": this.getOverrides().getLocalizations().tabs.addAdHocDocuments,
				"active": true
			}, {
				"id": HPIConstants.WizardSupportingDocsTabs.ExistingAdHocDocumentsTab,
				"name": this.getOverrides().getLocalizations().tabs.existingAdHocDocuments,
				"active": false
			}];

			//Reset listeners to avoid mem leak
			this.stopListening(manageAdHocDocumentsVent);
			
			this.listenTo(manageAdHocDocumentsVent, 'manageadHocDocuments:show:add:adHocDocuments', function(){
				this.createView(HPIConstants.WizardSupportingDocsTabs.AddAdHocDocumentsTab);
			}, this);

			this.listenTo(manageAdHocDocumentsVent, 'manageadHocDocuments:show:existing:adHocDocuments', function(){
				this.createView(HPIConstants.WizardSupportingDocsTabs.ExistingAdHocDocumentsTab);
			}, this);
			
			this.createView(HPIConstants.WizardSupportingDocsTabs.AddAdHocDocumentsTab);
		},
		tabClicked: function(e){
			//Get id to tell us which  tab was clicked
			var $el = $(e.currentTarget);
			var id = $el.attr("id");

			//Only do something if this tab isn't the active one
			if(!$el.hasClass("active")){
				this.createView(id);
			}
		},
		createView: function(tabName){
			if(tabName === HPIConstants.WizardSupportingDocsTabs.AddAdHocDocumentsTab){
				this.addAdHocDocumentView = new ManageAdHocDocuments.AddAdHocDocumentsView({
					"action": this.action,
					"myHandler": this.myHandler,
					"config": this.getOverrides()
				});
				this.switchViews(HPIConstants.WizardSupportingDocsTabs.AddAdHocDocumentsTab, this.addAdHocDocumentView);
			}else if(tabName === HPIConstants.WizardSupportingDocsTabs.ExistingAdHocDocumentsTab){
				this.existingAdHocDocumentView = new ManageAdHocDocuments.ExistingAdHocDocumentsView({
					"action": this.action,
					"myHandler": this.myHandler,
					"config": this.getOverrides()
				});
				this.switchViews(HPIConstants.WizardSupportingDocsTabs.ExistingAdHocDocumentsTab, this.existingAdHocDocumentView);
			}
		},
		switchViews: function(tabId, newView){
			this.removeView("#manageAdHocDocumentsSubview");
			this.setView("#manageAdHocDocumentsSubview", newView, true).render();
			$(".manageAdHocDocumentsTab").removeClass("active");
			$("#" + tabId).addClass("active");
		},
		getOverrides: function(){
			return this.configHelper;
		},
		serialize: function(){
			var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide,
                tabs: this.tabs
            };
		}
	});

	/**
	 * The view for the "Add Ad Hoc Documents" tab.
	 */
	ManageAdHocDocuments.AddAdHocDocumentsView = Backbone.Layout.extend({
		template: "actions/manageadhocdocuments/addadhocdocuments",
		events: {
			"click .deleteDocFromUploadScreenBtn": "deleteDocFromUploadScreen",
			"click .addAdHocUploadBtn" : "uploadAdHocDocuments"
		},
		initialize: function () {
			var self = this;

			this.adHocRelation = this.config.getRelationName();
			this.sterilizeAttributes = [];
			//The container here is the form b/c we're in OCMS Wizard
			this.formId = app.context.container.get("properties").objectId;
			//Get the parent folder's objectId so we don't have to get it each time a user wants to add docs.
			var folderId ="";
			app.context.util.getParents(this.formId, function (data) {
				folderId = data[0].objectId;
			});
			this.parentFolderId = folderId;

			// The list of file objects to upload
			this.files = [];
			// The list of file names to upload
			this.fileNames = [];

			this.fileUploadElement = ".dropZone";
			this.selectUploadElement = ".fileuploader-input";

			// this is a handlebars helper for building an element when a new file is chosen for upload
			// and for building the document status markers on the status bar
			Handlebars.registerHelper('tracker', function (fileNames) {
				var html = '';
				self.imagesLoaded = false;
				// this counter is for separating the filenames into sections that will scroll together
				// when the user clicks the next or previous arrows on the status bar
				var i = 0;

				// loop over each of the individual file names to upload and build their HTML
				_.each(fileNames, function (fileName, index) {
					// if our counter is at 0, we're creating a new group of document name labels to scroll together
					if (i === 0) {
						html += "<div>";
					}

					// if we're not past the file upload page yet, then we need to allow the user to remove documents chosen
					// for upload
					if (fileName.hasError) {
						html += '<div class="fileUploader" ><label class="fileHasUploadError"' + ' style="color:red">' +
							'<a name="' + index + '" class="deleteDocFromUploadScreenBtn">' +
							'<span class="glyphicon glyphicon-remove"/>' +
							'</a>';
					} else {
						html += '<div class="fileUploader" ><label>' +
							'<a name="' + index + '" class="deleteDocFromUploadScreenBtn">' +
							'<span class="glyphicon glyphicon-remove"/>' +
							'</a>';
					}
					html += fileName.name + '</label></div>';

					// we're done building up this document marker
					i++;

					// if we've reached the number of documents we can have on a page, let's close the container div
					// that surrounds that number of documents
					if (i === self.numDocsPerPage) {
						html += "</div>";

						// reset our counter so we start building a new container div
						i = 0;
					}
				}, this);

				// if we didn't have a divisible number of documents by the number we can have on a page, we need to close
				// off the final container div
				if (i !== 0) {
					html += "</div>";
				}

				return html;
			}, this);
		},
		afterRender: function () {
			var self = this;

			//html5 drag and drop file upload for browsers that support it
			this.$(self.fileUploadElement).bind('dragenter dragover', function (e) {
				e.preventDefault();
				$(this).css({
					'border': '3px dashed #e83a00'
				});
			});
			this.$(self.fileUploadElement).bind('dragleave drop', function (e) {
				e.preventDefault();
				$(this).css({
					'border': '2px dashed #c0c0c0'
				});
			});

			// dropzone
			this.$(self.fileUploadElement).fileupload({
				add: function (e, data) {
					self.addDocs(data.files);
					self.render();
				},
				dropZone: $(self.fileUploadElement)
			});

			//select documents file 
             this.$(this.selectUploadElement).fileupload({
                add: function(e, data) { 
                    self.addDocs(data.files);
					self.render();
                }, 
                dropZone: $(self.selectUploadElement)
            }); 
		},
		/**
		 * Deletes the document from the "Add Ad Hoc Documents" upload screen so it won't be uploaded.
		 * @param {Event} event 
		 */
		deleteDocFromUploadScreen: function (event) {
			// based on the index, delete the corrsponding doc
			var index = $(event.currentTarget).attr('name');
			this.fileNames.splice(index, 1);
			this.render();
		},
		addDocs: function (files) {
			if (files && files[0]) {
				// set the object name to the name of the file selected to the file name
				this.fileNames = [];

				// add the files chosen for upload to the array of files to upload
				_.each(files, function (file) {
					this.files.push(file);
				}, this);

				// add the file names to the list of filenames for upload, removing the file extension if configured to do so
				_.each(this.files, function (file) {
					var filenameToPush = file.name;
					if (this.sterilizeAttributes.shouldSterilizeFilenames === 'true') {
						filenameToPush = tsgUtils.sterilizeFilename(file.name, this.sterilizeAttributes);
					}
					this.fileNames.push(filenameToPush);		
				},this);
			}
		},
		uploadAdHocDocuments: function (collection) {
			//disable the upload button while uploading docs to prevent duplicate file uploads
			$(".addAdHocUploadBtn").addClass("disabled");
			//create a spinner over the dropZone while it's uploading docs
			this.spinner = HPISpinner.createSpinner({
				top: '50%',
				left: '50%',
				radius: 10,
                color: '#666'
            }, this.$el.find(".dropZone")[0]);
			
			var filesToUpload = [];

			this.collection = collection;
			this.successList = [];
			this.errorList = [];
			this.uploadIndex = 0;

			// Updating alert message to extend across screen
			$('#oa-indexing-modal-body').css("width", "100%");

			_.each(this.files, function(file) {
				filesToUpload.push(file);
			});

			this.performSynchronousUploads(filesToUpload, this.successList, this.errorList, 0, undefined, this);
		},
		/**
		 * Uploads objects passed into this function synchronously.
		 *
		 * @param {Object} files - Files passed in as objects that we get the file name and createEmail flag from.
		 * @param {Array} successList - The array to add to if this file uploads successfully.
		 * @param {Array} errorList - The array to add to if this file fails to upload.
		 * @param {number} uploadIndex - The index of the uploaded item in the collection / the order in which it was uploaded.
		 * @param {number} originalLength - The total length of all documents to be uploaded.  We track this variable because the files list itself
		 * is modified during each recursion.
		 * @param {Object} self - The context of this function.
		 */
		performSynchronousUploads: function (files, successList, errorList, uploadIndex, originalLength, self) {
			app.log.debug("Uploading document " + uploadIndex);

			// If originalLength is undefined this is the first call of performSynchronousUploads
			if (!originalLength) {
				// Set our original length to the length of the files array when it is first passed in
				originalLength = files.length;

				// Call the updateProgressBar functionality and set it to 0
				self.updateProgressBar(0, self);
			}

			// Grabs the first file in the array of files
			var file = files.shift();
			self.uploadIndex = uploadIndex;

			self.upload(file, successList, errorList).done(function() {
				self.updateSynchUploadProgressAndRecurse(files, successList, errorList, uploadIndex, originalLength, self);
			});
		},
		/**
		 * Updates the progress bar for a synchronous upload and then launches the next upload.
		 * 
		 * @param {Object} file - The file to upload.
		 * @param {Array} successList - The array to add to if this file uploads successfully.
		 * @param {Array} errorList - The array to add to if this file fails to upload.
		 * @param {number} uploadIndex - The index of the uploaded item in the collection / the order in which it was uploaded.
		 * @param {number} originalLength - The total length of all documents to be uploaded.  We track this variable because the files list itself
		 * is modified during each recursion.
		 * @param {Object} self - The context of this function.
		 */
		updateSynchUploadProgressAndRecurse: function(files, successList, errorList, uploadIndex, originalLength, self) {
			app.log.debug("Finished document " + uploadIndex);
			if (files.length > 0) {
				// Determine the currentProgress to update the progress bar with
				var currentProgress = (((uploadIndex + 1) / originalLength) * 100).toFixed(0);
				self.updateProgressBar(currentProgress, self);

				// Since we have more files in the files array we call performSynchronousUploads again
				app.log.debug("Trying again - not complete yet, progress: " + currentProgress);
				self.performSynchronousUploads(files, successList, errorList, uploadIndex + 1, originalLength, self);
			} else {
				// Calling the functionality to update the progress bar to 100 and then hide it
				self.updateProgressBar(100, self);
				self.hideProgressBarAndTriggerDoneUploading(successList, errorList, self);
			}
		},
		/**
		 * Updates the progress bar
		 *
		 * @param {number} currentProgress - The determined value that the progress bar should be set to
		 * @param {Object} self - The context of this function.
		 */
		updateProgressBar: function(currentProgress, self) {
			// Trigger the functionality to update the progress bar
			app[self.options.myHandler].trigger("showProgress");
			app[self.options.myHandler].trigger("showInfo", window.localize("action.manageAdHocDocuments.uploadingDocuments"));
			app[self.options.myHandler].trigger("updateProgress", currentProgress);
		},
		/**
		 * Hides the progress bar and triggers addadhocdocuments:doneUploading
		 *
		 * @param {Array} successList - The array to add to if this file uploads successfully.
		 * @param {Array} errorList - The array to add to if this file fails to upload.
		 * @param {Object} self - The context of this function.
		 */
		hideProgressBarAndTriggerDoneUploading: function(successList, errorList, self) {
			// Trigger the functionality to update the progress bar
			app[self.options.myHandler].trigger("hideProgress");
			app[self.options.myHandler].trigger("hideInfo");
			$("#addAdHocDocuments-fileNames").empty();
			this.files = [];
			this.fileNames = [];
			$(".addAdHocUploadBtn").removeClass("disabled");
			self.render();
			if(errorList.length === 0) {//if there's nothing in the error List, everything was successful. Otherwise something failed
				$("#" + self.myHandler + "-message").html(self.config.getLocalizations().add.success).show();
				setTimeout(function(){
					$("#" + self.myHandler + "-message").hide();
				}, 3000);
				app.trigger("stage.refresh.bothIds", app.context.container.id, app.context.document.id);
			} else {
				$("#" + self.myHandler + "-error").html(self.config.getLocalizations().add.failure).show();
				setTimeout(function(){
					$("#" + self.myHandler + "-error").hide();
				}, 3000);
			}
		},
		/**
		 * Uploads a provided file.
		 * @param {Object} file - The file to upload.
		 * @param {Array} successList - The array to add to if this file uploads successfully.
		 * @param {Array} errorList - The array to add to if this file fails to upload.
		 * @returns {Object} - A deferred promise object that is resolved when the ajax request for uploading the file
		 * is completed.
		 */
		upload: function (file, successList, errorList) {
			var self = this;

			// the deferred to return when the ajax request for uploading this file is completed
			var deferred = $.Deferred();

			// this is the index of the document in the oco collection when we upload it (so we can pull off its
			// properties when the xhr resolves)
			var currentDocIndex = self.uploadIndex;

			// add our action params to the file we're going to upload, the addActionParamsToFile function returns a deferred
			// and resolves it since it may make an ajax call
			var doneAddingActionParams = this.addActionParamsToFile(file);

			// wait til we're done adding our action params to the file
			$.when(doneAddingActionParams).done(function () {
				// do our normal XHR upload
				self._doXHRUpload(file, currentDocIndex, deferred, successList, errorList);
			});

			// return our promise object so the calling function can wait til we've resolved
			return deferred.promise();
		},
		// adds the action parameters to the file object (that will get sent to OC eventually) and returns a deferred
		// since if you have dropOffScan functionality enabled, we may have to make an async call to grab the attributes
		// of the selected file's objectType so we can add the required parameters to the action parameters
		addActionParamsToFile: function (file) {
			// we're going to return a deferred from this function because it's possible we'll have to make an async
			// call to grab some attributes
			var addActionParamsDeferred = $.Deferred();

			var uploadSupportingDocAction = new Backbone.Model({
				name: 'bulkUpload',
				parameters: {
					objectId: this.parentFolderId,
					objectType: HPIConstants.ObjectTypes.AttachedDocument,
					properties: {
						 "prop-objectName": file.name,
						 "prop-isAdHoc": true
					},
					hideFileExtensions: "true"
				}
			});
			// add our formData object to the file - we'll attach the stringified action below in the appropriate place
			file.formData = {
				// helper function to set our stringified action on the file formData
				setActionAndResolve: function (uploadSupportingDocAction) {
					// stringify our action and set it on this object
					this.action = JSON.stringify(uploadSupportingDocAction);

					// resolve our deferred
					addActionParamsDeferred.resolve();
				}
			};

			file.formData.setActionAndResolve(uploadSupportingDocAction);

			// return the promise object for our deferred so the calling function can wait til we've resolved
			return addActionParamsDeferred.promise();
		},
		/**
		 * Performs an XHR upload for a passed in file. This method of uploading is not supported in IE<10.
		 * @param {Object} file - The file to upload.
		 * @param {number} currrentDocIndex - The index of the file we're uploading in our OCO collection so when
		 * we're done uploading the file we can access its properties.
		 * @param {Object} deferred - A deferred object to resolve when we're finished with the document upload.
		 * @param {Array} successList - The array to add to if this file uploads successfully.
		 * @param {Array} errorList - The array to add to if this file fails to upload.
		 */
		_doXHRUpload: function (file, currentDocIndex, deferred, successList, errorList) {
			var self = this;
			var xhr = new XMLHttpRequest();

			// keep track of progress, written to console for now
			xhr.upload.addEventListener("progress", function (e) {
				if (e.lengthComputable) {
					var percentage = Math.round((e.loaded * 100) / e.total);
					app.log.debug(percentage);
				}
			}, false);

			xhr.upload.addEventListener("load", function () { }, false);

			xhr.open("POST", app.serviceUrlRoot + '/action/executeWithAttachment');

			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4) {
					if (xhr.status >= 200 && xhr.status <= 202) {
						// do our success funcitonality
						var response = app.context.util.parseIEJSON(xhr.response);
						var objectIdArray = _.values(response.result); //this is broken up by the documents
						$.ajax({
							url: app.serviceUrlRoot + "/content/addRelation?parentID=" + self.formId +"&idArray=" + objectIdArray + 
							"&relationType=" + self.adHocRelation + "&isPermanent=false", 
							type: "POST",
							global: false, //prevent greying and ungreying for each doc
							success: function(doc){
								app[self.myHandler].trigger("loading", false);
								successList.push(doc);
							},
							error: function(doc){
								app[self.myHandler].trigger("loading", false);
								errorList.push(doc);
							}
						});
						// we're done with our ajax request for this file so resolve our deferred
                        deferred.resolve();
					}
				}

			};
			
			// build up our form data object to send with our XHR
			var fd = new FormData();
	
			fd.append('parts', file, file.name);
			
			// add the action parameters we built up
			fd.append('action', file.formData.action);

			// send our request
			xhr.send(fd);
		},
		// helper method to get an array of file names with either the extensions removed or not touched - the user may have
		// the action configured to hide file extensions
		getDisplayFileNames: function () {
			var self = this;

			// start with an empty array - we need to remove the file extension if the user configured the action to hide them
			var displayFileNames = [];

			// loop over each file and remove the extension if it's configured to do so
			_.each(this.fileNames, function (fileName) {
				if (self.options.hideFileExtensions === "true" || (self.options.options && self.options.options.hideFileExtensions === "true")) {
					// the file names array always has the full file name with the extension so if they don't want to display extensions
					// we have to strip it off first before adding it to the array to return
					displayFileNames.push(self.removeFileExt(fileName));
				} else { // we're not removing any extensions so just push on the normal file name with the extension
					displayFileNames.push(fileName);
				}
			});

			return displayFileNames;
		},
		/**
		 * Removes the file extension from the passed in filename. If there is no file extension on the passed in
		 * filename, the passed in filename is returned unchanged.
		 * @param {String} filename - The filename to remove the file extension from.
		 * @returns {String} - A string representing the passed in file name without its file extension.
		 */
		removeFileExt: function (filename) {
			var fileNameNoExt = filename.substr(0, filename.lastIndexOf('.'));
			// if there's no file extension (ie when creating a cover page) then this will come back as a blank string
			// in that case there's no file extension to remove, so just return the original name
			if (fileNameNoExt) {
				return fileNameNoExt;
			} else {
				return filename;
			}
		},
		serialize: function () {
			var tempFileList = [];
			_.each(this.getDisplayFileNames(), function (fileName) {
					tempFileList.push({
						name: fileName,
						hasError: false
					});
			});
			return {
				fileNames: tempFileList,
				modal: this.myHandler === "modalActionHandler"
			};
		}
	});
		
	// //Models
	ManageAdHocDocuments.Document = Backbone.Model.extend({
		defaults: function(){
			return _.extend({}, {
				objectId: '',
				oco: {},
				message: ''
			});
		},
		initialize: function(options){
			this.options = _.defaults(options, this.defaults);
			if(this.options.oco){
				this._id = this.options.oco.objectId;
				this.set('objectId', this.options.oco.objectId);
			}
		},
		validate: function(){
			return this.get('message');
		}
	});

	ManageAdHocDocuments.Documents = Backbone.Collection.extend({
		model: ManageAdHocDocuments.Document,
		initialize: function(options, config){
			this.config = config;
		},
		isValid: function(){
			return this.validate() ? false : true;
		},
		validate: function(){
			var docsValid = true;
			if(this.size() === 0){
				return this.config.getLocalizations().noAdHocDocumentsSelected;
			}
			this.each(function(doc){
				if(docsValid){
					docsValid = doc.isValid();
				}
			}, this);
			return docsValid ? undefined : this.config.getLocalizations().errorMessage;
		}
	});

	//Views
	ManageAdHocDocuments.ExistingAdHocDocumentsRow = Backbone.Layout.extend({
		tagName: 'tr',
		template: 'actions/manageadhocdocuments/existingadhocdocumentsrow',
		events: {
			'click .removeAdHocDocCheckbox': 'validate'
		},
		initialize: function(options){
			var self = this;
			this.config = options.config;
			this.attrs = this.config.getAttributes();
			this.model = options.model || new ManageAdHocDocuments.Document();
			//Order is based off of the order of the attrs array
			this.serializedAttributes = [];
			_.each(this.attrs, function(attr){
				if(attr.createLink){
					//Generate a direct content link
					var attrValue = this.model.get('oco')[attr.ocoName];
					var url = '<a data-bypass target="_blank" class="manageAdHocDocumentsLink" href="' + app.serviceUrlRoot 
					+ '/content/content/' + encodeURIComponent(attrValue) + '?id=' + this.model.get('objectId') + '&contentType[]=pdf&overlay=true' 
					+ '">' + attrValue + '</a>';
					this.serializedAttributes.push(url);
				}else if (attr.ocoName.toLowerCase().indexOf("date") != -1){
					app.context.dateService.getFormattedDatetime(new Date(this.model.get('oco')[attr.ocoName])).done(function(formattedDate) {
			            self.serializedAttributes.push(formattedDate);
			        });
					
				}else{
					this.serializedAttributes.push(this.model.get('oco')[attr.ocoName]);
				}
			}, this);

			//Whenever this doc is validated, re-render and show the message
			this.listenTo(this.model, 'change:message', function(obj, message){
				this.$('.message').html(message);
			}, this);
			
			this.listenTo(this.model, 'set:checkbox', function(checked){
				this.$('input[type=checkbox]').prop('checked', checked);
			});
		},
		validate: function(evt){
			var self = this;
			var isChecked = this.$(evt.currentTarget).is(':checked');
			//if checked and no message, validate
			if(isChecked && !this.model.get('message')){
				var isValid = this.config.validate(this.model.get('oco'));
				$.when(isValid).done(function(message){
					self.model.set('message', message);
					//make row red if ther's a message
					if(message){
						self.$el.addClass('danger');
					}
					self.model.trigger('pendingadHocDocuments:add');
				});
			}else if(!isChecked){
				this.model.trigger('pendingadHocDocuments:remove');
			}else if(isChecked){
				//already validated one way or the other
				self.model.trigger('pendingadHocDocuments:add');
			}
		},
		serialize: function(){
			return {
				'config': this.config,
				'attributes': this.serializedAttributes,
				'model': this.model.attributes,
				'message': this.model.get('message')
			};
		}
	});

	ManageAdHocDocuments.ExistingAdHocDocumentsTable = Backbone.Layout.extend({
		template: 'actions/manageadhocdocuments/existingadhocdocumentstable',
		initialize: function(options){
			this.config = options.config;
			this.headers = _.pluck(this.config.getAttributes(), 'displayName');

			this.config.showAdHocDocument = options.showAdHocDocument !== undefined ? options.showAdHocDocument : false;

			//if showing relationship names add a header for it
			if(this.config.showAdHocDocument){
				this.headers.push('Relation');
			}
			this.pendingAdHocDocument = options.pendingAdHocDocument || new ManageAdHocDocuments.Documents(undefined, this.config);

			this.documents = options.documents || new ManageAdHocDocuments.Documents(undefined, this.config);

			this.listenTo(this.documents, 'reset', this.reload, this);
		},
		reload: function(){
			this.render();
			this.removeView('.document-rows-outlet');
			this.documents.each(function(model){
				this.stopListening(model);
				//listen for this doc to be added or removed from the pending queue
				this.listenTo(model, 'pendingadHocDocuments:add', function(){
					this.pendingAdHocDocument.add(model);
					this.documents.trigger('check', model);
				}, this);
				this.listenTo(model, 'pendingadHocDocuments:remove', function(){
					this.pendingAdHocDocument.remove(model);
					this.documents.trigger('uncheck', model);
				}, this);
				this.insertView('.document-rows-outlet', new ManageAdHocDocuments.ExistingAdHocDocumentsRow({
					'config': this.config,
					'model': model
				})).render();
			}, this);
		},
		serialize: function(){
			return _.extend({
				'headers': this.headers,
				'showTable': this.documents.length
			}, this.config.getLocalizations());
		}
	});

	ManageAdHocDocuments.ExistingAdHocDocumentsView = Backbone.Layout.extend({
		template: "actions/manageadhocdocuments/existingadhocdocuments",
		events: {
			"click .removeAdHocDocumentsButton": "removeAdHocDocuments",
		},
		initialize: function(){
			this.config = this.options.config;
			this.adHocDocumentNames = this.options.adHocDocumentNames;
			this.action = this.options.action;
			this.adHocRelation = this.config.getRelationName();
			this.myHandler = this.options.myHandler;
			this.currentFormId = app.context.container.get("properties").objectId;
			this.showAdHocDocuments = true;
			this.pendingAdHocDocument = new ManageAdHocDocuments.Documents(undefined, this.config);
			this.existingAdHocDocument = new ManageAdHocDocuments.Documents(undefined, this.config);

			this.existingAdHocDocumentsTable = new ManageAdHocDocuments.ExistingAdHocDocumentsTable({
				'pendingAdHocDocument': this.pendingAdHocDocument,
				'documents': this.existingAdHocDocument,
				'config': this.config
			});

			//listen for pending adHocDocuments and check if all are valid
			this.listenTo(this.pendingAdHocDocument, 'add remove', function(){
				this.allRelationDocsValid = this.pendingAdHocDocument.isValid();
				if(this.allRelationDocsValid){
					this.$('.removeAdHocDocumentsButton').removeClass('disabled');
				}else{
					this.$('.removeAdHocDocumentsButton').addClass('disabled');
				}
			}, this);	
		},
		getExistingAdHocDocuments: function(){
			var self = this;
			this.spinner = HPISpinner.createSpinner({
				top: '50%',
				left: '102%',
                color: '#666'
            }, this.$el.find(".loadRelationDiv")[0]);
			return $.ajax({
				url: app.serviceUrlRoot + "/content/getChildRelations?id=" + this.currentFormId +
				"&relationName=" + self.adHocRelation, 
				type: "GET",
				success: function(childOcos){
					var ocos = [];
					var fullCollection = new OC.OpenContentObjectCollection(childOcos);
					fullCollection.each(function(oco){
						ocos.push(_.extend({}, oco.get("properties"), {
							"objectId": oco.get("objectId"),
							"objectName": oco.get("properties").objectName,
							"title": oco.get("properties").title,
						}));
					});

					//This ensures that the documents that weren't add with ad hoc aren't visible
					ocos = _.where(ocos,{
						'isAdHoc': true 
					});

					//build up Document models
					var documents = [];
					_.each(ocos, function(oco){
						//get oco and the currently set relation name
						documents.push(new ManageAdHocDocuments.Document({
							'selectedRelation': self.adHocRelation,
							'oco': oco
						}));
					}, this);
					self.existingAdHocDocument.reset(documents);
					//wait a sec
					window.setTimeout(function(){
						if(self.spinner){
							HPISpinner.destroySpinner(self.spinner);
						}
					}, 1000);
				},
				error: function(){
					if(self.spinner){
						HPISpinner.destroySpinner(self.spinner);
					}
					app.log.debug("Error getting existing adHocDocuments");
				}
			});	
		},
		removeAdHocDocuments: function(){
			var self = this;

			app[self.myHandler].trigger("loading", true);
			var objectsToDelete = "";
			var modelsToRemove = [];

			_.each(this.existingAdHocDocumentsTable.pendingAdHocDocument.models,function(doc) {
				objectsToDelete+="&objectId="+doc.get("objectId");
				modelsToRemove.push(doc);
			});
			this.existingAdHocDocumentsTable.pendingAdHocDocument.remove(modelsToRemove);
			$.ajax({
				url: app.serviceUrlRoot + "/content/deleteObjects?allVersions=true" + objectsToDelete,
				type: "POST",
				success: function(){
					app[self.myHandler].trigger("loading", false);
					$("#" + self.myHandler + "-message").html(self.config.getLocalizations().remove.success).show();
					self.getExistingAdHocDocuments();
					setTimeout(function(){
						$("#" + self.myHandler + "-message").hide();
					}, 2000);
					app.trigger("stage.refresh.bothIds", app.context.container.id, app.context.document.id);
				},
				error: function(){
					app[self.myHandler].trigger("loading", false);
					$("#" + self.myHandler + "-error").html(self.config.getLocalizations().remove.failure).show();
					self.getExistingAdHocDocuments();
					setTimeout(function(){
						$("#" + self.myHandler + "-error").hide();
					}, 2000);
				}
			});
			this.render();
		},
		beforeRender: function(){
			this.setView('.existing-adhocdocuments-table-outlet', this.existingAdHocDocumentsTable);
		},
		afterRender: function(){
			this.getExistingAdHocDocuments();
		},
		serialize: function(){
			return _.extend({
				'adHocDocumentNames': this.adHocDocumentNames,
				'showAdHocDocuments': this.showAdHocDocuments,
				'allRelationDocsValid': this.allRelationDocsValid
			}, this.config.getLocalizations());
		}
	});

	actionModules.registerAction("manageAdHocDocuments", ManageAdHocDocuments, {
		"actionId": "manageAdHocDocuments",
		"label": "Manage Ad Hoc Documents",
		"icon": "file-plus"
	});

	return ManageAdHocDocuments;
});
require['manageadhocdocuments'];