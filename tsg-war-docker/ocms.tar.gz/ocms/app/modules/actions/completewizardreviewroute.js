define("completewizardreviewroute",[
  // Application.
  "app",
  "modules/actions/actionmodules",
  "modules/hpiadmin/picklistconfig/picklistconfig"
],

// Map dependencies from above array.
function(app, actionModules, PicklistConfig) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    action.View = Backbone.Layout.extend({
		template: "actions/completewizardreviewroute",
        events: {
            "keyup #inputComment": "keyCheck"
        },
		defaults:{
			'allowVoting': 'false',
			'picklistName': 'Voting Options', //default picklist name - configure this in the completewizardreviewroute admin
			'allowWfRejection': 'false'
		},
		initialize: function() {
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
			// override any default properties with the configured values from the action config in the admin
            this.options = _.extend({}, this.defaults, this.options.config.attributes);

            this.allowVoting = this.options.allowVoting === "true" ? true : false; //convert from stringified boolean to real bool
            this.allowWfRejection = this.options.allowWfRejection === "true" ? true : false;
            this.rejectionKeyword = this.options.rejectionKeyword;
            this.enableComment = this.options.enableComment === "true" ? true : false;
            this.eSigReviewComment = ko.observable();
            this.maxASCIICharNum = 127;

		},
		beforeRender: function() {
			var self = this;

			self.picklistOptions = ko.observableArray([]);
			self.defaultOption = ko.observable();
            //load the picklist of voting options
            app.context.picklistService.getPicklist(this.options.picklistName, function(picklistOptions, defaultOption, picklistName){
            	var values = [];
            	_.each(picklistOptions, function(picklistItem){
            		values.push(picklistItem.label);
            	});
            	self.picklistOptions(values);
            	self.defaultOption(defaultOption);
            });

			this.viewModel = {

				taskId : ko.observable(),
				objectId : self.action.get("parameters").objectId,
				allowVoting: ko.observable(self.options.allowVoting),
				allowWfRejection: ko.observable(self.options.allowWfRejection),
				rejectionKeyword: ko.observable(self.options.rejectionKeyword),
                enableComment: ko.observable(self.options.enableComment),
                eSigReviewComment: ko.observable(),
				votingOptions: self.picklistOptions,
				vote: self.defaultOption,
				formComplete: ko.computed(function(){
					return self.defaultOption() && self.defaultOption() !== '';
				}),
				setTaskId : function(){
					var opts = {
						type : "GET",
						contentType: "application/json",
						url: app.serviceUrlRoot + "/aw-workflow/getMyWizardTasks?formId=" + self.action.get("parameters").objectId,
						data: JSON.stringify({
						}),
						success: function(result){
							if(result === null || result === undefined){
								app[self.myHandler].trigger("showError", (window.localize("modules.actions.completeWizardReviewRoute.noTasksFound")));
							}	
							//should only have one task if this is the basic review route
							self.viewModel.taskId(result[0].id);
						},
						error: function(){
							app[self.myHandler].trigger("showError", (window.localize("modules.actions.completeWizardReviewRoute.errorRetrieving")));
						}
					};

					$.ajax(opts);
				},
				onSubmit : function() {
					app.log.debug((window.localize("modules.actions.completeWizardReviewRoute.timeToSubmit")));
					//taskId must be on the config
					if(self.viewModel.taskId() === undefined){
						app[self.myHandler].trigger("showError", (window.localize("modules.actions.completeWizardReviewRoute.unableToComplete")));
					}else{
						app.log.debug("time to submit this form");
				
						self.toggleLoader(true);

						//set our params
						self.action.get("parameters").taskId = self.viewModel.taskId();
						self.action.get("parameters").completionType = "approve";
                        self.action.get("parameters").comments = self.viewModel.eSigReviewComment();
						//only cast vote if configured
						if(self.options.allowVoting === "true"){
							self.action.get("parameters").vote = self.viewModel.vote();
							self.action.get("parameters").allowWfRejection = self.viewModel.allowWfRejection();
							self.action.get("parameters").rejectionKeyword = self.viewModel.rejectionKeyword();
						}
						self.action.execute({
							success : function(data) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.completeWizardReviewRoute.reviewTask")));

								app.listenToOnce(app[self.myHandler], "hide", function() {
									app.trigger("stage.refresh.bothIds", self.viewModel.objectId, self.viewModel.objectId);
								});
								
							},
							error : function(jqXHR, textStatus, errorThrown) {
								self.toggleLoader(false);
								app[self.myHandler].trigger("showError", (window.localize("modules.actions.completeWizardReviewRoute.failedToComplete")) +
										jqXHR.status + " " + jqXHR.statusText);
							}
						});
					}
				}
			};
		},
        keyCheck: function(event) {
            if(event.target.textLength>this.maxASCIICharNum){
                return false;
            }
            return true;
        },
		afterRender: function(){
			this.viewModel.setTaskId();
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
		serialize: function() {
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				votingEnabled : this.options.allowVoting === "true",
                commentEnabled : this.options.enableComment === "true",
				modal: modal
			};
		}
	});

	// Custom config view for HPI admin configuration
    action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/completewizardreviewroute",

        initialize: function () {
            var viewModel = this.options.viewModel;

            //by default, auto-select reviewers is true
            viewModel.allowVoting = kb.observable(viewModel.model(), "allowVoting");
            viewModel.allowWfRejection = kb.observable(viewModel.model(), "allowWfRejection");
            viewModel.rejectionKeyword = kb.observable(viewModel.model(), "rejectionKeyword");

            viewModel.enableComment = kb.observable(viewModel.model(), "enableComment");

            viewModel.picklists = ko.observableArray();

            viewModel.showVoting = ko.computed(function(){
            	return viewModel.allowVoting() === 'true' ? true : false;
			});

			viewModel.showRejectionTextbox = ko.computed(function(){
            	return viewModel.showVoting() && viewModel.allowWfRejection() === 'true';
			});

            viewModel.picklistName = kb.observable(viewModel.model(), "picklistName");

            var picklistName = viewModel.picklistName();
            // get our picklist config and fetch it - findOrCreateConfig is not async
			var plc = app.context.findOrCreateConfig(PicklistConfig.Model, "default");

			plc.fetch({
				success: function(plConfig){
					var plNames = [];
	            	plConfig.get('picklists').each(function(picklist){
	            		plNames.push(picklist.get('label'));
	            	});
	            	viewModel.picklists(plNames);

	            	//picklist updated, apply the persisted value
	            	viewModel.picklistName(picklistName);					
				},
				error: function(){
					app.trigger("alert:error", {
						header: (window.localize("generic.alert")),
						message: (window.localize("modules.actions.completeWizardReviewRoute.weAreUnable"))
					});
				}
			});

            //default allowVoting to false
            if(viewModel.allowVoting() === null){
                viewModel.allowVoting("false");
            }

            //default allowWfRejection to false
            if(viewModel.allowWfRejection() === null){
                viewModel.allowWfRejection("false");
            }

            //default enableComment to false
            if(viewModel.enableComment() === null){
                viewModel.enableComment("false");
            }
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

	actionModules.registerAction("completeWizardReviewRoute", action, {
        "actionId" : "completeWizardReviewRoute",
      	"label" : (window.localize("modules.actions.completeWizardReviewRoute.completeWizardReview")),
      	"icon" : "ok",
      	"groups" : ["wizard", "complete", "review"]
    });

	return action;
});
require(["completewizardreviewroute"]);