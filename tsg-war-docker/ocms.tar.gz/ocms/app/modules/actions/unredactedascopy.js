define("unredactedascopy",[
    "app",
    "modules/actions/actionmodules"
],
function(app, actionModules) {
    "use strict";

    var UnredactedAsCopy = {};
    
    UnredactedAsCopy.View = Backbone.Layout.extend({
        template: "actions/redaction",
        events: {
            "click #redact-ok" : "dismiss"
        },
        initialize: function() {
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");

            // Opening OA in separate window to begin redaction
            window.open(app.openAnnotateURL +
             "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&parentId=" + app.context.container.get('properties').objectId +
                    "&username=" + app.user.get("loginName") + "&mode=redact" + "&redactionMode=unredactedAsCopy");
        },
        serialize: function() {
            return {
                message: window.localize("modules.actions.redaction.wereOpening"),
                modal: this.myHandler === "modalActionHandler"
            };
        },
        dismiss: function() {
            app.trigger("stage.refresh.documentId", true);
        }
    });

    //action registers itself with getAction in actionModules
    actionModules.registerAction("unredactedAsCopy", UnredactedAsCopy, {
       "actionId": "unredactedAsCopy",
       "label": window.localize("modules.actions.unredactedAsCopy.redactSave"),
       "icon": "exclamation-sign"
    });

    return UnredactedAsCopy;
});
require(["unredactedascopy"]);