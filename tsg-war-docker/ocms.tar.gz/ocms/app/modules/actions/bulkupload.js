define("bulkupload", [
    "app",
    "context",
    "handlebars",
    "modules/formsupport",
    "modules/common/tossacross",
    "modules/common/scanner/scanner",
    "modules/common/addDocTemplate/addDocTemplate",
    "modules/common/printToRepo/printToRepo",
    "modules/common/addfromexistingcontent/addfromexistingcontent",
    "modules/common/action",
    "modules/common/cloudlinkauthentication",
    "modules/common/cloudlinkutils",
    "modules/common/gmailupload",
    "modules/common/slickgridtableview",
    "modules/common/ocquery",
    "oc",
    "modules/hpiadmin/common/iosswitch",
    "modules/actions/actionmodules",
    "modules/common/spinner",
    "modules/common/typeahead",
    "modules/common/propertiesview",
    "modules/services/boxstorageintegrationservice",
    "foldernotes",
    "modules/hpiadmin/oamodeselect",
    "module",
    "modules/common/hpiconstants",
    'modules/hpiadmin/adminUtil',
    "modules/services/logstashservice",
    "modules/externalEventsModule",
    "modules/common/useragent",
    "tsgUtils",
    "dateformat",
    "scrollable"
],

    function (app, context, Handlebars, Formsupport, TossAcross, Scanner, AddDocTemplate, printToRepo, AddFromExistingContent, Action, CloudLinkAuthenticaion, CloudLinkUtils
        , GmailUpload, SlickGridTableView, OCQuery, OC, iOSSwitch, actionModules, HPISpinner, HPITypeAhead, PropertiesView,
         BoxStorageIntegrationService, FolderNotes, OAModeSelect, module, HPIConstants, AdminUtil, LogstashService, ExternalEventsModule, UserAgent, tsgUtils) {
        var BulkUpload = {
            CONSTANTS: {
                "ZIP" :"zip",
                "EMAIL" : "email"
            }
        };
        var uploadSizeErrorList = [];
        var hasTotalUploadSizeError = false;
        var totalUploadSize = 0;

        BulkUpload._removeOldListener = function (listenerName) {
            if (app._events[listenerName] && app._events[listenerName].length > 0) {
                app._events[listenerName] = [];
            }
        };

        BulkUpload.updateErrorModal = function (myHandler, totalLimit, singleUploadLimit) {
            if (uploadSizeErrorList.length === 0) {
                if (!hasTotalUploadSizeError) {
                    app[myHandler].trigger("hideError");
                } else {
                    app[myHandler].trigger("showError", window.localize("action.bulkUpload.totalUploadCapacityFirstHalf") + totalLimit + window.localize("action.bulkUpload.totalUploadCapacitySecondHalf"), true);
                }
            } else {
                var errorText = "";
                _.each(uploadSizeErrorList, function (fileName) {
                    errorText += "<li>" + fileName + "</li>";
                });
                if (hasTotalUploadSizeError) {
                    app[myHandler].trigger("showError", window.localize("action.bulkUpload.totalUploadCapacityFirstHalf") + totalLimit + window.localize("action.bulkUpload.totalUploadCapacitySecondHalf") + "<br><br> " + window.localize("action.bulkUpload.singleUploadCapacityFirstHalf") + singleUploadLimit + window.localize("action.bulkUpload.singleUploadCapacitySecondHalf") + "<ul>" + errorText + "</ul>", true);
                } else {
                    app[myHandler].trigger("showError", window.localize("action.bulkUpload.singleUploadCapacityFirstHalf") + singleUploadLimit + window.localize("action.bulkUpload.singleUploadCapacitySecondHalf") + "<ul>" + errorText + "</ul>", true);
                }
            }
        };

        // this method sets the properties to be inherited from the folder
        var getPropsToInherit = BulkUpload._getPropsToInherit = function (objectType, formName) {
            var deferred = $.Deferred();
            var propsToInherit = {};
            //If objectType is not defined we shouldn't even try to make this call, return the deferred.resolve and move on
            if (objectType) {
                // each time the objectType changes, we'll want to get the parent folder properties,
                // strip out any folder specific attributes, and extend it across the document otc
                app.context.configService.getFormTypeConfig(formName, objectType, function (config) {

                    var containerProps = app.context.container.get("properties");
                    // if the propMap was not set for some reason.
                    if (!containerProps) {
                        app.context.container.fetch({
                            success: function (fetchedResult) {
                                containerProps = fetchedResult.get("properties");
                            },
                            async: false,
                            global: false
                        });
                    }
                    var otcProps = config.get('configuredAttrsPri').pluck('ocName');

                    var rejectProps = ['objectName', 'document_type', 'creationDate', 'modifiedDate'];

                    otcProps = _.reject(otcProps, function (prop) {
                        return _.contains(rejectProps, prop);
                    });

                    // omit any attributes that are labelled as NONE and return the ocNames
                    var omittedAttributes = new Backbone.Collection(config.get('configuredAttrsPri').where({
                        'controlType': 'NONE'
                    })).pluck('ocName');
                    otcProps = _.reject(otcProps, function (prop) {
                        return _.contains(omittedAttributes, prop);
                    });

                    var containerKeys = [];
                    // get only ocNames from container
                    _.each(containerProps, function (value, key) {
                        containerKeys.push(key);
                    });
                    // only extend properties whitelisted by the document's otc
                    var whiteListedProps = _.intersection(otcProps, containerKeys);

                    // ok list built, populate the values
                    _.each(whiteListedProps, function (ocName) {
                        // if the folder actually has a value that we can inherit, let's add it to the list of values to inherit
                        if (containerProps[ocName]) {
                            propsToInherit[ocName] = containerProps[ocName];
                        }
                    });

                    deferred.resolve(propsToInherit);
                }, app.context.configName());
                return deferred.promise();
            } else {
                return deferred.resolve();
            }

        };

        // this represents a view model for a path configuration for an object type
        BulkUpload.TypePathViewModel = function (options) {
            var self = this;

            self.model = options.model;
            // the value of the objectType
            self.objectType = options.objectType;

            // the server data with trac configurations
            self.typePathServerData = options.typePathServerData;

            self.typeLabel = ko.observable("");
            app.context.configService.getLabels(self.objectType).done(function (typeLabel) {
                self.typeLabel(typeLabel);
            });

            // the path that is displayed on the admin screen
            self.computedPath = ko.observable("");
            if (options.path) { // the path will be set if we get data back from the server
                self.computedPath(options.path);
            }

            // every time the observable's value changes, update that object type's path in the server data map
            self.computedPath.subscribe(function (newValue) {
                if (!self.typePathServerData[options.formName]) {
                    self.typePathServerData[options.formName] = {};
                }
                self.typePathServerData[options.formName][self.objectType] = newValue;
                self.model.set("customTypePaths", self.typePathServerData);
            });
        };

        // acting as a ViewModel for an individual document type attribute configuation
        BulkUpload.TypeAttributeViewModel = function (options) {
            var self = this;

            // type attribute server data that needs to be updated when a type attribute's attributes change
            self.typeAttributeServerData = options.typeAttributeServerData;

            // the value of the objectType
            self.objectType = options.objectType;

            // the display label of the objectType on the admin screen
            self.typeLabel = ko.observable(options.typeLabel || "");
            // if the label isn't passed in (when we get the data from the server), fetch the type label
            if (!self.typeLabel()) {
                app.context.configService.getLabels(self.objectType).done(function (typeLabel) {
                    self.typeLabel(typeLabel);
                });
            }

            // the different attributes the objectType has that can be displayed on the cover page
            self.availableCoverPageAttributes = ko.observableArray([]);
            // the selected attributes the user wants to display on the cover page
            self.selectedCoverPageAttributes = ko.observableArray(self.typeAttributeServerData[self.objectType] || []);

            // this fetches all the available attributes for a user to use for configuration for a type
            app.context.configService.getAdminTypeConfig(self.objectType, function (typeConfig) {
                // partition the returned attributes into the selected attributes to use for the cover page and the available
                // attributes the user can add to the selected ones
                var partitionedAttrs = _.partition(typeConfig.get("attrs").models, function (attr) {
                    return _.findWhere(self.selectedCoverPageAttributes(), {
                        ocName: attr.get("ocName")
                    });
                });


                // we only want the lable and ocName properties of the available attributes
                self.availableCoverPageAttributes(partitionedAttrs[1].map(function (attr) {
                    return {
                        label: attr.get("label"),
                        ocName: attr.get("ocName")
                    };
                }));
            });

            // every time the selected attributes are updated, set the new list onto the server data for this object type
            self.selectedCoverPageAttributes.subscribe(function (values) {
                self.typeAttributeServerData[self.objectType] = values;
            });
        };

        // Main view of bulkupload
        BulkUpload.View = Backbone.Layout.extend({

            template: "actions/bulkupload/bulkupload",

            events: {
                // click event for the "Next" button on the choose files to upload page
                "click #acceptFileList": "acceptFileList",
                "click .cloudStorageIntegration": "cloudStorageIntegration",
                "click #propIndexButton": "propertyIndexing",
                "click .scanDocButton": "scanDoc",
                "click .templateDocButton": "templateDoc",
                "click .createDocFromExistingContentButton": "createDocFromExistingContent",
                "click .gmailUploadButton": "gmailUpload",
                // a click event for the "Generate Cover Page" button
                "click #dropOffScanButton": "dropOffScan",
                "focus .form-control": "initiateIndexerAnnotation",
                "blur .form-control": "inputBoxDeselected"   
            
            },

            cleanup: function () {
                // COMPLETELY UNBIND THE VIEW
                this.undelegateEvents();

                this.$el.removeData().unbind();
            },

            initialize: function () {
                var self = this;

                // handler if this is a modal or right side configured action
                this.myHandler = this.options.config.get("handler");

                // default properties that get overriden by configured properties
                var defaults = {
                    // using the config method for getPropsToInherit so clients can override this method
                    'getPropsToInherit': this.options.config.getPropsToInherit,
                    'containerPath': '',
                    'createPdfRendition': 'false',
                    'enableLookUp': 'false',
                    'lookUpSearchConfig': '',
                    'inheritFolderAttributes': 'false',
                    'scannerConfig': 'false',
                    'addDocTemplateEnabled': 'false',
                    'enablePathSecurityCheck': 'false',
                    'createDocFromContentEnabled': 'false',
                    'gmailUploadEnabled': 'false',
                    'scannerLicense': '',
                    'dropOffScanning': 'false',
                    'dropOffScanningAttribute': 'objectId',
                    'printBarcodePageText': 'Generate Cover Page',
                    'coverPageTitle': 'Scanning Cover Page',
                    'customAttrsOnCoverPage': 'false',
                    'auditTrail': 'false',
                    'auditTrailObjectType': 'HPI Note',
                    'auditTrailNoteType': 'Audit Trail',
                    'auditTrailRelationship': '',
                    'parseForLinks': 'false',
                    'dropsClientKey': 'UNSET',
                    'dropboxClientSecret': 'UNSET',
                    'googleClientId': 'UNSET',
                    'microsoftClientId': 'UNSET',
                    'gmailUploadClientId': 'UNSET',
                    'enableSetNewVersion': 'false',
                    'enableDocumentLinkTracResolving': 'false',
                    'indexingMode': 'false',
                    'printMode' : 'false',
                    'fileNamesUniqueCheckRequired' : 'false',
                    'oaviewerMode': 'indexer',
                    'isCustomBulkPropertiesFormConfigured': 'false',
                    'isTrackerThumbnailsEnabled': 'true',
                    'cloudIntegration': 'false',
                    'customTypePaths': {},
                    "AWSTextractEnabled" : 'false',
                    'attrToShow': 'objectName',
                    'defaultDocumentTypesWhiteListed' : module.config().defaultDocumentTypesWhiteListed,
                    'extenWhiteList': module.config().oaIframeExtenWhiteList || HPIConstants.oaIframeExtenWhiteList,
                    'currentDocIndex': 0
                };
                //saving contextlessActionOptions on the view
                this.contextlessActionOptions = this.options.contextlessActionOptions;

                if (!this.config.get("isHeaderMode")) {
                    //if we don't have one, then we must not be in the context-less upload, we should use the trac were in.
                    this.lookUpSearchConfig = app.context.configName();
                }else{
                    this.lookUpSearchConfig = this.config.get("lookUpSearchConfig");
                }

                // an indicator if the user has clicked the next button from the choose files page
                this.filesAccepted = false;
                this.scanning = false;
                this.templating = false;
                this.addFromExisting = false;
                this.hasNext = false;

                // variables used when we are using indexing mode
                this.hasIndexing = false;
                this.indexingIframe = false;
                this.indexerFileDocIds = [];
                this.currentDocId = "";
                this.hasBoxSelected = false;

                // a counter so we can append a number to the end of a cover page in case a user wants to generate
                // two or more cover pages
                this.numCoverPages = 0;

                // a unique ID to apply to each MSG/ZIP file chosen for upload so we can attach its attachments' properties to it
                // when we create the email and attachments
                this.emailId = 1;
                this.zipId = 1;
                // we keep track of the filenames here so that we can bounce them between gmailupload and the bulkupload
                this.fileNames = [];

                // override any default properties with the configured values from the action config in the admin
                this.options = _.extend(defaults, this.options.config.attributes);

                //convert printMode into boolean to show/hide print from repo table
                this.printMode = this.options.printMode === "true";

                // If there is a separate form that is set up for bulk properties page 
                this.isCustomBulkPropertiesFormConfigured = this.options.isCustomBulkPropertiesFormConfigured === 'true';

                //check appConfig for configuration of file extensions
                app.context.configService.getApplicationConfig(function (config) {
                    // Make sure that configs about regex replacements are available
                    self.options.sterilizeAttributes = {
                        "shouldSterilizeFilenames": config.attributes.shouldSterilizeFilenames,
                        "regexToSterilizeFilenamesWith": config.attributes.regexToSterilizeFilenamesWith,
                        "sterilizeReplacementString": config.attributes.sterilizeReplacementString
                    };

                    self.options.hideFileExtensions = config.get('hideFileExtensions') || 'false';

                    // IE8 and IE9 will not have drag and drop support so we'll use the flash upload view instead of our nice
                    // HTML 5 way of uploading
                    self.uploadControllerView = new BulkUpload.HTML5UploadControllerView({
                        options: self.options,
                        fileNames: self.fileNames
                    });

                    self.activeChildView = self.uploadControllerView;

                    // these are the controls on the upload page that allow a user to choose a file or click the next button
                    // (with extension for scanning and generating cover pages)
                    self.uploadControls = new BulkUpload.UploadControls({
                        config: self.options
                    });
                });

                if(this.printMode){
                    //show print from repo view
                    this.printToRepo(true);
                }

                this._removeAndReplaceOldListeners();
            },
            _goToBulkProperties: function (){
                var self = this;

                var formName = this.options.form;
                if(this.isCustomBulkPropertiesFormConfigured){
                    formName = this.options.bulkPropertiesForm;
                }

                this.bulkPropertiesView = new BulkUpload.BulkPropertiesView({
                    fileNames: this.activeChildView.getDisplayFileNames(),
                    ocos: this.activeChildView.getOcos(),
                    inheritFolderAttributes: this.options.inheritFolderAttributes,
                    getPropsToInherit: this.options.getPropsToInherit,
                    formName: formName,
                    customTypePaths: this.options.customTypePaths,
                    enablePathSecurityCheck: this.options.enablePathSecurityCheck
                });

                var controls = new BulkUpload.PaginationControls({
                    showIndex: false,
                    showRequired: false,
                    hasNext: false,
                    hasPrevious: false,
                    allowFinish: false,
                    enableLookUp: this.options.enableLookUp === 'true' ? true : false,
                    lookUpSearchConfig: this.lookUpSearchConfig,
                    myHandler: this.myHandler,
                    fileNamesUniqueCheckRequired: this.options.fileNamesUniqueCheckRequired === 'true'
                });

                this.setView('#properties-section', this.bulkPropertiesView);

                // now that we've created our object type picker view and have attached our listener, we can go ahead and resolve
                // the object type, which will trigger our generateFormSupoort event once the object type has been resolved
                this.bulkPropertiesView.objectTypePicker.resolveObjectType().done(function () {
                    // once the object type picker has resolved, we can go ahead and render since we'll have our list of object types
                    // to pick from
                    self.bulkPropertiesView.render();

                    self.setView("#uploadFileControls", controls).render();

                    // we're already listening to the nextPressed button click (when we initalized this view) and if we don't stop listening
                    // before we listen to the event, we'll end up listening to the event twice which will cause bad behavior (cause form support
                    // to be generated twice - trust me, you don't want that to happen)
                    self.stopListening(app, "bulkupload:nextPressed");
                    self.listenToOnce(app, "bulkupload:nextPressed", self.loadSequentialPropertiesView);
                });
            },

            /**
             * This function is uploaded a parent folder (ZIP, MSG currently supported) for parsing that could possibly have attachments on it
             */
            uploadItemsWithAttachments: function() {
                // find if the user has chosen any MSG/Zip files to upload - we only want to parse the MSG/Zip files for their
                // attachments once, so also check the array that contains the MSG/Zip file names we've checked already
                this.uploadFileType('isMSGFile', 'addEmail', 'numMessagesToParse', 'uploadMSGFileForParsing');
                this.uploadFileType('isZIPFile', 'addZip', 'numZipsToParse', 'uploadZipFileForParsing');
                
            },

            /**
             * Goes through and uploads the files that are children of the MSG or ZIP files that have been selected
             * @param {String} isTypeFileFunc calls either the isMSGFile or isZIPFile Function
             * @param {String} addFileType addEmail or addZip file, will be a boolean
             * @param {String} typeToParse numMessagesToParse or numZipsToParse, number of the specific files to parse
             * @param {String} uploadFileTypeForParsing uploadMSGFileForParsing or uploadZipFileForParsing function to upload the filetype to be parsed for attachments
            **/
            uploadFileType: function(isTypeFileFunc, addFileType, typeToParse, uploadFileTypeForParsing) {
				//going through and pulling the files that will need further parsing (ZIP and MSG files) and storing those files
                var filesToParse = _.filter(this.activeChildView.getFileNames(), function (filename) {
                    return !_.contains(this.activeChildView.getCheckedFileNames(), filename) && this.activeChildView[isTypeFileFunc](filename);
                },this);

                var numFilesToParse = filesToParse.length;
                var filesParsed = 0;

                if (this.options[addFileType]) {
                    // set on our upload controls how many MSG/Zip files need to be parsed - that way our upload
                    // controls can resist from parsing an MSG/Zip file that has already been parsed
                    this.uploadControls[typeToParse] = numFilesToParse;
                }

                if (numFilesToParse > 0) {
                    // trigger the event that we're processing attachments so we can display a notification to the user
                    app.trigger('bulkupload:processingAttachments', true);

                    _.each(filesToParse,function (filename) {
                        // add this MSG/Zip file name to the list of files we've checked so we don't check it again
                        this.activeChildView.addCheckedFileName(filename);
                        // let's upload our MSG/Zip/Zip file so we can parse it for attachments
                        this[uploadFileTypeForParsing](filename).always(
                            this.processFileDeferred(isTypeFileFunc, addFileType, filesParsed, numFilesToParse));
                    },this);
                }
            },
            /**
             * if we're using the add email action, we want to update our upload controls
             * to have a new deferred for processing the emails in case the user wants to
             * upload another email
             * @param {String} isTypeFileFunc - calls either the isMSGFile or isZIPFile Function
             * @param {String} addFileType - addEmail or addZip file, will be a boolean
             * @param {*} filesParsed - number of files that have been parsed
             * @param {*} numFilesToParse - the number of files (ZIPs or MSGs currently supported) that need to be parsed for attachments
             */
            processFileDeferred: function(isTypeFileFunc, addFileType, filesParsed, numFilesToParse){
                
                if (isTypeFileFunc === 'isMSGFile' && this.options[addFileType]) {
                    //we only defer Emails right now, in the future we might defer other types, but specify for this right now
                    this.uploadControls.processingEmailDeferred = $.Deferred();
                }

                // we've finished parsing another message
                filesParsed++;

                // if we've parsed all the MSG/Zip files the user has selected to upload, trigger the event
                // to hide the processing email attachments message and spinner
                if (filesParsed === numFilesToParse) {
                    app.trigger('bulkupload:processingAttachments', false);
                }
            },
            
            _removeAndReplaceOldListeners: function(){
                var self = this; 

                BulkUpload._removeOldListener("retrievedDocIds");
                
                this.listenTo(app, "retrievedDocIds", function (docIds) {
                    this.indexerFileDocIds = docIds;
                    this.currentDocId = this.indexerFileDocIds[0];
                });

                BulkUpload._removeOldListener("changeCurrentDocId");

                this.listenTo(app, "changeCurrentDocId", function (index) {
                    this.currentDocId = this.indexerFileDocIds[--index];
                    this.render();
                });


                BulkUpload._removeOldListener("bulkupload:getIndexerTempDocIds");

                this.listenTo(app, "bulkupload:getIndexerTempDocIds", function(cb){
                    cb(this.indexerFileDocIds);
                });
                
                // Adds the OA Iframe view for the correct doc types
                BulkUpload._removeOldListener("addIndexingIframe");
                this.listenTo(app, "addIndexingIframe", this._addOrRemoveOAIframeView);
                
                BulkUpload._removeOldListener("disableIndexingIframe");
                this.listenTo(app, "disableIndexingIframe", this._disableOAIframeView);

                BulkUpload._removeOldListener("disableIndexing");

                this.listenTo(app, "disableIndexing", function () {
                    this.hasIndexing = false;
                    this.render();
                });

                BulkUpload._removeOldListener("authentication:finished");

                // Listen for all cloud link authentication to finish, then attempt to upload all of
                // the indicated files
                this.listenTo(app, "authentication:finished", function (data) {
                    _.each(data, function (links, service) {
                        // for each selected link
                        _.each(data[service].selectedLinks, function (link) {
                            // add the document objects associated with that link
                            // parse the folder or document id out of the url
                            var id = CloudLinkUtils[service].parseLink(link);
                            CloudLinkUtils[service].getDocuments(id, data[service].authentication);
                        });
                    });
                });

                BulkUpload._removeOldListener("bulkupload:docUploaded");

                this.listenTo(app, "bulkupload:docUploaded", function (object) {
                    if (self.config.get("isHeaderMode")) {
                        //sometimes we come in here with "/hpi" already
                        if (object.url.indexOf(app.root) !== -1) {
                            object.url = object.url.substring(object.url.indexOf(app.root) + app.root.length);
                        }
                        Backbone.history.navigate(object.url, {
                            trigger: true
                        });
                    } else {
                        app.trigger("stage.refresh.documentId", object.objectId);
                        if (this.myHandler === "modalActionHandler") {
                            app[this.myHandler].trigger("hide");
                        }
                    }
                });

                //This is hacky and hopefully a temp fix.  This is in an effort to get rid of the duplication of attachments on emails.
                //Here we are "resetting" the event on app, since we aren't getting backbone to clear it properly
                BulkUpload._removeOldListener("bulkUpload:filesChosen");

                // enable the next button if the files are chosen
                this.listenTo(app, "bulkUpload:filesChosen", function () {
                    // there is no next button for the flash view so we only need to care about the next button
                    // if we're using the HTML 5 view
                        if (self.activeChildView.getFileNames().length > 0) {
                            self.hasNext = true;
                            
                            self.uploadItemsWithAttachments();

                        } else { // there aren't any files to upload, so the user can't click the next button yet
                            self.hasNext = false;
                        }

                    // the acceptFileList div is the next button so we'll enable it if we've got more than one file
                    // otherwise, it's disabled
                    //second check to see if there are any upload size errors, if so then disable button
                    if (self.activeChildView.getFileNames().length > 0) {
                        if (uploadSizeErrorList.length === 0 && !hasTotalUploadSizeError) {
                            $('#acceptFileList').removeClass('disabled');
 							$('#propIndexButton').removeClass('disabled');
                        } else {
                            $('#acceptFileList').addClass('disabled');
                        	$('#propIndexButton').addClass('disabled');
                        }
                    } else {
                        $('#acceptFileList').addClass('disabled');
                        $('#propIndexButton').addClass('disabled');
                    }
                });


                //This is hacky and hopefully a temp fix.  This is in an effort to get rid of the duplication of attachments on emails.
                //Here we are "resetting" the event on app, since we aren't getting backbone to clear it properly
                BulkUpload._removeOldListener("bulkupload:processItemWithAttachments");

                // listen for when an email is done being parsed so we can process the results of parsing it
                this.listenTo(app, "bulkupload:processItemWithAttachments",  this.processZipOrEmail);

                // once the user clicks next, we're going to load our sequential properties view
                this.listenToOnce(app, "bulkupload:nextPressed", this.loadSequentialPropertiesView);

                BulkUpload._removeOldListener("bulkupload:lookUpValues");

                this.listenTo(app, "bulkupload:lookUpValues", function () {
                    if (this.sequentialProperties.options.activeChildView) {
                        this.sequentialProperties.lookUpValues();
                    } else {
                        this.sequentialProperties.lookUpValues(this.bulkPropertiesView.activeChildView.getValues(), this.bulkPropertiesView.bulkPropertiesObjectType);
                    }

                }, this);

                // they just clicked the "Look Up Values" button
                this.listenTo(app, "bulkupload:copyValuesToForm", function (rowOco) {
                    //for each field, grab the value off my oco

                    var formValues = {};
                    var controlsToLoop;
                    var currentType;
                    if (this.sequentialProperties.options.activeChildView) {
                        controlsToLoop = this.sequentialProperties.options.activeChildView.options.propertiesViewModel.controls();
                        currentType = this.sequentialProperties.options.activeChildView.options.propertiesViewModel.objectType();
                    } else {
                        controlsToLoop = this.bulkPropertiesView.activeChildView.options.propertiesViewModel.controls();
                        currentType = this.sequentialProperties.options.activeChildView.options.propertiesViewModel.objectType();
                    }
                    _.each(controlsToLoop, function (control) {
                        var lookupFields = [];
                        if (self.config.get("uploadLookupFields")) {
                            //we might have a config to not copy all values
                            lookupFields = _.pluck(self.config.get("uploadLookupFields")[currentType], 'ocName');
                        }
                        if (lookupFields.length === 0 || _.contains(lookupFields, control.id)) {
                            //lookup field has it so lets grab it
                            if (control.controlType === 'DateBox') {
                                formValues[control.id] = app.context.dateService.convertDateToIso(rowOco.get('properties')[control.id], false);
                            } else if (control.controlType === 'DatetimeBox') {
                                formValues[control.id] = app.context.dateService.convertDateToIso(rowOco.get('properties')[control.id], true);
                            } else {
                                formValues[control.id] = rowOco.get('properties')[control.id];
                            }
                        }

                    });

                    delete formValues.objectName;
                    this.sequentialProperties.options.activeChildView.options.propertiesViewModel.setValues(formValues);
                    app.popoverHandler.trigger('hide');

                }, this);

                // once the user clicks the file list button, we want to rebuild the upload view
                this.listenTo(app, "bulkupload:backPressed", function () {
                    this.rebuildUploadView();
                    // if we were using indexing mode, we want to remove the iFrame and disable indexing
                    if (this.hasIndexing) {
                        app.trigger("disableIndexingIframe");
                        app.trigger("disableIndexing");
                    }
                    if(this.printMode){
                        //show the print from repo table
                        this.printToRepo(true);
                    }
                }, this);

                // this is called from the Bulk Properties view once the object type has changed and we've created our collection
                // of OCOs from the files chosen to be uploaded
                this.listenTo(app, 'bulkupload:setupSequentialProperties', function (objectType, bulkProperties, collection) {
                    // set up the properties view and pass it the collection of objects
                    this.sequentialProperties = new BulkUpload.SequentialPropertyEditingView({
                        attributes: this.configurationAttributes,
                        objectType: objectType,
                        ocoCollection: collection,
                        contextlessActionOptions: this.contextlessActionOptions,
                        bulkProperties: bulkProperties,
                        fileNames: this.activeChildView.getDisplayFileNames(),
                        inheritFolderAttributes: this.options.inheritFolderAttributes,
                        getPropsToInherit: this.options.getPropsToInherit,
                        formName: this.options.form,
                        templateObjectType: self.templateObjectType,
                        existingContentObjectType: self.existingContentObjectType,
                        enableSetNewVersion: this.options.enableSetNewVersion,
                        indexingMode: this.hasIndexing,
                        oaviewerMode: this.options.oaviewerMode,
                        enablePathSecurityCheck: this.options.enablePathSecurityCheck,
                        customTypePaths: this.options.customTypePaths,
                        gmailFiles: this.gmailFiles,
                        lookUpSearchConfig: this.lookUpSearchConfig,
                        isHeaderMode: this.options.isHeaderMode,
                        handler: this.options.handler,
                        positionDataEnabled: this.config.get("positionDataEnabled")
                    });

                    // we don't want sequential properties to be listening for anything when we first initialize it
                    // if you want sequential properties to listen to something, use the startListening method
                    this.sequentialProperties.stopListening();
                }, this);

                // listen for scan done and remove the view and rerender - prevents a stack of scanning views
                this.listenTo(app, "doneScanPressed", function (scannedBlob) {

                    self.removeView("#scanner-bulk-upload-view");
                    self.scanning = false;
                    self.render();
                    self.activeChildView.docScanned(scannedBlob);
                    // only rebuild if drag and drop support is enabled, flash doesn't need this reconstructiopn
                    self.rebuildUploadView();
                }, this);

                BulkUpload._removeOldListener("bulkupload:doneUploading");


                this.listenTo(app, 'bulkupload:doneUploading', this._handleDoneUploading, this);

                BulkUpload._removeOldListener("bulkupload:goToBulkProperties");


                this.listenTo(app, 'bulkupload:goToBulkProperties', this._goToBulkProperties);

                BulkUpload._removeOldListener("bulkupload:initDisallowedDocumentsView");

                this.listenTo(app, 'bulkupload:initDisallowedDocumentsView', function (disallowedDocuments) {
                    var disallowedDocumentsView = new BulkUpload.DisallowedDocuments({
                        disallowedDocuments: disallowedDocuments
                    });
                    this.disallowedDocuments = disallowedDocuments;
                    this.setView("#bulk-upload-disallowed-documents", disallowedDocumentsView).render();
                });

                this.listenTo(app, "showDraggable", function () {
                    this.removeView("#scanner-bulk-upload-view");
                    self.scanning = false;
                    self.render();
                });

                //This is hacky and hopefully a temp fix.  This is in an effort to get rid of the duplication of attachments on emails.
                //Here we are "resetting" the event on app, since we aren't getting backbone to clear it properly
                BulkUpload._removeOldListener("bulkupload:onFinish");


                this.listenTo(app, 'bulkupload:onFinish', function (collection) {
                    this.bulkUploadStartTime = Date.now();
                    this.uploadControllerView.doUpload(collection);
                });

                this.listenTo(app, 'bulkupload:allOcosValid', function (deferred) {
                    if (self.sequentialProperties) {
                        deferred.resolve(self.sequentialProperties._allOcosValid());
                    }
                }, this);

                this.listenTo(app, 'bulkupload:doneUploading', function (successList) {
                    app.trigger('stage.container.childrenChanged');
                    if (successList.length > 0) {
                        app.trigger("stage.refresh.containerId", true);
                    }
                });

                this.listenTo(app, 'bulkupload:removedCoverPage', function () {
                    this.numCoverPages--;
                });

                if (this.options.gmailUploadEnabled) {
                    //need to grab auth token for upload if gmail is
                    //enabled
                    this.listenTo(app, "cloudservicesauthentication:google:authenticated", function (result) {
                        self.gmailAccessToken = result.access_token;
                        self.activeChildView.setGmailAuthToken(self.gmailAccessToken);
                    });
                }
            },
            _handleDoneUploading: function (successList, errorList) {
                var uploadResults = {
                    successList: successList,
                    errorList: errorList
                };

                // remove the properties section and file controls views since we're done uploading
                this.removeView("#properties-section");
                this.removeView("#uploadFileControls");

                this._updateStyleAfterUpload();

                // set our results view
                var resultsView = new BulkUpload.Results(uploadResults);
                this.setView("#bulk-upload-uploader-output", resultsView).render();

                this._refreshStageOnSuccess(uploadResults);

                this._updateAuditTrail(successList);

                this.trigger("action:success", uploadResults);

                this.logBUCompletion(successList);
            },
            logBUCompletion: function(successList) {
                var bulkUploadCompletionTime = Date.now();
                var successDocProps = [];

                //put the type-size of each successful document into an array to log as a comma-separated list in the events object
                _.each(successList, function(successDoc) {
                    successDocProps.push(successDoc.type + "-" + successDoc.size);
                });

                LogstashService.sendMetrics(
                    new LogstashService.PerformanceLog({
                        'eventTitle': HPIConstants.Logging.Events.BulkUpload,
                        'events': {
                            'eventDuration': bulkUploadCompletionTime - this.bulkUploadStartTime,
                            'uploadedDocs': successDocProps.join(",")
                        },
                        'docCount': successList.length
                    })
                );
            },
            _updateStyleAfterUpload: function() {
                if(this.myHandler === HPIConstants.Handlers.ModalActionHandler) {
                    // show the footer
                    $('#bulk-upload-footer').removeClass('hide');

                    // show our done button that can close the modal
                    $('#upload-dismiss-modal').removeClass('hidden');

                    // remove the float:left which was interfering with bootstrap modal styling
                    $('#oa-indexing-modal-body').css('float', 'none');
                } else if(this.myHandler === HPIConstants.Handlers.RightSideActionHandler) {
                    // hide our footer so there's no buttons for a user to interact with
                    $('#bulk-upload-footer').addClass('hide');
                }
            },
            _refreshStageOnSuccess: function (uploadResults) {
                var successList = uploadResults.successList;
                var errorList = uploadResults.errorList;

                // if we only uploaded one document, let's refresh the stage with that successfully uploaded document
                // when the user hides the bulk upload action
                if (successList.length === 1 && errorList.length === 0 && successList[0].objectId) {
                    this.listenToOnce(app[this.myHandler], "hide", function () {
                        app.trigger("stage.refresh.bothIds", true, successList[0].objectId);
                    });
                } else { // there was either an error or more than one document uploaded successfully
                    if (successList.length !== 0) {
                        this.listenToOnce(app[this.myHandler], "hide", function () {
                            app.trigger("stage.refresh.containerId", true);
                        });
                    }

                    // find each of the cover pages that uploaded successfully
                    var coverPages = _.filter(successList, function (file) {
                        return file.coverPage;
                    });

                    // open each cover page that uploaded successfully in a new window
                    _.each(coverPages, function (coverPage) {
                        window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(coverPage.fileName) + "?id=" + coverPage.objectId + "&overlay=true&contentType[]=" + ["pdf", "txt", ".*"], "_blank");
                    });
                }
            },
            _updateAuditTrail: function(successList) {
                // check if we uploaded at least one document successfully and the admin is configured to generate
                // an audit trail
                if (this.options.auditTrail === "true" && successList.length !== 0) {
                    // let's generate a date so that the objectName of the folder note we are creating can be unique
                    // we will append to the objectName in the properties map
                    var currentDate = DateFormat.format.date(new Date(), "E, d MMM yyyy hh-mm-ss a");

                    // the parent is going to be the current folder the user is in
                    var parentID = app.context.container.get("properties").objectId;

                    // build up the HTML for each note with a link they can click to navigate to the document
                    var noteContent = "<p>" + (window.localize("modules.actions.bulkUpload.theFollowingDocuments")) + "</p>";
                    var index = 0;
                    _.each(successList, function (successFile) {
                        var linkToUploadedDoc = "<a class='stageLink' documentId='" + successFile.objectId + "'>" + successFile.filename + "</a>";
                        if (index > 0) {
                            linkToUploadedDoc = ", " + linkToUploadedDoc;
                        }
                        index++;
                        noteContent += linkToUploadedDoc;
                    });
                    noteContent += "<p class='margin-top'>" + window.localize("modules.actions.bulkUpload.toViewA") + "</p>";


                    FolderNotes.Service.execute({
                        parameters: {
                            parentID: parentID,
                            note_content: noteContent,
                            note_rel_type: this.options.auditTrailRelationship,
                            note_object_type: this.options.auditTrailObjectType,
                            property_map: {
                                note_type: this.options.auditTrailNoteType,
                                objectName: 'Document Import - ' + currentDate
                            }
                        },
                        errorFunction: function () {
                            $("#bulk-upload-uploader-output").append("<div class='alert alert-error'><ul><li>Audit trail not created.</li></ul></div>");
                        }
                    });
                }
            },
            _disableOAIframeView: function(){
                this.indexingIframe = false;
                this.bulkuploadIFrameView = false;
                this.removeView("#bulk-upload-oa-iframe");
                this.render();
            },

            _addOrRemoveOAIframeView: function(docIndex){
                //pull the name of the document based on the currentDocId
                //then split off the extension after the "."
                //if that matches anything in the extension whitelist
                //show the indexing iFrame, if not, don't
				
				// Fetch the original filenames so the bhudi can be triggered
				// even if extensions are stripped off
                var docName = this.activeChildView.getFileNames()[docIndex];
                var docExten = docName.split(".").pop().toLowerCase();
                this.indexingIframe = true;
                if(_.contains(this.options.extenWhiteList, docExten)){
                    var options = {
                        "docIndex": docIndex,
                        "docName": docName,
                        "docId": this.indexerFileDocIds[docIndex],
                        "config": this.config
                    };
                    this.indexingIframe = true;
                    //this will open up the oportunity to create error messages 
                    //or other custom iFrame enhancements based off of the avail white list
                    this.bulkuploadIFrameView = new BulkUpload.OAIframeView(options);
                    this.setView("#bulk-upload-oa-iframe", this.bulkuploadIFrameView);
                    this.bulkuploadIFrameView.render();
                }else{
                    this.indexingIframe = false;
                    this.removeView('#bulk-upload-oa-iframe');
                    this.render();
                }
            },

            // this fixes issues with swapping scanner and bulk upload views by copying and rebuilding each subview
            rebuildUploadView: function () {
                var self = this;

                // copy over any selected files into the new view
                var prevSelectedFiles = self.uploadControllerView.getDocs();

                //if we are in add from existing doc mode we want to remove all existing docs
                if (prevSelectedFiles.length > 0 && prevSelectedFiles[0].isAddingFromExistingContent) {
                    prevSelectedFiles = [];
                    this.uploadControls.disableAddFromExisting = false;
                } else if (prevSelectedFiles.length > 0) {
                    this.uploadControls.disableAddFromExisting = true;
                } else {
                    this.uploadControls.disableAddFromExisting = false;
                }

                if (prevSelectedFiles.length > 0) {
                    this.uploadControls.hasFiles = true;
                } else {
                    this.uploadControls.hasFiles = false;
                }

                // copy over any checked MSG/Zip files into the new view
                var previouslyCheckedFiles = self.uploadControllerView.getCheckedFileNames();
                self.uploadControllerView =  new BulkUpload.HTML5UploadControllerView({
                    options: self.options,
                    fileNames: self.fileNames
                });
                this.sequentialProperties = undefined;
                this.uploadControllerView.addDocs(prevSelectedFiles);

                // once we've recreated our upload controller, we want to repopulate the array of MSG files we've already
                // checked so they're not parsed again if the user drags in the MSG file again
                _.each(previouslyCheckedFiles, function (checkedFile) {
                    self.uploadControllerView.addCheckedFileName(checkedFile);
                });
                this.filesAccepted = false;
                this.uploadControllerView.filesAccepted(self.filesAccepted);
                this.activeChildView = this.uploadControllerView;
                this.setView("#bulk-upload-uploader-output", this.activeChildView).render();

                this.setView("#uploadFileControls", this.uploadControls).render();

                this.$('#acceptFileList').removeClass('disabled');
                // hide properties controls
                this.removeView('#properties-section');
                this.removeView('#bulkUpload-properties-controls');
                this.removeView('#bulk-upload-templating-output');
                this.removeView('#bulk-upload-existing-content-output');

                // show the normal bulk upload uploader if it was hidden
                $("#bulk-upload-uploader-output").show();
                $(".addDocButton").show();
                $("#acceptFileList").show();
                this.activeChildView.keepWellhidden = false;
                $(".createDocFromExistingContentButton").show();
                $("#propIndexButton").show();
                $("#bulk-upload-disallowed-documents").show();

                // we're already listening to the nextPressed button click (when we initalized this view) and if we don't stop listening
                // before we listen to the event, we'll end up listening to the event twice which will cause bad behavior (cause form support
                // to be generated twice - trust me, you don't want that to happen)
                this.stopListening(app, "bulkupload:nextPressed").listenToOnce(app, "bulkupload:nextPressed", this.loadSequentialPropertiesView);
            },

            // after choosing files for upload, the user clicks the "Next" button and we're taken here
            acceptFileList: function () {
                // if they're clicking the disabled button, we're not ready to proceed yet
                // (most likely because they haven't chosen any files for upload yet)
                if ($('#acceptFileList').hasClass('disabled')) {
                    return;
                }
                //jquery and blue imp dont play nice together - im clearing the jquery internal drop target cache here
                $.event.special.drop.targets = [];
                // hide the "Next" button
                $('#acceptFileList').hide();
                $("#bulk-upload-disallowed-documents").hide();

                this.buildPaginationControls();

                // files are valid (there are more than 0 files chosen for upload)
                this.filesAccepted = true;

                // tell widget view that files have been accepted
                this.uploadControllerView.filesAccepted(this.filesAccepted);

                // get the list of file names of the files the user is uploading
                this.fileNames = this.activeChildView.getDisplayFileNames();

                // if we are adding from existing content we will need the ocos
                this.ocos = this.activeChildView.getOcos();

                if(this.printMode){
                    this.printToRepo(false);
                }

                // if there are more than 1 file chosen for upload, we want to show the bulk properties view
                if (this.fileNames.length > 1) {
                    this.loadBulkPropertiesView();

                } else {
                    // there was one file chosen for upload so we're "pressing" the "Next" button for the user
                    // to load the sequential properties view instead
                    app.trigger('bulkupload:nextPressed');
                }
            },
            cloudStorageIntegration: function () {
                // we have set up box integration for now. In the future, we can handle oter types based on their cloudSelectType
                BoxStorageIntegrationService.setup(this.options);

                BoxStorageIntegrationService.fileSelect();
            },
            propertyIndexing: function () {
                // turn indexing mode on
                this.hasIndexing = true;
                // if they're clicking the disabled button, we're not ready to proceed yet
                // (most likely because they haven't chosen any files for upload yet)
                if ($('#propIndexButton').hasClass('disabled')) {
                    return;
                }

                // hide the "Next" button
                $('#acceptFileList').hide();
                $('#propIndexButton').hide();
                // hide the disallowed documents list
                $('#bulk-upload-disallowed-documents').hide();

                this.buildPaginationControls();

                // files are valid (there are more than 0 files chosen for upload)
                this.filesAccepted = true;

                // tell widget view that files have been accepted
                this.uploadControllerView.filesAccepted(this.filesAccepted);

                // get the list of file names of the files the user is uploading
                this.fileNames = this.activeChildView.getDisplayFileNames();

                // if we are adding from existing content we will need the ocos
                this.ocos = this.activeChildView.getOcos();

                // hide print mode table if pressed
                if(this.printMode){
                    this.printToRepo(false);
                }

                // if there are more than 1 file chosen for upload, we want to show the bulk properties view
                if (this.fileNames.length > 1) {
                    this.loadBulkPropertiesView();
                    // registers that the indexing button was pressed. this initiates the initial file upload for indexing mode
                    app.trigger('bulkupload:indexButtonPressed');
                } else {
                    // there was one file chosen for upload so we're "pressing" the "Next" button for the user
                    // to load the sequential properties view instead
                    app.trigger('bulkupload:nextPressed');
                    // registers that the indexing button was pressed. this initiates the initial file upload for indexing mode
                    app.trigger('bulkupload:indexButtonPressed');
                    app.trigger('addIndexingIframe', this.currentDocIndex);
                }
            },

            loadBulkPropertiesView: function () {
                // load our bulk properties view for more than one document upload
                // Note: bulk properties handles any inheiritence
                var self = this;
                // If the object type is configured to have a separate form for the bulk edit properties page then we will provide that value
                // If not, then we will fall back on the form that has been configured for the individual document properties.
                var formName = this.options.form;
                if(this.isCustomBulkPropertiesFormConfigured) {
                    formName = this.options.bulkPropertiesForm;
                }

                this.bulkPropertiesView = new BulkUpload.BulkPropertiesView({
                    fileNames: self.fileNames,
                    ocos: this.ocos,
                    contextlessActionOptions: this.contextlessActionOptions,
                    // whether or not to inherit folder attributes
                    inheritFolderAttributes: this.options.inheritFolderAttributes,
                    // the method to use to inherit folder attributes (overridable)
                    getPropsToInherit: this.options.getPropsToInherit,
                    formName: formName,
                    customTypePaths: this.options.customTypePaths,
                    enablePathSecurityCheck: this.options.enablePathSecurityCheck
                });

                // set our properties section outlet to this bulk properties view
                this.setView('#properties-section', this.bulkPropertiesView);

                // now that we've created our object type picker view and have attached our listener, we can go ahead and resolve
                // the object type, which will trigger our generateFormSupoort event once the object type has been resolved
                this.bulkPropertiesView.objectTypePicker.resolveObjectType().done(function () {
                    // once the object type picker has resolved, we can go ahead and render since we'll have our list of object types
                    // to pick from
                    self.bulkPropertiesView.render();
                });
            },

            buildPaginationControls: function () {
                // now we're going to build the controls that sit along the bottom of the view allowing the user
                // to navigate through the action
                var controls = new BulkUpload.PaginationControls({
                    showIndex: false,
                    showRequired: false,
                    hasNext: false,
                    hasPrevious: false,
                    allowFinish: false,
                    enableLookUp: this.options.enableLookUp === 'true' ? true : false,
                    lookUpSearchConfig: this.lookUpSearchConfig,
                    isHeaderMode: this.options.isHeaderMode,
                    myHandler: this.myHandler,
                    fileNamesUniqueCheckRequired: this.options.fileNamesUniqueCheckRequired === 'true'
                });
                this.setView("#uploadFileControls", controls).render();
            },

            // get the information from the selected input box and send a message to OA that we are going to use property indexing
            initiateIndexerAnnotation: function (event) {

                //Only trigger OA call if not currently called, allowed to call, OA exists, and we are in a page with a single document view (not the bulk properties view)
                if (!this.hasBoxSelected && this.hasIndexing && app.openAnnotate && this.sequentialProperties.options.activeChildView) {
                    var propertiesViewModel = this.sequentialProperties.options.activeChildView.options.propertiesViewModel;
                    var oco = this.sequentialProperties.ocoCollection.at(this.sequentialProperties.options.currentIndex);
                    ExternalEventsModule.initiateIndexerAnnotation.call(this, event,propertiesViewModel, oco);
                }
            },

            // if we click of off an input box, we want to remove the information that we stored about it
            //and stop our "finishIndexing" listener so it doesn't accidentally update the property
            inputBoxDeselected: function () {
                app.trigger("blurInputBox");
            },

            scanDoc: function () {
                this.setView("#scanner-bulk-upload-view", new Scanner.View({
                    license: this.options.scannerLicense
                }));
                this.scanning = true;
                this.render();
            },

            templateDoc: function () {
                var self = this;
                if (!this.getView("#bulk-upload-templating-output")) {
                    this.listenTo(app, "addDocTemplate:setObjectType", function (type) {
                        self.templateObjectType = type;
                    });

                    this.setView("#bulk-upload-templating-output", new AddDocTemplate.View()).render();
                    this.templating = true;
                    $("#templateDocBtnLabel").text(" Upload Documents");
                    $("#templateDocBtnIcon").removeClass("glyphicon-list-alt");
                    $("#templateDocBtnIcon").addClass("glyphicon-folder-open");

                    this.listenTo(app, "addDocTemplate:removeView", function () {
                        if (self.getView("#bulk-upload-templating-output")) {
                            self.removeView('#bulk-upload-templating-output');
                        }
                    });
                } else {
                    this.removeView('#bulk-upload-templating-output');
                    $("#templateDocBtnLabel").text(" Create Document from Template");
                    $("#templateDocBtnIcon").addClass("glyphicon-list-alt");
                    $("#templateDocBtnIcon").removeClass("glyphicon-folder-open");
                    $(".dropZone").show();
                    $(".addDocButton").show();
                }
            },

            printToRepo: function(show) {
                if (show) {
                    //pass in selected documents to view and render
                    //spy on view, expect selected files
                    var printToRepoView = new printToRepo.View({
                        'selectedFiles': this.uploadControllerView.getDocs(),
                    });
                    this.setView("#bulk-upload-printToRepo-output", printToRepoView).render();
                } else {
                    this.removeView('#bulk-upload-printToRepo-output');
                }
            },

            createDocFromExistingContent: function () {
                var self = this;

                $(".createDocFromExistingContentButton").trigger("blur");
                this.listenTo(app, "addFromExistingContent:setObjectType", function (type) {
                    self.existingContentObjectType = type;
                });

                this.setView("#bulk-upload-existing-content-output", new AddFromExistingContent.SearchView()).render();
                this.addFromExisting = true;

                $(".createDocFromExistingContentButton").hide();

                // this trigger works for both templates and create from existing doc
                this.listenTo(app, "addDocTemplate:removeView", function () {
                    if (self.getView("#bulk-upload-existing-content-output")) {
                        self.removeView('#bulk-upload-existing-content-output');
                    }
                });
            },

            gmailUpload: function () {
                var self = this;
                //listen for when gmail emails are selected
                this.listenToOnce(app, "gmailUpload:emailsSelected", function (files) {
                    self.processGmailEmails(files);
                }, this);

                self.gmailView = new GmailUpload.View({
                    client_id: this.options.gmailUploadClientId,
                    scope: "https://www.googleapis.com/auth/gmail.readonly",
                    immediate: false,
                    fileNames: self.fileNames,
                    sterilizeAttributes: self.options.sterilizeAttributes
                });

                // trigger a custom event to kick off our gmail upload view
                app.trigger('alert:custom', {
                    view: self.gmailView,
                    width: '680px'
                });
            },

            // called when a user clicks the "Generate Cover Page" button
            dropOffScan: function () {
                // create our "files" that should be added to the list to be uploaded
                // in our case, we're making a placeholder file with the name "Cover Page {number}" and indicating
                // it's a cover page so we can run some custom logic when the user clicks the "Finish and Upload" button
                var files = [{
                    name: "Cover Page " + (++this.numCoverPages),
                    coverPage: true
                }];

                // trigger the event that the "Generate Cover Page" button was pressed
                // this will cause our cover page to actually get added to the list of files to be uploaded
                app.trigger('bulkupload:dropOffScanPressed', files);
            },

            /**
             * Makes a request to parse our MSG file for attachments. If we're using the "Add Emails" action, this
             * simply returns the deferred that indicates if we've parsed the MSG file yet, since the request to
             * parse the MSG file in that case is triggered right when the file is selected.
             * @param {String} filename - The file name of the MSG file we're parsing so we can modify it in our
             * files array.
             * @returns {Object} - A deferred to indicate when we've finished parsing the MSG file.
             */
            uploadMSGFileForParsing: function (filename) {
                // find the email file
                var email = _.findWhere(this.activeChildView.files, {
                    name: filename
                });

                // give the email the next available ID
                email.emailId = this.emailId++;

                // indicate that this file is an email
                email.email = true;

                // if we're not using the "Add Emails" action, let's kick off our request to parse this email
                if (!this.options.addEmail) {
                    var fd = new FormData();

                    // append this email to our form data object to send to OC to parse
                    fd.append("file", email, filename);

                    // make our ajax request to parse the email and get a list of the attachment file names
                    var urlExtension = app.serviceUrlRoot + "/email/parseEmail?parseAttachments=true&parseForLinks=" + this.options.parseForLinks;
                    if(this.options.indexingMode === "true"){
                        urlExtension = urlExtension + "&parentFolderPath="+this.options.indexingFileDumpFolder;
                    }
                    return $.ajax({
                            url: urlExtension,
                            data: fd,
                            cache: false,
                            contentType: false,
                            processData: false,
                            type: "POST",
                            success: function(results) {
                                // we're done parsing the email so let's trigger an event to process the results
                                app.trigger("bulkupload:processItemWithAttachments",email.emailId, results, BulkUpload.CONSTANTS.EMAIL);
                            }
                        });
                    
                } else { // we're using the "Add Emails" action
                    // just return the deferred that indicates if we've finished parsing the MSG file for
                    // attachments yet since the request to actually parse the MSG file is triggered right
                    // when the MSG file is selected
                    return this.uploadControls.processingEmailDeferred.promise();
                }
            },
            /**
             * This file is finding the specified zip file and extracting the attachments from it
             * @param {String} filename - The string filename to compare which zip file we're looking for
             */
            uploadZipFileForParsing: function(filename) {
                // find the zip file
                var zip = _.findWhere(this.activeChildView.files, {
                    name: filename
                });

                // give the zip the next available ID
                zip.zipId = this.zipId++;

                // indicate that this file is a zip
                zip.zip = true;
                var fd = new FormData();

                // append this zip to our form data object to send to OC to parse
                fd.append("file", zip, filename);

                var urlExtension = app.serviceUrlRoot + "/zip/parseZipAttachments";
                //if indexerMode is on, we want to assign a folderpath for the files to go
                if(this.options.indexingMode === "true") {
                    urlExtension = urlExtension + "?parentFolderPath="+this.options.indexingFileDumpFolder;
                }

                // make our ajax request to parse the zip and get a list of the attachment file names
                return $.ajax({
                    url: urlExtension,
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    type: "POST",
                    success: function(results) {
                        // we're done parsing the zip so let's trigger an event to process the results
                        app.trigger("bulkupload:processItemWithAttachments",zip.zipId, results, BulkUpload.CONSTANTS.ZIP);
                    }
                });
            },
            
            /**
             * Processes the emails selected by the user through the gmail inbox module. Adds any
             * attachments to the list of files to create when the user chooses to upload the files. Stores
             * the gmail email id of the email that the attachment came from.
             */
            processGmailEmails: function (emails) {
                var emailsAndAttachments = [];
                var self = this;
                _.each(emails, function (email) {
                    //add our email
                    email.emailId = self.emailId++;
                    email.email = true;
                    emailsAndAttachments.push(email);
                    if (email.attachments) {
                        _.each(email.attachments, function (attachment) {
                            // We need to apply the gmailId, emailAttachment flag, and the emailId
                            // to the blob representing the attachment before proceeding.
                            attachment.attachmentId = attachment.id;
                            attachment.gmailId = email.id;
                            attachment.emailAttachment = true;
                            attachment.emailId = email.emailId;
                            emailsAndAttachments.push(attachment);
                        });
                    }
                });

                this.gmailFiles = emailsAndAttachments;
                app.trigger("bulkupload:filesUploaded", emailsAndAttachments);
            },

            setTempObjectId: function (objectId, itemId, results) {
                var file = _.findWhere(this.activeChildView.files, function(file){
                    file[objectId] = itemId;
                });
                if (objectId == 'emailId') {
                    file.tempEmailObjectId = results.tempEmailObjectId;
                } else if (objectId == 'zipId') {
                    file.tempZipObjectId = results.tempZipObjectId;
                }
                return file;
            },
            /**
             * Processes the results of parsing an MSG/ZIP file for attachments. This adds any attachments to our
             * list of files to create when the user chooses to finally upload the files. It also stores the
             * temporary objectId of a temporary email if we're using the "Add Emails" action (since we can
             * no longer upload the content of the MSG file after parsing it unless we want to ask the user
             * to choose the file again - this is on IE9).
             * @param {number} itemId - The ID of the email we just finished parsing.
             * @param {Object} results - An object containing a list of attachment names that represent
             * attachments on the email and a temporary email objectId field if we are using the "Add Emails"
             * action and created a temporary email object in the repository.
             * @param {String} zipOrEmail - Either "zip" or "email", this variable indicates what type of file is being processesd
             * 
             */
            processZipOrEmail: function (itemId, results, zipOrEmail) {
                // if we created a temporary objectId for our MSG file, then let's put that on our internal
                // representation of the MSG file so we can send this temporary objectId over when the user
                // chooses to finally upload the documents
                this.listenTo(app, "cleanUpIndexingDocs", function() {
                    // send our request, no need to listen for any response
                    _.each(this.indexerFileDocIds, function(id) {
                        $.ajax({
                            url: app.serviceUrlRoot + "/content/enhancedDeleteObject",
                            method: "POST",
                            global: false,
                            data: {
                                id: id,
                                allVersions: true
                            }
                        });
                    });
                });
                
                if (results.tempEmailObjectId) {
                   this.setTempObjectId('emailId', itemId, results);
                }
                if (results.tempZipObjectId) {
                    this.setTempObjectId('zipId', itemId, results);
                }

                // build up a list of attachment files to display as available files to upload to the user
                var attachmentFiles = [];

                // the "attachments" object that come back is a map with filenames to objectIds - since we're only
                // parsing the email and not creating the attachments, we'll ignore the objectId field in the
                // attachments map

                for (var i = 0; i < _.keys(results.attachments).length; i++) {
                    var fileName = _.keys(results.attachments)[i];
                    var objectId = _.values(results.attachments)[i];
                    // if the attachment is an MSG, let's add it to the list of checked file names
                    // so we don't try to parse it again (we already parse nested MSG files in OC)
                    if (this.activeChildView.isMSGFile(fileName) || this.activeChildView.isZIPFile(fileName)) {
                        this.activeChildView.addCheckedFileName(fileName);
                    }

                    var file = this.createEmailAttachmentFile(results, fileName);
                    // we want to associate this attachment with the email it came from
                    if (zipOrEmail === BulkUpload.CONSTANTS.EMAIL) {
                        file.emailId = itemId;
                        file.emailAttachment = true;
                    } else if (zipOrEmail === BulkUpload.CONSTANTS.ZIP) {
                        file.zipId = itemId;
                        file.zipAttachment = true;
                    }
                    file.objectId=objectId;
                    attachmentFiles.push(file);
                }

                // if we found supported or unsupported cloud links, we want to trigger the authentication route
                if (results.supportedCloudLinks || results.unsupportedCloudLinks) {
                    // create new cloud authentication view with supported and unsupported links
                    var cloudLinkAuthenticationView = new CloudLinkAuthenticaion.View({
                        "cloudResults": results,
                        "googleClientId": this.options.googleClientId,
                        "microsoftClientId": this.options.microsoftClientId,
                        "dropBoxClientKey": this.options.dropboxClientKey,
                        "dropboxClientSecret": this.options.dropboxClientSecret
                    });

                    // trigger a custom event to kick off our cloud service authentication
                    app.trigger('alert:custom', {
                        view: cloudLinkAuthenticationView,
                        width: '680px'
                    });
                }

                // trigger files uploaded to display the list of attachment files to the user
                app.trigger('bulkupload:filesUploaded', attachmentFiles);
            },
            createEmailAttachmentFile: function (results, fileName) {

                var blobToFile = function (theBlob, fileName) {
                    //A Blob() is almost a File() - it's just missing the two properties below which we will add
                    theBlob.lastModifiedDate = new Date();
                    theBlob.name = fileName;
                    return theBlob;
                };

                var blob = new Blob([], {
                    type: "application/octet-stream"
                });

                var file = blobToFile(blob, fileName);
                file.type = blob.type;

                return file;
            },

            /**
             * Builds the sequential properties view. Called when the user clicks "Next" from the Bulk Properties page,
             * or if we have a single document to upload, the app triggers this event itself in accept file list.
             */
            loadSequentialPropertiesView: function () {
                var self = this;

                var bulkPropertiesObjectType = '';
                var bulkProperties = {};

                // if we have more than one file, then we've built a bulk properties view and have possibly gotten
                // starting properties from inheritance and user entry into the bulk properties form
                if (this.fileNames && this.fileNames.length > 1) {
                    // let's grab our starting properties from bulk properties
                    bulkProperties = this.bulkPropertiesView.getBulkProperties();
                    // let's get our selected object type the user chose for all the documents to be uploaded
                    bulkPropertiesObjectType = this.bulkPropertiesView.getBulkPropertiesObjectType();
                }

                // this will happen if the app triggered this method itself (there is only one document to upload)
                if (!this.sequentialProperties) {
                    // let's create a collection
                    var collection = new OC.OpenContentObjectCollection();

                    // normal bulk upload
                    if (this.fileNames && this.fileNames.length > 0 && !this.ocos) {
                        // let's push on our file names, creating an OCO for each one
                        _.each(this.fileNames, function () {
                            var oco = new OC.OpenContentObject({
                                objectType: bulkPropertiesObjectType,
                                properties: {}
                            });

                            // add our new OCO to our collection
                            collection.add(oco);
                        }, this);
                    }
                    // create from existing object upload
                    else {
                        _.each(this.ocos, function (oco) {
                            collection.add(oco);
                        }, this);
                    }

                    // set up the sequential properties view and pass it the collection of objects
                    // we don't have an object type to pass in here
                    this.sequentialProperties = new BulkUpload.SequentialPropertyEditingView({
                        attributes: this.configurationAttributes,
                        ocoCollection: collection,
                        bulkProperties: bulkProperties,
                        contextlessActionOptions: this.contextlessActionOptions,
                        fileNames: this.activeChildView.getDisplayFileNames(),
                        inheritFolderAttributes: this.options.inheritFolderAttributes,
                        getPropsToInherit: this.options.getPropsToInherit,
                        formName: this.options.form,
                        templateObjectType: this.templateObjectType,
                        existingContentObjectType: this.existingContentObjectType,
                        enableSetNewVersion: this.options.enableSetNewVersion,
                        indexingMode: this.hasIndexing,
                        oaviewerMode: this.options.oaviewerMode,
                        enablePathSecurityCheck: this.options.enablePathSecurityCheck,
                        customTypePaths: this.options.customTypePaths,
                        gmailFiles: this.gmailFiles,
                        lookUpSearchConfig: this.lookUpSearchConfig,
                        isHeaderMode: this.options.isHeaderMode,
                        handler: this.options.handler,
                        AWSTextractEnabled:this.options.AWSTextractEnabled,
                        AWSTextractLowerBound:this.options.AWSTextractLowerBound,
                        AWSTextractUpperBound:this.options.AWSTextractUpperBound,
                        positionDataEnabled: this.config.get("positionDataEnabled")
                    });
                    this.sequentialProperties.stopListening();
                }

                $.when(this.sequentialProperties.setAndPropagateBulkProperties(bulkProperties)).done(function () {
                    app.trigger('bulkupload:controls:update', {
                        // we're going to start at the first document to upload
                        currentIndex: 1,
                        // we pass this in so we can get the number of total docs we're trying to upload (for "1 of 3")
                        numDocsToUpload: self.fileNames ? self.fileNames.length : self.activeChildView.getDisplayFileNames(),
                        // i.e. show "1 of 3"
                        showIndex: true
                    });

                    // now we want our sequential properties to start listening for events
                    self.sequentialProperties.startListening();

                    // Leaving Bulk Properties page, need to trigger index if we are in indexing mode.
                    if (self.hasIndexing) {
                        app.trigger("changeCurrentDocId", 1);
                        app.trigger("addIndexingIframe", 0);
                    }

                    // set our properties-section outlet with our sequential properties view - this will replace the bulk properties
                    // view that was there if there was more than one document to upload
                    self.setView('#properties-section', self.sequentialProperties).render();
                });

            },

            beforeRender: function () {
                if (!this.filesAccepted) {
                    this.setView("#uploadFileControls", this.uploadControls);
                }
                // before we render, always redo the dropzone/file loader
                this.setView("#bulk-upload-uploader-output", this.activeChildView);
            },
            serialize: function () {
                return {
                    dragSupport: true,
                    filesAccepted: this.filesAccepted,
                    scanning: this.scanning,
                    templating: this.templating,
                    hasNext: this.hasNext,
                    modal: this.myHandler === "modalActionHandler",
                    printMode : this.printMode,
                    hasIndexing: this.hasIndexing,
                    indexingIframe: this.indexingIframe
                };
            }
        });

        BulkUpload.OAIframeView = Backbone.Layout.extend({

            template: "actions/bulkupload/bulkupload-oa-iframe",

            initialize: function(options){
                this.config = options.config;
                this.currentDocId = options.docId;
                this.currentDocIndex = options.docIndex;
                this._startListening();
            },

            _startListening: function(){
                
                this.listenTo(app, "deleteIframeSpinner", this._deleteIframeSpinner);
            },

            _deleteIframeSpinner: function (uploadedIndexes) {
                var matchingdocindex = _.indexOf(uploadedIndexes, this.currentDocIndex);
                // IndexOf will return -1 when the contents of the array do not have the currentDocIndex.
                // If the currentDocIndex isn't inside of the array the doc hasn't been loaded, and do not
                // destroy the spinner.
                if(matchingdocindex !== -1 ){
                    HPISpinner.destroySpinner(this.spinner);
                    this.spinner = undefined;
                    app.trigger("addIndexingIframe", this.docIndex); //<- trigger this to create a new iframe
                }
            },
       
            serialize: function(){
                this.fullSourcePath = app.openAnnotateURL + "/login/external.htm?docId=" + this.currentDocId + "&username=" + app.user.get("loginName") + "&mode=" + (this.config.get("oaviewerMode") || "indexer");
                return {
                    hasDocId: this.currentDocId,
                    src: this.fullSourcePath
                };
            },

            afterRender: function(){
                if(!this.currentDocId){
                    var spinElem = $(".indexingIframeWaitingSpinner")[0];
                    spinElem.spinner = HPISpinner.createSpinner({
                        color: '#b6b6b6',
                        length: 32, 
                        width: 8, 
                        radius: 30,
                    }, spinElem);
                }
            }

        });

        // a pagable (not backbone.pagable) list of UploadItemView
        BulkUpload.SequentialPropertyEditingView = Backbone.Layout.extend({
            template: "actions/bulkupload/sequentialpropertyeditingview",
            events: {
                "click #suggestButton" : "queryTextract"
            }, 
            initialize: function () {
                var defaults = {
                    ocoCollection: new OC.OpenContentObjectCollection(),
                    fileNames: []
                };

                this.options = _.extend(defaults, this.options);

                this.options.currentIndex = 0;

                // the bulk properties object type for these sequential upload item views - will be undefined if they're
                // only uploading one document
                this.bulkPropertiesObjectType = this.options.objectType;

                // the object type of the current upload item view being looked at
                this.currentObjectType = this.options.objectType;

                this.lookupSearchConfig = this.options.lookupSearchConfig;

                //create and show typeahead only if configured
                if (this.options.enableSetNewVersion === 'true') {
                    this.selectDocumentView = new BulkUpload.SetNewVersionDocSelector();
                    this.selectDocumentView.setupTypeahead();
                    this.setView("#setNewVersionDiv", this.selectDocumentView);
                }

                //Positional Data Objects
                this.positionalAttr = module.config().positionalAttribute || HPIConstants.hpiMetadataPositions;
            },
            beforeRender: function () {
                // do this here makes unit testing alot easier..
                this._goto();
            },
            afterRender: function () {
                var self = this;
                // once this view is done rendering we want to resolve our object type, render the object type picker
                // and set the type so the generation of form support is initiated with the correct object type
                $.when(this.activeObjectTypePicklist.resolveObjectType()).done(function () {
                    self.activeObjectTypePicklist.render().promise().done(function () {
                        // if they're limiting the available object types to choose from to a single type, then
                        // we always want to set the type to be that object type
                        if (self.activeObjectTypePicklist.singleType) {
                            // we don't need to pass in an objectType to set in this case because the ObjectTypePicklist view
                            // handles the case where there's only one type by itself
                            self.activeObjectTypePicklist.setType();
                        } else { // they're not limiting the object types or they're limiting the types to more than one
                            // it's possible neither the currentObjectType nor the bulkPropertiesObjectType are defined at this point
                            // if we're uploading one document and are not limiting the object types - if we don't have a defined
                            // objectType to set, let's not set it and instead let the user change it
                            if (self.currentObjectType || self.bulkPropertiesObjectType) {
                                // set the type of the object type picker to be the current object type of the document being viewed,
                                // defaulting back to the starting object type
                                self.activeObjectTypePicklist.setType(self.currentObjectType || self.bulkPropertiesObjectType);
                            } else if (self.templateObjectType) {
                                // if we are in templating mode and there is only one document we want to set the correct objectType
                                self.activeObjectTypePicklist.setType(self.templateObjectType);
                            } else if (self.existingContentObjectType) {
                                // if we are in add from existing content mode and there is only one document we want to set the correct objectType
                                self.activeObjectTypePicklist.setType(self.existingContentObjectType);
                            } else if(self.options.contextlessActionOptions && self.options.contextlessActionOptions.objectType){
                                self.activeObjectTypePicklist.setType();
                            }
                        }
                    });
                });

                //Textract

                if(self.options.AWSTextractEnabled === 'true') { 
                    $('#active-suggestButton').removeClass("hidden");
                }
            },

            displayResults: function (valuesFilled, totalValues) {
                $('#suggestButton').replaceWith("<div id='textractResult' class='alert alert-success'>" + valuesFilled + " of " + totalValues + " values suggested.</div>"); //jshint ignore:line
            },
            //calculate levenshtein distanceb
            editDistance: function(s1, s2) {
                s1 = s1.toLowerCase();
                s2 = s2.toLowerCase();

                var costs = [];
                for (var i = 0; i <= s1.length; i++) {
                    var lastValue = i;
                    for (var j = 0; j <= s2.length; j++) {
                        if (i == 0)
                            costs[j] = j;
                        else {
                            if (j > 0) {
                                var newValue = costs[j - 1];

                                if (s1.charAt(i - 1) != s2.charAt(j - 1)) {
                                    newValue = Math.min(Math.min(newValue, lastValue),costs[j]) + 1;
                                }

                                costs[j - 1] = lastValue;
                                lastValue = newValue;
                                
                            }
                        }
                    }

                    if (i > 0) {
                        costs[s2.length] = lastValue;
                    }
                }

                return costs[s2.length];
            },

            //use the levenshtein distance to get the accuracy
            similarity: function (s1, s2) {
                var longer = s1;
                var shorter = s2;

                if (s1.length < s2.length) {
                    longer = s2;
                    shorter = s1;
                }

                var longerLength = longer.length;
                if (longerLength == 0) {
                    return 1.0;
                }

                return (longerLength -this.editDistance(longer, shorter)) / parseFloat(longerLength);
            },


            //compare the values in keyarray and labelarray and see if their closest Edit Distance exceeds our threshold
            //The threshold is set in OCMS configs, it should never be lower than .5
            compareValues:function (keyArray,labelArray,threshold) {
                var bestFits = {};
                //keys for the response
                var labels = [];
                //values for the response
                var myVals = [];
                var bestIndex = 0;
                var bestAccuracy = 0;

                //for each element in keyArray, find it's closest partner inlabelArray2.  This will be used for populating the response object and comparing to existing values
                for (var i = 0 ; i < keyArray.length; i++) { 
                    bestIndex=0;
                    bestAccuracy = 0;
                    for (var j = 0; j < labelArray.length; j++) {
                        if (this.similarity(keyArray[i],labelArray[j]) > bestAccuracy) {
                            bestAccuracy = this.similarity(keyArray[i],labelArray[j]);
                            bestIndex = j;
                        }
                    }     
                    //if the best deistance is less than the threshold, we do nothing
                    if (bestAccuracy <= threshold) {
                        continue;
                    }
                    //if the label isnt in the list and has a bestDistance better than the threshold 
                    if (!labels.includes(keyArray[i])) {

                        //check to make sure the label hasnt already been matched, if it hasnt, wejust add it
                        if (!myVals.includes[bestIndex]) {
                            bestFits[keyArray[i]] = bestIndex;
                            labels.push([keyArray[i]]);
                            myVals.push(bestIndex);
                            continue;
                        }
                        //if the value has already been matched, if we have a better value, we need to rematch it
                        //and then remove the previous instance of it
                        else if (bestAccuracy > this.similarity(keyArray[i],labels[myVals.indexOf(bestIndex)])) {
                            delete bestFits.labels[myVals.indexOf(bestIndex)];
                            bestFits[keyArray[i]] = bestIndex;
                            continue;

                        }
                        continue;
                    }
                    //if the value is in the list and has a bestDistance better than the threshold
                    else {
                        //if the existing value is worse than our current value, get rid of it
                        if (bestAccuracy > this.similarity(keyArray[i],labels.indexOf(keyArray[i]))) {
                            delete bestFits.labels[labels.indexOf(keyArray[i])];
                            bestFits[keyArray[i]] = bestIndex;
                            continue;
                        }
                    }
                }

                return bestFits;
            },

            queryTextract: function() {
                var self = this;
                app.trigger("bulkupload:getIndexerTempDocIds", function(docIDs) {
                    var document = docIDs[self.options.currentIndex];
                    var spinElem = $("#active-suggestButton")[0];
                    $('#suggestButton').hide();

                    spinElem.spinner = HPISpinner.createSpinner({
                        color: '#b6b6b6',
                        length: 8,  
                        width: 8, 
                        radius: 8,
                        position: 'relative',
                        left:'90%',
                    }, spinElem);

                    $.ajax({ 
                        url: app.serviceUrlRoot + "/aws/textract?document=" + document,
                        type: "GET",    
                        global: false,
                        tryCount:0,
                        retryLimit:3,
                        //dataType: "application/json",
                        //contentType: "application/json",
                        success: function(msg) {                            
                            HPISpinner.destroySpinner(spinElem.spinner);
                            self.populateForm(msg);
                        },
                        error: function(jqXHR) {
                            if (JSON.parse(jqXHR.responseText).message == "504 Gateway Timeout") {
                                this.tryCount++;
                                if (this.tryCount <= this.retryLimit) {
                                	
                                    $.ajax(this);
                                    return;
                                } else {
                                    HPISpinner.destroySpinner(spinElem.spinner);
                                     $('#suggestButton').replaceWith("<div id ='textractResult' class='alert alert-warning'>" + window.localize("action.bulkupload.TextractErrorMessage") + "</div>");
                                }
                            }

                            if (JSON.parse(jqXHR.responseText).message == "502 Bad Gateway") { 
                                $.ajax(this);
                            }
                            
                        }
                    });
                
               });

             },
                                                                                                                       
            populateForm: function (msg) {
                var self = this;
                app.context.configService.getAdminOTC(function() {
                    //Parse the response from textract into a JSON we can use
                    var responseJSON = JSON.parse(msg);
                    var responseKeys = Object.keys(responseJSON);
                    var responseValues = Object.values(responseJSON);
                    var formLabels = self.options.activeChildView.options.propertiesViewModel.getFormLabels();              
                    //get a list of fields to fill for comparison to the responseJSON                    
                    var labelNames = Object.values(formLabels);
                    var myOCNames = [];               
                    //compare the keys from our textract response to the labels we parsed from the OTC
                    var fieldsArray = self.compareValues(responseKeys, labelNames, self.options.AWSTextractLowerBound);
                    //the indecies of the values we should be assigning to the form fields
                    var indecies = Object.values(fieldsArray);

                    for (var i = 0 ; i < indecies.length; i++) {
                        myOCNames.push(Object.keys(formLabels)[indecies[i]]);
                    } 
                   
                   //populate the result json we will be using to fill the 
                    var resultJSON = {};
                    myOCNames.forEach(function (k,v) {
                        resultJSON[k]=responseValues[responseKeys.indexOf(Object.keys(fieldsArray)[v])];
                        
                     });

                    //update form styling to add outlines and boxes with the ap,.propriate confidence levels. 
                    var placeholderName = "";
                    var inputGroupName = "";
                    var matchPercent = 0;

                    for (var j = 0; j < myOCNames.length; j++) {
                        placeholderName = myOCNames[j];
                        inputGroupName = "input-group" + j;
                        matchPercent = Math.round(self.similarity(labelNames[Object.values(fieldsArray)[j]],Object.keys(fieldsArray)[j]) *100);

                        if (matchPercent / 100 >= self.options.AWSTextractUpperBound) {
                            $('[id*="' + placeholderName + '"]').css("border", "2px solid #dff0d8");
                            $('[id*="' + placeholderName + '"]').wrap("<div class='input-group' id='" + inputGroupName + "'></div>");
                            $("#" + inputGroupName).append("<span id='textractSuccessSpan' class='input-group-addon'>" + matchPercent + "%</span>");
                        } else {
                            $('[id*="' + placeholderName + '"]').css("border", "2px solid #fff3cd");
                            $('[id*="' + placeholderName + '"]').wrap("<div class='input-group' id='" + inputGroupName + "'></div>");
                            $("#" + inputGroupName).append("<span id='textractWarningSpan' class='input-group-addon'>" + matchPercent + "%</span>");
                        }
                    }

                    self.options.activeChildView.options.propertiesViewModel.setValues(resultJSON,myOCNames);
                    self.displayResults(Object.values(fieldsArray).length,labelNames.length);
                   
                });
                
            }, 
            
            // called when a user clicks on the name of a file to edit
            jumpTo: function (clickedIndex) {
                var hasNext, hasPrevious;

                // save the properties of the current document being viewed
                this._saveCurrentOcoProperties();

                // the current index should be 0-based, clickedIndex is 1-based
                this.options.currentIndex = clickedIndex - 1;

                // set the current object type to be the type of the document that we're navigating to
                this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');

                // check to see if we can go "Next" past the document we're navigating to
                hasNext = this._canGoto(this.options.currentIndex + 1);
                // check to see if we can go "Previous" before the document we're navigating to
                hasPrevious = this._canGoto(this.options.currentIndex - 1);

                //if we have setNewVersion implemented, need to set the typeahead value
                if (this.selectDocumentView) {
                    this.selectDocumentView.setTypeaheadValue(this.options.ocoCollection.at(this.options.currentIndex).get("selectedDocument"));
                }

                // update our pagination controls
                app.trigger('bulkupload:controls:update', {
                    hasNext: hasNext,
                    hasPrevious: hasPrevious,
                    currentIndex: this.options.currentIndex + 1,
                    numDocsToUpload: this.options.ocoCollection.models.length,
                    // we want to display "1 of 3 files"
                    showIndex: true,
                    showRequired: this._isCurrentOcoValid()
                });

                // render this view
                this.render();
            },
            prepareSearchValuesForLookUp: function (query, bulkPropValues) {
                var self = this;
                query.searchParameters = [];

                var currentValues;
                if (bulkPropValues) {
                    currentValues = bulkPropValues;
                } else {
                    currentValues = self.options.activeChildView.getValues();
                }
                $.each(currentValues, function (key, value) {
                    var foundProperty = false;
                    _.each(query.searchParameters, function (sParam) {
                        if ((sParam.paramType === 'property' || sParam.paramType === 'compositeProperty') && sParam.paramName === key) {
                            sParam.paramValue = value;
                            foundProperty = true;
                        }
                    });
                    if (!foundProperty && value && key !== 'objectName') {
                        var sp = {
                            paramName: key,
                            paramValue: value,
                            paramType: "property"
                        };

                        query.searchParameters.push(sp);
                    }
                });

                //lets always toss on obj name as * so it doesnt throw oc errors
                var sp = {
                    paramName: 'objectName',
                    paramValue: '*',
                    paramType: "property"
                };

                query.searchParameters.push(sp);
                //limiting this to 10000
                query.state.pageSize = 10000;
            },
            lookUpValues: function (bulkPropValues, bulkPropObjType) {
                var self = this;

                //execute an OCQuery
                //TODO: take this off the view
                var lookupQuery = new OCQuery.Collection([], {
                    mode: "client"
                });

                self.prepareSearchValuesForLookUp(lookupQuery, bulkPropValues);
                //add the type param
                lookupQuery.searchParameters.push({
                    logic: " and ",
                    paramName: self.options.activeChildView ? self.options.activeChildView.objectType : bulkPropObjType,
                    paramType: "type",
                    paramValue: self.options.activeChildView ? self.options.activeChildView.objectType : bulkPropObjType,
                    relatedObjectOperator: null
                });
                
                // animate our loading indicator with spin.js (lighter weight than animated gif)
                if(!self.spinner){
                    self.spinner = HPISpinner.createSpinner({
                        color: '#666'
                    }, $(".progressSpinner")[0]);
                }

                
                app.popoverHandler.trigger("show", {
                    view: new SlickGridTableView.View({
                        query: lookupQuery,
                        tracConfig: self.lookUpSearchConfig,
                        searchType: self.options.activeChildView ? self.options.activeChildView.objectType : bulkPropObjType,
                        handler: self.options.handler
                    }),
                    title: window.localize("action.bulkUpload.uploadLookupBtn"),
                    size: 'max'
                });

                if(self.spinner){
                    HPISpinner.destroySpinner(self.spinner);
                    self.spinner = undefined;
                }

            },
            next: function () {
                var hasNext, hasPrevious;

                // if we can go to the next object
                if (this._canGoto(this.options.currentIndex + 1, "next")) {
                    // save the current object's properties
                    this._saveCurrentOcoProperties();

                    // increase our current index by one
                    this.options.currentIndex = this.options.currentIndex + 1;

                    // update our "Next" and "Previous" buttons
                    hasNext = this._canGoto(this.options.currentIndex + 1);
                    hasPrevious = true;

                    // if we're in indexing mode, we want to make sure that the document displayed changes based on the document selected
                    if (this.options.indexingMode) {
                        app.trigger("changeCurrentDocId", this.options.currentIndex + 1);
                        app.trigger("addIndexingIframe", this.options.currentIndex);
                    }
                } else {
                    // we can't go to the next object, update our "Next" and "Previous" buttons
                    hasNext = this._canGoto(this.options.currentIndex + 1);
                    hasPrevious = this._canGoto(this.options.currentIndex - 1);
                }

                // set the current object type to be the type of the document that we're navigating to
                this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');

                if (this.selectDocumentView) {
                    this.selectDocumentView.setTypeaheadValue(this.options.ocoCollection.at(this.options.currentIndex).get("selectedDocument"));
                }

                // update our pagination controls
                app.trigger('bulkupload:controls:update', {
                    hasNext: hasNext,
                    hasPrevious: hasPrevious,
                    // current index is 0-based and we want to make it 1-based for display purposes
                    currentIndex: this.options.currentIndex + 1,
                    numDocsToUpload: this.options.ocoCollection.models.length,
                    showIndex: true,
                    showRequired: this._isCurrentOcoValid()
                });

                // render the view
                this.render();
            },
            previous: function () {
                var hasPrevious, hasNext;

                // if we can go to the previous object
                if (this._canGoto(this.options.currentIndex - 1)) {
                    // save the current object's properties
                    this._saveCurrentOcoProperties();

                    // update our current object index
                    this.options.currentIndex = this.options.currentIndex - 1;

                    // update our "Next" and "Previous" buttons
                    hasNext = this._canGoto(this.options.currentIndex + 1);
                    hasPrevious = this._canGoto(this.options.currentIndex - 1);

                    // if we're in indexing mode, we want to make sure that the document displayed changes based on the document selected
                    if (this.options.indexingMode) {
                        app.trigger("changeCurrentDocId", this.options.currentIndex + 1);
                        app.trigger("addIndexingIframe", this.options.currentIndex);
                    }
                } else {
                    // we can't go to the next object, update our "Next" and "Previous" buttons
                    hasNext = this._canGoto(this.options.currentIndex + 1);
                    hasPrevious = this._canGoto(this.options.currentIndex - 1);
                }

                // set the current object type to be the type of the document that we're navigating to
                this.currentObjectType = this.options.ocoCollection.at(this.options.currentIndex).get('objectType');

                //update the typeahead to show the selected document of the document we're navigating to
                //if setNewVersion is enabled
                if (this.selectDocumentView) {
                    this.selectDocumentView.setTypeaheadValue(this.options.ocoCollection.at(this.options.currentIndex).get("selectedDocument"));
                }

                // update our pagination controls
                app.trigger('bulkupload:controls:update', {
                    hasPrevious: hasPrevious,
                    hasNext: hasNext,
                    // current index is 0-based and we want to make it 1-based for display purposes
                    currentIndex: this.options.currentIndex + 1,
                    numDocsToUpload: this.options.ocoCollection.models.length,
                    showIndex: true,
                    showRequired: this._isCurrentOcoValid()
                });

                // render the view
                this.render();
            },
            _canGoto: function (index, action) {
                // index is the 0-based index
                if (index <= this.options.ocoCollection.length - 1 && index > -1) {
                    if (action && action === "next") {
                        return this._isCurrentOcoValid();
                    } else {
                        return true;
                    }
                } else {
                    return false;
                }
            },
            // helper function to generate the upload item view (form support container), set it and render
            _generateFormSupport: function (properties, title, objectType, formName) {
                // set the object type of the object at our current index to be the new object type selected
                this.options.ocoCollection.at(this.options.currentIndex).set("objectType", objectType);

                // generate our formsupport container view
                this.options.activeChildView = new PropertiesView.PropertyList({
                    'properties': properties,
                    'objectType': objectType,
                    'title': title,
                    'enableRequired': true,
                    'formName': formName,
                    'listener': 'bulkupload',
                    'contextlessActionOptions': this.contextlessActionOptions,
                    'controlValueChangeHandler': _.bind(this.processControlValueChanges, this)
                });

                // set and render our formsupport view
                this.setView("#active-item-outlet", this.options.activeChildView).render();
            },
            // called from the beforeRender of this view to set up our object type picklist view and set our listener for
            // when we're done rendering and we trigger the generation of our form support
            _goto: function () {
                // let's make our object type picker with the allowed document types the user has configured
                this.activeObjectTypePicklist = new BulkUpload.ObjectTypePicklist({
                    formName: this.options.formName,
                    contextlessActionOptions: this.contextlessActionOptions,
                    enablePathSecurityCheck: this.options.enablePathSecurityCheck,
                    customTypePaths: this.options.customTypePaths
                });

                // listen for an event to regenerate the UploadItemView, which creates form support for us
                this.listenTo(this.activeObjectTypePicklist, 'bulkupload:generateFormSupport', function (objectType) {
                    var self = this;

                    // get the current properties of the document we're currently looking at
                    var currentProps = this.options.ocoCollection.at(this.options.currentIndex).get("properties");

                    if (this.gmailFiles) {
                        var allPossibleGmailFileNames = [];
                        _.each(this.gmailFiles, function (fileObject) {
                            allPossibleGmailFileNames.push(fileObject);
                            var strippedObject = {};
                            strippedObject.emailProps = fileObject.emailProps;
                            strippedObject.name = fileObject.name.substr(0, fileObject.name.lastIndexOf("."));
                            allPossibleGmailFileNames.push(strippedObject);
                        });
                        var gmailFile = _.where(allPossibleGmailFileNames, {
                            name: currentProps.objectName
                        })[0];
                        if (gmailFile) {
                            currentProps = _.extend(currentProps, gmailFile.emailProps);
                        } else {
                            app.log.warn("Email object could not be found will not auto populate email values");
                        }
                    }

                    // this will be the title of the form support view - so we'll make it the original file name of
                    // the current document being edited
                    var title = "Original Document Name: " + this.options.fileNames[this.options.currentIndex];

                    //this is the formName attached to the actionconfig
                    var formName = this.options.formName;

                    app.context.configService.getFormTypeConfig(self.options.formName, objectType, function (config) {
                        var foundObjectNameControl = config.get('configuredAttrsPri').findWhere({
                            'ocName': 'objectName'
                        });

                        self.checkForObjectName(currentProps, foundObjectNameControl, self.options.currentIndex);
                        // if we only have one document let's do this logic which contains some special logic for figuring out
                        // the control type of the object name (so we can use the filename if it's not computed)
                        if (self.options.ocoCollection.length === 1) {
                            // if we need to inherit folder attributes, first we'll call the getPropsToInherit and then
                            // figure out the control type of the objectName
                            if (self.options.inheritFolderAttributes === "true") {
                                // we need to use the getPropsToInherit function from the options passed in and not the private
                                // method because if a client extends / overrides this method we want to use their custom
                                // implementation
                                self.options.getPropsToInherit(objectType, self.options.formName).done(function (propsToInherit) {
                                    // now we have our properties with the the correct object name so let's generate form support
                                    self._generateFormSupport(_.extend(currentProps, propsToInherit), title, objectType, formName);
                                });
                            } else {
                                // now we have our properties with the the correct object name so let's generate form support
                                self._generateFormSupport(currentProps, title, objectType, formName);
                            }

                        } else { // we are uploading multiple documents
                            // our properties are either the bulk properties overriden with whatever the current properties are
                            // or just the current properties if this object type is not the type selected in bulk properties
                            self._generateFormSupport(((self.bulkPropertiesObjectType === objectType) ? _.extend(self.options.bulkProperties, currentProps) : currentProps), title, objectType, formName);
                        }
                    });
                }, this);

                // this is essentially the beforeRender, so we're setting the object type picklist view here
                this.setView("#active-objectType-picklist", this.activeObjectTypePicklist);
            },
            finish: function () {
                app.trigger('bulkupload:onFinish', this.options.ocoCollection);
            },
            _fileNamesUniqueCheck: function(){
                var names = [];
                _.each(this.options.ocoCollection.models, function(oco){
                    names.push(oco.get("properties").objectName);
                });
                
                var uniqueNames = _.uniq(names);
                var duplicates = _.clone(names);
                _.each(uniqueNames, function(uniqueName){
                    // removing one instance of each unique name from the array
                    duplicates.splice(duplicates.indexOf(uniqueName), 1);
                });
                return duplicates;
            },
            _allOcosValid: function () {
                var allValid = true;
                this.options.ocoCollection.each(function (oco) {
                    if (!oco.get('isValid')) {
                        allValid = false;
                    }
                });
                return allValid;
            },
            _isCurrentOcoValid: function () {
                return this.options.activeChildView ? this.options.activeChildView.isValid() : true;
            },
            // this saves the properties of the current document being viewed
            _saveCurrentOcoProperties: function () {
                // if we have an upload item view (a.k.a a formsupport instance to get the values from)
                // we'll get the values currently on the document, save them to the OCOs properties
                // and also set the indicator on the document Backbone model if it's valid or not
                if (this.options.activeChildView) {
                    var newValues = this.options.activeChildView.getValues();
                    var oco = this.options.ocoCollection.at(this.options.currentIndex);
                    oco.set('properties', _.extend(oco.get('properties'), newValues));
                    oco.set('isValid', this._isCurrentOcoValid());
                    var updatedOcos = this.options.ocoCollection.models;
                    updatedOcos[this.options.currentIndex] = oco;
                    this.options.ocoCollection.set(updatedOcos);
                }
            },
            processControlValueChanges: function(newValue, control) {
                //Don't override location data if it is supposed to be preserved
                if(control.preserveLocationData() || !this.positionDataEnabled) {
                    return;
                }

                //Otherwise remove positional data from the changed attribute
                var curOco = this.options.ocoCollection.at(this.options.currentIndex);
                var ocoProps = curOco.get("properties");
                var positionalData = JSON.parse(ocoProps[this.positionalAttr] || '{}');
                positionalData = _.omit(positionalData, control.id);
                ocoProps[this.positionalAttr] = JSON.stringify(positionalData);
            },
            // oco's need to have an object name on their properties for success link to work
            checkForObjectName: function (props, foundObjectNameControl, index) {
                if (foundObjectNameControl) {
                    if (foundObjectNameControl.get('controlType') !== 'Computed' && !props.objectName) {
                        props.objectName = this.options.fileNames[index];
                    } else if (foundObjectNameControl.get('controlType') === 'Computed') {
                        //we have a computed control, so object name shouldn't be set
                        props.objectName = "";
                    }
                } else if (!props.objectName) {
                    props.objectName = this.options.fileNames[index];
                }
            },
            // this method could be asynchronous if we have to fetch the type configuration from the OTC, so we
            // return a deferred so callers can know when we're done
            setAndPropagateBulkProperties: function (bulkProperties) {
                var self = this;

                this.options.bulkProperties = bulkProperties;

                // this will be undefined if we're only uploading one document
                var selectedObjectType = this.bulkPropertiesObjectType;


                // this method could be asynchronous if we have to fetch the type configuration from the OTC, so we
                // return a deferred so callers can know when we're done
                var deferred = $.Deferred();

                // we won't have a selected object type if they are uploading one document and they are not limiting the object types
                // to one type - in that case we have to wait for the user to choose the object type they want
                if (selectedObjectType) {
                    app.context.configService.getFormTypeConfig(self.options.formName, selectedObjectType, function (config) {
                        var foundObjectNameControl = config.get('configuredAttrsPri').findWhere({
                            'ocName': 'objectName'
                        });

                        var propertiesToCopyOver = [];

                        // the _.extend below will replace true values if left blank
                        // we need to remove any blank fields in bulkProperties
                        for (var key in self.options.bulkProperties) {
                            if (self.options.bulkProperties.hasOwnProperty(key)) {
                                propertiesToCopyOver.push(key);
                                if (!self.options.bulkProperties[key]) {
                                    delete self.options.bulkProperties[key];
                                }
                            }
                        }

                        self.options.ocoCollection.each(function (oco, index) {
                            //only overrite objectTypes that are of the same type as the master
                            if (oco.get('objectType') === selectedObjectType) {
                                // if an oco already exists we only want to copy over properties that are shown in the form
                                for (var key in oco.get("properties")) {
                                    if (propertiesToCopyOver.indexOf(key) === -1) {
                                        delete oco.get("properties")[key];
                                    }
                                }
                                oco.set('properties', _.extend(oco.get('properties'), this.options.bulkProperties));
                            }

                            //if not configured as a computed value,
                            //use the file name as a placeholder in the name field of the oco
                            //ONLY if bulk properties hasn't already injected something
                            self.checkForObjectName(oco.get('properties'), foundObjectNameControl, index);

                        }, self);

                        deferred.resolve();
                    });
                } else {
                    // we're uploading one document
                    // we have to make sure that if the objectName isn't on the form (or not required) there is a default objectName
                    self.checkForObjectName(self.options.ocoCollection.at(0).get('properties'), null, 0);

                    // we're not limiting object types to just one type so let's resolve so the user can choose the object type they want to use for this document
                    deferred.resolve();
                }

                return deferred.promise();
            },
            startListening: function () {
                this.listenTo(app, "bulkupload:backPressed", function () {
                    this.options.currentIndex = 0; //reset if back button pressed
                }, this);

                this.listenTo(app, 'bulkupload:onFinish:fileNamesUniqueCheck', function(deferred){
                    deferred.resolve(this._fileNamesUniqueCheck());
                });

                this.listenTo(app, 'bulkUpload:saveLastOCO', function(){
                    this._saveCurrentOcoProperties();
                });

                // they just clicked the "Next" button
                this.listenTo(app, "bulkupload:nextPressed", function () {
                    this.next();
                });

                // they just clicked the "Previous" button
                this.listenTo(app, "bulkupload:prevPressed", function () {
                    this.previous();
                });

                BulkUpload._removeOldListener("bulkupload:finishPressed");

                // they just clicked the "Finish and Upload" Button
                this.listenTo(app, "bulkupload:finishPressed", function () {
                    this.finish();
                });

                // they clicked on a file name across the top
                this.listenTo(app, "bulkupload:goTo", function (clickedIndex) {
                    this.jumpTo(clickedIndex);
                }, this);

                // we need to set the valid indicator on the OCO when this event is fired
                this.listenTo(app, 'bulkupload:ocoValid', function (documentIndex) {
                    this.options.ocoCollection.at(documentIndex - 1).set('isValid', true);
                }, this);

                // we need to set the invalid indicator on the OCO when this event is fired
                this.listenTo(app, 'bulkupload:ocoInvalid', function (documentIndex) {
                    this.options.ocoCollection.at(documentIndex - 1).set('isValid', false);
                }, this);

                //listen to when the setNewVersion typeahead value changes and rest the value on our oco
                this.listenTo(app, "bulkupload:setNewVersion:docChanged", function (docId) {
                    if (docId) {
                        this.options.ocoCollection.at(this.options.currentIndex).set("selectedDocument", docId);
                        //selected something, so hide our formsupport
                        $("#active-item-outlet").hide();
                        $("#objectTypeDiv").hide();
                        //need to say that this oco is 'valid'
                        app.trigger("bulkupload:formIsValid", {
                            isValid: true
                        });
                    } else {
                        this.options.ocoCollection.at(this.options.currentIndex).set("selectedDocument", undefined);
                        //typeahead cleared, show form support and object type dropdown
                        $("#active-item-outlet").show();
                        $("#objectTypeDiv").show();
                        //since we aren't setting as a new version, we need
                        //to confirm if the form is valid or not and trigger
                        //the event if needed
                        if (!this.options.activeChildView || !this.options.activeChildView.isValid()) {
                            //TODO: youre missing the message you idiot
                            app.trigger("bulkupload:formIsValid", {
                                isValid: false,
                                'externalFormValidationMessage': this.options.activeChildView.externalFormMessage,
                                showExternal: this.options.activeChildView.showExternalValidityMessage()
                            });
                        }
                    }
                }, this);
            }
        });

        // this is the view for choosing bulk properties to apply to multiple documents being uploaded
        BulkUpload.BulkPropertiesView = Backbone.Layout.extend({
            template: "actions/bulkupload/bulkpropertiesview",
            initialize: function (options) {
                var self = this;

                if (options) {
                    // the selected object type for the documents
                    this.bulkPropertiesObjectType = options.bulkPropertiesObjectType;
                    // the list of file names to upload
                    this.fileNames = options.fileNames;
                    // if we are adding from existing content we already have ocos
                    this.ocos = options.ocos;

                    // whether or not to inherit folder attributes
                    this.inheritFolderAttributes = options.inheritFolderAttributes;
                    //form to use
                    this.formName = options.formName;
                    //custom path security
                    this.customTypePaths = options.customTypePaths;
                    this.enablePathSecurityCheck = options.enablePathSecurityCheck;
                }

                // the title for this view - which is actually used in our upload item view above our form support
                this.title = "Bulk Property Edit Page";

                // make a new collection of ocos which will hold our OCOs we build up throughout the action
                this.collection = new OC.OpenContentObjectCollection();

                // let's make our object type picker with the allowed document types the user has configured
                this.objectTypePicker = new BulkUpload.ObjectTypePicklist({
                    contextlessActionOptions: this.contextlessActionOptions,
                    formName: this.formName,
                    enablePathSecurityCheck: this.enablePathSecurityCheck,
                    customTypePaths: this.customTypePaths
                });

                // we're going to listen for when we're ready to generate form support for our bulk properties view (a.k.a once a
                // document type has been chosen by the user and we know the document type to use initially)
                this.listenTo(this.objectTypePicker, 'bulkupload:generateFormSupport', function (objectType) {
                    // we only need to remake our OpenContentCollection and form support view if we've got a new object
                    // type selected
                    if (!this.bulkPropertiesObjectType || this.bulkPropertiesObjectType !== objectType) {
                        this.bulkPropertiesObjectType = objectType;

                        // if we're inheriting folder properties, we need to first fetch our folder properties before continuing
                        if (this.options.inheritFolderAttributes === "true") {
                            // getPropsToInherit returns a deferred so let's wait til that finishes before continuing
                            this.options.getPropsToInherit(this.bulkPropertiesObjectType, this.formName).done(function (propsToInherit) {
                                // set the bulk properties to be the properties we got back from the folder
                                self.bulkProperties = propsToInherit;

                                // if we haven't already built our OCO collection, let's do that
                                if (self.collection.length === 0) {
                                    // if we are adding from existing content we have our ocos already
                                    if (self.ocos && self.ocos[0].isAddingFromExistingContent) {
                                        _.each(self.ocos, function (oco) {
                                            // remove the objectId attribute because we are making a new copy of this object
                                            oco.set("objectId", undefined);
                                            oco.get("properties").objectId = undefined;
                                            // add it to our collection of OCOs
                                            self.collection.add(oco);
                                        }, this);
                                    } else {
                                        // for each of the file names we have, we'll create a new OCO, set its objectType and its
                                        // initial properties from the properties we just fetched from the parent folder
                                        _.each(self.fileNames, function (fileName) {
                                            // create our new OCO
                                            var oco = new OC.OpenContentObject({
                                                objectType: objectType,
                                                properties: _.extend({
                                                    'objectName': fileName
                                                }, propsToInherit)
                                            });

                                            // add it to our collection of OCOs
                                            self.collection.add(oco);
                                        }, this);
                                    }
                                } else { // we've got our OCO collection but we need to update each OCO with the new objectType
                                    self.collection.invoke('set', {
                                        objectType: objectType
                                    });
                                }

                                // this sets up our sequential properties view with our starting properties, the collection and object type selected
                                app.trigger('bulkupload:setupSequentialProperties', objectType, propsToInherit, self.collection);

                                // let's build our upload item view - which houses our form support for Bulk Properties
                                self.buildBulkPropertiesView();
                            }, this);
                        } else { // folder inheritance turned off
                            // we have no starting properties since we're not inheriting anything
                            self.bulkProperties = {};

                            // if we haven't already built our OCO collection, let's do that
                            if (self.collection.length === 0) {
                                // if we are adding from existing content we have our ocos already
                                if (self.ocos && self.ocos[0].isAddingFromExistingContent) {
                                    _.each(self.ocos, function (oco) {
                                        // remove the objectId attribute because we are making a new copy of this object
                                        oco.set("objectId", undefined);
                                        oco.get("properties").objectId = undefined;
                                        // add it to our collection of OCOs
                                        self.collection.add(oco);
                                    }, this);
                                } else {
                                    // for each of the file names we have, we'll create a new OCO, set its objectType and its
                                    // initial properties from the properties we just fetched from the parent folder
                                    _.each(self.fileNames, function (fileName) {
                                        var oco = new OC.OpenContentObject({
                                            objectType: objectType,
                                            properties: {
                                                'objectName': fileName
                                            }
                                        });

                                        // add it to our collection of OCOs
                                        self.collection.add(oco);
                                    }, this);
                                }
                            } else { // we've got our OCO collection but we need to update each OCO with the new objectType
                                self.collection.invoke('set', {
                                    objectType: objectType
                                });
                            }

                            // this sets up our sequential properties view with our starting properties, the collection and object type selected
                            app.trigger('bulkupload:setupSequentialProperties', this.bulkPropertiesObjectType, self.bulkProperties, self.collection);

                            // let's build our upload item view - which houses our form support for Bulk Properties
                            self.buildBulkPropertiesView();
                        }

                        // we now have a next button we should display to the user so they can click "Next" from
                        // the "Bulk Properties" page
                        app.trigger('bulkupload:controls:update', {
                            hasNext: true
                        });
                    }
                }, this);
            },
            getBulkProperties: function () {
                this.bulkProperties = this.activeChildView.getValues();
                return this.bulkProperties;
            },
            getBulkPropertiesObjectType: function () {
                return this.bulkPropertiesObjectType;
            },
            buildBulkPropertiesView: function () {
                // we don't want to build our upload item view (form support container) if we have no object type
                if (this.bulkPropertiesObjectType) {
                    // this builds a view which houses our form support for our bulk properties
                    this.activeChildView = new PropertiesView.PropertyList({
                        // enables read only options for the bulk upload page
                        'enableReadonly': true,
                        'contextlessActionOptions': this.contextlessActionOptions,
                        'properties': this.bulkProperties,
                        'objectType': this.bulkPropertiesObjectType,
                        // we're in bulk properties view so we don't have a document name title to display over form support
                        'bulkProperties': true,
                        // disable validation if this is the bulk property edit page
                        'enableRequired': false,
                        //formName for formsupport
                        'formName': this.formName,
                        'listener': 'bulkupload'
                    });

                    // let's set our form support container view and render it (the controls will show up since
                    // form support uses knockout and we apply bindings in the after render of the upload item view)
                    this.setView(".bulk-properties-item-view", this.activeChildView).render();
                }
            },
            beforeRender: function () {
                // set our object type picklist that the user can choose from before we render
                this.setView('.object-type-picklist', this.objectTypePicker);
            },
            afterRender: function () {
                // after we're done rendering, let's set the object type value
                this.objectTypePicker.setType(this.bulkPropertiesObjectType);
            }
        });

        BulkUpload.SetNewVersionDocSelector = Backbone.Layout.extend({
            template: "actions/bulkupload/setNewVersionDocSelector",
            initialize: function () {
                this.folderContents = new OCQuery.Children([]);
                this.folderContents.id = app.context.container.get("objectId");
            },
            setupTypeahead: function () {
                var self = this;
                app.context.configService.getAdminOTC(function (OTC) {
                    self.folderContents.fetch({
                        success: function () {
                            self.possibleObjects = [];
                            self.folderContents.each(function (model) {
                                var typeModel = OTC.get("configs").where({
                                    ocName: model.get("objectType")
                                })[0];
                                if (typeModel.get("isContainer") === "false") {
                                    self.possibleObjects.push({
                                        name: model.get("properties").objectName,
                                        value: model.get("objectId")
                                    });
                                }
                            });
                            self.typeahead = new HPITypeAhead({
                                options: self.possibleObjects,
                                displayKey: 'name',
                                searchOn: 'name',
                                isGrowable: false,
                                tabIndex: 3
                            });
                            self.typeaheadResolved = true;
                            self.startTypeaheadListening();

                            if (self.hasRendered) {
                                self.setViews({
                                    '#setNewVersion-typeahead': self.typeahead
                                }).render();
                            } else {
                                self.setViews({
                                    '#setNewVersion-typeahead': self.typeahead
                                });
                            }
                        },
                        global: false
                    });
                });
            },
            startTypeaheadListening: function () {
                if (this.typeaheadResolved) {
                    this.stopListening(this.typeahead);
                    this.listenTo(this.typeahead, 'change:selected', this.setSelectedDocument, this);
                }
            },
            setSelectedDocument: function (object) {
                if (object) {
                    this.selectedDocument = object.value;
                } else {
                    this.selectedDocument = undefined;
                }
                app.trigger("bulkupload:setNewVersion:docChanged", this.selectedDocument);
            },
            setTypeaheadValue: function (id) {
                this.selectedDocument = id;
                this.typeahead.setOption(id, true);
            },
            afterRender: function () {
                if (this.selectedDocument && this.typeahead) {
                    this.setTypeaheadValue(this.selectedDocument);
                }
            }
        });

        BulkUpload.DisallowedDocuments = Backbone.Layout.extend({
            template: "actions/bulkupload/disallowedDocuments",
            initialize: function (options) {
                this.disallowedDocuments = options.disallowedDocuments;
            },
            serialize: function () {
                // want to make sure we only call this before it's rendered, otherwise the list of disallowed documents
                // shows up in the bulk properties page when Indexing Mode is enabled.  Check to ensure it's called before rendered 
                if (!this.hasRendered) {
                    return {
                        disallowedDocuments: this.disallowedDocuments
                    };
                }
            }
        });

		// TODO - This view is very similar to the errored docs view in ACTPDF. Should make them use the same view at some point. 
        BulkUpload.DuplicateDocuments = Backbone.Layout.extend({
            template: "actions/bulkupload/duplicateDocuments",
            initialize: function (options) {
                this.duplicateDocuments = options.duplicateDocuments;
            },
            serialize: function () {
                return {
                    duplicateDocuments: this.duplicateDocuments
                };
            }
        });

        BulkUpload.ObjectTypePicklist = Backbone.Layout.extend({
            template: "actions/bulkupload/objectTypePicklist",
            events: {
                "change .objectTypePicklist": "onObjectTypeChange"
            },
            initialize: function (options) {
                // the object types for this object type picker
                this.objectTypes = [];

                this.formName = options.formName;
            },
            // we're either going to have to select a list of all the available document types the user can
            // choose from, or we're good to go - we need to return a deferred in case we need to make our async
            // call to get the list of available object types to choose from
            resolveObjectType: function () {
                var self = this;

                var deferred = $.Deferred();
                var totalPaths = 0;
                var typesToKeep =  [];

                if(self.options.customTypePaths){
                    totalPaths = _.size(self.options.customTypePaths[self.formName]) - 1;
                }

                // Get object types that I should keep
                app.context.configService.getTracConfigs(function(tracConfigs) {
                    _.each(tracConfigs.models, function(trac) {
                        if (trac.has("typesUsedInTrac")) {
                            typesToKeep = typesToKeep.concat(trac.get("typesUsedInTrac"));
                        }
                    });

                    // Intersect the types that I should keep
                    self.intersectFilteredTypes(typesToKeep).done(function() {
                        // Check for path 
                        self.pathSecurity(totalPaths).done(function() {
                            deferred.resolve();
                        });
                    });
                });

                // return our promise object so callers can wait til we've resolved ourselves
                return deferred.promise();
            },
            // Checks for path security if the option was set in settings
            // and if there in custom paths
            pathSecurity: function(totalPaths) {
                var self = this;

                var resolvedPaths = 0;
                var typesToRemove = [];
                var deferred = $.Deferred();

                // Lets limit our types if we cant access the path.
                if (self.options.enablePathSecurityCheck === 'true' && totalPaths > 0) {
                    _.each(_.keys(self.options.customTypePaths[self.formName]),function(typeKey) {
                        if (typeKey !== '_id') {
                            var customPath = self.options.customTypePaths[self.formName][typeKey];

                            // check to see if the user has write permission on the specified path
                            $.ajax({
                                type : "GET",
                                contentType: "application/json",
                                url: app.serviceUrlRoot + "/permission/write?id=" + customPath,
                                success: function (permission) {
                                    // The AJAX call returns a boolean value on whether
                                    // we have write permissions; if we don't have permissions,
                                    // we will remove the type from the option available in the
                                    // object pick list
                                    if (!permission) {
                                        typesToRemove.push(typeKey);
                                    }
                                },
                                error: function() {
                                    // On error, we will remove this type key as it doesn't exist,
                                    // so it should not be shown in the objectTypePicker
                                    typesToRemove.push(typeKey);

                                },
                                complete: function() {
                                    resolvedPaths++;

                                    if (resolvedPaths === totalPaths) {
                                        // we need to fetch the OTC, for this trac, but we don't need the full config
                                        self.removeFilteredTypes(typesToRemove);
                                        deferred.resolve();
                                    }
                                }
                            });
                        }
                    });
                } else {
                    self.removeFilteredTypes([]);
                    deferred.resolve();
                }

                return deferred.promise();
            },
            // Intersects the list of object types and intersects
            // it with the list of object types that the user
            // has access to
            intersectFilteredTypes: function(typesToKeep) {
                var self = this;

                var deferred = $.Deferred();

                // we need to fetch the OTC, for this trac, but we don't need the full config
                app.context.configService.getAdminOTC(function(otc) {
                    // We also need the formTypes, to see what can be created based on the form
                    app.context.configService.getFormConfig(self.formName, function(formConfig) {
                        formConfig.get("configuredTypes").each(function(typeConfig) {
                            // Find the form's type on the OTC and see if it is a container
                            var type = otc.get("configs").findWhere({ocName : typeConfig.get("ocName")});
                            if (type.get("isContainer") === "false") {
                                if(typesToKeep.indexOf(type.get('ocName')) !== -1){
                                    // If type is in the "types to keep" array, push it into object types
                                    self.objectTypes.push({
                                        label: type.get("label"),
                                        value: type.get("ocName")
                                    });
                                }
                            }
                        });
                        deferred.resolve();
                    });
                });

                return deferred.promise();
            },
            // Removes types that the user does not have access to
            removeFilteredTypes: function(typesToRemove) {
                if (typesToRemove !== null && typesToRemove !== undefined && typesToRemove instanceof Array) {
                    this.objectTypes = this.objectTypes.filter(function(objectType) {
                        return typesToRemove.indexOf(objectType.value) === -1;
                    });
                }
                this.singleType = this.objectTypes.length === 1;
            },
            onObjectTypeChange: function(event) {
                var objectType = this.$(event.currentTarget).val();
                this.trigger('bulkupload:generateFormSupport', objectType);
            },
            setType: function (objectType) {
                this.$('.objectTypePicklist').val(objectType);

                // if they're limiting the object types to a single type or we've got a single type for the
                // object type, we want to trigger our event with that single object type
                if (this.singleType) {
                    objectType = this.objectTypes[0] === undefined ? null : this.objectTypes[0].value;
                }

                if(this.contextlessActionOptions && this.contextlessActionOptions.objectType){
                    objectType = this.contextlessActionOptions.objectType;
                    this.$('.objectTypePicklist').val(objectType);
                }
                this.trigger('bulkupload:generateFormSupport', objectType);
            },
            serialize: function () {
                return {
                    singleType: this.singleType,
                    objectTypes: this.objectTypes
                };
            }
        });

        BulkUpload.HTML5UploadControllerView = Backbone.Layout.extend({
            template: "actions/bulkupload/uploadhtml5widget",

            events: {
                // these are the little "X"s next to file names that allow a user to remove a file from bulk upload
                "click .deleteDoc": "deleteDoc",
                // triggered when a user clicks on a document along the status bar to switch to
                "click .uploadDoc": "goTo",
                // the button "Yes" that confirms the user wants to go to the bulk properties page
                "click #confirmBulkProperties": "goToBulkProperties",
                // the button "No" that represents the user does not want to go back to bulk properties
                "click #cancelBulkProperties": "cancelBulkProperties"
            },
            initialize: function (attributes) {
                var self = this;

                // let's make the configuration attributes available to methods of this view (like addActionParamsToFile)
                this.configurationAttributes = attributes.options;

                this.sterilizeAttributes = attributes.options.sterilizeAttributes;
                
                // a list of file objects for upload
                this.files = [];
                // a list of file names for upload
                this.fileNames = attributes.fileNames;
                // a list of MSG file names that have already been checked - we don't want to parse the same MSG file
                // for attachments more than once
                this.checkedFileNames = [];
                // an array of emails and zips that the user removed from the list to upload by clicking the "X" button by the
                // email name - we need to store these so we can attach the attachment properties to the email/zip object when
                // we go to create an email attachment
                this.removedEmails = [];
                this.removedZips = [];
                this.hasAccepted = false;
                // an indicator of whether or not to show the spinner and message that email attachments are being processed
                this.processingAttachments = false;
                // an indicator of whether or not images are part of this bulkupload
                this.hasImages = false;
                // the current index in the oco collection
                this.currentIndex = 0;
                // an array of OCO indexes representing the OCOs that are not yet valid
                this.invalidOcos = [];
                // an array of OCO indexes representing the OCOs that are currently valid
                this.validOcos = [];

                this.fileUploadElement = ".dropZone";
                // list of all the document ids when we do the initial document upload when indexing mode is enabled
                this.indexerFileDocIds = [];
                // this lets us know if we have indexing mode on or off
                this.hasIndexing = false;

                //get allowed doc types from admin config if we have enabled the white list
                if(this.configurationAttributes.documentTypesWhiteListed && this.configurationAttributes.documentTypesWhiteListed.length !== 0){
                    this.allowedDocTypes = attributes.options.documentTypesWhiteListed.split(",");
                } 
                // if there are no whitelist extensions configured in admin, use the defaults, if any
                else if (attributes.options.defaultDocumentTypesWhiteListed && attributes.options.defaultDocumentTypesWhiteListed.length !== 0) {
                    this.allowedDocTypes = attributes.options.defaultDocumentTypesWhiteListed.split(",");
                }
                this.disallowedDocuments = [];

                // this is a handlebars helper for building an element when a new file is chosen for upload
                // and for building the document status markers on the status bar
                Handlebars.registerHelper('tracker', function (fileNames) {
                    // we're going to construct our HTML and return it
                    var html = '';
                    self.imagesLoaded = false;
                    // this counter is for separating the filenames into sections that will scroll together
                    // when the user clicks the next or previous arrows on the status bar
                    var i = 0;

                    // loop over each of the individual file names to upload and build their HTML
                    _.each(fileNames, function (fileName, index) {
                        // if our counter is at 0, we're creating a new group of document name labels to scroll together
                        if (i === 0) {
                            html += "<div>";
                        }

                        // index is 0 based and we want to be 1-based
                        var offset = index + 1;

                        // if we're not past the file upload page yet, then we need to allow the user to remove documents chosen
                        // for upload
                        if (!this.hasAccepted) {
                            if (fileName.hasError) {
                                html += '<div class="fileUploader" ><label class="fileHasUploadError"' + ' style="color:red">' +
                                    '<a name="' + index + '" class="deleteDoc">' +
                                    '<span class="glyphicon glyphicon-remove"/>' +
                                    '</a>';
                            } else {
                                html += '<div class="fileUploader" ><label>' +
                                    '<a name="' + index + '" class="deleteDoc">' +
                                    '<span class="glyphicon glyphicon-remove"/>' +
                                    '</a>';

                            }
                            html += fileName.name + '</label></div>';
                        } else { // we can now display nice looking document status markers
                            //Check if the file is an image,
                            //  if it is, display a thumbnail image instead of a label
                            html += '<div class="acceptedDoc">';
                            html += '<div class="tracker-wrapper">';
                            html += '<div id="bulkupload-tracker-' + offset + '" class="uploadLabel';

                            //Configure the label's style by adding various classes
                            if (self.currentIndex <= 0) {
                                // here we are in bulk properties since we don't have a currentIndex yet - so we want to add
                                // the disabled class to prevent the user from thinking a document marker is clickable
                                html += ' disabled">';
                            } else { // we are past the bulk properties page
                                if (offset === self.currentIndex) {
                                    // we are dealing with the current document, let's add the arrow underneath it to
                                    // indicate to the user which document is currently being viewed
                                    html += ' current-arrow';

                                    // if this document is valid, let's make it green, otherwise make it blue
                                    if (_.contains(self.validOcos, offset)) {
                                        html += ' btn-success">';
                                    } else {
                                        html += ' btn-primary">';
                                    }
                                } else { // we're building up something other than the current document
                                    // if the current document is invalid, we'll make it a btn-danger to make it a red background
                                    if (_.contains(self.invalidOcos, offset)) {
                                        html += ' uploadDoc btn-danger">';
                                    } else { // possibly valid or not visited
                                        // if the current document is visited (it's also valid) we'll make it green
                                        if (_.contains(self.validOcos, offset)) {
                                            html += ' uploadDoc btn-success">';
                                        } else { // not visited - let's make the not visited documents a black gradient background
                                            html += ' uploadDoc btn-inverse">';
                                        }
                                    }
                                }
                            }
                            html += fileName.name;
                            //Add the container and image.  Image tags are shrunk in after reader if there are no thumbnails
                            html += '<div class="image-wrapper">';
                            html += '<img id="bulkupload-image-tracker-' + offset;
                            //Enable/disable the thumbnail by giving assigning it the proper class
                            var fileExtension = fileName.name.split('.').pop().toLowerCase();
                            if (fileExtension === "jpg" || fileExtension === "jpeg" || fileExtension === "png" || fileExtension === "gif") {
                                html += '" class="previewImage"';
                                self.hasImages = true;
                            } else {
                                html += '" class="disabledImage"';
                            }
                            //Close the image-wrapper, bulkupload-tracker-#, tracker-wrapper, and acceptedDoc div's respectively.
                            html += ' src="" /></div></div></div></div>';
                        }

                        // we're done building up this document marker
                        i++;

                        // if we've reached the number of documents we can have on a page, let's close the container div
                        // that surrounds that number of documents
                        if (i === self.numDocsPerPage) {
                            html += "</div>";

                            // reset our counter so we start building a new container div
                            i = 0;
                        }
                    }, this);

                    // if we didn't have a divisible number of documents by the number we can have on a page, we need to close
                    // off the final container div
                    if (i !== 0) {
                        html += "</div>";
                    }

                    return html;
                }, this);

                this.removeListeners();
                this.applyListeners();

                $(document).bind('drop dragover', function (e) {
                    e.preventDefault();
                });
            },

            removeListeners: function() {
                BulkUpload._removeOldListener("bulkupload:indexButtonPressed");
                BulkUpload._removeOldListener("bulkupload:filesUploaded");
                BulkUpload._removeOldListener("bulkupload:processingAttachments");
                BulkUpload._removeOldListener("bulkupload:toggleAttachmentsSpinner");
            },

            applyListeners: function() {
                this.listenTo(app, 'bulkupload:indexButtonPressed', this.fileIndexingEnabled);
                
                // retrieve the files and all them to the list and re-render
                this.listenTo(app, 'bulkupload:filesUploaded', function (files) {
                    this.addDocs(files);
                    this.render();
                    app.trigger("bulkUpload:filesChosen");
                }, this);

                this.listenTo(app, 'bulkupload:nextPressed', function (gotoIndex) {
                    // both currentIndex and docMarker are 1-based
                    if (gotoIndex) {
                        this.currentIndex = gotoIndex;
                    } else {
                        this.currentIndex++;
                    }
                    this.docMarker = this.currentIndex;
                    this.render();
                }, this);

                this.listenTo(app, 'bulkupload:prevPressed', function () {
                    // both currentIndex and docMarker are 1-based
                    this.currentIndex--;
                    this.docMarker = this.currentIndex;
                    this.render();
                }, this);
                
                //going back to bulk properties, reset
                this.listenTo(app, 'bulkupload:goToBulkProperties', function () {
                    this.currentIndex = 0;
                    this.render();
                }, this);

                this.listenTo(app, 'bulkupload:ocoInvalid', function (index) {
                    // if this document is not already in the invalidOcos array, add it
                    if (!_.contains(this.invalidOcos, index)) {
                        this.invalidOcos.push(index);
                    }

                    // remove the document from the validOcos if it's there
                    this.validOcos = _.without(this.validOcos, index);

                    this.render();
                }, this);

                this.listenTo(app, 'bulkupload:ocoValid', function (index) {
                    // if this document is not already valid, add it to the list of validOcos
                    if (!_.contains(this.validOcos, this.currentIndex)) {
                        this.validOcos.push(this.currentIndex);
                    }

                    // remove the document from the invalidOcos array if it's there
                    this.invalidOcos = _.without(this.invalidOcos, index);

                    this.render();
                }, this);

                // once the "Generate Cover Page" button is pressed, we want to add the placeholder cover page file
                // to the list of files to upload
                this.listenTo(app, 'bulkupload:dropOffScanPressed', function (files) {
                    // add the files to the list of files to upload, should be only one file in the files array
                    // for the cover page button since we only generate one with each click of the button
                    this.addDocs(files);
                    // render this view so we can see the newly added cover page file
                    this.render();
                    // trigger the filesChosen event so we can enable the "Next" button if we're good to go
                    app.trigger("bulkUpload:filesChosen");
                }, this);

                // a listener to toggle the HTML5ControllerView's processingAttachments variable that controls
                // if the processing attachments message and spinner are visible and active
                this.listenTo(app, 'bulkupload:processingAttachments', function (processingAttachments) {
                    var self = this;

                    self.processingAttachments = processingAttachments;

                    self.render();
                }, this);

                // a listener that should get triggered when this view is rendered to either stop or create the spinner
                // that indicates that email attachments are being processed
                this.listenTo(app, 'bulkupload:toggleAttachmentsSpinner', function () {
                    if (this.processingAttachments) {
                        // animate our loading indicator with spin.js (lighter weight than animated gif)
                        this.processingAttachmentsSpinner = HPISpinner.createSpinner({
                            color: '#666'
                        }, this.$("#processingAttachmentsSpinner")[0]);
                    } else { // we're no longer processing attachments
                        // get rid of our spinner
                        HPISpinner.destroySpinner(this.processingAttachmentsSpinner);
                    }
                }, this);

                this.listenTo(app, 'bulkupload:controls:update', function (options) {
                    var canAdvance = options.hasNext;

                    if (canAdvance) {
                        $(".uploadLabel").removeClass("disabled").addClass("uploadDoc");
                    }
                }, this);
            },
            
            afterRender: function () {
                var self = this;

                // we only want the fileupload dropzone if we're not in the "Add Emails" action
                if (!this.configurationAttributes.addEmail) {
                    //html5 drag and drop file upload for browsers that support it
                    this.$(self.fileUploadElement).bind('dragenter dragover', function (e) {
                        e.preventDefault();
                        $(this).css({
                            'border': '3px dashed #e83a00'
                        });
                    });
                    this.$(self.fileUploadElement).bind('dragleave drop', function (e) {
                        e.preventDefault();
                        $(this).css({
                            'border': '2px dashed #c0c0c0'
                        });
                    });

                    // dropzone
                    this.$(self.fileUploadElement).fileupload({
                        add: function (e, data) {
                            self.addDocs(data.files);
                            self.render();
                            app.trigger("bulkUpload:filesChosen");
                        },
                        dropZone: $(self.fileUploadElement)
                    });
                }


                // now that we've rendered we want to either show or hide the message and spinner that indicates if we're processing
                // email attachments or not
                app.trigger("bulkupload:toggleAttachmentsSpinner");

                // if the user has accepted a list of documents to upload, then we're dealing with formatting the status bar
                if (this.hasAccepted) {
                    // get the amount of space we have to deal with for our status bar
                    var statusBarWidth = $("#fileupload-list").width();

                    // we subtract 175 pixels from the available width, since we've got a Bulk Properties button (120 pixels), a left arrrow (15 pixels),
                    // a right facing arrow (15 pixels) and a scrollbar (20 pixels) and we want to space things a little bit
                    var scrollerWidth = statusBarWidth - 175;

                    // if we're at this point, then the Handlebars tracker for generating the containers for the "pages" of documents
                    // to scroll through has already executed and it's possible that it ran before we have run this code (i.e., the first time)
                    // so the numDocsPerPage will be undefined and once we've calculated the real number of documents per page, we'll re-render
                    // so we get the right number of containers
                    var previousDocsPerPage = this.numDocsPerPage;

                    // the minimum width we want for each document marker label is 151px so we should divide our usable space by that
                    // to figure out how many documents we can have per page
                    this.numDocsPerPage = Math.floor(scrollerWidth / 151);

                    // if we have room to display more documents than we have, then we should only account for the amount of docs
                    // the user is uploading
                    var docsToDisplay = this.numDocsPerPage > this.fileNames.length ? this.fileNames.length : this.numDocsPerPage;

                    // each document label should be our available width for the documents divided by how many we have
                    var docWidth = Math.floor(scrollerWidth / docsToDisplay);

                    // we want a maximum size for our document labels (230 pixels), otherwise they'll stretch a lot and look ridiculous
                    docWidth = Math.min(docWidth, 230);

                    // set the width of the scroller container to be just enough to display however many docs will fit fully on the
                    // status bar
                    $("#bulkUpload-fileNames").width(docsToDisplay * docWidth);

                    // update the width of each document status div to be the width we calculated minus the padding (10 on each side) and
                    // the border (1 pixel from one side)
                    //this.$("#bulkUpload-fileNames .acceptedDoc").width(docWidth - 21);

                    // initialize our scrollable plugin on that div that we've now resized correctly
                    this.$("#bulkUpload-fileNames").scrollable();

                    // let's figure out the page we should be looking at - if docMarker is defined then they could have clicked
                    // on a document on the second, third, fourth, etc. page so we want to seek there
                    var page;
                    if (!this.docMarker) {
                        // we have no docMarker defined so they either clicked the bulk properties button or are just entering the
                        // bulk properties page for the first time
                        page = 0;
                    } else {
                        // docMarker is the index they clicked on so we can figure out what page that is by dividing by the number
                        // of documents we have per page, rounding up to the nearest integer and subtracting 1
                        page = Math.ceil(this.docMarker / this.numDocsPerPage) - 1;
                    }

                    // get the api for our scrollable plugin
                    var api = this.$("#bulkUpload-fileNames").data("scrollable");

                    // go to the page that we should be viewing (0 specifies that we want to go right away)
                    api.seekTo(page, 0);

                    // this is the case above where we've incorrectly (probably) calculated the number of containers we need, since
                    // now we know how many documents we can have per page, let's re-render so we get the right number of containers
                    if (!previousDocsPerPage) {
                        self.render();
                    }
                    
                    if(this.configurationAttributes.isTrackerThumbnailsEnabled === 'true'){
                        //Decide if special actions are need because the uploads contain images.
                        if (self.imagesLoaded === false) {
                            self.evaluateThumbnails();
                        }
                    }
                }

                // if we're not on the bulk properties page, let's remove the arrow from the bulk properties button
                if (this.currentIndex > 0) {
                    this.$("#bulkupload-tracker--1").removeClass("current-arrow");
                }

                // now that the HTML for the document markers has been created, we want to create a tooltip of the document name
                // for each one - we don't want a tooltip for the bulk properties button
                this.$(".acceptedDoc").not("#bulk-properties-btn").each(function () {
                    // we're attaching the tooltip to the bulkUpload div since our document marker divs are constrained by
                    // a specific height (needed to make the scrollable plugin work correctly) so they would not show completely
                    $(this).tooltip({
                        title: $(this).text(),
                        container: $("#bulkUpload"),
                        delay: {
                            show: 500,
                            hide: 0
                        }
                    });

                    // when a tooltip hides, it unfortunately triggers a 'hide' event that the modal would pick up on and
                    // end up closing itself if we don't stop the propagation of the event
                    $(this).on('hidden', function (event) {
                        event.stopPropagation();
                    });
                });

                // we are in templating mode so we hide the dropzone and add docs button
                if (this.keepWellhidden) {
                    $(".dropZone").hide();
                    $(".addDocButton").hide();
                }
            },
            /**
             * This is exclusively run when a zip or email is removed, need to push these files to a removed array in order to still parse attachments off of it
             * @param {String} fileId -emailId or zipId
             * @param {Object} removedFilesArray - array that already contains the removed files (either this.removedEmails or this.removedZips)
             * @param {Object} removedFile - the file that's being removed (zip or msg)
             */
            addRemovedFilesWithAttachmentsToRemovedFilesArray: function(fileId, removedFilesArray, removedFile){
                // if we haven't already put the email/zip in the removedEmails/removedZips array, let's put it there
                var valueToFind = removedFile[fileId];
                if (!_.findWhere(removedFilesArray, valueToFind)) {
                    removedFilesArray.push(removedFile);
                }
            },

            /**
             * This method gets called whenever a file is removed from the bulkupload screen, regardless of the filetype.
             * @param {Event} event 
             */
            deleteDoc: function (event) {
                // based on the index, delete the corrsponding doc
                var index = $(event.currentTarget).attr('name');

                // get our file that we're removing so we can check if its an email and do extra logic with it
                var removedFile = this.files.splice(index, 1);
                if (this.options.maxTotalUploadSize) {
                    totalUploadSize -= removedFile[0].size;
                    if (totalUploadSize < parseInt((this.options.maxTotalUploadSize * tsgUtils.FILE_SIZE_CONVERSIONS.BYTES_TO_KILOBYTE), 10)) {
                        hasTotalUploadSizeError = false;
                    } else {
                        hasTotalUploadSizeError = true;
                    }
                }

                // if the removed file is an email object, we want to store this in our removedEmails array so when the user
                // tries to upload the attachments of the email, we can send the email content to OC to parse to get the attachment
                // content
                if (removedFile[0].email) {
                    this.addRemovedFilesWithAttachmentsToRemovedFilesArray('emailId', this.removedEmails, removedFile[0]);
                }

                // if the removed file is an zip object, we want to store this in our removedZips array so when the user
                // tries to upload the attachments of the email, we can send the email content to OC to parse to get the attachment
                // content
                if (removedFile[0].zip) {
                    this.addRemovedFilesWithAttachmentsToRemovedFilesArray('zipId', this.removedZips, removedFile[0]);
                }

                if (removedFile[0].coverPage) {
                    app.trigger('bulkupload:removedCoverPage');
                }

                // get rid of the removed file from the fileNames array as well
                this.fileNames.splice(index, 1);

                var foundFile = false;
                uploadSizeErrorList = _.filter(uploadSizeErrorList, function (errorFile) {
                    if (errorFile === removedFile[0].name && !foundFile) {
                        foundFile = true;
                        return false;
                    } else {
                        return true;
                    }
                });


                BulkUpload.updateErrorModal(this.options.handler, this.options.maxTotalUploadSize, this.options.maxUploadSize);

                if (removedFile[0].isAddingFromExistingContent) {
                    app.trigger("addingFromExistingContent:fileRemoved", removedFile);
                }

                // if we had added normal documents and now they are gone we want to enable add from exisiting again
                if (this.files.length === 0) {
                    this.disableAddFromExisting = false;
                    $(".createDocFromExistingContentButton").removeClass("disabled");
                }

                this.render();

                // if we are in templating mode the dropzone will be hidden
                this.keepWellhidden = !$(".dropZone").is(":visible") && !$("#processingAttachments").is(":visible");

                // there is only one doc and it's a templated or an existing doc we want to set the type
                if (this.files.length > 0 && this.files[0] instanceof OC.OpenContentObject) {
                    if (this.files[0].isAddingFromExistingContent) {
                        app.trigger("addFromExistingContent:setObjectType", this.files[0].get("objectType"));
                    } else {
                        app.trigger("addDocTemplate:setObjectType", this.files[0].get("properties").hpiTargetType);
                    }
                }

                // trigger this event in case there aren't any docs left - we'll want to disable the "Next" button in that case
                app.trigger("bulkUpload:filesChosen");

                // show the removed value in the print from repo table
                if(removedFile[0].isPrintToRepo === "true"){
                    app.trigger("printToRepo:updateTable", removedFile[0].id);
                }
            },

            // this gets called when a user clicks a document status marker on the status bar or the bulk properties button
            // on the status bar
            goTo: function (event) {
                // strip bulkupload-tracker prefix and compute the id as an index - the index is -1 if they clicked the bulk properties button
                var index = Number(this.$(event.currentTarget).attr('id').replace(/bulkupload-tracker-/, ''));
                if (this.currentIndex === 0) {
                    app.trigger('bulkupload:nextPressed', index);
                }
                if (!isNaN(index)) {
                    // we want to destroy all the tooltips for the document status markers, otherwise they'll stick around on the DOM
                    // and won't hide because their associated DOM element goes away
                    this.$(".acceptedDoc").not("#bulk-properties-btn").each(function () {
                        $(this).tooltip("destroy");
                    });

                    // index is -1 if they clicked on "Bulk Properties"
                    if (index === -1) {
                        // let's make sure we're not currently on the bulk properties page - if so, there's no warning to display
                        if (this.currentIndex > 0) {
                            // we're not on the bulk properties page so slide down our warning message and options
                            this.$("#bulk-properties-warning").slideDown("fast");
                        }
                    } else { // they clicked on a document to view
                        // the docMarker is the document they clicked on (1-based)
                        this.docMarker = index;
                        // the current index is also the document they clicked on (1-based)
                        this.currentIndex = index;

                        app.trigger('bulkupload:goTo', index);
                        // if we are in indexing mode, we need to make sure that we are displaying the iFrame and changing the displayed document based on the current document
                        if (this.hasIndexing) {
                            app.trigger("addIndexingIframe", this.currentIndex-1);
                            app.trigger('changeCurrentDocId', index);
                            this.render();
                        }
                    }
                }
            },

            // this gets called if the user confirms they actually want to go to Bulk Properties by clicking the "Yes" button
            goToBulkProperties: function () {
                // if indexing mode is enabled, we don't want to show the iFrame on the "Bulk Properties" tab.
                if (this.hasIndexing) {
                    app.trigger("disableIndexingIframe");
                }

                // reset our current index to 0
                this.currentIndex = 0;
                // our docMarker is 0 (so we scroll back to the first page of documents)
                this.docMarker = 0;
                // reset our valid and invalid OCOs (will get rid of the colors)
                this.validOcos = [];
                this.invalidOcos = [];

                // go to bulk properties now
                app.trigger('bulkupload:goToBulkProperties');
            },

            // this gets called if the user cancels their request to go to Bulk Properties by clicking the "No" button - it simply
            // hides the warning
            cancelBulkProperties: function () {
                this.$("#bulk-properties-warning").slideUp("fast");
            },

            // adds file objects to the list of the files to upload as well as the file names (hiding or showing extensions)
            addDocs: function (files) {
                if (files && files[0]) {
                    // set the object name to the name of the file selected to the file name
                    this.fileNames = [];

                    // add the files chosen for upload to the array of files to upload
                    _.each(files, function (file) {
                        var fileExtension = file.name.split('.').pop().toLowerCase();
                        // if we have a white list of document types and the file's type is not
                        // included in the document type white list, do not add it to the docs being uploaded
                        // also, we will NOT check if we are in "Create Document from Template" mode
                        if (file.isTemplate !== true && file.coverPage !== true && this.allowedDocTypes && this.allowedDocTypes.indexOf(fileExtension) === -1) {
                            this.disallowedDocuments.push(file);
                        }
                        else {
                            this.files.push(file);
                        }
                    }, this);

                    app.trigger("bulkupload:initDisallowedDocumentsView", this.disallowedDocuments);

                    uploadSizeErrorList = [];
                    totalUploadSize = 0;
                    // add the file names to the list of filenames for upload, removing the file extension if configured to do so
                    _.each(this.files, function (file) {

                        if (this.options.maxTotalUploadSize) {
                            totalUploadSize += file.size;
                            if (totalUploadSize > parseInt((this.options.maxTotalUploadSize * tsgUtils.FILE_SIZE_CONVERSIONS.BYTES_TO_KILOBYTE), 10)) {
                                hasTotalUploadSizeError = true;
                            }
                        }
                        //check if we have a max size set in the config
                        var filenameToPush = file.name;
                        if (this.sterilizeAttributes.shouldSterilizeFilenames === 'true') {
                            filenameToPush = tsgUtils.sterilizeFilename(file.name, this.sterilizeAttributes);
                        }
                        if (this.options.maxUploadSize) {
                            if (file.size > parseInt((this.options.maxUploadSize * tsgUtils.FILE_SIZE_CONVERSIONS.BYTES_TO_KILOBYTE), 10)) {
                                //this doc is TOO BIG!
                                uploadSizeErrorList.push(file.name);
                                this.fileNames.push(filenameToPush);
                            } else { //The file works
                                // put our file name on the list of file names to upload
                                this.fileNames.push(filenameToPush);
                                // if the message we're adding is an MSG message
                                
                            }
                        } else {
                            this.fileNames.push(filenameToPush);
                        }

                        if (this.isMSGFile(file.name)) {
                            this.removingFiles(file, BulkUpload.CONSTANTS.EMAIL, "emailId", "removedEmails");
                        }
                        //if uploadSize exists

                        if (this.isZIPFile(file.name)) {
                            this.removingFiles(file, BulkUpload.CONSTANTS.ZIP, "zipId", "removedZips");
                        }
                    },this); //end of each files

                    BulkUpload.updateErrorModal(this.options.handler, this.options.maxTotalUploadSize, this.options.maxUploadSize);
                }

                // if we are in templating mode the dropzone will be hidden
                this.keepWellhidden = !$(".dropZone").is(":visible") && !$("#processingAttachments").is(":visible");

                // if this is a normal upload we want to disable the add from existing button
                if (this.files.length > 0 && !this.files[0].isAddingFromExistingContent) {
                    $(".createDocFromExistingContentButton").addClass("disabled");
                }

                // there is only one doc and it's a templated doc we want to set the type
                if (this.files.length > 0 && this.files[0] instanceof OC.OpenContentObject) {
                    if (this.files[0].isAddingFromExistingContent) {
                        app.trigger("addFromExistingContent:setObjectType", this.files[0].get("objectType"));
                    } else {
                        app.trigger("addDocTemplate:setObjectType", this.files[0].get("properties").hpiTargetType);
                    }
                }
            },

            removingFiles: function(file, fileType, fileId, removedFiles) {
                 // let's check the removedEmails array to see if the user previously removed this file
                 var removedFile = _.findWhere(this[removedFiles], {
                    name: file.name
                });

                // if we found it there, then we want to reassociate any attachments back to this email/zip
                if (removedFile) {
                    // mark this file as being an email/zip
                    file[fileType] = true;
                    // give the file the email/zipId of the removed email/zip (which will associate any remaining attachments
                    // back to this email/zip)
                    file[fileId] = removedFile[fileId];

                    // remove this email/zip from the removed email/zips array since the user now wants to create this email/zip object
                    this[removedFiles] = _.without(this[removedFiles], removedFile);
                }
            },

            docScanned: function (scannedBlob) {
                this.addDocs([scannedBlob]);
                this.render();
                app.trigger("bulkUpload:filesChosen");
            },

            getDocs: function () {
                return this.files;
            },

            doUpload: function (collection) {
                var filesToUpload = [];

                this.collection = collection;
                this.successList = [];
                this.errorList = [];
                this.uploadIndex = 0;
                this.deferreds = [];

                // Calling to remove properties view from the view
                this.removePropertiesView();

                // Updating alert message to extend across screen
                $('#oa-indexing-modal-body').css("width", "100%");

                // A create and pass a shallow copied files list into synchronous upload, since that method modifies 
                // the passed in list, but OTHER methods expect self.files to be unchanged.
                _.each(this.files, function(file) {
                    // Set the createEmail/createZip flag to true always regardless of what the file is (email, attachment, document, etc.)
                    file.createEmail = true;
                    file.createZip = true;
                    filesToUpload.push(file);
                });

                this.uploadRemovedFilesForAttachmentParsing("removedEmails", filesToUpload, "createEmail");
                this.uploadRemovedFilesForAttachmentParsing("removedZips", filesToUpload, "createZip");

                // If asynchronousOption is false, call performSynchronousUploads
                // otherwise call performAsychronousUploads
                if (!this.options.asynchronousOption) {
                    this.performSynchronousUploads(filesToUpload, this.successList, this.errorList, 0, undefined, this);
                } else {
                    this.performAsynchronousUploads(filesToUpload, this.successList, this.errorList, this);
                }
            },

            /**
             * 
             * @param {String} removedAttachmentContainer - removedEmails or removedZips array, which will contain the array of removed parent folders to compare with
             * @param {*} filesToUpload - this is an array of files to upload to share
             * @param {*} createFile - createEmail or createZip, this variable is what determines if the MSG/Zip file gets added into share
             */
            uploadRemovedFilesForAttachmentParsing: function(removedAttachmentContainer, filesToUpload, createFile) {
                _.each(this[removedAttachmentContainer], function(file) {
                    file[createFile] = false;
                    filesToUpload.push(file);
                    // Make a blank OCO to keep the files and OC collection in synchronization and to not throw off the index
                    var oco = new OC.OpenContentObject();
                    this.collection.add(oco);
                }, this);
            },

            /**
             * Uploads objects passed into this function asynchronously.
             *
             * @param {Object} files - Files passed in as objects that we get the file name and createEmail flag from.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             * @param {number} uploadIndex - The index of the uploaded item in the collection / the order in which it was uploaded.
             * @param {number} originalLength - The total length of all documents to be uploaded.  We track this variable because the files list itself
             * is modified during each recursion.
             * @param {Object} self - The context of this function.
             */
            performSynchronousUploads: function (files, successList, errorList, uploadIndex, originalLength, self) {
                app.log.debug("Uploading document " + uploadIndex);

                // If originalLength is undefined this is the first call of performSynchronousUploads
                if (!originalLength) {
                    // Set our original length to the length of the files array when it is first passed in
                    originalLength = files.length;

                    // Call the updateProgressBar functionality and set it to 0
                    self.updateProgressBar(0, self);
                }

                // Grabs the first file in the array of files
                var file = files.shift();
                self.uploadIndex = uploadIndex;

                // If we have an email attachment, immediately proceed to the next file, since attachments are handled in the email itself's upload.
                // Otherwise we have an actual file, and we need to wait for that file's upload to complete before proceeding to the next file.
                if(file.emailAttachment) {
                    self.updateSynchUploadProgressAndRecurse(files, successList, errorList, uploadIndex, originalLength, self);
                } else {
                    self.upload(file, successList, errorList).done(function() {
                        self.updateSynchUploadProgressAndRecurse(files, successList, errorList, uploadIndex, originalLength, self);
                    });
                }
            },
            
            /**
             * Updates the progress bar for a synchronous upload and then launches the next upload.
             * 
             * @param {Object} file - The file to upload.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             * @param {number} uploadIndex - The index of the uploaded item in the collection / the order in which it was uploaded.
             * @param {number} originalLength - The total length of all documents to be uploaded.  We track this variable because the files list itself
             * is modified during each recursion.
             * @param {Object} self - The context of this function.
             */
            updateSynchUploadProgressAndRecurse: function(files, successList, errorList, uploadIndex, originalLength, self) {
                app.log.debug("Finished document " + uploadIndex);
                if (files.length > 0) {
                    // Determine the currentProgress to update the progress bar with
                    var currentProgress = (((uploadIndex + 1) / originalLength) * 100).toFixed(0);
                    self.updateProgressBar(currentProgress, self);

                    // Since we have more files in the files array we call performSynchronousUploads again
                    app.log.debug("Trying again - not complete yet, progress: " + currentProgress);
                    self.performSynchronousUploads(files, successList, errorList, uploadIndex + 1, originalLength, self);
                } else {
                    // Calling the functionality to update the progress bar to 100 and then hide it
                    // and trigger doneUploading
                    self.updateProgressBar(100, self);
                    self.hideProgressBarAndTriggerDoneUploading(successList, errorList, self);
                }
            },

            /**
             * Uploads objects passed into this function asynchronously.
             *
             * @param {Object} fileObjectsToUpload - Files passed in as objects that we get the file name and createEmail flag from.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             * @param {Object} self - The context of this function.
             */
            performAsynchronousUploads: function (filesToUpload, successList, errorList, self) {
                var finishedUploadCount = 0;
                var totalDocsToUpload = filesToUpload.length;
                
                // Trigger the initial calls to setup the progress bar to 0
                self.updateProgressBar(0, self);

                // Loop through each file, determine which ones are uploadable, then process for upload
                _.each(filesToUpload, function(file) {

                    // Check to see if file.emailAttachment or file.zipAttachment is truthy, it will only be falsy in the case where we are processing an
                    // email/zip attachment that already has had its parent email processed for uploading TODO
                    if (!file.emailAttachment && !file.zipAttachment) {
                        app.log.debug("Uploading document " + self.uploadIndex);
                        
                        // Set up our deferred object which references the file we sent for uploading
                        // Also have a done function setup on the deferred to update the progress bar as each individual
                        // response that comes back after finishing an upload
                        var deferred = self.upload(file, successList, errorList).done( function() {
                            finishedUploadCount++;
                            self.updateAsynchUploadProgress(finishedUploadCount, totalDocsToUpload, self);
                        });

                        // Push our deferred to the list of deferreds
                        self.deferreds.push(deferred);
                    } else {
                        // If we are processing an email attachment we don't actually upload but we still want to represent
                        // this processing to the user. Increment the finishedUploadCount and update the progress bar
                        finishedUploadCount++;
                        self.updateAsynchUploadProgress(finishedUploadCount, totalDocsToUpload, self);
                    }

                    // Increment the uploadIndex for each file that is processed to make sure that we are staying in sync
                    // with the array of ocos
                    self.uploadIndex++;
                }, this);

                // Wait for all the deferreds to resolve which means the upload process has completed
                // We then call the functionality to update the progress bar to 100 and then hide it
                // and trigger doneUploading
                $.when.apply($, self.deferreds).then(function () {
                    self.updateProgressBar(100, self);
                    self.hideProgressBarAndTriggerDoneUploading(successList, errorList, self);
                });
            },
            
            /**
             * Updates the progress bar for an asynchronous upload and then launches the next upload.
             *
             * @param {number} finishedUploadCount - The index of the uploaded item in the collection / the order in which it was uploaded.
             * @param {number} totalDocsToUpload - The total length of all documents to be uploaded.
             * @param {Object} self - The context of this function.
             */
            updateAsynchUploadProgress: function(finishedUploadCount, totalDocsToUpload, self) {
                app.log.debug("Finished document " + finishedUploadCount);
                // Trigger the functionality to update the progress bar based on our current finishedUploadCount versus
                // totalDocsToUpload
                var currentProgress = (((finishedUploadCount) / totalDocsToUpload) * 100).toFixed(0);
                self.updateProgressBar(currentProgress, self);
            },

            /**
             * Updates the progress bar
             *
             * @param {number} currentProgress - The determined value that the progress bar should be set to
             * @param {Object} self - The context of this function.
             */
            updateProgressBar: function(currentProgress, self) {
                // Trigger the functionality to update the progress bar
                app[self.options.handler].trigger("showProgress");
                app[self.options.handler].trigger("showInfo", window.localize("modules.actions.bulkUpload.uploadingDocuments"));
                app[self.options.handler].trigger("updateProgress", currentProgress);
            },

            /**
             * Hides the progress bar and triggers bulkupload:doneUploading
             *
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             * @param {Object} self - The context of this function.
             */
            hideProgressBarAndTriggerDoneUploading: function(successList, errorList, self) {
                // Trigger the functionality to update the progress bar
                app[self.options.handler].trigger("hideProgress");
                app[self.options.handler].trigger("hideInfo");
                app.trigger("bulkupload:doneUploading", successList, errorList);
            },

            /**
             * Uploads a provided file.
             * @param {Object} file - The file to upload.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             * @returns {Object} - A deferred promise object that is resolved when the ajax request for uploading the file
             * is completed.
             */
            upload: function (file, successList, errorList) {
                var self = this;

                // the deferred to return when the ajax request for uploading this file is completed
                var deferred = $.Deferred();

                // this is the index of the document in the oco collection when we upload it (so we can pull off its
                // properties when the xhr resolves)
                var currentDocIndex = self.uploadIndex;

                // add our action params to the file we're going to upload, the addActionParamsToFile function returns a deferred
                // and resolves it since it may make an ajax call
                var doneAddingActionParams = this.addActionParamsToFile(file);

                // wait til we're done adding our action params to the file
                $.when(doneAddingActionParams).done(function () {
                    // if this is the "Add Emails" action, then we're probably on IE9 and want to do a content less upload
                    // since we already created a temporary repository object for the MSG file we're uploading
                    if (self.configurationAttributes.addEmail) {
                        self._doContentLessUpload(file, currentDocIndex, deferred, successList, errorList);
                    } else { // this is the add documents action
                        // do our normal XHR upload
                        self._doXHRUpload(file, currentDocIndex, deferred, successList, errorList);
                    }
                });

                // return our promise object so the calling function can wait til we've resolved
                return deferred.promise();
            },

            // adds the action parameters to the file object (that will get sent to OC eventually) and returns a deferred
            // since if you have dropOffScan functionality enabled, we may have to make an async call to grab the attributes
            // of the selected file's objectType so we can add the required parameters to the action parameters
            addActionParamsToFile: function (file) {
                var self = this;

                // we're going to return a deferred from this function because it's possible we'll have to make an async
                // call to grab some attributes
                var addActionParamsDeferred = $.Deferred();

                // add our formData object to the file - we'll attach the stringified action below in the appropriate place
                file.formData = {
                    // helper function to set our stringified action on the file formData
                    setActionAndResolve: function (action) {
                        // stringify our action and set it on this object
                        this.action = JSON.stringify(action);

                        // resolve our deferred
                        addActionParamsDeferred.resolve();
                    }
                };

                // paginate along with the incoming files to match oco with file
                var oco = self.collection.at(self.uploadIndex);

                // add prop- to each key as that's the way OC expects the properties
                var prefixedProps = app.context.util.prefixProperties(oco.get("properties"));

                // check if we are in header mode
                var getContainerId = $.Deferred();

                // if no container path is configured, we're using the context verion of bulkupload
                if (!self.configurationAttributes.containerPath) {
                    getContainerId.resolve(app.context.container.get("objectId"));
                } else { // otherwise, fetch the id of the configured path and proceed as normal
                    self.containerPathHolder = self.configurationAttributes.containerPath;
                    //hold on to the default containe in case we dont have a custom path
                    if (self.options.customTypePaths) {
                        _.each(_.keys(self.options.customTypePaths[self.options.form]), function (typeKey) {
                            if (oco.get("objectType") === typeKey) {
                                self.containerPathHolder = self.options.customTypePaths[self.options.form][typeKey];
                            }
                        });
                    }
                    $.ajax({
                        url: app.serviceUrlRoot + "/content/getIdByPath?path=" + encodeURIComponent(self.containerPathHolder),
                        success: function (containerId) {
                            //folderContainerId = containerId;
                            getContainerId.resolve(containerId);
                        },
                        global: false
                    });
                }


                getContainerId.done(function (resolvedContainerId) {

                    var hideFileExtensions = self.options.hideFileExtensions;
                    if (!hideFileExtensions && self.options.options) {
                        hideFileExtensions = self.options.options.hideFileExtensions;
                    }

                    var processRequiredDocs = self.options.processRequiredDocs;
                    // create our action bulkupload model and put on our objectId (of the parent folder), the selected objectType
                    // of the document being uploaded, and the properties (each prefixed with "prop-")
                    var action = new Backbone.Model({
                        name: 'bulkUpload',
                        parameters: {
                            // this assumes this action is configured as a folder action
                            objectId: resolvedContainerId,
                            objectType: oco.get('objectType'),
                            hideFileExtensions: hideFileExtensions,
                            processRequiredDocs: processRequiredDocs,
                            properties: prefixedProps,
                            existingRepoId: file.existingRepoId,
                            tempGroupId: self.getTemporaryGroupId(),
                            numberOfFilesInUpload: self.fileNames.length,
                            isPrintToRepo : file.isPrintToRepo
                        }
                    });

                    //if we are setting a new version on an existing doc, pass that info back
                    //to OC on the action
                    if (oco.get('selectedDocument')) {
                        action.get("parameters").selectedDocument = oco.get('selectedDocument');
                    }

                    action.get("parameters").createPdfRendition = self.configurationAttributes.createPdfRendition;

                    // if this file is a cover page then we need to add the barcode attribute and any custom attributes to
                    // display on the generated PDF (or default to the required attributes)
                    if (file.coverPage) {
                        // add the configured attribute to use for the barcode to the action parameters
                        action.get("parameters").barcodeAttribute = self.configurationAttributes.dropOffScanningAttribute;

                        // add the title that should go at the top of the generated cover page PDF
                        action.get("parameters").coverPageTitle = self.configurationAttributes.coverPageTitle;

                        // grab the custom attributes to display on the generated PDF for this object type, will be undefined
                        // if the user does not have any attributes configured for this object type
                        var typeAttributes = self.configurationAttributes.typeAttributes[oco.get('objectType')];

                        //grab the formName that the action is using
                        var formName = self.configurationAttributes.form;

                        // if the user has it configured to NOT allow custom attributes on the generated PDF OR there is no list
                        // of custom attributes for this objectType, then we'll need to fetch the required attributes for this
                        // objectType
                        if (self.configurationAttributes.customAttrsOnCoverPage === "false" || !typeAttributes) {
                            // fetch the type config for this object type
                            app.context.configService.getFormTypeConfig(formName, oco.get('objectType'), function (typeConfig) {
                                // filter out any non-required attributes, and then get only the ocName
                                //using map
                                var requiredAttrs = typeConfig.get("configuredAttrsPri").filter(function (attr) {
                                    return attr.get("required");
                                }).map(function (attr) {
                                    return attr.get("ocName");
                                });

                                // add the list of attributes to display on the generated PDF by mapping to only have a list
                                // containing each attribute's label and ocName (so we can grab the value of the property in OC)
                                app.context.configService.getLabels(oco.get('objectType'), requiredAttrs).done(function (labels) {
                                    action.get("parameters").coverPageAttributes = labels;

                                    // set our action data resolve our deferred object since we're done doing our async call
                                    file.formData.setActionAndResolve(action);
                                });
                            });
                        } else { // the user is allowing custom attributes and we have attributes configured for this objectType
                            // add the list of attributes to display on the generated PDF by mapping to only have a list
                            // containing each attribute's label and ocName (so we can grab the value of the property in OC)
                            action.get("parameters").coverPageAttributes = _.map(typeAttributes, function (attr) {
                                return {
                                    label: attr.label,
                                    ocName: attr.ocName
                                };
                            });

                            // set our action data and resolve our deferred object since we're done
                            // processing for this file (no async call was required in this case)
                            file.formData.setActionAndResolve(action);
                        }
                    } else if (file.email) { // the file we're dealing with is an email
                        // get the related attachments to this email
                        var emailAttachments = self.getRelatedEmailAttachments(file.emailId);

                        self.setupCommonFileParameters(action, file, emailAttachments, "tempEmailObjectId", "createEmail", "emailRelationType", "emailAttachmentProperties", self.configurationAttributes["emailRelationType"]);

                        // check to see if it is a gmail upload
                        if (file.id) {
                            action.get("parameters").gmailId = file.id;
                            action.get("parameters").gmailUser = app.user.get("emailAddress");
                        }
                        if (self.gmailAuthToken) {
                            action.get("parameters").gmailAuthToken = self.gmailAuthToken;
                        }

                        // we're done so set our action data and resolve our deferred object
                        file.formData.setActionAndResolve(action);
                    } else if (file.zip) { // the file we're dealing with is a zip
                        // get the related attachments to this email
                        var zipAttachments = self.getRelatedZipAttachments(file.zipId);

                        self.setupCommonFileParameters(action, file, zipAttachments, "tempZipObjectId", "createZip", "zipRelationType", "zipAttachmentProperties", self.configurationAttributes["zipRelationType"]);

                        // we're done so set our action data and resolve our deferred object
                        file.formData.setActionAndResolve(action);

                    } else if (file.cloudLinkDoc || file.cloudDoc) {

                        action.get("parameters").downloadUrl = file.downloadUrl;
                        action.get("parameters").name = file.name;
                        action.get("parameters").authToken = file.authToken;
                        action.get("parameters").mimeType = file.mimeType;
                        if (file.byteArray) {
                            action.get("parameters").byteArray = file.byteArray;
                        }
                        file.formData.setActionAndResolve(action);
                    } else { // this is not a cover page file
                        // resolve our deferred object since we're done processing for this file (no async call was required in this case)
                        file.formData.setActionAndResolve(action);
                    }
                });

                // return the promise object for our deferred so the calling function can wait til we've resolved
                return addActionParamsDeferred.promise();
            },

            /**
             * set all the common ZIP/MSG parameters onto the action parameters
             * @param {Action} action - action bulkupload model
             * @param {Object} file - ZIP or MSG file object 
             * @param {*} attachments - (emailAttachments or zipAttachments) related attachments from the MSG/ZIP file 
             * @param {String} tempFileObjectId  - (tempEmailObjectId or tempZipObjectId) If we had a temporary email/zip object that we used to get the content, this is the objectId of that temporary repository email/zip object.
             * @param {String} createFile - (createEmail or createZip) True if we're actually creating the email/ZIP object, false otherwise. This could be false if the user only wanted to create
	         * 		                        the attachment objects and not the email/ZIP file itself.
             * @param {String} fileRelationType - (emailRelationType or zipRelationType) parameter on the actionId to set the fileRelation to on the action
             * @param {String} fileAttachmentProperties (emailAttachmentProperties or zipAttachmentProperties) A map of properties for the email attachments we're going to parse and create, keyed by the name of the attachment.
             * @param {String} fileRelation - (hpi:emailed or hpi:related) how the file is related to it's parent file
             */
            setupCommonFileParameters: function(action, file, attachments, tempFileObjectId, createFile, fileRelationType, fileAttachmentProperties, fileRelation){

                var tempGroup = action.get("parameters").tempGroupId;
                // if we're on IE9 using the HTML5 viewer for parsing file messages, the we'll have created
                // a temporary repository object with our File content - this parameter represents the objectId
                // of that temporary object so we can parse that content when we're ready to create the documents
                action.get("parameters")[tempFileObjectId] = file[tempFileObjectId];
                // indicate whether or not we want OC to actually create the email object or not (if they're
                // only uploading the attachments, this createEmail/createZip variable will be false)
                action.get("parameters")[createFile] = file[createFile];
                // attach the attachments' properties to the File object
                action.get("parameters")[fileAttachmentProperties] = this.buildUpAttachmentProperties(attachments, tempGroup);
                // indicate the relation type we'll create between the email/zip and the attachments (hpi:emailed (hpi_emailed) or hpi:related (hpi_related))
                action.get("parameters")[fileRelationType] = fileRelation;
            },

            buildUpAttachmentProperties: function(attachments, tempGroup) {
                // we're going to build up a map of properties the user entered for each attachment related to this
                // it is keyed by the filename of the attachment (NOT the objectName because that can change)
                var attachmentProperties = {};

                _.each(attachments, function (attachment) {
                    // get the OCO for this email attachment from our collection
                    var attachmentFile = this.collection.at(attachment.idx);

                    // prefix each property for this attachment the same way we do for normal files
                    // add the prefixed properties to the attachments map, keyed by file name
                    attachmentProperties[attachment.name] =  app.context.util.prefixProperties(attachmentFile.get("properties"));
                    // we additionally need to set the object type on this attachment so we know what type to create in OC
                    attachmentProperties[attachment.name].objectType = attachmentFile.get("objectType");

                    //if this is a gmail attachment we want to add the gmail attachment id.
                    attachmentProperties[attachment.name].gmailAttachmentId = attachment.attachmentId;

                    attachmentProperties[attachment.name].tempGroup = tempGroup;

                    if (attachmentFile.get("selectedDocument")) {
                        attachmentProperties[attachment.name].selectedDocument = attachmentFile.get("selectedDocument");
                    }
                },this);

                return attachmentProperties;
            },

            /**
             * Will set the group ID for the view. If there is no group ID already set, then a new one will
             * be set on the view.
             * @returns {String} groupId - a group ID that is randomly generated.
             */
            getTemporaryGroupId: function() {
                if(!this.tempGroupId){
                    // Format is #### #### - #### - #### - #### - #### #### #### (spaces to see more easily).
                    var generatedGroupId = this.getRandomString() + this.getRandomString() + '-' + 
                    this.getRandomString() + '-' + this.getRandomString() + '-' + this.getRandomString() 
                    + '-' + this.getRandomString() + this.getRandomString() + this.getRandomString();
    
                    this.tempGroupId = generatedGroupId;                
                    return generatedGroupId;
                } else {
					return this.tempGroupId;
				}
            },

            /**
             * Generates a random String to make a group ID (guid essentially). There
             * is no built in functionality for generating a guid, so this is the 
             * best way to do it without having to import a library for one line.
             * @returns {String} - a string of 4 randomly generated characters and/or numbers.
             */
            getRandomString: function() {
                return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
            },

            //removes the Bulk Upload properties view after finish upload is pressed
            removePropertiesView: function () {
                $('#bulk-upload-footer').addClass('hide');
                $('#properties-section').empty();
                $('#uploadFileControls').empty();
                $('#bulk-upload-uploader-output').empty();
                $('#oa-indexing-frame').remove();
            },

            /**
             * Performs an XHR upload for a passed in file. This method of uploading is not supported in IE<10.
             * @param {Object} file - The file to upload.
             * @param {number} currrentDocIndex - The index of the file we're uploading in our OCO collection so when
             * we're done uploading the file we can access its properties.
             * @param {Object} deferred - A deferred object to resolve when we're finished with the document upload.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             */
            _doXHRUpload: function (file, currentDocIndex, deferred, successList, errorList) {
                var self = this;

                var xhr = new XMLHttpRequest();

                // keep track of progress, written to console for now
                xhr.upload.addEventListener("progress", function (e) {
                    if (e.lengthComputable) {
                        var percentage = Math.round((e.loaded * 100) / e.total);
                        app.log.debug(percentage);
                    }
                }, false);

                xhr.upload.addEventListener("load", function () { }, false);

                xhr.open("POST", app.serviceUrlRoot + '/action/executeWithAttachment');
                xhr.onreadystatechange = function () {
                    // doc is finished upload, get response
                    if (xhr.readyState === 4) {
                        // get the filename to display in the success or error list (the objectName the user entered)
                        var filename = self._getOcoObjectName(currentDocIndex, file.name);

                        var attachments = self.getRelatedContainerAttachments([], file);

                        // for some reason, OC is returning a 202: Accepted
                        if (xhr.status >= 200 && xhr.status <= 202) {
                            // do our success funcitonality
                            self._uploadSuccess(xhr.response, file, filename, attachments, successList);
                        } else {
                            // there was an error
                            self._uploadFailure(xhr.response, file, filename, attachments, errorList);
                        }

                        // we're done with our ajax request for this file so resolve our deferred
                        deferred.resolve();
                    }
                };

                // build up our form data object to send with our XHR
                var fd = new FormData();

                // if this isn't a cover page and is not an email attachment AND is not a cloud link, we actually
                // have a real file to send with the request so let's add it
                if (!file.coverPage && !file.emailAttachment && !file.cloudLinkDoc && !file.cloudDoc) {
                    // firefox needs fd.append to take a Blob as the second argument
                    // so for template document creation, a Blob is given
                    if (file.attributes) {
                        var b = new Blob();
                        fd.append('parts', b, file.name);
                    } else {
                        fd.append('parts', file, file.name);
                    }
                }

                // add the action parameters we built up
                fd.append('action', file.formData.action);

                // send our request
                xhr.send(fd);
            },

            getRelatedContainerAttachments: function(attachments, file){
                if (file.email) {
                    // get the email attachments that are related to this email we just uploaded
                    attachments = this.getRelatedEmailAttachments(file.emailId);
                } else if (file.zip) {
                    attachments = this.getRelatedZipAttachments(file.zipId);
                }
                return attachments;
            },

            /**
             * Performs an AJAX call that represents a content less upload for the passed in file. This will get called
             * when we're using the "Add Emails" action that allows us to use the HTML5 viewer on IE9 for parsing
             * MSG files. In this case, we'll have already uploaded the MSG content and created a temporary repository
             * object for it (since we can't upload the file twice in IE9 without making the user re-select the file - the
             * first time we uploaded it was to parse it for attachments).
             * @param {Object} file - The file to upload.
             * @param {number} currrentDocIndex - The index of the file we're uploading in our OCO collection so when
             * we're done uploading the file we can access its properties.
             * @param {Object} deferred - A deferred object to resolve when we're finished with the document upload.
             * @param {Array} successList - The array to add to if this file uploads successfully.
             * @param {Array} errorList - The array to add to if this file fails to upload.
             */
            _doContentLessUpload: function (file, currentDocIndex, deferred, successList, errorList) {
                var self = this;

                // get the filename to display in the success or error list (the objectName the user entered)
                var filename = self._getOcoObjectName(currentDocIndex, file.name);

                var emailAttachments = [];
                if (file.email) {
                    // get the email attachments that are related to this email we just uploaded
                    emailAttachments = self.getRelatedEmailAttachments(file.emailId);
                }

                // make our AJAX request to execute our Bulk Upload action with a string response (for IE9 comptability)
                $.ajax({
                    url: app.serviceUrlRoot + '/action/executeWithStringResponse',
                    method: 'GET',
                    data: {
                        // pass the action and params we built up previously
                        action: file.formData.action
                    },
                    success: function (response) {
                        self._uploadSuccess(response, file, filename, emailAttachments, successList);
                    },
                    error: function (jqXHR) {
                        self._uploadFailure(jqXHR.response, file, filename, emailAttachments, errorList);
                    }
                }).always(function () {
                    // we're done with our ajax request for this file so resolve our deferred
                    deferred.resolve();
                });
            },

            /**
             * Called when a successful file upload is completed. This constructs our object to put into the success list
             * so we can display the successful upload message to the user.
             * @param {String} xhrResponse - The response from our upload that we'll parse into an object.
             * @param {Object} file - The file we uploaded successfully.
             * @param {String} filename - The filename of the file we uploaded.
             * @param {Array} emailAttachments - An array of email attachments that were also created with this file
             * upload.
             * @param {Array} successList - The array to add to for our successful upload.
             */
            _uploadSuccess: function (xhrResponse, file, filename, emailAttachments, successList) {
                var self = this;

                // parse the response of the ajax call into a JSON object so we can pull of the
                // result objectId of the new document we just uploaded
                var response = app.context.util.parseIEJSON(xhrResponse);

                // the result of our add document call is a map of filenames to repository objectIds
                var filenamesToObjectIds = response.result;

                // get the objectId of the newly created document
                var objectId = filenamesToObjectIds[filename];
                // if there is no object id it could be because of the file extention
                if (!objectId) {
                    for (var key in filenamesToObjectIds) {
                        if (self.removeFileExt(key) === filename) {
                            objectId = filenamesToObjectIds[key];
                            break;
                        }
                    }
                }

                // check if we've got a cover page
                if (file.coverPage) {
                    // the map that comes back has the "PDF" extension on our cover page but our filename won't
                    // since we don't add the extension to a cover page in our display file name
                    objectId = filenamesToObjectIds[filename + ".pdf"];
                }

                // construct our stage URL so the user can click a link we display to them in our success view
                // and it will show them the document they clicked on in the stage
                var stageUrl = this._getUploadedDocumentStageUrl(objectId);

                // Get the property based off of the attribute we want to show 
                var property = "prop-" + self.options.attrToShow;
                var attrToShow = response.parameters.properties[property];

                // we only want to add our file to the success list this if either this file is not an email or it is an
                // email and we actually created the email (it's possible we didn't if they chose to remove the email
                // but upload the attachments)
                if ((!file.email && !file.zip) || (file.email && file.createEmail) || (file.zip && file.createZip)) {
                    successList.push({
                        // want the objectId so that if the user only uploaded one file we can refresh the stage
                        // with that file ID when they close this action
                        objectId: objectId,
                        // want the filename of the uploaded doc for display purposes
                        filename: filename,
                        // cover page flag so that we can open separate tabs with each cover page generated on success
                        coverPage: file.coverPage,
                        // URL to the stage so the user can click on the document uploaded to view it in the stage
                        url: stageUrl,
                        // Attribute of the uploaded document that will be displayed to the user 
                        attrToShow: attrToShow,
                        // mimetype of the uploaded file
                        type: file.type,
                        // content size of the uploaded file
                        size: file.size
                    });
                }

                // loop over the emailAttachments for this email and add each one to the success list
                _.each(emailAttachments, function (emailAttachment) {
                    // get the name of our attachment file
                    var attachmentFilename = self._getOcoObjectName(emailAttachment.idx, emailAttachment.name);

                    // get the objectId of the newly created email attachment
                    var attachmentObjectId = filenamesToObjectIds[attachmentFilename];
                    // if there is no object id it could be because of the file extention
                    if (!attachmentObjectId) {
                        for (var key in filenamesToObjectIds) {
                            if (self.removeFileExt(key) === attachmentFilename) {
                                attachmentObjectId = filenamesToObjectIds[key];
                                break;
                            }
                        }
                    }

                    // construct the URL to the stage for our attachment
                    var attachmentStageUrl = self._getUploadedDocumentStageUrl(attachmentObjectId);

                    // build our successfulAttachment object
                    var successfulAttachment = {
                        // want the objectId so that if the user only uploaded one file we can refresh the stage
                        // with that file ID when they close this action
                        objectId: attachmentObjectId,
                        // want the filename of the uploaded doc for display purposes
                        filename: attachmentFilename,
                        // cover page flag so that we can open separate tabs with each cover page generated on success
                        coverPage: false,
                        // URL to the stage so the user can click on the document uploaded to view it in the stage
                        url: attachmentStageUrl,
                        // unable to get size of email attachments at this time
                        type: "emailAttachment",
                        size: 0
                    };

                    // push on the successfulAttachment object onto our successList
                    successList.push(successfulAttachment);
                });
            },

            /**
             * Called when a file fails to upload. This constructs our object to put into the error list so we can
             * display the error message to the user.
             * @param {Object} file - The file we failed to upload.
             * @param {String} filename - The filename of the file we failed to upload.
             * @param {Array} emailAttachments - An array of email attachments that also failed to upload.
             * @param {Array} errorList - The array to add to for our failed upload.
             */
            _uploadFailure: function (response, file, filename, emailAttachments, errorList) {
                var self = this;

                // push an object on our error list with the name of the failed uploaded file (for display) - we only want
                // to do this if either this file is not an email or it is an email and we actually tried to
                // create the email (it's possible we didn't if they chose to remove the email but upload the attachments)
                if (!file.email || (file.email && file.createEmail)) {
                    errorList.push({
                        name: filename,
                        error: response
                    });
                }

                // loop over the emailAttachments for this email and add each one to the error list
                _.each(emailAttachments, function (emailAttachment) {
                    // push on the file name of each attachment onto the error list
                    errorList.push({
                        name: self._getOcoObjectName(emailAttachment.idx, file.name),
                        error: response
                    });
                });
            },

            getFileNames: function () {
                return this.fileNames;
            },

            // helper method to get an array of file names with either the extensions removed or not touched - the user may have
            // the action configured to hide file extensions
            getDisplayFileNames: function () {
                var self = this;

                // start with an empty array - we need to remove the file extension if the user configured the action to hide them
                var displayFileNames = [];

                // loop over each file and remove the extension if it's configured to do so
                _.each(this.fileNames, function (fileName) {
                    if (self.options.hideFileExtensions === "true" || (self.options.options && self.options.options.hideFileExtensions === "true")) {
                        // the file names array always has the full file name with the extension so if they don't want to display extensions
                        // we have to strip it off first before adding it to the array to return
                        displayFileNames.push(self.removeFileExt(fileName));
                    } else { // we're not removing any extensions so just push on the normal file name with the extension
                        displayFileNames.push(fileName);
                    }
                });

                return displayFileNames;
            },

            // if we are creating documents from an existing object we need to have access to these ocos in the controls
            getOcos: function () {
                if (this.files && this.files.length > 0 && this.files[0].isAddingFromExistingContent) {
                    return this.files;
                } else {
                    return null;
                }
            },

            // sets the gmail authentication token
            setGmailAuthToken: function (token) {
                this.gmailAuthToken = token;
            },

            // the checked file names are the MSG file names we've already processed for attachments
            getCheckedFileNames: function () {
                return this.checkedFileNames;
            },

            /**
             * Adds an MSG/ZIP file that we've proccessed for attachments to the array of ones we've already checked.
             * @param {String} filename - The filename of the MSG/ZIP file to add to the list of MSG/ZIP files we've already
             * parsed.
             */
            addCheckedFileName: function (filename) {
                this.checkedFileNames.push(filename);
            },

            /**
             * Gets email attachments related to the passed in email.
             * @param {number} emailId - The ID number of the email to fetch attachments for.
             * @returns {Array} - An array of email attachment files that are related to the emailId passed in.
             */
            getRelatedEmailAttachments: function (emailId) {
                var possibleEmailAttachments = this.getPossibleAttachments();

                // filter our possibleEmailAttachments and return the actual email attachments for the specified email
                return _.filter(possibleEmailAttachments, function (possibleEmailAttachment) {
                    // if this file is an email attachment and has the emailId we're looking for, this is a related attachment
                    return possibleEmailAttachment.emailAttachment && possibleEmailAttachment.emailId === emailId;
                });
            },
            /**
             * Gets zip attachments related to the passed in zip.
             * @param {number} zipId - The ID number of the zip to fetch attachments for.
             * @returns {Array} - An array of zip attachment files that are related to the zipId passed in.
             */
            getRelatedZipAttachments: function (zipId) {
                var possibleZipAttachments = this.getPossibleAttachments();
                // filter our possibleZipAttachments and return the actual zip attachments for the specified zip
                return _.filter(possibleZipAttachments, function (possibleZipAttachment) {
                    // if this file is an zip attachment and has the zipId we're looking for, this is a related attachment
                    return possibleZipAttachment.zipAttachment && possibleZipAttachment.zipId === zipId;
                });
            },
            
            /**
             * pulls the important data from the possible attachments being uploaded
             */
            getPossibleAttachments: function() {
                // we want to add the index to each attachment so we can grab the right properties from the OCO
                // collection
                var idx = 0;

                // map each of the files the user has chosen to upload
                var possibleAttachments = _.map(this.getDocs(), function (possibleAttachment) {
                    return {
                        // add the name
                        name: possibleAttachment.name,
                        // add the index of the file
                        idx: idx++,
                        // add whether or not this is an email attachment (will be undefined if this isn't an attachment)
                        emailAttachment: possibleAttachment.emailAttachment,
                        // add what email this attachment is related to (will be undefined if this isn't an attachment)
                        emailId: possibleAttachment.emailId,
                        // add whether or not this is a zip attachment (will be undefined if it isn't)
                        zipAttachment: possibleAttachment.zipAttachment,
                        // add what zip this attachment is related to (will be undefined if it isn't an attachment)
                        zipId: possibleAttachment.zipId,
                        // if there is a gmail attachmentId we want to add it here
                        attachmentId: possibleAttachment.attachmentId
                    };
                });
                return possibleAttachments;
            },

            /**
             * Gets the objectName of a specified index in the OCO collection. This will strip off file
             * extensions if so configured.
             * @param {number} ocoIndex - The index of the object in the OCO collection to get the objectName for.
             * @param {String} nameOfFile - A default file name to use if none is found in the OCO collection for
             * the index specified.
             * @returns {String} - The file name of the requested object in the OCO collection.
             */
            _getOcoObjectName: function (ocoIndex, nameOfFile) {
                // this is only relevant if we have a collection to check against
                if (this.collection) {
                    // get the object name of the file we just uploaded
                    var filename = this.collection.at(ocoIndex).get("properties").objectName;
                    if (!filename) {
                        filename = nameOfFile;
                    }

                    // remove the file extension if they have it configured to hide file extensions
                    if (this.options.hideFileExtensions === "true" || (this.options.options && this.options.options.hideFileExtensions === "true")) {
                        filename = this.removeFileExt(filename);
                    }


                    return filename;
                }
            },

            /**
             * Constructs and returns a URL that leads to the stage for the provided objectId.
             * @param {String} objectId - The objectId to use to construct the link to the Stage for.
             * @returns {String} - A string representing the URL to the stage for the provided filename.
             */
            _getUploadedDocumentStageUrl: function (objectId) {
                // the URL to the stage for the document we're clicking on
                var documentStageUrl = "";

                if (this.options.addEmail || (this.options.options && this.options.options.addEmail)) {
                    if (this.configurationAttributes.enableDocumentLinkTracResolving === "true") {
                        documentStageUrl = app.root + "#Stage/" + this.configurationAttributes.documentLinkTracResolving + "/|" + objectId;
                    } else if (this.configurationAttributes.containerPath) {
                        documentStageUrl = app.root + "#StageSimple/" + objectId;
                    } else {
                        documentStageUrl = app.root + "#Stage/" + app.context.configName() + "/|" + objectId;
                    }
                } else {
                    if (this.configurationAttributes.enableDocumentLinkTracResolving === "true") {
                        documentStageUrl = app.root + "Stage/" + this.configurationAttributes.documentLinkTracResolving + "/|" + objectId;
                    } else if (this.configurationAttributes.containerPath) {
                        documentStageUrl = app.root + "StageSimple/" + objectId;
                    } else {
                        documentStageUrl = app.root + "Stage/" + app.context.configName() + "/|" + objectId;
                    }
                }

                return documentStageUrl;
            },

            /**
             * Removes the file extension from the passed in filename. If there is no file extension on the passed in
             * filename, the passed in filename is returned unchanged.
             * @param {String} filename - The filename to remove the file extension from.
             * @returns {String} - A string representing the passed in file name without its file extension.
             */
            removeFileExt: function (filename) {
                var fileNameNoExt = filename.substr(0, filename.lastIndexOf('.'));
                // if there's no file extension (ie when creating a cover page) then this will come back as a blank string
                // in that case there's no file extension to remove, so just return the original name
                if (fileNameNoExt) {
                    return fileNameNoExt;
                } else {
                    return filename;
                }
            },

            evaluateThumbnails: function () {
                var self = this;

                if (self.hasImages === true) {
                    // Adjust the height of the fileupload-list & other containers if there are images.
                    $("div#bulkUpload-fileNames").addClass("image-filenames");
                    // Add in the loaded images, currently nothing extra is done here to makes sure
                    // they play nice with the spacing of the labels.
                    _.each(self.files, function (file, index) {
                        var offset = index + 1;
                        //If we have an image, load it into its corresponding image-tracker.
                        var fileExtension = file.name.split('.').pop().toLowerCase();
                        if (fileExtension === "jpg" || fileExtension === "jpeg" || fileExtension === "png" || fileExtension === "gif") {
                            if (file) {
                                var reader = new FileReader();

                                reader.onload = function (e) {
                                    $("#bulkupload-image-tracker-" + offset).attr('src', e.target.result);
                                };
                                reader.readAsDataURL(file);
                            }
                        }
                        //For non-image panes we need to adjust the height of the empty image div so that
                        // the labels for non-images line up with the image label.
                        else {
                            $("#bulkupload-image-tracker-" + offset).removeClass("disabledImage").addClass("unusedImage");
                        }
                        if (offset === self.currentIndex) {
                            $("#bulkupload-tracker-" + offset).removeClass("current-arrow").addClass("current-image-arrow");
                        }
                    }, this);

                    $(".uploadLabel").addClass("img-upload-label");
                    self.imagesLoaded = true;
                } else {
                    // Remove the height attribute of the containers incase it was previously set due to
                    //  images being part of the upload.
                    $("div#bulkUpload-fileNames").removeClass("image-filenames");
                    $(".image-wrapper").addClass("unused-image-wrapper");
                    $("div.current-image-arrow").removeClass("current-image-arrow").addClass("current-arrow");
                }
            },

            // helper function to determine if a file is an MSG file based on its file name
            isMSGFile: function (filename) {
                // if the substring after the last period in the file name is "msg", we'll assume it's an MSG file
                return filename.substr(filename.lastIndexOf('.') + 1).toLowerCase() === "msg";
            },
            // helper function to determine if a file is an ZIP file based on its file name
            isZIPFile: function(filename) {
                return filename.substr(filename.lastIndexOf('.') + 1).toLowerCase() === BulkUpload.CONSTANTS.ZIP;
            },

            // set to true when a user hits 'Next' and stops selecting files
            filesAccepted: function (newVal) {
                this.hasAccepted = newVal;
                this.render();
            },

            // updates the indexerFileDocIds array with the fileId in the order the files were uploaded for indexer mode
            _updateId: function (index, newDocId) {
                if (newDocId.length < 1 || this.files[index].objectId) {
                    this.indexerFileDocIds[index] = this.files[index].objectId;
                } else {
                    this.indexerFileDocIds[index] = newDocId;
                }
                this._deleteUnusedTemp(index, newDocId);

                app.trigger("retrievedDocIds", this.indexerFileDocIds);
                //needed to know if a document has been uploaded
                return index;
            },

            _deleteUnusedTemp: function(index, newDocId){
                if(newDocId.length > 1 && this.files[index].objectId && newDocId !== this.files[index].objectId){
                    var tempData = {
                    objectId: newDocId,
                    allVersions: true
                    };
                    $.ajax({
                        url: app.serviceUrlRoot + "/content/deleteObjects",
                        type: "POST",
                        data: tempData,
                        global: false,
                        success: function() {
                            app.log.debug("Document deleted successfully");
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            app.log.debug((window.localize("modules.actions.bulkUpload.errorDeleting")) + errorThrown);
                        }
                    });
                }

            },

            // this is where we make our initial document upload when we are in indexing mode.  We get the documentId returned and that Id is used to show the document in our iFrame.
            fileIndexingEnabled: function () {
                var self = this;

                this.hasIndexing = true;
                var docIndex = 0;
                this.filesUploaded = [];

                /** Array of Object IDs of the files uploaded */
                this.idsOfUploadedFiles = [];


                _.each(self.files, function (file) {
                    var docName = file.name;
                    if (self.sterilizeAttributes.shouldSterilizeFilenames === 'true') {
                        docName = tsgUtils.sterilizeFilename(file.name, self.sterilizeAttributes);
                    }
                    
                    var docExten = docName.split(".").pop().toLowerCase();

                    //adding if to catch files that aren't actually being uploaded
                    //files shown by the indexer and uploaded via print to repoistory mode will already exist in the repository
                    if(!(file instanceof Blob)){
                        self.idsOfUploadedFiles.push(file.attributes.objectId);
                        self.filesUploaded.push(self.idsOfUploadedFiles.length-1);
						// these triggers will show the document in the indexer
                        app.trigger("retrievedDocIds", self.idsOfUploadedFiles);
                        app.trigger("deleteIframeSpinner", self.filesUploaded);
                    }else{
                        if(_.contains(this.options.extenWhiteList, docExten)){
                            var fd = new FormData();
                            // this is pointing to a dumpfolder in HPI that stores all of the initial upload documents separate from where the file will actually be saved
                            fd.append('parentId', this.options.indexingFileDumpFolder);
                            fd.append('objectType', 'Indexer Temp Document');
                            fd.append('properties', {
                                "prop-name": "temp"
                            });
                            // when making the filename, we added a timestamp in milliseconds and an index to ensure uniqueness within the batch and
                            // across upload sessions 
                            fd.append('parts', file, Date.now() + "-" + docIndex +  "-" + file.name);
                            // push a blank objext to the indexerFileDocIds array so we can add documents in order based on index
                            self.indexerFileDocIds.push("");
                            // becasue we are using an ajax call, we can't guarantee the order that we will get the docIds back, so we use _.partial so we can tie an index to each ajax call.
                            var partializedUpdateId = _.partial(self._updateId, docIndex);
                            
        
                            $.ajax({
                                method: "POST",
                                data: fd,
                                contentType: false,
                                processData: false,
                                url: app.serviceUrlRoot + "/content/upload",
                                global: false,
                                success: function (newDocId) {
                                    //returns index of uploaded doc and puts it on a list of all docIndexes to be 
                                    //passed to the listener that refreshes the iframe/hpiSpinner
                                    var uploadedDocIndex = partializedUpdateId.call(self, newDocId);
                                    self.filesUploaded.push(uploadedDocIndex);
                                    // triggers iframe spinner deletion and triggers oaiframe loading
                                    app.trigger("deleteIframeSpinner", self.filesUploaded);
                                }
                            });
                        } 
                        docIndex++;
                    }
                    
                }, this);

                this.listenTo(app[this.options.handler], "hide", function () {
                    self.deleteIndexedObjects();
                });

                this.listenTo(app, 'bulkupload:doneUploading', function () {
                    self.deleteIndexedObjects();
                });

            },

            deleteIndexedObjects: function () {
                var self = this;
                // if in indexing mode remove all the documents from the indexer dump folder
                if (self.indexerFileDocIds && self.indexerFileDocIds.length > 0) {
                    // Delete each one with a separate Ajax call
                    _.each(self.indexerFileDocIds, function (objectId) {
                        if( objectId )
                        {
                            var tempData = {
                                objectId: objectId,
                                allVersions: true
                            };
                            $.ajax({
                                url: app.serviceUrlRoot + "/content/deleteObjects",
                                type: "POST",
                                data: tempData,
                                global: false,
                                success: function () {
                                    self.indexerFileDocIds = [];
                                },
                                error: function (jqXHR, textStatus, errorThrown) {
                                    app.log.debug((window.localize("modules.actions.bulkUpload.errorDeleting")) + errorThrown);
                                }
                            });
                        }
                    });
                    self.indexerFileDocIds = [];
                }
            },

            serialize: function () {
                var tempFileList = [];
                _.each(this.getDisplayFileNames(), function (fileName) {
                    if (_.contains(uploadSizeErrorList, fileName)) {
                        tempFileList.push({
                            name: fileName,
                            hasError: true
                        });
                    } else {
                        tempFileList.push({
                            name: fileName,
                            hasError: false
                        });
                    }
                });
                return {
                    // true if we're in the "Add Emails" action, false otherwise
                    addEmail: this.configurationAttributes.addEmail,
                    fileNames: tempFileList,
                    uploadSizeErrorList: uploadSizeErrorList,
                    // hide the delete buttons to remove documents from the list of ones to upload
                    hasAccepted: this.hasAccepted,
                    // we're in bulk properties mode if we have more than 1 document to upload - otherwise
                    // we'll hide the bulk properties button from the user
                    bulkPropertiesMode: this.fileNames.length > 1,
                    processingAttachments: this.processingAttachments,
                    modal: this.myHandler === "modalActionHandler"
                };
            }
        });
        
        BulkUpload.UploadControls = Backbone.Layout.extend({

            template: "actions/bulkupload/bulkupload-file-controls",

            initialize: function (options) {
                // set our passed in options onto our view
                this.options = options;

                // set configuration options from admin
                this.licenseIsSet = options.config.scannerConfig;
                this.templatingSet = options.config.addDocTemplateEnabled;
                this.createFromContentSet = options.config.createDocFromContentEnabled;
                this.gmailUploadSet = options.config.gmailUploadEnabled;
                this.scannerLicense = options.config.scannerLicense;

                this.processRequiredDocs = options.config.processRequiredDocs;

                // determines whether or not the user wants indexing mode enabled for bulkupload
                this.indexingMode = options.config.indexingMode === "true";

                // determines what mode OA should open in indexing mode
                this.oaviewerMode = options.config.oaviewerMode;

                // the location where the initial file uploads for indexing mode will be stored
                this.indexingFileDumpFolder = options.config.indexingFileDumpFolder;

                // the document attribute to be displayed
                this.attrToShow = options.config.attrToShow;

                // determines whether or not the user wants cloud integration enabled for bulkupload
                this.cloudIntegration = options.config.cloudIntegration === "true";

                // determines the client id for cloud upload
                this.cloudIntegrationClientId = options.config.cloudIntegrationClientId;

                // determines what link type the user expects to get back
                this.cloudIntegrationLinkType = options.config.cloudIntegrationLinkType;

                // determines whether or not the user wants box integration enabled for bulkupload
                this.cloudIntegrationSelectMultiple = options.config.cloudIntegrationSelectMultiple;

                // the type of cloud connection we want to make
                this.cloudSelectType = options.config.cloudSelectType;

                // whether to have documents uploaded all at once or one at a time (defaulting to 'asynchronous')
                options.config.asynchronousOption = options.config.asynchronousOption === "false" ? false : true;

                // an indicator of whether or not to show the "Generate Cover Page" button on the modal depending on if the
                // user configured this in the admin
                this.dropOffScanning = options.config.dropOffScanning === "true";

                // the actual text to use for the "Generate Cover Page" (default) button
                this.dropOffScanningButtonText = options.config.printBarcodePageText;

                // this is the input of our "Select Files" button for choosing files to upload
                this.element = '.fileuploader-input';

                // the number of messages we have to parse - this is used in case the user re-selects an MSG file
                // that has already been parsed (we don't want to parse it again)
                this.numMessagesToParse = 0;

                // a deferred object that we'll use if this is the "Add Emails" action and we need to parse an MSG
                // file for attachments when it's chosen to be uploaded
                this.processingEmailDeferred = $.Deferred();

                // This tells if the user is on a mobile or tablet device
                this.isMobile = UserAgent.isMobileOrTablet();

            },

            afterRender: function () {
                var self = this;

                this.$(this.element).bind('dragenter dragover', function (e) {
                    e.preventDefault();
                });

                this.$(this.element).bind('dragleave drop', function (e) {
                    e.preventDefault();
                });

                // if add from existing was disabled we want to keep it that way.
                if (this.disableAddFromExisting) {
                    $(".createDocFromExistingContentButton").addClass("disabled");
                } else {
                    $(".createDocFromExistingContentButton").removeClass("disabled");
                }

                // check if we're in the "Add Emails" action
                if (this.options.config.addEmail) {
                    this.$(this.element).fileupload({
                        // we're in the "Add Emails" action so the URL we want is to parse our MSG file and create a
                        // temporary repository object with its content because we won't be able to re-upload the
                        // MSG file content when the user chooses to upload since we're probably in IE9
                        url: app.serviceUrlRoot + "/email/parseEmailWithStringResponse",
                        forceIframeTransport: true,
                        add: function (e, data) {
                            // assume we don't yet have any error
                            var addEmailError = false;
                            var errorText = "";
                            $('#addEmailError').hide();

                            // check the file name of the file they chose to upload to make sure it has ".msg" at the end
                            var filename = data.files[0].name;
                            if (filename.substr(filename.lastIndexOf('.') + 1).toLowerCase() !== "msg") {
                                addEmailError = true;
                                errorText = window.localize("modules.actions.bulkUpload.thisActionOnly");
                            } else if (data.files.length > 1) { // check to make sure they're only choosing one file at a time
                                addEmailError = true;
                                errorText = window.localize("modules.actions.bulkUpload.pleaseOnlyChoose");
                            }

                            // if there was no error, let's parse our email
                            if (!addEmailError) {
                                // the user chose some files to upload - this will set the number of messages that
                                // need to be parsed based on whether or not we've already parsed the selected MSG file
                                app.trigger('bulkupload:filesUploaded', data.files);

                                // if we actually have an MSG file to parse, let's parse it (this will get set in the
                                // above event trigger)
                                if (self.numMessagesToParse > 0) {
                                    // add our request parameters onto our request
                                    data.formData = {
                                        'parseForLinks': self.options.config.parseForLinks,
                                        'createTempEmail': true,
                                        'parentFolderId': app.context.container.get("objectId"),
                                        'parseAttachments': true
                                    };

                                    // disable the "Next" button so the use can't continue until we're done parsing
                                    // the email for attachments
                                    $('#acceptFileList').addClass('disabled');

                                    // submit our MSG file to be parsed
                                    data.submit();
                                }
                            } else { // there was an error
                                // show the user what the error was so they can fix it
                                $("#addEmailError p").text(errorText);
                                $('#addEmailError').show();
                            }
                        },
                        // disable drag and drop because we're on IE9
                        dropZone: null
                    }).bind('fileuploaddone', function (e, data) {
                        // IE 9 and iframes make getting the response interesting
                        // http://stackoverflow.com/questions/8814068/jquery-file-upload-ie-done-callback-data-result-issue
                        var result = $('pre', data.result).text();
                        var results = $.parseJSON(result);

                        // resolve our deferred since we're done parsing this email
                        self.processingEmailDeferred.resolve();

                        // trigger our event to process our email now that we've got our results back
                        app.trigger("bulkupload:processItemWithAttachments", data.files[0].emailId, results, BulkUpload.CONSTANTS.EMAIL);
                    });
                } else { // we're in the normal "Add Documents" action
                    // bind our file upload plugin to our input field
                    this.$(this.element).fileupload({
                        add: function (e, data) {
                            app.trigger('bulkupload:filesUploaded', data.files);
                        },
                        dropZone: $(this.element)
                    });
                }
            },

            serialize: function () {
                return {
                    // true if the scan button should be present, false otherwise
                    scanningConfigured: this.licenseIsSet !== "false" && this.licenseIsSet && this.scannerLicense,
                    // true if the add doc from Template button should be present, false otherwise
                    templatingConfigured: this.templatingSet !== "false",
                    // true if the create doc from existing content should be present, false otherwise
                    createFromContentConfigrued: this.createFromContentSet !== "false",
                    // true if gmail upload should be present, false otherwise
                    gmailUploadConfigrued: this.gmailUploadSet !== "false",
                    // true if the cover page button is present, false otherwise
                    dropOffScanning: this.dropOffScanning,
                    // only relevant if "dropOffScanning" is true - this is the text on the cover page button
                    dropOffScanningButtonText: this.dropOffScanningButtonText,
                    // true if the user clicked on the add emails action, false otherwise
                    addEmail: this.options.config.addEmail,
                    // if there are files selected we want to enable the next button
                    hasFiles: this.hasFiles,
                    // true if indexing mode has been enabled by the admin
                    indexingMode: this.indexingMode,
                    // the mode we are opening indexing mode in
                    oaviewerMode: this.oaviewerMode,
                    // true if box integration has been enabled by the admin
                    cloudIntegration: this.cloudIntegration,
                    // the client id we are targetting
                    cloudIntegrationClientId: this.cloudIntegrationClientId,
                    // the type of link we expect to get back
                    cloudIntegrationLinkType: this.cloudIntegrationLinkType,
                    // whether or not we want to select multiple documents
                    cloudIntegrationSelectMultiple: this.cloudIntegrationSelectMultiple,
                    // the cloud system we are going to connect to
                    cloudSelectType: this.cloudSelectType,
                    // if user is on mobile or not
                    isMobile: this.isMobile
                };
            }
        });

        BulkUpload.PaginationControls = Backbone.Layout.extend({
            template: "actions/bulkupload/bulkupload-pagination-controls",
            events: {
                "click #nextUploadFormBtn": "next",
                "click #prevUploadFormBtn": "previous",
                "click #finishUploadFormBtn": "fileNamesUniqueCheck",
                "click #uploadLookupBtn": "lookUpValues",
                "click #properties-back-button": "goBack",
                "click #bulk-properties-back-button": "goToBulkProperties"
            },
            initialize: function (options) {
                // options will be the initial options for this view
                if (options) {
                    // the "1 of 2" documents to indicate where in the list the user is currently
                    this.showIndex = options.showIndex;
                    // the text indicating to the user that there are more required fields to fill out
                    this.showRequired = options.showRequired;
                    // if the "Next" button should be disabled or not
                    this.hasNext = options.hasNext;
                    // if the "Previous" button should be disabled or not
                    this.hasPrevious = options.hasPrevious;
                    // the current index in the list of documents the user is viewing (for the "1" in the "1 of 2")
                    this.currentIndex = options.currentIndex;
                    // the total number of documents chosen for upload (for the "2" in the "1 of 2")
                    this.numOfUploadItems = options.numOfUploadItems;
                    // if the documents are all valid and the finish button should be shown to complete the action
                    this.allowFinish = options.allowFinish;

                    //whether or not look up is enabled
                    this.enableLookUp = options.enableLookUp;

                    //the search trac attached if there is one
                    this.lookUpSearchConfig = options.lookUpSearchConfig;

                    this.myHandler = options.myHandler;

                    this.fileNamesUniqueCheckRequired = options.fileNamesUniqueCheckRequired;
                }

                // the text for the button that allows the user to be done setting properties and actually perform the upload
                this.finishMessage = window.localize("action.bulkUpload.finishAndUpdate");

                BulkUpload._removeOldListener("bulkupload:formIsValid");

                // this listener is nessesary in the case that there is only one document selected, we still want to finish and upload
                this.listenTo(app, 'bulkupload:formIsValid', function (options) {

                    // update tracker with the current index and its validity
                    if (this.currentIndex !== undefined) {
                        if (options.isValid) {
                            // oco is valid, pagination controls and sequential editor will show a valid oco
                            app.trigger('bulkupload:ocoValid', this.currentIndex);
                        } else {
                            // conversly, we need to diable the next button and show an error message if its invalid
                            app.trigger('bulkupload:ocoInvalid', this.currentIndex);
                        }
                    }

                    if (options.externalFormValidationMessage) {
                        this.externalFormValidationMessage = options.externalFormValidationMessage;
                    }


                    // if we want to show the index then we are not on the bulk properties page
                    if (this.showIndex) {
                        // we have a next button if the current index is less than the number of items to upload
                        this.hasNext = this.currentIndex < this.numOfUploadItems;

                        // show the helper text that there are required fields to fill out if this form is not yet valid
                        this.showRequired = !options.isValid;

                        //show external message?
                        this.showExternalValidityMessage = options.showExternal;

                        // figure out whether we can show the user the Finish & Upload button
                        this.setAllowFinish();
                    } else { // we are on the bulk properties page
                        // there's always a next button on the bulk properties page
                        this.hasNext = true;
                        this.render();
                    }
                }, this);

                this.listenTo(app, 'bulkupload:controls:update', function (options) {
                    this.hasPrevious = options.hasPrevious;
                    this.hasNext = options.hasNext;
                    this.currentIndex = options.currentIndex;
                    this.numOfUploadItems = options.numDocsToUpload;
                    this.showRequired = options.showRequired;
                    this.showIndex = options.showIndex !== undefined ? options.showIndex : this.showIndex;

                    // figure out whether we can show the user the Finish & Upload button
                    this.setAllowFinish();
                }, this);
            },
            next: function () {
                app.trigger("bulkupload:nextPressed");
            },
            previous: function () {
                app.trigger("bulkupload:prevPressed");
            },
            lookUpValues: function () {
                if(!$('#slickgrid-tableview-grid').is(":visible") || !this.lookupOpen){
                    this.lookupOpen = true;
                    app.trigger("bulkupload:lookUpValues");
                }else{
                    this.lookupOpen = false;
                    app.popoverHandler.trigger('hide');
                }
            },
            fileNamesUniqueCheck: function(){
                // Saving the changes on the last OCO before doing the duplicate check
                app.trigger("bulkUpload:saveLastOCO");
                
                if(this.fileNamesUniqueCheckRequired) {
                    var deferred = new $.Deferred();
    
                    app.trigger('bulkupload:onFinish:fileNamesUniqueCheck', deferred);
  
                    deferred.then(_.bind(this.processDuplicateFileNames, this));
                } else {
                    this.finish();
                }
            },
            processDuplicateFileNames: function(duplicates){
                if(duplicates.length === 0){
                    app[this.myHandler].trigger("hideWarning");
                    this.finish();
                } else {
                    var duplicatesView = new BulkUpload.DuplicateDocuments({
                        duplicateDocuments: _.uniq(duplicates)
                    });
                    app[this.myHandler].trigger("showWarning", duplicatesView);
                    var warningMessage = document.getElementById(this.myHandler + "-warning");
                    warningMessage.scrollIntoView();
                }
            },
            finish: function () {
                // animate our loading indicator with spin.js (lighter weight than animated gif)
                this.spinner = HPISpinner.createSpinner({
                    color: '#666'
                }, this.$el.find(".progressSpinner")[0]);

                app.trigger("bulkupload:finishPressed");

                // when a user is uploading the documents we want to disable all buttons so they can't
                // do anything else until the upload completes
                this.disableButtons();

                this.listenTo(app, 'bulkupload:doneUploading', function () {
                    // we're done uploading so let's destroy the spinner that indicates we're still processing something
                    HPISpinner.destroySpinner(this.spinner);
                }, this);

            },

            /**
             * Finds all buttons and disables them.
             */
            disableButtons: function () {
                // add the disabled class to all our buttons
                this.$('button').addClass('disabled');

                // disable all events so no buttons clicks trigger anything
                this.undelegateEvents();
            },

            /**
             * Finda all buttons and enables them.
             */
            enableButtons: function () {
                // get rid of the disabled class for all the buttons
                this.$('button').removeClass('disabled');

                // re-enable all events so button clicks trigger things again
                this.delegateEvents();
            },
            goBack: function () {
                app.trigger("bulkupload:backPressed");
            },
            goToBulkProperties: function () { //return to bulk properties view
                if ($('#bulk-properties-back-button').hasClass('disabled')) {
                    return; //do nothing if btn disabled
                }
                app.trigger('bulkupload:goToBulkProperties');
            },
            // helper method to set whether the Finish and Upload button should be enabled or not
            setAllowFinish: function () {
                var self = this;

                // if we're not showing a message saying the current OCO is invalid and we're on the last OCO
                if (!this.showRequired && !this.hasNext) {
                    var deferred = new $.Deferred();
                    // this code runs a scan of all the ocos in sequential properties and checks their validity on the whole
                    app.trigger('bulkupload:allOcosValid', deferred);
                    deferred.then(function (allValid) {
                        // if all ocos are valid, allow finish & upload
                        self.allowFinish = allValid;

                        self.render();
                    });
                } else { // we're either not on the last OCO or the last OCO isn't valid so let's not show the finish & upload button
                    this.allowFinish = false;
                    this.render();
                }
            },
            afterRender: function () {
                //if in templating mode hide the template picker
                app.trigger("addDocTemplate:removeView");
            },
            serialize: function () {
                return {
                    showIndex: this.showIndex,
                    currentIndex: this.currentIndex,
                    numOfUploadItems: this.numOfUploadItems,
                    showRequired: this.showRequired,
                    hasNext: this.hasNext,
                    hasPrevious: this.hasPrevious,
                    allowFinish: this.allowFinish,
                    finishMessage: this.finishMessage,
                    enableLookUp: this.enableLookUp,
                    externalFormValidationMessage: this.externalFormValidationMessage,
                    showExternalValidityMessage: this.showExternalValidityMessage
                };
            }
        });

        /**
         * Shows the successfully uploaded documents and documents that failed to upload.
         */
        BulkUpload.Results = Backbone.Layout.extend({

            template: "actions/bulkupload/bulkupload-results",

            events: {
                "click a.uploaded-doc": "navigateToDoc"
            },

            initialize: function (options) {
                this.successList = options.successList;
                this.errorList = options.errorList;
            },

            serialize: function () {
                return {
                    successList: this.successList,
                    errorList: this.errorList
                };
            },
            navigateToDoc: function (evt) {
                app.trigger("bulkupload:docUploaded", _.findWhere(this.successList, {
                    objectId: $(evt.target).attr('value')
                }));
            }
        });

        BulkUpload.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/bulkuploadconfig",
            events : {
                "click .admin_ui_subsectionToggle" : "toggleSubsection"
            },
            initialize: function () {
                var self = this;

                // cache a reference to the viewModel and model for shorter references to them
                var viewModel = self.options.viewModel;
                var model = viewModel.model();

                    // is this action a header action
                viewModel.isHeaderMode = ko.observable(viewModel.model().get("isHeaderMode") ? viewModel.model().get("isHeaderMode") : false);

                //LOOK UP KBS
                viewModel.enableLookUp = kb.observable(model, "enableLookUp");
                //config
                viewModel.lookUpSearchConfig = kb.observable(model, "lookUpSearchConfig");
                //end LOOK UP KBS
                if(!viewModel.isHeaderMode()){
                    model.set('lookUpSearchConfig',"");
                    viewModel.lookUpSearchConfig("");
                }

                viewModel.availableSearchConfigs = ko.observableArray([]);
                viewModel.availableSearchConfigs([""]);
                if(viewModel.isHeaderMode()){
                    app.context.configService.getSearchConfigNames(function (allConfigs) {
                        viewModel.availableSearchConfigs(allConfigs);
                    }, function () { }, true);
                }   
                
                // Create the positional data config view
                this.positionDataView = new iOSSwitch.View({
                    model: model,
                    configModelKey: "positionDataEnabled",
                    switchTitle: window.localize("indexerConfig.indexerMainLayout.positionalTracking"),
                    configDescription: window.localize("indexerConfig.positionalTrackingTooltip")
                });

                viewModel.containerPath = kb.observable(model, "containerPath");

                viewModel.maxUploadSize = kb.observable(model, "maxUploadSize");
                viewModel.maxTotalUploadSize = kb.observable(model, "maxTotalUploadSize");


                // whether or not to inherit attribute values from the parent folder the documents are being uploaded into
                viewModel.inheritFolderAttributes = kb.observable(model, "inheritFolderAttributes");

                // whether or not to enable add doc from template
                viewModel.addDocTemplateEnabled = kb.observable(model, "addDocTemplateEnabled");

                //whether path security check will hide/show types or not.
                viewModel.enablePathSecurityCheck = kb.observable(model, "enablePathSecurityCheck");

                // whether or not to enable add doc from existiing content
                viewModel.createDocFromContentEnabled = kb.observable(model, "createDocFromContentEnabled");

                // Add documents from gmail
                viewModel.gmailUploadEnabled = kb.observable(model, "gmailUploadEnabled");

                // If add from gmail is enabled user needs a client id
                viewModel.gmailUploadClientId = kb.observable(model, "gmailUploadClientId");
                if (!viewModel.gmailUploadClientId()) {
                    viewModel.gmailUploadClientId("UNSET");
                }

                // the relation type to apply to attachments of dragged in MSG files
                viewModel.emailRelationType = kb.observable(model, "emailRelationType");

                // the relation type to apply to attachments of dragged in ZIP files
                viewModel.zipRelationType = kb.observable(model, "zipRelationType");

                //whether we want to enable set new version of existing doc or not
                viewModel.enableSetNewVersion = kb.observable(model, "enableSetNewVersion");

                // whether we want to upload a pdf rendition or nor
                viewModel.createPdfRendition = kb.observable(model, "createPdfRendition");
                // email cloud link service
                viewModel.parseForLinks = kb.observable(model, "parseForLinks");

                viewModel.dropboxClientKey = kb.observable(model, "dropboxClientKey");
                if (!viewModel.dropboxClientKey()) {
                    viewModel.dropboxClientKey("UNSET");
                }
                viewModel.dropboxClientSecret = kb.observable(model, "dropboxClientSecret");
                if (!viewModel.dropboxClientSecret()) {
                    viewModel.dropboxClientSecret("UNSET");
                }
                viewModel.googleClientId = kb.observable(model, "googleClientId");

                if (!viewModel.googleClientId()) {
                    viewModel.googleClientId("UNSET");
                }
                viewModel.microsoftClientId = kb.observable(model, "microsoftClientId");

                if (!viewModel.microsoftClientId()) {
                    viewModel.microsoftClientId("UNSET");
                }
                // whether or not to limit the document object types the user can set at the types of the uploaded documents
                viewModel.limitTypes = kb.observable(model, "limitTypes");
                // available document types for the user to choose to limit the object types to
                viewModel.availableDocumentTypesInConfig = ko.observableArray([]);
                // selected document types the user has chosen to allow settin the object type to
                viewModel.selectedDocumentTypesInConfig = ko.observableArray([]);
                // when this toss across changes, we want to update the model property that tracks the limited document types
                viewModel.selectedDocumentTypesInConfig.subscribe(function (values) {
                    model.set("selectedDocumentTypes", values);
                });

                // whether or not to allow documents from a scanner
                viewModel.scannerConfig = kb.observable(model, "scannerConfig");
                // the license key for the scanner
                viewModel.scannerLicense = kb.observable(model, "scannerLicense");

                // whether or not to enable drop off scanning (generating a barcode PDF placeholder)
                viewModel.dropOffScanning = kb.observable(model, "dropOffScanning");

                // whether or not to enable drop off scanning (generating a barcode PDF placeholder)
                viewModel.processRequiredDocs = kb.observable(model, "processRequiredDocs");

                //document types that are added to the white list for upload
                viewModel.documentTypesWhiteListed = kb.observable(model, "documentTypesWhiteListed");

                // the button text for the "generate cover page" button that shows up on the bulk upload action
                viewModel.printBarcodePageText = kb.observable(model, "printBarcodePageText");
                // if there is no text set for the "generate cover page" button, default to "Generate Cover Page"
                if (!viewModel.printBarcodePageText()) {
                    viewModel.printBarcodePageText("Generate Cover Page");
                }
                // the attribute that the generated attribute is made from
                viewModel.dropOffScanningAttribute = kb.observable(model, "dropOffScanningAttribute");
                // if there is no attribute specified to generate the barcode with, default to objectId
                if (!viewModel.dropOffScanningAttribute()) {
                    viewModel.dropOffScanningAttribute("objectId");
                }
                // the value of the title to set on the generated cover page PDF
                viewModel.coverPageTitle = kb.observable(model, "coverPageTitle");
                if (!viewModel.coverPageTitle()) {
                    viewModel.coverPageTitle("Scanning Cover Page");
                }
                // whether or not to allow the user to customize the attributes that show up on the generated cover page
                // if this is "Off", the default is to use the properties present atCreation
                viewModel.customAttrsOnCoverPage = kb.observable(model, "customAttrsOnCoverPage");
                // all the available document types the user can set custom properties for
                viewModel.barcodeDocumentTypesToConfig = ko.observableArray([]);

                //whether or not to create a Folder Note after document upload
                viewModel.auditTrail = kb.observable(model, "auditTrail");
                // selected audit trail type from the admin
                viewModel.auditTrailObjectType = kb.observable(model, "auditTrailObjectType");
                if (!viewModel.auditTrailObjectType()) {
                    viewModel.auditTrailObjectType("HPI Note");
                }
                // note type to apply to all audit trail notes
                viewModel.auditTrailNoteType = kb.observable(model, "auditTrailNoteType");
                if (!viewModel.auditTrailNoteType()) {
                    viewModel.auditTrailNoteType("Audit Trail");
                }
                //selected audit trail relationship from admin
                viewModel.auditTrailRelationship = kb.observable(model, "auditTrailRelationship");

                // set to true if the user wishes to have indexing mode enabled
                viewModel.indexingMode = kb.observable(model, "indexingMode");

                // set to true if the user wishes to have print from repo enabled
                viewModel.printMode = kb.observable(model, "printMode");

                // the location where initial document uploads for indexing mode will be stored
                viewModel.indexingFileDumpFolder = kb.observable(model, "indexingFileDumpFolder");

                // what OpenAnnotate mode the document will use
                viewModel.oaviewerMode = kb.observable(model, "oaviewerMode");

                viewModel.isCustomBulkPropertiesFormConfigured = kb.observable(model, "isCustomBulkPropertiesFormConfigured");

                viewModel.isTrackerThumbnailsEnabled = kb.observable(model, "isTrackerThumbnailsEnabled");
                // if there is no value specified then we set to TRUE by default
                if (!viewModel.isTrackerThumbnailsEnabled()) {
                    viewModel.isTrackerThumbnailsEnabled("true");
                }

                // whether or not the user will be using box integration
                viewModel.cloudIntegration = kb.observable(model, "cloudIntegration");

                // the id of the client we will be using
                viewModel.cloudIntegrationClientId = kb.observable(model, "cloudIntegrationClientId");

                // the type of link we expect to get back from the cloud
                viewModel.cloudIntegrationLinkType = kb.observable(model, "cloudIntegrationLinkType");

                // whether or not the user wants to select multiple documents
                viewModel.cloudIntegrationSelectMultiple = kb.observable(model, "cloudIntegrationSelectMultiple");

                // the cloud storage system we will be using
                viewModel.cloudSelectType = kb.observable(model, "cloudSelectType");

                // whether or not the action should upload documents all at once or one at a time
                viewModel.asynchronousOption = kb.observable(model, "asynchronousOption");

                // check if the file names that are being uploaded are all unique. This will not check the names of files that already exist in the folder.
                // An external rule can be set for that in the bulkUpload form config. 
                viewModel.fileNamesUniqueCheckRequired = kb.observable(model, "fileNamesUniqueCheckRequired");
                
				// Attribute to show
                viewModel.attrToShow = kb.observable(model, "attrToShow");

                // this is the array of types that the user has configured a custom properties list for that
                // is sent / received by the server
                self.typeAttributeServerData = model.get("typeAttributes") || {};
                // this is an array for displaying the currently configured types to the user on the admin screen
                viewModel.typeAttributeViewModels = ko.observableArray([]);

                viewModel.AWSTextractEnabled=kb.observable(model, "AWSTextractEnabled");

                // the id of the client we will be using
                viewModel.AWSTextractClientId = kb.observable(model, "AWSTextractClientId");

                // the type of link we expect to get back from the cloud
                viewModel.AWSTextractUpperBound = kb.observable(model, "AWSTextractUpperBound");

                // whether or not the user wants to select multiple documents
                viewModel.AWSTextractLowerBound = kb.observable(model, "AWSTextractLowerBound");
                
                // if the user already has types configured
                if (model.get("typeAttributes")) {
                    // grab the already configured types
                    var oldTypeAttributes = model.get("typeAttributes");
                    // we are copying over the currently configured types so we can build up the inidividual view models for each one
                    // this is essentially what knockback collection observable does, but it doesn't really work well in this situation
                    _.each(oldTypeAttributes, function (attributes, objectType) {
                        if (objectType !== "_id") { // an extra key with "_id" is sent in the obejct to the server, skip this
                            var newTypeAttribute = new BulkUpload.TypeAttributeViewModel({
                                objectType: objectType,
                                attributes: attributes,
                                typeAttributeServerData: self.typeAttributeServerData
                            });

                            // add our existing typeAttribute (which we've now newly created) to our view models to display to the user
                            viewModel.typeAttributeViewModels.push(newTypeAttribute);
                        }
                    });
                } else { // we need to set the empty object on the model becasue the user hasn't configured type attributes
                    model.set("typeAttributes", self.typeAttributeServerData);
                }

                // this is the currently selected type that the user wants to configure
                viewModel.selectedType = ko.observable();
                viewModel.selectedType.subscribe(function (newSelectedType) {
                    // this will be undefined when you reject a value from the barcodeDocumentTypesToConfig below, which causes
                    // this subscription to fire again since it changes to the optionsCaption value
                    if (newSelectedType) {
                        // create our new type attribute view model
                        var typeAttribute = new BulkUpload.TypeAttributeViewModel({
                            typeLabel: newSelectedType.label,
                            objectType: newSelectedType,
                            typeAttributeServerData: self.typeAttributeServerData
                        });

                        // enter an entry into the map of type attributes that gets sent back to the server
                        // with an initially empty array
                        self.typeAttributeServerData[newSelectedType] = [];
                        // add an entry to the observable array that holds our type attributes
                        viewModel.typeAttributeViewModels.push(typeAttribute);

                        // remove the doc type from the list of available doc types to configure
                        viewModel.barcodeDocumentTypesToConfig(_.reject(viewModel.barcodeDocumentTypesToConfig(), function (availableDocType) {
                            return availableDocType.value === newSelectedType;
                        }));
                    }
                });

                // called when a user clicks the "x" button to remove a configured type attribute
                viewModel.removeTypeAttribute = function (typeAttribute) {
                    // remove the entry from the data that gets sent back to the server
                    delete self.typeAttributeServerData[typeAttribute.objectType];
                    // remove the entry from the observable array
                    viewModel.typeAttributeViewModels.remove(typeAttribute);

                    // add the type being removed back into the list of available types to configure
                    viewModel.barcodeDocumentTypesToConfig.push({
                        // typeLabel is an observable, objectType is not
                        "label": typeAttribute.typeLabel(),
                        "value": typeAttribute.objectType
                    });

                    // if this type attribute was being edited when they clicked the delete button, get rid of the edit view
                    if (viewModel.editTypeAttributeViewModel().objectType === typeAttribute.objectType) {
                        viewModel.editTypeAttributeViewModel(undefined);
                    }
                };

                // the type attribute that is currently being edited
                viewModel.editTypeAttributeViewModel = ko.observable();

                // called when a user clicks the edit button for a type attribute
                viewModel.editTypeAttribute = function (typeAttribute) {
                    viewModel.editTypeAttributeViewModel(typeAttribute);
                };

                // grab the adminOTC so we can populate our document types
                app.context.configService.getAdminOTC(function (config) {
                    // we only care about document types so filter through the returned configs for only document configs
                    var documentConfigs = config.get("configs").filter(function (config) {
                        return config.get("isContainer") === "false";
                    });

                    // a cached value for all the document types available on this admin OTC with only the label and ocName fields
                    var allDocumentTypes = _.map(documentConfigs, function (docConfig) {
                        return {
                            label: docConfig.get("label"),
                            value: docConfig.get("ocName")
                        };
                    });

                    // filter out the already configured barcode document types from the list of those that are available to configure
                    viewModel.barcodeDocumentTypesToConfig(_.reject(allDocumentTypes, function (docConfig) {
                        // if the value of the docConfig (the ocName) is already a key in the type attributes server data, then it's already configured
                        return _.find(_.keys(self.typeAttributeServerData), function (objectType) {
                            return objectType === docConfig.value;
                        });
                    }));

                    // split our documentConfigs into two parts: one for available types to limit, one for selected types to limit
                    var partitionedDocumentTypes = _.partition(allDocumentTypes, function (docConfig) {
                        // if the ocName of the document config (mapped to value) is already in the selectedDocumentTypes on the model,
                        // then the user has selected it as a limiting document type already
                        return _.findWhere(model.get("selectedDocumentTypes"), {
                            value: docConfig.value
                        });
                    });

                    // our selected document types is the first part of the partitionedDocumentTypes array
                    viewModel.selectedDocumentTypesInConfig(partitionedDocumentTypes[0]);
                    // our available document types is the second part of the partitionedDocumentTypes array
                    viewModel.availableDocumentTypesInConfig(partitionedDocumentTypes[1]);
                });

                viewModel.enableDocumentLinkTracResolving = kb.observable(model, "enableDocumentLinkTracResolving");
                viewModel.documentLinkTracResolving = kb.observable(model, "documentLinkTracResolving");
                viewModel.availableTracs = ko.observableArray([]);
                app.context.configService.getTracConfigs(function (allConfigs) {
                    viewModel.availableTracs(allConfigs.pluck("name"));
                }, function () { }, true);

                viewModel.form = kb.observable(model, "form");
                 
                viewModel.bulkPropertiesForm = kb.observable(model, "bulkPropertiesForm");

                viewModel.potentialForms = ko.observableArray();
                this.initializeDef = app.context.configService.getFormConfigNames(function(formConfigNames) {
                    self.viewModel.potentialForms(formConfigNames);
                });

                viewModel.typePathServerData = model.get("customTypePaths") ? model.get("customTypePaths") : {};
                viewModel.typePathViewModels = ko.observableArray([]);
                viewModel.objectTypesWithoutPathConfig = ko.observableArray([]);
                viewModel.selectedObjectTypeWithoutPathConfig = ko.observable();
                viewModel.selectedTossAccrossType = ko.observable();
                viewModel.objectTypesForLookupToss = ko.observableArray([]);

                viewModel.form.subscribe(this._formSubscribeHandler, this);

                self.availableAttributes = new Backbone.Collection([]);
                self.selectedAttributes = new Backbone.Collection([]);

                viewModel.selectedTossAccrossType.subscribe(function (tossAcrossType) {
                    if (tossAcrossType) {
                        var lookupFieldsForType;
                        if (model.get("uploadLookupFields")) {
                            lookupFieldsForType = model.get("uploadLookupFields")[tossAcrossType];
                        } else {
                            lookupFieldsForType = [];
                        }
                        self.lookupFieldsForType = lookupFieldsForType;
                        self.availableAttributes.reset();
                        self.selectedAttributes.reset();
                        //Getting all potential attributes from the OTC
                        app.context.configService.getAdminTypeConfig(tossAcrossType, function (typeConfig) {

                            _.each(typeConfig.get("attrs").models, function (attr) {
                                var lookupLocation = $.inArray(attr.get("ocName"), _.pluck(self.lookupFieldsForType, 'ocName'));
                                if (lookupLocation === -1) {
                                    self.availableAttributes.push({
                                        'label': attr.get("label"),
                                        'ocName': attr.get("ocName")
                                    });
                                } else {
                                    self.selectedAttributes.push({
                                        'label': attr.get("label"),
                                        'ocName': attr.get("ocName"),
                                        'ordinal': self.lookupFieldsForType[lookupLocation].ordinal
                                    });
                                }
                            });

                            self.selectedAttributes.models = _.sortBy(self.selectedAttributes.models, function (model) {
                                return model.get("ordinal");
                            });
                            self.uploadLookupMetaToss = new TossAcross.Layout({
                                clickAcross: true,
                                enableAddRemove: true,
                                srcCollection: {
                                    title: 'Available Attributes',
                                    filter: true,
                                    labelAttr: 'label',
                                    valueAttr: 'ocName',
                                    collection: self.availableAttributes
                                },
                                targetCollections: [{
                                    filter: true,
                                    title: 'Selected Attributes',
                                    labelAttr: 'label',
                                    valueAttr: 'ocName',
                                    collection: self.selectedAttributes
                                }]
                            });

                            self.setView("#upload-lookup-meta-toss-across", self.uploadLookupMetaToss).render();

                        });
                    }
                });

                // Listener that controls any movements to the attributes selected to display for an object type
                this.stopListening(self.selectedAttributes, 'add remove reset');
                this.listenTo(self.selectedAttributes, 'add remove reset', function () {
                    var currentLookupFields = model.get("uploadLookupFields") ? model.get("uploadLookupFields") : {};
                    var newObjectProps = [];
                    _.each(self.selectedAttributes.models, function (model) {
                        newObjectProps.push({
                            label: model.get('label'),
                            ocName: model.get('ocName'),
                            ordinal: model.get('ordinal')
                        });
                    });
                    currentLookupFields[viewModel.selectedTossAccrossType()] = newObjectProps;
                    model.set("uploadLookupFields", _.extend({}, currentLookupFields));
                }, this);
                // this allows a user to add a path configuration for a selected object type
                viewModel.selectedObjectTypeWithoutPathConfig.subscribe(function (objectType) {
                    if (objectType) { // will be undefined if the caption is chosen
                        viewModel.typePathViewModels.push(new BulkUpload.TypePathViewModel({
                            objectType: objectType,
                            path: "",
                            typePathServerData: viewModel.typePathServerData,
                            formName: viewModel.form(),
                            model: model
                        }));
                        viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(viewModel.objectTypesWithoutPathConfig(), {
                            "value": objectType
                        }));
                    }
                });

                // this allows a user to delete a path configuration for a selected object type
                viewModel.deleteTypePath = function (typePath) {
                    viewModel.typePathViewModels.remove(typePath);
                    if (viewModel.typePathServerData[viewModel.form()] && viewModel.typePathServerData[viewModel.form()][typePath.objectType]) {
                        delete viewModel.typePathServerData[viewModel.form()][typePath.objectType];
                    }
                    viewModel.objectTypesWithoutPathConfig.push({
                        "label": typePath.typeLabel,
                        "value": typePath.objectType
                    });
                    viewModel.objectTypesWithoutPathConfig(_.sortBy(viewModel.objectTypesWithoutPathConfig(), 'label'));
                };

                this._formSubscribeHandler(viewModel.form());
            },
            beforeRender: function() {
                var oaModeSlider = new OAModeSelect.DropdownView({viewModel: this.viewModel});
                
                this.setView("#bulkupload-oamodeselect", oaModeSlider).render();
            },
            afterRender: function () {
                var self = this;

                this.initializeDef.done(function(){
                    kb.applyBindings(self.options.viewModel, self.$el[0]);
                });

                this.OAModeTooltip = this.$(".oa-mode-select-tooltip");
                //add popover to icon for glyphicons
                this.OAModeTooltip.popover({
                  placement: 'right',
                  container: 'body',
                  trigger: 'hover',
                  title: window.localize("stageConfig.docViewerConfig.oaModeSelect.title"),
                  html : true,
                  content: "<p>"+window.localize("stageConfig.docViewerConfig.oaModeSelect.info")+ " " + window.localize("stageConfig.oaModeSelect.warning") + "<ul><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.annotationMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.redactMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.signatureMode") + "</li><li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.openViewerMode") + "</li> <li>" + window.localize("stageConfig.docViewerConfig.oaModeSelect.indexerMode") + "</li></ul></p>",
                  delay: {show: 500}
              });
            },
            _formSubscribeHandler: function (newFormName) {
                var viewModel = this.viewModel;
                var self = this;
                if (newFormName) {
                    app.context.configService.getFormConfig(newFormName, function (formConfig) {
                        viewModel.objectTypesWithoutPathConfig.removeAll();
                        viewModel.objectTypesForLookupToss([]);

                        self.insertView("#positionalAttrsToBindWith", self.positionDataView).render();

                        formConfig.get("configuredTypes").each(function (type) {
                            viewModel.objectTypesForLookupToss.push({
                                label: type.get('label'),
                                value: type.get('ocName')
                            });
                            viewModel.objectTypesWithoutPathConfig.push({
                                label: type.get('label'),
                                value: type.get('ocName')
                            });
                        });
                        viewModel.objectTypesWithoutPathConfig(_.sortBy(viewModel.objectTypesWithoutPathConfig(), 'label'));
                        _.each(_.keys(viewModel.typePathServerData[newFormName]), function (typeKey) {
                            if (typeKey.indexOf("_id") === -1) {
                                // skip the _id key, and remove all those that are already present
                                viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(viewModel.objectTypesWithoutPathConfig(), {
                                    "value": typeKey
                                }));
                            }
                        });
                    });
                    viewModel.typePathViewModels.removeAll();
                    _.each(_.keys(viewModel.typePathServerData[newFormName]), function (typeKey) {
                        if (typeKey.indexOf("_id") === -1) {
                            // skip the limit types key and the _id key
                            viewModel.typePathViewModels.push(new BulkUpload.TypePathViewModel({
                                objectType: typeKey,
                                path: viewModel.typePathServerData[newFormName][typeKey],
                                typePathServerData: viewModel.typePathServerData,
                                formName: newFormName,
                                model: viewModel.model()
                            }));
                            viewModel.objectTypesWithoutPathConfig.remove(_.findWhere(viewModel.objectTypesWithoutPathConfig(), {
                                "value": typeKey
                            }));
                        }
                    });
                }
            },
            toggleSubsection: function(e) {
                AdminUtil.UI.toggleCustomConfigSubsection({'event': e});
            }
        });

        actionModules.registerAction(HPIConstants.Actions.BulkUpload, BulkUpload, {
            "actionId": HPIConstants.Actions.BulkUpload,
            "label": (window.localize("modules.actions.bulkUpload.addDocuments")),
            "icon": "plus",
            "addEmail": false,
            "handler": "rightSideActionHandler",
            "paneSize": "fullPane"
        }, {
                "getPropsToInherit": getPropsToInherit
            });

        // this action is only relevant for clients using IE9 that also want to use the HTML5 viewer to parse MSG
        // files for attachments
        actionModules.registerAction("bulkUploadEmail", BulkUpload, {
            "actionId": "bulkUploadEmail",
            "label": (window.localize("common.addEmails")),
            "icon": "plus",
            "addEmail": true,
            "handler": "rightSideActionHandler",
            "paneSize": "fullPane"
        }, {
                "getPropsToInherit": getPropsToInherit
            });

        return BulkUpload;

    });
require(["bulkupload"]);
