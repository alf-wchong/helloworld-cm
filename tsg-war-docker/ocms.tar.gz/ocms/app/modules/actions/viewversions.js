define("viewversions", [
    "app",
    "modules/actions/actionmodules",
    "modules/tsg",
    "revertversion"
],
function(app, actionModules, TSG, RevertVersion) {
    "use strict";
    
    var ViewVersions = {};

    /**
     * Represents an individual version.
     * @constructor
     * @param {Object} versionObject - The OCO containing the information regarding the version.
     * @param {String} myHandler - The handler string representing the containing handler for
     *      our action.
     * @param {String} oaRootUrl - The root URL where OpenAnnotate can be reached.
     * @param {String} isSelectVersionModeOn - Whether the module is in Advanced Combine to PDF select version mode.
     */
    ViewVersions.Version = function(versionObject, myHandler, oaRootUrl, isSelectVersionModeOn) {
        var self = this;
        // Store the objectId of the version object.
        var versionId = versionObject.objectId;
        this.versionId = versionObject.objectId;

        // We need to check both the versionLabels and versionLabel fields since in DCTM,
        // we receive an array of version labels.
        if(versionObject.properties.versionLabels === undefined) {
            this.versionLabel = ko.observable(versionObject.properties.versionLabel);
        } else {
            this.versionLabel = ko.observable(versionObject.properties.versionLabels[0]);
        }

        // Create modifier name for the version modifier name.
        var isoModifier = versionObject.properties.modifier;
        this.versionModifier = ko.observable(isoModifier);
        app.context.filterService.getUserDisplayName(isoModifier, function(displayName){
            self.versionModifier = displayName;
        });
		
		// Create our formatted modification date for the version modification date.
        var isoModificationDate = versionObject.properties.modifiedDate;
        this.versionModificationDate = ko.observable(isoModificationDate);
        app.context.dateService.getFormattedDatetime(isoModificationDate).done(function(formattedDate) {
            self.versionModificationDate(formattedDate);
        });

        this.versionDescription = ko.observable(versionObject.properties.versionDescription);

        // Assume this object is not annotated but then make a request to find out if it
        // actually is annotated.
        this.annotated = ko.observable(false);
        if(!isSelectVersionModeOn) {
            TSG.services.ajaxService.isAnnotated({
                context: this,
                successCallback: function(isAnnotated) {
                    this.annotated(isAnnotated);
                },
                objectId: versionId
            });
        }
       
        /**
         * Shows the clicked on version next to the document being viewed.
         */
        this.showVersionInSideBySideView = function() {
            // Create our options object to pass on
			var options = {
                objectId: versionId,
                context: "viewVersions"
            };
            
            // hide the rsah before we set the documentId2 so our documentId2 doesn't get cleared out
            app[myHandler].trigger("hide");
            app.trigger("stage.refresh.documentId2", options);
        };

        /**
         * Shows the clicked on version in the main object pane.
         */
        this.showVersion = function() {
            if(!isSelectVersionModeOn) {
                app[myHandler].trigger("hide");
                app.trigger("stage.refresh.documentId", versionId);
            } else {
                // preventing knockout from stopping the propagation of this event
                // to our previewVersionInOA listener
                return true;
            }
        };
        
        /**
         * Opens a new OpenAnnotate window with the clicked on version.
         */
        this.showAnnotationWindow = function() {
            // Make sure this document is actually annotated.
            if(self.annotated()) {
                // All annotated versions are opened in read only mode when opened from the viewVersions 
                // action (even the current version).
                 window.open(oaRootUrl + "/login/external.htm?docId=" + versionId + "&readOnlyView=true" + "&username=" + app.user.get("loginName"));
            } else {
                app.log.warn(window.localize("modules.actions.viewVersions.annotationsNot") + versionId);
            }
        };
    };

    /**
     * The view model constructor for our view versions action.
     * @constructor
     * @param {Object} action - The Backbone action object containing the information needed
     *      to run our action.
     * @param {String} myHandler - The handler string representing the containing handler for
     *      our action.
     * @param {String} oaRootUrl - The root URL where OpenAnnotate can be reached.
     * @param {String} selectedVersionLabel - Previously selected version (for select version mode).
     * @param {String} isSelectVersionModeOn - Whether select version mode is on.
     */
    ViewVersions.ViewModel = function(action, myHandler, oaRootUrl, selectedVersionLabel, isSelectVersionModeOn) {
        var self = this;
        this.objectId = action.get("parameters").objectId;
        var objectNameParam = action.get("parameters").objectName;
        this.objectName = ko.observable("");
        this.docVersions = ko.observableArray([]);
        this.compareDocsCheckBox = ko.observableArray([]);
        this.selectedVersionLabel = selectedVersionLabel || "";
        this.isSelectVersionModeOn = isSelectVersionModeOn;

        // Get the objectName for our document whose versions are being viewed if we don't have it already
        if(!objectNameParam || objectNameParam === "") {
            TSG.services.ajaxService.getObjectProperties(this.objectId, function(obj) {
                self.objectName(obj.properties.objectName);
            });
        } else {
            self.objectName(objectNameParam);
        }

        // set the latest version as the currently selected version
        if(isSelectVersionModeOn) {
            this.selectedVersion = {
                workingCopyId: this.objectId,
                selectedVersionId: this.objectId,
                versionLabel: selectedVersionLabel,
                objectName: objectNameParam
            };
        }
        
        /**
         * Returns an object containing two properties: "majorVersionNumber" and "minorVersionNumber"
         * that are parsed as integers from the provided version's versionLabel. This method
         * normalizes the versionLabel since it may be a different type depending on which repository
         * is being used (it's a string in Alfresco and an array in Documentum).
         * @private
         * @param {Object} version - The version object containing the "versionLabel" property
         *      that should be parsed into its major and minor version parts.
         * @returns {Object} - An object with two keys: "majorVersionNumber" and "minorVersionNumber"
         *      that represent the integer values of the passed in version's major and minor version
         *      numbers.
         */
        this._getVersionParts = function(version) {
            // Initialize our version number string to the passed in version's "versionLabel"
            // property.
            var versionNumberStr = version.properties.versionLabel;

            // In Documentum, the version number is an array that contains the real version number
            // as well as other strings (e.g. "CURRENT", "LATEST").
            if(_.isArray(versionNumberStr)) {
                // Loop through each version label in the array and get one that is a number. NOTE:
                // if the array contains two numbers, the last number will be used (since we don't
                // break from the array when we find the first number).
                _.each(version.properties.versionLabel, function(versionLabelPart) {
                    // Check to see if this version label part CAN be converted to a float.
                    if(!isNaN(parseFloat(versionLabelPart))) {
                        versionNumberStr = versionLabelPart;
                    }
                });
            }

            // Split our version number on the "period" so we get the major and minor
            // version parts.
            var versionParts = versionNumberStr.split(".");

            // Make sure to parse our version number parts into integers below.
            return {
                majorVersionNumber: parseInt(versionParts[0], 10),
                minorVersionNumber: parseInt(versionParts[1], 10)
            };
        };

        /**
         * Provided an array of versions for the document, this updates our view model's
         * representation of the versions for our document.
         * @param {Array} versionHistory - An array of OCOs, each one representing a
         *      version.
         */
        this.processVersionHistory = function(versionHistory) {
            var self = this;

            // Remove any previous version history we had.
            self.docVersions.removeAll();

            // Sort our versions by the version label. NOTE: We cannot sort on creationDate because
            // the creationDate attribute is the same for all versions in Alfresco. We cannot sort
            // on modifiedDate since the modifiedDate attribute can be the same for more than one
            // version (somehow).
            versionHistory.sort(function(left, right) {
                // Get our major and minor version parts for the two versions we're comparing.
                var leftVersionParts = self._getVersionParts(left);
                var rightVersionParts = self._getVersionParts(right);

                // Check if the major versions are the same.
                if(leftVersionParts.majorVersionNumber === rightVersionParts.majorVersionNumber) {
                    // If the major versions are the same, then we want to sort on the minor version.
                    return leftVersionParts.minorVersionNumber > rightVersionParts.minorVersionNumber ? 1 : -1;
                } else {
                    // Sort on the major version numbers since they're not the same.
                    return leftVersionParts.majorVersionNumber > rightVersionParts.majorVersionNumber ? 1 : -1;
                }
            });

            // Add each of our versions to our array of document versions.
            _.each(versionHistory, function(version) {
                // Create a new version object for each version. The docVersions array should
                // be like a stack to get proper ordering of our versions.
                self.docVersions.unshift(new ViewVersions.Version(version, myHandler, oaRootUrl, self.isSelectVersionModeOn));
            });
        };
        
        /**
         * Fetches the version history for the document whose version history is to be
         * displayed.
         */
        this.fetchVersionHistory = function() {
            // Make sure we have an objectId to fetch documents for.
            if(this.objectId === undefined) {
                app[myHandler].trigger("showError", window.localize("modules.actions.viewVersions.unableToView"));
            } else {
                app[myHandler].trigger("loading", true);

                // Make sure the object we're fetching the versions for is the object
                // being viewed with the action.
                action.get("parameters").id = this.objectId;

                // Make our request to "execute" the action which really just means we want
                // to fetch the versions for our object.
                action.execute({
                    success: function(versions) {
                        // Process the versions we received from the server.
                        self.processVersionHistory(versions.result);

                        app[myHandler].trigger("loading", false);
                    },
                    error: function(jqXHR) {
                        app[myHandler].trigger("loading", false);
                        app[myHandler].trigger("showError", window.localize("modules.actions.viewVersions.couldNotRetrieve") +
                                jqXHR.status + " " + jqXHR.statusText);
                    }
                });
            }
        };
    };

    
    // This is the Backbone Layout for our action.
    ViewVersions.View = Backbone.Layout.extend({
        template: "actions/viewversions",
        events: {},
        initialize: function() {
            // Get our passed in options for our action.
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.oaRootUrl = app.openAnnotateURL;
            // This mode is used by the Advanced Combine to PDf action to select the version to include in a combined pdf
            this.isSelectVersionModeOn = this.options.selectVersionMode || false;
            this.selectedVersionLabel = this.options.selectedVersionLabel;
            this.viewModel = new ViewVersions.ViewModel(this.action, this.myHandler, this.oaRootUrl, this.selectedVersionLabel, this.isSelectVersionModeOn);

            // We don't need to make this revert service call in select mode
            // only add the event listeners needed for the current mode
            if(this.isSelectVersionModeOn) {
                this.events["click .versionLabel"] = "previewVersionInOA";
                this.events["click .selectVersionRadioBtnCell"] = "updateSelectedVersion";
            } else {
                this.events["click #compare-versions-btn"] = "compareDocs";
                this.events["click #revert-versions-btn"] = "revertVersion";
                this.events["click .compareCheckbox"] = "validate";
                var self = this;
                var deferred = $.Deferred();
                //Making a call to OC rest end point to get the permission information for the revertVersion action
                RevertVersion.Service.isValid({id: app.context.document.id, deferred: deferred});
                $.when(deferred).done(function(retreivedData){
                    self.revertValid = retreivedData;
                    self.render();
                });
            }
        },
        
        afterRender: function() {
            // Apply our bindings so our Knockout view model observables get tied to
            // the DOM.
            ko.applyBindings(this.viewModel, this.$el[0]);

            // Once the view has finished rendering, let's make our request to fetch
            // the versions for our object. 
            this.viewModel.fetchVersionHistory();
        },

        // tell our select version modal parent to display an OA iframe with this version
        previewVersionInOA: function(evt) {
            evt.stopPropagation();
            var versionRow = evt.currentTarget; 
            var objectId = versionRow.getAttribute("objectId");
            var versionLabel = versionRow.getAttribute("versionLabel");
            var objectName = this.viewModel.objectName();
            // this previewVersion object will be used by the selectVersionView 
            // if the user selects the version they are currently previewing
            this.viewModel.previewVersion = {
                workingCopyId: this.viewModel.objectId,
                selectedVersionId: objectId,
                versionLabel: versionLabel,
                objectName: objectName
            };
            // tell our parent view, selectVersionView, that the user wants to preview this version
            this.trigger("previewVersionInOA", {
                objectId: objectId,
                versionLabel: versionLabel, 
                objectName: objectName
            });
        },

        // handler for when a version is selected
        updateSelectedVersion: function(evt) {
            evt.stopPropagation();
            var versionRow = evt.currentTarget;
            var objectId = versionRow.getAttribute("objectId");
            var versionLabel = versionRow.getAttribute("versionLabel");
            
            // uncheck the previously selected version
            $('input[type=radio][versionlabel!="'+ versionLabel + '"]:checked').attr("checked", false);

            // check the newly selected version
            $('input[type=radio][versionlabel="'+ versionLabel + '"]').attr("checked", true);
            
            this.viewModel.selectedVersion = {
                workingCopyId: this.viewModel.objectId,
                selectedVersionId: objectId,
                versionLabel: versionLabel,
                objectName: this.viewModel.objectName()
            };

            // update the select version button with this version label
            $('#select-version-btn').html(window.localize("modules.actions.advancedCombineToPDF.selectVersionModal.title") + " " + versionLabel);
        },

        compareDocs: function(){
            var versionIds = [];
            //Pushing the version ids on to this array -- higher indexes mean older version.
            _.each(this.viewModel.docVersions(), function(doc){
                versionIds.push(doc.versionId);         
            });

            var firstDocIndex = _.indexOf(versionIds, this.viewModel.compareDocsCheckBox()[0]);
            var secondDocIndex = _.indexOf(versionIds, this.viewModel.compareDocsCheckBox()[1]);
            //HIGHER INDEX MEANS OLDER VERSION
            if(firstDocIndex > secondDocIndex){
                window.open(app.serviceUrlRoot + "/content/compare?primaryId=" + this.viewModel.compareDocsCheckBox()[0] + "&modifiedId=" + this.viewModel.compareDocsCheckBox()[1] + "&contentType=application%2Fpdf");       
            } else{
                window.open(app.serviceUrlRoot + "/content/compare?primaryId=" + this.viewModel.compareDocsCheckBox()[1] + "&modifiedId=" + this.viewModel.compareDocsCheckBox()[0] + "&contentType=application%2Fpdf");         
            }
        },

        //calling the revertversion action
        revertVersion: function(){
            RevertVersion.Service.execute({
                parameters:{
                    objectId: this.options.action.attributes.parameters.objectId,
                    prevVersionId: this.viewModel.compareDocsCheckBox()[0]
                }
            });
        },

        validate: function(){
            if(this.viewModel.compareDocsCheckBox().length === 2){
                $("#compare-versions-btn").attr('disabled', false);
            }else{
                $("#compare-versions-btn").attr('disabled', true);
            }

            //Enable revert version only when one version apart from the latest version is selected
            if(this.viewModel.compareDocsCheckBox().length === 1 &&(this.viewModel.compareDocsCheckBox()[0] !== app.context.document.id)){
                $("#revert-versions-btn").attr('disabled', false);
            }else{
                $("#revert-versions-btn").attr('disabled', true);
            }
        },

        serialize: function() {
            this.modal = this.myHandler === "modalActionHandler";
            this.compare = this.config.attributes.compareVersions === "true";
            this.revert = this.config.attributes.revertVersion === "true" && this.revertValid === true;
            return {
                    modal: this.modal,
                    rightSide: this.myHandler === "rightSideActionHandler",
                    // We are a modal on the stage if this action is configuerd to show as a modal
                    // and our URL has "Stage" in it.
                    modalStage: this.modal && (window.location.pathname.indexOf('Stage') > -1 || window.location.href.indexOf('Stage') > -1),
                    compare: this.compare,
                    revert: this.revert,
                    checkbox: this.revert || this.compare,
                    isSelectVersionModeOn: this.isSelectVersionModeOn,
                    selectedVersionLabel: this.selectedVersionLabel
                };
            }
        });

    ViewVersions.CustomConfigView = Backbone.Layout.extend({
            template: "hpiadmin/actions/customconfig/viewversionsconfig",
            initialize: function(){
                var viewModel = this.options.viewModel;

                viewModel.compareVersions = kb.observable(viewModel.model(), 'compareVersions');

                if(viewModel.compareVersions() === null){
                    viewModel.compareVersions(false);
                }

                viewModel.revertVersion = kb.observable(viewModel.model(), 'revertVersion');

                if(viewModel.revertVersion() === null){
                    viewModel.revertVersion(false);
                }
            },
            afterRender: function(){
                kb.applyBindings(this.options.viewModel, this.$el[0]);
            }
        });

    actionModules.registerAction("viewVersions", ViewVersions, {
        "actionId" : "viewVersions",
        "label" : "View Versions",
        "icon" : "list"
    });

    return ViewVersions;
});
require(["viewversions"]);