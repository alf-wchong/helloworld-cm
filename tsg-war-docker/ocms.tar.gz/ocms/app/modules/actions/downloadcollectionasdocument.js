define("downloadcollectionasdocument", [
    "app",
    "modules/actions/actionmodules",
    "modules/common/spinner",
    "modules/common/downloadutils",
    "modules/common/hpiconstants",
    "modules/hpiadmin/actionconfig/actions/collectionactions/downloadcollectionasdocumentcustomactionconfig"
    
], function(app, actionModules, HPISpinner, DownloadUtils, HPIConstants, DownloadCollectionAsDocumentCustomConfigView) {

    var DownloadCollectionAsDocument = {
        'TIMEOUT_DURATION': 3000
    };

    DownloadCollectionAsDocument.CustomConfigView = DownloadCollectionAsDocumentCustomConfigView.View;

    DownloadCollectionAsDocument.View = Backbone.Layout.extend({
        template: "actions/downloadcollectionasdocument",
        events: {
            "click .downloaddocument": "downloadCollectionAsDocument"
        },
        initialize: function() {
            this.handler = this.options.config.get("handler");
            this.collectionFileNameProps = this.options.config.get('nameAttrsToDisplay') ? this.config.get('nameAttrsToDisplay') : [];
            this.downloadInProgress = false;

            // this is the objectId of the current collection on the stage
            this.objectId = this.options.action.get("parameters").objectId;
            //Only listen to the instantExecute config if the handler is the modalactionhandler
            if(this.handler === HPIConstants.Handlers.ModalActionHandler) {
                this.instantExecute = this.options.config.get("instantExecute") === "true";
            } else {
                this.instantExecute = false;
            }

            if(this.instantExecute) {
                this.downloadCollectionAsDocument();
            }
        },
        downloadCollectionAsDocument: function() {
            //change modal to update user that combined collection is being created
            this.downloadInProgressView = new DownloadCollectionAsDocument.downloadInProgressView({
                handler: this.handler
            });
            this.setView("#downloadCollectionAsDocument", this.downloadInProgressView);
            this.render();

            //call custom action executor downloadCombinedCollection to run async
            this.action.get("parameters").asyncThread = "true";
            this.action.get("parameters").collectionFileNameProps = _.pluck(this.collectionFileNameProps, 'attrValue');
            this.action.execute({
                context: this,
                success: this.makeCheckStatusCall,
                error: this.showError
            });
            
        },
        checkStatus: function(data, responseData) {
            var self = this;
            if (data.percent === 100) {
                //when complete, download combined collection 
                DownloadUtils.asyncDownload(app.serviceUrlRoot + '/asyncMap/download/file?download=true&uniqueId=' + responseData.result);

                //destroy spinner, close modal
                this.downloadInProgressView.hideSpinner();
                app[this.handler].trigger("hide");
            } else if (data.percent < 0) {
                this.showError();
            } else {
                setTimeout(function() {
                    self.makeCheckStatusCall(responseData);
                }, DownloadCollectionAsDocument.TIMEOUT_DURATION);
            }
        },
        makeCheckStatusCall: function(responseData) {
            //ping asyncThread/download/status endpoint until action is complete
            $.ajax({
                url: app.serviceUrlRoot + "/asyncThread/download/status",
                method: "POST",
                global: false,
                data: {
                    uniqueId: responseData.result
				},
				context: this,
                success: _.partial(this.checkStatus, _, responseData),
				error: this.showError
            });
        },
        showError: function() {
            this.downloadInProgressView.hideSpinner();
            app[this.handler].trigger("showError", window.localize("stage.downloadCollection.unexpectedError"), false);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.handler === HPIConstants.Handlers.ModalActionHandler) {
                modal = true;
            } else if (this.handler === HPIConstants.Handlers.RightSideActionHandler) {
                rightSide = true;
            }

            return {
                modal: modal,
                rightSide: rightSide
            };
        }
    });

    DownloadCollectionAsDocument.downloadInProgressView = Backbone.Layout.extend({
        template: "actions/downloadcollectionasdocumentinprogress",
        initialize: function(options) {
            this.handler = options.handler;
        },
        afterRender: function() {
            app[this.handler].trigger("showInfo", window.localize("stage.downloadCollection.pleaseWait"), true);
            this.spinner = HPISpinner.createSpinner({
                length:11,
                width:6,
                radius: 16,
                color: '#000',
                shadow: false
            }, this.$("#download-spinner")[0]);
        },
        hideSpinner: function() {
            HPISpinner.destroySpinner(this.spinner);
        }
    });

    actionModules.registerAction("downloadCollectionAsDocument", DownloadCollectionAsDocument, {
        "actionId": "downloadCollectionAsDocument",
        "ocActionId": "downloadCollectionAsDocument",
        "label": window.localize("loggingConfig.eventNames.downloadDocument"),
        "icon": "download"
    });

    return DownloadCollectionAsDocument;
});

require(["downloadcollectionasdocument"]);