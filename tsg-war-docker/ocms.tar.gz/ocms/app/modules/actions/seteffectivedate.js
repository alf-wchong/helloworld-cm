define("seteffectivedate",[
  // Application.
  "app",
  "module",
  "modules/tsg",
  "modules/actions/actionmodules",
  "modules/hpiadmin/actionconfig/actions/seteffectivedate/seteffectivedatecustomconfig",
  "moment"
],

// Map dependencies from above array.
function(app, module, TSG, actionModules, SetEffectiveDateCustomConfig, moment) {

	var action = {};

	var ocEffectiveDateAttributeName = "tsg_effectiveDate";

	action.ViewModel = function(options, config){
		var self = this;
		self.action = options;
		self.config = config;
		self.myHandler = self.config.get("handler");
		self.taskId = ko.observable();
		self.workflowDocs = ko.observableArray([]);

		var getWorkflowDocObjectIds = function(formId, callback) {
			$.ajax({
				url: app.serviceUrlRoot + "/aw-workflow/getWFDocs?formId=" + formId,
				success: function(result) {
					callback(result);
				},
				error: function(jqXHR) {
					self.toggleLoader(false);
					self.workflowDocIds = undefined;
					app[self.myHandler].trigger("showError", (window.localize("modules.actions.setEffectiveDate.failedToGet")) + jqXHR.status +
												" " + jqXHR.statusText);
				}
			});
		};

		var addWfDocToArrayWithFormattedTime = function(wfDocProperties){
			var isApproved = true;
			if(wfDocProperties.aw_status !== "Approved"){
				isApproved = false;
			}
			self.workflowDocs.push({
				name: wfDocProperties.objectName,
				id: wfDocProperties.objectId,
				version:  ko.observable(wfDocProperties.versionLabel.toString()),
				currentDate: ko.observable( wfDocProperties[ocEffectiveDateAttributeName] ),
				date: ko.observable(),
				isApproved: ko.observable(isApproved),
				//maps the clear onClick event to this JSON object's data attribute.
				//This way there is a 1-1 relation between the date field and accompanying clear action
				clear: function(){
					this.date(undefined);
				}
			});
		};

		// NOTE: action._addWfDocToArray is used for testing purposes
		var addWfDocToArray = self._addWfDocToArray = function(wfDocProperties) {
			var objDate = wfDocProperties[ocEffectiveDateAttributeName];
			// if a date already exixts we want to format it correctly using the Application Config
			if(objDate){
				app.context.dateService.getFormattedDate(objDate).done(function(date){
					wfDocProperties[ocEffectiveDateAttributeName] = date;
					addWfDocToArrayWithFormattedTime(wfDocProperties);
				});
			}
			else {
				wfDocProperties[ocEffectiveDateAttributeName] = (window.localize("modules.actions.setEffectiveDate.dateNotSet"));
				addWfDocToArrayWithFormattedTime(wfDocProperties);
			}
		};

		_.each(this.action.get("parameters").objectIds, function(objectId) {
			// fetch properties and cache if a wf doc
			TSG.services.ajaxService.getObjectProperties(objectId, function(obj) {
				var props = obj.properties;
				_.each(self.action.validFormObjectTypes, function(validFormObjectType) {
					if( obj.objectType === validFormObjectType ) {
						// get wf docs of form and add to cache. TODO
						getWorkflowDocObjectIds(props.objectId, function(workflowDocIds) {
							_.each(workflowDocIds, function(wfDocId) {
								TSG.services.ajaxService.getObjectProperties(wfDocId, function(wfDocProps) {
									addWfDocToArray(wfDocProps.properties);
								});
							});
						});
					}
				});
				_.each(self.action.validDocObjectTypes, function(validDocObjectType) {
					if( obj.objectType === validDocObjectType ) {
						addWfDocToArray(props);
					}
				});

			});
        });

		self.onSubmit = function() {
			var that = this;
			// lets populate a container that maps the objectId to its selected date
			self.effectiveDates = {};
			var trueOffset,longDate;
			_.each(self.workflowDocs(), function(obj){
				if(obj.date() !== undefined && obj.date() !== ""){
					//if we have a timezone set, we need to set the effective date using that time zone
					if(that.action.timezoneFormat){
						trueOffset = moment(obj.date()).utcOffset() - moment(obj.date()).tz(that.action.timezoneFormat).utcOffset();
						longDate = moment(obj.date()).utcOffset(trueOffset)._d.getTime();
					}
					else{
						longDate = moment(obj.date())._d.getTime();
					}
					//get the formatted date that belongs to this objecctId
					self.effectiveDates[obj.id] = longDate;
				}
			});
			self.action.get("parameters").effectiveDates = self.effectiveDates;
			if(self.action.get("parameters").objectId === undefined){
				app[self.myHandler].trigger("showError", (window.localize("modules.actions.setEffectiveDate.unableToSet")));
			}
			else{
				app[self.myHandler].trigger("loading", true);
				self.action.execute({
					success : function() {
						app[self.myHandler].trigger("loading", false);
						app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.setEffectiveDate.effectiveDateSuccessfully")));
					},
					error : function(jqXHR) {
						app[self.myHandler].trigger("loading", false);
						app[self.myHandler].trigger("showError", (window.localize("modules.actions.setEffectiveDate.failedToSet")) + jqXHR.status +
							" " + jqXHR.statusText);
					}
				});
			}
		};
		return this;
	};

	action.View = Backbone.Layout.extend({
		template: "actions/seteffectivedate",
		initialize: function() {

			var self = this;

			this.action = this.options.action;
			this.config = this.options.config;
			//loads the effective date attribute name
			this.action.get("parameters").effectiveDate = this.config.attributes.effectiveDate;

			//Pull valid doc/form types from the configs (parse both backbone collections and arrays)
			var enabledDocTypes = this.config.get('enabledDocTypes');
			var enabledFormTypes = this.config.get('enabledFormTypes');
			if(enabledDocTypes instanceof Backbone.Collection) {
				enabledDocTypes = _.pluck(enabledDocTypes.models, 'attributes');
			}

			if(enabledFormTypes instanceof Backbone.Collection) {
				enabledFormTypes = _.pluck(enabledFormTypes.models, 'attributes');
			}

			this.action.validDocObjectTypes =  _.pluck(enabledDocTypes, 'ocName');
			this.action.validFormObjectTypes = _.pluck(enabledFormTypes, 'ocName');

			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};

			if (this.action.get("parameters").objectId !== null) {
                this.action.get("parameters").objectIds = [this.action.get("parameters").objectId];
            }

            self.viewModel = new action.ViewModel(self.action, self.config);

            this.docObjectPropsCache = {};

		},
		afterRender: function() {
			var self = this;

			//thanks stackoverflow, the knockout datepicker abstracts away the jquery datepicker to be just another knockout object
			ko.bindingHandlers.datepicker = {
				init: function(element, valueAccessor) {
			app.context.dateService.getDatetimeTimezoneFormat().done(function(dateTimeFormat){
				//instead of making a call later on the submit, we are going to grab the timezone now if there is one.
				//this way we only have to make 2 calls to dateService instead of 3.
				self.viewModel.action.timezoneFormat = dateTimeFormat.timezoneFormat ? dateTimeFormat.timezoneFormat : undefined;

				var jqueryFormat = app.context.dateService.getJQueryDateFormat(dateTimeFormat.dateFormat);

						var $el = $(element);

						//initialize datepicker with some optional options
						var options = { minDate: 0,
										dateFormat: jqueryFormat};
						$el.datepicker(options);

						//handle the field changing
						$el.change(function(){
							var observable = valueAccessor();
							observable($el.datepicker("getDate"));
						});
					});
					},
					update: function(element, valueAccessor) {
						var value = ko.utils.unwrapObservable(valueAccessor()),
							$el = $(element),
							current = $el.datepicker("getDate");

						if (value - current !== 0) {
							$el.datepicker("setDate", value);
						}
					}
				};

				kb.applyBindings(self.viewModel, self.$el[0]);

		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
        }
	});

	action.CustomConfigView = SetEffectiveDateCustomConfig.View;

	actionModules.registerAction("setEffectiveDate", action, {
        "actionId" : "setEffectiveDate",
      	"label" : (window.localize("modules.actions.setEffectiveDate.setEffectiveDate")),
      	"icon" : "calendar"
    });

    actionModules.registerAction("setEffectiveDateFromForm", action, {
        "actionId" : "setEffectiveDateFromForm",
      	"label" : (window.localize("modules.actions.setEffectiveDate.setDocEffectiveDates")),
      	"icon" : "calendar",
      	"groups" : ["wizard", "set", "effectiveDate"]
    });

	return action;
});
require(["seteffectivedate"]);
