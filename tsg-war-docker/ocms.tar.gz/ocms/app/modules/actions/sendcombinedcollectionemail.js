define("sendcombinedcollectionemail",[
	"app",
	"modules/actions/actionmodules",
	"sendemail",
	"modules/actions/sendemail/sendemailattachmentsview",
	"modules/actions/sendemail/sendemailutil",
	"modules/hpiadmin/actionconfig/actions/collectionactions/sendcombinedcollectionemailcustomactionconfig"
], function(app, actionModules, SendEmail, SendEmailAttachmentsView, SendEmailUtil, SendCombinedCollectionEmailCustomConfigView) {

    var SendCombinedCollectionEmail = _.extend({
		'TIMEOUT_DURATION': 3000
	}, SendEmail);

	SendCombinedCollectionEmail.CustomConfigView = SendCombinedCollectionEmailCustomConfigView.View;

	// we override this template so that we dont hyperlink collection docs in the attachments tab
	// for send email since we can launch collections in a new tab
	SendCombinedCollectionEmail.AttachmentsView = SendEmailAttachmentsView.View.extend({
		initialize: function(){
			SendCombinedCollectionEmail.AttachmentsView.__super__.initialize.apply(this, arguments);
			this.collectionAction = true;
		}
	});

    SendCombinedCollectionEmail.View = SendEmail.View.extend({
		initialize: function(){
			SendCombinedCollectionEmail.View.__super__.initialize.apply(this, arguments);
			this.attachmentsView = new SendCombinedCollectionEmail.AttachmentsView({options: this});
			this.collectionFileNameProps = this.options.config.get('nameAttrsToDisplay') ? this.config.get('nameAttrsToDisplay') : [];
		},
		displayAttachments: function(ocos) {
			this.attachmentsView.pending = false;
			var self = this;
			// Get the OTC and time formatting config in order to format any dates
			app.context.configService.getAdminOTC(function(otc) {
				_.each(ocos, function(doc){
					SendEmailUtil.setAttributesToDisplay(otc, doc, self.model.attributesToDisplay);
					//always add our attachment to the attachments view This will ensure that the
					//combined collection object will be passed along to the action executer for processing.
					self.attachmentsView.addSelectedAttachment(doc, true);
				});

				self.attachmentsView.render();
			});
		},
		executeAction: function() {
			// we are going to call start global loading her to mock out global loading, 
			// this will gray out our screen. We do this to prevent the flickering afect of global true with 
			// a ajax call that calls itself - async loading
			app.startGlobalLoading();
			//add parameters to our action so we know we are dealing with a collection 
			//and that we want to run the action asynchronosly
			this.model.action.get("parameters").asyncThread = "true";
			this.model.action.get("parameters").isCombinedCollection = "true";
			this.model.action.get("parameters").collectionFileNameProps = _.pluck(this.collectionFileNameProps, 'attrValue');
			this.model.action.execute({
				global: false,
				context: this,
				success: this.makeCheckStatusCall,
				error: this.showError
			});
		},
		showError: function(){
			app[this.handler].trigger("loading", false);
			// if there is an error we want to stop the gray out affect of the startgloballoading call
			app.doneGlobalLoading();
            app[this.handler].trigger("showError", window.localize("action.sendCombinedCollectionEmail.errorSendingEmail"), false);
		},
		checkStatus: function(data, responseData) {
			var self = this;
			if (data.percent === 100) {
				//remove the loading gif and show a success message
				app[this.handler].trigger("loading", false);
				// we want to stop the gray out affect of the startgloballoading call
				app.doneGlobalLoading();
				app[this.handler].trigger( "showMessage", window.localize("action.sendCombinedCollectionEmail.successfullySentEmail"));
			} else if (data.percent < 0) {
				app[this.handler].trigger("loading", false);
				// we want to stop the gray out affect of the startgloballoading call
				app.doneGlobalLoading();
				app[this.handler].trigger("showError", window.localize("action.sendCombinedCollectionEmail.errorAttachingDocsToEmail"), false);
			} else {
				//if we havent finished the action yet we want to check the satus again after a small wait
				setTimeout(function() {
					self.makeCheckStatusCall(responseData);
				}, SendCombinedCollectionEmail.TIMEOUT_DURATION);
			}
		},
		makeCheckStatusCall: function(responseData) {
			//ping asyncThread/status endpoint until action is complete
			// global:false here because we are handling our global loading on our own 
			// with startGlobalLoading and doneGlobalLoading so making this global true will 
			// cause a flickering affect
            $.ajax({
                url: app.serviceUrlRoot + "/asyncThread/status",
                method: "POST",
                global: false,
                data: {
                    uniqueId: responseData.result
				},
				context: this,
                success: _.partial(this.checkStatus, _, responseData),
				error: this.showError
            });
        }
	});

    actionModules.registerAction("sendCombinedCollectionEmail", SendCombinedCollectionEmail, {
        "actionId": "sendCombinedCollectionEmail",
        "ocActionId": "sendCombinedCollectionEmail",
        "label": window.localize("modules.actions.sendEmail.sendEmail"),
        "icon": "envelope"
	});
	
	return SendCombinedCollectionEmail;
});

require(["sendcombinedcollectionemail"]);