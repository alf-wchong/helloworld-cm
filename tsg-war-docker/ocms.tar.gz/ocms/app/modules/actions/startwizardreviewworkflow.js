define("startwizardreviewworkflow",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    function ViewModelWizardReviewStartAction(action, options, myHandler) {

        var self = this;

        self.objectId = action.get("parameters").objectId;
        self.isGroupBasedTask = options.isGroupBasedTask;
        self.parentGroup = options.parentGroup;

        self.filter = ko.observable('');
        self.modalHelpText = ko.observable('');
        if(self.isGroupBasedTask === "true"){
            self.modalHelpText(window.localize("action.startWizardReviewWorkflow.groupBasedEnabledMessage"));
        }
        else{
            self.modalHelpText(window.localize("action.startWizardReviewWorkflow.groupBasedDisabledMessage"));
        }

        self.userList = ko.observableArray([]); //userBeans array
        self.selectedUsers = ko.observableArray();
        self.selectedUsersToToss = ko.observableArray();
        self.selectedTossedUsers = ko.observableArray();
        self.usersSelected = ko.computed(function(){
            return self.selectedUsers() && self.selectedUsers().length > 0;
        });
        self.selectedUsers.valueHasMutated();
        self.filteredUsers = ko.observableArray([]);

        self.groupList = ko.observableArray([]); //groupBeans array
        self.selectedGroups = ko.observableArray();
        self.selectedGroupsToToss = ko.observableArray();
        self.selectedTossedGroups = ko.observableArray();
        self.groupsSelected = ko.computed(function(){
            return self.selectedGroups() && self.selectedGroups().length > 0;
        });
        self.selectedGroups.valueHasMutated();
        self.filteredGroups = ko.observableArray([]);

        self.usersOrGroupsSelected = ko.computed(function(){
            return self.usersSelected() || self.groupsSelected();
        })

        self.tossUsersRight = function() {
            if (self.selectedUsersToToss() !== undefined){
                ko.utils.arrayForEach(self.selectedUsersToToss(), function(item) {
                    //remove from user list
                    self.userList.remove(item);
                    //add to selected user list
                    self.selectedUsers.push(item);
                    //sort
                    self.selectedUsers.sort(function(left, right) { 
                        return (left.displayName < right.displayName ? -1 : 1); 
                    });

                });
                self.selectedUsersToToss([]);//reset selectedUsersToToss
                //reset filter
                self.filterUsers();
            }
        };

        self.tossUsersLeft = function() {
            if(self.selectedTossedUsers() !== undefined){
                ko.utils.arrayForEach(self.selectedTossedUsers(), function(item) {
                    //remove from selected user list
                    self.selectedUsers.remove(item);
                    //add to user list
                    self.userList.push(item);
                    //sort
                    self.selectedUsers.sort(function(left, right) { 
                        return (left.displayName < right.displayName ? -1 : 1); 
                    });
                });
                self.selectedTossedUsers([]);//reset selectedTossedUsers
                //reset filter
                self.filterUsers();
            }

        };

        self.tossGroupsRight = function() {
            if (self.selectedGroupsToToss() !== undefined){
                ko.utils.arrayForEach(self.selectedGroupsToToss(), function(item) {
                    //remove from user list
                    self.groupList.remove(item);
                    //add to selected user list
                    self.selectedGroups.push(item);
                    //sort
                    self.selectedGroups.sort(function(left, right) { 
                        return (left.displayName < right.displayName ? -1 : 1); 
                    });

                });
                self.selectedGroupsToToss([]);//reset selectedGroupsToToss
                //reset filter
                self.filterGroups();
            }
        };

        self.tossGroupsLeft = function() {
            if(self.selectedTossedGroups() !== undefined){
                ko.utils.arrayForEach(self.selectedTossedGroups(), function(item) {
                    //remove from selected user list
                    self.selectedGroups.remove(item);
                    //add to user list
                    self.groupList.push(item);
                    //sort
                    self.selectedGroups.sort(function(left, right) { 
                        return (left.displayName < right.displayName ? -1 : 1); 
                    });
                });
                self.selectedTossedGroups([]);//reset selectedTossedGroups
                //reset filter
                self.filterGroups();
            }

        };

        //load approval users from approval details
        self.getApprovalUsers = function() {

            $.ajax({
                url: app.serviceUrlRoot + "/aw-workflow/getPotentialApprovers?formId=" + self.objectId,
                type : "GET",
                success:function(approverList){
                    app[myHandler].trigger("loading", false);
                    if (self.userList() !== undefined){
                        var tempUserList = cloneArray(self.userList());
                        ko.utils.arrayForEach(tempUserList, function(item) {

                            //only auto-select reviewers if configured - if not configured, auto-select reviewers
                            if(!options.autoSelectReviewers || options.autoSelectReviewers === "true"){
                                //if users are in approval list, add to selected users list
                                $.each( approverList, function(index, val) {
                                    if(item.loginName === val.loginName) {
                                        if( $.inArray( item.loginName, self.selectedUsers() ) === -1){
                                            //add user
                                            self.selectedUsers.push(item);
                                            //remove from user list
                                            self.userList.remove(item);
                                        }
                                    }
                                } );
                            }
                        });
                        //reset filter
                        self.filterUsers();

                    }

                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app[myHandler].trigger("loading", false);
                    app[myHandler].trigger("showError",(window.localize("modules.actions.startWizardReviewWorkflow.failedToRetrieveApproval"))  + 
                        jqXHR.status + " " + jqXHR.statusText);
                }
            });
        };

        self.submitForm = function() {
            app[myHandler].trigger("loading", true);
            action.get("parameters").reviewerIds = self.getSelectedLoginNames();
            // Set the appRoot value so we can build up the email url properly
            action.get('parameters').appRoot = app.root;

            action.get('parameters').reviewerGroupIds = self.getSelectedGroupNames();

            action.get('parameters').isGroupBasedTask = self.isGroupBasedTask;

            action.execute({
                success : function(data) {
                    app[myHandler].trigger("loading", false);
                    app[myHandler].trigger("showMessage", (window.localize("modules.actions.startWizardReviewWorkflow.workflowStarted")));

                    app.listenToOnce(app[myHandler], "hide", function() {
                        app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
                    });
                },
                error : function(jqXHR, textStatus, errorThrown) {
                    app[myHandler].trigger("loading", false);
                    app[myHandler].trigger("showError", (window.localize("modules.actions.startWizardReviewWorkflow.failedToStart")) + jqXHR.responseText);
                }
            });
        };

        self.filterUsers = function(){
            var filter = self.filter().toLowerCase();
            if (filter === '') {
              //If there's no filter, return all users.
                self.filteredUsers(self.userList());
            } else {
                var users = [];
                ko.utils.arrayFilter(self.userList(), function(item) {
                    if ( item.displayName.toLowerCase().indexOf(filter) != -1 ) {
                        users.push(item);
                    }
                });

                self.filteredUsers(users);
            }
        };

        self.filterGroups = function(){
            var filter = self.filter().toLowerCase();
            if (filter === '') {
              //If there's no filter, return all groups.
                self.filteredGroups(self.groupList());
            } else {
                var groups = [];
                ko.utils.arrayFilter(self.groupList(), function(item) {
                    if ( item.displayName.toLowerCase().indexOf(filter) != -1 ) {
                        groups.push(item);
                    }
                });

                self.filteredGroups(groups);
            }
        };

        self.getSelectedLoginNames = function() {
            var arr = new Array(0);
            for(var i=0;i<self.selectedUsers().length;i++) {
                arr.push(self.selectedUsers()[i].loginName);
            }
            return arr;
        };

        self.getSelectedGroupNames = function() {
            var arr = new Array(0);
            for(var i=0;i<self.selectedGroups().length;i++) {
                //authority id will include the group prefix for alfresco
                arr.push(self.selectedGroups()[i].authorityId);
            }
            return arr;
        };

        self.fillUserArray = function(){
            app[myHandler].trigger("loading", true);
            $.ajax({
                url: app.serviceUrlRoot + "/aw-workflow/wizardContributors",//?formId=" + self.objectId,
                success: function(userBeanArray){
                    app[myHandler].trigger("loading", false);

                    //loop through the users
                    for(var i=0; i<userBeanArray.length; i++)
                    {
                        self.userList.push(
                            {
                                displayName : userBeanArray[i].displayName,
                                loginName : userBeanArray[i].loginName,
                                labelField : userBeanArray[i].displayName + " (" + userBeanArray[i].loginName + ")"
                            }
                        );                        
                    }
                    
                    self.getApprovalUsers();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app[myHandler].trigger("loading", false);
                    app[myHandler].trigger("showError", (window.localize("modules.actions.startWizardReviewWorkflow.failedToRetrieve")) + jqXHR.status + " " + jqXHR.statusText);
                }
            });
        };

        self.fillGroupArray = function(){
            app[myHandler].trigger("loading", true);
            $.ajax({
                url: app.serviceUrlRoot + "/groups",
                data: { parentGroup: self.parentGroup},
                success: function(groupBeanArray){
                    app[myHandler].trigger("loading", false);

                    //loop through the groups
                    for(var i=0; i<groupBeanArray.length; i++)
                    {
                        if(groupBeanArray[i])
                        self.groupList.push(
                            {
                                displayName : groupBeanArray[i].displayName,
                                authorityId : groupBeanArray[i].authorityId
                            }
                        );                        
                    }

                    self.filterGroups();
                    // self.getApprovalUsers();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    app[myHandler].trigger("loading", false);
                    app[myHandler].trigger("showError", (window.localize("modules.actions.startWizardReviewWorkflow.failedToRetrieve")) + jqXHR.status + " " + jqXHR.statusText);
                }
            });
        };
    }

    var cloneArray = function(arrayToClone) {
        var temp = [];
        ko.utils.arrayForEach(arrayToClone, function(item) {
            temp.push(item);
        });
        return temp;
    };

    action.View = Backbone.Layout.extend({
        template: "actions/startwizardreviewworkflow",
        defaults: {
            'autoSelectReviewers': "true",
            'allowGroupSelection': "false",
            'isGroupBasedTask': "false",
            'parentGroup': "wizard_contributors",

        },
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.myAllowGroupSelection = this.options.config.get("allowGroupSelection");
            this.isGroupBasedTask = this.options.config.get("isGroupBasedTask");
            // override any default properties with the configured values from the action config in the admin
            this.options = _.extend({}, this.defaults, this.options.config.attributes);

            //if parentGroup is left blank we wil use the default value of wizard_contributors
            this.options.parentGroup = this.options.parentGroup === "" ? 'wizard_contributors' : this.options.parentGroup;
        },
        beforeRender: function(){
            this.viewModel = new ViewModelWizardReviewStartAction(this.action, this.options, this.myHandler);
            this.viewModel.filter.subscribe(this.viewModel.filterUsers);
            this.viewModel.fillUserArray();

            if(this.myAllowGroupSelection === "true"){
                this.viewModel.filter.subscribe(this.viewModel.filterGroups);
                this.viewModel.fillGroupArray();
            }
            
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            var allowGroupSelection = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }

            if (this.myAllowGroupSelection === "true"){
                allowGroupSelection = true
            }

            return {
                modal : modal,
                rightSide : rightSide,
                allowGroupSelection : allowGroupSelection
            };
        }
    });

    // Custom config view for HPI admin configuration
    action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/startwizardreviewworkflow",

        initialize: function () {
            var viewModel = this.options.viewModel;

            //by default, auto-select reviewers is true
            viewModel.autoSelectReviewers = kb.observable(viewModel.model(), "autoSelectReviewers");

            viewModel.allowGroupSelection = kb.observable(viewModel.model(), "allowGroupSelection");
            viewModel.isGroupBasedTask = kb.observable(viewModel.model(), "isGroupBasedTask");
            viewModel.parentGroup = kb.observable(viewModel.model(), "parentGroup");

            //default to true
            if(viewModel.autoSelectReviewers() === null){
                //this must be stringified boolean to render the slider correctly
                viewModel.autoSelectReviewers("true");
            }

            if(viewModel.allowGroupSelection() === null){
                viewModel.allowGroupSelection("false");
            }

            if(viewModel.isGroupBasedTask() === null){
                viewModel.isGroupBasedTask("false");
            }
            
        },
        afterRender: function () {
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    actionModules.registerAction("startWizardReviewWorkflow", action, {
        "actionId" : "startWizardReviewWorkflow",
        "label" : "Start Review Workflow",
        "icon" : "chevron-right",
        "groups" : ["wizard", "start", "review", "streamline"]
    });

    return action;
});
require(["startwizardreviewworkflow"]);