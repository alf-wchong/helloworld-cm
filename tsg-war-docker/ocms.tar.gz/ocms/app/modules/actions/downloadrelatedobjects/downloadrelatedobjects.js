define("downloadrelatedobjects", [
		// Application.
		"app",
		"modules/actions/actionmodules",
		"foldertree",
		"modules/common/action",
		"modules/common/downloadutils"
	],

	// Map dependencies from above array.
	function (app, actionModules, FolderTree, Action, downloadUtils) {
		"use strict";

		var action = {};

		action.DELIMITER = "~|~";

		action.View = Backbone.Layout.extend({
			template: "actions/downloadrelatedobjects/downloadrelatedobjects",
			events: {
				"change .relatedObjectZipCheckbox": "relatedObjectChecked",
				"click #submitDownloadRelatedObjects": "submit",
				"keyup #downloadRelatedObjectsFilename": "checkValidity",
				"change .relatedObjectZipCheckboxChangeAll": "toggleAllCheckboxes"
			},
			initialize: function () {
				this.action = this.options.action;
				this.myHandler = this.options.config.get("handler");

				// this set will hold all of the ids we eventually will send to be combined
				// into a zip
				this.idsToCombine = new StringSet();
				this.objectIdsWithSections = new StringSet();

				this.relationTypes = app.context.currentStageConfig().get("relatedObjectsConfig").get("relationTypes");

				// kick off setup
				this.setUpRelatedObjects();
			},

			setUpRelatedObjects: function () {
				var self = this;

				// the individual configs - we need these to add all objectIds to the set initially
				this.relatedObjectsConfigs = [];

				// our deferreds for the querys
				var relatedObjectsConfigDefs = [];

				// create a relation view model for each relation configured from the admin
				this.relationTypes.each(function (relationConfig) {


					// only supporting relation based configs at this point
					// or those that don't use folder tags (the second level stuff there creates
					// complications)
					if (relationConfig.get("relationConfigType") === "relationBasedTemplate" ||

						// we can have query based sections, as long as the "optionsExpandWithTags" option
						// is false.  we also need to make sure that it isn't a "folderTagsTemplate" because
						// that renders the previous config check moot
						(relationConfig.get("relationConfigType") !== "folderTagsTemplate" &&
							relationConfig.get("optionsExpandWithTags") === "false")) {

						var relationVM = new FolderTree.ViewModel(relationConfig, app.context.currentAdminOTC());

						// turning this into an actual boolean so that handlebars can evaluate it
						relationVM.options.shouldHideEmptyRelations = relationVM.options.shouldHideEmptyRelations === "true";

						// adding the config if we are going to use it
						self.relatedObjectsConfigs.push(relationVM);

						// we are using this function from the FolderTree module since it "conveniently"
						// returns a deferred for us
						relatedObjectsConfigDefs.push(FolderTree._queryRelated(relationVM, relationConfig));
					}
				});


				// wait for all deferreds to be resolved
				$.when.apply(null, relatedObjectsConfigDefs).done(function () {
					// then render
					self.render();
				});
			},

			submit: function () {
				// needed for the callback
				var self = this;

				var parameters = {};

				// turning our set into an array as is expected on OC.
				parameters.objectIds = this.idsToCombine.values();
				parameters.objectIdsWithSections = this.objectIdsWithSections.values();

				// getting the file name input by the user
				parameters.fileName = $("#downloadRelatedObjectsFilename").val() + ".zip";

				// this will be the setting. maybe make configurable?
				parameters.useRenditionsIfPossible = true;

				var action = new Action.Model({
					name: "downloadAsZip",
					parameters: parameters
				});

				downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, _.bind(self._callback, self));
			},

			// for unit testing purposes
			_callback: function () {
				app[this.myHandler].trigger("showMessage", window.localize("modules.actions.folderNotes.theNotesFile"));
			},

			relatedObjectChecked: function (e) {
				var section = e.currentTarget.getAttribute("section");
				// adding or removing individually checked objects
				var objectId = e.currentTarget.getAttribute("objId");
				if (e.currentTarget.checked) {
					this.idsToCombine.add(objectId);
					this.objectIdsWithSections.add(objectId + action.DELIMITER + section);
				} else {
					this.idsToCombine.delete(objectId);
					this.objectIdsWithSections.delete(objectId + action.DELIMITER + section);
				}

				this.checkValidity();
			},

			toggleAllCheckboxes: function (e) {
				var self = this;
				var checkboxes = $("." + e.currentTarget.id);
				var isChecked = e.currentTarget.checked;
				checkboxes.each(function () {
					self._toggleCheckbox(this, isChecked, self);
				});

				if (isChecked) {
					$("#individualDocsTable" + e.currentTarget.id).hide();
				} else {
					$("#individualDocsTable" + e.currentTarget.id).show();
				}
				this.checkValidity();
			},

			_toggleCheckbox: function (elem, isChecked, self) {
				var section = $(elem).attr("section");
				var id = $(elem).attr("objid");
				$(elem).attr("checked", isChecked);

				// the checkall box won't have an objid, so we don't wanna try to add/remove
				// it from our set
				if (id) {
					if (isChecked) {
						self.idsToCombine.add(id);
						self.objectIdsWithSections.add(id + action.DELIMITER + section);
					} else {
						self.idsToCombine.delete(id);
						self.objectIdsWithSections.delete(id + action.DELIMITER + section);
					}
				}
			},

			// helper function that ensures that we have at least 1 file checked (not sure that's a
			// real use case) and that the file name is populated
			checkValidity: function () {
				var filename = $("#downloadRelatedObjectsFilename").val();
				if (filename.length > 0 && this.idsToCombine.values().length > 0) {
					$("#submitDownloadRelatedObjects").prop("disabled", false);
				} else {
					$("#submitDownloadRelatedObjects").prop("disabled", true);
				}
			},

			afterRender: function () {
				// since we are defaulting to having all related objects checked, we need to make
				// sure to add them to our 'idsToCombine' variable
				_.each(this.relatedObjectsConfigs, function (config) {
					config.sanitizedName = config.label.replace(/ /g, "_");
					_.each(config.query.models, function (model) {
						this.idsToCombine.add(model.get("properties").objectId);
						this.objectIdsWithSections.add(model.get("properties").objectId + action.DELIMITER + config.label);
					}, this);
				}, this);
			},

			serialize: function () {
				return {
					modal:  this.myHandler === "modalActionHandler",
					rightSide: this.myHandler === "rightSideActionHandler",
					relatedObjectConfigs: this.relatedObjectsConfigs
				};
			}
		});

		// using this "StringSet" funciton because the native JavaScript Set() class is not
		// in our version of Jasmine (as of 6/24/2019)
		function StringSet() {
			var setObj = {},
				val = {};

			this.add = function (str) {
				setObj[str] = val;
			};

			this.delete = function (str) {
				delete setObj[str];
			};

			this.values = function () {
				var values = [];
				for (var i in setObj) {
					if (setObj[i] === val) {
						values.push(i);
					}
				}
				return values;
			};
		}


		actionModules.registerAction("downloadRelatedObjects", action, {
			"actionId": "downloadRelatedObjects",
			"label": "Export Related Documents",
			"icon" : "download"
		});

		return action;
	});
require(["downloadrelatedobjects"]);
