define("viewlocations", [
	"app",
	"modules/formsupport",
	"modules/hpiadmin/otc/objecttypeconfig",
	"modules/actions/actionmodules"
],
function(app, Formsupport, OTC, actionModules) {
	
	"use strict";

	var action = {};

	action.LinkView = Backbone.Layout.extend({
		template: "actions/viewlocationslink",
		initialize: function(){
			this.url = null;
			//build correct url
			if(this.options.trac){
				this.url = "Stage/" + this.options.trac + "/" + this.options.objectId;
			}
			// if they didn't supply a trac we will stay on the same trac (if we are on stage)
			else {
				this.url = "Stage/" + app.context.configName() + "/" + this.options.objectId;
			}
		},
		serialize: function(){
			return{
				url: this.url,
				path: this.options.path
			};
		}
	});

	action.View = Backbone.Layout.extend({
		template: "actions/viewlocations",
		initialize: function(){
			var self = this;
			this.resolveToTrac = this.options.config.get("trac");
			this.pathViews = [];
			this.myHandler = this.options.config.get("handler");

			if(!this.options.action.get("parameters").objectId){
				app[this.myHandler].trigger("showError", "Sorry, an error has occured. There is no objectId.");
			}
			else{
				this.options.action.execute({
					success: function(data){
						_.each(data.result, function(object){
							var tempView = new action.LinkView({objectId: object.id, path: object.path, trac: self.resolveToTrac});
							self.insertView('.viewlocations-linklist', tempView);
							self.pathViews.push(tempView);
						});
						if(self.hasRendered){
							self.render();
						}
					}
				});
			}
		},
		afterRender: function(){
			this.hasRendered = true;
		},
		serialize: function(){
			var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide
			};
		}
	});

	// Custom config view for HPI admin configuration
	action.CustomConfigView = Backbone.Layout.extend({
		template: "actions/viewlocationsconfig",
		initialize: function(){
			var viewModel = this.options.viewModel;

			viewModel.trac = kb.observable(viewModel.model(), "trac");
			var tracSubscribePlaceholder = viewModel.trac();
			viewModel.potentialTracs = ko.observableArray();
			app.context.configService.getTracConfigs(function(tracConfig) {
				var tracOptions = tracConfig.pluck("name");
				tracOptions.unshift("");
				viewModel.potentialTracs(tracOptions);
				//since the form value is bound from the potentialTracs observable,
				//this context call will come back after the form has been gathered
				//from the config. this resets the form to the right value.
				viewModel.trac(tracSubscribePlaceholder);
			});
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("viewLocations", action, {
		"actionId" : "viewLocations",
		"label" : "View Locations",
		"icon" : "search"
	});

	return action;

});
require(["viewlocations"]);
