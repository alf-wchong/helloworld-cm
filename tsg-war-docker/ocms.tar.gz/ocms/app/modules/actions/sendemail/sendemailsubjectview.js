define([
    "app",
    "oc"
], function (app, OC) {
    var SubjectView = {};

    SubjectView.View = Backbone.Layout.extend({
        template: "actions/sendemail/sendemailsubject",
        events: {
            "blur #send-email-subject": "onSubjectBlur"
        },
        initialize: function (config) {
            this.parent = config.options;
            this.model = config.options.model;
            this.subjectPrefix = "";
            this.subjectText = "";
            this.isSubjectEditable = true;

            // Check if we have a configured subject prefix for this folder type
            this.subjectPrefixConfig = this.model.subjectPrefixes[app.context.container.get('objectType')];
            // since this used to just be a string, we'll verify that it's now an object
            if(this.subjectPrefixConfig && this.subjectPrefixConfig instanceof Object) {
                this.isSubjectEditable = this.subjectPrefixConfig.isSubjectPrefixEditable;
                this.subjectPrefixPattern = this.subjectPrefixConfig.pattern;
                
                // if we have a configured subject prefix pattern, build it up and apply it
                if (this.subjectPrefixPattern) {
                    this.formatFolderTypeAttrConfigs()
                        .done(_.bind(this.generateSubjectPrefix, this))
                        // render because formatFolderTypeAttrConfigs is async and we may have already rendered
                        .done(_.bind(this.render, this));
                }
            }
        },

        /**
         * Method to create the configured subject prefix
         * @param {Object} formattedFolderProperties the folder's OpenContentObject formatted properties map
         */
        generateSubjectPrefix: function (formattedFolderProperties) {
            this.formattedFolderProperties = formattedFolderProperties;
            this.prefixObjectTypes = app.context.util.parsePatternForAttributes(this.subjectPrefixPattern);
            var subjectPrefixArray = this.subjectPrefixPattern.split('$');
            _.each(subjectPrefixArray, this.addPatternSubstringToPrefix, this);
			this.subjectText = this.subjectPrefix;
			this.model.emailInfoModel.set("subject", this.subjectPrefix);
        },

        /**
         * Method to fetch formatted folder properties
         */
        formatFolderTypeAttrConfigs: function () {
            return OC._formatValues(app.context.container, {});
        },

        /**
         * Method to parse folder property patterns into values and add substring to the subject prefix
         * @param {String} patternSubstring the current substring of the prefix pattern
         */
        addPatternSubstringToPrefix: function (patternSubstring) {
            var prefixSubstring = patternSubstring;
            // if the substring is a folder prop placeholder, grab its value
            if (_.contains(this.prefixObjectTypes, patternSubstring)) {
                prefixSubstring = "";
                var folderProp = this.formattedFolderProperties[patternSubstring];
                if (folderProp) {
                    prefixSubstring = folderProp;
                }
            }

            this.subjectPrefix += prefixSubstring;
        },

        /**
         * Method to set the subject text on the view and emailInfoModel.
         * @param {String} subjectText the current value of the subject input field
         */
        setSubjectText: function (subjectText) {
            this.subjectText = subjectText;
            var fullSubjectText = this.subjectText;

            // if the subject prefix is uneditable, we need to add the prefix
            // we don't do this if the subject is editable since the user could have changed the prefix
            if (!this.isSubjectEditable) {
                fullSubjectText = this.subjectPrefix + subjectText;
            }

            this.model.emailInfoModel.set("subject", fullSubjectText);
        },

        /**
         * Method to validate the length of the subject text on the emailInfoModel. 
         * TODO move validate methods to the SendEmail.Models.EmailInfoModel
         */
        validateSubject: function () {
            var fullSubjectLength = this.model.emailInfoModel.get('subject').length;
            return fullSubjectLength > 0 && fullSubjectLength <= this.model.maxLength;
        },

        /**
         * Event handler to update view state with user input.
         * Updates and validates subject text and displays error message accordingly.
         */
        onSubjectBlur: function () {
            this.setSubjectText(this.$("#send-email-subject").val().trim());

            if (!this.validateSubject()) {
                this.$(".error-message-" + this.cid).show();
                this.$("#send-email-subject").addClass('bs-callout-basic bs-callout-warning');
            } else {
                this.$(".error-message-" + this.cid).hide();
                this.$("#send-email-subject").removeClass('bs-callout-basic bs-callout-warning');
            }

            // we need to revalidate the form when the subject changes
            this.parent.canSubmit();
        },

        serialize: function () {
            return {
                cid: this.cid,
                subjectPrefix: this.subjectPrefix,
                subjectText: this.subjectText,
                isSubjectEditable: this.isSubjectEditable,
                // calling parseInt here, preventing cross site scripting vulnerability from admin
                maxLength: parseInt(this.model.maxLength, 10)
            };
        }
    });

    return SubjectView;
});