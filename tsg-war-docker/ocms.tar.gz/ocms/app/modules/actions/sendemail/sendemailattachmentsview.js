define([
	"app",
	"modules/common/typeahead",
	"modules/actions/selectversionview",
	'modules/common/hpiconstants',
	"modules/common/ocquery",
	"oc",
	"modules/actions/sendemail/sendemailutil",
	"modules/common/spinner",
	"tsgUtils"
], function (app, HPITypeAhead, SelectVersion, HPIConstants, Query, OC, SendEmailUtil, Spinner, TSGUtils) {
	// Attachments view - having this in the main view was causing a lot of
	// rendering issues, so isolating this into it's own view helps

	var SendEmailAttachmentsView = {};

	SendEmailAttachmentsView.Constants = {
		FOLDER_ATTACHMENT_ACTIVE: "folderAttachmentActive",
		ATTACHED_ACTIVE: "attachedActive"
	};

	SendEmailAttachmentsView.View = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailattachments",
		events: {
			"change .checkFolderAttachment": "addSelectedAttachmentFromList",
			"click .removeDocument": "removeAttachedDocument",
			"click #attachedDocsTab": "showAttachedDocsTab",
			"click .checkCollectionAttachment": "addCollectionAttachmentDoc",
			"click .removeCollectionDocument": "removeCollectionAttachedDocument",
			"click .folderAttachment": "launchItemExternally",
			"click .collectionAttachment": "launchItemExternally",
			"click .selectedAttachment": "launchItemExternally",
			"click #attachmentTab": "triggerShowAttachmentTab",
			"click .selectedAttachmentVersion": "triggerSelectAttachmentVersion",
			"show.bs.collapse #attachments": "triggerAttachmentsShowHandler",
			"hide.bs.collapse #attachments": "triggerAttachmentsHideHandler"
		},

		initialize: function (config) {
			this.parent = config.options;
			this.pending = true;
			this.showFolderDocs = false;
			this.showAttachedTab = false;
			this.showCollectionDocs = false;
			this.attachments = [];
			this.attachedDocs = new Backbone.Collection();
			this.collectionAttachments = [];
			this.attachedCollectDocs = new Backbone.Collection();
			this.model = config.options.model;
			this.hideNoResultMessage = config.options.hideNoResultMessage;
			this.attributesToDisplay = this.model.attributesToDisplay;
			this.maxTotalAttachmentsSize = this.options.config.get('maxTotalAttachmentsSize');
			this.totalAttachmentSize = 0;
			this.tabState = {
				folderAttachmentActive: true,
				collectionAttachmentActive: false,
				attachedActive: false,
				sharefileActive: false
			};
			this.isExpanded = false;

			this.createCollectionTypeAhead();
			this.startListening();
		},

		createCollectionTypeAhead: function () {
			var deferredCollections = this.getSource();
			this.collectionTypeahead = new HPITypeAhead({
				options: this.model.collectionResults,
				enterKeys : this.enterKeys,
				displayKey: 'objectName',
				searchOn: 'objectName',
				loading: deferredCollections,
				hideNoResultMessage: this.hideNoResultMessage,
				overrideLoading: true
			});
		},

		startListening: function () {
			var self = this;
			this.listenTo(this.collectionTypeahead, 'change:selected', function (option) {
				if (option) {
					self.loadCollectionDocuments(option);
				}
			});
		},

		// this updates the CSS on the attachments slide down div so that the overflow is visible when the attachments
		// div is expanded - this makes sure the dropdown for collections appears above the text area for entering the email body
		triggerAttachmentsShowHandler: function () {
			this.isExpanded = true;
			this.$("#attachments").css("overflow", "visible");
		},

		// this updates the CSS on the attachments slide down div so that the overflow is hidden when the attachments
		// div STARTS to be hidden - this gives a much more intuitive look to the div sliding away into nothing
		triggerAttachmentsHideHandler: function () {
			this.isExpanded = false;
			this.$("#attachments").css("overflow", "hidden");
		},

		/**
		 * Handler for clicks on a version cell in the attachment table.
		 * Creates select version view and renders it based on the configured action handler.
		 * @param {Event} event the click event
		 */
		triggerSelectAttachmentVersion: function (event) {
			// get the attachmentModel and selected version label for this row
			var selectedAttachmentId = $(event.currentTarget).attr("data-id");
			var selectedAttachmentVersionLabel = $(event.currentTarget).attr("data-version");
			var attachmentModel = this.attachedDocs.findWhere({
				objectId: selectedAttachmentId
			});
			// If the action is configured for the RSAH, then we can use a modal instead of a popover
			var mode = this.model.handler === HPIConstants.Handlers.RightSideActionHandler ? HPIConstants.Modal : HPIConstants.Popover;
			this.selectAttachmentVersionView = new SelectVersion.View({
				mode: mode,
				objectId: attachmentModel.get('workingCopyId'),
				objectIds: [attachmentModel.get('workingCopyId')],
				objectName: attachmentModel.get('objectName'),
				selectedVersionLabel: selectedAttachmentVersionLabel,
				persistSelectedVersions: this.updateSelectedVersion,
				callbackContext: this
			});

			this.listenTo(this.selectAttachmentVersionView, "selectVersionView:closed", this.removeSelectAttachmentVersionView);

			if (mode === HPIConstants.Modal) {
				this.setView("#select-version-modal-outlet", this.selectAttachmentVersionView).render();
			} else {
				app.popoverHandler.trigger("show", {
					view: this.selectAttachmentVersionView,
					title: window.localize("modules.actions.advancedCombineToPDF.selectVersionModal.title"),
					size:  HPIConstants.ModalSizes.Small
				});

				// extend the popover container to the full viewport height
				$('.popover.in').height('100vh');
			}
		},

		/**
		 * Function to remove the selectAttachmentVersionView.
		 */
		removeSelectAttachmentVersionView: function() {
			// get rid of the selectAttachmentVersionView modal
			this.removeView("#select-version-modal-outlet");
			this.stopListening(this.selectAttachmentVersionView);
			delete this.selectAttachmentVersionView;
		},

		/**
		 * Function called when a user selects a version in the SelectVersion view.
		 * This function calls getAttachmentData for the selected version and updates the attachment table if the selected
		 * version has not changed.
		 * @param {Object} selectedVersion an object representing the user's version selection. Contains versionLabel and selectedVersionId
		 */
		updateSelectedVersion: function (selectedVersion) {
			this.removeSelectAttachmentVersionView();

			var attachmentModel = this.attachedDocs.findWhere({
				workingCopyId: selectedVersion.workingCopyId
			});

			// has the selected version changed?
			if(selectedVersion.versionLabel !== attachmentModel.get('versionLabel')) {
				attachmentModel.set('versionLabel', selectedVersion.versionLabel);
				// update the objectId so the attachment link preview shows the selected version
				attachmentModel.set('objectId', selectedVersion.selectedVersionId);
	
				var getAttachmentDataOptions = {
					model: this.model,
					ids: [selectedVersion.selectedVersionId],
					isOcoFetchGlobal: true,
					ocoFetchErrorCallback: this.onFetchAttachmentDataError,
					fetchContentSizeErrorCallback: this.onFetchContentSizeError,
					attachmentDataFetchSuccessCallback: _.partial(this.updateAttachmentModelContentSize, attachmentModel),
					context: this
				};
	
				if(!this.model.shouldTrackAttachmentSize) {
					getAttachmentDataOptions.ocoFetchSuccessCallback = _.partial(this.updateAttachmentModelFromOcoProperties, attachmentModel);
				}
	
				var getAttachmentDataDeferred = SendEmailUtil.getAttachmentData(getAttachmentDataOptions);
	
				// since jquery done callbacks are called in the order in which they are added,
				// updateAttachmentModelContentSize will execute, followed by render
				// have to bind in case shouldValidateTotalAttachmentsSize is true, in which case, this will be an array of contexts..
				getAttachmentDataDeferred.done(_.bind(this.render, this));
			}
		},

		/**
		 * Called when the getAttachmentData $.when deferred has resolved.
		 * Used in the case where shouldValidateTotalAttachmentsSize is true.
		 * @param {Backbone.Model} attachmentModel the model representing the current attachment
		 * @param {Array} ocosPromiseArray the array containing the ocos the fetchOcos deferred was resolved with
		 * @param {Array} contentInfoPromiseArray the array containing the contentInfo the fetchContentSizeCollection was resolved with
		 */
		updateAttachmentModelContentSize: function (attachmentModel, ocosPromiseArray, contentInfoPromiseArray) {
			// these arrays contain the result of their respective ajax calls as the first param 
			var selectedVersionOcoArray = ocosPromiseArray[0];
			var contentSizesArray = [];
			_.each(contentInfoPromiseArray[0], function(contentInfo) {
				var contentSizeMap = {
					size: contentInfo.contentSizes[0],
					id: contentInfo.objectId
				};
				contentSizesArray.push(contentSizeMap);
			});

			this.updateAttachmentModelFromOcoProperties(attachmentModel, selectedVersionOcoArray);
			this.updateAttachmentContentSizeData(attachmentModel, contentSizesArray);
		},

		/**
		 * Updates the attachment's model from the given version's OpenContentObject
		 * @param {Backbone.Model} attachmentModel the model representing the current attachment
		 * @param {Array} selectedVersionOcoArr an array containing the oco for the selected version
		 */
		updateAttachmentModelFromOcoProperties: function (attachmentModel, selectedVersionOcoArr) {
			var selectedVersionOcoObj = selectedVersionOcoArr[0];
			// update name, size, and attributes to display
			attachmentModel.set('objectName', selectedVersionOcoObj.properties.objectName);
			var self = this;

			// the admin object type config will be cached so we're treating this as synchronous
			app.context.configService.getAdminOTC(function (otc) {
				SendEmailUtil.setAttributesToDisplay(otc, selectedVersionOcoObj, self.model.attributesToDisplay);
				attachmentModel.set('attributesToDisplay', selectedVersionOcoObj.attributesToDisplay);
			});
		},

		/**
		 * Updates the totalAttachmentSize and attachmentModel with the updated size in contentSizeArray.
		 * @param {Backbone.Model} attachmentModel the model representing the current attachment
		 * @param {Array} contentSizeArray an array containing an object with the size and objectId of the selected version
		 */
		updateAttachmentContentSizeData: function (attachmentModel, contentSizeArray) {
			// remove the current version size from the totalAttachmentSize
			this.totalAttachmentSize = this.totalAttachmentSize - attachmentModel.get('sizeInMB');
			// update the content size collection
			var attachmentSizeModel = new Backbone.Model(contentSizeArray[0]);
			this.parent.contentSizeCollection.push(attachmentSizeModel);
			this.setAttachmentContentSize(attachmentModel, attachmentSizeModel);
			this.totalAttachmentSize += attachmentModel.get('sizeInMB');

			this.trigger('totalAttachmentsSize:updated');
		},

		/**
		 * Function that adds required sizing data (size, sizeLabel, sizeInMB, displaySize) to the attachment model.
		 * @param {Backbone.Model} attachmentModel model representing the current attachment
		 * @param {Backbone.Model} attachmentSizeModel model containing size and object id for the current attachment
		 */
		setAttachmentContentSize: function (attachmentModel, attachmentSizeModel) {
			var contentSizeInBytes = attachmentSizeModel.get('size');
			var attachmentSizeInMB = TSGUtils.getFileSizeAsMegabytes(contentSizeInBytes);
			var attachmentSizeLabel = TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE;
			var displaySize = parseFloat(attachmentSizeInMB.toPrecision(2));

			// If the file is less than 1MB, show KB instead
			if (attachmentSizeInMB < 1) {
				var attachmentSizeInKB = TSGUtils.getFileSizeAsKilobytes(contentSizeInBytes);
				attachmentSizeLabel = TSGUtils.FILE_SIZE_ABBREVIATIONS.KILOBYTE;
				displaySize = parseFloat(attachmentSizeInKB.toPrecision(2));
			}

			attachmentModel.set('sizeLabel', attachmentSizeLabel);
			attachmentModel.set('sizeInMB', attachmentSizeInMB);
			attachmentModel.set('displaySize', displaySize);
		},

		launchItemExternally: function (e) {
			var attachmentId = $(e.currentTarget).data("id");
			var attachmentName = $(e.currentTarget).data("displayname");
			window.open(app.serviceUrlRoot + "/content/content/" + encodeURIComponent(attachmentName) +
				"?id=" + attachmentId + "&overlay=true" + "&contentType[]=" + ["pdf", "txt", ".*"]);
		},

		addSelectedAttachmentFromList: function (e) {
			var index = $(e.currentTarget).data("id");
			this.options.previousPosition = $(".modal.in").scrollTop();
			this.addSelectedAttachment(this.attachments[index]);
		},

		addSelectedAttachment: function (attachment, fromGroupAction) {
			var attachmentId = attachment.properties.objectId;
			this.showFolderDocs = !this.attachedDocs.isEmpty();

			if (!attachment) {
				app.log.error((window.localize("modules.actions.sendEmail.withId")) + attachmentId);
			}

			// if this document is already checked, remove it
			if (attachment.checked) {
				this.removeAttachedDocument(null, attachmentId);
			} else {
				//otherwise, add it to the attachedDocs collection
				var attachmentModel = new Backbone.Model({
					objectId: attachmentId,
					objectName: attachment.properties.objectName,
					attributesToDisplay: attachment.attributesToDisplay
				});
				var attachmentSizeModel = this.parent.contentSizeCollection.findWhere({
					id: attachmentId
				});

				if (this.model.isSelectAttachmentVersionEnabled) {
					attachmentModel.set('versionLabel', attachment.properties.versionLabel);
					attachmentModel.set('workingCopyId', attachmentId);
				}

				// If configured, get the attachment size on the model and add it to the total attachment size
				if (this.model.shouldTrackAttachmentSize && attachmentSizeModel) {
					this.setAttachmentContentSize(attachmentModel, attachmentSizeModel);
					this.totalAttachmentSize += attachmentModel.get('sizeInMB');
					this.trigger('totalAttachmentSize:updated');
				}
				this.attachedDocs.push(attachmentModel);

				// make sure the attached doc is checked
				attachment.checked = true;
				this.showAttachedTab = true;
				var tabToActivate = !fromGroupAction ? SendEmailAttachmentsView.Constants.FOLDER_ATTACHMENT_ACTIVE : SendEmailAttachmentsView.Constants.ATTACHED_ACTIVE;
				this.activateTab(tabToActivate);
				this.render();
			}
		},

		removeAttachedDocument: function (e, objectId) {
			var attachmentId = objectId || $(e.currentTarget).data("id");
			var removedAttachment = this.attachedDocs.remove(this.attachedDocs.findWhere({
				objectId: attachmentId
			}));

			if (this.model.shouldTrackAttachmentSize) {
				this.totalAttachmentSize = this.totalAttachmentSize - removedAttachment.get('sizeInMB');
			}
			//if we are removing the last attached doc, go back to the folder attachment tab and we do not want to hide the available docs tab
			if (this.attachedDocs.length === 0 && this.attachedCollectDocs.length === 0 && !this.model.hideAvailableDocsTab) {
				this.showAttachedTab = false;
				this.activateTab(SendEmailAttachmentsView.Constants.FOLDER_ATTACHMENT_ACTIVE);
				// Remove reference to previous position, render and bring user top of documents list
				this.options.previousPosition = null;
				//if we are removing from the folder attachment tab
			} else if (objectId) {
				this.activateTab(SendEmailAttachmentsView.Constants.FOLDER_ATTACHMENT_ACTIVE);
				//if we are removing from the attached tab and there are still more attachments, stay on this tab
			} else {
				this.activateTab(SendEmailAttachmentsView.Constants.ATTACHED_ACTIVE);
			}

			// check if we are not hiding the available docs tab - if so we won't have an attachments list to set checked false on
			if (!this.model.hideAvailableDocsTab) {
				//make sure the attached doc is checked
				var index = _.indexOf(_.pluck(this.attachments, "objectId"), attachmentId);
				this.attachments[index].checked = false;
			}
			this.render();
		},

		addCollectionAttachmentDoc: function (e) {
			var index = $(e.currentTarget).data("id");
			var attachment = this.collectionAttachments[index];
			var attachmentId = attachment.properties.objectId;
			var attachmentName = attachment.properties.objectName;
			if (this.attachedCollectDocs.length !== 0) {
				this.showCollectionDocs = true;
			} else {
				this.showCollectionDocs = false;
			}
			//if this document is already checked, remove it
			if (this.collectionAttachments[index].checked) {
				this.removeCollectionAttachedDocument(null, attachmentId);
			} else {
				//otherise, add it to the attachedDocs collection
				var attachmentModel = new Backbone.Model();
				attachmentModel.set("objectId", attachmentId);
				attachmentModel.set("objectName", attachmentName);
				attachmentModel.set("attributesToDisplay", attachment.attributesToDisplay);
				this.attachedCollectDocs.push(attachmentModel);

				//make sure the attached doc is checked
				this.collectionAttachments[index].checked = true;

				this.showAttachedTab = true;
				this.activateTab("collectionAttachmentActive");
				this.render();
			}
		},

		removeCollectionAttachedDocument: function (e, objectId) {
			var attachmentId = objectId || $(e.currentTarget).data("id");
			this.attachedCollectDocs.remove(this.attachedCollectDocs.findWhere({
				objectId: attachmentId
			}));
			//if we are removing the last attached doc, go back to the folder attachment tab
			if (this.attachedDocs.length === 0 && this.attachedCollectDocs.length === 0) {
				this.showAttachedTab = false;
				this.activateTab("collectionAttachmentActive");
				//if we are removing from the collection attachment tab
			} else if (objectId) {
				this.activateTab("collectionAttachmentActive");
				//if we are removing from the attached tab and there are still more attachments, stay on this tab
			} else {
				this.activateTab(SendEmailAttachmentsView.Constants.ATTACHED_ACTIVE);
			}

			//make sure the attached doc is checked
			var index = _.indexOf(_.pluck(this.collectionAttachments, "objectId"), attachmentId);
			this.collectionAttachments[index].checked = false;
			this.render();
		},

		addCollectDocument: function () {
			var collectionDoc = {
				objectId: this.objectId,
				objectName: this.properties.objectName
			};
			for (var x = 0; x < this.attachedCollectDocs().length; x++) {
				if (this.attachedCollectDocs()[x].objectId === this.objectId) {
					this.attachedCollectDocs.splice(x, 1);
					return true;
				}
			}
			this.attachedCollectDocs.push(collectionDoc);
			return true;
		},
		
		removeAttachedCollectDocument: function () {
			this.attachedCollectDocs.remove(this);
			if (this.attachmentsView.attachedDocs.length === 0 && this.attachedCollectDocs.length === 0) {
				this.showAttachedTab = false;
				this.trigger("sendEmail:showAttachedTab");
				$('#attachmentTab li:eq(1) a').tab('show');
			}
			var id = "#collectionCheckBox-" + this.objectId;
			if ($(id).length) {
				$(id).prop('checked', false);
			}
		},

		/**
		 * Event handler to display the attached documents tab
		 */
		showAttachedDocsTab: function () {
			this.showFolderDocs = !this.attachedDocs.isEmpty();
			this.showCollectionDocs = !this.attachedCollectDocs.isEmpty();
			this.activateTab(SendEmailAttachmentsView.Constants.ATTACHED_ACTIVE);
			this.render();
		},

		activateTab: function (tab) {
			this.tabState = {
				folderAttachmentActive: false,
				collectionAttachmentActive: false,
				attachedActive: false,
				sharefileActive: false
			};
			this.tabState[tab] = true;
		},

		getSource: function (event) {
			//only kick off ajax search if we need to
			var self = this;

			var collectObjects = {
				paramName: "Collection",
				paramValue: "Collection",
				paramType: "type"
			};

			var collectionType = {
				paramName: "hpi_collectionVisibility",
				paramValue: self.model.collectionType,
				paramType: "property",
				operator: "OPERATOR_EQUALS"
			};

			var textInput = {
				paramName: "objectName",
				paramValue: "*",
				paramType: "property",
				operator: "LOGIC_LIKE"
			};

			var availableCollections = new Query.Collection([], {
				mode: "client"
			});
			availableCollections.searchParameters = [];
			availableCollections.searchParameters.push(collectObjects);
			availableCollections.searchParameters.push(collectionType);
			availableCollections.searchParameters.push(textInput);

			var deferredCollections = $.Deferred();
			availableCollections.fetch({
				success: function (queryResults) {
					//map collection names to id's
					self.model.collectionResults = [];
					_.each(queryResults.fullCollection.models, function (result) {
						self.model.collectionResults.push({
							"objectName": result.get("properties").objectName,
							"objectId": result.get("properties").objectId
						});
					});
					deferredCollections.resolve(self.model.collectionResults);
				}
			});

			return deferredCollections.promise();
		},

		loadCollectionDocuments: function (item) {
			var self = this;
			var collectionId;
			if (item) {
				this.model.chosenCollection = item.objectName;
				collectionId = item.objectId;
			}

			var oCObject = new OC.OpenContentObject({
				objectId: collectionId
			});

			if (!app.collectionRelation) {
				app.log.error((window.localize("modules.actions.sendEmail.theRelation")));
			}
			var jqxhr = oCObject.getRelatedObjects(app.collectionRelation, "Children");

			jqxhr.done(function (children) {
				self.collectionAttachments = [];

				// Get the OTC and time formatting config in order to format any dates
				app.context.configService.getAdminOTC(function (otc) {
					_.each(children, function (child) {
						//remove any sub folders
						if (child.objectType !== "Folder" && child.objectType !== "Note") {
							SendEmailUtil.setAttributesToDisplay(otc, child, self.attributesToDisplay);
							self.collectionAttachments.push(child);

							var childAttachment = {
								objectId: child.objectId,
								objectName: child.properties.objectName
							};
							//check the box of current document on the stage if send email called from document actions list
							if (child.objectId === self.model.action.get("parameters").objectId) {
								self.attachedCollectDocs.push(childAttachment);
							}
						}
					});

					self.activateTab("collectionAttachmentActive");
					self.render();
				}); //end getAdminOTC
			});
		},

		validateNumberOfAttachments: function () {
			var isValid = false;
			var maxNumberOfAttachments = this.options.config.get('maxNumberOfAttachments');
			if (this.attachedDocs.models.length > maxNumberOfAttachments) {
				var errorMessage = window.localize("modules.actions.sendEmail.exceedsMaxAttachments") + maxNumberOfAttachments +
					 " " + window.localize("stage.sendEmail.attachments") + "." + window.localize("modules.actions.sendEmail.removeAttachments");
				this.$(".error-message-" + this.cid).show().html("<span>" + errorMessage + "</span>");
			} else {
				this.$(".error-message-" + this.cid).hide();
				isValid = true;
			}

			return isValid;
		},

		validateTotalAttachmentsSize: function (maxTotalAttachmentsSize) {
			var isValid = false;

			if (this.totalAttachmentSize <= maxTotalAttachmentsSize) {
				this.$('#attachment-size-error-' + this.cid).hide();
				isValid = true;
			} else {
				var errorMessage = window.localize("modules.actions.sendEmail.exceedsMaxAttachmentSize") + maxTotalAttachmentsSize + 
					TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE + "." + window.localize("modules.actions.sendEmail.removeAttachments");
				this.$('#attachment-size-error-' + this.cid).show().html("<span>" + errorMessage + "</span>");
			}

			return isValid;
		},

		triggerShowAttachmentTab: function (e) {
			e.preventDefault();
			$(this).tab('show');
		},

		/**
		 * Method to create and render a loading spinner for the attachment data calls
		 */
		displayAttachmentDataSpinner: function () {
			var spinnerOutlet = this.$("#send-email-attachments-spinner")[0];
			this.pendingAttachmentLoadingSpinner = this.createLoadingSpinner(spinnerOutlet);
		},

		/**
		 * Method to create loading spinners
		 * @param spinnerOutlet - the dom element to hold the spinner
		 */
		createLoadingSpinner: function (spinnerOutlet) {
			// animate our loading indicator with spin.js (lighter weight than animated gif)
			return Spinner.createSpinner({
				color: '#fff',
				length: 15,
				width: 5,
				radius: 25,
				shadow: true
			}, spinnerOutlet);
		},

		beforeRender: function () {
			this.setView('#collectionSearch', this.collectionTypeahead);
			if (this.model.groupAction || this.model.action.get('parameters').objectId !== app.context.container.id) {
				this.showFolderDocs = true;
			}
		},

		afterRender: function () {
			// If we have previous position, go back to that position
			if (this.options.previousPosition) {
				$(".modal.in").scrollTop(this.options.previousPosition);
			}

			if(this.pending) {
				// we're still waiting on attachment data from OC, let's show a spinner
				this.displayAttachmentDataSpinner();
			} else {
				// let's make sure our spinner is cleaned up
				Spinner.destroySpinner(this.pendingAttachmentLoadingSpinner);
			}

			this.parent.canSubmit();
		},

		serialize: function () {
			var serializedObj = {
				cid: this.cid,
				pending: this.pending,
				showFolderDocs: this.showFolderDocs,
				attachments: this.attachments,
				showAttachedTab: this.showAttachedTab,
				attachedDocs: this.attachedDocs.models,
				collectionAttachmentsTab: this.model.collectionAttachmentsTab,
				showCollectionDocs: this.showCollectionDocs,
				collectionAttachments: this.collectionAttachments,
				attachedCollectDocs: this.attachedCollectDocs.models,
				chosenCollection: this.model.chosenCollection,
				tabState: this.tabState,
				hideAvailableDocsTab: this.model.hideAvailableDocsTab || false,
				attributesToShow: this.attributesToDisplay,
				isExpanded: this.isExpanded,
				showAttachmentSize: this.model.shouldValidateTotalAttachmentsSize,
				remainingAttachmentSizeMsg: "",
				noRemainingSpace: false,
				collectionAction: this.collectionAction,
				isSelectAttachmentVersionEnabled: this.model.isSelectAttachmentVersionEnabled
			};

			if (this.model.shouldValidateTotalAttachmentsSize && (this.maxTotalAttachmentsSize || this.maxTotalAttachmentsSize === 0) && (this.totalAttachmentSize || this.totalAttachmentSize === 0)) {
				// call Math.max on the total attachment size and .01 otherwise, a small totalAttachmentSize will be rounded to the nearest int
				var rawRemainingSpace = this.totalAttachmentSize === 0 ? this.maxTotalAttachmentsSize : this.maxTotalAttachmentsSize - Math.max(this.totalAttachmentSize, 0.01);

				// display the remaining size in MB or 0 if the limit is exceeded
				var remainingSpace = Math.max(0, parseFloat(rawRemainingSpace.toFixed(2)));
				serializedObj.remainingAttachmentSizeMsg = " " + remainingSpace + TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE + " / " + this.maxTotalAttachmentsSize + TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE;
				serializedObj.noRemainingSpace = remainingSpace === 0;
			}

			return serializedObj;
		}
	});

	return SendEmailAttachmentsView;
});