define("sendemail",[
	"app",
	"oc",
	"modules/actions/actionmodules",
	"modules/common/typeahead",
	"modules/common/exportwithannotations",
	"modules/hpiadmin/searchconfig/emailtemplatesconfig",
	'modules/common/hpiconstants',
	"modules/hpiadmin/actionconfig/actions/sendemail/sendemailcustomactionconfig",
	"modules/actions/sendemail/sendemailattachmentsview",
	"modules/actions/sendemail/sendemailsubjectview",
	"modules/actions/sendemail/sendemailutil",
	"tsgUtils",
	"ckeditorcore",
	"module"
],

function(app, OC, actionModules, HPITypeAhead, 
	ExportWithAnnotations, EmailTemplatesConfig, HPIConstants, SendEmailCustomConfigView, SendEmailAttachmentsView, SubjectView, SendEmailUtil, TSGUtils) {
	(window.localize("modules.actions.sendEmail.useStrict"));

	var SendEmail = {};

	SendEmail.CustomConfigView = SendEmailCustomConfigView.View;

	var MAX_NUM_PRESELECTED_ATTACHMENTS = 20;

	SendEmail.Constants = {
		TO: "to", 
		CC: "cc",
		BCC: "bcc"
	};

	// TODO don't add to this.. remove these when possible.
	SendEmail.Localizations = {
		'error': {
			'invalid:to:address'	: (window.localize("modules.actions.sendEmail.invalidTo")),
			'invalid:cc:address'	: (window.localize("modules.actions.sendEmail.invalidCC")),
			'invalid:bcc:address'	: (window.localize("modules.actions.sendEmail.invalidBCC")),
			'no:body'				: (window.localize("modules.actions.sendEmail.theBody")),
			'no:attachments'		: (window.localize("modules.actions.sendEmail.pleaseAttach")),
			'attachments:size'		: (window.localize("modules.actions.sendEmail.attachments.size")),
			'invalidEmail'			: (window.localize("modules.actions.sendEmail.invalidEmail")),
			'duplicatedEmail'		: (window.localize("modules.actions.sendEmail.duplicatedEmail"))
		}
	};

	// check if there are too many documents trying to be pre-attached, if so fail the condition
	SendEmail.evaluateClientCondition = function(action){
		var attachmentIds = action.get("parameters").objectIds;
		if (!attachmentIds || attachmentIds.length <= MAX_NUM_PRESELECTED_ATTACHMENTS){
			return true;
		}
		return false;
	};

	SendEmail.failedConditionMessage = (window.localize("modules.actions.sendEmail.condition.failed.part.one")) + 
							MAX_NUM_PRESELECTED_ATTACHMENTS + (window.localize("modules.actions.sendEmail.condition.failed.part.two"));

	SendEmail.validateEmail = function (email) {
		var emailReg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return emailReg.test(email);
	};

	SendEmail.parseMultipleEmails =  function(emails){
		var individualEmails = emails.split(/[,;]+/); // split on any number of commas and semicolons
		var responseObject = {
			validEmailList: [], 
			invalidEmailList: [],
			duplicatedEmailList: []			
		};

		//process the individual emails
		_.each(individualEmails, function(email){
			email = email.replace(/\s/g, ''); // throw out whitespace
			if (!email){
				return; // if you get rid of the whitespace and there's nothing left, don't bother doing anything else
			}

			// the name is irrelevant, I only care about what's in the brackets
			var hasBrackets = (email.indexOf("<") >= 0) ? true : false ; // do we have those angled brackets? 
			var isValid = false;
			var emailPortion; 
			if (hasBrackets){
				emailPortion = email.split(/[<>]+/)[1]; // this should grab the section of the email between brackets 
				isValid = SendEmail.validateEmail(emailPortion);
			} else {
				emailPortion = email; // I care about the whole thing, there aren't brackets
				isValid = SendEmail.validateEmail(emailPortion);
			}

			if (!isValid){
				responseObject.invalidEmailList.push(emailPortion);
				return;
			} else{ // it is a valid email
				
				if (responseObject.validEmailList.indexOf(emailPortion) >= 0){ // but this email is a duplicate (note: only valid emails can get marked as duplicates)
					responseObject.duplicatedEmailList.push(emailPortion);
				} else{
					responseObject.validEmailList.push(emailPortion); 
				}
			}
		});

		return responseObject; // just hand back all the emails as arrays of strings: valid, invalid, and duplicated. What the caller wants with that is up to them. 
	};

	SendEmail.Models = {};

	SendEmail.Models.EmailInfoModel = Backbone.Model.extend({
		initialize: function() {
			this.set("toCheckList", new Backbone.Collection());
			this.set("ccCheckList", new Backbone.Collection());
			this.set("bccCheckList", new Backbone.Collection());
			this.set("subject", "");
			this.set("body", "");
		}
	});

	//Model that will be created for each document selected
	SendEmail.Models.SendEmailCoordinator = Backbone.Model.extend({
		initialize: function(config, action) {
			this.config = config;
			this.action = action;
			this.handler = this.config.get("handler");
			this.emailInfoModel = new SendEmail.Models.EmailInfoModel();
			this.folderId = app.context.container.id || "";
			this.showCC	= false;
			this.showBCC = false;
			this.showShared = false;
			this.showCollectionDocs = "";
			this.collectionType = "private";
			this.chosenCollection = "";
			this.state = {};
			this.collectionResults = [];
			this.typeAheadContactList = {};
			this.typeAheadContactList.emails = [];
			this.typeAheadContactList.phones = [];
			this.validateAttachments = this.config.get("validateAttachments") === "true";
			this.validateMaxNumberOfAttachments = this.config.get('validateMaxNumberOfAttachments') === "true";
			this.shouldValidateTotalAttachmentsSize = this.config.get('shouldValidateTotalAttachmentsSize') === "true" ;
			this.shouldTrackAttachmentSize = (this.config.get('cloudSendMode') === "dependent" && this.config.get('restrictInternalBasedOnAttachmentSize') === true) || this.config.get('shouldValidateTotalAttachmentsSize') === "true";
			this.hideAvailableDocsTab = this.config.get("hideAvailableDocsTab") === 'true';
			this.maxLength = this.config.get("maxLength") || "225";
			this.integrateFolderNotes = this.config.get("integrateFolderNotes") === "true";
			this.hasMaxBodyLength = this.config.get('hasMaxBodyLength') === "true";
			this.maxBodyCharacters = this.config.get('maxBodyCharacters') || 8000;
			this.format = this.config.get('bodyFormat') || 'html';
			this.subjectPrefixes = this.config.get('subjectPrefixes') || {};
			this.isUploadAttachmentsActionEnabled = this.config.get('enableUploadAttachmentsAction');
			this.isSelectAttachmentVersionEnabled = this.config.get('enableSelectAttachmentVersion');

			// These should default to true if no value is configured
			var alwaysCreateNoteOnSend = this.config.get("alwaysCreateNoteOnSend");
			this.alwaysCreateNoteOnSend = (!alwaysCreateNoteOnSend || alwaysCreateNoteOnSend === "true");

			var collectionAttachmentsTab = this.config.get("collectionAttachmentsTab");
			this.collectionAttachmentsTab = (!collectionAttachmentsTab || collectionAttachmentsTab === "true");
		}
	});

	SendEmail.View = Backbone.Layout.extend({
		template: "actions/sendemail/sendemail",
		events: {
			"click #attachmentButton": "toggleExpandIcon",
			"click #sendEmailButton": "sendEmail",
			"click #uploadAttachmentsAction": "triggerUploadAttachmentsAction"
		},
		initialize: function(){
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.model = new SendEmail.Models.SendEmailCoordinator(this.options.config, this.options.action);
			this.model.attributesToDisplay = this.config.get('attrsToDisplay') ? this.config.get('attrsToDisplay') : [];
			this.hideNoResultMessage = this.options.config.get("hideNoResultMessage");
			this.contentSizeCollection = new Backbone.Collection();
			this.ckeditorSize = this.myHandler ===  HPIConstants.Handlers.RightSideActionHandler ? 400 : 100;
			this.advancedCombineToPDFSendEmail = this.options.advancedCombineToPDFSendEmail || false;
			this.showAttachments = this.options.showAttachments;
			this.showSubmitButton = this.options.showSubmitButton;

			if(this.showAttachments === undefined) {
				this.showAttachments = true;
			}

			if(this.showSubmitButton === undefined) {
				this.showSubmitButton = true;
			}

			// cloud send can be enabled (always use cloud send), false (never use cloud send), or dependent
			this.validateCloudSend = this.config.get('cloudSendMode') === "dependent";

			// can skip all this business if we're not in dependent mode
			var internalSendEmailDeferreds = [];
			if (this.validateCloudSend){
				internalSendEmailDeferreds = this.initializeInternalEmailRestrictions();
			}

			this.enterKeys =  this.options.config.get('selectedEnterKeys') || [HPIConstants.CHARCODES.Enter]; // just enter key if nothing is configured
			// Figure out if we are a group action coming from tableview. We will be a group action if 'group' is in the action id 
			this.model.groupAction = this.action.get('actionId').indexOf('group') > 0;
			if (this.model.groupAction){
				// set the folderId on the action objectId
				this.action.get('parameters').objectId = app.context.container.id;
			}
			
			this.unattachableDocsView = new SendEmail.UnattachableDocsView({});
			
			//load all of the attachments
			this.loadFolderDocs();

			if(this.config.get("allowEmailTemplates") === "true"){
				this.fetchEmailTemplates();
			}

			// This will reset the annotationInfo action parameter so that whatever was on there before will be erased.
			this.action.get("parameters").annotationInfo = null;

			//set up all of the subviews
			this.bodyView = new SendEmail.EmailBodyView({parent: this});
			// if validateCloudSend is false, this will resolve immediately
			$.when(internalSendEmailDeferreds).done(_.bind(function(){
				this.recipientsView = new SendEmail.RecipientsView({options: this});
			}, this));
			this.attachmentsView = new SendEmailAttachmentsView.View({ options: this });
			this.subjectView = new SubjectView.View({options: this});
			this.startListening();
		},
		initializeInternalEmailRestrictions: function(){
			var internalSendEmailDeferreds = [];
			this.restrictInternalBasedOnAttachmentSize = this.config.get('restrictInternalBasedOnAttachmentSize');
			this.restrictInternalBasedOnFileExtension = this.config.get('restrictInternalBasedOnFileExtension');
			this.restrictInternalBasedOnEmailDomains = this.config.get('restrictInternalBasedOnEmailDomain');


			this.internalSendEmailDomains = [];
			if (this.restrictInternalBasedOnEmailDomains){
				var internalSendEmailDomainsDeferred = $.Deferred();
				internalSendEmailDeferreds.push(internalSendEmailDomainsDeferred);
				var selectedEmailDomainsPicklist = this.config.get('selectedEmailDomains');
				app.context.picklistService.getPicklist(selectedEmailDomainsPicklist, _.bind(function(picklistOptions){
					this.internalSendEmailDomains = _.pluck(picklistOptions, 'label');
					this.internalSendEmailDomains = _.map(this.internalSendEmailDomains, function(domain){
						return domain.toLowerCase();
					});
					internalSendEmailDomainsDeferred.resolve();
				}, this));
			}

			this.internalSendEmailExtensions = [];
			if (this.restrictInternalBasedOnFileExtension){
				var internalSendEmailExtensionsDeferred = $.Deferred();
				internalSendEmailDeferreds.push(internalSendEmailExtensionsDeferred);
				var selectedFileExtensionsPicklist = this.config.get('selectedFileExtensions');
				app.context.picklistService.getPicklist(selectedFileExtensionsPicklist, _.bind(function(picklistOptions){
					this.internalSendEmailExtensions = _.pluck(picklistOptions, 'label');
					this.internalSendEmailExtensions = _.map(this.internalSendEmailExtensions, function(extension){
						return extension.toLowerCase();
					});
					internalSendEmailExtensionsDeferred.resolve();
				}, this));
			}

			if (this.restrictInternalBasedOnAttachmentSize){
				this.internalSendEmailAttachmentSize = this.config.get('internalSendEmailAttachmentSize');				
			}
			return internalSendEmailDeferreds;
		},
		// startListening function for client overrides
		startListening: function(){
			// add extra listeners if we need to be checking if we should be doing cloud send
			if (this.validateCloudSend){
				this.listenTo(this.recipientsView, 'emails:changed', this.verifyCanSendInternally);
				this.listenTo(this.attachmentsView, 'totalAttachmentSize:updated', this.verifyCanSendInternally);
			}
		},
		beforeRender: function(){
			this.setViews({
				"#recipientsView": this.recipientsView,
				"#attachmentsSubview": this.attachmentsView,
				"#subjectSubview": this.subjectView,
				"#unattachableDocs-outlet": this.unattachableDocsView,
				'#sendEmail-emailBody': this.bodyView
			});
		},
		afterRender: function(){
			// add folder note ckeditor if configured
			if (this.model.integrateFolderNotes) {
				CKEDITOR.replace('emailNoteContent-' + this.cid, {
					toolbar: "HPIMinimal",
					disableNativeSpellChecker: false,
					height: this.ckeditorSize
				}, '');
			}

			if(this.model.integrateFolderNotes){
				$("#emailNoteContentDiv").toggle();
			}

			if(this.model.collectionAttachmentsTab){
				$("#collectionAttachTab").toggle();
			}

			this.recipientsView.render();
			this.attachmentsView.render();
			this.subjectView.render();

			this.canSubmit();
		},
		serialize: function() {
			return {
				modal: this.myHandler === HPIConstants.Handlers.ModalActionHandler,
				rightSide: this.myHandler === HPIConstants.Handlers.RightSideActionHandler,
				integrateFolderNotes: this.model.integrateFolderNotes,
				isUploadAttachmentsActionEnabled: this.model.isUploadAttachmentsActionEnabled,
				cid: this.cid,
				showAttachments: this.showAttachments,
				showSubmitButton: this.showSubmitButton
			};
		},
		
		/**
		 * Grab a clone of the bulk upload folder action config from the stage config. Override a few modal config attributes.
		 * @param {Backbone.Model} stageConfig the stage config for this trac.
		 */
		getUploadFolderActionConfig: function (stageConfig) {
			var bulkUploadConfig;
			if (stageConfig) {
				var folderActionConfigs = stageConfig.get('folderActionConfig');

				if (folderActionConfigs) {
					var actionGroups = folderActionConfigs.get('actionGroups');

					if (actionGroups) {
						// search all of these for a bulk upload config, taking the first one
						actionGroups.each(function (actionGroup) {
							var actions = actionGroup.get('actions');

							if (actions && !bulkUploadConfig) {
								bulkUploadConfig = actions.findWhere({
									actionId: HPIConstants.Actions.BulkUpload
								});
							}
						}, this);
					}
				}
			}

			if (bulkUploadConfig) {
				this.uploadAttachmentsSubactionConfig = bulkUploadConfig.clone();
				// Assuming that the send email action is a right side action and so we fire the upload attachments sub action as a modal action
				this.uploadAttachmentsSubactionConfig.set('handler', HPIConstants.Handlers.ModalActionHandler);
				this.uploadAttachmentsSubactionConfig.set('modalSize', 'xl');
				this.uploadAttachmentsSubactionConfig.set('modalBackdrop', 'static');
				this.uploadAttachmentsSubactionConfig.set('label', window.localize("stage.sendEmail.uploadAttachments"));
			}
		},
		
		/**
		 * Callback for the #uploadAttachmentsAction click event. Kicks off the bulk upload modal. This will grab the bulk upload config if this is the
		 * first time the user has clicked this button.
		 */
		triggerUploadAttachmentsAction: function () {
			if (this.uploadAttachmentsSubactionConfig) {
				this.displayUploadModal();
			} else {
				app.context.configService.getStageConfigByName(app.context.configName(), null, null, this)
					.fail(this.showNoUploadConfigError)
					.done(this.getUploadFolderActionConfig)
					.then(this.displayUploadModal);
			}
		},

		showNoUploadConfigError: function() {
			app.trigger("alert:error", {
				header: window.localize("modules.actions.sendEmail.uploadAttachment.noConfigError.header"),
				message: window.localize("modules.actions.sendEmail.uploadAttachment.noConfigError.message")
			});
		},
		
		/**
		 * Triggers the modalActionHandler's show event with the bulk upload subaction. 
		 * Sets up the done callback on the subaction deferred.
		 * Displays an error to the user if there is no bulk upload config.
		 */
		displayUploadModal: function () {
			if (this.uploadAttachmentsSubactionConfig) {
				var uploadAttachmentSubactionDeferred = $.Deferred();
				uploadAttachmentSubactionDeferred.done(this.processUploadedAttachments);

				app[HPIConstants.Handlers.ModalActionHandler].trigger("show", {
					config: this.uploadAttachmentsSubactionConfig,
					subactionDeferred: uploadAttachmentSubactionDeferred,
					actionContext: this,
					isSubaction: true,
					removeSubactionOnCompletion: false
				});
			} else {
				this.showNoUploadConfigError();
			}
		},
		
		/**
		 * Calls getAttachmentData to add the newly uploaded attachments to the Attachments view.
		 * @param {Object} results Contains an array, successList, that contains all of the successfully uploaded attachments.//#endregion
		 */
		processUploadedAttachments: function (results) {
			var uploadedAttachments = _.pluck(results.successList, "objectId");
			if (!_.isEmpty(uploadedAttachments)) {
				SendEmailUtil.getAttachmentData({
					model: this.model,
					ids: uploadedAttachments,
					isOcoFetchGlobal: false,
					ocoFetchSuccessCallback: this.displayAttachments,
					ocoFetchErrorCallback: this.onFetchAttachmentDataError,
					fetchContentSizeSuccessCallback: this.setContentSizeCollection,
					fetchContentSizeErrorCallback: this.onFetchContentSizeError,
					attachmentDataFetchSuccessCallback: this.handleAttachmentDataFetch,
					context: this
				});
			}
		},
		populateAttachmentList: function(){
			var self = this;
			var oCObject = new OC.OpenContentObject({objectId: self.model.folderId});

			var jqxhr = oCObject.getChildren();
			jqxhr.done( function(children) {
				self.attachmentsView.pending = false;
				self.attachmentsView.attachments = [];

				// Get the OTC and time formatting config in order to format any dates
				app.context.configService.getAdminOTC(function(otc) {
					_.each(children, function(child){
						//remove any children that are of a 'bad' object type
						//default bad types are Folder and Note
						if(_.indexOf(self.model.config.badAttachmentObjectTypes, child.objectType) === -1)
						{
							SendEmailUtil.setAttributesToDisplay(otc, child, self.model.attributesToDisplay);
							self.attachmentsView.attachments.push(child);

							//check the box of current document on the stage if send email called from document actions list or if the current obj was passed via group action
							if(child.objectId === self.model.action.get("parameters").objectId || _.contains(self.model.action.get("parameters").objectIds, child.objectId))
							{
								// check if the current doc has content by making sure it's mimeType property is set
								if (child.mimeType){
									self.attachmentsView.addSelectedAttachment(child, true);
								} else {
									// we can't attach this doc it has no content, add it to the unattachableDocs view
									self.unattachableDocsView.addUnattachableDoc(child);
								}
							}
						}
						self.attachmentsView.render();
					});
				}); //end getAdminOTC
			});
		},
		onFetchAttachmentDataError: function() {					
			this.attachmentsView.render();
		},
		onFetchContentSizeError: function() {
			this.model.shouldValidateTotalAttachmentsSize = false;
			this.attachmentsView.render();
		},
		setContentSizeCollection: function(docs) {
			_.each(docs, function(doc) {
				var contentSizeMap = {
					size: doc.contentSizes[0],
					id: doc.objectId
				};
				this.contentSizeCollection.add(contentSizeMap);
			}, this);
		},
		displayAttachments: function(ocos) {
			this.attachmentsView.pending = false;
			var self = this;
			// Get the OTC and time formatting config in order to format any dates
			app.context.configService.getAdminOTC(function(otc) {
				_.each(ocos, function(doc){
					SendEmailUtil.setAttributesToDisplay(otc, doc, self.model.attributesToDisplay);
					// check if the current doc has content by making sure it's mimeType property is set
					if (doc.mimeType){
						self.attachmentsView.addSelectedAttachment(doc, true);
					} else {
						// we can't attach this doc it has no content, add it to the unattachableDocs view
						self.unattachableDocsView.addUnattachableDoc(doc);
					}
				});

				self.attachmentsView.render();
			});
		},
		fetchEmailTemplates: function(){
			var self = this;

			var templatesConfig = new EmailTemplatesConfig.Model();
			templatesConfig.fetch({
				context: this,
				success: function(response){
					self.templates = new Backbone.Collection(response.get("templates"));
				},
				error: function(){
					// The config doesn't exist yet...initialize the templates to an empty array
					self.templates = new Backbone.Collection([]);
				},
				complete: this.createAndRenderTemplatesView
			});
		},
		createAndRenderTemplatesView: function () {
			this.templatesView = new SendEmail.TemplatesView({
				templates: this.templates
			});
			this.setView("#templates-outlet", this.templatesView).render();
			this.listenTo(this.templatesView, 'sendEmail:emailBodyView:insertBodyText', this.updateBodyValue);
		},
		updateBodyValue: function(newBodyValue) {
			this.bodyView.insertBodyText(newBodyValue);
		},
		loadFolderDocs: function () {
			var oCObject = new OC.OpenContentObject({
				objectId: this.model.action.get("parameters").objectId
			});
			// first, we fetch the oco to get the object type,
			// then we determine the folder id,
			// then we grab all the folder docs for that folder id
			oCObject.fetch()
				.then(_.bind(this.setFolderId, this, oCObject))
				.then(_.bind(this.fetchFolderDocs, this));
		},
		setFolderId: function(object) {
			var self = this;
			var folderIdFoundDeferred = $.Deferred();
			app.context.configService.isContainer(object.get("objectType"), function(result) {
				if (result === "true") {
					self.model.folderId = self.model.action.get("parameters").objectId;
				} else {
					//we have a document, so we need to get its parent
					//id and use that as the folder id.
					self.model.folderId = app.context.container.id;
					self.model.action.get("parameters").objectIds = [self.model.action.get("parameters").objectId];
				}
				folderIdFoundDeferred.resolve();
			});
			
			return folderIdFoundDeferred;
		},
		fetchFolderDocs: function() {
			// only fetch all docs in folder if we don't want to hide the available docs tab,
			// else, just fetch docs that were passed in on the action params
			if (!this.model.hideAvailableDocsTab){
				this.populateAttachmentList();
			} else {
				SendEmailUtil.getAttachmentData({
					model: this.model,
					ids: this.model.action.get("parameters").objectIds,
					isOcoFetchGlobal: true,
					ocoFetchSuccessCallback: this.displayAttachments,
					ocoFetchErrorCallback: this.onFetchAttachmentDataError,
					fetchContentSizeSuccessCallback: this.setContentSizeCollection,
					fetchContentSizeErrorCallback: this.onFetchContentSizeError,
					attachmentDataFetchSuccessCallback: this.handleAttachmentDataFetch,
					context: this
				});
			}

			this.attachmentsView.render();
		},

		/**
		 * Calls displayAttachments with the attachment ocos. 
		 * Calls setContentSizeCollection with the content collection.
		 * @param  {Array} ocosPromiseArray the promise array for the fetchOcos call
		 * @param  {Array} contentSizesPromiseArray the promise array for the fetchContentSizeCollection call
		 */
		handleAttachmentDataFetch: function(ocosPromiseArray, contentSizesPromiseArray) {
			// these arrays contain the result of their respective ajax calls as the first param 
			var ocoArray = ocosPromiseArray[0];
			var contentSizesArray = contentSizesPromiseArray[0];
			this.displayAttachments(ocoArray);
			this.setContentSizeCollection(contentSizesArray);
		},

		toggleExpandIcon: function() {
			this.$('#attachmentToggleArrow').toggleClass('glyphicon-chevron-up glyphicon-chevron-down');
		},

		canSubmit: function() {
			var isSendEmailButtonDisabled = true;
			//Allow Submit is at least one user and a date have been selected. Message is optional.
			var hasEmailsInTheToField = this.model.emailInfoModel.get("toCheckList").length > 0;
			var hasValidSubject = this.subjectView.validateSubject();
			var hasValidNumberOfAttachments = true;
			var hasValidTotalSizeOfAttachments = true;

			if (this.validateCloudSend){
				this.verifyCanSendInternally();
			}

			if (this.model.validateMaxNumberOfAttachments) {
				hasValidNumberOfAttachments = this.attachmentsView.validateNumberOfAttachments();
			}

			if (this.model.shouldValidateTotalAttachmentsSize) {
				hasValidTotalSizeOfAttachments = this.attachmentsView.validateTotalAttachmentsSize(this.options.config.get('maxTotalAttachmentsSize'));
			}

			if (hasEmailsInTheToField && hasValidSubject && hasValidNumberOfAttachments && hasValidTotalSizeOfAttachments) {
				isSendEmailButtonDisabled = false;
			}

			// update the button
			$('#sendEmailButton').prop('disabled', isSendEmailButtonDisabled);

			// This button is specifically for enabling/disabling the ACTPDF Send Email Send Button
			if(this.advancedCombineToPDFSendEmail) {
				// actpdf send email button
				$('#saveSendEmail-Btn').prop('disabled', isSendEmailButtonDisabled);
			}
			
			// return if we can submit
			return !isSendEmailButtonDisabled;
		},
		getAttachmentIds: function() {
			var objectIdKey = HPIConstants.OpenContentObject.ObjectId;
			var selectedAttachmentVersionIdArray = [];
			var attachmentIdArray = [];

			// if we've allowed the user to select versions,
			// we need to grab and send both the selected version and working copy ids
			if (this.model.isSelectAttachmentVersionEnabled) {
				objectIdKey = "workingCopyId";
				selectedAttachmentVersionIdArray = _.uniq(this.attachmentsView.attachedDocs.pluck(HPIConstants.OpenContentObject.ObjectId));
			}

			// get objectId arrays
			var attachedDocsArray = this.attachmentsView.attachedDocs.pluck(objectIdKey);
			var collectionDocsArray = this.attachmentsView.attachedCollectDocs.pluck(HPIConstants.OpenContentObject.ObjectId);

			// get one array that is the unique set of both attached and collection docs
			attachmentIdArray = _.union(attachedDocsArray, collectionDocsArray);

			return {
				selectedAttachmentVersionIdArray: selectedAttachmentVersionIdArray,
				attachmentIdArray: attachmentIdArray
			};
		},
        verifyCanSendInternally: function(){
           
            var infoMessages = [];

            // three pieces of validation
            var internalEmailDomain = true;
            var internalAttachmentType = true;
            var underConfiguredAttachmentSize = true;

            // 1) domains
			if (this.restrictInternalBasedOnEmailDomains && this.recipientsView.getEmailList().length !== 0){
            	// _.every runs a boolean check for every element, and shortcut returns when it returns false
	            internalEmailDomain =  _.every(this.recipientsView.getEmailList(), function(emailAddress){
	                var domain =  emailAddress.split('@')[1].toLowerCase();
	                return _.contains(this.internalSendEmailDomains, domain);
	            }, this);

	            if (!internalEmailDomain) {
					infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalEmailDomainMessage"));   			
        	    }
            }

            // 2) attachment extensions
            if (this.restrictInternalBasedOnFileExtension && this.attachmentsView.attachedDocs.models.length !== 0){
            	// _.every runs a boolean check for every element, and shortcut returns when it returns false
	            internalAttachmentType =  _.every(this.attachmentsView.attachedDocs.models, function(doc){
	                var filename = doc.get('objectName');
	                var extension = filename.substring(filename.lastIndexOf('.')).toLowerCase();
	                return _.contains(this.internalSendEmailExtensions, extension);
	            }, this);

	            if (!internalAttachmentType) {
					infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalAttachmentExtensionMessage"));    			
        	    }
            }
           
            // 3) attachments under configurable size.
            if (this.restrictInternalBasedOnAttachmentSize){
	            if (this.attachmentsView.totalAttachmentSize > this.internalSendEmailAttachmentSize){
                	infoMessages.push(window.localize("modules.actions.sendEmail.invalidInternalAttachmentSizeMessage") + this.internalSendEmailAttachmentSize + TSGUtils.FILE_SIZE_ABBREVIATIONS.MEGABYTE);
                	underConfiguredAttachmentSize = false;
          		}
            }

            // if we're over the total attachment size limit, where send email is disabled, we don't want to see both the "can't send internally" and "please remove attachments" messages
            var underActionAttachmentSizeLimit = true;
            if (this.model.shouldValidateTotalAttachmentsSize){
            	underActionAttachmentSizeLimit = this.attachmentsView.validateTotalAttachmentsSize(this.options.config.get('maxTotalAttachmentsSize'));
            }
            // show the message if need be
            if ((!internalEmailDomain || !internalAttachmentType || !underConfiguredAttachmentSize) && underActionAttachmentSizeLimit){
                var messageView = new SendEmailUtil.GenericMessageView(
                	{
                		"mainMessage": window.localize("modules.actions.sendEmail.cannotSendInternally"),
                		"ordered" : false,
                		"messages" : infoMessages
                	}
                );
				// that true is to maintain the content
                app[this.myHandler].trigger("showInfo", messageView, true);
                return false; // cannot send internally
            } else {
            	app[this.myHandler].trigger("hideInfo");
 	            return true; // good to send internally
            }
        },
		sendEmail: function() {
			var self = this;
			self.handler = this.model.handler;
			self.$(".error-message-" + this.cid).hide();
			app[self.handler].trigger("loading", true);

			if (self.model.validateMaxNumberOfAttachments) {
				var maxAttachments = this.config.get('maxNumberOfAttachments');
				if (this.attachmentsView.attachedDocs.length > maxAttachments) {
					app[self.handler].trigger("loading", false);
					self.model.errorMessage = window.localize("modules.actions.sendEmail.exceedsMaxAttachments") + maxAttachments +
					" " + window.localize("stage.sendEmail.attachments") + "." + window.localize("modules.actions.sendEmail.removeAttachments");
					self.$(".error-message-" + self.cid).show().html("<span>" + self.model.errorMessage + "</span>");

					return;
				}
			}

			//Get the form info
			var toArray = [], ccArray = [],  bccArray =  [];

			//if user leaves a recipient in the input make sure they get added!
			self.recipientsView.addToRecipientsSubView(SendEmail.Constants.TO);
			self.recipientsView.addToRecipientsSubView(SendEmail.Constants.CC);
			self.recipientsView.addToRecipientsSubView(SendEmail.Constants.BCC);

			//Handler to check if the email is valid
			//get the email recipients
			self.model.emailInfoModel.get("toCheckList").each(function(addressModel){
				toArray.push(addressModel.get("emailAddress"));
			});
			self.model.emailInfoModel.get("ccCheckList").each(function(addressModel){
				ccArray.push(addressModel.get("emailAddress"));
			});
			self.model.emailInfoModel.get("bccCheckList").each(function(addressModel){
				bccArray.push(addressModel.get("emailAddress"));
			});

            //get plain text or HTML based on configuration (HTML by default)
			self.model.emailInfoModel.set("body", self.bodyView.getBodyValue());

			if(self.model.validateAttachments) {
				if (this.attachmentsView.attachedDocs.length === 0) {
                    app[self.handler].trigger("loading", false);
                    self.model.errorMessage = SendEmail.Localizations.error['no:attachments'];
                    self.$(".error-message-" + self.cid).show().html("<span>" + self.model.errorMessage + "</span>");
                    return;
                }
			}

			// Adds folder and collection attachment ids into one array
			var attachmentIdArray = [];
			var selectedAttachmentVersionIdArray = [];
			var attachmentIdArrays = self.getAttachmentIds();
			attachmentIdArray = attachmentIdArrays.attachmentIdArray;
			selectedAttachmentVersionIdArray = attachmentIdArrays.selectedAttachmentVersionIdArray;
			
			if(self.model.emailInfoModel.get("body").length > 0) {

				self.model.action.get("parameters").to = toArray;
				self.model.action.get("parameters").cc = ccArray;
				self.model.action.get("parameters").bcc = bccArray;
				self.model.action.get("parameters").subject = self.model.emailInfoModel.get("subject");
				self.model.action.get("parameters").email_folder_name = self.model.config.get("emailStorageLocation");
				self.model.action.get("parameters").attachment_ids = attachmentIdArray;
				self.model.action.get("parameters").email_rel_type = self.model.config.get("emailRelationship");
				self.model.action.get("parameters").body = self.model.emailInfoModel.get("body");
				self.model.action.get("parameters").from =  app.user.id;
				self.model.action.get("parameters").email_bean_name = self.model.config.get("emailObjectType");
				self.model.action.get("parameters").folderTags = self.model.config.get("folderTags");
				self.model.action.get("parameters").folderId = self.model.folderId || app.context.container.id;
				self.model.action.get("parameters").trac = app.context.configName();

				
				if (this.validateCloudSend){
					// run through the check to see if we should send through the cloud
					self.model.action.get("parameters").cloudSendEnabled = !this.verifyCanSendInternally();
				} else {
					self.model.action.get("parameters").cloudSendEnabled = self.model.config.get("cloudSendMode") === "enabled";
				}

				self.model.action.get("parameters").cloudSend = self.model.config.get("emailObjectType");
				self.model.action.get('parameters').selectedVersionIds = selectedAttachmentVersionIdArray;

				// If folder notes enabled
				if (self.model.integrateFolderNotes) {
					// Check if the ckeditor has a typed note
					if (CKEDITOR.instances[self._CKEDITOR_getFolderNoteBody()].getData()) {
						// We have verified that the ckeditor has content
						self.model.action.get("parameters").note_content = CKEDITOR.instances[self._CKEDITOR_getFolderNoteBody()].getData();
					} else if (self.model.alwaysCreateNoteOnSend) {
						// If the ckeditor note content is empty AND the configuration to create a default note is on,
						// set the note content to the subject of the email object being sent
						self.model.action.get("parameters").note_content = self.model.emailInfoModel.get("subject");
					}

					// If note content has been set by this point, let's configure the action to add the note
					if (self.model.action.get("parameters").note_content) {
						//get the parent container
						self.model.action.get("parameters").parentID = self.model.action.get("parameters").folderId;
						var currentDate = DateFormat.format.date(new Date(),"E, d MMM yyyy hh-mm-ss a");
						self.model.action.get("parameters").property_map = {
							'note_type': self.model.config.get('noteType'),
							'objectName': "Folder Note - " + currentDate
						};
						self.model.action.get("parameters").note_object_type = self.model.config.get('noteObjectType');
						self.model.action.get("parameters").note_rel_type = self.model.config.get('noteRelationship');
						self.model.action.get("parameters").createNote = "true";
					} else {
						self.model.action.get("parameters").createNote = "false";
					}
				} else {
					self.model.action.get("parameters").createNote = "false";
				}

				var deferred = $.Deferred();
				self.allAttachments = [];
				self.annotations = [];

				// If the Export With Annotations attribute was configured for this action OR if we have already selected some annotators
				if(self.config.get("exportWithAnnotationsToAttachments") === 'true' || self.model.action.get("parameters").annotationInfo) {
					// If the user has selected some annotators
					if(self.model.action.get("parameters").annotationInfo) {
						self.executeAction(self);
					// If the user has not selected any annotators yet
					} else {
						// If the e-mail has no attachments, we send the e-mail as usual.
						if(self.model.action.get("parameters").attachment_ids.length === 0) {
							self.executeAction(self);
						} else {
							var that = self;
							var deferreds = [];
							// For each document the user has selected, we want to call getAnnotations
							_.each(self.model.action.get("parameters").attachment_ids, function(attachmentId) {
								var lastModified = 0;
								var documentName = "";
								for(var i = 0; i < this.attachmentsView.attachments.length; i++){
									if(this.attachmentsView.attachments[i].objectId === attachmentId) {
										lastModified = this.attachmentsView.attachments[i].properties.modifiedDate;
										documentName = this.attachmentsView.attachments[i].properties.objectName;
									}
								}

								deferreds.push( self.getAnnotations(attachmentId, lastModified, documentName, self.allAttachments, self.annotations) );
							}, that);

							if(deferreds.length > 0) {
								$.when.apply(null, deferreds).done($.proxy(function() {
									// If there are no annotations on the attachments, we send the email as usual.
									if(self.annotations.length === 0) {
										self.executeAction(that);
									} else {
										self.exportWithAnnotationsView(that, self.allAttachments);
									}
									deferred.resolve();
								}, that));
							}
						}
					}
				} else {
					self.executeAction(self);
				}
			} else {
				app[self.handler].trigger("loading", false);
				self.model.errorMessage = SendEmail.Localizations.error['no:body'];
				self.$(".error-message-" + this.cid).show().html("<span>" + self.model.errorMessage + "</span>");
			}
		},
		getAnnotations: function(attachmentId, lastModified, documentName, allAttachments, annotations) {
			var authors = [];
			return $.ajax({
				url: app.serviceUrlRoot + "/annotation/getAnnotations",
				dataType: "json",
				method: "GET",
				data: {
					id: attachmentId,
					lastModified: lastModified
				},
				success: function(data) {
					// We only want to add the info to allAttachments if there were any annotations returned
					if(data.annotations && data.annotations.length > 0) {
						_.each(data.annotations, function(annotation) {
							annotations.push(annotation);
							authors.push(annotation.title);
						});
					}
				},
				error: function() {
					alert((window.localize("modules.actions.sendEmail.cannotGetAnnotations")));
				}
			}).done(function() {
				// We only want to add the info to allAttachments if there were any annotations returned
				if(authors.length > 0) {
					authors = _.uniq(authors);
					allAttachments.push({id: attachmentId, name: documentName, authors: authors});
				}
			});
		},
		exportWithAnnotationsView: function(self, allAttachments) {
			app[self.handler].trigger("loading", false);

			// Pass allAttachments and self.model.action into new ExportWithAnnotations view
			self.exportWithAnnotationsForm = new ExportWithAnnotations.View({
				options: this,
				allAttachments: allAttachments,
				action: self.model.action
			});

			// Set an attribute that will hide the "emailForm" div and show the "exportWithAnnotationsForm"
			self.$("#emailForm").toggleClass("hidden");
			$("div#exportWithAnnotationsForm").removeClass("hiddenExportWithAnnotations");

			// Re-render the action view
			self.setView("#exportWithAnnotationsForm", self.exportWithAnnotationsForm);
			self.exportWithAnnotationsForm.render();
		},
		executeAction: function(self) {
			self.model.action.execute({
				success: function(){
					app[self.handler].trigger("loading", false);
					app[self.handler].trigger( "showMessage", (window.localize("modules.actions.sendEmail.emailSuccessfully")));
					//ensure we are doing a container refresh with the folder id
					app.trigger("stage.refresh.containerId", self.model.folderId);
				},
				error: function(jqXHR){
					app[self.handler].trigger("loading", false);
					app[self.handler].trigger("showError", (window.localize("modules.actions.sorryAnErrorHasOccured")) + jqXHR.responseText);
				}
			});
		},
		//CKEDITOR namespaces
		_CKEDITOR_getFolderNoteBody: function(){
			return 'emailNoteContent-' + this.cid;
		},
		cleanup: function() {
			try {
			    //remove this instance of CKEDITOR from the global registry
				//of CKEDITOR.instances to prevent memory leaks
				if(CKEDITOR.instances[this._CKEDITOR_getFolderNoteBody()]){
					CKEDITOR.instances[this._CKEDITOR_getFolderNoteBody()].destroy(true);
					CKEDITOR.instances[this._CKEDITOR_getFolderNoteBody()].removeAllListeners(); // just in case
					delete CKEDITOR.instances[this._CKEDITOR_getFolderNoteBody()];
				}
			} catch (e) { 
				app.log.error("An error occured cleaning up the SendEmail.View");
			}
		}
	});

	SendEmail.PlainTextCharacterLimitView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailplaintextcharacterlimitview",
		initialize: function (options) {
			this.parent = options.parent;
			this.maxBodyCharacters = this.parent.maxBodyCharacters;
			this.currentLength = 0;
			this.startListening();
		},
		startListening: function () {
			this.listenTo(this.parent, 'sendEmail:plainTextCharacterLimitView:updateLength', this.updateLength);
		},
		updateLength: function (newLength) {
			this.currentLength = newLength;
			this.render();
		},
		serialize: function () {
			return {
				currentLength: this.currentLength,
				maxBodyCharacters: this.maxBodyCharacters,
				hasReachedMaxLength: this.currentLength >= this.maxBodyCharacters
			};
		}
	});

	SendEmail.EmailBodyView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailbodyview",
		events: {},
		initialize: function (options) {
			this.parent = options.parent;
			this.defaultBodyText = "";
			this.bodyId = 'email-body-' + this.cid;
			this.hasMaxBodyLength = this.parent.model.hasMaxBodyLength;
			this.maxBodyCharacters = this.parent.model.maxBodyCharacters;
			this.isHTMLBody = this.parent.model.format === 'html';

			if (!this.isHTMLBody && this.hasMaxBodyLength) {
				this.events['input #email-body-' + this.cid] = "updatePlainTextWordCount";
				this.createAndSetPlainTextCharacterLimitView();
			}
		},
		insertBodyText: function (newBodyValue) {
			this.setBodyValue(newBodyValue);
			if (!this.isHTMLBody && this.hasMaxBodyLength) {
				this.updatePlainTextWordCount();
			}
		},
		createAndSetPlainTextCharacterLimitView: function () {
			this.plainTextCharacterLimitView = new SendEmail.PlainTextCharacterLimitView({
				parent: this
			});
			this.setView("#plainTextCharacterLimit", this.plainTextCharacterLimitView);
		},
		updatePlainTextWordCount: function () {
			var bodyValue = this.getBodyValue();
			var currentLength = bodyValue.length;
			var maxBodyLength = parseInt(this.maxBodyCharacters, 10);

			if (currentLength > maxBodyLength) {
				// we're exceeding the max body length,
				// substring it to the max length
				var newBodyValue = bodyValue.substring(0, maxBodyLength);
				this.setBodyValue(newBodyValue);
				currentLength = newBodyValue.length;
			}

			this.trigger('sendEmail:plainTextCharacterLimitView:updateLength', currentLength);
		},
		createCkEditor: function () {
			//use CKEDITOR if configured for HTML emails or by default if no config exists
			var ckeditorConfig = {
				toolbar: "HPISimple",
				disableNativeSpellChecker: false,
				height: this.parent.ckeditorSize
			};

			// add the wordcount plugin and its dependencies if configured
			if (this.hasMaxBodyLength) {
				ckeditorConfig.extraPlugins = 'wordcount,notification';
				ckeditorConfig.autoParagraph = false;
				ckeditorConfig.wordcount = {
					showParagraphs: false,
					showWordCount: false,
					showCharCount: true,
					countHTML: true,
					countBytesAsChars: true,
					countSpacesAsChars: true,
					maxWordCount: -1,
					maxCharCount: this.maxBodyCharacters
				};
			}
			CKEDITOR.replace(this.bodyId, ckeditorConfig, '');
		},
		// hotspot function so overrides can set default body text
		setBodyDefaultText: function (defaultBodyText) {
			this.insertBodyText(defaultBodyText);
		},
		setBodyValue: function (newBodyValue) {
			if (this.isHTMLBody) {
				CKEDITOR.instances[this.bodyId].setData(newBodyValue.replace(/\n/g, '<br/>'));
			} else {
				this.$("#" + this.bodyId).val(newBodyValue);
			}
		},
		getBodyValue: function () {
			var body = "";
			if (this.isHTMLBody) {
				body = CKEDITOR.instances[this.bodyId].getData();
			} else {
				body = this.$('#' + this.bodyId).val();
			}

			return body;
		},
		serialize: function () {
			return {
				isHTMLBody: this.isHTMLBody,
				cid: this.cid
			};
		},
		afterRender: function () {
			if (this.isHTMLBody) {
				this.createCkEditor();
			}

			if (this.defaultBodyText) {
				this.setBodyDefaultText(this.defaultBodyText);
			}
		},
		cleanup: function () {
			try {
				//remove this instance of CKEDITOR from the global registry
				//of CKEDITOR.instances to prevent memory leaks
				if (CKEDITOR.instances[this.bodyId]) {
					CKEDITOR.instances[this.bodyId].destroy(true);
					CKEDITOR.instances[this.bodyId].removeAllListeners(); // just in case
					delete CKEDITOR.instances[this.bodyId];
				}
			} catch (e) {
				app.log.error("An Issue occured during cleanup SendEmail.EmailBodyView");
			}
		}
	});

	SendEmail.RecipientsView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailallrecipients",
		events: {
			"focus #toContacts" : "focusTo",
			"focus #ccContacts" : "focusCC",
			"focus #bccContacts" : "focusBCC",
			"click .glyphicon-remove-circle" : "removeClicked",
			"click #ccButton": "toggleCC",
			"click #bccButton": "toggleBCC"
		},
		initialize: function(config){
			this.parent = config.options;
			this.model = config.options.model;
			this.hideNoResultMessage = config.options.hideNoResultMessage; 
			this.enterKeys = config.options.enterKeys || [HPIConstants.CHARCODES.Enter];
			this.toRecipientsView = new SendEmail.RecipientsSubView();
			this.ccRecipientsView = new SendEmail.RecipientsSubView();
			this.bccRecipientsView = new SendEmail.RecipientsSubView();

			this.fetchAddressBook();
		},
		fetchAddressBook: function() {
			//get all contacts in the address book to populate the typeaheads
			$.ajax({
				url: app.serviceUrlRoot + "/email/folderAddressBook",
				type: "GET",
				context: this,
				data: {
					folderId: app.context.container.get("objectId")
				},
				success: this.onAddressBookFetch,
				error: this.createTypeaheadControls
			});
		},
		onAddressBookFetch: function(data) {
			this.addContactsToContactList(data.emailContactBook, data.phoneContactBook);
			this.createTypeaheadControls();
		},
		getEmailList: function(){
			var emails = [];

			emails = _.union(emails, _.pluck(this.toRecipientsView.addedEmailAddresses, 'emailAddress'));
			emails = _.union(emails, _.pluck(this.ccRecipientsView.addedEmailAddresses, 'emailAddress'));
			emails = _.union(emails, _.pluck(this.bccRecipientsView.addedEmailAddresses, 'emailAddress'));

			return emails;
		},
		addContactsToContactList: function(emailBook, phoneBook) {
			var self = this;
			if(emailBook !== null) {
				_.each(emailBook.contacts, function(contact){
					if (contact.username) {
						contact.username = contact.username + " " + contact.emailAddress;
					}
					else {
						contact.username = contact.emailAddress;
					}

					self.model.typeAheadContactList.emails.push(contact);
				});
			}
			if (phoneBook !== null) {
				_.each(phoneBook.contacts, function(contact){
					if (contact.username) {
						contact.username = contact.username + " " + contact.phoneNumber;
					}
					else {
						contact.username = contact.phoneNumber;
					}

					self.model.typeAheadContactList.phones.push(contact);
				});
			}
		},
		createTypeaheadControls: function(){
			var self = this;
			self.toTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)),
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true, 
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.ccTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)),
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true,
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.bccTypeahead = new HPITypeAhead({
                options: JSON.parse(JSON.stringify(self.model.typeAheadContactList.emails)),
                enterKeys : this.enterKeys,
                displayKey: 'emailAddress',
                searchOn: 'emailAddress',
                isGrowable: true,
                tabIndex: 2,
              	overrideLoading : true,
              	hideNoResultMessage: this.hideNoResultMessage
        	});
        	self.typeaheadResolved = true;
        	self.startListening();
			if(self.rendered){
	         	self.setViews({
	         		'#toContacts': self.toTypeahead,
	         		"#toRecipientsSubview": self.toRecipientsView,
	         		'#ccContacts': self.ccTypeahead,
	         		"#ccRecipientsSubview": self.ccRecipientsView,
	         		'#bccContacts': self.bccTypeahead,
	         		"#bccRecipientsSubview": self.bccRecipientsView
	         	}).render();
	        }else{
	        	self.setViews({
	         		'#toContacts': self.toTypeahead,
	         		"#toRecipientsSubview": self.toRecipientsView,
	         		'#ccContacts': self.ccTypeahead,
	         		"#ccRecipientsSubview": self.ccRecipientsView,
	         		'#bccContacts': self.bccTypeahead,
	         		"#bccRecipientsSubview": self.bccRecipientsView
	         	});
	        }
        },
        startListening: function(){
        	if(this.typeaheadResolved){
        		this.stopListening(this.toTypeahead);
        		this.stopListening(this.ccTypeahead);
        		this.stopListening(this.bccTypeahead);
	        	this.listenTo(this.toTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendEmail.Constants.TO, option);
					}
				}, this);
				this.listenTo(this.ccTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendEmail.Constants.CC, option);
					}
				}, this);
				this.listenTo(this.bccTypeahead,'change:selected', function(option){
					if(option){
						this.addToRecipientsSubView(SendEmail.Constants.BCC, option);
					}
				}, this);
				this.listenTo(this.toTypeahead,'render:done', function(){
					// check if we should show the required class on the 'To' field
					if (this.toRecipientsView.addedEmailAddresses.length <= 0) {
		                $(".typeahead-" + this.toTypeahead.cid + ".tt-input").addClass('bs-callout-basic bs-callout-warning');
		            }

					$(".typeahead-" + this.toTypeahead.cid + ".tt-input").focus();
				}, this);
			}
        },
        beforeRender: function(){
        	if(this.typeaheadResolved){
        		this.setView('#toContacts', this.toTypeahead);
        		this.setView('#ccContacts', this.ccTypeahead);
        		this.setView('#bccContacts', this.bccTypeahead);
        	}
        },
        afterRender: function() {
			this.rendered = true;
			if(this.typeaheadResolved){
				this.startListening();
			}
		},
		serialize: function(){
			return {
				showCC: this.model.showCC,
				showBCC: this.model.showBCC,
				// default to true even if the config is not defined yet
				showBCCToggleButton: this.parent.config.get("enableBCCControl") === "true" || this.parent.config.get("enableBCCControl") == undefined
			};
		},
		// small helper function for addToRecipientsSubView, which was getting a bit long
		differentiateSubView: function(fieldFlag){
			// ------- Begin code for differentiating between to, cc, and bcc fields ---------
			var isTo = false,isCC = false,isBCC = false;
			var recipientsSubView;
			var typeahead;
			var checkListString;
			switch (fieldFlag){  // using a switch statement to target the right objects so there aren't if statements everywhere
				case SendEmail.Constants.TO:
					recipientsSubView = this.toRecipientsView;
					typeahead = this.toTypeahead;
					checkListString = "toCheckList";
					isTo = true;
					break;
				case SendEmail.Constants.CC:
					recipientsSubView = this.ccRecipientsView;
					typeahead = this.ccTypeahead;
					checkListString = "ccCheckList";
					isCC = true;
					break; 

				case SendEmail.Constants.BCC:
					recipientsSubView = this.bccRecipientsView;
					typeahead = this.bccTypeahead;
					checkListString = "bccCheckList";
					isBCC = true;
					break;
			}
			// -------- End code for differentiating between to, cc, and bcc fields --------- 

			// now simply return all the parameters for the the specified field, (to, cc, or bcc)
			return {
				isTo: isTo, 
				isCC: isCC, 
				isBCC: isBCC, 
				recipientsSubView: recipientsSubView,
				typeahead: typeahead, 
				checkListString: checkListString
			};
		},
		addToRecipientsSubView: function(fieldFlag, currentUser) {

			var fieldParams = this.differentiateSubView(fieldFlag); // dial in on which field we're adding to 

			if (!currentUser) {
				var tempEmailAddress = $(".typeahead-" + fieldParams.typeahead.cid + ".tt-input").val(); // grab the address off the typeahead (if anything's there)
				if (tempEmailAddress){
					currentUser = {
						emailAddress: tempEmailAddress						
					};
				}
			}

			if(currentUser) {
				// below here is functionality for parsing emails etc
				var emailAddressString = currentUser.emailAddress ? currentUser.emailAddress : currentUser.value;
				var emailLists = SendEmail.parseMultipleEmails(emailAddressString); // get validEmailList, invalidEmailList, and duplicatedEmailList on this object

				// now that we've parsed the emails, we need to do certain things for valid emails, invalid emails, and duplicated emails
				if (emailLists.validEmailList.length != 0){
					var addedEmailAddresses = []; 
					_.each(fieldParams.recipientsSubView.addedEmailAddresses, function(address){addedEmailAddresses.push(address.emailAddress);});
					emailLists.validEmailList = _.filter(emailLists.validEmailList, function(validEmail){
						if (addedEmailAddresses.indexOf(validEmail) > -1){ // can't use "includes()" in IE
							emailLists.duplicatedEmailList.push(validEmail);
							return false; // it's a duplicate, don't want it in the validEmailList
						}
						this.model.emailInfoModel.get(fieldParams.checkListString).push(new Backbone.Model({ // push this new email onto the emailinfoModel on the right checklist
							"emailAddress": validEmail
						})); 
						fieldParams.recipientsSubView.addedEmailAddresses.push({ "emailAddress": validEmail, "isTo": fieldParams.isTo, "isCC": fieldParams.isCC, "isBCC": fieldParams.isBCC}); //tack it onto the emails we're sending to
						return true; // unique, leave it in the validEmailList
					}, this);
				}

				// error handling
				fieldParams.recipientsSubView.errorMessage = ""; // zero out the error message
				if (emailLists.invalidEmailList.length >= 1){ 
					fieldParams.recipientsSubView.errorMessage += SendEmail.Localizations.error.invalidEmail + emailLists.invalidEmailList.join(", ") + ". ";
				}

				if (emailLists.duplicatedEmailList.length >= 1){
					fieldParams.recipientsSubView.errorMessage += SendEmail.Localizations.error.duplicatedEmail + emailLists.duplicatedEmailList.join(", ") + ". ";
				}
				
				// moving on to to the final phase	
				if (emailLists.validEmailList.length > 0){
					fieldParams.typeahead.clear();
				}
				if (this.toRecipientsView.addedEmailAddresses.length > 0){ // remove the warning orange on the to field
		        	$(".typeahead-" + this.toTypeahead.cid + ".tt-input").removeClass('bs-callout-basic bs-callout-warning');		
				}
							
				fieldParams.recipientsSubView.render(); // all done, render the badges and show the relevant error messages (if any)
				this.trigger('emails:changed');
			}

			if (fieldParams.isTo){
				this.parent.canSubmit(); // check if we're good to send the email, but only on a to field. Edits to a cc/bcc field can never cause an email to become sendable/unsendable
			}
		},
		removeClicked: function(event){
        	var self = this;
        	//get the id so we know if the object to remove is a user, group, or date
        	var value = this.$(event.currentTarget)[0].id;
        	//make this the id of the remove date x and have it call its own remove function
        	if (value){
        		var name = this.$(event.currentTarget)[0].parentElement.id;
	        	if(value.indexOf(SendEmail.Constants.TO) > -1){
	        		self.removeToContact(name);
	        	}
	        	//need to put bcc first, otherwise the cc indexOf will catch bcc
	        	else if  (value.indexOf(SendEmail.Constants.BCC) > -1){
	        		self.removeBccContact(name);
	        	}
	        	else if  (value.indexOf(SendEmail.Constants.CC) > -1){
	        		self.removeCcContact(name);
	        	}
	    	}
			// check if we should show the required class on the 'To' field
			if (this.toRecipientsView.addedEmailAddresses.length <= 0) {
            	$(".typeahead-" + this.toTypeahead.cid + ".tt-input").addClass('bs-callout-basic bs-callout-warning');
            }
	    	this.parent.canSubmit();
	    	this.trigger('emails:changed');
        },
		removeToContact: function(item) {
			this.model.emailInfoModel.get("toCheckList").remove(this.model.emailInfoModel.get("toCheckList").findWhere({emailAddress : item}));
			this.toRecipientsView.addedEmailAddresses = _.without(this.toRecipientsView.addedEmailAddresses , _.findWhere(this.toRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.toRecipientsView.render();
		},
		removeCcContact: function(item) {
			this.model.emailInfoModel.get("ccCheckList").remove(this.model.emailInfoModel.get("ccCheckList").findWhere({emailAddress : item}));
			this.ccRecipientsView.addedEmailAddresses = _.without(this.ccRecipientsView.addedEmailAddresses, _.findWhere(this.ccRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.ccRecipientsView.render();
		},
		removeBccContact: function(item) {
			this.model.emailInfoModel.get("bccCheckList").remove(this.model.emailInfoModel.get("bccCheckList").findWhere({emailAddress : item}));
			this.bccRecipientsView.addedEmailAddresses = _.without(this.bccRecipientsView.addedEmailAddresses, _.findWhere(this.bccRecipientsView.addedEmailAddresses, {emailAddress : item}));
			this.bccRecipientsView.render();
		},
		focusTo: function() {
			this.toRecipientsView.errorMessage = "";
			this.toRecipientsView.$(".error-message-" + this.toRecipientsView.cid).hide();
		},

		focusCC: function() {
			this.ccRecipientsView.errorMessage = "";
			this.ccRecipientsView.$(".error-message-" + this.ccRecipientsView.cid).hide();
		},
		focusBCC: function() {
			this.bccRecipientsView.errorMessage = "";
			this.bccRecipientsView.$(".error-message-" + this.bccRecipientsView.cid).hide();
		},
		toggleCC: function(){
			if(this.model.showCC && this.model.emailInfoModel.get("ccCheckList").length===0 && !this.model.currentCCEmail)
			{
				this.model.showCC = false;
			}
			else if(!this.model.showCC)
			{
				this.model.showCC = true;
			}
			this.render();
		},
		toggleBCC: function(){
			if(this.model.showBCC && this.model.emailInfoModel.get("bccCheckList").length===0 && !this.model.currentBCCEmail)
			{
				this.model.showBCC = false;
			}
			else if(!this.model.showBCC)
			{
				this.model.showBCC = true;
			}
			this.render();
		}
	});

	/*This subview allows us to rerender only the list of recipients
	when a group or user is added or removed.
	Otherwise, rerendering the view resets the contents of the message and
	kills the typeahead listeners.*/
	SendEmail.RecipientsSubView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailrecipients",
		initialize: function(){
			this.addedEmailAddresses = [];
			this.errorMessage = ""; 
		},
		afterRender: function(){
			this.showOrHideErrors(); 
		},
		showOrHideErrors: function(){
			if (this.errorMessage){
				//$(".error-message-" + this.cid).show().html("<span>" + this.errorMessage + "</span>"); // show any remaining error messages
				$(".error-message-" + this.cid).show().html(this.errorMessage); // show any remaining error messages
			}else{
				$(".error-message-" + this.cid).hide();
			}
		},
		serialize: function(){
			return {
				addedEmailAddresses : this.addedEmailAddresses,
				cid : this.cid
			};
		}
	});

	SendEmail.UnattachableDocsView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailunattachabledocs",
		initialize: function(options){
			this.unattachableDocs = options.unattachableDocs || [];
		},
		addUnattachableDoc: function(newDoc){
			this.unattachableDocs.push(newDoc);
			this.render();
		},
		serialize: function(){
			return {
				unattachableDocs: this.unattachableDocs
			};
		}
	});

	SendEmail.TemplatesView = Backbone.Layout.extend({
		template: "actions/sendemail/sendemailtemplates",
		events: {
			"click #template-item": "triggerUpdateBodyValue"
		},
		initialize: function (options) {
			this.templates = options.templates;
		},
		triggerUpdateBodyValue: function (event) {
			var templateName = $(event.currentTarget).attr("data-value");
			this.trigger('sendEmail:emailBodyView:insertBodyText', this.getTemplateContent(templateName));
		},
		getTemplateContent: function (templateName) {
			var template = _.find(this.templates.models, function (templateModel) {
				return templateModel.get("name") === templateName;
			});

			var templateBody = template.get("content");

			if (app.context.container) { // skipped in search not stage
				// replace oc_variables within the template 
				var copyOfTemplateBody = templateBody; // need two copies for regex to work properly
				var regex = /\$\w*\$/gm; // matches if the first and last char in the word are $
				var match;

				// while there is regex match
				while ((match = regex.exec(copyOfTemplateBody)) !== null) {
				    
				    var oc_prop = match[0].replace(/\$/g, ""); // remove all $ from the var
				    var oc_value = app.context.container.get("properties")[oc_prop];
				    if (oc_value) { // if oc_prop exists oc_value should be populated

						// find if prop is a date if it is format the date
						oc_value = this.findAdminOTCFormat(oc_prop, oc_value);

                        // replace the match for the oc_value in the template
				    	templateBody = templateBody.replace(match[0], oc_value);
					}
				}
			}
			return templateBody;
		},
		findAdminOTCFormat: function(oc_prop, oc_value) {
			app.context.configService.getAdminOTC(function(otc) { 
				var folder = otc.get("configs").findWhere({"ocName": app.context.container.get("objectType")});
				if (folder) {
					var attr = folder.get("attrs").findWhere({"ocName": oc_prop});
					if (attr && attr.get("dataType") === "date") {
						if(attr.get("filter") === "date") {
							app.context.dateService.getFormattedDate([oc_value])
								.done(function(formattedDates) {
									oc_value = formattedDates[0];
								});
						} else if (attr.get("filter") === "datetime") {
							app.context.dateService.getFormattedDatetime([oc_value])
								.done(function(formattedDates) {
									oc_value = formattedDates[0];
								});
						}
					}
				}
			});

			return oc_value;
		},
		serialize: function () {
			if (this.templates) {
				return {
					templates: this.templates.toJSON()
				};
			}
		}
	});

	//list of object types that won't be included in the list of
	//possible email attachments (default is you can't send a note or folder as an attachment)
	var badAttachmentObjectTypes = ['Note', 'Folder'];

	actionModules.registerAction("sendEmail", SendEmail, {
        "actionId" : "sendEmail",
      	"label" : (window.localize("modules.actions.sendEmail.sendEmail")),
      	"icon" : "envelope"
    },
    {
    	"badAttachmentObjectTypes" : badAttachmentObjectTypes
    });
	
	actionModules.registerAction("sendEmail-group", SendEmail, {
        "actionId" : "sendEmail-group",
      	"label" : (window.localize("modules.actions.sendEmail.sendEmail")),
      	"icon" : "envelope"
    },
    {
    	"badAttachmentObjectTypes" : badAttachmentObjectTypes
    });

	return SendEmail;

});
require(["sendemail"]);
