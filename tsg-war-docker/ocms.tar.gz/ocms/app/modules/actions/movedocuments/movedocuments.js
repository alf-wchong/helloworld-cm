define("movedocuments", [
	"app",
	"handlebars",
	"modules/actions/actionmodules",
	'modules/common/spinner',
	'modules/common/ocquery',
	"modules/hpiadmin/actionconfig/actions/movedocuments/movedocumentscustomconfig"
],
function(app, Handlebars, actionModules, HPISpinner, OCQuery, MoveDocumentsCustomConfig) {
	
	"use strict";

	var ENTER_KEY = 13;
	var MIN_CHARS_FOR_SEARCH = 3;

	var MoveDocuments = {};

	MoveDocuments.FolderItem = Backbone.Model.extend({
		defaults: {
			folderPath: '',
			objectId: '',
			objectType: '',
			allFolderProps: {},
			tableDisplayValues: []
		}
	});

	MoveDocuments.View = Backbone.Layout.extend({
		template: "actions/movedocuments/movedocuments",
		events: {
			"click #moveDocuments_submitBtn": "submit"
		},
		initialize: function(options){
			this.config = options.config;
			this.myHandler = options.config.get("handler");
            this.searchResultsViewController = this.options.searchResultsViewController;

			// Create an event bus and apply listeners onto it so we can communicate to and from child views
			this.eventBus = _.extend({}, Backbone.Events);
			this._applyListeners();

			this.buildSearchControlView();
		},
		_applyListeners: function(){
			this.listenTo(this.eventBus, 'moveDoc:folderSelected', this._setSelectedFolder);
			
			this.listenTo(this.eventBus, 'moveDoc:executingQuery', this._resetSelectedFolderView);
		},
		buildSearchControlView: function(){
			this.searchControlView = new MoveDocuments.SearchControl({
				config: this.config,
				eventBus: this.eventBus
			});
			// Set child folder search view before rendering
			this.setView('#moveDocuments_folderSearch', this.searchControlView);
		},
		_setSelectedFolder: function(selectedFldr){
			this.selectedFolderView = new MoveDocuments.FolderResultsDisplay({
				'config': this.config,
				'folderResults': [selectedFldr], // view expects an array so it doesn't break
				'isSelectedFolder': true
				// no need for an eventBus because this is only for display purposes
			});
			this.setView('#moveDocuments_selectedFolder', this.selectedFolderView).render();

			// Set the object id on the view so we can validate this action properly
			this.selectedFolder = selectedFldr.get('objectId');
			this.validateSubmitBtn();
		},
		_resetSelectedFolderView: function(){
			if(this.selectedFolderView){
				this.selectedFolderView.remove();
			}
		},
        validateSubmitBtn: function(){
        	if(this.selectedFolder){
        		$("#moveDocuments_submitBtn").removeClass("disabled");
        	}else{
				$("#moveDocuments_submitBtn").addClass("disabled");
        	}
        },
        submit: function(){
			app[this.myHandler].trigger("loading", true);
						
			// The selected documentIds should already be on the action as parameters.
        	this.action.get("parameters").targetFolderId = this.selectedFolder;
			this.action.get("parameters").sourceFolderId = app.context.container.id;
			
        	this.action.execute({
				context: this,
				success: this._successfullyMovedDocumentCb,
        		error: this._errorMovingDocumentCb
        	});
		},
		_successfullyMovedDocumentCb: function(actionData){
			// importing actionData in case we want to report more clearly on errors 
			app[this.myHandler].trigger("loading", false);

			var message = (window.localize("modules.actions.moveDocument.successfullyMoved"));
			app[this.myHandler].trigger("showMessage", message);

			// Call the delte on tableview so we can "refresh" the collection without the moved items, only if we are in the context of a folder
			// so make sure the two values exist and are equal to each other.
			if(this.searchResultsViewController &&
				(app.context.container.id && this.action.get('parameters').sourceFolderId) &&
				app.context.container.id === this.action.get('parameters').sourceFolderId)
			{
				this.searchResultsViewController.tableEventsRef.trigger("search:deleteObjects", this.action.get('parameters').objectIds);
			}
		},
		_errorMovingDocumentCb: function(){
			app[this.myHandler].trigger('loading', false);
			app[this.myHandler].trigger('showError', window.localize('modules.actions.moveDocument.errorMovingDocument'));
		},
		serialize: function(){
			return {
				modal : this.myHandler === "modalActionHandler",
				rightSide : this.myHandler === "rightSideActionHandler"
			};
		}
	});

	MoveDocuments.SearchControl = Backbone.Layout.extend({
		template: 'actions/movedocuments/searchcontrol',
		events: {
			'keyup #moveDocument_searchInput': 'updateInputQuery',
			'click #moveDocuments_searchBtn': 'executeFolderQuery'
		},
		initialize: function(options){
			this.config = options.config;
			this.eventBus = options.eventBus;
			this.availableFolderPaths = [];
		},
		preventFormSubmission: function(evt){
            var code = evt.keyCode || evt.which;
            if(code === ENTER_KEY){
            	evt.preventDefault();
			}
			return code;
		},
		updateInputQuery: _.throttle(function(evt){
			this.searchTerm = this.$(evt.currentTarget).val();

			var code = this.preventFormSubmission(evt);
			var searchTermValid = this.isValidSearchTerm();
			   
           	if(searchTermValid && code === ENTER_KEY){
                this.executeFolderQuery();
           	}
		}, 200, this),
		isValidSearchTerm: function(){
			if(this.searchTerm && this.searchTerm.length >= MIN_CHARS_FOR_SEARCH){ //min three character length
				this.$('#moveDocuments_searchBtn').removeClass('disabled');
				this.$('#moveDocuments_lengthWarn').text('');
				return true;
			}else if(!this.searchTerm || this.searchTerm.length < MIN_CHARS_FOR_SEARCH){
				this.$('#moveDocuments_searchBtn').addClass('disabled');
				this.$('#moveDocuments_lengthWarn').text(window.localize("modules.actions.moveDocument.threeCharsMinWarn"));
				return false;
			}
		},
		executeFolderQuery: function(){
			// Remove the selected view if it's created
			this.eventBus.trigger('moveDoc:executingQuery');

			// Indicate to the user search has begun.
			this.spinner = HPISpinner.createSpinner({left: '95%',top: '75%'}, this.$el.find(".searchSpinnerDiv")[0]);

			// Build the folder fetch query and then search for those folders.
			this.buildFolderQuery();
			this.folderQuery.fetch({
				global: false, //don't gray out screen on ajax request
				context: this,
				success: this._folderQuerySuccessCb,
				complete: this._folderQueryCompleteCb
			});
		},
		_folderQuerySuccessCb: function(ocQueryData){
			var getFolderNameDefArr = []; // keep array of deferred folder path calls to render the subview when all are complete.
			this.availableFolderPaths = []; // empty the array before repopulating, especially if no results come back

			if(ocQueryData.length > 0){
				ocQueryData.fullCollection.each(function(oco){
					// Need to make an external deferred because we want to execute callback code for this array of calls
					// only when all calls are done, regardless of success or failure. See the $.when() documentation
					// as reference to understand why we can't just push the $.ajax deferred into the array.
					var deff = $.Deferred();
					getFolderNameDefArr.push(deff);

					// Only if it's configured, should we make a call to OC to get folder paths
					if(this.config.get('displayFolderPath')){
						// call /content/getPathById for each to get a list of available folders.
						$.ajax({
							global: false,
							context: this,
							url: app.serviceUrlRoot + '/content/getPathById?objectId=' + encodeURIComponent(oco.get('objectId')),
							success: function(ocQueryData) {
								var lastFldrIndex = ocQueryData.lastIndexOf('/');
								var folderPath = ocQueryData.substring(0, lastFldrIndex + 1);
								var folderName = ocQueryData.substring(lastFldrIndex + 1, ocQueryData.length);

								// Push the information we will use for display purposes.
								this.availableFolderPaths.push(new MoveDocuments.FolderItem({
									folderPath: folderPath,
									folderName: folderName,
									objectId: oco.get('objectId'),
									objectType: oco.get('objectType'),
									allFolderProps: oco.get('properties')
								}));
							},
							error: function(){}, // no-op because we don't want the global setup to fire an error modal
							complete: function(){ // executes everytime after above callbacks
								deff.resolve.apply(this, arguments);
							}
						});
					}
					else {
						// Push the information we will use for display purposes.
						this.availableFolderPaths.push(new MoveDocuments.FolderItem({
							folderName: oco.get('objectName'),
							objectId: oco.get('objectId'),
							objectType: oco.get('objectType'),
							allFolderProps: oco.get('properties')
						}));
						deff.resolve();
					}
				}, this);

				// Create the subview displaying all found folders once their path has been retrieved.
				$.when.apply($, getFolderNameDefArr).then(_.bind(this._createFolderResultsView, this));
			}
		},
		_folderQueryCompleteCb: function(){
			HPISpinner.destroySpinner(this.spinner);
		},
		buildFolderQuery: function(){
			if(!this.folderQuery){
				this.folderQuery = new OCQuery.Collection([], {mode: "client"});
			}

			// Clear any existing params and push type definition and name value definitions
			this.folderQuery.searchParameters = [];
			this.folderQuery.searchParameters.push({
				'paramType': 'type',
				'paramName': this.config.get('selectedFolderType'),
				'paramValue': this.config.get('selectedFolderType')
			});
			this.folderQuery.searchParameters.push({
				'paramType': 'property',
				'paramName': this.config.get('attrToSearchOn'),
				'paramValue': this.searchTerm
			});
		},
		_createFolderResultsView: function(){
			this.folderResultsView = new MoveDocuments.FolderResultsDisplay({
				'config': this.config,
				'folderResults': this.availableFolderPaths,
				'eventBus': this.eventBus
			});
			this.setView('#moveDocuments_folderResults', this.folderResultsView).render();
		},
		serialize: function(){
			return {
				attrToSearchOn: this.config.get('attrToSearchOn'),
				selectedFolderType: this.config.get('selectedFolderType')
			};
		}
	});

	MoveDocuments.FolderResultsDisplay = Backbone.Layout.extend({
		template: 'actions/movedocuments/folderresults',
		events: {
			'click .moveDoc_fldrRes_selectItem': 'selectFolderItem'
		},
		initialize: function(options){
			this.config = options.config;
			this.folderResults = options.folderResults;
			this.isSelectedFolder = options.isSelectedFolder;
			this.eventBus = options.eventBus;

			this.prepareTableDisplayValues();
		},
		prepareTableDisplayValues: function(){
			// We want to capture the index to highlight for the user, we'll initialize it to -1 so it won't display if the search term isn't being displayed.
			this.searchTermHighlightIndex = -1;

			_.each(this.folderResults, function(result){
				var displayValueArr = [];

				_.each(this.config.get('tableDisplayAttrs'), function(attr, index){
					displayValueArr.push(result.get('allFolderProps')[attr.ocName]);

					// If the current display attr matches the search attr, then let's save the index so we can highlight it for the user
					if(this.searchTermHighlightIndex === -1 && this.config.get('attrToSearchOn') === attr.ocName){
						this.searchTermHighlightIndex = index;
					}
				}, this);

				result.set('tableDisplayValues', displayValueArr);
			}, this);
		},
		selectFolderItem: function(evt){
			// Find the id and associated folder object to trigger an event to the parent view that a selection has been made
			var selectedId = this.$(evt.currentTarget).val();
			var selectedFolderObj = _.find(this.folderResults, function(fldr){
				return fldr.get('objectId') === selectedId;
			});

			if(this.eventBus){
				this.eventBus.trigger('moveDoc:folderSelected', selectedFolderObj);
			}
		},
		serialize: function(){
			return{
				'folderResults': this.folderResults,
				'isSelectedFolder': this.isSelectedFolder,
				'tableDisplayAttrs': this.config.get('tableDisplayAttrs'),
				'displayFolderPath': this.config.get('displayFolderPath'),
				'searchTermHighlightIndex': this.searchTermHighlightIndex
			};
		}
	});

	MoveDocuments.CustomConfigView = MoveDocumentsCustomConfig.View;

	actionModules.registerAction("moveDocument", MoveDocuments, {
		"actionId" : "moveDocument",
		"label" : (window.localize("modules.actions.moveDocument.moveDoc")),
		"icon" : "export",
		"modalSize" : "xl"
	});
	actionModules.registerAction("moveDocumentCollection", MoveDocuments, {
		"actionId": "moveDocumentCollection",
		"label": window.localize("modules.actions.moveDocument.moveDoc"),
		"icon": "export",
		"modalSize": "xl"
	});

	return MoveDocuments;

});
require(["movedocuments"]);
