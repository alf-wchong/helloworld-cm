// Advancedsearch module
define("viewannotations",[
  // Application.
  "app",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, actionModules) {
    "use strict";

    var action = {};

    action.localize = {
        message: "We're opening the annotation application in a new window. Please add your annotations and save, then return here and click OK to continue"
    };


    action.View = Backbone.Layout.extend({
        template: "actions/viewannotations",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.toggleLoader = function(bool){
                app[this.myHandler].trigger("loading", bool);
            };
            window.open(app.openAnnotateURL +
             "/login/external.htm?docId=" + this.action.get("parameters").objectId + "&ticket=" + app.ticket  +
             "&username=" + app.user.get("loginName") + "&readOnlyView=true");
        },
        events: {
            "click #annotate-ok" : "dismiss"
        },
        serialize: function(){
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        },
        dismiss : function(){
            app.trigger("stage.refresh.documentId", true);
        }

    });

    actionModules.registerAction("viewAnnotations", action, {
        "actionId" : "viewAnnotations",
        "label" : "View Annotations",
        "icon" : "comment"
    });
    
    return action;
});
require(["viewannotations"]);