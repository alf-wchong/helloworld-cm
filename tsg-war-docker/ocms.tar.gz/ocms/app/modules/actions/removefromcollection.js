define("removefromcollection",[
  // Application.
  "app",
  "knockout",
  "modules/actions/actionmodules"
],

// Map dependencies from above array.
function(app, ko, actionModules) {
    "use strict";
	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    function ViewModel(action, myHandler, searchResultsViewController) {
        
        var self = this;
        self.searchResultsViewController = searchResultsViewController;
        
        self.collectionId = ko.observable();

        self.removeFromCollection = function(){
            // If removing from single action menu,
            // Add the single objectId into a the
            // objectIds array parameter
            if (action.get("parameters").objectId !== null) {
                action.get("parameters").objectIds = [action.get("parameters").objectId];
            }
            self.toggleLoader(true);
            action.execute({
                success: function(data){
                    self.toggleLoader(false);
                    if (self.searchResultsViewController) {
                        self.searchResultsViewController.tableEventsRef.trigger("search:removeAllChecked");
                    }
                    app[myHandler].trigger("showMessage", window.localize("modules.actions.removeFromCollection.itemSuccessfully"));
                    app.trigger("stage.refresh.containerId", true);
                    // here is where we need to refresh the search view
                    app.trigger("action:itemModified", self.collectionId());

                },
                error: function(jqXHR, textStatus, errorThrown){
                    self.toggleLoader(false);
                    app[myHandler].trigger("showError", window.localize("modules.actions.removeFromCollection.sorry") +
                        " " + jqXHR.responseText);
                }
            });
        };

        self.toggleLoader = function(bool){
                app[myHandler].trigger("loading", bool);
        };
 
    }

    action.View = Backbone.Layout.extend({
        template: "actions/removefromcollection",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.viewModel = new ViewModel(this.action, this.myHandler, this.searchResultsViewController);
        },

        afterRender: function(){
            kb.applyBindings(this.viewModel, this.$el[0]);

        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
    });

    actionModules.registerAction("removeFromCollection", action, {
        "actionId" : "removeFromCollection",
        "label" : "Remove From Collection",
        "icon" : "remove"
    });

    actionModules.registerAction("removeFromCollection-singleDoc", action, {
        "actionId" : "removeFromCollection-singleDoc",
        "label" : "Remove From Collection",
        "icon" : "remove"
    });
    
    return action;
	
});
require(["removefromcollection"]);