define("reassignwizardworkflowtask",[
	//Application
	"app",
	"modules/actions/actionmodules",
	"modules/common/queryabletypeahead",
	"modules/common/hpiconstants",
	"handlebars",
	"modules/hpiadmin/actionconfig/actions/reassignwizardworkflowtask/reassignwizardworkflowtaskconfig",
	"oc"
],

function(app, actionModules, QueryableTypeahead, HPIConstants, Handlebars, ReassignWizardWorkflowTaskCustomConfigView, OC) {
	"use strict";

	//Start with declaring your id - this is the same value as in the filename between the words action. and .js
	//get the config from the namespace. The action handler is responsible for this; //
	var ReassignWizardWorkflowTask = {};

	ReassignWizardWorkflowTask.Model = Backbone.Model.extend({
        defaults: {

        },
        initialize: function(options) {
            this.options = _.defaults(options,this.defaults);
        }
    });

    ReassignWizardWorkflowTask.CustomConfigView = ReassignWizardWorkflowTaskCustomConfigView.View;

	ReassignWizardWorkflowTask.View = Backbone.Layout.extend({
		template: "actions/reassignwizardworkflowtask",
		events: {
			"click #reassignTask-submitBtn" : "onSubmit",
			"change #reassignTask-taskSelect" : "selectTask",
			'keydown #reassignTask-userList' : 'sanitizeKey'
		},
		initialize: function(){
			var self = this;
			this.action = this.options.action;
			this.myHandler = this.options.config.get("handler");
			this.selectedUsers = [];
			this.selectedUser = '';
			this.objectId = this.action.get("parameters").objectId;
			this.usersWhoHaveTasks = [];	
			this.taskEntryList = [];
			this.selectedTaskEntry = {};
			this.selectedUserLabel = '';
			this.isLastUserSelectionValid = false;
			this.isFutureTask = false;
			this.groupName = this.options.config.get("groupName");
			this.caseSensitiveRequired = this.options.config.get("caseSensitiveRequired");
			this.futureTaskEnabled = this.options.config.get("futureTaskEnabled");

			// decide what endpoint url to assign based on if the user configures the functionality in the admin
			this.getTasksUrl = (this.futureTaskEnabled) ? app.serviceUrlRoot + "/aw-workflow/getCurrentAndFutureWizardTasks?formId=" + this.objectId : app.serviceUrlRoot + "/aw-workflow/getWizardTasks?formId=" + this.objectId;

            //Clean up logic
            this.caseSensitiveRequired = ((this.caseSensitiveRequired === "true" || this.caseSensitiveRequired === true) ? true : false);

			this.startListening();

			$.when(this.getTasks()).done(function(){
				self.createUserTypeahead();
			});

			// custom handlebar to display the state if it is a future task but don't if it is active
			Handlebars.registerHelper('rt-displayState', function (state1, state2, options) {
			    if (state1 === state2) {
			        return options.fn(this);
			    } else{
			        return options.inverse(this);
			    }
			});

		},
		createUserTypeahead: function(){
            var self = this;
            // search on the oco for the form attribute
            var oco = new OC.OpenContentObject({ objectId : self.objectId });
            oco.fetch().done(function(docOco){

            	// update the set group name
                self.setGroupName(docOco);

                // build up the queryUrl with the group name
                self.queryUrl = app.serviceUrlRoot + "/authorities/search";
                self.queryUrl = self.queryUrl + "?authorityType=" + "user" + "&childOfAuthority=" + self.groupName + "&attrToSearch=" + "displayName" + "&matchType=" + "contains" + "&isCaseSensitive=" + self.caseSensitiveRequired;

                self.typeahead = new QueryableTypeahead({
                    queryUrl: self.queryUrl,
                    displayKey: 'displayName',
                    searchOn: 'displayName',
                    placeholder: 'Start typing here...'
                });

                // now call the listener here since the groupName is correctly set now
                self.startListening();
                self.render();
            });

        },
        setGroupName: function(docOco){
            var configuredGroupName = this.options.config.get("groupName");
            // check to see if the groupName is configured and if not then do the searching on all groups
            if (configuredGroupName && this.selectedTaskEntry.roleName){
                // parse the groupName to see if they are injecting properties
                if (configuredGroupName.indexOf("$") !== -1){

                    var attributeValues = app.context.util.parsePatternForAttributes(configuredGroupName);
                    _.each(attributeValues, function(attr) {
                        if (attr === "roleName"){
                            configuredGroupName = configuredGroupName.replace("$" + attr + "$", this.selectedTaskEntry.roleName);

                        }else if (docOco.properties.hasOwnProperty(attr)){
                            // check if the attribute isn't repeating and is just a string
                            if (!Array.isArray(docOco.properties[attr])){
                            	configuredGroupName = configuredGroupName.replace("$" + attr + "$", docOco.properties[attr]);
                            }
                        }
                    },this);

                    // set the groupname now that the attributes are injected
                    this.groupName = configuredGroupName;
                }

            }else{
                this.groupName = HPIConstants.WizardGroups.WizardContributorGroup;
            }
        },
		startListening: function(){
            if(this.typeahead){
                this.stopListening(this.typeahead);
                this.listenTo(this.typeahead, 'change:selected', function(option){
                    if(option){
                        this.selectedUserEventHandler(option);
                    }
                    else{
                        this.selectedUser = '';
                        this.dialog(false);
                        this.validSubmitData(false);
                    }
                }, this);

                this.listenTo(this.typeahead, 'typeahead:clear', function(){
                    this.clearUserInput();
                }, this);
            }
        },
		beforeRender: function(){
			this.setView('#reassignTask-userList', this.typeahead);
			_.each(this.taskEntryList, function(task){
				if (task.labelField === this.selectedTaskEntry.labelField && task.roleName === this.selectedTaskEntry.roleName){
					task.selected = true;
				}else{
					task.selected = false;
				}
			}, this);
		},
        serialize: function(){
            var modal = false;
			var rightSide = false;
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				taskEntryList: this.taskEntryList,
				groupName: this.groupName,
				multipleTask: this.multipleTask		
			};
        },
        onSubmit: function(){
        	var self = this;

			//disable submit button while call is happening.
            this.toggleSubmit(false);

			var taskId = self.selectedTaskEntry.taskId;
			var roleName = self.selectedTaskEntry.roleName;
			// if this is a group task, the labelField will contain the group name, and the taskOwner will be empty.
			var taskOwner = (self.selectedTaskEntry.taskOwner) ? self.selectedTaskEntry.taskOwner : self.selectedTaskEntry.labelField;
			//todo get rid of these error catches, form validation takes care of this.
			if(taskId === undefined && !self.isFutureTask){
				app[self.myHandler].trigger("showError", window.localize("modules.actions.reassignWizardWorkflowTask.unableToReassignTask"));
			}else if( self.selectedUser === undefined || self.selectedUser === '' ) {  //selectedUser must have a value selected
				app.trigger("alert:info", {header : window.localize("modules.actions.reassignWizardWorkflowTask.selectAUser"), message : window.localize("modules.actions.reassignWizardWorkflowTask.mustSelectUser")});
				return;
			}else{
				self.action.get("parameters").taskId = taskId;
				self.action.get("parameters").newUserLoginName = self.selectedUser;
				self.action.get("parameters").roleName = roleName;
				self.action.get("parameters").oldUserLoginName = taskOwner;
				self.action.get("parameters").isFutureTask = self.isFutureTask;

				self.action.execute({
					success : function() {
						app[self.myHandler].trigger("showMessage", window.localize("modules.actions.reassignWizardWorkflowTask.taskRessignedTo") + self.selectedUserLabel + ".");

						app.listenToOnce(app[self.myHandler], "hide", function() {
                            app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
                        });
					},
					error : function() {
						app[self.myHandler].trigger("showError", window.localize("modules.actions.reassignWizardWorkflowTask.failedToReassignTask"));
					}
				});
			}
		},
		validSubmitData: function(valid){
			var self = this;
			if (valid) {
				//then we show user feedback showing them what they're about to do
				$('.alert-danger').hide();
				self.dialog(true, window.localize("modules.actions.reassignWizardWorkflowTask.reassigningTask") + 
					self.selectedTaskEntry.labelField + window.localize("modules.actions.reassignWizardWorkflowTask.inThe")+
					self.selectedTaskEntry.roleName + window.localize("modules.actions.reassignWizardWorkflowTask.to") +
					self.selectedUserLabel + window.localize("modules.actions.reassignWizardWorkflowTask.toPerformThisAction"));
				self.toggleSubmit(true);
			} else {
				//then we disable Submit button
				self.dialog(false);
				$('.alert-danger').hide();
				self.toggleSubmit(false);
			}
		},
		selectedUserEventHandler: function(option){
			var self = this;
			//clear any previous validation
			$('.alert-success').hide();
			$('.alert-danger').hide();
			self.toggleSubmit(false);

			self.selectedUser = option.authorityId;
			self.selectedUserLabel = option.displayName + " (" + option.authorityId + ")";
			var valid = true;
			$.each(self.usersWhoHaveTasks, function(index, user) {
				if (user.authorityId === self.selectedUser && user.role === self.selectedTaskEntry.roleName){
					$('.alert-danger').html(window.localize("modules.actions.reassignWizardWorkflowTask.selectedUserIs"));
					$('.alert-danger').show();    
					valid = false;
					self.isLastUserSelectionValid = false;
				}
			});
			if (valid) {
				self.isLastUserSelectionValid = true;
				self.evaluateValidity();
			}
		},
		getTasks: function(){
			return $.ajax({
				context: this,
				url: this.getTasksUrl,
				success: function(result){
					_.each(result, function(item) {
						this.usersWhoHaveTasks.push({authorityId : item.assignee, role: item.roleName});
						this.taskEntryList.push({roleName : item.roleName, taskId : item.id, taskOwner: item.assignee, 
								labelField : item.labelName, state: item.state});
						
						if(result.length === 1){
							this.selectedTaskEntry = {roleName: item.roleName, taskId: item.id, taskOwner: item.assignee, labelField: item.labelName, state: item.state};
							this.multipleTask = false;
						}
						else{
							this.multipleTask = true;
						}
					},this);
				},
				error: function() {
					app[this.myHandler].trigger("loading", false);
					app[this.myHandler].trigger("showError",window.localize("modules.actions.reassignWizardWorkflowTask.failedToRetrieve"));
				}
			});
		},
		clearUserInput: function(){
			var self = this;
			self.selectedUser = '';
			self.selectedUserLabel = '';
			self.isLastUserSelectionValid = false;
			self.dialog(false);
			self.validSubmitData(false);
		},
		dialog: function(show, html){
			if (show) {
				$('.alert-success').html(html);
				$('.alert-success').show();
			}
			else {
				$('.alert-success').hide();
			}
		},
		toggleSubmit: function(enabled){
			if(enabled){
				document.getElementById('reassignTask-submitBtn').disabled = false;
			}else{
				document.getElementById('reassignTask-submitBtn').disabled = true;
			}
		},
		evaluateValidity: function(){
			if (this.selectedUser && this.selectedTaskEntry.roleName && (this.selectedTaskEntry.taskId || this.isFutureTask)){
                if (this.isLastUserSelectionValid){
                	this.validSubmitData(true);
                }
                else {
                	this.dialog(false);
                    this.toggleSubmit(false);
                }
            }
            else {
                this.validSubmitData(false);
            }
		},
		selectTask: function(){
			var data = $("#reassignTask-taskSelect option:selected").val();
			var parseData =JSON.parse(data);
            this.selectedTaskEntry = {roleName: parseData.roleName, taskId: parseData.taskId, taskOwner: parseData.taskOwner, labelField: parseData.labelField, state: parseData.state};
            if (this.selectedTaskEntry.state === "Future Task"){
				this.isFutureTask = true;
			}
			this.evaluateValidity();
			this.createUserTypeahead();
		},
		sanitizeKey: function(evt){
			//catch the enter key to prevent the query text being set as the selected user
            var code = evt.keyCode || evt.which;
            if(code==13){
                //prevent default for enter key only
                evt.preventDefault();
            }
        }
	});
		
	actionModules.registerAction("reassignWizardWorkflowTask", ReassignWizardWorkflowTask, {
       	"actionId" : "reassignWizardWorkflowTask",
      	"label" : (window.localize("modules.actions.reassignWizardWorkflowTask.reassignWizardTask")),
      	"icon" : "user",
      	"groups" : ["wizard", "reassign", "task"]
    });

	return ReassignWizardWorkflowTask;
	
});
require(["reassignwizardworkflowtask"]);