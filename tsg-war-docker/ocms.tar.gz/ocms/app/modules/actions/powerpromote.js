define("powerpromote",[
  // Application.
  "app",
  "modules/actions/actionmodules",
  "modules/tsg"
],

// Map dependencies from above array.
function(app, actionModules, TSG) {
	"use strict";

	var action = {};
	var maxASCIICharNum = 127;

	action.View = Backbone.Layout.extend({
		template: "actions/powerpromote",
		events : {
        	"keyup #inputUsername" : "updateUserName",
        	"keyup #inputPassword" : "updatePassword"

        },
		initialize: function() {
			this.action = this.options.action;
			this.config = this.options.config;
			// default promotion state to "Approved" if nothing else is configured.
			this.action.get("parameters").promoteToState = this.config.get("promoteToState") ? this.config.get("promoteToState") : "approved";
			this.myHandler = this.options.config.get("handler");
			this.toggleLoader = function(bool) {
				app[this.myHandler].trigger("loading", bool);
			};
		},

		beforeRender: function() {
			var self = this;
			
			// In the case of selecting the action on a single object
			if (self.action.get("parameters").objectId !== null) {
                self.action.get("parameters").objectIds = [self.action.get("parameters").objectId];
            }
            self.objectIds = self.action.get("parameters").objectIds;
			self.objectNames =  ko.observableArray([]);
			_.each(self.objectIds, function(objectId){
				TSG.services.ajaxService.getObjectProperties(objectId,
				function(obj) {
					self.objectNames.push({ name: obj.properties.objectName, id: obj.properties.objectId});
				});
			});

			this.viewModel = {
                taskId : ko.observable(),
				eSigUsername : ko.observable().extend({ required: true, validateMessage: maxASCIICharNum}),
				eSigPassword : ko.observable().extend({ required: true, validateMessage: maxASCIICharNum}),
				eSigError : ko.observable(),
				objectNames : self.objectNames,

				//prevents the user from entering any characters that are outside the scope of the maxASCIICharNum, defined above
				keyCheck : function(data, event){
					if(event.charCode>maxASCIICharNum){
						return false;
					}
					return true;
				},
        
                powerPromote : function(){
                    self.action.execute({
                        success : function(data) {
                            self.toggleLoader(false);
                              
                            if(data.result !== undefined && data.result.length > 0){
                                var failedToPromote = "";
                                _.each(self.objectNames(), function(obj){
                                    if(data.result.indexOf(obj.id) != -1){ //result exists in objectNames
                                        failedToPromote += obj.name + '<br />';
                                    }
                                });
                                app[self.myHandler].trigger("showError", window.localize("modules.actions.powerPromote.failedTo") + '<br />' + failedToPromote);
                            }else{
                                app[self.myHandler].trigger("showMessage", window.localize("modules.actions.powerPromote.powerPromoteInitiated"));
                            }

                            // if we have a single doc that was power promoted, this indicates we may be on the stage - trigger a refresh with the latest version
                            var oldId = self.action.get("parameters").objectId;
                            if(undefined !== oldId && null !== oldId && '' !== oldId) {
                                $.get(app.serviceUrlRoot + "/content/resolveVersion?objectId=" + oldId + "&label=LATEST", function(newId){
                                    app.trigger("stage.refresh.documentId", newId);
                                });
                            }								
                        },
                        error : function(jqXHR, textStatus, errorThrown) {
                          self.toggleLoader(false);
                          app[self.myHandler].trigger("showError", window.localize("modules.actions.powerPromote.failedToStart") + jqXHR.status + 
                                              " " + jqXHR.statusText);
                        }
                    });
                },

				onSubmit : function() {
					var eSigPage = self.config.get("eSigPage");
					if(eSigPage ==="true") {
						eSigPage = true;
					}
					else {
						eSigPage = false;
					}
					self.action.get("parameters").eSigEnabled = eSigPage;
					if(eSigPage) {
						if (self.viewModel.eSigUsername.isValid() && self.viewModel.eSigPassword.isValid()){
							self.toggleLoader(true);
							if(self.action.get("parameters").objectId === undefined){
								app[self.myHandler].trigger("showError", window.localize("modules.actions.powerPromote.unableToStartPower"));
							}
							//have to be the current logged in user to sign-off
							if(self.viewModel.eSigUsername() !== app.user.id){
								self.toggleLoader(false);
								self.viewModel.eSigError(window.localize("modules.actions.powerPromote.invalidUserName"));
								$('#eSigError').show();
							}else{
								//validate the e-signature and then submit the form
								var opts = {
									type:	"POST",
									contentType:	"application/json",
									url:	app.serviceUrlRoot + "/authentication/newSession?username=" + self.viewModel.eSigUsername(),
									data: JSON.stringify(self.viewModel.eSigPassword()),
									success: function(result){
										if(result){
										    //we got a valid ticket, so let's submit!					
                                            self.viewModel.powerPromote();
										}
									},
									//override default to go to login screen on login failure
									statusCode: {
										401: function(jqXHR, textStatus, errorThrown){   
											self.toggleLoader(false);
											self.viewModel.eSigError("Incorrect username and/or password.");
											$('#eSigError').show();
										}
									},

									error: function(jqXHR, textStatus, errorThrown){
										self.toggleLoader(false);
										self.viewModel.eSigError(window.localize("modules.actions.powerPromote.incorrectUsername"));
										$('#eSigError').show();
									}

							  };
							$.ajax(opts);				
							}	
						}else {
							self.viewModel.eSigError(window.localize("modules.actions.powerPromote.incorrectUsername"));
							$('#eSigError').show();
						}
					}
					else {
						if(self.action.get("parameters").objectId === undefined){
							app[self.myHandler].trigger("showError", window.localize("modules.actions.powerPromote.unableToStartPowerPromotion"));
						}
						else{
							self.toggleLoader(true);
							self.viewModel.powerPromote();
						}
					}
				}
			};
		},

		afterRender: function() {
			kb.applyBindings(this.viewModel, this.$el[0]);
		},
        serialize: function() {
            var modal = false;
			var rightSide = false;
			var eSigPage = this.config.get("eSigPage");
			if(eSigPage ==="true") {
				eSigPage = true;
			}
			else {
				eSigPage = false;
			}
			if (this.myHandler === "modalActionHandler") {
				modal = true;
			} else if (this.myHandler === "rightSideActionHandler") {
				rightSide = true;
			}
			return {
				modal : modal,
				rightSide : rightSide,
				eSigPage : eSigPage
			};
        }
	});

	action.CustomConfigView = Backbone.Layout.extend({
		template: "hpiadmin/actions/customconfig/powerpromoteconfig",
		initialize: function(){
			this.viewModel = this.options.viewModel;
			this.viewModel.eSigPage = kb.observable(this.viewModel.model(), "eSigPage");
			if (!this.viewModel.eSigPage()) {
				this.viewModel.eSigPage("true");
			}
            this.viewModel.promoteToState = kb.observable(this.viewModel.model(),"promoteToState");
		},
		afterRender: function(){
			kb.applyBindings(this.options.viewModel, this.$el[0]);
		}
	});

	actionModules.registerAction("powerPromote", action, {
        "actionId" : "powerPromote",
      	"label" : (window.localize("modules.actions.powerPromote.powerPromote")) ,
      	"icon" : "fast-forward",
      	"handler" : "modalActionHandler",
      	"groups" : ["wizard", "powerPromote"]
    });
		
	return action;
});
require(["powerpromote"]);