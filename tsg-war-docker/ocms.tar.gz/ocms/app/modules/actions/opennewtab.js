// OpenNewTab module
//@author: Bradley White
define("opennewtab", [
        // Application.
        "app",
        "modules/actions/actionmodules",
        'module',
        "modules/services/logstashservice",
        "modules/common/hpiconstants",
        "modules/hpiadmin/actionconfig/actions/opennewtab/opennewtabconfig"
    ],

    // Map dependencies from above array.
    function (app, actionModules, module, LogstashService, HPIConstants, openNewTabConfig) {
        "use strict";
        //Start with declaring your id - this is the same value as in the filename between the words action. and .js
        //get the config from the namespace. The action handler is responsible for this; //

        var action = {};

        action.CustomConfigView = openNewTabConfig.CustomConfigView;

        action.View = Backbone.Layout.extend({
            initialize: function (options) {
                this.action = options.action;
                this.docVals = options.docVals;
                this.config = options.config;

                // For easy access make them separate vars, since we won't be modifying the actual values, just reading them in.
                var actionMultiObjIds = this.action.get('parameters').objectIds;
                var actionSingleObjId = this.action.get('parameters').objectId;

                // For unit test: needed a way to inject new value b/c module.config() is just an object created at RT
                this.newTabLimit = module.config().newTabLimit;
                if (!this.newTabLimit) {
                    this.newTabLimit = options.newTabLimit ? options.newTabLimit : 25;
                }

                if (actionMultiObjIds && this.newTabLimit < actionMultiObjIds.length) {
                    //too many selected, show error
                    app.trigger("alert:error", {
                        header: "Error",
                        message: "Too many documents chosen for viewing. Please select below " + this.newTabLimit + " documents."
                    });
                } else {
                    if (actionMultiObjIds && actionMultiObjIds.length) {
                        // we've got multiple to open, let's get crackin'
                        for (var index = 0; index < actionMultiObjIds.length; index++) {
                            this.openDocument(index);
                        }
                    } else {
                        this.openDocument();
                    }

                    // log the open in new tab event
                    LogstashService.sendMetrics(
                        new LogstashService.PerformanceLog({
                            'eventTitle': HPIConstants.Logging.Events.OpenInNewTab,
                            'objectId': (actionSingleObjId) ? actionSingleObjId : actionMultiObjIds.join(",")
                        })
                    );
                }
            },
            openDocument: function (index) {
                var id, name, docVals;

                if(index > -1){ // we could get a 0 passed in, which is falsey, but applicable
                    id = this.action.get('parameters').objectIds[index];
                    name = this.action.get('parameters').objectNames[index];
                    docVals = this.docVals[index];
                }
                else{
                    id = this.action.get('parameters').objectId;
                    name = this.action.get('parameters').objectName;
                    docVals = this.docVals[0];
                }

                // Build up the correct tab name
                var tabName = "";
                if (docVals) {
                    _.each(docVals, function (val, i) {
                        if (val) {
                            tabName += val;
                            // Add a separator if it's not the last item in the list
                            if (docVals.length - 1 !== i) {
                                tabName += '--';
                            }
                        }
                    });
                } else if (name) {
                    tabName = name;
                }

                var url;
                // XMLs do not display nicely in an iframe...
                // we will lose the ability to name the window with tabName
                // but we gain a nicely displayed XML file in the browser
                if (name && name.indexOf("xml") > -1) {
                    url = app.serviceUrlRoot + "/content/content/" + encodeURIComponent(tabName);
                } else {
                    var configuredRoute = this.config.get('selectedNewTabViewer') === "docviewer" ? "DocViewer/" + app.context.configName() : "View";
                    url = app.root + configuredRoute + "/" + encodeURIComponent(tabName);
                }

                //Build additional property map from config
                var overlayParamMap = {};
                if(this.config.get('selectedNewTabViewer') === "stream") {
                    _.each(this.config.get("overlayParameters"), function(propModel) {
                        var key = propModel.key;
                        var value = propModel.value;
                        if(key && value) {
                            overlayParamMap[key] = value;
                        }
                    });
                }

                //Build query string
                var paramMap = {
                    id: id
                };
                if(!_.isEmpty(overlayParamMap)) {
                    paramMap.overlayParameters = overlayParamMap;
                }
                var queryString = $.param(paramMap);

                //Make call with completed url
                url += "?" + queryString;
                window.open(url);
            }
        });

        actionModules.registerAction("openNewTab", action, {
            "actionId": "openNewTab",
            "label": window.localize("stage.openInNewTab"),
            "icon": "share-alt"
        });

        actionModules.registerAction("openNewTabCollection", action, {
            "actionId": "openNewTabCollection",
            "label": window.localize("stage.openEachInNewTab"),
            "icon": "share-alt"
        });

        return action;
    });
require(["opennewtab"]);