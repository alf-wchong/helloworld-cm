define("downloadaszip",[
  // Application.
  "app",
  "knockout",
  "knockback",
  "moment",
  "oc",
  "modules/actions/actionmodules",
  "modules/common/downloadutils",
  "modules/common/action",
  "foldernotes",
  "modules/services/logstashservice",
  "modules/common/hpiconstants",
  "jqueryDownload"
],

// Map dependencies from above array.
function(app, ko, kb, moment, OC, actionModules, downloadUtils, Action, FolderNotes, LogstashService, HPIConstants) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    function ViewModel(action, myHandler, config, searchResultsViewController) {
        var self = this;

        self.toggleLoader = function(bool) {
            app[myHandler].trigger("loading", bool);
        };

        self.zipName = ko.observable();

        self.config = config;

        self.downloadAsZip = function() {
            var self = this;
            
            var dt = moment().format(),
                dtFormat = dt.replace(/:/g, "-");

            action.get("parameters").fileName = self.zipName() + "-" + dtFormat + ".zip";
            action.get("parameters").downloadWithTags = config.get('downloadWithTags');
            action.get("parameters").useRenditionsIfPossible = config.get('downloadRenditionsIfPossible') === "true" ? true : false;
            
            if(config.get('zippedNamedParam')) {
                action.get("parameters").zippedNamedParam = config.get('zippedNamedParam');
            }

            self.toggleLoader(true);

            downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', action.attributes, self.iframeCallback);
        };

        self.iframeCallback = function() {
            //log download as zip duration
            var executeActionCompletionTime = Date.now();
            LogstashService.sendMetrics(
                new LogstashService.PerformanceLog({
                    'eventTitle': HPIConstants.Logging.Events.ExecuteAction,
                    'events' : {
                        'action': action.get("name"),
                        'eventDuration': executeActionCompletionTime - action.get("startTime")
                    },
                    'docCount': action.get('parameters').objectIds.length
                })
            );

            self.toggleLoader(false);
            app[myHandler].trigger("showMessage", window.localize("stage.actions.exportFolder.downloadMessage"));            
            searchResultsViewController.tableEventsRef.trigger("search:removeAllChecked");
            if(config.get("folderNotes") && config.get("folderNotes") === 'true'){
                self.ocoCollection = new OC.OpenContentObjectCollection({'ids': action.get('parameters').objectIds});
                self.ocoCollection.fetch().done(function() {
                    self.createFolderNotes(self.ocoCollection);
                });
            }
        };

        self.createFolderNotes = function(ocoCollection) {
            var self = this;
            self.parentIdMap = {};
            var type,objectType, otcObjectType;
            _.each(ocoCollection.models, function(oco, index) {
                app.context.configService.getAdminOTC(function(otc) { 
                    self.otc = otc;
                    app.context.util.getParents(oco.get("properties").objectId, function(fetchedParents) {
                        var parentId;
                        if(index === 0) {
                            objectType = oco.get("objectType");
                            otcObjectType = self.otc.get('configs').where({'ocName': objectType})[0];
                            type = otcObjectType.get("isContainer") === 'false' ? "document" : "folder";
                        }
                        if(type === 'document') {
                            if(config.get('enableDocumentNoteRelation') && config.get('enableDocumentNoteRelation') === "true"){
                                parentId = oco.get('properties').objectId;
                            }else{
                                parentId = fetchedParents[0].objectId;
                            } 
                        } else {
                            parentId = oco.get('properties').objectId;
                        }
                        if(self.parentIdMap[parentId]) {
                            self.parentIdMap[parentId].push({'objectName': oco.get("properties").objectName, 'objectId': oco.get('properties').objectId});
                        } else {
                            self.parentIdMap[parentId] = [];
                            self.parentIdMap[parentId].push({'objectName': oco.get("properties").objectName, 'objectId': oco.get('properties').objectId});
                        }

                    });

                });
            });
            
            _.each(_.keys(self.parentIdMap), function(parentId) {
                self.executeFolderNoteCreation(parentId);

            }, this);
            
        };

        self.executeFolderNoteCreation = function(parentId) {
            var note_type = config.get("folderNoteType");
            var objects = this.parentIdMap[parentId];
            var noteContent = "<p>User " + app.user.get("displayName") + "downloaded ";
            _.each(objects, function(object) {
                noteContent += "<a class='stageLink' documentId='" + object.objectId + "'>" + object.objectName + "</a>" + ", ";
            });
            noteContent = noteContent.substring(0,noteContent.length-2);
            noteContent += " into zip file " + this.zipName() + "</p>";

            var folderNoteParameters = {
                parameters: {
                    parentID: parentId,
                    note_content: noteContent,
                    note_rel_type: this.config.get("folderNoteRelationship"),
                    note_object_type: this.config.get("folderNoteObjectType"),
                    property_map:{
                        note_type: note_type
                    }
                }
            };
            if(config.get('enableDocumentNoteRelation') && config.get('enableDocumentNoteRelation') === "true"){
                folderNoteParameters.parameters.property_map.note_attachment = parentId;
            }
            FolderNotes.Service.execute(folderNoteParameters);
        };

        return self;
    }

    action.View = Backbone.Layout.extend({
        template: "actions/downloadaszip",
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.config = this.options.config;
            this.searchResultsViewController = this.options.searchResultsViewController;
            this.viewModel = new ViewModel(this.action, this.myHandler, this.config, this.searchResultsViewController);
        },
        afterRender: function() {
            kb.applyBindings(this.viewModel, this.$el[0]);
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        }
    });

    //custom config view for download with tags slider option
    action.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/downloadaszipconfig",
        initialize: function(){
            var viewModel = this.options.viewModel;
            
            viewModel.downloadWithTags = kb.observable(viewModel.model(), 'downloadWithTags');
            
            //default folder notes integration to false
            if(viewModel.downloadWithTags() === null){
                viewModel.downloadWithTags("false");
            }

            viewModel.downloadRenditionsIfPossible = kb.observable(viewModel.model(), 'downloadRenditionsIfPossible');
            
            // download renditions if possible defaulted to false
            if(_.isUndefined(viewModel.downloadRenditionsIfPossible())){
                viewModel.downloadRenditionsIfPossible("false");
            }

            viewModel.zippedNamedParam = kb.observable(viewModel.model(), 'zippedNamedParam');
            
            //FOLDER NOTES INTEGRATION
            viewModel.folderNotes = kb.observable(viewModel.model(), "folderNotes");
            
            if(_.isUndefined(viewModel.folderNotes()) || viewModel.folderNotes() === null ) {
                viewModel.folderNotes(false);
            }
            // selected folder note type from the admin
            viewModel.folderNoteObjectType = kb.observable(viewModel.model(),"folderNoteObjectType");
            if (!viewModel.folderNoteObjectType()){
                viewModel.folderNoteObjectType("HPI Note");
            }
            // note type to apply to all folder notes
            viewModel.folderNoteType = kb.observable(viewModel.model(),"folderNoteType");
            if (!viewModel.folderNoteType()) {
                viewModel.folderNoteType("Folder Note");
            }
            //selected folder note relationship from admin
            viewModel.folderNoteRelationship = kb.observable(this.viewModel.model(),"folderNoteRelationship");

            //is the note directly related to the folder or document?
            viewModel.enableDocumentNoteRelation = kb.observable(viewModel.model(), "enableDocumentNoteRelation");
            //END FOLDER NOTES INTEGRATION
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        }
    });

    actionModules.registerAction("downloadAsZip", action, {
        "actionId" : "downloadAsZip",
        "label" : (window.localize("modules.actions.downloadAsZip.downloadAsZip")),
        "icon" : "download-alt"
    });

    return action;

});
require(["downloadaszip"]);