define("changewizardformowner",[
  // Application.
  "app",
  "modules/actions/actionmodules",
  "modules/common/queryabletypeahead"
],

// Map dependencies from above array.
function(app, actionModules, QueryableTypeahead) {
    "use strict";
    //Start with declaring your id - this is the same value as in the filename between the words action. and .js
    //get the config from the namespace. The action handler is responsible for this; //

    var action = {};

    action.Model = Backbone.Model.extend({
        defaults: {

        },
        initialize: function(options) {
            this.options = _.defaults(options,this.defaults);
        }
    });


    // Carry out the action
    action.View = Backbone.Layout.extend({
        template: "actions/changewizardformowner",
        events:{
            "click #delegateTask-submitBtn" : "onSubmit",
            'keydown #delegateTask-userList' : 'sanitizeKey'
        },
        initialize: function(){
            var self = this;
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            self.selectedUsers = [];
            self.selectedUser = '';
            self.isLastUserSelectionValid = false;
            self.selectedUserLabel = '';
            self.objectId = this.action.get("parameters").objectId;
            self.formName = app.context.document.get("properties").objectName;
            self.formOwner = app.context.document.get("properties").owner_name;

            self.typeahead = new QueryableTypeahead({
                queryUrl: app.serviceUrlRoot + "/aw-workflow/searchWizardContributors",
                displayKey: 'displayName',
                searchOn: 'displayName',
                placeholder:'Start typing here...'

            });

            self.listenTo(this.typeahead, 'change:selected', function(option){
                if(option){
                    this.selectedUserEventHandler(option);
                }
                else{
                    self.selectedUser = '';
                    self.dialog(false);
                    self.validSubmitData(false);
                }
            });

            self.listenTo(this.typeahead, 'typeahead:clear', function(){
                this.clearUserInput();
            }, this);
        },
        beforeRender: function(){
            if(this.typeahead){
                this.setView('#delegateTask-userList', this.typeahead);
            }
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }
            return {
                modal : modal,
                rightSide : rightSide
            };
        },
        onSubmit: function() {
            var self = this;
            self.toggleSubmit(false);
            //todo get rid of these error catches, form validation takes care of this.
            if( self.selectedUser === undefined || self.selectedUser === '' ) {  //selectedUser() must have a value selected
                alert(window.localize("modules.actions.changeWizardFormOwner.mustSelect"));
                return;
            }else{
                self.action.get("parameters").newOwner = self.selectedUserLabel;
                self.action.get("parameters").formUrl = window.origin + app.root + "Stage/wizard/" + encodeURIComponent(self.objectId + "|" + self.objectId);

                self.action.execute({
                    success : function() {
                                // self.toggleLoader(false);
                                app.trigger("stage.refresh.bothIds", self.objectId, self.objectId);
                                app[self.myHandler].trigger("showMessage", (window.localize("modules.actions.changeWizardFormOwner.newOwner")) + self.formName + " is " + self.selectedUserLabel + ".");
                            },
                    error : function(jqXHR) {
                                // self.toggleLoader(false);
                                app[self.myHandler].trigger("showError", (window.localize("modules.actions.changeWizardFormOwner.failedToSet")) + jqXHR.status + 
                                    " " + jqXHR.statusText);
                            }
                });
            }
        },
        selectedUserEventHandler: function (item) {
            var self = this;
            self.toggleSubmit(false);
            document.getElementById('delegateTask-userList').disabled = true;
            self.selectedUser = item.authorityId;
            self.selectedUserLabel = item.displayName;
            self.evaluateValidity(); 
        },

        validSubmitData: function (valid) {
            var self = this;
            if (valid) {               
                //then we show user feedback showing them what they're about to do
                self.dialog(true,false, (window.localize("modules.actions.changeWizardFormOwner.toChange")) + self.formName +(window.localize("modules.actions.changeWizardFormOwner.to")) + self.selectedUserLabel + (window.localize("modules.actions.changeWizardFormOwner.pressChange")));
                self.toggleSubmit(true);

            } else {
                //then we disable Submit button and... show error? TODO decide
                //self.dialog(false);                  
                self.toggleSubmit(false);
            }
        },

        dialog: function (show,error, html) {
            if (show && !error) {
                $('.alert-success').html(html);
                $('.alert-success').show();
                $('.alert-danger').hide();
            }else if(show && error){
                $('.alert-danger').html(html);
                $('.alert-danger').show();
                $('.alert-success').hide();
            }
            else {
                $('.alert-success').hide();
                $('.alert-danger').hide();
            }
        },
        clearUserInput: function() {
            var self = this;
            self.selectedUser = '';
            self.selectedUserLabel = '';
            self.dialog(false);
            self.validSubmitData(false);
        },  
        toggleSubmit: function(enabled) {
            if(enabled){
                document.getElementById('delegateTask-submitBtn').disabled = false;
            }
            else{
                document.getElementById('delegateTask-submitBtn').disabled = true;
            }
        },
        evaluateValidity: function() {
            if(this.selectedUser){
                if(this.formOwner === this.selectedUserLabel){
                    this.dialog(true,true, (window.localize("modules.actions.changeWizardFormOwner.ownerCanNot")));
                    this.validSubmitData(false);
                
                }else{
                    this.validSubmitData(true);
                }

            }else{
                this.validSubmitData(false);
            }
        },
        sanitizeKey: function(evt){
            //catch the enter key to prevent the query text being set as the selected user
            var code = evt.keyCode || evt.which;
            if(code==13){
                //prevent default for enter key only
                evt.preventDefault();
            }
        }
    });
    
    actionModules.registerAction("changeWizardFormOwner", action, {
       "actionId" : "changeWizardFormOwner",
        "label" : (window.localize("modules.actions.changeWizardFormOwner.changeFormOwner")),
        "icon" : "user",
        "groups" : ["wizard", "change", "formOwner"]
    });

    return action;
});
require(["changewizardformowner"]);