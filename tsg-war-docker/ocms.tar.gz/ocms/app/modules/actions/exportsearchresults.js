// Export Search Results action
define("exportsearchresults",[
  // Application.
  "app",
  "moment",
  "modules/actions/actionmodules",
  "modules/common/downloadutils",
  "modules/common/linkformatterutil",
  "knockout",
  "knockback",
  "oc",
  "jqueryDownload"
],

// Map dependencies from above array.
function(app, moment, actionModules, downloadUtils,LinkFormatter,ko, kb, OC) {
    "use strict";
    
    var ExportSearchResults = {};

    ExportSearchResults.View = Backbone.Layout.extend({
        template: "actions/exportsearchresults",
        events: {
            "click #sendEmailButton": "emailResults"
        },
        initialize: function(){
            this.action = this.options.action;
            this.myHandler = this.options.config.get("handler");
            this.config = this.options.config;
            this.currentTypes = this.action.get("parameters").objectTypes;

            //objectIds param needs to be set on this group action. 
            //if only one document was selected, objectId will be set and objectIds will not be
            if(this.action.get("parameters").objectId) {
                this.action.get("parameters").objectIds = [this.action.get("parameters").objectId];
                this.action.get("parameters").objectNames = [this.action.get("parameters").objectName];
            }

            // Set our filename on the action
            this.action.get("parameters").appRoot = app.root;
            var dt = moment().format();
            var dtFormat = dt.replace(/:/g, "-");
            this.action.get("parameters").fileName = 'Search-Results' + "-" + dtFormat + ".xls";
        },
        exportSearchResultsAndDownload: function(searchConfigName) {
            var self = this;
            var returnAllProps = this.config.get("exportAllProps");
            var returnStageURL = this.config.get("generateStageURL");

            self.toggleLoader(true);

            var callback = function() {
                self.toggleLoader(false);
                app[self.myHandler].trigger("showMessage", window.localize("modules.actions.exportSearchResults.theResults"));
            };

            if (returnStageURL) {
                this.excelStageUrl(); 
            }

            // If we're configured to return all props, we'll want to overwrite the 'sortFields' attr on the action.
            if (returnAllProps) {
                // Get the search config we're using's Form Config, and then the form for current type being searched on.
                app.context.configService.getSearchConfigByName(searchConfigName, function(searchConfig) {
                    var fieldLabels = [];
                    // For now we assume we're in tableView, since exportSearchResults currently on works there.
                    var resultsTableConfig = searchConfig.get("resultsConfig").get("resultsTableConfig");
                    var typesResultCollection = resultsTableConfig.get("types");

                    _.each(self.currentTypes, function(currentType) {
                        var currentTypeResultsConfig = typesResultCollection.findWhere({objectType: currentType});

                        //people can configure the application wrong and not have a type setup in the search config
                        if (currentTypeResultsConfig) {
                            // Put all fields (visible and invisible) onto sort fields
                            self.action.get("parameters").sortFields = _.map(currentTypeResultsConfig.get("fields"), function(ocConfig) {
                                if(ocConfig.ocName) {
                                    return ocConfig.ocName;
                                } else {
                                    return ocConfig;
                                }
                            });

                            app.context.configService.getAdminTypeConfig(currentType, function(objectTypeConfig) {
                                var attributeCollection = objectTypeConfig.get("attrs");

                                _.each(self.action.get("parameters").sortFields, function(fieldOcName) {
                                    var attributeModel = attributeCollection.findWhere({ocName: fieldOcName});
                                    var fieldLabel = attributeModel.get("label");
                                    fieldLabels.push(fieldLabel);
                                });

                                self.action.get("parameters").fieldLabels = fieldLabels;
                                
                            });
                        } else {
                            app.log.warn(window.localize("modules.actions.exportSearchResults.noTypeFoundInTableViewConfig"));
                        }
                    });

                    // This check will pass if all of the types searched on or viewed in view all documents are somehow not configured in the search
                    // config - we will want the action to alert the user that the excel will not download
                    if (_.isEmpty(fieldLabels)) {
                        self.toggleLoader(false);
                        app[self.myHandler].trigger("showError", window.localize("modules.actions.exportSearchResults.noTypeFoundInTableViewConfig"));
                    } else {
                        app.context.dateService.getDateFormat().done(function(dateFormat) {
                            self.action.get("parameters").dateFormat = moment().toJDFString(dateFormat);

                            // Since the getting of configs is asynchronous, we launch our action within the callback.
                            downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', self.action.attributes, callback);
                        });
                    }
                });
            } else {
                app.context.dateService.getDateFormat().done(function(dateFormat) {
                    self.action.get("parameters").dateFormat = moment().toJDFString(dateFormat);

                    // Since the getting of configs is asynchronous, we launch our action within the callback.
                    downloadUtils.asyncDownload(app.serviceUrlRoot + '/action/executeAndReturnStream?download=true', self.action.attributes, callback);
                });
            }
        },
        emailResults: function() {
            var self = this;
            this.toggleLoader(true);

            app.context.dateService.getDateFormat().done(function(dateFormat) {
                // Grab the email address from the input box
                self.action.get("parameters").toAddress = self.$("#userEmailField").val();
                self.action.get("parameters").dateFormat = moment().toJDFString(dateFormat);

                self.action.execute({
                    success: function(){
                        self.toggleLoader(false);
                        app[self.myHandler].trigger( "showMessage", (window.localize("modules.actions.exportSearchResults.emailQueued")));
                    },
                    error: function(jqXHR){
                        app[self.myHandler].trigger("loading", false);
                        app[self.myHandler].trigger("showError", (window.localize("modules.actions.sendEmail.sorryAnError")) + jqXHR.responseText);
                    }
                });
            });
        },
        excelStageUrl: function() {
            var ocoList = [];
            var index = 0;
            var selectedIds = this.action.get("parameters").objectIds;
            var selectedNames = this.action.get("parameters").objectNames;
            var resolver = this.config.get("resolver");
            var externalLink = this.config.get("resolverExternalLink");

            _.each(selectedIds, function(selectedId) {
                var ocoForCreation = new OC.OpenContentObject({
                    objectId : selectedId,
                    //so with the VAD changes, there can be mulitple types in tableview so we need to take the [0] element of this array - 
                    //this SHOULD NOT break anything, since the type is only used to figure out if the type is a container or not - so in search
                    //we only have one type and this is fine and in VAD the type should always resolve to not a container and we should also be fine,
                    //this will need to be changed in the future if we atart doing weirder stuff in search or VAD
                    objectType : this.currentTypes[0],
                    objectName : selectedNames[index]
                });

                ocoList.push(ocoForCreation);
                index += 1;
            }, this);
           
            var tracToUse;
            if (Backbone.history.fragment.indexOf("search/") === 0) {
                tracToUse = encodeURIComponent(app.context.configName());
            }
 
            var resultObj = {};
            _.map(ocoList, function(oco) {
                var objectId = oco.get("objectId");
                
                if (resolver.match("stage")) {
                    var stageUrl = LinkFormatter.stage(tracToUse, oco, resolver);
                    resultObj[objectId] =  stageUrl;
                } else if (resolver === "stream") {
                    var streamUrl = LinkFormatter.stream(oco);
                    resultObj[objectId] = streamUrl;
                } else if (resolver === "external-link") {
                    var externalLinkUrl = LinkFormatter.externalLink(oco, externalLink);
                    resultObj[objectId] = externalLinkUrl;
                }
            });

            this.action.get("parameters").objectUrls = resultObj;
        },
        toggleLoader: function(bool) {
            app[this.myHandler].trigger("loading", bool);
        },
        afterRender: function() {
            if (!this.config.get("exportViaEmail")) {
                //let's get the search config by name by pulling it from the id of the current config we are working with
                //the exportSearchResults() function needs this if we have to pull all the properties off, the config will
                //ALWAYS have an _id so we don't need to null check - if no _id is present we have bigger problems 
                var searchConfigName = this.config.get("_id").split(".")[1];
                this.exportSearchResultsAndDownload(searchConfigName);
            }
        },
        serialize: function() {
            var modal = false;
            var rightSide = false;
            
            if (this.myHandler === "modalActionHandler") {
                modal = true;
            } else if (this.myHandler === "rightSideActionHandler") {
                rightSide = true;
            }

            return {
                modal : modal,
                rightSide : rightSide,
                exportAllViaEmail : this.config.get("exportViaEmail"),
                disableEmailFieldForExport: this.config.get("disableEmailFieldForExport") === "false" ? false : true,
                userEmail : app.user.get("emailAddress")
            };
        }
    });

    ExportSearchResults.CustomConfigView = Backbone.Layout.extend({
        template: "hpiadmin/actions/customconfig/exportsearchresultsconfig",
        initialize: function(){
            var viewModel = this.options.viewModel;
            var config = actionModules.getDefaultConfig(this.options.viewModel.actionId());
            viewModel.exportViaEmail = config.exportViaEmail;
            
            var model = viewModel.model();

            viewModel.exportAllProps = kb.observable(viewModel.model(), "exportAllProps");
            viewModel.generateStageURL  = kb.observable(viewModel.model(), "generateStageURL");
            viewModel.resolver  = kb.observable(viewModel.model(), "resolver");
            viewModel.attr  = kb.observable(viewModel.model(), "attr");
            viewModel.resolverExternalLink =kb.observable(viewModel.model(), "resolverExternalLink");

            viewModel.showExternalLink = ko.observable(model.get("showExternalLink"));
            //Shows externalLink option if link is already set in admin
            viewModel.showExternalLink.subscribe(function() {
                model.set('showExternalLink', viewModel.showExternalLink());
            });

            // Default the value based on the model
            if (_.isUndefined(model.get("resolver"))) {
                viewModel.resolver("stage");
            }

            viewModel.resolver.subscribe(function() {
                // Check if we need to show the external link textBox.
                var showExternLink = viewModel.resolver() === "external-link" ? true : false;
                viewModel.showExternalLink(showExternLink);

                model.set('resolver', viewModel.resolver());
            });

            if (viewModel.exportViaEmail) {
                // Enable or disable the functionality that allows the user to change the email results
                // are being exported to
                viewModel.disableEmailFieldForExport = kb.observable(viewModel.model(), "disableEmailFieldForExport");
                
                // Default the value based on the model
                if (model.get("disableEmailFieldForExport") === "false") {
                    viewModel.disableEmailFieldForExport("false");
                } else {
                    viewModel.disableEmailFieldForExport("true");
                }
                
                viewModel.disableEmailFieldForExport.subscribe(function() {
                    if (viewModel.disableEmailFieldForExport() === "false") {
                        model.set('disableEmailFieldForExport', "false");
                    } else {
                        model.set('disableEmailFieldForExport', "true");
                    }
                });
            }
        },
        afterRender: function(){
            kb.applyBindings(this.options.viewModel, this.$el[0]);
        },
        serialize: function() {
            return {
                exportViaEmail: this.options.viewModel.exportViaEmail
            };
        }
    });

    actionModules.registerAction("exportSearchResults", ExportSearchResults, {
        "actionId" : "exportSearchResults",
        "exportViaEmail" : false,
        "label" : "Export Results to Excel",
        "icon" : "list-alt"
    });

    actionModules.registerAction("exportSearchResultsSingleDoc", ExportSearchResults, {
        "actionId" : "exportSearchResultsSingleDoc",
        "exportViaEmail" : false,
        "label" : "Export Results to Excel",
        "icon" : "list-alt"
    });

    actionModules.registerAction("exportSearchResultsEmail", ExportSearchResults, {
        "actionId" : "exportSearchResultsEmail",
        "exportViaEmail" : true,
        "label" : "Export All Results to Excel via Email",
        "icon" : "list-alt"
    });

    return ExportSearchResults;

});
require(["exportsearchresults"]);