define([
	// Application.
	"app",

	"modules/detailview/detailview",
	"oc",
	"modules/hpiadmin/applicationconfig/detailviewconfig"
],

	function(app, DetailView, OC, DetailViewConfig) {
		"use strict";

		//All routes in this router are expected to use the one column layout setup.
		//This function ensures the correct layout and the correct subviews
		var setupLayout = function(id, isBackAvailable){
			$("body").removeClass(); // removes all classes (such as login)
			
			var layout = app.useLayout("layout-1-col");
			var model = new OC.OpenContentObject({ objectId: id });
			var config = app.context.findOrCreateConfig(DetailViewConfig.Model, app.context.configName());

			var contentOutlet = layout.getView("#content-outlet");
			if(contentOutlet) {
				// make sure the content outlet has the correct sub-view
				if(contentOutlet.name !== "detailview") {
					contentOutlet.remove();
					layout.setViews({
						"#content-outlet" : new DetailView.Views.Layout({ model: model, config: config, isBackAvailable: isBackAvailable })
					});
				}
				else { 
					app.log.debug("RE-RENDERING DETAIL VIEW WITH NEW MODEL.");
					// the correct sub view is there... but we need to re-render it with the correct model in case we've changed models
					contentOutlet.model = model;
					contentOutlet.isBackAvailable = isBackAvailable;
					contentOutlet.remove();
					layout.setView("#content-outlet", new DetailView.Views.Layout({ model: model, config: config, isBackAvailable: isBackAvailable}), false);
				}
			}
			else {
				layout.setView("#content-outlet", new DetailView.Views.Layout({ model: model, config: config, isBackAvailable: isBackAvailable }));
			}

			return layout;
		};


		// Defining the application router, you can attach sub routers here.
		var Router = Backbone.Router.extend({

			/**
			Detail View Routes: 

			"details/:id(/:isBackAvailable)" 
				- route includes id of the oc object that should be fetched
				- optional isBackAvailable determines if the user has arrived from search results or a direct link (to generate proper nav)
			**/
			routes: {
				"details/:trac/:id(/:isBackAvailable)" : "details"
			},

			details: function(trac, id, isBackAvailable) {

				app.context.configName(trac);
				
				var layout = setupLayout(id, isBackAvailable);
				$("body").addClass("detailview");
				layout.render();

			}
		});

		return Router;

	});