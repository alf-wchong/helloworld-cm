define([
    'app',
    "router",
    "adminrouter",
    "searchrouter",
    "dashboardrouter",
    "indexerrouter",
    "modules/wizard/activeformrouter",
    "detailviewrouter",
    "oauthrouter",
    "userpreferencesrouter",
    "claimrouter"
], function(app, Router, AdminRouter,
    SearchRouter, DashboardRouter,
    IndexerRouter, ActiveFormRouter, DetailViewRouter,
    OAuthRouter, UserPreferencesRouter, ClaimRouter) {
    var configuredRouters = {
        main: new Router(),
        admin: new AdminRouter(),
        search: new SearchRouter({
            encodedSplatParts: true
        }),
        dashboard: new DashboardRouter(),
        indexer: new IndexerRouter(),
        activeform: new ActiveFormRouter(),
        detailView: new DetailViewRouter(),
        oauth: new OAuthRouter(),
        userpreferences: new UserPreferencesRouter(),
        claimrouter: new ClaimRouter()
    };

    return configuredRouters;
});
