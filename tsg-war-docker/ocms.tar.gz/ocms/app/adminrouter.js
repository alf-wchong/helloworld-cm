define([
    // Application.
    "app",
    "abstractrouter",
    "modules/hpiadmin/hpiadmin",
    "modules/hpiadmin/adminsecurity",
    "modules/hpiadmin/otc/objecttypeconfig",
    "modules/hpiadmin/stageconfig/stageconfig",
    "modules/hpiadmin/searchconfig/searchconfig",
    "modules/hpiadmin/indexerconfig/indexerconfig",
    "modules/hpiadmin/applicationconfig/applicationconfig",
    "modules/hpiadmin/picklistconfig/picklistconfig",
    "modules/hpiadmin/applicationconfig/detailviewconfig",
    "modules/hpiadmin/collectionconfig/collectionconfig",
    "modules/hpiadmin/dashboardconfig/dashboardconfig",
    "modules/hpiadmin/tracconfig/tracconfig",
    "modules/hpiadmin/formconfig/formconfig",
    "modules/hpiadmin/templatemanagementconfig/templatemanagementconfig",
    "modules/hpiadmin/workflowformconfig/singleworkflowform",
    "modules/hpiadmin/workflowformconfig/workflowformconfig",
    "modules/hpiadmin/workflowconfig/workflowconfig",
    "modules/hpiadmin/actioninfo",
    "modules/hpiadmin/groupconfig/groupconfig",
    "modules/hpiadmin/securityconfig/securityconfig",
    "modules/hpiadmin/userconfig/userconfig",
    "modules/hpiadmin/wizardconfig/wizardconfig",
    "modules/hpiadmin/adminsearchtool/adminsearchtool",
    "modules/hpiadmin/aclconfig/aclconfig",
    "modules/hpiadmin/configarchiver/configarchiver",
    "modules/hpiadmin/licensemanager/licensemanager",
    "modules/hpiadmin/developerzone/developerzone",
    "modules/hpiadmin/nmac/nonmandatoryaspectconfig",
    "modules/hpiadmin/loggingconfig/loggingconfig",
    "modules/common/hpiconstants"
],

function(app, AbstractRouter, Hpiadmin, AdminSecurity, Objecttypeconfig,
    StageConfig, SearchConfig, IndexerConfig, AppConfig, PicklistConfig,
    DetailViewConfig, CollectionConfig, DashboardConfig,
    TracConfig, FormConfig, TemplateManagementConfig, SingleWorkflowForm, WorkflowFormConfig, WorkflowConfig,
    ActionInfo, GroupConfig, SecurityConfig, UserConfig, WizardConfig, AdminSearchTool,
    aclConfig, ConfigArchiver, LicenseManager, DeveloperZone, NonMandatoryAspectConfig, LoggingConfig, HPIConstants) {

    "use strict";

    // Defining the application router, you can attach sub routers here.
    var Router = AbstractRouter.extend({

        before: {
            "*any": "adminSecurity"
        },

        routes: {
            "admin": "applicationConfig",
            "admin/": "applicationConfig",

            "admin/TracConfig(/:name)": "tracConfig",
            "admin/TracConfig/": "tracConfig",
            "admin/ObjectTypeConfig(/:name)": "objectTypeConfig",
            "admin/ObjectTypeConfig/": "objectTypeConfig",
            "admin/StageConfig(/:name)": "stageConfig",
            "admin/StageConfig/": "stageConfig",
            "admin/SearchConfig(/:name)": "searchConfig",
            "admin/SearchConfig/": "searchConfig",
            "admin/ApplicationConfig": "applicationConfig",
            "admin/PicklistConfig": "picklistConfig",
            "admin/CollectionConfig(/:name)": "collectionConfig",
            "admin/DashboardConfig(/:name)": "dashboardConfig",
            "admin/FormConfig(/:name)": "formConfig",
            "admin/TemplateManagementConfig(/:name)": "templateManagementConfig",
            "admin/WorkflowFormConfig/": "workflowFormConfig",
            "admin/WorkflowFormConfig": "workflowFormConfig",
            "admin/WorkflowConfig(/:name)": "workflowConfig",
            "admin/ActionInfo": "actionInfo",
            "admin/GroupConfig": "groupConfig",
            "admin/SecurityConfig": "securityConfig",
            "admin/UserConfig": "userConfig",
            "admin/WizardConfig": "wizardConfig",
            "admin/AdminSearchTool": "adminSearchTool",
            "admin/aclConfig": "aclConfig",
            "admin/ConfigArchiver": "configArchiver",
            "admin/LicenseManager": "licenseManager",
            "admin/DeveloperZone": "developerZone",
            "admin/NMAC": "nonMandatoryAspectConfig",
            "admin/LoggingConfig": "loggingConfig",
            "admin/IndexerConfig(/:name)" : "indexerConfig"
        },

        adminSecurity: function(fragment, args, next) {      
            this.resetTabTitle(fragment);
            // Retrieve the default that tells us if the admin URL is secured for the application.
            if(fragment !== "error/userDoesNotExist" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.ExistenceError) {
                Backbone.history.navigate("/error/userDoesNotExist", { trigger: true }, { replace: true });
            } else if(fragment !== "error/userDisabled" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.DisabledError) {
                Backbone.history.navigate("/error/userDisabled", { trigger: true }, { replace: true });
            } else if(fragment !== "error/fetchingUserData" && $.cookie("ocUser") === HPIConstants.Errors.OCUser.FetchingDataError) {
                    Backbone.history.navigate("/error/fetchingUserData", { trigger: true }, { replace: true });
            } else if (app.secureAdminUrl) {
                if(app.secureAdminUrl.viaUsernamePassword) {
                    if ($.cookie('securedAdminAccess')) {
                        $.ajax({
                            type: 'POST',
                            url: app.serviceUrlRoot + '/hpi/validateSecuredAdminAccess',
                            data: {
                                securedAdminAccess: $.cookie('securedAdminAccess')
                            },
                            success: function(validation) {
                                if (validation) {
                                    // We already have a cookie that was validated against OC, proceed processing the URL.
                                    next();
                                } else {
                                    $.removeCookie('securedAdminAccess', { path: '/' });
                                    // Let's bring up the login to allow the current user to enter credentials to access the admin.
                                    $("body").attr("class", "login");
                                    app.useLayout("layout-login").setViews({
                                        "#login-outlet": new AdminSecurity.Views.LoginView({ 'nextFunction': next })
                                    }).render();
                                }
                            },
                            error: function() {}
                        });
                    } else {
                        // Let's bring up the login to allow the current user to enter credentials to access the admin.
                        $("body").attr("class", "login");
                        app.useLayout("layout-login").setViews({
                            "#login-outlet": new AdminSecurity.Views.LoginView({ 'nextFunction': next })
                        }).render();
                    }
                }
                else if(app.secureAdminUrl.viaAdminGroupMembership){
                    var determineAccessToAdmin = function(){
                        if(_.intersection(app.user.get('groupNames'), app.secureAdminUrl.allowedHpiAdminGroups).length){ // need at least one match
                            next();
                        } else{
                            // No match was found, taking the user back to the default route.
                            app.context.configService.getApplicationConfig(function(config) {
                                Backbone.history.navigate(config.get('defaultPath'), {trigger : true});
                            });
                        }                        
                    };

                    if(app.user && _.isArray(app.user.get('groupNames')) && app.user.get('groupNames').length){
                        determineAccessToAdmin();
                    } else {
                        app.user.getGroups().done(function() {
                            determineAccessToAdmin();
                        });                            
                    }
                } else {
                    // If the admin URL it's not secured, but open to all, then continue processing the remaining of the URL.
                    next();
                }
            } else {
                // If the admin URL it's not secured, but open to all, then continue processing the remaining of the URL.
                next();
            }
        },

        applicationConfig: function() {
            // specify the configuration module to set up and the name of the config (the name just needs to match the selector to highlight the correct tabs eg:
            // id="tab-application" is on the selector, so provide everything after the "tab-" )
            executeSingleConfigRoute(AppConfig, "application", true);
        },

        picklistConfig: function() {
            executeSingleConfigRoute(PicklistConfig, "picklists");
        },
        developerZone: function() {
            executeSingleConfigRoute(DeveloperZone, "developerzone");
        },
        nonMandatoryAspectConfig: function() {
            executeSingleConfigRoute(NonMandatoryAspectConfig, "nonMandatoryAspectConfig");
        },
        loggingConfig: function() {
            executeSingleConfigRoute(LoggingConfig, "loggingConfig");
        },
        collectionConfig: function() {
            executeSingleConfigRoute(CollectionConfig, "collections");
        },
        dashboardConfig: function() {
            executeSingleConfigRoute(DashboardConfig, "dashboard", true);
        },
        formConfig: function(name) {
            executeMultipleConfigRoute(FormConfig, "forms", name);
        },
        templateManagementConfig: function(name) {
            executeSingleConfigRoute(TemplateManagementConfig, "templatemanagement", name, true);
        },
        workflowFormConfig: function(name) {
            SingleWorkflowForm.parentView = WorkflowFormConfig;
            executeMultipleConfigRoute(SingleWorkflowForm, "workflowforms", name);
        },
        workflowConfig: function() {
            executeSingleConfigRoute(WorkflowConfig, "workflow");
        },
        indexerConfig: function(name) {
            Router._executeMultipleConfigRoute(IndexerConfig, "indexer", name);
        },
        tracConfig: function(name) {
            // trac config is not like the others - it will do its own collection fetch because it maanages many models at a time
            //fetch the tracs before building the view
            var tracs = new TracConfig.Collection();
            tracs.full = true;
            tracs.fetch({
                success: function() {
                    app.log.debug("fetched trac configs, building view");
                    var subview = new TracConfig.Views.Layout({
                        collection: tracs,
                        name: name
                    });
                    var layout = setTabbedAdminView({ subview: subview, configName: "tracs" });
                    layout.render();
                },
                error: function() {
                    app.log.debug("Failed to retrieve trac configs");
                }
            });
        },
        objectTypeConfig: function() {
            executeSingleConfigRoute(Objecttypeconfig, "objecttype");
        },
        searchConfig: function(name) {
            executeMultipleConfigRoute(SearchConfig, "search", name);
        },
        stageConfig: function(name) {
            executeMultipleConfigRoute(StageConfig, "stage", name);
        },
        actionInfo: function() {
            setTabbedAdminView({ subview: new ActionInfo.Views.Layout(), configName: "actioninfo" }).render();
        },
        groupConfig: function() {
            executeSingleConfigRoute(GroupConfig, "groups", true);
        },
        securityConfig: function() {
            executeSingleConfigRoute(SecurityConfig, "security");
        },
        userConfig: function() {
            executeSingleConfigRoute(UserConfig, "users", true);
        },
        wizardConfig: function() {
            executeSingleConfigRoute(WizardConfig, "wizard");
        },
        adminSearchTool: function() {
            executeSingleConfigRoute(AdminSearchTool, "adminSearchTool");
        },
        aclConfig: function() {
            executeSingleConfigRoute(aclConfig, "aclConfig");
        },
        configArchiver: function() {
            executeSingleConfigRoute(ConfigArchiver, "configArchiver");
        }, 
        licenseManager: function() {
            setTabbedAdminView({ subview: new LicenseManager.Views.Layout(), configName: "licenseManager" }).render();
        }
    });

    /**
     * common function that sets up the core layout for all admin screens
     **/
    var setTabbedAdminView = function(options) {
        $("body").attr('class', 'hpi-admin');

        var layout = app.useLayout("layout-1-col");

        // set up the tabbed view - passing along the subview we'd like to render (the main view for the selected config)
        var adminView = new Hpiadmin.Views.Layout({
            subview: options.subview,
            currentConfig: options.configName
        });
        layout.setView('#content-outlet', adminView);

        return layout;
    };

    /**
    This function is executed by a route when a config should just have a single instance.  E.g. "Application Config" can only have one instance (app wide config)
    Params:
        configModule - a reference to this configs entire module or "class" that is referenced to build up needed Models/Collections/Views etc. This keeps everything dynamic.
        verboseName - the verbose name of the config (e.g. 'application' - used for front end things such as activating a tab based on the currently viewed config)
    **/
    var executeSingleConfigRoute = Router._executeSingleConfigRoute = function(configModule, verboseName) {
        // since we expect there will be only one application config - we don't need to worry if they routed a name
        var config = app.context.findOrCreateConfig(configModule.Model, "default");
        config.fetch({
            error: function() {
                // we didnt get one with the name default.. so lets create one...
                // config = new configModule.Model();
                config.save({}, {
                    success: function() {
                        app.log.debug("New default config has been created...");
                        var subview;
                        if (configModule.parentView) {
                            subview = new configModule.parentView.Views.Layout({ model: config });
                        } else {
                            subview = new configModule.Views.Layout({ model: config });
                        }


                        var layout = setTabbedAdminView({ subview: subview, configName: verboseName });
                        layout.render();
                    },
                    error: function(model, response) {
                        app.trigger("alert:error", { message: "Could not create config, likely it has already been created: " + response.responseText });
                    }
                });
            },
            success: function() {
                var subview = new configModule.Views.Layout({ model: config });
                var layout = setTabbedAdminView({ subview: subview, configName: verboseName });
                layout.render();
            }
        });
    };
    /**
    This function is executed by a route when a config has multiple config instances, E.g. SearchConfig can have multiple configs and be used on different tracs.
    Params:
        configModule - a reference to this configs entire module or "class" that is referenced to build up needed Models/Collections/Views etc. This keeps everything dynamic.
        verboseName - the verbose name of the config (e.g. 'application' - used for front end things such as activating a tab based on the currently viewed config)
        configName - the particular named instance of the config in which we should be showing - if not provided it will start with a blank config
    **/
    var executeMultipleConfigRoute = Router._executeMultipleConfigRoute = function(configModule, verboseName, configName, autoCreateDefault) {
        var config;
        if (configName) {
            // we are trying to load an existing config
            config = app.context.findOrCreateConfig(configModule.Model, configName, true);
            config.fetch({
                success: function() {
                    var subview;
                    if (configModule.parentView) {
                        subview = new configModule.parentView.Views.Layout({ model: config, configClass: configModule });
                    } else {
                        subview = new configModule.Views.Layout({ model: config, configClass: configModule });
                    }
                    var layout = setTabbedAdminView({ subview: subview, configName: verboseName });
                    layout.render();
                },
                error: function(model, response) {
                    app.trigger("alert:error", { message: "Could not load config with name: " + configName + ": " + response.responseText });
                }
            });
        } else {

            // if we dont have a config named default, then create one and go to it - WERE FORCING A USER TO AT LEAST SAVE A DEFAULT CONFIG
            if (autoCreateDefault) {
                config = app.context.findOrCreateConfig(configModule.Model, "default", true);
                var configCreated = $.Deferred();
                config.fetch({
                    error: function() {
                        config.set("name", "default");
                        config.save({}, {
                            success: function() {
                                configCreated.resolve();
                                app.log.debug("new default config has been created, one didn't exist...");
                            }
                        });
                    },
                    success: function() {
                        configCreated.resolve();
                    }
                });
                configCreated.done(function() {
                    var subview;
                    if (configModule.parentView) {
                        subview = new configModule.parentView.Views.Layout({ model: config, configClass: configModule });
                    } else {
                        subview = new configModule.Views.Layout({ model: config, configClass: configModule });
                    }
                    var layout = setTabbedAdminView({ subview: subview, configName: verboseName });
                    layout.render();
                });
            } else {
                config = new configModule.Model();
                var subview;
                if (configModule.parentView) {
                    subview = new configModule.parentView.Views.Layout({ model: config, configClass: configModule });
                } else {
                    subview = new configModule.Views.Layout({ model: config, configClass: configModule });
                }
                var layout = setTabbedAdminView({ subview: subview, configName: verboseName });
                layout.render();
            }
        }
    };

    return Router;
});